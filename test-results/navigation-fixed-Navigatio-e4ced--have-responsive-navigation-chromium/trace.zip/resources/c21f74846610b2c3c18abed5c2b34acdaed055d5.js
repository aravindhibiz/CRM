import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/Header.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/components/ui/Header.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import { Link, useLocation, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=44ab9529";
import toast from "/node_modules/.vite/deps/react-hot-toast.js?v=44ab9529";
import { useAuth } from "/src/contexts/AuthContext.jsx";
import Icon from "/src/components/AppIcon.jsx";
import ThemeToggle from "/src/components/ThemeToggle.jsx";
const Header = () => {
  _s();
  const { signOut, user, userProfile } = useAuth();
  const navigate = useNavigate();
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();
  const navigationItems = [
    { label: "Dashboard", path: "/sales-dashboard", icon: "BarChart3", tooltip: "Pipeline overview and metrics" },
    { label: "Deals", path: "/deal-management", icon: "Target", tooltip: "Manage deal lifecycle and opportunities" },
    { label: "Contacts", path: "/contact-management", icon: "Users", tooltip: "Customer relationship management" },
    { label: "Analytics", path: "/pipeline-analytics", icon: "TrendingUp", tooltip: "Performance insights and analysis" },
    { label: "Activity", path: "/activity-timeline", icon: "Clock", tooltip: "Interaction timeline and history" }
  ];
  const userMenuItems = [
    { label: "Settings", path: "/settings-administration", icon: "Settings" },
    { label: "Logout", action: "logout", icon: "LogOut" }
  ];
  const isActiveRoute = (path) => {
    return location.pathname === path;
  };
  const handleUserMenuToggle = () => {
    setIsUserMenuOpen(!isUserMenuOpen);
  };
  const handleMobileMenuToggle = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };
  const handleNavigation = () => {
    setIsMobileMenuOpen(false);
    setIsUserMenuOpen(false);
  };
  const handleLogout = async () => {
    console.log("handleLogout called");
    try {
      setIsUserMenuOpen(false);
      setIsMobileMenuOpen(false);
      console.log("Calling signOut...");
      await signOut();
      console.log("SignOut completed");
      toast.success("Logged out successfully!");
      navigate("/login");
    } catch (error) {
      console.error("Logout error:", error);
      toast.error("Failed to logout. Please try again.");
    }
  };
  const handleMenuItemClick = (item) => {
    if (item.action === "logout") {
      handleLogout();
    } else {
      handleNavigation();
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("header", { "data-component-id": "src\\components\\ui\\Header.jsx:72:2", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "72", "data-component-file": "Header.jsx", "data-component-name": "header", "data-component-content": "%7B%22elementName%22%3A%22header%22%2C%22className%22%3A%22fixed%20top-0%20left-0%20right-0%20bg-surface%20border-b%20border-border%20z-1000%22%7D", className: "fixed top-0 left-0 right-0 bg-surface border-b border-border z-1000", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\components\\ui\\Header.jsx:73:8", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "73", "data-component-file": "Header.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22px-6%20py-3%22%7D", className: "px-6 py-3", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\components\\ui\\Header.jsx:74:10", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "74", "data-component-file": "Header.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\components\\ui\\Header.jsx:76:12", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "76", "data-component-file": "Header.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%22%7D", className: "flex items-center", children: /* @__PURE__ */ jsxDEV(Link, { "data-component-id": "src\\components\\ui\\Header.jsx:77:14", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "77", "data-component-file": "Header.jsx", "data-component-name": "Link", "data-component-content": "%7B%22elementName%22%3A%22Link%22%2C%22className%22%3A%22flex%20items-center%20space-x-3%22%7D", to: "/sales-dashboard", className: "flex items-center space-x-3", onClick: handleNavigation, children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\components\\ui\\Header.jsx:78:16", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "78", "data-component-file": "Header.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-8%20h-8%20bg-primary%20rounded-lg%20flex%20items-center%20justify-center%22%7D", className: "w-8 h-8 bg-primary rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV("svg", { "data-component-id": "src\\components\\ui\\Header.jsx:79:18", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "79", "data-component-file": "Header.jsx", "data-component-name": "svg", "data-component-content": "%7B%22elementName%22%3A%22svg%22%7D", width: "20", height: "20", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg", children: [
          /* @__PURE__ */ jsxDEV("path", { "data-component-id": "src\\components\\ui\\Header.jsx:80:20", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "80", "data-component-file": "Header.jsx", "data-component-name": "path", "data-component-content": "%7B%22elementName%22%3A%22path%22%7D", d: "M3 13L12 4L21 13", stroke: "white", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
            lineNumber: 80,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("path", { "data-component-id": "src\\components\\ui\\Header.jsx:81:20", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "81", "data-component-file": "Header.jsx", "data-component-name": "path", "data-component-content": "%7B%22elementName%22%3A%22path%22%7D", d: "M9 21V13H15V21", stroke: "white", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
            lineNumber: 81,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
          lineNumber: 79,
          columnNumber: 19
        }, this) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
          lineNumber: 78,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\components\\ui\\Header.jsx:84:16", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "84", "data-component-file": "Header.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-xl%20font-semibold%20text-text-primary%20font-heading%22%2C%22textContent%22%3A%22SalesForce%20Pro%22%7D", className: "text-xl font-semibold text-text-primary font-heading", children: "SalesForce Pro" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
          lineNumber: 84,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
        lineNumber: 77,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
        lineNumber: 76,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("nav", { "data-component-id": "src\\components\\ui\\Header.jsx:89:12", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "89", "data-component-file": "Header.jsx", "data-component-name": "nav", "data-component-content": "%7B%22elementName%22%3A%22nav%22%2C%22className%22%3A%22hidden%20lg%3Aflex%20items-center%20space-x-1%22%7D", className: "hidden lg:flex items-center space-x-1", children: navigationItems?.map(
        (item) => /* @__PURE__ */ jsxDEV(
          Link,
          {
            "data-component-id": "src\\components\\ui\\Header.jsx:91:14",
            "data-component-path": "src\\components\\ui\\Header.jsx",
            "data-component-line": "91",
            "data-component-file": "Header.jsx",
            "data-component-name": "Link",
            "data-component-content": "%7B%22elementName%22%3A%22Link%22%7D",
            to: item?.path,
            onClick: handleNavigation,
            className: `px-6 py-4 rounded-lg text-sm font-medium transition-all duration-150 ease-smooth flex items-center space-x-2 ${isActiveRoute(item?.path) ? "bg-primary-50 text-primary border border-primary-100" : "text-text-secondary hover:text-text-primary hover:bg-surface-hover"}`,
            title: item?.tooltip,
            children: [
              /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\components\\ui\\Header.jsx:101:18", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "101", "data-component-file": "Header.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%7D", name: item?.icon, size: 16 }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
                lineNumber: 101,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\components\\ui\\Header.jsx:102:18", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "102", "data-component-file": "Header.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: item?.label }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
                lineNumber: 102,
                columnNumber: 19
              }, this)
            ]
          },
          item?.path,
          true,
          {
            fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
            lineNumber: 91,
            columnNumber: 15
          },
          this
        )
      ) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
        lineNumber: 89,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\components\\ui\\Header.jsx:108:12", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "108", "data-component-file": "Header.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-4%22%7D", className: "flex items-center space-x-4", children: [
        /* @__PURE__ */ jsxDEV(ThemeToggle, { "data-component-id": "src\\components\\ui\\Header.jsx:110:14", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "110", "data-component-file": "Header.jsx", "data-component-name": "ThemeToggle", "data-component-content": "%7B%22elementName%22%3A%22ThemeToggle%22%7D" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
          lineNumber: 110,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\components\\ui\\Header.jsx:113:14", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "113", "data-component-file": "Header.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22relative%22%7D", className: "relative", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\components\\ui\\Header.jsx:114:16",
              "data-component-path": "src\\components\\ui\\Header.jsx",
              "data-component-line": "114",
              "data-component-file": "Header.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22flex%20items-center%20space-x-3%20p-2%20rounded-lg%20hover%3Abg-surface-hover%20transition-colors%20duration-150%20ease-smooth%22%7D",
              onClick: handleUserMenuToggle,
              className: "flex items-center space-x-3 p-2 rounded-lg hover:bg-surface-hover transition-colors duration-150 ease-smooth",
              children: [
                /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\components\\ui\\Header.jsx:118:18", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "118", "data-component-file": "Header.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-8%20h-8%20bg-primary-100%20rounded-full%20flex%20items-center%20justify-center%22%7D", className: "w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\components\\ui\\Header.jsx:119:20", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "119", "data-component-file": "Header.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22User%22%2C%22className%22%3A%22text-primary%22%7D", name: "User", size: 16, className: "text-primary" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
                  lineNumber: 119,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
                  lineNumber: 118,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\components\\ui\\Header.jsx:121:18", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "121", "data-component-file": "Header.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22hidden%20md%3Ablock%20text-left%22%7D", className: "hidden md:block text-left", children: [
                  /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\components\\ui\\Header.jsx:122:20", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "122", "data-component-file": "Header.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-sm%20font-medium%20text-text-primary%22%7D", className: "text-sm font-medium text-text-primary", children: userProfile?.full_name || userProfile?.first_name || user?.email || "User" }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
                    lineNumber: 122,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\components\\ui\\Header.jsx:125:20", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "125", "data-component-file": "Header.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-xs%20text-text-secondary%22%7D", className: "text-xs text-text-secondary", children: userProfile?.role === "admin" ? "Administrator" : userProfile?.role === "manager" ? "Manager" : userProfile?.role === "sales_rep" ? "Sales Rep" : "User" }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
                    lineNumber: 125,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
                  lineNumber: 121,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\components\\ui\\Header.jsx:132:18", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "132", "data-component-file": "Header.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22ChevronDown%22%2C%22className%22%3A%22text-text-secondary%22%7D", name: "ChevronDown", size: 16, className: "text-text-secondary" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
                  lineNumber: 132,
                  columnNumber: 19
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
              lineNumber: 114,
              columnNumber: 17
            },
            this
          ),
          isUserMenuOpen && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\components\\ui\\Header.jsx:137:16", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "137", "data-component-file": "Header.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22absolute%20right-0%20mt-2%20w-48%20bg-surface%20rounded-lg%20shadow-lg%20border%20border-border%20z-1100%22%7D", className: "absolute right-0 mt-2 w-48 bg-surface rounded-lg shadow-lg border border-border z-1100", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\components\\ui\\Header.jsx:138:20", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "138", "data-component-file": "Header.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22py-2%22%7D", className: "py-2", children: userMenuItems?.map((item) => {
            if (item.action === "logout") {
              return /* @__PURE__ */ jsxDEV(
                "div",
                {
                  "data-component-id": "src\\components\\ui\\Header.jsx:142:26",
                  "data-component-path": "src\\components\\ui\\Header.jsx",
                  "data-component-line": "142",
                  "data-component-file": "Header.jsx",
                  "data-component-name": "div",
                  "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-full%20text-left%20flex%20items-center%20space-x-3%20px-4%20py-2%20text-sm%20text-text-secondary%20hover%3Atext-text-primary%20hover%3Abg-surface-hover%20transition-colors%20duration-150%20ease-smooth%20cursor-pointer%22%7D",
                  onClick: handleLogout,
                  className: "w-full text-left flex items-center space-x-3 px-4 py-2 text-sm text-text-secondary hover:text-text-primary hover:bg-surface-hover transition-colors duration-150 ease-smooth cursor-pointer",
                  children: [
                    /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\components\\ui\\Header.jsx:147:30", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "147", "data-component-file": "Header.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%7D", name: item?.icon, size: 16 }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
                      lineNumber: 147,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\components\\ui\\Header.jsx:148:30", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "148", "data-component-file": "Header.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: item?.label }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
                      lineNumber: 148,
                      columnNumber: 31
                    }, this)
                  ]
                },
                item.label,
                true,
                {
                  fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
                  lineNumber: 142,
                  columnNumber: 27
                },
                this
              );
            } else {
              return /* @__PURE__ */ jsxDEV(
                Link,
                {
                  "data-component-id": "src\\components\\ui\\Header.jsx:153:26",
                  "data-component-path": "src\\components\\ui\\Header.jsx",
                  "data-component-line": "153",
                  "data-component-file": "Header.jsx",
                  "data-component-name": "Link",
                  "data-component-content": "%7B%22elementName%22%3A%22Link%22%2C%22className%22%3A%22flex%20items-center%20space-x-3%20px-4%20py-2%20text-sm%20text-text-secondary%20hover%3Atext-text-primary%20hover%3Abg-surface-hover%20transition-colors%20duration-150%20ease-smooth%22%7D",
                  to: item?.path,
                  onClick: () => handleMenuItemClick(item),
                  className: "flex items-center space-x-3 px-4 py-2 text-sm text-text-secondary hover:text-text-primary hover:bg-surface-hover transition-colors duration-150 ease-smooth",
                  children: [
                    /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\components\\ui\\Header.jsx:159:30", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "159", "data-component-file": "Header.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%7D", name: item?.icon, size: 16 }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
                      lineNumber: 159,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\components\\ui\\Header.jsx:160:30", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "160", "data-component-file": "Header.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: item?.label }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
                      lineNumber: 160,
                      columnNumber: 31
                    }, this)
                  ]
                },
                item?.path,
                true,
                {
                  fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
                  lineNumber: 153,
                  columnNumber: 27
                },
                this
              );
            }
          }) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
            lineNumber: 138,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
            lineNumber: 137,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
          lineNumber: 113,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\components\\ui\\Header.jsx:171:14",
            "data-component-path": "src\\components\\ui\\Header.jsx",
            "data-component-line": "171",
            "data-component-file": "Header.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22lg%3Ahidden%20p-2%20text-text-secondary%20hover%3Atext-text-primary%20transition-colors%20duration-150%20ease-smooth%22%7D",
            onClick: handleMobileMenuToggle,
            className: "lg:hidden p-2 text-text-secondary hover:text-text-primary transition-colors duration-150 ease-smooth",
            children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\components\\ui\\Header.jsx:175:16", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "175", "data-component-file": "Header.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%7D", name: isMobileMenuOpen ? "X" : "Menu", size: 20 }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
              lineNumber: 175,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
            lineNumber: 171,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
        lineNumber: 108,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
      lineNumber: 74,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
      lineNumber: 73,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
      lineNumber: 72,
      columnNumber: 3
    }, this),
    isMobileMenuOpen && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\components\\ui\\Header.jsx:183:6", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "183", "data-component-file": "Header.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20z-1200%20lg%3Ahidden%22%7D", className: "fixed inset-0 z-1200 lg:hidden", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\components\\ui\\Header.jsx:184:10", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "184", "data-component-file": "Header.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20bg-black%20bg-opacity-50%22%7D", className: "fixed inset-0 bg-black bg-opacity-50", onClick: handleMobileMenuToggle }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
        lineNumber: 184,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\components\\ui\\Header.jsx:185:10", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "185", "data-component-file": "Header.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20left-0%20top-0%20bottom-0%20w-80%20bg-surface%20shadow-xl%22%7D", className: "fixed left-0 top-0 bottom-0 w-80 bg-surface shadow-xl", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\components\\ui\\Header.jsx:186:12", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "186", "data-component-file": "Header.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22p-6%22%7D", className: "p-6", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\components\\ui\\Header.jsx:187:14", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "187", "data-component-file": "Header.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%20mb-8%22%7D", className: "flex items-center justify-between mb-8", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\components\\ui\\Header.jsx:188:16", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "188", "data-component-file": "Header.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-3%22%7D", className: "flex items-center space-x-3", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\components\\ui\\Header.jsx:189:18", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "189", "data-component-file": "Header.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-8%20h-8%20bg-primary%20rounded-lg%20flex%20items-center%20justify-center%22%7D", className: "w-8 h-8 bg-primary rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV("svg", { "data-component-id": "src\\components\\ui\\Header.jsx:190:20", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "190", "data-component-file": "Header.jsx", "data-component-name": "svg", "data-component-content": "%7B%22elementName%22%3A%22svg%22%7D", width: "20", height: "20", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg", children: [
              /* @__PURE__ */ jsxDEV("path", { "data-component-id": "src\\components\\ui\\Header.jsx:191:22", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "191", "data-component-file": "Header.jsx", "data-component-name": "path", "data-component-content": "%7B%22elementName%22%3A%22path%22%7D", d: "M3 13L12 4L21 13", stroke: "white", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
                lineNumber: 191,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("path", { "data-component-id": "src\\components\\ui\\Header.jsx:192:22", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "192", "data-component-file": "Header.jsx", "data-component-name": "path", "data-component-content": "%7B%22elementName%22%3A%22path%22%7D", d: "M9 21V13H15V21", stroke: "white", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
                lineNumber: 192,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
              lineNumber: 190,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
              lineNumber: 189,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\components\\ui\\Header.jsx:195:18", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "195", "data-component-file": "Header.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-xl%20font-semibold%20text-text-primary%20font-heading%22%2C%22textContent%22%3A%22SalesForce%20Pro%22%7D", className: "text-xl font-semibold text-text-primary font-heading", children: "SalesForce Pro" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
              lineNumber: 195,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
            lineNumber: 188,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\components\\ui\\Header.jsx:197:16",
              "data-component-path": "src\\components\\ui\\Header.jsx",
              "data-component-line": "197",
              "data-component-file": "Header.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22p-2%20text-text-secondary%20hover%3Atext-text-primary%20transition-colors%20duration-150%20ease-smooth%22%7D",
              onClick: handleMobileMenuToggle,
              className: "p-2 text-text-secondary hover:text-text-primary transition-colors duration-150 ease-smooth",
              children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\components\\ui\\Header.jsx:201:18", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "201", "data-component-file": "Header.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22X%22%7D", name: "X", size: 20 }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
                lineNumber: 201,
                columnNumber: 19
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
              lineNumber: 197,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
          lineNumber: 187,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("nav", { "data-component-id": "src\\components\\ui\\Header.jsx:205:14", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "205", "data-component-file": "Header.jsx", "data-component-name": "nav", "data-component-content": "%7B%22elementName%22%3A%22nav%22%2C%22className%22%3A%22space-y-2%22%7D", className: "space-y-2", children: [
          navigationItems?.map(
            (item) => /* @__PURE__ */ jsxDEV(
              Link,
              {
                "data-component-id": "src\\components\\ui\\Header.jsx:207:14",
                "data-component-path": "src\\components\\ui\\Header.jsx",
                "data-component-line": "207",
                "data-component-file": "Header.jsx",
                "data-component-name": "Link",
                "data-component-content": "%7B%22elementName%22%3A%22Link%22%7D",
                to: item?.path,
                onClick: handleNavigation,
                className: `flex items-center space-x-3 px-4 py-3 rounded-lg text-base font-medium transition-all duration-150 ease-smooth ${isActiveRoute(item?.path) ? "bg-primary-50 text-primary border border-primary-100" : "text-text-secondary hover:text-text-primary hover:bg-surface-hover"}`,
                children: [
                  /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\components\\ui\\Header.jsx:216:20", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "216", "data-component-file": "Header.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%7D", name: item?.icon, size: 20 }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
                    lineNumber: 216,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\components\\ui\\Header.jsx:217:20", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "217", "data-component-file": "Header.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: item?.label }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
                    lineNumber: 217,
                    columnNumber: 21
                  }, this)
                ]
              },
              item?.path,
              true,
              {
                fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
                lineNumber: 207,
                columnNumber: 15
              },
              this
            )
          ),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\components\\ui\\Header.jsx:221:16", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "221", "data-component-file": "Header.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22border-t%20border-border%20my-4%22%7D", className: "border-t border-border my-4" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
            lineNumber: 221,
            columnNumber: 17
          }, this),
          userMenuItems?.map((item) => {
            if (item.action === "logout") {
              return /* @__PURE__ */ jsxDEV(
                "div",
                {
                  "data-component-id": "src\\components\\ui\\Header.jsx:226:20",
                  "data-component-path": "src\\components\\ui\\Header.jsx",
                  "data-component-line": "226",
                  "data-component-file": "Header.jsx",
                  "data-component-name": "div",
                  "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-full%20flex%20items-center%20space-x-3%20px-4%20py-3%20rounded-lg%20text-base%20font-medium%20text-text-secondary%20dark%3Atext-text-secondary%20hover%3Atext-text-primary%20dark%3Ahover%3Atext-text-primary%20hover%3Abg-surface-hover%20dark%3Ahover%3Abg-surface-hover%20transition-all%20duration-150%20ease-smooth%20cursor-pointer%22%7D",
                  onClick: handleLogout,
                  className: "w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-base font-medium text-text-secondary dark:text-text-secondary hover:text-text-primary dark:hover:text-text-primary hover:bg-surface-hover dark:hover:bg-surface-hover transition-all duration-150 ease-smooth cursor-pointer",
                  children: [
                    /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\components\\ui\\Header.jsx:231:24", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "231", "data-component-file": "Header.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%7D", name: item?.icon, size: 20 }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
                      lineNumber: 231,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\components\\ui\\Header.jsx:232:24", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "232", "data-component-file": "Header.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: item?.label }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
                      lineNumber: 232,
                      columnNumber: 25
                    }, this)
                  ]
                },
                item.label,
                true,
                {
                  fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
                  lineNumber: 226,
                  columnNumber: 21
                },
                this
              );
            } else {
              return /* @__PURE__ */ jsxDEV(
                Link,
                {
                  "data-component-id": "src\\components\\ui\\Header.jsx:237:20",
                  "data-component-path": "src\\components\\ui\\Header.jsx",
                  "data-component-line": "237",
                  "data-component-file": "Header.jsx",
                  "data-component-name": "Link",
                  "data-component-content": "%7B%22elementName%22%3A%22Link%22%2C%22className%22%3A%22flex%20items-center%20space-x-3%20px-4%20py-3%20rounded-lg%20text-base%20font-medium%20text-text-secondary%20dark%3Atext-text-secondary%20hover%3Atext-text-primary%20dark%3Ahover%3Atext-text-primary%20hover%3Abg-surface-hover%20dark%3Ahover%3Abg-surface-hover%20transition-all%20duration-150%20ease-smooth%22%7D",
                  to: item?.path,
                  onClick: () => handleMenuItemClick(item),
                  className: "flex items-center space-x-3 px-4 py-3 rounded-lg text-base font-medium text-text-secondary dark:text-text-secondary hover:text-text-primary dark:hover:text-text-primary hover:bg-surface-hover dark:hover:bg-surface-hover transition-all duration-150 ease-smooth",
                  children: [
                    /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\components\\ui\\Header.jsx:243:24", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "243", "data-component-file": "Header.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%7D", name: item?.icon, size: 20 }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
                      lineNumber: 243,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\components\\ui\\Header.jsx:244:24", "data-component-path": "src\\components\\ui\\Header.jsx", "data-component-line": "244", "data-component-file": "Header.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: item?.label }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
                      lineNumber: 244,
                      columnNumber: 25
                    }, this)
                  ]
                },
                item?.path,
                true,
                {
                  fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
                  lineNumber: 237,
                  columnNumber: 21
                },
                this
              );
            }
          })
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
          lineNumber: 205,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
        lineNumber: 186,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
        lineNumber: 185,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
      lineNumber: 183,
      columnNumber: 7
    }, this),
    isUserMenuOpen && /* @__PURE__ */ jsxDEV(
      "div",
      {
        "data-component-id": "src\\components\\ui\\Header.jsx:257:6",
        "data-component-path": "src\\components\\ui\\Header.jsx",
        "data-component-line": "257",
        "data-component-file": "Header.jsx",
        "data-component-name": "div",
        "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20z-1050%22%7D",
        className: "fixed inset-0 z-1050",
        onClick: () => setIsUserMenuOpen(false)
      },
      void 0,
      false,
      {
        fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
        lineNumber: 257,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/components/ui/Header.jsx",
    lineNumber: 71,
    columnNumber: 5
  }, this);
};
_s(Header, "vP+yz2f6QwSXklTDVeO5ynZS6CU=", false, function() {
  return [useAuth, useNavigate, useLocation];
});
_c = Header;
export default Header;
var _c;
$RefreshReg$(_c, "Header");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/components/ui/Header.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/components/ui/Header.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0VJLG1CQVNnQixjQVRoQjsyQkF0RUo7QUFBZ0JBLE1BQVEsY0FBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN2QyxTQUFTQyxNQUFNQyxhQUFhQyxtQkFBbUI7QUFDL0MsT0FBT0MsV0FBVztBQUNsQixTQUFTQyxlQUFlO0FBQ3hCLE9BQU9DLFVBQVU7QUFDakIsT0FBT0MsaUJBQWlCO0FBRXhCLE1BQU1DLFNBQVNBLE1BQU07QUFBQUMsS0FBQTtBQUNuQixRQUFNLEVBQUVDLFNBQVNDLE1BQU1DLFlBQVksSUFBSVAsUUFBUTtBQUMvQyxRQUFNUSxXQUFXVixZQUFZO0FBQzdCLFFBQU0sQ0FBQ1csZ0JBQWdCQyxpQkFBaUIsSUFBSWYsU0FBUyxLQUFLO0FBQzFELFFBQU0sQ0FBQ2dCLGtCQUFrQkMsbUJBQW1CLElBQUlqQixTQUFTLEtBQUs7QUFDOUQsUUFBTWtCLFdBQVdoQixZQUFZO0FBRTdCLFFBQU1pQixrQkFBa0I7QUFBQSxJQUN0QixFQUFFQyxPQUFPLGFBQWFDLE1BQU0sb0JBQW9CQyxNQUFNLGFBQWFDLFNBQVMsZ0NBQWdDO0FBQUEsSUFDNUcsRUFBRUgsT0FBTyxTQUFTQyxNQUFNLG9CQUFvQkMsTUFBTSxVQUFVQyxTQUFTLDBDQUEwQztBQUFBLElBQy9HLEVBQUVILE9BQU8sWUFBWUMsTUFBTSx1QkFBdUJDLE1BQU0sU0FBU0MsU0FBUyxtQ0FBbUM7QUFBQSxJQUM3RyxFQUFFSCxPQUFPLGFBQWFDLE1BQU0sdUJBQXVCQyxNQUFNLGNBQWNDLFNBQVMsb0NBQW9DO0FBQUEsSUFDcEgsRUFBRUgsT0FBTyxZQUFZQyxNQUFNLHNCQUFzQkMsTUFBTSxTQUFTQyxTQUFTLG1DQUFtQztBQUFBLEVBQUM7QUFHL0csUUFBTUMsZ0JBQWdCO0FBQUEsSUFDdEIsRUFBRUosT0FBTyxZQUFZQyxNQUFNLDRCQUE0QkMsTUFBTSxXQUFXO0FBQUEsSUFDeEUsRUFBRUYsT0FBTyxVQUFVSyxRQUFRLFVBQVVILE1BQU0sU0FBUztBQUFBLEVBQUM7QUFHckQsUUFBTUksZ0JBQWdCQSxDQUFDTCxTQUFTO0FBQzlCLFdBQU9ILFNBQVNTLGFBQWFOO0FBQUFBLEVBQy9CO0FBRUEsUUFBTU8sdUJBQXVCQSxNQUFNO0FBQ2pDYixzQkFBa0IsQ0FBQ0QsY0FBYztBQUFBLEVBQ25DO0FBRUEsUUFBTWUseUJBQXlCQSxNQUFNO0FBQ25DWix3QkFBb0IsQ0FBQ0QsZ0JBQWdCO0FBQUEsRUFDdkM7QUFFQSxRQUFNYyxtQkFBbUJBLE1BQU07QUFDN0JiLHdCQUFvQixLQUFLO0FBQ3pCRixzQkFBa0IsS0FBSztBQUFBLEVBQ3pCO0FBRUEsUUFBTWdCLGVBQWUsWUFBWTtBQUMvQkMsWUFBUUMsSUFBSSxxQkFBcUI7QUFDakMsUUFBSTtBQUNGbEIsd0JBQWtCLEtBQUs7QUFDdkJFLDBCQUFvQixLQUFLO0FBRXpCZSxjQUFRQyxJQUFJLG9CQUFvQjtBQUNoQyxZQUFNdkIsUUFBUTtBQUNkc0IsY0FBUUMsSUFBSSxtQkFBbUI7QUFDL0I3QixZQUFNOEIsUUFBUSwwQkFBMEI7QUFDeENyQixlQUFTLFFBQVE7QUFBQSxJQUNuQixTQUFTc0IsT0FBTztBQUNkSCxjQUFRRyxNQUFNLGlCQUFpQkEsS0FBSztBQUNwQy9CLFlBQU0rQixNQUFNLHFDQUFxQztBQUFBLElBQ25EO0FBQUEsRUFDRjtBQUVBLFFBQU1DLHNCQUFzQkEsQ0FBQ0MsU0FBUztBQUNwQyxRQUFJQSxLQUFLWixXQUFXLFVBQVU7QUFDNUJNLG1CQUFhO0FBQUEsSUFDZixPQUFPO0FBQ0xELHVCQUFpQjtBQUFBLElBQ25CO0FBQUEsRUFDRjtBQUVBLFNBQ0UsbUNBQ0Y7QUFBQSwyQkFBQyxzWkFBTyxXQUFVLHVFQUNaLGlDQUFDLHVVQUFJLFdBQVUsYUFDYixpQ0FBQyxrV0FBSSxXQUFVLHFDQUViO0FBQUEsNkJBQUMsZ1ZBQUksV0FBVSxxQkFDYixpQ0FBQyw2VkFBSyxJQUFHLG9CQUFtQixXQUFVLCtCQUE4QixTQUFTQSxrQkFDM0U7QUFBQSwrQkFBQyx1WUFBSSxXQUFVLGtFQUNiLGlDQUFDLGtTQUFJLE9BQU0sTUFBSyxRQUFPLE1BQUssU0FBUSxhQUFZLE1BQUssUUFBTyxPQUFNLDhCQUNoRTtBQUFBLGlDQUFDLHFTQUFLLEdBQUUsb0JBQW1CLFFBQU8sU0FBUSxhQUFZLEtBQUksZUFBYyxTQUFRLGdCQUFlLFdBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNHO0FBQUEsVUFDdEcsdUJBQUMscVNBQUssR0FBRSxrQkFBaUIsUUFBTyxTQUFRLGFBQVksS0FBSSxlQUFjLFNBQVEsZ0JBQWUsV0FBN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0c7QUFBQSxhQUZ0RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUNBLHVCQUFDLHVhQUFLLFdBQVUsd0RBQXVELDhCQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFGO0FBQUEsV0FQdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsTUFHQSx1QkFBQywwV0FBSSxXQUFVLHlDQUNaWCwyQkFBaUJtQjtBQUFBQSxRQUFJLENBQUNELFNBQ3JCO0FBQUEsVUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFFQyxJQUFJQSxNQUFNaEI7QUFBQUEsWUFDVixTQUFTUztBQUFBQSxZQUNULFdBQVcsZ0hBQ1RKLGNBQWNXLE1BQU1oQixJQUFJLElBQ3BCLHlEQUF5RCxvRUFBb0U7QUFBQSxZQUVuSSxPQUFPZ0IsTUFBTWQ7QUFBQUEsWUFFYjtBQUFBLHFDQUFDLHFTQUFLLE1BQU1jLE1BQU1mLE1BQU0sTUFBTSxNQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpQztBQUFBLGNBQ2pDLHVCQUFDLHVTQUFNZSxnQkFBTWpCLFNBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUI7QUFBQTtBQUFBO0FBQUEsVUFWZGlCLE1BQU1oQjtBQUFBQSxVQURiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFZQTtBQUFBLE1BQ0QsS0FmSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0JBO0FBQUEsTUFHQSx1QkFBQyw4VkFBSSxXQUFVLCtCQUViO0FBQUEsK0JBQUMsNFRBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFZO0FBQUEsUUFHWix1QkFBQyx1VUFBSSxXQUFVLFlBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsU0FBU087QUFBQUEsY0FDVCxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLCtZQUFJLFdBQVUsd0VBQ2IsaUNBQUMsc1dBQUssTUFBSyxRQUFPLE1BQU0sSUFBSSxXQUFVLGtCQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvRCxLQUR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsOFZBQUksV0FBVSw2QkFDYjtBQUFBLHlDQUFDLHdXQUFJLFdBQVUseUNBQ1poQix1QkFBYTJCLGFBQWEzQixhQUFhNEIsY0FBYzdCLE1BQU04QixTQUFTLFVBRHZFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyw0VkFBSSxXQUFVLCtCQUNaN0IsdUJBQWE4QixTQUFTLFVBQVUsa0JBQ2hDOUIsYUFBYThCLFNBQVMsWUFBWSxZQUNsQzlCLGFBQWE4QixTQUFTLGNBQWMsY0FDcEMsVUFKSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUtBO0FBQUEscUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFVQTtBQUFBLGdCQUNBLHVCQUFDLG9YQUFLLE1BQUssZUFBYyxNQUFNLElBQUksV0FBVSx5QkFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0U7QUFBQTtBQUFBO0FBQUEsWUFsQnBFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQW1CQTtBQUFBLFVBR0M1QixrQkFDQyx1QkFBQyx1YUFBSSxXQUFVLDBGQUNiLGlDQUFDLG1VQUFJLFdBQVUsUUFDWlUseUJBQWVjLElBQUksQ0FBQ0QsU0FBUztBQUM1QixnQkFBSUEsS0FBS1osV0FBVyxVQUFVO0FBQzVCLHFCQUNFO0FBQUEsZ0JBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUVDLFNBQVNNO0FBQUFBLGtCQUNULFdBQVU7QUFBQSxrQkFFVjtBQUFBLDJDQUFDLHFTQUFLLE1BQU1NLE1BQU1mLE1BQU0sTUFBTSxNQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpQztBQUFBLG9CQUNqQyx1QkFBQyx1U0FBTWUsZ0JBQU1qQixTQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW1CO0FBQUE7QUFBQTtBQUFBLGdCQUxkaUIsS0FBS2pCO0FBQUFBLGdCQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPQTtBQUFBLFlBRUosT0FBTztBQUNMLHFCQUNFO0FBQUEsZ0JBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUVDLElBQUlpQixNQUFNaEI7QUFBQUEsa0JBQ1YsU0FBUyxNQUFNZSxvQkFBb0JDLElBQUk7QUFBQSxrQkFDdkMsV0FBVTtBQUFBLGtCQUVWO0FBQUEsMkNBQUMscVNBQUssTUFBTUEsTUFBTWYsTUFBTSxNQUFNLE1BQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlDO0FBQUEsb0JBQ2pDLHVCQUFDLHVTQUFNZSxnQkFBTWpCLFNBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBbUI7QUFBQTtBQUFBO0FBQUEsZ0JBTmRpQixNQUFNaEI7QUFBQUEsZ0JBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVFBO0FBQUEsWUFFSjtBQUFBLFVBQ0YsQ0FBQyxLQTFCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTJCQSxLQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTZCQTtBQUFBLGFBckRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF1REE7QUFBQSxRQUdBO0FBQUEsVUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFDQyxTQUFTUTtBQUFBQSxZQUNULFdBQVU7QUFBQSxZQUVWLGlDQUFDLHFTQUFLLE1BQU1iLG1CQUFtQixNQUFNLFFBQVEsTUFBTSxNQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRDtBQUFBO0FBQUEsVUFKeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxXQXBFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUVBO0FBQUEsU0F2R0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXdHQSxLQXpHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMEdBLEtBM0dOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E0R0k7QUFBQSxJQUVDQSxvQkFDQyx1QkFBQyxvV0FBSSxXQUFVLGtDQUNiO0FBQUEsNkJBQUMseVdBQUksV0FBVSx3Q0FBdUMsU0FBU2EsMEJBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUY7QUFBQSxNQUN2Rix1QkFBQyxnWUFBSSxXQUFVLHlEQUNiLGlDQUFDLGtVQUFJLFdBQVUsT0FDYjtBQUFBLCtCQUFDLDJXQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyw4VkFBSSxXQUFVLCtCQUNiO0FBQUEsbUNBQUMseVlBQUksV0FBVSxrRUFDYixpQ0FBQyxvU0FBSSxPQUFNLE1BQUssUUFBTyxNQUFLLFNBQVEsYUFBWSxNQUFLLFFBQU8sT0FBTSw4QkFDaEU7QUFBQSxxQ0FBQyx1U0FBSyxHQUFFLG9CQUFtQixRQUFPLFNBQVEsYUFBWSxLQUFJLGVBQWMsU0FBUSxnQkFBZSxXQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzRztBQUFBLGNBQ3RHLHVCQUFDLHVTQUFLLEdBQUUsa0JBQWlCLFFBQU8sU0FBUSxhQUFZLEtBQUksZUFBYyxTQUFRLGdCQUFlLFdBQTdGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9HO0FBQUEsaUJBRnRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsWUFDQSx1QkFBQyx5YUFBSyxXQUFVLHdEQUF1RCw4QkFBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUY7QUFBQSxlQVB2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsU0FBU0E7QUFBQUEsY0FDVCxXQUFVO0FBQUEsY0FFVixpQ0FBQyw0VEFBSyxNQUFLLEtBQUksTUFBTSxNQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3QjtBQUFBO0FBQUEsWUFKMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxhQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkE7QUFBQSxRQUVBLHVCQUFDLHdVQUFJLFdBQVUsYUFDWlY7QUFBQUEsMkJBQWlCbUI7QUFBQUEsWUFBSSxDQUFDRCxTQUNyQjtBQUFBLGNBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUVDLElBQUlBLE1BQU1oQjtBQUFBQSxnQkFDVixTQUFTUztBQUFBQSxnQkFDVCxXQUFXLGtIQUNQSixjQUFjVyxNQUFNaEIsSUFBSSxJQUNwQix5REFBeUQsb0VBQW9FO0FBQUEsZ0JBR3JJO0FBQUEseUNBQUMscVNBQUssTUFBTWdCLE1BQU1mLE1BQU0sTUFBTSxNQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpQztBQUFBLGtCQUNqQyx1QkFBQyx1U0FBTWUsZ0JBQU1qQixTQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW1CO0FBQUE7QUFBQTtBQUFBLGNBVGRpQixNQUFNaEI7QUFBQUEsY0FEYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBV0E7QUFBQSxVQUNEO0FBQUEsVUFFRCx1QkFBQyw4VkFBSSxXQUFVLGlDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZDO0FBQUEsVUFFNUNHLGVBQWVjLElBQUksQ0FBQ0QsU0FBUztBQUM1QixnQkFBSUEsS0FBS1osV0FBVyxVQUFVO0FBQzVCLHFCQUNFO0FBQUEsZ0JBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUVDLFNBQVNNO0FBQUFBLGtCQUNULFdBQVU7QUFBQSxrQkFFVjtBQUFBLDJDQUFDLHFTQUFLLE1BQU1NLE1BQU1mLE1BQU0sTUFBTSxNQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpQztBQUFBLG9CQUNqQyx1QkFBQyx1U0FBTWUsZ0JBQU1qQixTQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW1CO0FBQUE7QUFBQTtBQUFBLGdCQUxkaUIsS0FBS2pCO0FBQUFBLGdCQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPQTtBQUFBLFlBRUosT0FBTztBQUNMLHFCQUNFO0FBQUEsZ0JBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUVDLElBQUlpQixNQUFNaEI7QUFBQUEsa0JBQ1YsU0FBUyxNQUFNZSxvQkFBb0JDLElBQUk7QUFBQSxrQkFDdkMsV0FBVTtBQUFBLGtCQUVWO0FBQUEsMkNBQUMscVNBQUssTUFBTUEsTUFBTWYsTUFBTSxNQUFNLE1BQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlDO0FBQUEsb0JBQ2pDLHVCQUFDLHVTQUFNZSxnQkFBTWpCLFNBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBbUI7QUFBQTtBQUFBO0FBQUEsZ0JBTmRpQixNQUFNaEI7QUFBQUEsZ0JBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVFBO0FBQUEsWUFFSjtBQUFBLFVBQ0YsQ0FBQztBQUFBLGFBM0NIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0Q0E7QUFBQSxXQS9ERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0VBLEtBakVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrRUE7QUFBQSxTQXBFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUVBO0FBQUEsSUFJRFAsa0JBQ0M7QUFBQSxNQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUNDLFdBQVU7QUFBQSxRQUNWLFNBQVMsTUFBTUMsa0JBQWtCLEtBQUs7QUFBQTtBQUFBLE1BRnhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUdDO0FBQUEsT0E3TEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQStMQTtBQUVKO0FBQUVOLEdBaFFJRCxRQUFNO0FBQUEsVUFDNkJILFNBQ3RCRixhQUdBRCxXQUFXO0FBQUE7QUFBQXlDLEtBTHhCbkM7QUFrUU4sZUFBZUE7QUFBTyxJQUFBbUM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiTGluayIsInVzZUxvY2F0aW9uIiwidXNlTmF2aWdhdGUiLCJ0b2FzdCIsInVzZUF1dGgiLCJJY29uIiwiVGhlbWVUb2dnbGUiLCJIZWFkZXIiLCJfcyIsInNpZ25PdXQiLCJ1c2VyIiwidXNlclByb2ZpbGUiLCJuYXZpZ2F0ZSIsImlzVXNlck1lbnVPcGVuIiwic2V0SXNVc2VyTWVudU9wZW4iLCJpc01vYmlsZU1lbnVPcGVuIiwic2V0SXNNb2JpbGVNZW51T3BlbiIsImxvY2F0aW9uIiwibmF2aWdhdGlvbkl0ZW1zIiwibGFiZWwiLCJwYXRoIiwiaWNvbiIsInRvb2x0aXAiLCJ1c2VyTWVudUl0ZW1zIiwiYWN0aW9uIiwiaXNBY3RpdmVSb3V0ZSIsInBhdGhuYW1lIiwiaGFuZGxlVXNlck1lbnVUb2dnbGUiLCJoYW5kbGVNb2JpbGVNZW51VG9nZ2xlIiwiaGFuZGxlTmF2aWdhdGlvbiIsImhhbmRsZUxvZ291dCIsImNvbnNvbGUiLCJsb2ciLCJzdWNjZXNzIiwiZXJyb3IiLCJoYW5kbGVNZW51SXRlbUNsaWNrIiwiaXRlbSIsIm1hcCIsImZ1bGxfbmFtZSIsImZpcnN0X25hbWUiLCJlbWFpbCIsInJvbGUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkhlYWRlci5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBMaW5rLCB1c2VMb2NhdGlvbiwgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0IHRvYXN0IGZyb20gJ3JlYWN0LWhvdC10b2FzdCc7XHJcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tICcuLi8uLi9jb250ZXh0cy9BdXRoQ29udGV4dCc7XHJcbmltcG9ydCBJY29uIGZyb20gJy4uL0FwcEljb24nO1xyXG5pbXBvcnQgVGhlbWVUb2dnbGUgZnJvbSAnLi4vVGhlbWVUb2dnbGUnO1xyXG5cclxuY29uc3QgSGVhZGVyID0gKCkgPT4ge1xyXG4gIGNvbnN0IHsgc2lnbk91dCwgdXNlciwgdXNlclByb2ZpbGUgfSA9IHVzZUF1dGgoKTtcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcbiAgY29uc3QgW2lzVXNlck1lbnVPcGVuLCBzZXRJc1VzZXJNZW51T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2lzTW9iaWxlTWVudU9wZW4sIHNldElzTW9iaWxlTWVudU9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcclxuXHJcbiAgY29uc3QgbmF2aWdhdGlvbkl0ZW1zID0gW1xyXG4gICAgeyBsYWJlbDogJ0Rhc2hib2FyZCcsIHBhdGg6ICcvc2FsZXMtZGFzaGJvYXJkJywgaWNvbjogJ0JhckNoYXJ0MycsIHRvb2x0aXA6ICdQaXBlbGluZSBvdmVydmlldyBhbmQgbWV0cmljcycgfSxcclxuICAgIHsgbGFiZWw6ICdEZWFscycsIHBhdGg6ICcvZGVhbC1tYW5hZ2VtZW50JywgaWNvbjogJ1RhcmdldCcsIHRvb2x0aXA6ICdNYW5hZ2UgZGVhbCBsaWZlY3ljbGUgYW5kIG9wcG9ydHVuaXRpZXMnIH0sXHJcbiAgICB7IGxhYmVsOiAnQ29udGFjdHMnLCBwYXRoOiAnL2NvbnRhY3QtbWFuYWdlbWVudCcsIGljb246ICdVc2VycycsIHRvb2x0aXA6ICdDdXN0b21lciByZWxhdGlvbnNoaXAgbWFuYWdlbWVudCcgfSxcclxuICAgIHsgbGFiZWw6ICdBbmFseXRpY3MnLCBwYXRoOiAnL3BpcGVsaW5lLWFuYWx5dGljcycsIGljb246ICdUcmVuZGluZ1VwJywgdG9vbHRpcDogJ1BlcmZvcm1hbmNlIGluc2lnaHRzIGFuZCBhbmFseXNpcycgfSxcclxuICAgIHsgbGFiZWw6ICdBY3Rpdml0eScsIHBhdGg6ICcvYWN0aXZpdHktdGltZWxpbmUnLCBpY29uOiAnQ2xvY2snLCB0b29sdGlwOiAnSW50ZXJhY3Rpb24gdGltZWxpbmUgYW5kIGhpc3RvcnknIH1cclxuICBdO1xyXG5cclxuICBjb25zdCB1c2VyTWVudUl0ZW1zID0gW1xyXG4gIHsgbGFiZWw6ICdTZXR0aW5ncycsIHBhdGg6ICcvc2V0dGluZ3MtYWRtaW5pc3RyYXRpb24nLCBpY29uOiAnU2V0dGluZ3MnIH0sXHJcbiAgeyBsYWJlbDogJ0xvZ291dCcsIGFjdGlvbjogJ2xvZ291dCcsIGljb246ICdMb2dPdXQnIH1cclxuICBdO1xyXG5cclxuICBjb25zdCBpc0FjdGl2ZVJvdXRlID0gKHBhdGgpID0+IHtcclxuICAgIHJldHVybiBsb2NhdGlvbi5wYXRobmFtZSA9PT0gcGF0aDtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVVc2VyTWVudVRvZ2dsZSA9ICgpID0+IHtcclxuICAgIHNldElzVXNlck1lbnVPcGVuKCFpc1VzZXJNZW51T3Blbik7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlTW9iaWxlTWVudVRvZ2dsZSA9ICgpID0+IHtcclxuICAgIHNldElzTW9iaWxlTWVudU9wZW4oIWlzTW9iaWxlTWVudU9wZW4pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZU5hdmlnYXRpb24gPSAoKSA9PiB7XHJcbiAgICBzZXRJc01vYmlsZU1lbnVPcGVuKGZhbHNlKTtcclxuICAgIHNldElzVXNlck1lbnVPcGVuKGZhbHNlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVMb2dvdXQgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBjb25zb2xlLmxvZygnaGFuZGxlTG9nb3V0IGNhbGxlZCcpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0SXNVc2VyTWVudU9wZW4oZmFsc2UpO1xyXG4gICAgICBzZXRJc01vYmlsZU1lbnVPcGVuKGZhbHNlKTtcclxuICAgICAgXHJcbiAgICAgIGNvbnNvbGUubG9nKCdDYWxsaW5nIHNpZ25PdXQuLi4nKTtcclxuICAgICAgYXdhaXQgc2lnbk91dCgpO1xyXG4gICAgICBjb25zb2xlLmxvZygnU2lnbk91dCBjb21wbGV0ZWQnKTtcclxuICAgICAgdG9hc3Quc3VjY2VzcygnTG9nZ2VkIG91dCBzdWNjZXNzZnVsbHkhJyk7XHJcbiAgICAgIG5hdmlnYXRlKCcvbG9naW4nKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0xvZ291dCBlcnJvcjonLCBlcnJvcik7XHJcbiAgICAgIHRvYXN0LmVycm9yKCdGYWlsZWQgdG8gbG9nb3V0LiBQbGVhc2UgdHJ5IGFnYWluLicpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZU1lbnVJdGVtQ2xpY2sgPSAoaXRlbSkgPT4ge1xyXG4gICAgaWYgKGl0ZW0uYWN0aW9uID09PSAnbG9nb3V0Jykge1xyXG4gICAgICBoYW5kbGVMb2dvdXQoKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGhhbmRsZU5hdmlnYXRpb24oKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICA8aGVhZGVyIGNsYXNzTmFtZT1cImZpeGVkIHRvcC0wIGxlZnQtMCByaWdodC0wIGJnLXN1cmZhY2UgYm9yZGVyLWIgYm9yZGVyLWJvcmRlciB6LTEwMDBcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcHktM1wiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgey8qIExvZ28gKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICA8TGluayB0bz1cIi9zYWxlcy1kYXNoYm9hcmRcIiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTNcIiBvbkNsaWNrPXtoYW5kbGVOYXZpZ2F0aW9ufT5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGgtOCBiZy1wcmltYXJ5IHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPHN2ZyB3aWR0aD1cIjIwXCIgaGVpZ2h0PVwiMjBcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgZmlsbD1cIm5vbmVcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHBhdGggZD1cIk0zIDEzTDEyIDRMMjEgMTNcIiBzdHJva2U9XCJ3aGl0ZVwiIHN0cm9rZVdpZHRoPVwiMlwiIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIi8+XHJcbiAgICAgICAgICAgICAgICAgICAgPHBhdGggZD1cIk05IDIxVjEzSDE1VjIxXCIgc3Ryb2tlPVwid2hpdGVcIiBzdHJva2VXaWR0aD1cIjJcIiBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIvPlxyXG4gICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkIHRleHQtdGV4dC1wcmltYXJ5IGZvbnQtaGVhZGluZ1wiPlNhbGVzRm9yY2UgUHJvPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogRGVza3RvcCBOYXZpZ2F0aW9uICovfVxyXG4gICAgICAgICAgICA8bmF2IGNsYXNzTmFtZT1cImhpZGRlbiBsZzpmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTFcIj5cclxuICAgICAgICAgICAgICB7bmF2aWdhdGlvbkl0ZW1zPy5tYXAoKGl0ZW0pID0+IChcclxuICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgIGtleT17aXRlbT8ucGF0aH1cclxuICAgICAgICAgICAgICAgICAgdG89e2l0ZW0/LnBhdGh9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZU5hdmlnYXRpb259XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTYgcHktNCByb3VuZGVkLWxnIHRleHQtc20gZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMTUwIGVhc2Utc21vb3RoIGZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMiAke1xyXG4gICAgICAgICAgICAgICAgICAgIGlzQWN0aXZlUm91dGUoaXRlbT8ucGF0aClcclxuICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXByaW1hcnktNTAgdGV4dC1wcmltYXJ5IGJvcmRlciBib3JkZXItcHJpbWFyeS0xMDAnIDogJ3RleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC10ZXh0LXByaW1hcnkgaG92ZXI6Ymctc3VyZmFjZS1ob3ZlcidcclxuICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgIHRpdGxlPXtpdGVtPy50b29sdGlwfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPXtpdGVtPy5pY29ufSBzaXplPXsxNn0gLz5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4+e2l0ZW0/LmxhYmVsfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9uYXY+XHJcblxyXG4gICAgICAgICAgICB7LyogUmlnaHQgU2lkZSBBY3Rpb25zICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgIHsvKiBUaGVtZSBUb2dnbGUgKi99XHJcbiAgICAgICAgICAgICAgPFRoZW1lVG9nZ2xlIC8+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBVc2VyIE1lbnUgKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVVc2VyTWVudVRvZ2dsZX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0zIHAtMiByb3VuZGVkLWxnIGhvdmVyOmJnLXN1cmZhY2UtaG92ZXIgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwIGVhc2Utc21vb3RoXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggaC04IGJnLXByaW1hcnktMTAwIHJvdW5kZWQtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJVc2VyXCIgc2l6ZT17MTZ9IGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpZGRlbiBtZDpibG9jayB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnlcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHt1c2VyUHJvZmlsZT8uZnVsbF9uYW1lIHx8IHVzZXJQcm9maWxlPy5maXJzdF9uYW1lIHx8IHVzZXI/LmVtYWlsIHx8ICdVc2VyJ31cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC10ZXh0LXNlY29uZGFyeVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3VzZXJQcm9maWxlPy5yb2xlID09PSAnYWRtaW4nID8gJ0FkbWluaXN0cmF0b3InIDpcclxuICAgICAgICAgICAgICAgICAgICAgICB1c2VyUHJvZmlsZT8ucm9sZSA9PT0gJ21hbmFnZXInID8gJ01hbmFnZXInIDpcclxuICAgICAgICAgICAgICAgICAgICAgICB1c2VyUHJvZmlsZT8ucm9sZSA9PT0gJ3NhbGVzX3JlcCcgPyAnU2FsZXMgUmVwJyA6IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICdVc2VyJ31cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJDaGV2cm9uRG93blwiIHNpemU9ezE2fSBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5XCIgLz5cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBVc2VyIERyb3Bkb3duICovfVxyXG4gICAgICAgICAgICAgICAge2lzVXNlck1lbnVPcGVuICYmIChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC0wIG10LTIgdy00OCBiZy1zdXJmYWNlIHJvdW5kZWQtbGcgc2hhZG93LWxnIGJvcmRlciBib3JkZXItYm9yZGVyIHotMTEwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3VzZXJNZW51SXRlbXM/Lm1hcCgoaXRlbSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaXRlbS5hY3Rpb24gPT09ICdsb2dvdXQnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpdGVtLmxhYmVsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVMb2dvdXR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWxlZnQgZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0zIHB4LTQgcHktMiB0ZXh0LXNtIHRleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC10ZXh0LXByaW1hcnkgaG92ZXI6Ymctc3VyZmFjZS1ob3ZlciB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTAgZWFzZS1zbW9vdGggY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPXtpdGVtPy5pY29ufSBzaXplPXsxNn0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2l0ZW0/LmxhYmVsfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aXRlbT8ucGF0aH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG89e2l0ZW0/LnBhdGh9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZU1lbnVJdGVtQ2xpY2soaXRlbSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMyBweC00IHB5LTIgdGV4dC1zbSB0ZXh0LXRleHQtc2Vjb25kYXJ5IGhvdmVyOnRleHQtdGV4dC1wcmltYXJ5IGhvdmVyOmJnLXN1cmZhY2UtaG92ZXIgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwIGVhc2Utc21vb3RoXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT17aXRlbT8uaWNvbn0gc2l6ZT17MTZ9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntpdGVtPy5sYWJlbH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIE1vYmlsZSBNZW51IEJ1dHRvbiAqL31cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVNb2JpbGVNZW51VG9nZ2xlfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibGc6aGlkZGVuIHAtMiB0ZXh0LXRleHQtc2Vjb25kYXJ5IGhvdmVyOnRleHQtdGV4dC1wcmltYXJ5IHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MCBlYXNlLXNtb290aFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPEljb24gbmFtZT17aXNNb2JpbGVNZW51T3BlbiA/IFwiWFwiIDogXCJNZW51XCJ9IHNpemU9ezIwfSAvPlxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2hlYWRlcj5cclxuICAgICAgey8qIE1vYmlsZSBOYXZpZ2F0aW9uIERyYXdlciAqL31cclxuICAgICAge2lzTW9iaWxlTWVudU9wZW4gJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTEyMDAgbGc6aGlkZGVuXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctYmxhY2sgYmctb3BhY2l0eS01MFwiIG9uQ2xpY2s9e2hhbmRsZU1vYmlsZU1lbnVUb2dnbGV9PjwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBsZWZ0LTAgdG9wLTAgYm90dG9tLTAgdy04MCBiZy1zdXJmYWNlIHNoYWRvdy14bFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNlwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLThcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGgtOCBiZy1wcmltYXJ5IHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3ZnIHdpZHRoPVwiMjBcIiBoZWlnaHQ9XCIyMFwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBmaWxsPVwibm9uZVwiIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwYXRoIGQ9XCJNMyAxM0wxMiA0TDIxIDEzXCIgc3Ryb2tlPVwid2hpdGVcIiBzdHJva2VXaWR0aD1cIjJcIiBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD1cIk05IDIxVjEzSDE1VjIxXCIgc3Ryb2tlPVwid2hpdGVcIiBzdHJva2VXaWR0aD1cIjJcIiBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkIHRleHQtdGV4dC1wcmltYXJ5IGZvbnQtaGVhZGluZ1wiPlNhbGVzRm9yY2UgUHJvPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZU1vYmlsZU1lbnVUb2dnbGV9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiB0ZXh0LXRleHQtc2Vjb25kYXJ5IGhvdmVyOnRleHQtdGV4dC1wcmltYXJ5IHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MCBlYXNlLXNtb290aFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJYXCIgc2l6ZT17MjB9IC8+XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPG5hdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICAgIHtuYXZpZ2F0aW9uSXRlbXM/Lm1hcCgoaXRlbSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgIGtleT17aXRlbT8ucGF0aH1cclxuICAgICAgICAgICAgICAgICAgICB0bz17aXRlbT8ucGF0aH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVOYXZpZ2F0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMyBweC00IHB5LTMgcm91bmRlZC1sZyB0ZXh0LWJhc2UgZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMTUwIGVhc2Utc21vb3RoICR7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzQWN0aXZlUm91dGUoaXRlbT8ucGF0aClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1wcmltYXJ5LTUwIHRleHQtcHJpbWFyeSBib3JkZXIgYm9yZGVyLXByaW1hcnktMTAwJyA6ICd0ZXh0LXRleHQtc2Vjb25kYXJ5IGhvdmVyOnRleHQtdGV4dC1wcmltYXJ5IGhvdmVyOmJnLXN1cmZhY2UtaG92ZXInXHJcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9e2l0ZW0/Lmljb259IHNpemU9ezIwfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPntpdGVtPy5sYWJlbH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci10IGJvcmRlci1ib3JkZXIgbXktNFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICB7dXNlck1lbnVJdGVtcz8ubWFwKChpdGVtKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGlmIChpdGVtLmFjdGlvbiA9PT0gJ2xvZ291dCcpIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2l0ZW0ubGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUxvZ291dH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMyBweC00IHB5LTMgcm91bmRlZC1sZyB0ZXh0LWJhc2UgZm9udC1tZWRpdW0gdGV4dC10ZXh0LXNlY29uZGFyeSBkYXJrOnRleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC10ZXh0LXByaW1hcnkgZGFyazpob3Zlcjp0ZXh0LXRleHQtcHJpbWFyeSBob3ZlcjpiZy1zdXJmYWNlLWhvdmVyIGRhcms6aG92ZXI6Ymctc3VyZmFjZS1ob3ZlciB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0xNTAgZWFzZS1zbW9vdGggY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPXtpdGVtPy5pY29ufSBzaXplPXsyMH0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2l0ZW0/LmxhYmVsfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aXRlbT8ucGF0aH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgdG89e2l0ZW0/LnBhdGh9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZU1lbnVJdGVtQ2xpY2soaXRlbSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMyBweC00IHB5LTMgcm91bmRlZC1sZyB0ZXh0LWJhc2UgZm9udC1tZWRpdW0gdGV4dC10ZXh0LXNlY29uZGFyeSBkYXJrOnRleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC10ZXh0LXByaW1hcnkgZGFyazpob3Zlcjp0ZXh0LXRleHQtcHJpbWFyeSBob3ZlcjpiZy1zdXJmYWNlLWhvdmVyIGRhcms6aG92ZXI6Ymctc3VyZmFjZS1ob3ZlciB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0xNTAgZWFzZS1zbW9vdGhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPXtpdGVtPy5pY29ufSBzaXplPXsyMH0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2l0ZW0/LmxhYmVsfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICA8L25hdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgICAgXHJcbiAgICAgIHsvKiBDbGljayBvdXRzaWRlIGhhbmRsZXIgZm9yIHVzZXIgbWVudSAqL31cclxuICAgICAge2lzVXNlck1lbnVPcGVuICYmIChcclxuICAgICAgICA8ZGl2XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotMTA1MFwiXHJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc1VzZXJNZW51T3BlbihmYWxzZSl9XHJcbiAgICAgICAgPjwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgPC8+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEhlYWRlcjsiXSwiZmlsZSI6IkQ6L2N1cnJlbnQgcHJvamVjdHMvY2xhdWRlLWNvZGUvc3JjL2NvbXBvbmVudHMvdWkvSGVhZGVyLmpzeCJ9