import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/settings-administration/index.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/settings-administration/index.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import Header from "/src/components/ui/Header.jsx";
import Breadcrumb from "/src/components/ui/Breadcrumb.jsx";
import SettingsNavigation from "/src/pages/settings-administration/components/SettingsNavigation.jsx";
import UserManagement from "/src/pages/settings-administration/components/UserManagement.jsx";
import Permissions from "/src/pages/settings-administration/components/Permissions.jsx";
import Integrations from "/src/pages/settings-administration/components/Integrations.jsx";
import CustomFields from "/src/pages/settings-administration/components/CustomFields.jsx";
import EmailTemplates from "/src/pages/settings-administration/components/EmailTemplates.jsx";
import SystemConfiguration from "/src/pages/settings-administration/components/SystemConfiguration.jsx";
const SettingsAdministration = () => {
  _s();
  const [activeSection, setActiveSection] = useState("user-management");
  const renderActiveSection = () => {
    switch (activeSection) {
      case "user-management":
        return /* @__PURE__ */ jsxDEV(UserManagement, { "data-component-id": "src\\pages\\settings-administration\\index.jsx:19:15", "data-component-path": "src\\pages\\settings-administration\\index.jsx", "data-component-line": "19", "data-component-file": "index.jsx", "data-component-name": "UserManagement", "data-component-content": "%7B%22elementName%22%3A%22UserManagement%22%7D" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/index.jsx",
          lineNumber: 19,
          columnNumber: 16
        }, this);
      case "permissions":
        return /* @__PURE__ */ jsxDEV(Permissions, { "data-component-id": "src\\pages\\settings-administration\\index.jsx:21:15", "data-component-path": "src\\pages\\settings-administration\\index.jsx", "data-component-line": "21", "data-component-file": "index.jsx", "data-component-name": "Permissions", "data-component-content": "%7B%22elementName%22%3A%22Permissions%22%7D" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/index.jsx",
          lineNumber: 21,
          columnNumber: 16
        }, this);
      case "integrations":
        return /* @__PURE__ */ jsxDEV(Integrations, { "data-component-id": "src\\pages\\settings-administration\\index.jsx:23:15", "data-component-path": "src\\pages\\settings-administration\\index.jsx", "data-component-line": "23", "data-component-file": "index.jsx", "data-component-name": "Integrations", "data-component-content": "%7B%22elementName%22%3A%22Integrations%22%7D" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/index.jsx",
          lineNumber: 23,
          columnNumber: 16
        }, this);
      case "custom-fields":
        return /* @__PURE__ */ jsxDEV(CustomFields, { "data-component-id": "src\\pages\\settings-administration\\index.jsx:25:15", "data-component-path": "src\\pages\\settings-administration\\index.jsx", "data-component-line": "25", "data-component-file": "index.jsx", "data-component-name": "CustomFields", "data-component-content": "%7B%22elementName%22%3A%22CustomFields%22%7D" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/index.jsx",
          lineNumber: 25,
          columnNumber: 16
        }, this);
      case "email-templates":
        return /* @__PURE__ */ jsxDEV(EmailTemplates, { "data-component-id": "src\\pages\\settings-administration\\index.jsx:27:15", "data-component-path": "src\\pages\\settings-administration\\index.jsx", "data-component-line": "27", "data-component-file": "index.jsx", "data-component-name": "EmailTemplates", "data-component-content": "%7B%22elementName%22%3A%22EmailTemplates%22%7D" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/index.jsx",
          lineNumber: 27,
          columnNumber: 16
        }, this);
      case "system-config":
        return /* @__PURE__ */ jsxDEV(SystemConfiguration, { "data-component-id": "src\\pages\\settings-administration\\index.jsx:29:15", "data-component-path": "src\\pages\\settings-administration\\index.jsx", "data-component-line": "29", "data-component-file": "index.jsx", "data-component-name": "SystemConfiguration", "data-component-content": "%7B%22elementName%22%3A%22SystemConfiguration%22%7D" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/index.jsx",
          lineNumber: 29,
          columnNumber: 16
        }, this);
      default:
        return /* @__PURE__ */ jsxDEV(UserManagement, { "data-component-id": "src\\pages\\settings-administration\\index.jsx:31:15", "data-component-path": "src\\pages\\settings-administration\\index.jsx", "data-component-line": "31", "data-component-file": "index.jsx", "data-component-name": "UserManagement", "data-component-content": "%7B%22elementName%22%3A%22UserManagement%22%7D" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/index.jsx",
          lineNumber: 31,
          columnNumber: 16
        }, this);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\index.jsx:36:4", "data-component-path": "src\\pages\\settings-administration\\index.jsx", "data-component-line": "36", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22min-h-screen%20bg-background%22%7D", className: "min-h-screen bg-background", children: [
    /* @__PURE__ */ jsxDEV(Header, { "data-component-id": "src\\pages\\settings-administration\\index.jsx:37:6", "data-component-path": "src\\pages\\settings-administration\\index.jsx", "data-component-line": "37", "data-component-file": "index.jsx", "data-component-name": "Header", "data-component-content": "%7B%22elementName%22%3A%22Header%22%7D" }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/index.jsx",
      lineNumber: 37,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("main", { "data-component-id": "src\\pages\\settings-administration\\index.jsx:38:6", "data-component-path": "src\\pages\\settings-administration\\index.jsx", "data-component-line": "38", "data-component-file": "index.jsx", "data-component-name": "main", "data-component-content": "%7B%22elementName%22%3A%22main%22%2C%22className%22%3A%22pt-20%22%7D", className: "pt-20", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\index.jsx:39:8", "data-component-path": "src\\pages\\settings-administration\\index.jsx", "data-component-line": "39", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22max-w-full%20mx-auto%22%7D", className: "max-w-full mx-auto", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\index.jsx:40:10", "data-component-path": "src\\pages\\settings-administration\\index.jsx", "data-component-line": "40", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22px-6%20py-4%22%7D", className: "px-6 py-4", children: /* @__PURE__ */ jsxDEV(Breadcrumb, { "data-component-id": "src\\pages\\settings-administration\\index.jsx:41:12", "data-component-path": "src\\pages\\settings-administration\\index.jsx", "data-component-line": "41", "data-component-file": "index.jsx", "data-component-name": "Breadcrumb", "data-component-content": "%7B%22elementName%22%3A%22Breadcrumb%22%7D" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/index.jsx",
        lineNumber: 41,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/index.jsx",
        lineNumber: 40,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\index.jsx:44:10", "data-component-path": "src\\pages\\settings-administration\\index.jsx", "data-component-line": "44", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20h-%5Bcalc(100vh-7rem)%5D%22%7D", className: "flex h-[calc(100vh-7rem)]", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\index.jsx:46:12", "data-component-path": "src\\pages\\settings-administration\\index.jsx", "data-component-line": "46", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22hidden%20lg%3Ablock%22%7D", className: "hidden lg:block", children: /* @__PURE__ */ jsxDEV(
          SettingsNavigation,
          {
            "data-component-id": "src\\pages\\settings-administration\\index.jsx:47:14",
            "data-component-path": "src\\pages\\settings-administration\\index.jsx",
            "data-component-line": "47",
            "data-component-file": "index.jsx",
            "data-component-name": "SettingsNavigation",
            "data-component-content": "%7B%22elementName%22%3A%22SettingsNavigation%22%7D",
            activeSection,
            onSectionChange: setActiveSection
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/index.jsx",
            lineNumber: 47,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/index.jsx",
          lineNumber: 46,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\index.jsx:54:12", "data-component-path": "src\\pages\\settings-administration\\index.jsx", "data-component-line": "54", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22lg%3Ahidden%22%7D", className: "lg:hidden", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\index.jsx:55:14", "data-component-path": "src\\pages\\settings-administration\\index.jsx", "data-component-line": "55", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20border-r%20border-border%20p-4%22%7D", className: "bg-surface border-r border-border p-4", children: /* @__PURE__ */ jsxDEV(
          "select",
          {
            "data-component-id": "src\\pages\\settings-administration\\index.jsx:56:16",
            "data-component-path": "src\\pages\\settings-administration\\index.jsx",
            "data-component-line": "56",
            "data-component-file": "index.jsx",
            "data-component-name": "select",
            "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22value%22%3A%22%5Bvar%3AactiveSection%5D%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
            value: activeSection,
            onChange: (e) => setActiveSection(e?.target?.value),
            className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
            children: [
              /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\index.jsx:61:18", "data-component-path": "src\\pages\\settings-administration\\index.jsx", "data-component-line": "61", "data-component-file": "index.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22user-management%22%2C%22textContent%22%3A%22User%20Management%22%7D", value: "user-management", children: "User Management" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/index.jsx",
                lineNumber: 61,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\index.jsx:62:18", "data-component-path": "src\\pages\\settings-administration\\index.jsx", "data-component-line": "62", "data-component-file": "index.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22permissions%22%2C%22textContent%22%3A%22Permissions%22%7D", value: "permissions", children: "Permissions" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/index.jsx",
                lineNumber: 62,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\index.jsx:63:18", "data-component-path": "src\\pages\\settings-administration\\index.jsx", "data-component-line": "63", "data-component-file": "index.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22integrations%22%2C%22textContent%22%3A%22Integrations%22%7D", value: "integrations", children: "Integrations" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/index.jsx",
                lineNumber: 63,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\index.jsx:64:18", "data-component-path": "src\\pages\\settings-administration\\index.jsx", "data-component-line": "64", "data-component-file": "index.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22custom-fields%22%2C%22textContent%22%3A%22Custom%20Fields%22%7D", value: "custom-fields", children: "Custom Fields" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/index.jsx",
                lineNumber: 64,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\index.jsx:65:18", "data-component-path": "src\\pages\\settings-administration\\index.jsx", "data-component-line": "65", "data-component-file": "index.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22email-templates%22%2C%22textContent%22%3A%22Email%20Templates%22%7D", value: "email-templates", children: "Email Templates" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/index.jsx",
                lineNumber: 65,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\index.jsx:66:18", "data-component-path": "src\\pages\\settings-administration\\index.jsx", "data-component-line": "66", "data-component-file": "index.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22system-config%22%2C%22textContent%22%3A%22System%20Configuration%22%7D", value: "system-config", children: "System Configuration" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/index.jsx",
                lineNumber: 66,
                columnNumber: 19
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/index.jsx",
            lineNumber: 56,
            columnNumber: 17
          },
          this
        ) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/index.jsx",
          lineNumber: 55,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/index.jsx",
          lineNumber: 54,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\index.jsx:72:12", "data-component-path": "src\\pages\\settings-administration\\index.jsx", "data-component-line": "72", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex-1%20overflow-y-auto%22%7D", className: "flex-1 overflow-y-auto", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\index.jsx:73:14", "data-component-path": "src\\pages\\settings-administration\\index.jsx", "data-component-line": "73", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22p-6%22%7D", className: "p-6", children: renderActiveSection() }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/index.jsx",
          lineNumber: 73,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/index.jsx",
          lineNumber: 72,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/index.jsx",
        lineNumber: 44,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/index.jsx",
      lineNumber: 39,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/index.jsx",
      lineNumber: 38,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/settings-administration/index.jsx",
    lineNumber: 36,
    columnNumber: 5
  }, this);
};
_s(SettingsAdministration, "dsm9qZWsLEUro0+hqAQxZZMO1SU=");
_c = SettingsAdministration;
export default SettingsAdministration;
var _c;
$RefreshReg$(_c, "SettingsAdministration");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/settings-administration/index.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/settings-administration/index.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0JlOzJCQWxCZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBLE9BQU9BLFNBQVNDLGdCQUFnQjtBQUNoQyxPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGdCQUFnQjtBQUN2QixPQUFPQyx3QkFBd0I7QUFDL0IsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyx5QkFBeUI7QUFFaEMsTUFBTUMseUJBQXlCQSxNQUFNO0FBQUFDLEtBQUE7QUFDbkMsUUFBTSxDQUFDQyxlQUFlQyxnQkFBZ0IsSUFBSWIsU0FBUyxpQkFBaUI7QUFFcEUsUUFBTWMsc0JBQXNCQSxNQUFNO0FBQ2hDLFlBQVFGLGVBQWE7QUFBQSxNQUNuQixLQUFLO0FBQ0gsZUFBTyx1QkFBQyxnV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWU7QUFBQSxNQUN4QixLQUFLO0FBQ0gsZUFBTyx1QkFBQyx1VkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVk7QUFBQSxNQUNyQixLQUFLO0FBQ0gsZUFBTyx1QkFBQywwVkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWE7QUFBQSxNQUN0QixLQUFLO0FBQ0gsZUFBTyx1QkFBQywwVkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWE7QUFBQSxNQUN0QixLQUFLO0FBQ0gsZUFBTyx1QkFBQyxnV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWU7QUFBQSxNQUN4QixLQUFLO0FBQ0gsZUFBTyx1QkFBQywrV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9CO0FBQUEsTUFDN0I7QUFDRSxlQUFPLHVCQUFDLGdXQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZTtBQUFBLElBQzFCO0FBQUEsRUFDRjtBQUVBLFNBQ0UsdUJBQUMscVhBQUksV0FBVSw4QkFDYjtBQUFBLDJCQUFDLHVVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBTztBQUFBLElBQ1AsdUJBQUMsaVdBQUssV0FBVSxTQUNkLGlDQUFDLDZXQUFJLFdBQVUsc0JBQ2I7QUFBQSw2QkFBQyxxV0FBSSxXQUFVLGFBQ2IsaUNBQUMsb1ZBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFXLEtBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFQSx1QkFBQyx5WEFBSSxXQUFVLDZCQUViO0FBQUEsK0JBQUMsNldBQUksV0FBVSxtQkFDYjtBQUFBLFVBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBQ0M7QUFBQSxZQUNBLGlCQUFpQkM7QUFBQUE7QUFBQUEsVUFGbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRW9DLEtBSHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFFBR0EsdUJBQUMscVdBQUksV0FBVSxhQUNiLGlDQUFDLHFZQUFJLFdBQVUseUNBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUNDLE9BQU9EO0FBQUFBLFlBQ1AsVUFBVSxDQUFDRyxNQUFNRixpQkFBaUJFLEdBQUdDLFFBQVFDLEtBQUs7QUFBQSxZQUNsRCxXQUFVO0FBQUEsWUFFVjtBQUFBLHFDQUFDLDRaQUFPLE9BQU0sbUJBQWtCLCtCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQztBQUFBLGNBQy9DLHVCQUFDLGtaQUFPLE9BQU0sZUFBYywyQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUM7QUFBQSxjQUN2Qyx1QkFBQyxvWkFBTyxPQUFNLGdCQUFlLDRCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5QztBQUFBLGNBQ3pDLHVCQUFDLHdaQUFPLE9BQU0saUJBQWdCLDZCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyQztBQUFBLGNBQzNDLHVCQUFDLDRaQUFPLE9BQU0sbUJBQWtCLCtCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQztBQUFBLGNBQy9DLHVCQUFDLCtaQUFPLE9BQU0saUJBQWdCLG9DQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrRDtBQUFBO0FBQUE7QUFBQSxVQVZwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFXQSxLQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQSxLQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQTtBQUFBLFFBR0EsdUJBQUMsa1hBQUksV0FBVSwwQkFDYixpQ0FBQyw2VkFBSSxXQUFVLE9BQ1pILDhCQUFvQixLQUR2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxXQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUNBO0FBQUEsU0F0Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVDQSxLQXhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeUNBO0FBQUEsT0EzQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTRDQTtBQUVKO0FBQUVILEdBckVJRCx3QkFBc0I7QUFBQVEsS0FBdEJSO0FBdUVOLGVBQWVBO0FBQXVCLElBQUFRO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZVN0YXRlIiwiSGVhZGVyIiwiQnJlYWRjcnVtYiIsIlNldHRpbmdzTmF2aWdhdGlvbiIsIlVzZXJNYW5hZ2VtZW50IiwiUGVybWlzc2lvbnMiLCJJbnRlZ3JhdGlvbnMiLCJDdXN0b21GaWVsZHMiLCJFbWFpbFRlbXBsYXRlcyIsIlN5c3RlbUNvbmZpZ3VyYXRpb24iLCJTZXR0aW5nc0FkbWluaXN0cmF0aW9uIiwiX3MiLCJhY3RpdmVTZWN0aW9uIiwic2V0QWN0aXZlU2VjdGlvbiIsInJlbmRlckFjdGl2ZVNlY3Rpb24iLCJlIiwidGFyZ2V0IiwidmFsdWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbImluZGV4LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBzcmMvcGFnZXMvc2V0dGluZ3MtYWRtaW5pc3RyYXRpb24vaW5kZXguanN4XHJcbmltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IEhlYWRlciBmcm9tICdjb21wb25lbnRzL3VpL0hlYWRlcic7XHJcbmltcG9ydCBCcmVhZGNydW1iIGZyb20gJ2NvbXBvbmVudHMvdWkvQnJlYWRjcnVtYic7XHJcbmltcG9ydCBTZXR0aW5nc05hdmlnYXRpb24gZnJvbSAnLi9jb21wb25lbnRzL1NldHRpbmdzTmF2aWdhdGlvbic7XHJcbmltcG9ydCBVc2VyTWFuYWdlbWVudCBmcm9tICcuL2NvbXBvbmVudHMvVXNlck1hbmFnZW1lbnQnO1xyXG5pbXBvcnQgUGVybWlzc2lvbnMgZnJvbSAnLi9jb21wb25lbnRzL1Blcm1pc3Npb25zJztcclxuaW1wb3J0IEludGVncmF0aW9ucyBmcm9tICcuL2NvbXBvbmVudHMvSW50ZWdyYXRpb25zJztcclxuaW1wb3J0IEN1c3RvbUZpZWxkcyBmcm9tICcuL2NvbXBvbmVudHMvQ3VzdG9tRmllbGRzJztcclxuaW1wb3J0IEVtYWlsVGVtcGxhdGVzIGZyb20gJy4vY29tcG9uZW50cy9FbWFpbFRlbXBsYXRlcyc7XHJcbmltcG9ydCBTeXN0ZW1Db25maWd1cmF0aW9uIGZyb20gJy4vY29tcG9uZW50cy9TeXN0ZW1Db25maWd1cmF0aW9uJztcclxuXHJcbmNvbnN0IFNldHRpbmdzQWRtaW5pc3RyYXRpb24gPSAoKSA9PiB7XHJcbiAgY29uc3QgW2FjdGl2ZVNlY3Rpb24sIHNldEFjdGl2ZVNlY3Rpb25dID0gdXNlU3RhdGUoJ3VzZXItbWFuYWdlbWVudCcpO1xyXG5cclxuICBjb25zdCByZW5kZXJBY3RpdmVTZWN0aW9uID0gKCkgPT4ge1xyXG4gICAgc3dpdGNoIChhY3RpdmVTZWN0aW9uKSB7XHJcbiAgICAgIGNhc2UgJ3VzZXItbWFuYWdlbWVudCc6XHJcbiAgICAgICAgcmV0dXJuIDxVc2VyTWFuYWdlbWVudCAvPjtcclxuICAgICAgY2FzZSAncGVybWlzc2lvbnMnOlxyXG4gICAgICAgIHJldHVybiA8UGVybWlzc2lvbnMgLz47XHJcbiAgICAgIGNhc2UgJ2ludGVncmF0aW9ucyc6XHJcbiAgICAgICAgcmV0dXJuIDxJbnRlZ3JhdGlvbnMgLz47XHJcbiAgICAgIGNhc2UgJ2N1c3RvbS1maWVsZHMnOlxyXG4gICAgICAgIHJldHVybiA8Q3VzdG9tRmllbGRzIC8+O1xyXG4gICAgICBjYXNlICdlbWFpbC10ZW1wbGF0ZXMnOlxyXG4gICAgICAgIHJldHVybiA8RW1haWxUZW1wbGF0ZXMgLz47XHJcbiAgICAgIGNhc2UgJ3N5c3RlbS1jb25maWcnOlxyXG4gICAgICAgIHJldHVybiA8U3lzdGVtQ29uZmlndXJhdGlvbiAvPjtcclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICByZXR1cm4gPFVzZXJNYW5hZ2VtZW50IC8+O1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy1iYWNrZ3JvdW5kXCI+XHJcbiAgICAgIDxIZWFkZXIgLz5cclxuICAgICAgPG1haW4gY2xhc3NOYW1lPVwicHQtMjBcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LWZ1bGwgbXgtYXV0b1wiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC02IHB5LTRcIj5cclxuICAgICAgICAgICAgPEJyZWFkY3J1bWIgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC1bY2FsYygxMDB2aC03cmVtKV1cIj5cclxuICAgICAgICAgICAgey8qIExlZnQgTmF2aWdhdGlvbiBQYW5lbCAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaWRkZW4gbGc6YmxvY2tcIj5cclxuICAgICAgICAgICAgICA8U2V0dGluZ3NOYXZpZ2F0aW9uIFxyXG4gICAgICAgICAgICAgICAgYWN0aXZlU2VjdGlvbj17YWN0aXZlU2VjdGlvbn0gXHJcbiAgICAgICAgICAgICAgICBvblNlY3Rpb25DaGFuZ2U9e3NldEFjdGl2ZVNlY3Rpb259IFxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgey8qIE1vYmlsZSBOYXZpZ2F0aW9uIC0gQ29sbGFwc2libGUgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6aGlkZGVuXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zdXJmYWNlIGJvcmRlci1yIGJvcmRlci1ib3JkZXIgcC00XCI+XHJcbiAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXthY3RpdmVTZWN0aW9ufVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEFjdGl2ZVNlY3Rpb24oZT8udGFyZ2V0Py52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ib3JkZXIgcm91bmRlZC1sZyBmb2N1czpyaW5nLXByaW1hcnkgZm9jdXM6Ym9yZGVyLXByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwidXNlci1tYW5hZ2VtZW50XCI+VXNlciBNYW5hZ2VtZW50PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJwZXJtaXNzaW9uc1wiPlBlcm1pc3Npb25zPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJpbnRlZ3JhdGlvbnNcIj5JbnRlZ3JhdGlvbnM8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImN1c3RvbS1maWVsZHNcIj5DdXN0b20gRmllbGRzPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJlbWFpbC10ZW1wbGF0ZXNcIj5FbWFpbCBUZW1wbGF0ZXM8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cInN5c3RlbS1jb25maWdcIj5TeXN0ZW0gQ29uZmlndXJhdGlvbjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgey8qIE1haW4gQ29udGVudCBBcmVhICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBvdmVyZmxvdy15LWF1dG9cIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNlwiPlxyXG4gICAgICAgICAgICAgICAge3JlbmRlckFjdGl2ZVNlY3Rpb24oKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9tYWluPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFNldHRpbmdzQWRtaW5pc3RyYXRpb247Il0sImZpbGUiOiJEOi9jdXJyZW50IHByb2plY3RzL2NsYXVkZS1jb2RlL3NyYy9wYWdlcy9zZXR0aW5ncy1hZG1pbmlzdHJhdGlvbi9pbmRleC5qc3gifQ==