import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ProtectedRoute.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/components/ProtectedRoute.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { Navigate } from "/node_modules/.vite/deps/react-router-dom.js?v=44ab9529";
import { useAuth } from "/src/contexts/AuthContext.jsx";
const ProtectedRoute = ({ children }) => {
  _s();
  const { user, loading } = useAuth();
  if (loading) {
    return null;
  }
  if (!user) {
    return /* @__PURE__ */ jsxDEV(Navigate, { "data-component-id": "src\\components\\ProtectedRoute.jsx:15:11", "data-component-path": "src\\components\\ProtectedRoute.jsx", "data-component-line": "15", "data-component-file": "ProtectedRoute.jsx", "data-component-name": "Navigate", "data-component-content": "%7B%22elementName%22%3A%22Navigate%22%7D", to: "/login", replace: true }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/components/ProtectedRoute.jsx",
      lineNumber: 15,
      columnNumber: 12
    }, this);
  }
  return children;
};
_s(ProtectedRoute, "EmJkapf7qiLC5Br5eCoEq4veZes=", false, function() {
  return [useAuth];
});
_c = ProtectedRoute;
export default ProtectedRoute;
var _c;
$RefreshReg$(_c, "ProtectedRoute");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/components/ProtectedRoute.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/components/ProtectedRoute.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBY1c7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBYlgsT0FBT0EsV0FBVztBQUNsQixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsZUFBZTtBQUV4QixNQUFNQyxpQkFBaUJBLENBQUMsRUFBRUMsU0FBUyxNQUFNO0FBQUFDLEtBQUE7QUFDdkMsUUFBTSxFQUFFQyxNQUFNQyxRQUFRLElBQUlMLFFBQVE7QUFFbEMsTUFBSUssU0FBUztBQUVYLFdBQU87QUFBQSxFQUNUO0FBRUEsTUFBSSxDQUFDRCxNQUFNO0FBQ1QsV0FBTyx1QkFBQywrVEFBUyxJQUFHLFVBQVMsU0FBTyxRQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZCO0FBQUEsRUFDdEM7QUFFQSxTQUFPRjtBQUNUO0FBQUVDLEdBYklGLGdCQUFjO0FBQUEsVUFDUUQsT0FBTztBQUFBO0FBQUFNLEtBRDdCTDtBQWVOLGVBQWVBO0FBQWUsSUFBQUs7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwiTmF2aWdhdGUiLCJ1c2VBdXRoIiwiUHJvdGVjdGVkUm91dGUiLCJjaGlsZHJlbiIsIl9zIiwidXNlciIsImxvYWRpbmciLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlByb3RlY3RlZFJvdXRlLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJcclxuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uL2NvbnRleHRzL0F1dGhDb250ZXh0JztcclxuXHJcbmNvbnN0IFByb3RlY3RlZFJvdXRlID0gKHsgY2hpbGRyZW4gfSkgPT4ge1xyXG4gIGNvbnN0IHsgdXNlciwgbG9hZGluZyB9ID0gdXNlQXV0aCgpO1xyXG5cclxuICBpZiAobG9hZGluZykge1xyXG4gICAgLy8gT3B0aW9uYWxseSByZW5kZXIgYSBsb2FkaW5nIHNwaW5uZXIgb3Igc2tlbGV0b24gaGVyZVxyXG4gICAgcmV0dXJuIG51bGw7IFxyXG4gIH1cclxuXHJcbiAgaWYgKCF1c2VyKSB7XHJcbiAgICByZXR1cm4gPE5hdmlnYXRlIHRvPVwiL2xvZ2luXCIgcmVwbGFjZSAvPjtcclxuICB9XHJcblxyXG4gIHJldHVybiBjaGlsZHJlbjtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFByb3RlY3RlZFJvdXRlO1xyXG4iXSwiZmlsZSI6IkQ6L2N1cnJlbnQgcHJvamVjdHMvY2xhdWRlLWNvZGUvc3JjL2NvbXBvbmVudHMvUHJvdGVjdGVkUm91dGUuanN4In0=