import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/contact-management/components/ActivityTimeline.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import { format } from "/node_modules/.vite/deps/date-fns.js?v=44ab9529";
import toast from "/node_modules/.vite/deps/react-hot-toast.js?v=44ab9529";
import Icon from "/src/components/AppIcon.jsx";
import AddActivityModal from "/src/pages/contact-management/components/AddActivityModal.jsx";
import { activitiesService } from "/src/services/activitiesService.js";
const ActivityTimeline = ({ activities, contact, onActivityAdded }) => {
  _s();
  const [filter, setFilter] = useState("all");
  const [showAddActivityModal, setShowAddActivityModal] = useState(false);
  const getActivityIcon = (type) => {
    switch (type) {
      case "email":
        return "Mail";
      case "call":
        return "Phone";
      case "meeting":
        return "Calendar";
      case "note":
        return "FileText";
      case "task":
        return "CheckSquare";
      default:
        return "Activity";
    }
  };
  const getActivityColor = (type) => {
    switch (type) {
      case "email":
        return "bg-primary-50 text-primary";
      case "call":
        return "bg-success-50 text-success";
      case "meeting":
        return "bg-secondary-50 text-secondary";
      case "note":
        return "bg-warning-50 text-warning";
      case "task":
        return "bg-accent-50 text-accent";
      default:
        return "bg-gray-100 text-gray-600";
    }
  };
  const formatDateTime = (dateString) => {
    return format(new Date(dateString), "MMM d, yyyy h:mm a");
  };
  const handleAddActivity = async (activityData) => {
    try {
      const newActivity = await activitiesService.createActivity(activityData);
      if (onActivityAdded) {
        onActivityAdded(newActivity);
      }
      return newActivity;
    } catch (error) {
      console.error("Error creating activity:", error);
      throw error;
    }
  };
  const handleOpenAddModal = () => {
    setShowAddActivityModal(true);
  };
  const handleCloseAddModal = () => {
    setShowAddActivityModal(false);
  };
  const filteredActivities = filter === "all" ? activities : activities?.filter((activity) => activity?.type === filter);
  const sortedActivities = [...filteredActivities]?.sort(
    (a, b) => new Date(b.scheduled_at || b.created_at) - new Date(a.scheduled_at || a.created_at)
  );
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:80:4", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "80", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:81:6", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "81", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20justify-between%20items-center%20mb-6%22%7D", className: "flex justify-between items-center mb-6", children: [
      /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:82:8", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "82", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%2C%22textContent%22%3A%22Activity%20Timeline%22%7D", className: "text-lg font-semibold text-text-primary", children: "Activity Timeline" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
        lineNumber: 82,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:84:8", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "84", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%22%7D", className: "flex items-center space-x-2", children: [
        /* @__PURE__ */ jsxDEV(
          "select",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:85:10",
            "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx",
            "data-component-line": "85",
            "data-component-file": "ActivityTimeline.jsx",
            "data-component-name": "select",
            "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22value%22%3A%22%5Bvar%3Afilter%5D%22%2C%22className%22%3A%22text-sm%20border%20border-border%20rounded-md%20py-1%20px-2%20text-text-primary%20bg-surface%20focus%3Aoutline-none%20focus%3Aring-1%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
            value: filter,
            onChange: (e) => setFilter(e?.target?.value),
            className: "text-sm border border-border rounded-md py-1 px-2 text-text-primary bg-surface focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary",
            children: [
              /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:90:12", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "90", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22all%22%2C%22textContent%22%3A%22All%20Activities%22%7D", value: "all", children: "All Activities" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
                lineNumber: 90,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:91:12", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "91", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22email%22%2C%22textContent%22%3A%22Emails%22%7D", value: "email", children: "Emails" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
                lineNumber: 91,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:92:12", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "92", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22call%22%2C%22textContent%22%3A%22Calls%22%7D", value: "call", children: "Calls" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
                lineNumber: 92,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:93:12", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "93", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22meeting%22%2C%22textContent%22%3A%22Meetings%22%7D", value: "meeting", children: "Meetings" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
                lineNumber: 93,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:94:12", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "94", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22note%22%2C%22textContent%22%3A%22Notes%22%7D", value: "note", children: "Notes" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
                lineNumber: 94,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:95:12", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "95", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22task%22%2C%22textContent%22%3A%22Tasks%22%7D", value: "task", children: "Tasks" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
                lineNumber: 95,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
            lineNumber: 85,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:98:10",
            "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx",
            "data-component-line": "98",
            "data-component-file": "ActivityTimeline.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22inline-flex%20items-center%20space-x-2%20px-3%20py-1%20border%20border-border%20rounded-md%20text-text-secondary%20hover%3Atext-primary%20hover%3Aborder-primary%20transition-all%20duration-150%20ease-out%20text-sm%22%7D",
            className: "inline-flex items-center space-x-2 px-3 py-1 border border-border rounded-md text-text-secondary hover:text-primary hover:border-primary transition-all duration-150 ease-out text-sm",
            onClick: handleOpenAddModal,
            children: [
              /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:102:12", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "102", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Plus%22%7D", name: "Plus", size: 14 }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
                lineNumber: 102,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:103:12", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "103", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Log%20Activity%22%7D", children: "Log Activity" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
                lineNumber: 103,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
            lineNumber: 98,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
        lineNumber: 84,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
      lineNumber: 81,
      columnNumber: 7
    }, this),
    sortedActivities?.length > 0 ? /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:108:6", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "108", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22relative%22%7D", className: "relative", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:110:10", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "110", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22absolute%20left-6%20top-0%20bottom-0%20w-px%20bg-border%22%7D", className: "absolute left-6 top-0 bottom-0 w-px bg-border" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
        lineNumber: 110,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:113:10", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "113", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-6%22%7D", className: "space-y-6", children: sortedActivities?.map(
        (activity) => /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:115:10", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "115", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22relative%20pl-14%22%7D", className: "relative pl-14", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:117:16", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "117", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", className: `absolute left-0 w-12 h-12 rounded-full flex items-center justify-center ${getActivityColor(activity?.type)}`, children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:118:18", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "118", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%7D", name: getActivityIcon(activity?.type), size: 20 }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
            lineNumber: 118,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
            lineNumber: 117,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:122:16", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "122", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-4%22%7D", className: "card p-4", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:123:18", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "123", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20justify-between%20items-start%20mb-2%22%7D", className: "flex justify-between items-start mb-2", children: [
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:124:20", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "124", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
                /* @__PURE__ */ jsxDEV("h4", { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:125:22", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "125", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "h4", "data-component-content": "%7B%22elementName%22%3A%22h4%22%2C%22className%22%3A%22font-medium%20text-text-primary%22%7D", className: "font-medium text-text-primary", children: [
                  activity?.type === "email" && "Email: ",
                  activity?.type === "call" && "Call: ",
                  activity?.type === "meeting" && "Meeting: ",
                  activity?.subject || activity?.summary
                ] }, void 0, true, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
                  lineNumber: 125,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:131:22", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "131", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%20text-text-tertiary%22%7D", className: "text-sm text-text-tertiary", children: [
                  formatDateTime(activity?.scheduled_at || activity?.created_at),
                  activity?.duration_minutes && ` • ${activity?.duration_minutes} minutes`
                ] }, void 0, true, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
                  lineNumber: 131,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
                lineNumber: 124,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:136:20", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "136", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20space-x-2%22%7D", className: "flex space-x-2", children: [
                /* @__PURE__ */ jsxDEV("button", { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:137:22", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "137", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "button", "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22text-text-tertiary%20hover%3Atext-text-primary%22%7D", className: "text-text-tertiary hover:text-text-primary", children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:138:24", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "138", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Edit%22%7D", name: "Edit", size: 14 }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
                  lineNumber: 138,
                  columnNumber: 25
                }, this) }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
                  lineNumber: 137,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("button", { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:140:22", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "140", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "button", "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22text-text-tertiary%20hover%3Atext-error%22%7D", className: "text-text-tertiary hover:text-error", children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:141:24", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "141", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Trash2%22%7D", name: "Trash2", size: 14 }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
                  lineNumber: 141,
                  columnNumber: 25
                }, this) }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
                  lineNumber: 140,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
                lineNumber: 136,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
              lineNumber: 123,
              columnNumber: 19
            }, this),
            activity?.description && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:147:14", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "147", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-text-primary%20text-sm%20mt-2%22%7D", className: "text-text-primary text-sm mt-2", children: activity?.description }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
              lineNumber: 147,
              columnNumber: 15
            }, this),
            activity?.summary && !activity?.subject && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:153:14", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "153", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-text-primary%20text-sm%20mt-2%22%7D", className: "text-text-primary text-sm mt-2", children: activity?.summary }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
              lineNumber: 153,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
            lineNumber: 122,
            columnNumber: 17
          }, this)
        ] }, activity?.id, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
          lineNumber: 115,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
        lineNumber: 113,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
      lineNumber: 108,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:163:6", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "163", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-center%20py-12%20border%20border-dashed%20border-border%20rounded-lg%22%7D", className: "text-center py-12 border border-dashed border-border rounded-lg", children: [
      /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:164:10", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "164", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Calendar%22%2C%22className%22%3A%22text-text-tertiary%20mx-auto%20mb-3%22%7D", name: "Calendar", size: 32, className: "text-text-tertiary mx-auto mb-3" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
        lineNumber: 164,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("h4", { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:165:10", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "165", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "h4", "data-component-content": "%7B%22elementName%22%3A%22h4%22%2C%22className%22%3A%22text-lg%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22No%20activities%20found%22%7D", className: "text-lg font-medium text-text-primary mb-1", children: "No activities found" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
        lineNumber: 165,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:166:10", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "166", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20mb-4%22%7D", className: "text-text-secondary mb-4", children: filter === "all" ? "There are no activities recorded for this contact yet." : `There are no ${filter} activities recorded for this contact.` }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
        lineNumber: 166,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:170:10",
          "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx",
          "data-component-line": "170",
          "data-component-file": "ActivityTimeline.jsx",
          "data-component-name": "button",
          "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22btn-primary%20inline-flex%20items-center%20space-x-2%22%7D",
          className: "btn-primary inline-flex items-center space-x-2",
          onClick: handleOpenAddModal,
          children: [
            /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:174:12", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "174", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Plus%22%7D", name: "Plus", size: 16 }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
              lineNumber: 174,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:175:12", "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx", "data-component-line": "175", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Log%20an%20Activity%22%7D", children: "Log an Activity" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
              lineNumber: 175,
              columnNumber: 13
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
          lineNumber: 170,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
      lineNumber: 163,
      columnNumber: 7
    }, this),
    showAddActivityModal && /* @__PURE__ */ jsxDEV(
      AddActivityModal,
      {
        "data-component-id": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx:182:6",
        "data-component-path": "src\\pages\\contact-management\\components\\ActivityTimeline.jsx",
        "data-component-line": "182",
        "data-component-file": "ActivityTimeline.jsx",
        "data-component-name": "AddActivityModal",
        "data-component-content": "%7B%22elementName%22%3A%22AddActivityModal%22%7D",
        contact,
        onClose: handleCloseAddModal,
        onActivityAdded: handleAddActivity
      },
      void 0,
      false,
      {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
        lineNumber: 182,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx",
    lineNumber: 80,
    columnNumber: 5
  }, this);
};
_s(ActivityTimeline, "5mBcZ5shMoiGG4ctDpWjNATcEB8=");
_c = ActivityTimeline;
export default ActivityTimeline;
var _c;
$RefreshReg$(_c, "ActivityTimeline");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/contact-management/components/ActivityTimeline.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUZROzJCQWpGUjtBQUFnQkEsTUFBUSxjQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3ZDLFNBQVNDLGNBQWM7QUFDdkIsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxVQUFVO0FBQ2pCLE9BQU9DLHNCQUFzQjtBQUM3QixTQUFTQyx5QkFBeUI7QUFFbEMsTUFBTUMsbUJBQW1CQSxDQUFDLEVBQUVDLFlBQVlDLFNBQVNDLGdCQUFnQixNQUFNO0FBQUFDLEtBQUE7QUFDckUsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUlaLFNBQVMsS0FBSztBQUMxQyxRQUFNLENBQUNhLHNCQUFzQkMsdUJBQXVCLElBQUlkLFNBQVMsS0FBSztBQUV0RSxRQUFNZSxrQkFBa0JBLENBQUNDLFNBQVM7QUFDaEMsWUFBUUEsTUFBSTtBQUFBLE1BQ1YsS0FBSztBQUNILGVBQU87QUFBQSxNQUNULEtBQUs7QUFDSCxlQUFPO0FBQUEsTUFDVCxLQUFLO0FBQ0gsZUFBTztBQUFBLE1BQ1QsS0FBSztBQUNILGVBQU87QUFBQSxNQUNULEtBQUs7QUFDSCxlQUFPO0FBQUEsTUFDVDtBQUNFLGVBQU87QUFBQSxJQUNYO0FBQUEsRUFDRjtBQUVBLFFBQU1DLG1CQUFtQkEsQ0FBQ0QsU0FBUztBQUNqQyxZQUFRQSxNQUFJO0FBQUEsTUFDVixLQUFLO0FBQ0gsZUFBTztBQUFBLE1BQ1QsS0FBSztBQUNILGVBQU87QUFBQSxNQUNULEtBQUs7QUFDSCxlQUFPO0FBQUEsTUFDVCxLQUFLO0FBQ0gsZUFBTztBQUFBLE1BQ1QsS0FBSztBQUNILGVBQU87QUFBQSxNQUNUO0FBQ0UsZUFBTztBQUFBLElBQ1g7QUFBQSxFQUNGO0FBRUEsUUFBTUUsaUJBQWlCQSxDQUFDQyxlQUFlO0FBQ3JDLFdBQU9sQixPQUFPLElBQUltQixLQUFLRCxVQUFVLEdBQUcsb0JBQW9CO0FBQUEsRUFDMUQ7QUFFQSxRQUFNRSxvQkFBb0IsT0FBT0MsaUJBQWlCO0FBQ2hELFFBQUk7QUFDRixZQUFNQyxjQUFjLE1BQU1sQixrQkFBa0JtQixlQUFlRixZQUFZO0FBQ3ZFLFVBQUliLGlCQUFpQjtBQUNuQkEsd0JBQWdCYyxXQUFXO0FBQUEsTUFDN0I7QUFDQSxhQUFPQTtBQUFBQSxJQUNULFNBQVNFLE9BQU87QUFDZEMsY0FBUUQsTUFBTSw0QkFBNEJBLEtBQUs7QUFDL0MsWUFBTUE7QUFBQUEsSUFDUjtBQUFBLEVBQ0Y7QUFFQSxRQUFNRSxxQkFBcUJBLE1BQU07QUFDL0JiLDRCQUF3QixJQUFJO0FBQUEsRUFDOUI7QUFFQSxRQUFNYyxzQkFBc0JBLE1BQU07QUFDaENkLDRCQUF3QixLQUFLO0FBQUEsRUFDL0I7QUFFQSxRQUFNZSxxQkFBcUJsQixXQUFXLFFBQ2xDSixhQUNBQSxZQUFZSSxPQUFPLENBQUFtQixhQUFZQSxVQUFVZCxTQUFTTCxNQUFNO0FBRTVELFFBQU1vQixtQkFBbUIsQ0FBQyxHQUFHRixrQkFBa0IsR0FBR0c7QUFBQUEsSUFBSyxDQUFDQyxHQUFHQyxNQUN6RCxJQUFJZCxLQUFLYyxFQUFFQyxnQkFBZ0JELEVBQUVFLFVBQVUsSUFBSSxJQUFJaEIsS0FBS2EsRUFBRUUsZ0JBQWdCRixFQUFFRyxVQUFVO0FBQUEsRUFDcEY7QUFFQSxTQUNFLHVCQUFDLDZXQUNDO0FBQUEsMkJBQUMsb2JBQUksV0FBVSwwQ0FDYjtBQUFBLDZCQUFDLGdlQUFHLFdBQVUsMkNBQTBDLGlDQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlFO0FBQUEsTUFFekUsdUJBQUMsdWFBQUksV0FBVSwrQkFDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFDQyxPQUFPekI7QUFBQUEsWUFDUCxVQUFVLENBQUMwQixNQUFNekIsVUFBVXlCLEdBQUdDLFFBQVFDLEtBQUs7QUFBQSxZQUMzQyxXQUFVO0FBQUEsWUFFVjtBQUFBLHFDQUFDLDhiQUFPLE9BQU0sT0FBTSw4QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0M7QUFBQSxjQUNsQyx1QkFBQyxzYkFBTyxPQUFNLFNBQVEsc0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRCO0FBQUEsY0FDNUIsdUJBQUMsb2JBQU8sT0FBTSxRQUFPLHFCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwQjtBQUFBLGNBQzFCLHVCQUFDLDBiQUFPLE9BQU0sV0FBVSx3QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0M7QUFBQSxjQUNoQyx1QkFBQyxvYkFBTyxPQUFNLFFBQU8scUJBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBCO0FBQUEsY0FDMUIsdUJBQUMsb2JBQU8sT0FBTSxRQUFPLHFCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwQjtBQUFBO0FBQUE7QUFBQSxVQVY1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFXQTtBQUFBLFFBRUE7QUFBQSxVQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUNDLFdBQVU7QUFBQSxZQUNWLFNBQVNaO0FBQUFBLFlBRVQ7QUFBQSxxQ0FBQywyWUFBSyxNQUFLLFFBQU8sTUFBTSxNQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyQjtBQUFBLGNBQzNCLHVCQUFDLDhaQUFLLDRCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtCO0FBQUE7QUFBQTtBQUFBLFVBTHBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsV0FwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFCQTtBQUFBLFNBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5QkE7QUFBQSxJQUNDSSxrQkFBa0JTLFNBQVMsSUFDMUIsdUJBQUMsa1pBQUksV0FBVSxZQUViO0FBQUEsNkJBQUMsa2NBQUksV0FBVSxtREFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStEO0FBQUEsTUFHL0QsdUJBQUMsb1pBQUksV0FBVSxhQUNaVCw0QkFBa0JVO0FBQUFBLFFBQUksQ0FBQ1gsYUFDdEIsdUJBQUMsMlpBQXVCLFdBQVUsa0JBRWhDO0FBQUEsaUNBQUMsZ1hBQUksV0FBVywyRUFBMkViLGlCQUFpQmEsVUFBVWQsSUFBSSxDQUFDLElBQ3pILGlDQUFDLGlYQUFLLE1BQU1ELGdCQUFnQmUsVUFBVWQsSUFBSSxHQUFHLE1BQU0sTUFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0QsS0FEeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBR0EsdUJBQUMscVpBQUksV0FBVSxZQUNiO0FBQUEsbUNBQUMsc2JBQUksV0FBVSx5Q0FDYjtBQUFBLHFDQUFDLGdYQUNDO0FBQUEsdUNBQUMsdWFBQUcsV0FBVSxpQ0FDWGM7QUFBQUEsNEJBQVVkLFNBQVMsV0FBVztBQUFBLGtCQUM5QmMsVUFBVWQsU0FBUyxVQUFVO0FBQUEsa0JBQzdCYyxVQUFVZCxTQUFTLGFBQWE7QUFBQSxrQkFDaENjLFVBQVVZLFdBQVdaLFVBQVVhO0FBQUFBLHFCQUpsQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsZ0JBQ0EsdUJBQUMsaWFBQUUsV0FBVSw4QkFDVnpCO0FBQUFBLGlDQUFlWSxVQUFVSyxnQkFBZ0JMLFVBQVVNLFVBQVU7QUFBQSxrQkFDN0ROLFVBQVVjLG9CQUFvQixNQUFNZCxVQUFVYyxnQkFBZ0I7QUFBQSxxQkFGakU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLG1CQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBV0E7QUFBQSxjQUNBLHVCQUFDLDJaQUFJLFdBQVUsa0JBQ2I7QUFBQSx1Q0FBQyxrY0FBTyxXQUFVLDhDQUNoQixpQ0FBQywyWUFBSyxNQUFLLFFBQU8sTUFBTSxNQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyQixLQUQ3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsMmJBQU8sV0FBVSx1Q0FDaEIsaUNBQUMsNllBQUssTUFBSyxVQUFTLE1BQU0sTUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkIsS0FEL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBT0E7QUFBQSxpQkFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFxQkE7QUFBQSxZQUVtQmQsVUFBVWUsZUFDM0IsdUJBQUMsNmFBQUksV0FBVSxrQ0FDWmYsb0JBQVVlLGVBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBR0RmLFVBQVVhLFdBQVcsQ0FBQ2IsVUFBVVksV0FDL0IsdUJBQUMsNmFBQUksV0FBVSxrQ0FDWlosb0JBQVVhLFdBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBakNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUNBO0FBQUEsYUExQ1FiLFVBQVVnQixJQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMkNBO0FBQUEsTUFDRCxLQTlDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBK0NBO0FBQUEsU0FwREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFEQSxJQUVBLHVCQUFDLG1kQUFJLFdBQVUsbUVBQ2I7QUFBQSw2QkFBQyw2Y0FBSyxNQUFLLFlBQVcsTUFBTSxJQUFJLFdBQVUscUNBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkU7QUFBQSxNQUMzRSx1QkFBQyw0ZUFBRyxXQUFVLDhDQUE2QyxtQ0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4RTtBQUFBLE1BQzlFLHVCQUFDLCtaQUFFLFdBQVUsNEJBQ1ZuQyxxQkFBVyxRQUFPLDJEQUNmLGdCQUFnQkEsTUFBTSw0Q0FGNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBQ0MsV0FBVTtBQUFBLFVBQ1YsU0FBU2dCO0FBQUFBLFVBRVQ7QUFBQSxtQ0FBQywyWUFBSyxNQUFLLFFBQU8sTUFBTSxNQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyQjtBQUFBLFlBQzNCLHVCQUFDLG1hQUFLLCtCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFCO0FBQUE7QUFBQTtBQUFBLFFBTHZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1BO0FBQUEsU0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBY0E7QUFBQSxJQUlEZCx3QkFDQztBQUFBLE1BQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBLFNBQVNlO0FBQUFBLFFBQ1QsaUJBQWlCUDtBQUFBQTtBQUFBQSxNQUhuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFHcUM7QUFBQSxPQXpHekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTRHQTtBQUVKO0FBQUVYLEdBdExJSixrQkFBZ0I7QUFBQXlDLEtBQWhCekM7QUF3TE4sZUFBZUE7QUFBaUIsSUFBQXlDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsImZvcm1hdCIsInRvYXN0IiwiSWNvbiIsIkFkZEFjdGl2aXR5TW9kYWwiLCJhY3Rpdml0aWVzU2VydmljZSIsIkFjdGl2aXR5VGltZWxpbmUiLCJhY3Rpdml0aWVzIiwiY29udGFjdCIsIm9uQWN0aXZpdHlBZGRlZCIsIl9zIiwiZmlsdGVyIiwic2V0RmlsdGVyIiwic2hvd0FkZEFjdGl2aXR5TW9kYWwiLCJzZXRTaG93QWRkQWN0aXZpdHlNb2RhbCIsImdldEFjdGl2aXR5SWNvbiIsInR5cGUiLCJnZXRBY3Rpdml0eUNvbG9yIiwiZm9ybWF0RGF0ZVRpbWUiLCJkYXRlU3RyaW5nIiwiRGF0ZSIsImhhbmRsZUFkZEFjdGl2aXR5IiwiYWN0aXZpdHlEYXRhIiwibmV3QWN0aXZpdHkiLCJjcmVhdGVBY3Rpdml0eSIsImVycm9yIiwiY29uc29sZSIsImhhbmRsZU9wZW5BZGRNb2RhbCIsImhhbmRsZUNsb3NlQWRkTW9kYWwiLCJmaWx0ZXJlZEFjdGl2aXRpZXMiLCJhY3Rpdml0eSIsInNvcnRlZEFjdGl2aXRpZXMiLCJzb3J0IiwiYSIsImIiLCJzY2hlZHVsZWRfYXQiLCJjcmVhdGVkX2F0IiwiZSIsInRhcmdldCIsInZhbHVlIiwibGVuZ3RoIiwibWFwIiwic3ViamVjdCIsInN1bW1hcnkiLCJkdXJhdGlvbl9taW51dGVzIiwiZGVzY3JpcHRpb24iLCJpZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQWN0aXZpdHlUaW1lbGluZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBmb3JtYXQgfSBmcm9tICdkYXRlLWZucyc7XHJcbmltcG9ydCB0b2FzdCBmcm9tICdyZWFjdC1ob3QtdG9hc3QnO1xyXG5pbXBvcnQgSWNvbiBmcm9tICdjb21wb25lbnRzL0FwcEljb24nO1xyXG5pbXBvcnQgQWRkQWN0aXZpdHlNb2RhbCBmcm9tICcuL0FkZEFjdGl2aXR5TW9kYWwnO1xyXG5pbXBvcnQgeyBhY3Rpdml0aWVzU2VydmljZSB9IGZyb20gJy4uLy4uLy4uL3NlcnZpY2VzL2FjdGl2aXRpZXNTZXJ2aWNlJztcclxuXHJcbmNvbnN0IEFjdGl2aXR5VGltZWxpbmUgPSAoeyBhY3Rpdml0aWVzLCBjb250YWN0LCBvbkFjdGl2aXR5QWRkZWQgfSkgPT4ge1xyXG4gIGNvbnN0IFtmaWx0ZXIsIHNldEZpbHRlcl0gPSB1c2VTdGF0ZSgnYWxsJyk7XHJcbiAgY29uc3QgW3Nob3dBZGRBY3Rpdml0eU1vZGFsLCBzZXRTaG93QWRkQWN0aXZpdHlNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgXHJcbiAgY29uc3QgZ2V0QWN0aXZpdHlJY29uID0gKHR5cGUpID0+IHtcclxuICAgIHN3aXRjaCAodHlwZSkge1xyXG4gICAgICBjYXNlICdlbWFpbCc6XHJcbiAgICAgICAgcmV0dXJuICdNYWlsJztcclxuICAgICAgY2FzZSAnY2FsbCc6XHJcbiAgICAgICAgcmV0dXJuICdQaG9uZSc7XHJcbiAgICAgIGNhc2UgJ21lZXRpbmcnOlxyXG4gICAgICAgIHJldHVybiAnQ2FsZW5kYXInO1xyXG4gICAgICBjYXNlICdub3RlJzpcclxuICAgICAgICByZXR1cm4gJ0ZpbGVUZXh0JztcclxuICAgICAgY2FzZSAndGFzayc6XHJcbiAgICAgICAgcmV0dXJuICdDaGVja1NxdWFyZSc7XHJcbiAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgcmV0dXJuICdBY3Rpdml0eSc7XHJcbiAgICB9XHJcbiAgfTtcclxuICBcclxuICBjb25zdCBnZXRBY3Rpdml0eUNvbG9yID0gKHR5cGUpID0+IHtcclxuICAgIHN3aXRjaCAodHlwZSkge1xyXG4gICAgICBjYXNlICdlbWFpbCc6XHJcbiAgICAgICAgcmV0dXJuICdiZy1wcmltYXJ5LTUwIHRleHQtcHJpbWFyeSc7XHJcbiAgICAgIGNhc2UgJ2NhbGwnOlxyXG4gICAgICAgIHJldHVybiAnYmctc3VjY2Vzcy01MCB0ZXh0LXN1Y2Nlc3MnO1xyXG4gICAgICBjYXNlICdtZWV0aW5nJzpcclxuICAgICAgICByZXR1cm4gJ2JnLXNlY29uZGFyeS01MCB0ZXh0LXNlY29uZGFyeSc7XHJcbiAgICAgIGNhc2UgJ25vdGUnOlxyXG4gICAgICAgIHJldHVybiAnYmctd2FybmluZy01MCB0ZXh0LXdhcm5pbmcnO1xyXG4gICAgICBjYXNlICd0YXNrJzpcclxuICAgICAgICByZXR1cm4gJ2JnLWFjY2VudC01MCB0ZXh0LWFjY2VudCc7XHJcbiAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgcmV0dXJuICdiZy1ncmF5LTEwMCB0ZXh0LWdyYXktNjAwJztcclxuICAgIH1cclxuICB9O1xyXG4gIFxyXG4gIGNvbnN0IGZvcm1hdERhdGVUaW1lID0gKGRhdGVTdHJpbmcpID0+IHtcclxuICAgIHJldHVybiBmb3JtYXQobmV3IERhdGUoZGF0ZVN0cmluZyksICdNTU0gZCwgeXl5eSBoOm1tIGEnKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVBZGRBY3Rpdml0eSA9IGFzeW5jIChhY3Rpdml0eURhdGEpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IG5ld0FjdGl2aXR5ID0gYXdhaXQgYWN0aXZpdGllc1NlcnZpY2UuY3JlYXRlQWN0aXZpdHkoYWN0aXZpdHlEYXRhKTtcclxuICAgICAgaWYgKG9uQWN0aXZpdHlBZGRlZCkge1xyXG4gICAgICAgIG9uQWN0aXZpdHlBZGRlZChuZXdBY3Rpdml0eSk7XHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIG5ld0FjdGl2aXR5O1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgY3JlYXRpbmcgYWN0aXZpdHk6JywgZXJyb3IpO1xyXG4gICAgICB0aHJvdyBlcnJvcjtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVPcGVuQWRkTW9kYWwgPSAoKSA9PiB7XHJcbiAgICBzZXRTaG93QWRkQWN0aXZpdHlNb2RhbCh0cnVlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDbG9zZUFkZE1vZGFsID0gKCkgPT4ge1xyXG4gICAgc2V0U2hvd0FkZEFjdGl2aXR5TW9kYWwoZmFsc2UpO1xyXG4gIH07XHJcbiAgXHJcbiAgY29uc3QgZmlsdGVyZWRBY3Rpdml0aWVzID0gZmlsdGVyID09PSAnYWxsJyBcclxuICAgID8gYWN0aXZpdGllcyBcclxuICAgIDogYWN0aXZpdGllcz8uZmlsdGVyKGFjdGl2aXR5ID0+IGFjdGl2aXR5Py50eXBlID09PSBmaWx0ZXIpO1xyXG4gIFxyXG4gIGNvbnN0IHNvcnRlZEFjdGl2aXRpZXMgPSBbLi4uZmlsdGVyZWRBY3Rpdml0aWVzXT8uc29ydCgoYSwgYikgPT4gXHJcbiAgICBuZXcgRGF0ZShiLnNjaGVkdWxlZF9hdCB8fCBiLmNyZWF0ZWRfYXQpIC0gbmV3IERhdGUoYS5zY2hlZHVsZWRfYXQgfHwgYS5jcmVhdGVkX2F0KVxyXG4gICk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYi02XCI+XHJcbiAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXRleHQtcHJpbWFyeVwiPkFjdGl2aXR5IFRpbWVsaW5lPC9oMz5cclxuICAgICAgICBcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMlwiPlxyXG4gICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICB2YWx1ZT17ZmlsdGVyfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZpbHRlcihlPy50YXJnZXQ/LnZhbHVlKX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1zbSBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLW1kIHB5LTEgcHgtMiB0ZXh0LXRleHQtcHJpbWFyeSBiZy1zdXJmYWNlIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1wcmltYXJ5IGZvY3VzOmJvcmRlci1wcmltYXJ5XCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImFsbFwiPkFsbCBBY3Rpdml0aWVzPC9vcHRpb24+XHJcbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJlbWFpbFwiPkVtYWlsczwvb3B0aW9uPlxyXG4gICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiY2FsbFwiPkNhbGxzPC9vcHRpb24+XHJcbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJtZWV0aW5nXCI+TWVldGluZ3M8L29wdGlvbj5cclxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIm5vdGVcIj5Ob3Rlczwvb3B0aW9uPlxyXG4gICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwidGFza1wiPlRhc2tzPC9vcHRpb24+XHJcbiAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgPGJ1dHRvbiBcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMiBweC0zIHB5LTEgYm9yZGVyIGJvcmRlci1ib3JkZXIgcm91bmRlZC1tZCB0ZXh0LXRleHQtc2Vjb25kYXJ5IGhvdmVyOnRleHQtcHJpbWFyeSBob3Zlcjpib3JkZXItcHJpbWFyeSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0xNTAgZWFzZS1vdXQgdGV4dC1zbVwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZU9wZW5BZGRNb2RhbH1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPEljb24gbmFtZT1cIlBsdXNcIiBzaXplPXsxNH0gLz5cclxuICAgICAgICAgICAgPHNwYW4+TG9nIEFjdGl2aXR5PC9zcGFuPlxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICB7c29ydGVkQWN0aXZpdGllcz8ubGVuZ3RoID4gMCA/IChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XHJcbiAgICAgICAgICB7LyogVGltZWxpbmUgbGluZSAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgbGVmdC02IHRvcC0wIGJvdHRvbS0wIHctcHggYmctYm9yZGVyXCI+PC9kaXY+XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIHsvKiBBY3Rpdml0aWVzICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cclxuICAgICAgICAgICAge3NvcnRlZEFjdGl2aXRpZXM/Lm1hcCgoYWN0aXZpdHkpID0+IChcclxuICAgICAgICAgICAgICA8ZGl2IGtleT17YWN0aXZpdHk/LmlkfSBjbGFzc05hbWU9XCJyZWxhdGl2ZSBwbC0xNFwiPlxyXG4gICAgICAgICAgICAgICAgey8qIEFjdGl2aXR5IGljb24gKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGFic29sdXRlIGxlZnQtMCB3LTEyIGgtMTIgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyICR7Z2V0QWN0aXZpdHlDb2xvcihhY3Rpdml0eT8udHlwZSl9YH0+XHJcbiAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9e2dldEFjdGl2aXR5SWNvbihhY3Rpdml0eT8udHlwZSl9IHNpemU9ezIwfSAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIHsvKiBBY3Rpdml0eSBjb250ZW50ICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIHAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLXN0YXJ0IG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHthY3Rpdml0eT8udHlwZSA9PT0gJ2VtYWlsJyAmJiAnRW1haWw6ICd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHthY3Rpdml0eT8udHlwZSA9PT0gJ2NhbGwnICYmICdDYWxsOiAnfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7YWN0aXZpdHk/LnR5cGUgPT09ICdtZWV0aW5nJyAmJiAnTWVldGluZzogJ31cclxuICAgICAgICAgICAgICAgICAgICAgICAge2FjdGl2aXR5Py5zdWJqZWN0IHx8IGFjdGl2aXR5Py5zdW1tYXJ5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC10ZXh0LXRlcnRpYXJ5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXREYXRlVGltZShhY3Rpdml0eT8uc2NoZWR1bGVkX2F0IHx8IGFjdGl2aXR5Py5jcmVhdGVkX2F0KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAge2FjdGl2aXR5Py5kdXJhdGlvbl9taW51dGVzICYmIGAg4oCiICR7YWN0aXZpdHk/LmR1cmF0aW9uX21pbnV0ZXN9IG1pbnV0ZXNgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBzcGFjZS14LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwidGV4dC10ZXh0LXRlcnRpYXJ5IGhvdmVyOnRleHQtdGV4dC1wcmltYXJ5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJFZGl0XCIgc2l6ZT17MTR9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwidGV4dC10ZXh0LXRlcnRpYXJ5IGhvdmVyOnRleHQtZXJyb3JcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIlRyYXNoMlwiIHNpemU9ezE0fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2FjdGl2aXR5Py5kZXNjcmlwdGlvbiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtcHJpbWFyeSB0ZXh0LXNtIG10LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHthY3Rpdml0eT8uZGVzY3JpcHRpb259XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICB7YWN0aXZpdHk/LnN1bW1hcnkgJiYgIWFjdGl2aXR5Py5zdWJqZWN0ICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtdGV4dC1wcmltYXJ5IHRleHQtc20gbXQtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2FjdGl2aXR5Py5zdW1tYXJ5fVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICkgOiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS0xMiBib3JkZXIgYm9yZGVyLWRhc2hlZCBib3JkZXItYm9yZGVyIHJvdW5kZWQtbGdcIj5cclxuICAgICAgICAgIDxJY29uIG5hbWU9XCJDYWxlbmRhclwiIHNpemU9ezMyfSBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtdGVydGlhcnkgbXgtYXV0byBtYi0zXCIgLz5cclxuICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IG1iLTFcIj5ObyBhY3Rpdml0aWVzIGZvdW5kPC9oND5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtdGV4dC1zZWNvbmRhcnkgbWItNFwiPlxyXG4gICAgICAgICAgICB7ZmlsdGVyID09PSAnYWxsJyA/J1RoZXJlIGFyZSBubyBhY3Rpdml0aWVzIHJlY29yZGVkIGZvciB0aGlzIGNvbnRhY3QgeWV0LicgXHJcbiAgICAgICAgICAgICAgOiBgVGhlcmUgYXJlIG5vICR7ZmlsdGVyfSBhY3Rpdml0aWVzIHJlY29yZGVkIGZvciB0aGlzIGNvbnRhY3QuYH1cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDxidXR0b24gXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5IGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTJcIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVPcGVuQWRkTW9kYWx9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxJY29uIG5hbWU9XCJQbHVzXCIgc2l6ZT17MTZ9IC8+XHJcbiAgICAgICAgICAgIDxzcGFuPkxvZyBhbiBBY3Rpdml0eTwvc3Bhbj5cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG5cclxuICAgICAgey8qIEFkZCBBY3Rpdml0eSBNb2RhbCAqL31cclxuICAgICAge3Nob3dBZGRBY3Rpdml0eU1vZGFsICYmIChcclxuICAgICAgICA8QWRkQWN0aXZpdHlNb2RhbFxyXG4gICAgICAgICAgY29udGFjdD17Y29udGFjdH1cclxuICAgICAgICAgIG9uQ2xvc2U9e2hhbmRsZUNsb3NlQWRkTW9kYWx9XHJcbiAgICAgICAgICBvbkFjdGl2aXR5QWRkZWQ9e2hhbmRsZUFkZEFjdGl2aXR5fVxyXG4gICAgICAgIC8+XHJcbiAgICAgICl9XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQWN0aXZpdHlUaW1lbGluZTsiXSwiZmlsZSI6IkQ6L2N1cnJlbnQgcHJvamVjdHMvY2xhdWRlLWNvZGUvc3JjL3BhZ2VzL2NvbnRhY3QtbWFuYWdlbWVudC9jb21wb25lbnRzL0FjdGl2aXR5VGltZWxpbmUuanN4In0=