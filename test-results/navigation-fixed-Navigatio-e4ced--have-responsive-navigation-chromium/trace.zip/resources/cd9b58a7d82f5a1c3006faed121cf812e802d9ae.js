import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/contact-management/components/DealsList.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/contact-management/components/DealsList.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=44ab9529";
import Icon from "/src/components/AppIcon.jsx";
const DealsList = ({ deals, contactName }) => {
  const formatCurrency = (value) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    })?.format(value);
  };
  const getStageLabel = (stage) => {
    switch (stage) {
      case "discovery":
        return "Discovery";
      case "proposal":
        return "Proposal";
      case "negotiation":
        return "Negotiation";
      case "closed-won":
        return "Closed Won";
      case "closed-lost":
        return "Closed Lost";
      default:
        return stage?.charAt(0)?.toUpperCase() + stage?.slice(1);
    }
  };
  const getStageColor = (stage) => {
    switch (stage) {
      case "discovery":
        return "bg-primary-50 text-primary";
      case "proposal":
        return "bg-secondary-50 text-secondary";
      case "negotiation":
        return "bg-warning-50 text-warning";
      case "closed-won":
        return "bg-success-50 text-success";
      case "closed-lost":
        return "bg-error-50 text-error";
      default:
        return "bg-gray-100 text-gray-600";
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\DealsList.jsx:50:4", "data-component-path": "src\\pages\\contact-management\\components\\DealsList.jsx", "data-component-line": "50", "data-component-file": "DealsList.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\DealsList.jsx:51:6", "data-component-path": "src\\pages\\contact-management\\components\\DealsList.jsx", "data-component-line": "51", "data-component-file": "DealsList.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20justify-between%20items-center%20mb-6%22%7D", className: "flex justify-between items-center mb-6", children: [
      /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\contact-management\\components\\DealsList.jsx:52:8", "data-component-path": "src\\pages\\contact-management\\components\\DealsList.jsx", "data-component-line": "52", "data-component-file": "DealsList.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%2C%22textContent%22%3A%22Deals%22%7D", className: "text-lg font-semibold text-text-primary", children: "Deals" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/DealsList.jsx",
        lineNumber: 52,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        Link,
        {
          "data-component-id": "src\\pages\\contact-management\\components\\DealsList.jsx:54:8",
          "data-component-path": "src\\pages\\contact-management\\components\\DealsList.jsx",
          "data-component-line": "54",
          "data-component-file": "DealsList.jsx",
          "data-component-name": "Link",
          "data-component-content": "%7B%22elementName%22%3A%22Link%22%2C%22className%22%3A%22inline-flex%20items-center%20space-x-2%20px-3%20py-1%20border%20border-border%20rounded-md%20text-text-secondary%20hover%3Atext-primary%20hover%3Aborder-primary%20transition-all%20duration-150%20ease-out%20text-sm%22%7D",
          to: "/deal-management",
          className: "inline-flex items-center space-x-2 px-3 py-1 border border-border rounded-md text-text-secondary hover:text-primary hover:border-primary transition-all duration-150 ease-out text-sm",
          children: [
            /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\DealsList.jsx:58:10", "data-component-path": "src\\pages\\contact-management\\components\\DealsList.jsx", "data-component-line": "58", "data-component-file": "DealsList.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Plus%22%7D", name: "Plus", size: 14 }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/DealsList.jsx",
              lineNumber: 58,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\DealsList.jsx:59:10", "data-component-path": "src\\pages\\contact-management\\components\\DealsList.jsx", "data-component-line": "59", "data-component-file": "DealsList.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Add%20Deal%22%7D", children: "Add Deal" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/DealsList.jsx",
              lineNumber: 59,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/DealsList.jsx",
          lineNumber: 54,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/DealsList.jsx",
      lineNumber: 51,
      columnNumber: 7
    }, this),
    deals?.length > 0 ? /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\DealsList.jsx:63:6", "data-component-path": "src\\pages\\contact-management\\components\\DealsList.jsx", "data-component-line": "63", "data-component-file": "DealsList.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22overflow-x-auto%22%7D", className: "overflow-x-auto", children: /* @__PURE__ */ jsxDEV("table", { "data-component-id": "src\\pages\\contact-management\\components\\DealsList.jsx:64:10", "data-component-path": "src\\pages\\contact-management\\components\\DealsList.jsx", "data-component-line": "64", "data-component-file": "DealsList.jsx", "data-component-name": "table", "data-component-content": "%7B%22elementName%22%3A%22table%22%2C%22className%22%3A%22min-w-full%20divide-y%20divide-border%22%7D", className: "min-w-full divide-y divide-border", children: [
      /* @__PURE__ */ jsxDEV("thead", { "data-component-id": "src\\pages\\contact-management\\components\\DealsList.jsx:65:12", "data-component-path": "src\\pages\\contact-management\\components\\DealsList.jsx", "data-component-line": "65", "data-component-file": "DealsList.jsx", "data-component-name": "thead", "data-component-content": "%7B%22elementName%22%3A%22thead%22%7D", children: /* @__PURE__ */ jsxDEV("tr", { "data-component-id": "src\\pages\\contact-management\\components\\DealsList.jsx:66:14", "data-component-path": "src\\pages\\contact-management\\components\\DealsList.jsx", "data-component-line": "66", "data-component-file": "DealsList.jsx", "data-component-name": "tr", "data-component-content": "%7B%22elementName%22%3A%22tr%22%7D", children: [
        /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\contact-management\\components\\DealsList.jsx:67:16", "data-component-path": "src\\pages\\contact-management\\components\\DealsList.jsx", "data-component-line": "67", "data-component-file": "DealsList.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22px-4%20py-3%20bg-surface-hover%20text-left%20text-xs%20font-medium%20text-text-secondary%20uppercase%20tracking-wider%22%2C%22textContent%22%3A%22Deal%20Name%22%7D", className: "px-4 py-3 bg-surface-hover text-left text-xs font-medium text-text-secondary uppercase tracking-wider", children: "Deal Name" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/DealsList.jsx",
          lineNumber: 67,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\contact-management\\components\\DealsList.jsx:70:16", "data-component-path": "src\\pages\\contact-management\\components\\DealsList.jsx", "data-component-line": "70", "data-component-file": "DealsList.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22px-4%20py-3%20bg-surface-hover%20text-left%20text-xs%20font-medium%20text-text-secondary%20uppercase%20tracking-wider%22%2C%22textContent%22%3A%22Stage%22%7D", className: "px-4 py-3 bg-surface-hover text-left text-xs font-medium text-text-secondary uppercase tracking-wider", children: "Stage" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/DealsList.jsx",
          lineNumber: 70,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\contact-management\\components\\DealsList.jsx:73:16", "data-component-path": "src\\pages\\contact-management\\components\\DealsList.jsx", "data-component-line": "73", "data-component-file": "DealsList.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22px-4%20py-3%20bg-surface-hover%20text-right%20text-xs%20font-medium%20text-text-secondary%20uppercase%20tracking-wider%22%2C%22textContent%22%3A%22Value%22%7D", className: "px-4 py-3 bg-surface-hover text-right text-xs font-medium text-text-secondary uppercase tracking-wider", children: "Value" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/DealsList.jsx",
          lineNumber: 73,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\contact-management\\components\\DealsList.jsx:76:16", "data-component-path": "src\\pages\\contact-management\\components\\DealsList.jsx", "data-component-line": "76", "data-component-file": "DealsList.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22px-4%20py-3%20bg-surface-hover%20text-right%20text-xs%20font-medium%20text-text-secondary%20uppercase%20tracking-wider%22%2C%22textContent%22%3A%22Actions%22%7D", className: "px-4 py-3 bg-surface-hover text-right text-xs font-medium text-text-secondary uppercase tracking-wider", children: "Actions" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/DealsList.jsx",
          lineNumber: 76,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/DealsList.jsx",
        lineNumber: 66,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/DealsList.jsx",
        lineNumber: 65,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("tbody", { "data-component-id": "src\\pages\\contact-management\\components\\DealsList.jsx:81:12", "data-component-path": "src\\pages\\contact-management\\components\\DealsList.jsx", "data-component-line": "81", "data-component-file": "DealsList.jsx", "data-component-name": "tbody", "data-component-content": "%7B%22elementName%22%3A%22tbody%22%2C%22className%22%3A%22bg-surface%20divide-y%20divide-border%22%7D", className: "bg-surface divide-y divide-border", children: deals?.map(
        (deal) => /* @__PURE__ */ jsxDEV("tr", { "data-component-id": "src\\pages\\contact-management\\components\\DealsList.jsx:83:12", "data-component-path": "src\\pages\\contact-management\\components\\DealsList.jsx", "data-component-line": "83", "data-component-file": "DealsList.jsx", "data-component-name": "tr", "data-component-content": "%7B%22elementName%22%3A%22tr%22%2C%22className%22%3A%22hover%3Abg-surface-hover%22%7D", className: "hover:bg-surface-hover", children: [
          /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\contact-management\\components\\DealsList.jsx:84:18", "data-component-path": "src\\pages\\contact-management\\components\\DealsList.jsx", "data-component-line": "84", "data-component-file": "DealsList.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22px-4%20py-4%20whitespace-nowrap%22%7D", className: "px-4 py-4 whitespace-nowrap", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\DealsList.jsx:85:20", "data-component-path": "src\\pages\\contact-management\\components\\DealsList.jsx", "data-component-line": "85", "data-component-file": "DealsList.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-sm%20font-medium%20text-text-primary%22%7D", className: "text-sm font-medium text-text-primary", children: deal?.name }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/DealsList.jsx",
            lineNumber: 85,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/DealsList.jsx",
            lineNumber: 84,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\contact-management\\components\\DealsList.jsx:87:18", "data-component-path": "src\\pages\\contact-management\\components\\DealsList.jsx", "data-component-line": "87", "data-component-file": "DealsList.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22px-4%20py-4%20whitespace-nowrap%22%7D", className: "px-4 py-4 whitespace-nowrap", children: /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\DealsList.jsx:88:20", "data-component-path": "src\\pages\\contact-management\\components\\DealsList.jsx", "data-component-line": "88", "data-component-file": "DealsList.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", className: `inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStageColor(deal?.stage)}`, children: getStageLabel(deal?.stage) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/DealsList.jsx",
            lineNumber: 88,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/DealsList.jsx",
            lineNumber: 87,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\contact-management\\components\\DealsList.jsx:92:18", "data-component-path": "src\\pages\\contact-management\\components\\DealsList.jsx", "data-component-line": "92", "data-component-file": "DealsList.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22px-4%20py-4%20whitespace-nowrap%20text-right%20text-sm%20text-text-primary%20font-medium%22%7D", className: "px-4 py-4 whitespace-nowrap text-right text-sm text-text-primary font-medium", children: formatCurrency(deal?.value) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/DealsList.jsx",
            lineNumber: 92,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\contact-management\\components\\DealsList.jsx:95:18", "data-component-path": "src\\pages\\contact-management\\components\\DealsList.jsx", "data-component-line": "95", "data-component-file": "DealsList.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22px-4%20py-4%20whitespace-nowrap%20text-right%20text-sm%22%7D", className: "px-4 py-4 whitespace-nowrap text-right text-sm", children: /* @__PURE__ */ jsxDEV(
            Link,
            {
              "data-component-id": "src\\pages\\contact-management\\components\\DealsList.jsx:96:20",
              "data-component-path": "src\\pages\\contact-management\\components\\DealsList.jsx",
              "data-component-line": "96",
              "data-component-file": "DealsList.jsx",
              "data-component-name": "Link",
              "data-component-content": "%7B%22elementName%22%3A%22Link%22%2C%22className%22%3A%22text-primary%20hover%3Atext-primary-700%22%2C%22textContent%22%3A%22View%20Details%22%7D",
              to: `/deal-management?deal=${deal?.id}`,
              className: "text-primary hover:text-primary-700",
              children: "View Details"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/DealsList.jsx",
              lineNumber: 96,
              columnNumber: 21
            },
            this
          ) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/DealsList.jsx",
            lineNumber: 95,
            columnNumber: 19
          }, this)
        ] }, deal?.id, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/DealsList.jsx",
          lineNumber: 83,
          columnNumber: 13
        }, this)
      ) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/DealsList.jsx",
        lineNumber: 81,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/DealsList.jsx",
      lineNumber: 64,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/DealsList.jsx",
      lineNumber: 63,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\DealsList.jsx:109:6", "data-component-path": "src\\pages\\contact-management\\components\\DealsList.jsx", "data-component-line": "109", "data-component-file": "DealsList.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-center%20py-12%20border%20border-dashed%20border-border%20rounded-lg%22%7D", className: "text-center py-12 border border-dashed border-border rounded-lg", children: [
      /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\DealsList.jsx:110:10", "data-component-path": "src\\pages\\contact-management\\components\\DealsList.jsx", "data-component-line": "110", "data-component-file": "DealsList.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Target%22%2C%22className%22%3A%22text-text-tertiary%20mx-auto%20mb-3%22%7D", name: "Target", size: 32, className: "text-text-tertiary mx-auto mb-3" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/DealsList.jsx",
        lineNumber: 110,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("h4", { "data-component-id": "src\\pages\\contact-management\\components\\DealsList.jsx:111:10", "data-component-path": "src\\pages\\contact-management\\components\\DealsList.jsx", "data-component-line": "111", "data-component-file": "DealsList.jsx", "data-component-name": "h4", "data-component-content": "%7B%22elementName%22%3A%22h4%22%2C%22className%22%3A%22text-lg%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22No%20deals%20found%22%7D", className: "text-lg font-medium text-text-primary mb-1", children: "No deals found" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/DealsList.jsx",
        lineNumber: 111,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\contact-management\\components\\DealsList.jsx:112:10", "data-component-path": "src\\pages\\contact-management\\components\\DealsList.jsx", "data-component-line": "112", "data-component-file": "DealsList.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20mb-4%22%2C%22textContent%22%3A%22doesn't%20have%20any%20deals%20associated%20yet.%22%7D", className: "text-text-secondary mb-4", children: [
        contactName,
        " doesn't have any deals associated yet."
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/DealsList.jsx",
        lineNumber: 112,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        Link,
        {
          "data-component-id": "src\\pages\\contact-management\\components\\DealsList.jsx:115:10",
          "data-component-path": "src\\pages\\contact-management\\components\\DealsList.jsx",
          "data-component-line": "115",
          "data-component-file": "DealsList.jsx",
          "data-component-name": "Link",
          "data-component-content": "%7B%22elementName%22%3A%22Link%22%2C%22className%22%3A%22btn-primary%20inline-flex%20items-center%20space-x-2%22%7D",
          to: "/deal-management",
          className: "btn-primary inline-flex items-center space-x-2",
          children: [
            /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\DealsList.jsx:119:12", "data-component-path": "src\\pages\\contact-management\\components\\DealsList.jsx", "data-component-line": "119", "data-component-file": "DealsList.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Plus%22%7D", name: "Plus", size: 16 }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/DealsList.jsx",
              lineNumber: 119,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\DealsList.jsx:120:12", "data-component-path": "src\\pages\\contact-management\\components\\DealsList.jsx", "data-component-line": "120", "data-component-file": "DealsList.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Create%20a%20Deal%22%7D", children: "Create a Deal" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/DealsList.jsx",
              lineNumber: 120,
              columnNumber: 13
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/DealsList.jsx",
          lineNumber: 115,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/DealsList.jsx",
      lineNumber: 109,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/contact-management/components/DealsList.jsx",
    lineNumber: 50,
    columnNumber: 5
  }, this);
};
_c = DealsList;
export default DealsList;
var _c;
$RefreshReg$(_c, "DealsList");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/contact-management/components/DealsList.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/contact-management/components/DealsList.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbURRO0FBbkRSLE9BQU9BLG9CQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN6QixTQUFTQyxZQUFZO0FBQ3JCLE9BQU9DLFVBQVU7QUFFakIsTUFBTUMsWUFBWUEsQ0FBQyxFQUFFQyxPQUFPQyxZQUFZLE1BQU07QUFDNUMsUUFBTUMsaUJBQWlCQSxDQUFDQyxVQUFVO0FBQ2hDLFdBQU8sSUFBSUMsS0FBS0MsYUFBYSxTQUFTO0FBQUEsTUFDcENDLE9BQU87QUFBQSxNQUNQQyxVQUFVO0FBQUEsTUFDVkMsdUJBQXVCO0FBQUEsTUFDdkJDLHVCQUF1QjtBQUFBLElBQ3pCLENBQUMsR0FBR0MsT0FBT1AsS0FBSztBQUFBLEVBQ2xCO0FBRUEsUUFBTVEsZ0JBQWdCQSxDQUFDQyxVQUFVO0FBQy9CLFlBQVFBLE9BQUs7QUFBQSxNQUNYLEtBQUs7QUFDSCxlQUFPO0FBQUEsTUFDVCxLQUFLO0FBQ0gsZUFBTztBQUFBLE1BQ1QsS0FBSztBQUNILGVBQU87QUFBQSxNQUNULEtBQUs7QUFDSCxlQUFPO0FBQUEsTUFDVCxLQUFLO0FBQ0gsZUFBTztBQUFBLE1BQ1Q7QUFDRSxlQUFPQSxPQUFPQyxPQUFPLENBQUMsR0FBR0MsWUFBWSxJQUFJRixPQUFPRyxNQUFNLENBQUM7QUFBQSxJQUMzRDtBQUFBLEVBQ0Y7QUFFQSxRQUFNQyxnQkFBZ0JBLENBQUNKLFVBQVU7QUFDL0IsWUFBUUEsT0FBSztBQUFBLE1BQ1gsS0FBSztBQUNILGVBQU87QUFBQSxNQUNULEtBQUs7QUFDSCxlQUFPO0FBQUEsTUFDVCxLQUFLO0FBQ0gsZUFBTztBQUFBLE1BQ1QsS0FBSztBQUNILGVBQU87QUFBQSxNQUNULEtBQUs7QUFDSCxlQUFPO0FBQUEsTUFDVDtBQUNFLGVBQU87QUFBQSxJQUNYO0FBQUEsRUFDRjtBQUVBLFNBQ0UsdUJBQUMsd1ZBQ0M7QUFBQSwyQkFBQywrWkFBSSxXQUFVLDBDQUNiO0FBQUEsNkJBQUMsNmJBQUcsV0FBVSwyQ0FBMEMscUJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkQ7QUFBQSxNQUU3RDtBQUFBLFFBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBQ0MsSUFBRztBQUFBLFVBQ0gsV0FBVTtBQUFBLFVBRVY7QUFBQSxtQ0FBQyxvWEFBSyxNQUFLLFFBQU8sTUFBTSxNQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyQjtBQUFBLFlBQzNCLHVCQUFDLG1ZQUFLLHdCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWM7QUFBQTtBQUFBO0FBQUEsUUFMaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUE7QUFBQSxTQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLElBQ0NaLE9BQU9pQixTQUFTLElBQ2YsdUJBQUMsa1lBQUksV0FBVSxtQkFDYixpQ0FBQywrWkFBTSxXQUFVLHFDQUNmO0FBQUEsNkJBQUMsK1ZBQ0MsaUNBQUMsc1ZBQ0M7QUFBQSwrQkFBQyw4Z0JBQUcsV0FBVSx5R0FBd0cseUJBQXRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsd2dCQUFHLFdBQVUseUdBQXdHLHFCQUF0SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLHlnQkFBRyxXQUFVLDBHQUF5RyxxQkFBdkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQywyZ0JBQUcsV0FBVSwwR0FBeUcsdUJBQXZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBLEtBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWVBO0FBQUEsTUFDQSx1QkFBQywrWkFBTSxXQUFVLHFDQUNkakIsaUJBQU9rQjtBQUFBQSxRQUFJLENBQUNDLFNBQ1gsdUJBQUMseVlBQWtCLFdBQVUsMEJBQzNCO0FBQUEsaUNBQUMsZ1pBQUcsV0FBVSwrQkFDWixpQ0FBQyw2WkFBSSxXQUFVLHlDQUF5Q0EsZ0JBQU1DLFFBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1FLEtBRHJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLGdaQUFHLFdBQVUsK0JBQ1osaUNBQUMsNFZBQUssV0FBVywyRUFBMkVKLGNBQWNHLE1BQU1QLEtBQUssQ0FBQyxJQUNuSEQsd0JBQWNRLE1BQU1QLEtBQUssS0FENUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxVQUNBLHVCQUFDLHljQUFHLFdBQVUsZ0ZBQ1hWLHlCQUFlaUIsTUFBTWhCLEtBQUssS0FEN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsdWFBQUcsV0FBVSxrREFDWjtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsSUFBSSx5QkFBeUJnQixNQUFNRSxFQUFFO0FBQUEsY0FDckMsV0FBVTtBQUFBLGNBQXFDO0FBQUE7QUFBQSxZQUZqRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxhQW5CT0YsTUFBTUUsSUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0JBO0FBQUEsTUFDRCxLQXZCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0JBO0FBQUEsU0F6Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBDQSxLQTNDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNENBLElBRUEsdUJBQUMsOGJBQUksV0FBVSxtRUFDYjtBQUFBLDZCQUFDLHNiQUFLLE1BQUssVUFBUyxNQUFNLElBQUksV0FBVSxxQ0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5RTtBQUFBLE1BQ3pFLHVCQUFDLGtkQUFHLFdBQVUsOENBQTZDLDhCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlFO0FBQUEsTUFDekUsdUJBQUMsdWRBQUUsV0FBVSw0QkFDVnBCO0FBQUFBO0FBQUFBLFFBQVk7QUFBQSxXQURmO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUNDLElBQUc7QUFBQSxVQUNILFdBQVU7QUFBQSxVQUVWO0FBQUEsbUNBQUMsc1hBQUssTUFBSyxRQUFPLE1BQU0sTUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkI7QUFBQSxZQUMzQix1QkFBQyw0WUFBSyw2QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtQjtBQUFBO0FBQUE7QUFBQSxRQUxyQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNQTtBQUFBLFNBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWFBO0FBQUEsT0F4RUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTBFQTtBQUVKO0FBQUVxQixLQXpISXZCO0FBMkhOLGVBQWVBO0FBQVUsSUFBQXVCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsIkxpbmsiLCJJY29uIiwiRGVhbHNMaXN0IiwiZGVhbHMiLCJjb250YWN0TmFtZSIsImZvcm1hdEN1cnJlbmN5IiwidmFsdWUiLCJJbnRsIiwiTnVtYmVyRm9ybWF0Iiwic3R5bGUiLCJjdXJyZW5jeSIsIm1pbmltdW1GcmFjdGlvbkRpZ2l0cyIsIm1heGltdW1GcmFjdGlvbkRpZ2l0cyIsImZvcm1hdCIsImdldFN0YWdlTGFiZWwiLCJzdGFnZSIsImNoYXJBdCIsInRvVXBwZXJDYXNlIiwic2xpY2UiLCJnZXRTdGFnZUNvbG9yIiwibGVuZ3RoIiwibWFwIiwiZGVhbCIsIm5hbWUiLCJpZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiRGVhbHNMaXN0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcbmltcG9ydCBJY29uIGZyb20gJ2NvbXBvbmVudHMvQXBwSWNvbic7XHJcblxyXG5jb25zdCBEZWFsc0xpc3QgPSAoeyBkZWFscywgY29udGFjdE5hbWUgfSkgPT4ge1xyXG4gIGNvbnN0IGZvcm1hdEN1cnJlbmN5ID0gKHZhbHVlKSA9PiB7XHJcbiAgICByZXR1cm4gbmV3IEludGwuTnVtYmVyRm9ybWF0KCdlbi1VUycsIHtcclxuICAgICAgc3R5bGU6ICdjdXJyZW5jeScsXHJcbiAgICAgIGN1cnJlbmN5OiAnVVNEJyxcclxuICAgICAgbWluaW11bUZyYWN0aW9uRGlnaXRzOiAwLFxyXG4gICAgICBtYXhpbXVtRnJhY3Rpb25EaWdpdHM6IDBcclxuICAgIH0pPy5mb3JtYXQodmFsdWUpO1xyXG4gIH07XHJcbiAgXHJcbiAgY29uc3QgZ2V0U3RhZ2VMYWJlbCA9IChzdGFnZSkgPT4ge1xyXG4gICAgc3dpdGNoIChzdGFnZSkge1xyXG4gICAgICBjYXNlICdkaXNjb3ZlcnknOlxyXG4gICAgICAgIHJldHVybiAnRGlzY292ZXJ5JztcclxuICAgICAgY2FzZSAncHJvcG9zYWwnOlxyXG4gICAgICAgIHJldHVybiAnUHJvcG9zYWwnO1xyXG4gICAgICBjYXNlICduZWdvdGlhdGlvbic6XHJcbiAgICAgICAgcmV0dXJuICdOZWdvdGlhdGlvbic7XHJcbiAgICAgIGNhc2UgJ2Nsb3NlZC13b24nOlxyXG4gICAgICAgIHJldHVybiAnQ2xvc2VkIFdvbic7XHJcbiAgICAgIGNhc2UgJ2Nsb3NlZC1sb3N0JzpcclxuICAgICAgICByZXR1cm4gJ0Nsb3NlZCBMb3N0JztcclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICByZXR1cm4gc3RhZ2U/LmNoYXJBdCgwKT8udG9VcHBlckNhc2UoKSArIHN0YWdlPy5zbGljZSgxKTtcclxuICAgIH1cclxuICB9O1xyXG4gIFxyXG4gIGNvbnN0IGdldFN0YWdlQ29sb3IgPSAoc3RhZ2UpID0+IHtcclxuICAgIHN3aXRjaCAoc3RhZ2UpIHtcclxuICAgICAgY2FzZSAnZGlzY292ZXJ5JzpcclxuICAgICAgICByZXR1cm4gJ2JnLXByaW1hcnktNTAgdGV4dC1wcmltYXJ5JztcclxuICAgICAgY2FzZSAncHJvcG9zYWwnOlxyXG4gICAgICAgIHJldHVybiAnYmctc2Vjb25kYXJ5LTUwIHRleHQtc2Vjb25kYXJ5JztcclxuICAgICAgY2FzZSAnbmVnb3RpYXRpb24nOlxyXG4gICAgICAgIHJldHVybiAnYmctd2FybmluZy01MCB0ZXh0LXdhcm5pbmcnO1xyXG4gICAgICBjYXNlICdjbG9zZWQtd29uJzpcclxuICAgICAgICByZXR1cm4gJ2JnLXN1Y2Nlc3MtNTAgdGV4dC1zdWNjZXNzJztcclxuICAgICAgY2FzZSAnY2xvc2VkLWxvc3QnOlxyXG4gICAgICAgIHJldHVybiAnYmctZXJyb3ItNTAgdGV4dC1lcnJvcic7XHJcbiAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgcmV0dXJuICdiZy1ncmF5LTEwMCB0ZXh0LWdyYXktNjAwJztcclxuICAgIH1cclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgbWItNlwiPlxyXG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC10ZXh0LXByaW1hcnlcIj5EZWFsczwvaDM+XHJcbiAgICAgICAgXHJcbiAgICAgICAgPExpbmtcclxuICAgICAgICAgIHRvPVwiL2RlYWwtbWFuYWdlbWVudFwiXHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yIHB4LTMgcHktMSBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLW1kIHRleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC1wcmltYXJ5IGhvdmVyOmJvcmRlci1wcmltYXJ5IHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTE1MCBlYXNlLW91dCB0ZXh0LXNtXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8SWNvbiBuYW1lPVwiUGx1c1wiIHNpemU9ezE0fSAvPlxyXG4gICAgICAgICAgPHNwYW4+QWRkIERlYWw8L3NwYW4+XHJcbiAgICAgICAgPC9MaW5rPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAge2RlYWxzPy5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvXCI+XHJcbiAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwibWluLXctZnVsbCBkaXZpZGUteSBkaXZpZGUtYm9yZGVyXCI+XHJcbiAgICAgICAgICAgIDx0aGVhZD5cclxuICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0zIGJnLXN1cmZhY2UtaG92ZXIgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC10ZXh0LXNlY29uZGFyeSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgRGVhbCBOYW1lXHJcbiAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTQgcHktMyBiZy1zdXJmYWNlLWhvdmVyIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1zZWNvbmRhcnkgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIFN0YWdlXHJcbiAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTQgcHktMyBiZy1zdXJmYWNlLWhvdmVyIHRleHQtcmlnaHQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXRleHQtc2Vjb25kYXJ5IHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICBWYWx1ZVxyXG4gICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC00IHB5LTMgYmctc3VyZmFjZS1ob3ZlciB0ZXh0LXJpZ2h0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC10ZXh0LXNlY29uZGFyeSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgQWN0aW9uc1xyXG4gICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiYmctc3VyZmFjZSBkaXZpZGUteSBkaXZpZGUtYm9yZGVyXCI+XHJcbiAgICAgICAgICAgICAge2RlYWxzPy5tYXAoKGRlYWwpID0+IChcclxuICAgICAgICAgICAgICAgIDx0ciBrZXk9e2RlYWw/LmlkfSBjbGFzc05hbWU9XCJob3ZlcjpiZy1zdXJmYWNlLWhvdmVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTQgd2hpdGVzcGFjZS1ub3dyYXBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnlcIj57ZGVhbD8ubmFtZX08L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktNCB3aGl0ZXNwYWNlLW5vd3JhcFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0yLjUgcHktMC41IHJvdW5kZWQtZnVsbCB0ZXh0LXhzIGZvbnQtbWVkaXVtICR7Z2V0U3RhZ2VDb2xvcihkZWFsPy5zdGFnZSl9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Z2V0U3RhZ2VMYWJlbChkZWFsPy5zdGFnZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS00IHdoaXRlc3BhY2Utbm93cmFwIHRleHQtcmlnaHQgdGV4dC1zbSB0ZXh0LXRleHQtcHJpbWFyeSBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtmb3JtYXRDdXJyZW5jeShkZWFsPy52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTQgd2hpdGVzcGFjZS1ub3dyYXAgdGV4dC1yaWdodCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgIHRvPXtgL2RlYWwtbWFuYWdlbWVudD9kZWFsPSR7ZGVhbD8uaWR9YH1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeSBob3Zlcjp0ZXh0LXByaW1hcnktNzAwXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBWaWV3IERldGFpbHNcclxuICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKSA6IChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LTEyIGJvcmRlciBib3JkZXItZGFzaGVkIGJvcmRlci1ib3JkZXIgcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgPEljb24gbmFtZT1cIlRhcmdldFwiIHNpemU9ezMyfSBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtdGVydGlhcnkgbXgtYXV0byBtYi0zXCIgLz5cclxuICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IG1iLTFcIj5ObyBkZWFscyBmb3VuZDwvaDQ+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5IG1iLTRcIj5cclxuICAgICAgICAgICAge2NvbnRhY3ROYW1lfSBkb2Vzbid0IGhhdmUgYW55IGRlYWxzIGFzc29jaWF0ZWQgeWV0LlxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgdG89XCIvZGVhbC1tYW5hZ2VtZW50XCJcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLXByaW1hcnkgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMlwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxJY29uIG5hbWU9XCJQbHVzXCIgc2l6ZT17MTZ9IC8+XHJcbiAgICAgICAgICAgIDxzcGFuPkNyZWF0ZSBhIERlYWw8L3NwYW4+XHJcbiAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgRGVhbHNMaXN0OyJdLCJmaWxlIjoiRDovY3VycmVudCBwcm9qZWN0cy9jbGF1ZGUtY29kZS9zcmMvcGFnZXMvY29udGFjdC1tYW5hZ2VtZW50L2NvbXBvbmVudHMvRGVhbHNMaXN0LmpzeCJ9