import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/settings-administration/components/CustomFields.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import Icon from "/src/components/AppIcon.jsx";
const CustomFields = () => {
  _s();
  const [fields, setFields] = useState(
    [
      {
        id: 1,
        name: "Lead Source",
        type: "select",
        entity: "contact",
        required: true,
        options: ["Website", "Social Media", "Referral", "Cold Call"],
        placement: "contact_form",
        createdAt: "2024-01-10"
      },
      {
        id: 2,
        name: "Annual Revenue",
        type: "number",
        entity: "contact",
        required: false,
        validation: { min: 0, max: 999999999 },
        placement: "contact_detail",
        createdAt: "2024-01-08"
      },
      {
        id: 3,
        name: "Deal Priority",
        type: "select",
        entity: "deal",
        required: true,
        options: ["Low", "Medium", "High", "Critical"],
        placement: "deal_form",
        createdAt: "2024-01-05"
      }
    ]
  );
  const [showFieldModal, setShowFieldModal] = useState(false);
  const [editingField, setEditingField] = useState(null);
  const [fieldForm, setFieldForm] = useState({
    name: "",
    type: "text",
    entity: "contact",
    required: false,
    options: [""],
    validation: {},
    placement: "contact_form"
  });
  const fieldTypes = [
    { value: "text", label: "Text", icon: "Type" },
    { value: "textarea", label: "Long Text", icon: "AlignLeft" },
    { value: "number", label: "Number", icon: "Hash" },
    { value: "email", label: "Email", icon: "Mail" },
    { value: "phone", label: "Phone", icon: "Phone" },
    { value: "url", label: "URL", icon: "Link" },
    { value: "date", label: "Date", icon: "Calendar" },
    { value: "select", label: "Dropdown", icon: "ChevronDown" },
    { value: "checkbox", label: "Checkbox", icon: "Check" },
    { value: "radio", label: "Radio Button", icon: "Circle" }
  ];
  const entities = [
    { value: "contact", label: "Contact" },
    { value: "deal", label: "Deal" },
    { value: "activity", label: "Activity" }
  ];
  const placements = {
    contact: [
      { value: "contact_form", label: "Contact Form" },
      { value: "contact_detail", label: "Contact Detail View" },
      { value: "contact_list", label: "Contact List" }
    ],
    deal: [
      { value: "deal_form", label: "Deal Form" },
      { value: "deal_detail", label: "Deal Detail View" },
      { value: "pipeline_card", label: "Pipeline Card" }
    ],
    activity: [
      { value: "activity_form", label: "Activity Form" },
      { value: "activity_detail", label: "Activity Detail View" }
    ]
  };
  const handleCreateField = () => {
    setEditingField(null);
    setFieldForm({
      name: "",
      type: "text",
      entity: "contact",
      required: false,
      options: [""],
      validation: {},
      placement: "contact_form"
    });
    setShowFieldModal(true);
  };
  const handleEditField = (field) => {
    setEditingField(field);
    setFieldForm({
      name: field?.name,
      type: field?.type,
      entity: field?.entity,
      required: field?.required,
      options: field?.options || [""],
      validation: field?.validation || {},
      placement: field?.placement
    });
    setShowFieldModal(true);
  };
  const handleDeleteField = (fieldId) => {
    setFields((prev) => prev?.filter((field) => field?.id !== fieldId));
  };
  const handleSaveField = (e) => {
    e?.preventDefault();
    if (editingField) {
      setFields(
        (prev) => prev?.map(
          (field) => field?.id === editingField?.id ? { ...field, ...fieldForm } : field
        )
      );
    } else {
      const newField = {
        id: Date.now(),
        ...fieldForm,
        createdAt: (/* @__PURE__ */ new Date())?.toISOString()?.split("T")?.[0]
      };
      setFields((prev) => [...prev, newField]);
    }
    setShowFieldModal(false);
    setEditingField(null);
  };
  const addOption = () => {
    setFieldForm((prev) => ({
      ...prev,
      options: [...prev?.options, ""]
    }));
  };
  const updateOption = (index, value) => {
    setFieldForm((prev) => ({
      ...prev,
      options: prev?.options?.map((option, i) => i === index ? value : option)
    }));
  };
  const removeOption = (index) => {
    setFieldForm((prev) => ({
      ...prev,
      options: prev?.options?.filter((_, i) => i !== index)
    }));
  };
  const getTypeIcon = (type) => {
    const fieldType = fieldTypes?.find((ft) => ft?.value === type);
    return fieldType?.icon || "Type";
  };
  const getEntityBadge = (entity) => {
    const colors = {
      contact: "bg-primary-50 text-primary border-primary-100",
      deal: "bg-success-50 text-success border-success-100",
      activity: "bg-accent-50 text-accent border-accent-100"
    };
    return /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:177:6", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "177", "data-component-file": "CustomFields.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", className: `px-2 py-1 text-xs font-medium rounded border ${colors?.[entity] || "bg-gray-50 text-gray-600 border-gray-100"}`, children: entity?.charAt(0)?.toUpperCase() + entity?.slice(1) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
      lineNumber: 177,
      columnNumber: 7
    }, this);
  };
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:184:4", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "184", "data-component-file": "CustomFields.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-6%22%7D", className: "space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:186:6", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "186", "data-component-file": "CustomFields.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:187:8", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "187", "data-component-file": "CustomFields.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
        /* @__PURE__ */ jsxDEV("h2", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:188:10", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "188", "data-component-file": "CustomFields.jsx", "data-component-name": "h2", "data-component-content": "%7B%22elementName%22%3A%22h2%22%2C%22className%22%3A%22text-2xl%20font-bold%20text-text-primary%22%2C%22textContent%22%3A%22Custom%20Fields%22%7D", className: "text-2xl font-bold text-text-primary", children: "Custom Fields" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
          lineNumber: 188,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:189:10", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "189", "data-component-file": "CustomFields.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20mt-1%22%2C%22textContent%22%3A%22Create%20and%20manage%20custom%20fields%20for%20your%20data%22%7D", className: "text-text-secondary mt-1", children: "Create and manage custom fields for your data" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
          lineNumber: 189,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
        lineNumber: 187,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:191:8",
          "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx",
          "data-component-line": "191",
          "data-component-file": "CustomFields.jsx",
          "data-component-name": "button",
          "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22bg-primary%20text-white%20px-4%20py-2%20rounded-lg%20hover%3Abg-primary-600%20transition-colors%20duration-150%20ease-smooth%20flex%20items-center%20space-x-2%22%7D",
          onClick: handleCreateField,
          className: "bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary-600 transition-colors duration-150 ease-smooth flex items-center space-x-2",
          children: [
            /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:195:10", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "195", "data-component-file": "CustomFields.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Plus%22%7D", name: "Plus", size: 16 }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
              lineNumber: 195,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:196:10", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "196", "data-component-file": "CustomFields.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Create%20Field%22%7D", children: "Create Field" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
              lineNumber: 196,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
          lineNumber: 191,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
      lineNumber: 186,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:200:6", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "200", "data-component-file": "CustomFields.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20rounded-lg%20border%20border-border%20overflow-hidden%22%7D", className: "bg-surface rounded-lg border border-border overflow-hidden", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:201:8", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "201", "data-component-file": "CustomFields.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22overflow-x-auto%22%7D", className: "overflow-x-auto", children: /* @__PURE__ */ jsxDEV("table", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:202:10", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "202", "data-component-file": "CustomFields.jsx", "data-component-name": "table", "data-component-content": "%7B%22elementName%22%3A%22table%22%2C%22className%22%3A%22w-full%22%7D", className: "w-full", children: [
      /* @__PURE__ */ jsxDEV("thead", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:203:12", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "203", "data-component-file": "CustomFields.jsx", "data-component-name": "thead", "data-component-content": "%7B%22elementName%22%3A%22thead%22%2C%22className%22%3A%22bg-background%20border-b%20border-border%22%7D", className: "bg-background border-b border-border", children: /* @__PURE__ */ jsxDEV("tr", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:204:14", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "204", "data-component-file": "CustomFields.jsx", "data-component-name": "tr", "data-component-content": "%7B%22elementName%22%3A%22tr%22%7D", children: [
        /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:205:16", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "205", "data-component-file": "CustomFields.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22text-left%20py-3%20px-4%20text-sm%20font-medium%20text-text-primary%22%2C%22textContent%22%3A%22Field%20Name%22%7D", className: "text-left py-3 px-4 text-sm font-medium text-text-primary", children: "Field Name" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
          lineNumber: 205,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:206:16", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "206", "data-component-file": "CustomFields.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22text-left%20py-3%20px-4%20text-sm%20font-medium%20text-text-primary%22%2C%22textContent%22%3A%22Type%22%7D", className: "text-left py-3 px-4 text-sm font-medium text-text-primary", children: "Type" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
          lineNumber: 206,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:207:16", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "207", "data-component-file": "CustomFields.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22text-left%20py-3%20px-4%20text-sm%20font-medium%20text-text-primary%22%2C%22textContent%22%3A%22Entity%22%7D", className: "text-left py-3 px-4 text-sm font-medium text-text-primary", children: "Entity" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
          lineNumber: 207,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:208:16", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "208", "data-component-file": "CustomFields.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22text-left%20py-3%20px-4%20text-sm%20font-medium%20text-text-primary%22%2C%22textContent%22%3A%22Required%22%7D", className: "text-left py-3 px-4 text-sm font-medium text-text-primary", children: "Required" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
          lineNumber: 208,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:209:16", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "209", "data-component-file": "CustomFields.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22text-left%20py-3%20px-4%20text-sm%20font-medium%20text-text-primary%22%2C%22textContent%22%3A%22Placement%22%7D", className: "text-left py-3 px-4 text-sm font-medium text-text-primary", children: "Placement" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
          lineNumber: 209,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:210:16", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "210", "data-component-file": "CustomFields.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22text-left%20py-3%20px-4%20text-sm%20font-medium%20text-text-primary%22%2C%22textContent%22%3A%22Created%22%7D", className: "text-left py-3 px-4 text-sm font-medium text-text-primary", children: "Created" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
          lineNumber: 210,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:211:16", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "211", "data-component-file": "CustomFields.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22text-left%20py-3%20px-4%20text-sm%20font-medium%20text-text-primary%22%2C%22textContent%22%3A%22Actions%22%7D", className: "text-left py-3 px-4 text-sm font-medium text-text-primary", children: "Actions" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
          lineNumber: 211,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
        lineNumber: 204,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
        lineNumber: 203,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("tbody", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:214:12", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "214", "data-component-file": "CustomFields.jsx", "data-component-name": "tbody", "data-component-content": "%7B%22elementName%22%3A%22tbody%22%7D", children: fields?.map(
        (field) => /* @__PURE__ */ jsxDEV("tr", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:216:14", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "216", "data-component-file": "CustomFields.jsx", "data-component-name": "tr", "data-component-content": "%7B%22elementName%22%3A%22tr%22%2C%22className%22%3A%22border-b%20border-border%20hover%3Abg-surface-hover%22%7D", className: "border-b border-border hover:bg-surface-hover", children: [
          /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:217:18", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "217", "data-component-file": "CustomFields.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22py-3%20px-4%22%7D", className: "py-3 px-4", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:218:20", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "218", "data-component-file": "CustomFields.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%22%7D", className: "flex items-center space-x-2", children: [
            /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:219:22", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "219", "data-component-file": "CustomFields.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22className%22%3A%22text-text-tertiary%22%7D", name: getTypeIcon(field?.type), size: 16, className: "text-text-tertiary" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
              lineNumber: 219,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:220:22", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "220", "data-component-file": "CustomFields.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22font-medium%20text-text-primary%22%7D", className: "font-medium text-text-primary", children: field?.name }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
              lineNumber: 220,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
            lineNumber: 218,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
            lineNumber: 217,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:223:18", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "223", "data-component-file": "CustomFields.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22py-3%20px-4%20text-sm%20text-text-secondary%20capitalize%22%7D", className: "py-3 px-4 text-sm text-text-secondary capitalize", children: field?.type }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
            lineNumber: 223,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:224:18", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "224", "data-component-file": "CustomFields.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22py-3%20px-4%22%7D", className: "py-3 px-4", children: getEntityBadge(field?.entity) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
            lineNumber: 224,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:225:18", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "225", "data-component-file": "CustomFields.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22py-3%20px-4%22%7D", className: "py-3 px-4", children: field?.required ? /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:227:18", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "227", "data-component-file": "CustomFields.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Check%22%2C%22className%22%3A%22text-success%22%7D", name: "Check", size: 16, className: "text-success" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
            lineNumber: 227,
            columnNumber: 19
          }, this) : /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:229:18", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "229", "data-component-file": "CustomFields.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22X%22%2C%22className%22%3A%22text-text-tertiary%22%7D", name: "X", size: 16, className: "text-text-tertiary" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
            lineNumber: 229,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
            lineNumber: 225,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:232:18", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "232", "data-component-file": "CustomFields.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22py-3%20px-4%20text-sm%20text-text-secondary%22%7D", className: "py-3 px-4 text-sm text-text-secondary", children: placements?.[field?.entity]?.find((p) => p?.value === field?.placement)?.label || field?.placement }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
            lineNumber: 232,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:235:18", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "235", "data-component-file": "CustomFields.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22py-3%20px-4%20text-sm%20text-text-secondary%22%7D", className: "py-3 px-4 text-sm text-text-secondary", children: field?.createdAt }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
            lineNumber: 235,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:236:18", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "236", "data-component-file": "CustomFields.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22py-3%20px-4%22%7D", className: "py-3 px-4", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:237:20", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "237", "data-component-file": "CustomFields.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20space-x-2%22%7D", className: "flex space-x-2", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:238:22",
                "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx",
                "data-component-line": "238",
                "data-component-file": "CustomFields.jsx",
                "data-component-name": "button",
                "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22p-1%20text-text-secondary%20hover%3Atext-primary%20transition-colors%20duration-150%22%7D",
                onClick: () => handleEditField(field),
                className: "p-1 text-text-secondary hover:text-primary transition-colors duration-150",
                children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:242:24", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "242", "data-component-file": "CustomFields.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Edit3%22%7D", name: "Edit3", size: 16 }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
                  lineNumber: 242,
                  columnNumber: 25
                }, this)
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
                lineNumber: 238,
                columnNumber: 23
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:244:22",
                "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx",
                "data-component-line": "244",
                "data-component-file": "CustomFields.jsx",
                "data-component-name": "button",
                "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22p-1%20text-text-secondary%20hover%3Atext-error%20transition-colors%20duration-150%22%7D",
                onClick: () => handleDeleteField(field?.id),
                className: "p-1 text-text-secondary hover:text-error transition-colors duration-150",
                children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:248:24", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "248", "data-component-file": "CustomFields.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Trash2%22%7D", name: "Trash2", size: 16 }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
                  lineNumber: 248,
                  columnNumber: 25
                }, this)
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
                lineNumber: 244,
                columnNumber: 23
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
            lineNumber: 237,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
            lineNumber: 236,
            columnNumber: 19
          }, this)
        ] }, field?.id, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
          lineNumber: 216,
          columnNumber: 15
        }, this)
      ) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
        lineNumber: 214,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
      lineNumber: 202,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
      lineNumber: 201,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
      lineNumber: 200,
      columnNumber: 7
    }, this),
    showFieldModal && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:260:6", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "260", "data-component-file": "CustomFields.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20z-1200%20overflow-y-auto%22%7D", className: "fixed inset-0 z-1200 overflow-y-auto", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:261:10", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "261", "data-component-file": "CustomFields.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-center%20min-h-screen%20px-4%22%7D", className: "flex items-center justify-center min-h-screen px-4", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:262:12", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "262", "data-component-file": "CustomFields.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20bg-black%20bg-opacity-50%22%7D", className: "fixed inset-0 bg-black bg-opacity-50", onClick: () => setShowFieldModal(false) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
        lineNumber: 262,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:263:12", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "263", "data-component-file": "CustomFields.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20rounded-lg%20shadow-xl%20max-w-2xl%20w-full%20relative%20z-1300%20max-h-screen%20overflow-y-auto%22%7D", className: "bg-surface rounded-lg shadow-xl max-w-2xl w-full relative z-1300 max-h-screen overflow-y-auto", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:264:14", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "264", "data-component-file": "CustomFields.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22p-6%22%7D", className: "p-6", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:265:16", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "265", "data-component-file": "CustomFields.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%20mb-4%22%7D", className: "flex items-center justify-between mb-4", children: [
          /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:266:18", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "266", "data-component-file": "CustomFields.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%7D", className: "text-lg font-semibold text-text-primary", children: editingField ? "Edit Field" : "Create New Field" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
            lineNumber: 266,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:269:18",
              "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx",
              "data-component-line": "269",
              "data-component-file": "CustomFields.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22text-text-secondary%20hover%3Atext-text-primary%20transition-colors%20duration-150%22%7D",
              onClick: () => setShowFieldModal(false),
              className: "text-text-secondary hover:text-text-primary transition-colors duration-150",
              children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:273:20", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "273", "data-component-file": "CustomFields.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22X%22%7D", name: "X", size: 20 }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
                lineNumber: 273,
                columnNumber: 21
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
              lineNumber: 269,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
          lineNumber: 265,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("form", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:277:16", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "277", "data-component-file": "CustomFields.jsx", "data-component-name": "form", "data-component-content": "%7B%22elementName%22%3A%22form%22%2C%22className%22%3A%22space-y-4%22%7D", onSubmit: handleSaveField, className: "space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:278:18", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "278", "data-component-file": "CustomFields.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20md%3Agrid-cols-2%20gap-4%22%7D", className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:279:20", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "279", "data-component-file": "CustomFields.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:280:22", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "280", "data-component-file": "CustomFields.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Field%20Name%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Field Name" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
                lineNumber: 280,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:281:22",
                  "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx",
                  "data-component-line": "281",
                  "data-component-file": "CustomFields.jsx",
                  "data-component-name": "input",
                  "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22text%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
                  type: "text",
                  value: fieldForm?.name,
                  onChange: (e) => setFieldForm((prev) => ({ ...prev, name: e?.target?.value })),
                  className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
                  placeholder: "Enter field name",
                  required: true
                },
                void 0,
                false,
                {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
                  lineNumber: 281,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
              lineNumber: 279,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:291:20", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "291", "data-component-file": "CustomFields.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:292:22", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "292", "data-component-file": "CustomFields.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Field%20Type%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Field Type" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
                lineNumber: 292,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:293:22",
                  "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx",
                  "data-component-line": "293",
                  "data-component-file": "CustomFields.jsx",
                  "data-component-name": "select",
                  "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
                  value: fieldForm?.type,
                  onChange: (e) => setFieldForm((prev) => ({ ...prev, type: e?.target?.value })),
                  className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
                  children: fieldTypes?.map(
                    (type) => /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:299:22", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "299", "data-component-file": "CustomFields.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%7D", value: type?.value, children: type?.label }, type?.value, false, {
                      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
                      lineNumber: 299,
                      columnNumber: 23
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
                  lineNumber: 293,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
              lineNumber: 291,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
            lineNumber: 278,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:305:18", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "305", "data-component-file": "CustomFields.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20md%3Agrid-cols-2%20gap-4%22%7D", className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:306:20", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "306", "data-component-file": "CustomFields.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:307:22", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "307", "data-component-file": "CustomFields.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Apply%20To%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Apply To" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
                lineNumber: 307,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:308:22",
                  "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx",
                  "data-component-line": "308",
                  "data-component-file": "CustomFields.jsx",
                  "data-component-name": "select",
                  "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
                  value: fieldForm?.entity,
                  onChange: (e) => setFieldForm((prev) => ({
                    ...prev,
                    entity: e?.target?.value,
                    placement: placements?.[e?.target?.value]?.[0]?.value || ""
                  })),
                  className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
                  children: entities?.map(
                    (entity) => /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:318:22", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "318", "data-component-file": "CustomFields.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%7D", value: entity?.value, children: entity?.label }, entity?.value, false, {
                      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
                      lineNumber: 318,
                      columnNumber: 23
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
                  lineNumber: 308,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
              lineNumber: 306,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:323:20", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "323", "data-component-file": "CustomFields.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:324:22", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "324", "data-component-file": "CustomFields.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Placement%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Placement" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
                lineNumber: 324,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:325:22",
                  "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx",
                  "data-component-line": "325",
                  "data-component-file": "CustomFields.jsx",
                  "data-component-name": "select",
                  "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
                  value: fieldForm?.placement,
                  onChange: (e) => setFieldForm((prev) => ({ ...prev, placement: e?.target?.value })),
                  className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
                  children: placements?.[fieldForm?.entity]?.map(
                    (placement) => /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:331:22", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "331", "data-component-file": "CustomFields.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%7D", value: placement?.value, children: placement?.label }, placement?.value, false, {
                      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
                      lineNumber: 331,
                      columnNumber: 23
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
                  lineNumber: 325,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
              lineNumber: 323,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
            lineNumber: 305,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:337:18", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "337", "data-component-file": "CustomFields.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:338:20", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "338", "data-component-file": "CustomFields.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%22%7D", className: "flex items-center space-x-2", children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:339:22",
                "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx",
                "data-component-line": "339",
                "data-component-file": "CustomFields.jsx",
                "data-component-name": "input",
                "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22checkbox%22%2C%22className%22%3A%22rounded%20border-border%20text-primary%20focus%3Aring-primary%22%7D",
                type: "checkbox",
                checked: fieldForm?.required,
                onChange: (e) => setFieldForm((prev) => ({ ...prev, required: e?.target?.checked })),
                className: "rounded border-border text-primary focus:ring-primary"
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
                lineNumber: 339,
                columnNumber: 23
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:345:22", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "345", "data-component-file": "CustomFields.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-primary%22%2C%22textContent%22%3A%22Required%20field%22%7D", className: "text-sm text-text-primary", children: "Required field" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
              lineNumber: 345,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
            lineNumber: 338,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
            lineNumber: 337,
            columnNumber: 19
          }, this),
          (fieldForm?.type === "select" || fieldForm?.type === "radio") && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:350:16", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "350", "data-component-file": "CustomFields.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:351:22", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "351", "data-component-file": "CustomFields.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Options%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Options" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
              lineNumber: 351,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:352:22", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "352", "data-component-file": "CustomFields.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-2%22%7D", className: "space-y-2", children: [
              fieldForm?.options?.map(
                (option, index) => /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:354:20", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "354", "data-component-file": "CustomFields.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%22%7D", className: "flex items-center space-x-2", children: [
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:355:28",
                      "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx",
                      "data-component-line": "355",
                      "data-component-file": "CustomFields.jsx",
                      "data-component-name": "input",
                      "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22text%22%2C%22value%22%3A%22%5Bvar%3Aoption%5D%22%2C%22className%22%3A%22flex-1%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
                      type: "text",
                      value: option,
                      onChange: (e) => updateOption(index, e?.target?.value),
                      className: "flex-1 px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
                      placeholder: `Option ${index + 1}`
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
                      lineNumber: 355,
                      columnNumber: 29
                    },
                    this
                  ),
                  fieldForm?.options?.length > 1 && /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:363:22",
                      "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx",
                      "data-component-line": "363",
                      "data-component-file": "CustomFields.jsx",
                      "data-component-name": "button",
                      "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22button%22%2C%22className%22%3A%22p-2%20text-error%20hover%3Abg-error-50%20rounded%20transition-colors%20duration-150%22%7D",
                      type: "button",
                      onClick: () => removeOption(index),
                      className: "p-2 text-error hover:bg-error-50 rounded transition-colors duration-150",
                      children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:368:32", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "368", "data-component-file": "CustomFields.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22X%22%7D", name: "X", size: 16 }, void 0, false, {
                        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
                        lineNumber: 368,
                        columnNumber: 33
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
                      lineNumber: 363,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, index, true, {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
                  lineNumber: 354,
                  columnNumber: 21
                }, this)
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:373:24",
                  "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx",
                  "data-component-line": "373",
                  "data-component-file": "CustomFields.jsx",
                  "data-component-name": "button",
                  "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22button%22%2C%22className%22%3A%22text-sm%20text-primary%20hover%3Atext-primary-600%20flex%20items-center%20space-x-1%22%7D",
                  type: "button",
                  onClick: addOption,
                  className: "text-sm text-primary hover:text-primary-600 flex items-center space-x-1",
                  children: [
                    /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:378:26", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "378", "data-component-file": "CustomFields.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Plus%22%7D", name: "Plus", size: 14 }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
                      lineNumber: 378,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:379:26", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "379", "data-component-file": "CustomFields.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Add%20Option%22%7D", children: "Add Option" }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
                      lineNumber: 379,
                      columnNumber: 27
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
                  lineNumber: 373,
                  columnNumber: 25
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
              lineNumber: 352,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
            lineNumber: 350,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:385:18", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "385", "data-component-file": "CustomFields.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20justify-end%20space-x-3%20mt-6%22%7D", className: "flex justify-end space-x-3 mt-6", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:386:20",
                "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx",
                "data-component-line": "386",
                "data-component-file": "CustomFields.jsx",
                "data-component-name": "button",
                "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22button%22%2C%22className%22%3A%22px-4%20py-2%20text-text-secondary%20hover%3Atext-text-primary%20transition-colors%20duration-150%22%2C%22textContent%22%3A%22Cancel%22%7D",
                type: "button",
                onClick: () => setShowFieldModal(false),
                className: "px-4 py-2 text-text-secondary hover:text-text-primary transition-colors duration-150",
                children: "Cancel"
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
                lineNumber: 386,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:393:20",
                "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx",
                "data-component-line": "393",
                "data-component-file": "CustomFields.jsx",
                "data-component-name": "button",
                "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22submit%22%2C%22className%22%3A%22bg-primary%20text-white%20px-4%20py-2%20rounded-lg%20hover%3Abg-primary-600%20transition-colors%20duration-150%20ease-smooth%22%7D",
                type: "submit",
                className: "bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary-600 transition-colors duration-150 ease-smooth",
                children: editingField ? "Update Field" : "Create Field"
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
                lineNumber: 393,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
            lineNumber: 385,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
          lineNumber: 277,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
        lineNumber: 264,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
        lineNumber: 263,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
      lineNumber: 261,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
      lineNumber: 260,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:407:6", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "407", "data-component-file": "CustomFields.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-background%20border%20border-border%20rounded-lg%20p-4%22%7D", className: "bg-background border border-border rounded-lg p-4", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:408:8", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "408", "data-component-file": "CustomFields.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-start%20space-x-3%22%7D", className: "flex items-start space-x-3", children: [
      /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:409:10", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "409", "data-component-file": "CustomFields.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Info%22%2C%22className%22%3A%22text-primary%20mt-0.5%22%7D", name: "Info", size: 16, className: "text-primary mt-0.5" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
        lineNumber: 409,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:410:10", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "410", "data-component-file": "CustomFields.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex-1%22%7D", className: "flex-1", children: [
        /* @__PURE__ */ jsxDEV("h4", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:411:12", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "411", "data-component-file": "CustomFields.jsx", "data-component-name": "h4", "data-component-content": "%7B%22elementName%22%3A%22h4%22%2C%22className%22%3A%22font-medium%20text-text-primary%20text-sm%22%2C%22textContent%22%3A%22Custom%20Field%20Guidelines%22%7D", className: "font-medium text-text-primary text-sm", children: "Custom Field Guidelines" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
          lineNumber: 411,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\settings-administration\\components\\CustomFields.jsx:412:12", "data-component-path": "src\\pages\\settings-administration\\components\\CustomFields.jsx", "data-component-line": "412", "data-component-file": "CustomFields.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20text-sm%20mt-1%22%2C%22textContent%22%3A%22Custom%20fields%20appear%20in%20forms%20and%20detail%20views%20based%20on%20their%20placement%20configuration.%20%5Cn%20%20%20%20%20%20%20%20%20%20%20%20%20%20Required%20fields%20must%20be%20filled%20before%20saving.%20Field%20changes%20may%20require%20cache%20refresh.%22%7D", className: "text-text-secondary text-sm mt-1", children: "Custom fields appear in forms and detail views based on their placement configuration. Required fields must be filled before saving. Field changes may require cache refresh." }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
          lineNumber: 412,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
        lineNumber: 410,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
      lineNumber: 408,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
      lineNumber: 407,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx",
    lineNumber: 184,
    columnNumber: 5
  }, this);
};
_s(CustomFields, "sJdkkIZeYdrEOrYXzfVlpB/rHQA=");
_c = CustomFields;
export default CustomFields;
var _c;
$RefreshReg$(_c, "CustomFields");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/settings-administration/components/CustomFields.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0xNOzJCQWhMTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBLE9BQU9BLFNBQVNDLGdCQUFnQjtBQUNoQyxPQUFPQyxVQUFVO0FBRWpCLE1BQU1DLGVBQWVBLE1BQU07QUFBQUMsS0FBQTtBQUN6QixRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSUw7QUFBQUEsSUFBUztBQUFBLE1BQ25DO0FBQUEsUUFDRU0sSUFBSTtBQUFBLFFBQ0pDLE1BQU07QUFBQSxRQUNOQyxNQUFNO0FBQUEsUUFDTkMsUUFBUTtBQUFBLFFBQ1JDLFVBQVU7QUFBQSxRQUNWQyxTQUFTLENBQUMsV0FBVyxnQkFBZ0IsWUFBWSxXQUFXO0FBQUEsUUFDNURDLFdBQVc7QUFBQSxRQUNYQyxXQUFXO0FBQUEsTUFDYjtBQUFBLE1BQ0E7QUFBQSxRQUNFUCxJQUFJO0FBQUEsUUFDSkMsTUFBTTtBQUFBLFFBQ05DLE1BQU07QUFBQSxRQUNOQyxRQUFRO0FBQUEsUUFDUkMsVUFBVTtBQUFBLFFBQ1ZJLFlBQVksRUFBRUMsS0FBSyxHQUFHQyxLQUFLLFVBQVU7QUFBQSxRQUNyQ0osV0FBVztBQUFBLFFBQ1hDLFdBQVc7QUFBQSxNQUNiO0FBQUEsTUFDQTtBQUFBLFFBQ0VQLElBQUk7QUFBQSxRQUNKQyxNQUFNO0FBQUEsUUFDTkMsTUFBTTtBQUFBLFFBQ05DLFFBQVE7QUFBQSxRQUNSQyxVQUFVO0FBQUEsUUFDVkMsU0FBUyxDQUFDLE9BQU8sVUFBVSxRQUFRLFVBQVU7QUFBQSxRQUM3Q0MsV0FBVztBQUFBLFFBQ1hDLFdBQVc7QUFBQSxNQUNiO0FBQUEsSUFBQztBQUFBLEVBQ0Y7QUFFRCxRQUFNLENBQUNJLGdCQUFnQkMsaUJBQWlCLElBQUlsQixTQUFTLEtBQUs7QUFDMUQsUUFBTSxDQUFDbUIsY0FBY0MsZUFBZSxJQUFJcEIsU0FBUyxJQUFJO0FBQ3JELFFBQU0sQ0FBQ3FCLFdBQVdDLFlBQVksSUFBSXRCLFNBQVM7QUFBQSxJQUN6Q08sTUFBTTtBQUFBLElBQ05DLE1BQU07QUFBQSxJQUNOQyxRQUFRO0FBQUEsSUFDUkMsVUFBVTtBQUFBLElBQ1ZDLFNBQVMsQ0FBQyxFQUFFO0FBQUEsSUFDWkcsWUFBWSxDQUFDO0FBQUEsSUFDYkYsV0FBVztBQUFBLEVBQ2IsQ0FBQztBQUVELFFBQU1XLGFBQWE7QUFBQSxJQUNqQixFQUFFQyxPQUFPLFFBQVFDLE9BQU8sUUFBUUMsTUFBTSxPQUFPO0FBQUEsSUFDN0MsRUFBRUYsT0FBTyxZQUFZQyxPQUFPLGFBQWFDLE1BQU0sWUFBWTtBQUFBLElBQzNELEVBQUVGLE9BQU8sVUFBVUMsT0FBTyxVQUFVQyxNQUFNLE9BQU87QUFBQSxJQUNqRCxFQUFFRixPQUFPLFNBQVNDLE9BQU8sU0FBU0MsTUFBTSxPQUFPO0FBQUEsSUFDL0MsRUFBRUYsT0FBTyxTQUFTQyxPQUFPLFNBQVNDLE1BQU0sUUFBUTtBQUFBLElBQ2hELEVBQUVGLE9BQU8sT0FBT0MsT0FBTyxPQUFPQyxNQUFNLE9BQU87QUFBQSxJQUMzQyxFQUFFRixPQUFPLFFBQVFDLE9BQU8sUUFBUUMsTUFBTSxXQUFXO0FBQUEsSUFDakQsRUFBRUYsT0FBTyxVQUFVQyxPQUFPLFlBQVlDLE1BQU0sY0FBYztBQUFBLElBQzFELEVBQUVGLE9BQU8sWUFBWUMsT0FBTyxZQUFZQyxNQUFNLFFBQVE7QUFBQSxJQUN0RCxFQUFFRixPQUFPLFNBQVNDLE9BQU8sZ0JBQWdCQyxNQUFNLFNBQVM7QUFBQSxFQUFDO0FBRzNELFFBQU1DLFdBQVc7QUFBQSxJQUNmLEVBQUVILE9BQU8sV0FBV0MsT0FBTyxVQUFVO0FBQUEsSUFDckMsRUFBRUQsT0FBTyxRQUFRQyxPQUFPLE9BQU87QUFBQSxJQUMvQixFQUFFRCxPQUFPLFlBQVlDLE9BQU8sV0FBVztBQUFBLEVBQUM7QUFHMUMsUUFBTUcsYUFBYTtBQUFBLElBQ2pCQyxTQUFTO0FBQUEsTUFDUCxFQUFFTCxPQUFPLGdCQUFnQkMsT0FBTyxlQUFlO0FBQUEsTUFDL0MsRUFBRUQsT0FBTyxrQkFBa0JDLE9BQU8sc0JBQXNCO0FBQUEsTUFDeEQsRUFBRUQsT0FBTyxnQkFBZ0JDLE9BQU8sZUFBZTtBQUFBLElBQUM7QUFBQSxJQUVsREssTUFBTTtBQUFBLE1BQ0osRUFBRU4sT0FBTyxhQUFhQyxPQUFPLFlBQVk7QUFBQSxNQUN6QyxFQUFFRCxPQUFPLGVBQWVDLE9BQU8sbUJBQW1CO0FBQUEsTUFDbEQsRUFBRUQsT0FBTyxpQkFBaUJDLE9BQU8sZ0JBQWdCO0FBQUEsSUFBQztBQUFBLElBRXBETSxVQUFVO0FBQUEsTUFDUixFQUFFUCxPQUFPLGlCQUFpQkMsT0FBTyxnQkFBZ0I7QUFBQSxNQUNqRCxFQUFFRCxPQUFPLG1CQUFtQkMsT0FBTyx1QkFBdUI7QUFBQSxJQUFDO0FBQUEsRUFFL0Q7QUFFQSxRQUFNTyxvQkFBb0JBLE1BQU07QUFDOUJaLG9CQUFnQixJQUFJO0FBQ3BCRSxpQkFBYTtBQUFBLE1BQ1hmLE1BQU07QUFBQSxNQUNOQyxNQUFNO0FBQUEsTUFDTkMsUUFBUTtBQUFBLE1BQ1JDLFVBQVU7QUFBQSxNQUNWQyxTQUFTLENBQUMsRUFBRTtBQUFBLE1BQ1pHLFlBQVksQ0FBQztBQUFBLE1BQ2JGLFdBQVc7QUFBQSxJQUNiLENBQUM7QUFDRE0sc0JBQWtCLElBQUk7QUFBQSxFQUN4QjtBQUVBLFFBQU1lLGtCQUFrQkEsQ0FBQ0MsVUFBVTtBQUNqQ2Qsb0JBQWdCYyxLQUFLO0FBQ3JCWixpQkFBYTtBQUFBLE1BQ1hmLE1BQU0yQixPQUFPM0I7QUFBQUEsTUFDYkMsTUFBTTBCLE9BQU8xQjtBQUFBQSxNQUNiQyxRQUFReUIsT0FBT3pCO0FBQUFBLE1BQ2ZDLFVBQVV3QixPQUFPeEI7QUFBQUEsTUFDakJDLFNBQVN1QixPQUFPdkIsV0FBVyxDQUFDLEVBQUU7QUFBQSxNQUM5QkcsWUFBWW9CLE9BQU9wQixjQUFjLENBQUM7QUFBQSxNQUNsQ0YsV0FBV3NCLE9BQU90QjtBQUFBQSxJQUNwQixDQUFDO0FBQ0RNLHNCQUFrQixJQUFJO0FBQUEsRUFDeEI7QUFFQSxRQUFNaUIsb0JBQW9CQSxDQUFDQyxZQUFZO0FBQ3JDL0IsY0FBVSxDQUFBZ0MsU0FBUUEsTUFBTUMsT0FBTyxDQUFBSixVQUFTQSxPQUFPNUIsT0FBTzhCLE9BQU8sQ0FBQztBQUFBLEVBQ2hFO0FBRUEsUUFBTUcsa0JBQWtCQSxDQUFDQyxNQUFNO0FBQzdCQSxPQUFHQyxlQUFlO0FBRWxCLFFBQUl0QixjQUFjO0FBQ2hCZDtBQUFBQSxRQUFVLENBQUFnQyxTQUNSQSxNQUFNSztBQUFBQSxVQUFJLENBQUFSLFVBQ1JBLE9BQU81QixPQUFPYSxjQUFjYixLQUN4QixFQUFFLEdBQUc0QixPQUFPLEdBQUdiLFVBQVUsSUFDekJhO0FBQUFBLFFBQ047QUFBQSxNQUNGO0FBQUEsSUFDRixPQUFPO0FBQ0wsWUFBTVMsV0FBVztBQUFBLFFBQ2ZyQyxJQUFJc0MsS0FBS0MsSUFBSTtBQUFBLFFBQ2IsR0FBR3hCO0FBQUFBLFFBQ0hSLFlBQVcsb0JBQUkrQixLQUFLLElBQUdFLFlBQVksR0FBR0MsTUFBTSxHQUFHLElBQUksQ0FBQztBQUFBLE1BQ3REO0FBQ0ExQyxnQkFBVSxDQUFBZ0MsU0FBUSxDQUFDLEdBQUdBLE1BQU1NLFFBQVEsQ0FBQztBQUFBLElBQ3ZDO0FBRUF6QixzQkFBa0IsS0FBSztBQUN2QkUsb0JBQWdCLElBQUk7QUFBQSxFQUN0QjtBQUVBLFFBQU00QixZQUFZQSxNQUFNO0FBQ3RCMUIsaUJBQWEsQ0FBQWUsVUFBUztBQUFBLE1BQ3BCLEdBQUdBO0FBQUFBLE1BQ0gxQixTQUFTLENBQUMsR0FBRzBCLE1BQU0xQixTQUFTLEVBQUU7QUFBQSxJQUNoQyxFQUFFO0FBQUEsRUFDSjtBQUVBLFFBQU1zQyxlQUFlQSxDQUFDQyxPQUFPMUIsVUFBVTtBQUNyQ0YsaUJBQWEsQ0FBQWUsVUFBUztBQUFBLE1BQ3BCLEdBQUdBO0FBQUFBLE1BQ0gxQixTQUFTMEIsTUFBTTFCLFNBQVMrQixJQUFJLENBQUNTLFFBQVFDLE1BQU1BLE1BQU1GLFFBQVExQixRQUFRMkIsTUFBTTtBQUFBLElBQ3pFLEVBQUU7QUFBQSxFQUNKO0FBRUEsUUFBTUUsZUFBZUEsQ0FBQ0gsVUFBVTtBQUM5QjVCLGlCQUFhLENBQUFlLFVBQVM7QUFBQSxNQUNwQixHQUFHQTtBQUFBQSxNQUNIMUIsU0FBUzBCLE1BQU0xQixTQUFTMkIsT0FBTyxDQUFDZ0IsR0FBR0YsTUFBTUEsTUFBTUYsS0FBSztBQUFBLElBQ3RELEVBQUU7QUFBQSxFQUNKO0FBRUEsUUFBTUssY0FBY0EsQ0FBQy9DLFNBQVM7QUFDNUIsVUFBTWdELFlBQVlqQyxZQUFZa0MsS0FBSyxDQUFBQyxPQUFNQSxJQUFJbEMsVUFBVWhCLElBQUk7QUFDM0QsV0FBT2dELFdBQVc5QixRQUFRO0FBQUEsRUFDNUI7QUFFQSxRQUFNaUMsaUJBQWlCQSxDQUFDbEQsV0FBVztBQUNqQyxVQUFNbUQsU0FBUztBQUFBLE1BQ2IvQixTQUFTO0FBQUEsTUFDVEMsTUFBTTtBQUFBLE1BQ05DLFVBQVU7QUFBQSxJQUNaO0FBRUEsV0FDRSx1QkFBQyxnWEFBSyxXQUFXLGdEQUFnRDZCLFNBQVNuRCxNQUFNLEtBQUssMENBQTBDLElBQzVIQSxrQkFBUW9ELE9BQU8sQ0FBQyxHQUFHQyxZQUFZLElBQUlyRCxRQUFRc0QsTUFBTSxDQUFDLEtBRHJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFFQSxTQUNFLHVCQUFDLGlaQUFJLFdBQVUsYUFFYjtBQUFBLDJCQUFDLDZhQUFJLFdBQVUscUNBQ2I7QUFBQSw2QkFBQyw2V0FDQztBQUFBLCtCQUFDLDBkQUFHLFdBQVUsd0NBQXVDLDZCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtFO0FBQUEsUUFDbEUsdUJBQUMscWZBQUUsV0FBVSw0QkFBMkIsNkRBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUY7QUFBQSxXQUZ2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFDQyxTQUFTL0I7QUFBQUEsVUFDVCxXQUFVO0FBQUEsVUFFVjtBQUFBLG1DQUFDLHlZQUFLLE1BQUssUUFBTyxNQUFNLE1BQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJCO0FBQUEsWUFDM0IsdUJBQUMsNFpBQUssNEJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0I7QUFBQTtBQUFBO0FBQUEsUUFMcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUE7QUFBQSxTQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQTtBQUFBLElBRUEsdUJBQUMsMGNBQUksV0FBVSw4REFDYixpQ0FBQyx1WkFBSSxXQUFVLG1CQUNiLGlDQUFDLHFaQUFNLFdBQVUsVUFDZjtBQUFBLDZCQUFDLHViQUFNLFdBQVUsd0NBQ2YsaUNBQUMsMldBQ0M7QUFBQSwrQkFBQyxrZkFBRyxXQUFVLDZEQUE0RCwwQkFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRjtBQUFBLFFBQ3BGLHVCQUFDLDBlQUFHLFdBQVUsNkRBQTRELG9CQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThFO0FBQUEsUUFDOUUsdUJBQUMsNGVBQUcsV0FBVSw2REFBNEQsc0JBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0Y7QUFBQSxRQUNoRix1QkFBQyw4ZUFBRyxXQUFVLDZEQUE0RCx3QkFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRjtBQUFBLFFBQ2xGLHVCQUFDLCtlQUFHLFdBQVUsNkRBQTRELHlCQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1GO0FBQUEsUUFDbkYsdUJBQUMsNmVBQUcsV0FBVSw2REFBNEQsdUJBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUY7QUFBQSxRQUNqRix1QkFBQyw2ZUFBRyxXQUFVLDZEQUE0RCx1QkFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRjtBQUFBLFdBUG5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLE1BQ0EsdUJBQUMsb1hBQ0U1QixrQkFBUXNDO0FBQUFBLFFBQUksQ0FBQ1IsVUFDWix1QkFBQyx5YkFBbUIsV0FBVSxpREFDNUI7QUFBQSxpQ0FBQyxpWkFBRyxXQUFVLGFBQ1osaUNBQUMsd2FBQUksV0FBVSwrQkFDYjtBQUFBLG1DQUFDLDRaQUFLLE1BQU1xQixZQUFZckIsT0FBTzFCLElBQUksR0FBRyxNQUFNLElBQUksV0FBVSx3QkFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEU7QUFBQSxZQUM5RSx1QkFBQywyYUFBSyxXQUFVLGlDQUFpQzBCLGlCQUFPM0IsUUFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkQ7QUFBQSxlQUYvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBQ0EsdUJBQUMsOGJBQUcsV0FBVSxvREFBb0QyQixpQkFBTzFCLFFBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThFO0FBQUEsVUFDOUUsdUJBQUMsaVpBQUcsV0FBVSxhQUFhbUQseUJBQWV6QixPQUFPekIsTUFBTSxLQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RDtBQUFBLFVBQ3pELHVCQUFDLGlaQUFHLFdBQVUsYUFDWHlCLGlCQUFPeEIsV0FDTix1QkFBQyxpYkFBSyxNQUFLLFNBQVEsTUFBTSxJQUFJLFdBQVUsa0JBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFELElBRXJELHVCQUFDLG1iQUFLLE1BQUssS0FBSSxNQUFNLElBQUksV0FBVSx3QkFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUQsS0FKM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLFVBQ0EsdUJBQUMsaWJBQUcsV0FBVSx5Q0FDWGtCLHVCQUFhTSxPQUFPekIsTUFBTSxHQUFHZ0QsS0FBSyxDQUFBTyxNQUFLQSxHQUFHeEMsVUFBVVUsT0FBT3RCLFNBQVMsR0FBR2EsU0FBU1MsT0FBT3RCLGFBRDFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLGliQUFHLFdBQVUseUNBQXlDc0IsaUJBQU9yQixhQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RTtBQUFBLFVBQ3hFLHVCQUFDLGlaQUFHLFdBQVUsYUFDWixpQ0FBQyx5WkFBSSxXQUFVLGtCQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFDQyxTQUFTLE1BQU1vQixnQkFBZ0JDLEtBQUs7QUFBQSxnQkFDcEMsV0FBVTtBQUFBLGdCQUVWLGlDQUFDLDBZQUFLLE1BQUssU0FBUSxNQUFNLE1BQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTRCO0FBQUE7QUFBQSxjQUo5QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFDQyxTQUFTLE1BQU1DLGtCQUFrQkQsT0FBTzVCLEVBQUU7QUFBQSxnQkFDMUMsV0FBVTtBQUFBLGdCQUVWLGlDQUFDLDJZQUFLLE1BQUssVUFBUyxNQUFNLE1BQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZCO0FBQUE7QUFBQSxjQUovQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLGVBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFhQSxLQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZUE7QUFBQSxhQW5DTzRCLE9BQU81QixJQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0NBO0FBQUEsTUFDRCxLQXZDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0NBO0FBQUEsU0FwREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFEQSxLQXRERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdURBLEtBeERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5REE7QUFBQSxJQUVDVyxrQkFDQyx1QkFBQyxrYkFBSSxXQUFVLHdDQUNiLGlDQUFDLG1jQUFJLFdBQVUsc0RBQ2I7QUFBQSw2QkFBQyxtYkFBSSxXQUFVLHdDQUF1QyxTQUFTLE1BQU1DLGtCQUFrQixLQUFLLEtBQTVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0Y7QUFBQSxNQUMvRix1QkFBQyxzZkFBSSxXQUFVLGlHQUNiLGlDQUFDLDRZQUFJLFdBQVUsT0FDYjtBQUFBLCtCQUFDLHFiQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxpYkFBRyxXQUFVLDJDQUNYQyx5QkFBZSxlQUFlLHNCQURqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNRCxrQkFBa0IsS0FBSztBQUFBLGNBQ3RDLFdBQVU7QUFBQSxjQUVWLGlDQUFDLHNZQUFLLE1BQUssS0FBSSxNQUFNLE1BQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdCO0FBQUE7QUFBQSxZQUoxQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLGFBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsUUFFQSx1QkFBQyxxWkFBSyxVQUFVcUIsaUJBQWlCLFdBQVUsYUFDekM7QUFBQSxpQ0FBQyxzYkFBSSxXQUFVLHlDQUNiO0FBQUEsbUNBQUMsOFdBQ0M7QUFBQSxxQ0FBQyxnZkFBTSxXQUFVLG9EQUFtRCwwQkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEU7QUFBQSxjQUM5RTtBQUFBLGdCQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsT0FBT2xCLFdBQVdkO0FBQUFBLGtCQUNsQixVQUFVLENBQUNpQyxNQUFNbEIsYUFBYSxDQUFBZSxVQUFTLEVBQUUsR0FBR0EsTUFBTTlCLE1BQU1pQyxHQUFHeUIsUUFBUXpDLE1BQU0sRUFBRTtBQUFBLGtCQUMzRSxXQUFVO0FBQUEsa0JBQ1YsYUFBWTtBQUFBLGtCQUNaLFVBQVE7QUFBQTtBQUFBLGdCQU5WO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1VO0FBQUEsaUJBUlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLFlBRUEsdUJBQUMsOFdBQ0M7QUFBQSxxQ0FBQyxnZkFBTSxXQUFVLG9EQUFtRCwwQkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEU7QUFBQSxjQUM5RTtBQUFBLGdCQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFDQyxPQUFPSCxXQUFXYjtBQUFBQSxrQkFDbEIsVUFBVSxDQUFDZ0MsTUFBTWxCLGFBQWEsQ0FBQWUsVUFBUyxFQUFFLEdBQUdBLE1BQU03QixNQUFNZ0MsR0FBR3lCLFFBQVF6QyxNQUFNLEVBQUU7QUFBQSxrQkFDM0UsV0FBVTtBQUFBLGtCQUVURCxzQkFBWW1CO0FBQUFBLG9CQUFJLENBQUFsQyxTQUNmLHVCQUFDLHVYQUF5QixPQUFPQSxNQUFNZ0IsT0FBUWhCLGdCQUFNaUIsU0FBeENqQixNQUFNZ0IsT0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBMkQ7QUFBQSxrQkFDNUQ7QUFBQTtBQUFBLGdCQVBIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVFBO0FBQUEsaUJBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFXQTtBQUFBLGVBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeUJBO0FBQUEsVUFFQSx1QkFBQyxzYkFBSSxXQUFVLHlDQUNiO0FBQUEsbUNBQUMsOFdBQ0M7QUFBQSxxQ0FBQyw4ZUFBTSxXQUFVLG9EQUFtRCx3QkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEU7QUFBQSxjQUM1RTtBQUFBLGdCQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFDQyxPQUFPSCxXQUFXWjtBQUFBQSxrQkFDbEIsVUFBVSxDQUFDK0IsTUFBTWxCLGFBQWEsQ0FBQWUsVUFBUztBQUFBLG9CQUNyQyxHQUFHQTtBQUFBQSxvQkFDSDVCLFFBQVErQixHQUFHeUIsUUFBUXpDO0FBQUFBLG9CQUNuQlosV0FBV2dCLGFBQWFZLEdBQUd5QixRQUFRekMsS0FBSyxJQUFJLENBQUMsR0FBR0EsU0FBUztBQUFBLGtCQUMzRCxFQUFFO0FBQUEsa0JBQ0YsV0FBVTtBQUFBLGtCQUVURyxvQkFBVWU7QUFBQUEsb0JBQUksQ0FBQWpDLFdBQ2IsdUJBQUMsdVhBQTJCLE9BQU9BLFFBQVFlLE9BQVFmLGtCQUFRZ0IsU0FBOUNoQixRQUFRZSxPQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpRTtBQUFBLGtCQUNsRTtBQUFBO0FBQUEsZ0JBWEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBWUE7QUFBQSxpQkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWVBO0FBQUEsWUFFQSx1QkFBQyw4V0FDQztBQUFBLHFDQUFDLDZlQUFNLFdBQVUsb0RBQW1ELHlCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2RTtBQUFBLGNBQzdFO0FBQUEsZ0JBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUNDLE9BQU9ILFdBQVdUO0FBQUFBLGtCQUNsQixVQUFVLENBQUM0QixNQUFNbEIsYUFBYSxDQUFBZSxVQUFTLEVBQUUsR0FBR0EsTUFBTXpCLFdBQVc0QixHQUFHeUIsUUFBUXpDLE1BQU0sRUFBRTtBQUFBLGtCQUNoRixXQUFVO0FBQUEsa0JBRVRJLHVCQUFhUCxXQUFXWixNQUFNLEdBQUdpQztBQUFBQSxvQkFBSSxDQUFBOUIsY0FDcEMsdUJBQUMsdVhBQThCLE9BQU9BLFdBQVdZLE9BQVFaLHFCQUFXYSxTQUF2RGIsV0FBV1ksT0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBMEU7QUFBQSxrQkFDM0U7QUFBQTtBQUFBLGdCQVBIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVFBO0FBQUEsaUJBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFXQTtBQUFBLGVBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBOEJBO0FBQUEsVUFFQSx1QkFBQyw4V0FDQyxpQ0FBQyw4YUFBTSxXQUFVLCtCQUNmO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBU0gsV0FBV1g7QUFBQUEsZ0JBQ3BCLFVBQVUsQ0FBQzhCLE1BQU1sQixhQUFhLENBQUFlLFVBQVMsRUFBRSxHQUFHQSxNQUFNM0IsVUFBVThCLEdBQUd5QixRQUFRQyxRQUFRLEVBQUU7QUFBQSxnQkFDakYsV0FBVTtBQUFBO0FBQUEsY0FKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJbUU7QUFBQSxZQUVuRSx1QkFBQyxvZEFBSyxXQUFVLDZCQUE0Qiw4QkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEQ7QUFBQSxlQVA1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFdBRUU3QyxXQUFXYixTQUFTLFlBQVlhLFdBQVdiLFNBQVMsWUFDcEQsdUJBQUMsOFdBQ0M7QUFBQSxtQ0FBQywyZUFBTSxXQUFVLG9EQUFtRCx1QkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkU7QUFBQSxZQUMzRSx1QkFBQyxrWkFBSSxXQUFVLGFBQ1phO0FBQUFBLHlCQUFXVixTQUFTK0I7QUFBQUEsZ0JBQUksQ0FBQ1MsUUFBUUQsVUFDaEMsdUJBQUMsd2FBQWdCLFdBQVUsK0JBQ3pCO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLE9BQU9DO0FBQUFBLHNCQUNQLFVBQVUsQ0FBQ1gsTUFBTVMsYUFBYUMsT0FBT1YsR0FBR3lCLFFBQVF6QyxLQUFLO0FBQUEsc0JBQ3JELFdBQVU7QUFBQSxzQkFDVixhQUFhLFVBQVUwQixRQUFRLENBQUM7QUFBQTtBQUFBLG9CQUxsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS3FDO0FBQUEsa0JBRXBDN0IsV0FBV1YsU0FBU3dELFNBQVMsS0FDNUI7QUFBQSxvQkFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFNBQVMsTUFBTWQsYUFBYUgsS0FBSztBQUFBLHNCQUNqQyxXQUFVO0FBQUEsc0JBRVYsaUNBQUMsc1lBQUssTUFBSyxLQUFJLE1BQU0sTUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBd0I7QUFBQTtBQUFBLG9CQUwxQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBTUE7QUFBQSxxQkFmTUEsT0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWlCQTtBQUFBLGNBQ0Q7QUFBQSxjQUNEO0FBQUEsZ0JBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxTQUFTRjtBQUFBQSxrQkFDVCxXQUFVO0FBQUEsa0JBRVY7QUFBQSwyQ0FBQyx5WUFBSyxNQUFLLFFBQU8sTUFBTSxNQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUEyQjtBQUFBLG9CQUMzQix1QkFBQywwWkFBSywwQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnQjtBQUFBO0FBQUE7QUFBQSxnQkFObEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBT0E7QUFBQSxpQkE1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE2QkE7QUFBQSxlQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdDQTtBQUFBLFVBR0YsdUJBQUMsOGFBQUksV0FBVSxtQ0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVMsTUFBTTlCLGtCQUFrQixLQUFLO0FBQUEsZ0JBQ3RDLFdBQVU7QUFBQSxnQkFBc0Y7QUFBQTtBQUFBLGNBSGxHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUEsZ0JBRVRDLHlCQUFlLGlCQUFpQjtBQUFBO0FBQUEsY0FKbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxlQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBY0E7QUFBQSxhQTFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMkhBO0FBQUEsV0F4SUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlJQSxLQTFJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMklBO0FBQUEsU0E3SUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThJQSxLQS9JRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0pBO0FBQUEsSUFHRix1QkFBQyxpY0FBSSxXQUFVLHFEQUNiLGlDQUFDLHNhQUFJLFdBQVUsOEJBQ2I7QUFBQSw2QkFBQyx5YkFBSyxNQUFLLFFBQU8sTUFBTSxJQUFJLFdBQVUseUJBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkQ7QUFBQSxNQUMzRCx1QkFBQywrWUFBSSxXQUFVLFVBQ2I7QUFBQSwrQkFBQyx1ZUFBRyxXQUFVLHlDQUF3Qyx1Q0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2RTtBQUFBLFFBQzdFLHVCQUFDLGl0QkFBRSxXQUFVLG9DQUFtQyw2TEFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUE7QUFBQSxTQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQSxLQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FXQTtBQUFBLE9BMU9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EyT0E7QUFFSjtBQUFFaEIsR0FoYUlELGNBQVk7QUFBQWtFLEtBQVpsRTtBQWthTixlQUFlQTtBQUFhLElBQUFrRTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJ1c2VTdGF0ZSIsIkljb24iLCJDdXN0b21GaWVsZHMiLCJfcyIsImZpZWxkcyIsInNldEZpZWxkcyIsImlkIiwibmFtZSIsInR5cGUiLCJlbnRpdHkiLCJyZXF1aXJlZCIsIm9wdGlvbnMiLCJwbGFjZW1lbnQiLCJjcmVhdGVkQXQiLCJ2YWxpZGF0aW9uIiwibWluIiwibWF4Iiwic2hvd0ZpZWxkTW9kYWwiLCJzZXRTaG93RmllbGRNb2RhbCIsImVkaXRpbmdGaWVsZCIsInNldEVkaXRpbmdGaWVsZCIsImZpZWxkRm9ybSIsInNldEZpZWxkRm9ybSIsImZpZWxkVHlwZXMiLCJ2YWx1ZSIsImxhYmVsIiwiaWNvbiIsImVudGl0aWVzIiwicGxhY2VtZW50cyIsImNvbnRhY3QiLCJkZWFsIiwiYWN0aXZpdHkiLCJoYW5kbGVDcmVhdGVGaWVsZCIsImhhbmRsZUVkaXRGaWVsZCIsImZpZWxkIiwiaGFuZGxlRGVsZXRlRmllbGQiLCJmaWVsZElkIiwicHJldiIsImZpbHRlciIsImhhbmRsZVNhdmVGaWVsZCIsImUiLCJwcmV2ZW50RGVmYXVsdCIsIm1hcCIsIm5ld0ZpZWxkIiwiRGF0ZSIsIm5vdyIsInRvSVNPU3RyaW5nIiwic3BsaXQiLCJhZGRPcHRpb24iLCJ1cGRhdGVPcHRpb24iLCJpbmRleCIsIm9wdGlvbiIsImkiLCJyZW1vdmVPcHRpb24iLCJfIiwiZ2V0VHlwZUljb24iLCJmaWVsZFR5cGUiLCJmaW5kIiwiZnQiLCJnZXRFbnRpdHlCYWRnZSIsImNvbG9ycyIsImNoYXJBdCIsInRvVXBwZXJDYXNlIiwic2xpY2UiLCJwIiwidGFyZ2V0IiwiY2hlY2tlZCIsImxlbmd0aCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ3VzdG9tRmllbGRzLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBzcmMvcGFnZXMvc2V0dGluZ3MtYWRtaW5pc3RyYXRpb24vY29tcG9uZW50cy9DdXN0b21GaWVsZHMuanN4XHJcbmltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IEljb24gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9BcHBJY29uJztcclxuXHJcbmNvbnN0IEN1c3RvbUZpZWxkcyA9ICgpID0+IHtcclxuICBjb25zdCBbZmllbGRzLCBzZXRGaWVsZHNdID0gdXNlU3RhdGUoW1xyXG4gICAge1xyXG4gICAgICBpZDogMSxcclxuICAgICAgbmFtZTogJ0xlYWQgU291cmNlJyxcclxuICAgICAgdHlwZTogJ3NlbGVjdCcsXHJcbiAgICAgIGVudGl0eTogJ2NvbnRhY3QnLFxyXG4gICAgICByZXF1aXJlZDogdHJ1ZSxcclxuICAgICAgb3B0aW9uczogWydXZWJzaXRlJywgJ1NvY2lhbCBNZWRpYScsICdSZWZlcnJhbCcsICdDb2xkIENhbGwnXSxcclxuICAgICAgcGxhY2VtZW50OiAnY29udGFjdF9mb3JtJyxcclxuICAgICAgY3JlYXRlZEF0OiAnMjAyNC0wMS0xMCdcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGlkOiAyLFxyXG4gICAgICBuYW1lOiAnQW5udWFsIFJldmVudWUnLFxyXG4gICAgICB0eXBlOiAnbnVtYmVyJyxcclxuICAgICAgZW50aXR5OiAnY29udGFjdCcsXHJcbiAgICAgIHJlcXVpcmVkOiBmYWxzZSxcclxuICAgICAgdmFsaWRhdGlvbjogeyBtaW46IDAsIG1heDogOTk5OTk5OTk5IH0sXHJcbiAgICAgIHBsYWNlbWVudDogJ2NvbnRhY3RfZGV0YWlsJyxcclxuICAgICAgY3JlYXRlZEF0OiAnMjAyNC0wMS0wOCdcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGlkOiAzLFxyXG4gICAgICBuYW1lOiAnRGVhbCBQcmlvcml0eScsXHJcbiAgICAgIHR5cGU6ICdzZWxlY3QnLFxyXG4gICAgICBlbnRpdHk6ICdkZWFsJyxcclxuICAgICAgcmVxdWlyZWQ6IHRydWUsXHJcbiAgICAgIG9wdGlvbnM6IFsnTG93JywgJ01lZGl1bScsICdIaWdoJywgJ0NyaXRpY2FsJ10sXHJcbiAgICAgIHBsYWNlbWVudDogJ2RlYWxfZm9ybScsXHJcbiAgICAgIGNyZWF0ZWRBdDogJzIwMjQtMDEtMDUnXHJcbiAgICB9XHJcbiAgXSk7XHJcblxyXG4gIGNvbnN0IFtzaG93RmllbGRNb2RhbCwgc2V0U2hvd0ZpZWxkTW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtlZGl0aW5nRmllbGQsIHNldEVkaXRpbmdGaWVsZF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbZmllbGRGb3JtLCBzZXRGaWVsZEZvcm1dID0gdXNlU3RhdGUoe1xyXG4gICAgbmFtZTogJycsXHJcbiAgICB0eXBlOiAndGV4dCcsXHJcbiAgICBlbnRpdHk6ICdjb250YWN0JyxcclxuICAgIHJlcXVpcmVkOiBmYWxzZSxcclxuICAgIG9wdGlvbnM6IFsnJ10sXHJcbiAgICB2YWxpZGF0aW9uOiB7fSxcclxuICAgIHBsYWNlbWVudDogJ2NvbnRhY3RfZm9ybSdcclxuICB9KTtcclxuXHJcbiAgY29uc3QgZmllbGRUeXBlcyA9IFtcclxuICAgIHsgdmFsdWU6ICd0ZXh0JywgbGFiZWw6ICdUZXh0JywgaWNvbjogJ1R5cGUnIH0sXHJcbiAgICB7IHZhbHVlOiAndGV4dGFyZWEnLCBsYWJlbDogJ0xvbmcgVGV4dCcsIGljb246ICdBbGlnbkxlZnQnIH0sXHJcbiAgICB7IHZhbHVlOiAnbnVtYmVyJywgbGFiZWw6ICdOdW1iZXInLCBpY29uOiAnSGFzaCcgfSxcclxuICAgIHsgdmFsdWU6ICdlbWFpbCcsIGxhYmVsOiAnRW1haWwnLCBpY29uOiAnTWFpbCcgfSxcclxuICAgIHsgdmFsdWU6ICdwaG9uZScsIGxhYmVsOiAnUGhvbmUnLCBpY29uOiAnUGhvbmUnIH0sXHJcbiAgICB7IHZhbHVlOiAndXJsJywgbGFiZWw6ICdVUkwnLCBpY29uOiAnTGluaycgfSxcclxuICAgIHsgdmFsdWU6ICdkYXRlJywgbGFiZWw6ICdEYXRlJywgaWNvbjogJ0NhbGVuZGFyJyB9LFxyXG4gICAgeyB2YWx1ZTogJ3NlbGVjdCcsIGxhYmVsOiAnRHJvcGRvd24nLCBpY29uOiAnQ2hldnJvbkRvd24nIH0sXHJcbiAgICB7IHZhbHVlOiAnY2hlY2tib3gnLCBsYWJlbDogJ0NoZWNrYm94JywgaWNvbjogJ0NoZWNrJyB9LFxyXG4gICAgeyB2YWx1ZTogJ3JhZGlvJywgbGFiZWw6ICdSYWRpbyBCdXR0b24nLCBpY29uOiAnQ2lyY2xlJyB9XHJcbiAgXTtcclxuXHJcbiAgY29uc3QgZW50aXRpZXMgPSBbXHJcbiAgICB7IHZhbHVlOiAnY29udGFjdCcsIGxhYmVsOiAnQ29udGFjdCcgfSxcclxuICAgIHsgdmFsdWU6ICdkZWFsJywgbGFiZWw6ICdEZWFsJyB9LFxyXG4gICAgeyB2YWx1ZTogJ2FjdGl2aXR5JywgbGFiZWw6ICdBY3Rpdml0eScgfVxyXG4gIF07XHJcblxyXG4gIGNvbnN0IHBsYWNlbWVudHMgPSB7XHJcbiAgICBjb250YWN0OiBbXHJcbiAgICAgIHsgdmFsdWU6ICdjb250YWN0X2Zvcm0nLCBsYWJlbDogJ0NvbnRhY3QgRm9ybScgfSxcclxuICAgICAgeyB2YWx1ZTogJ2NvbnRhY3RfZGV0YWlsJywgbGFiZWw6ICdDb250YWN0IERldGFpbCBWaWV3JyB9LFxyXG4gICAgICB7IHZhbHVlOiAnY29udGFjdF9saXN0JywgbGFiZWw6ICdDb250YWN0IExpc3QnIH1cclxuICAgIF0sXHJcbiAgICBkZWFsOiBbXHJcbiAgICAgIHsgdmFsdWU6ICdkZWFsX2Zvcm0nLCBsYWJlbDogJ0RlYWwgRm9ybScgfSxcclxuICAgICAgeyB2YWx1ZTogJ2RlYWxfZGV0YWlsJywgbGFiZWw6ICdEZWFsIERldGFpbCBWaWV3JyB9LFxyXG4gICAgICB7IHZhbHVlOiAncGlwZWxpbmVfY2FyZCcsIGxhYmVsOiAnUGlwZWxpbmUgQ2FyZCcgfVxyXG4gICAgXSxcclxuICAgIGFjdGl2aXR5OiBbXHJcbiAgICAgIHsgdmFsdWU6ICdhY3Rpdml0eV9mb3JtJywgbGFiZWw6ICdBY3Rpdml0eSBGb3JtJyB9LFxyXG4gICAgICB7IHZhbHVlOiAnYWN0aXZpdHlfZGV0YWlsJywgbGFiZWw6ICdBY3Rpdml0eSBEZXRhaWwgVmlldycgfVxyXG4gICAgXVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNyZWF0ZUZpZWxkID0gKCkgPT4ge1xyXG4gICAgc2V0RWRpdGluZ0ZpZWxkKG51bGwpO1xyXG4gICAgc2V0RmllbGRGb3JtKHtcclxuICAgICAgbmFtZTogJycsXHJcbiAgICAgIHR5cGU6ICd0ZXh0JyxcclxuICAgICAgZW50aXR5OiAnY29udGFjdCcsXHJcbiAgICAgIHJlcXVpcmVkOiBmYWxzZSxcclxuICAgICAgb3B0aW9uczogWycnXSxcclxuICAgICAgdmFsaWRhdGlvbjoge30sXHJcbiAgICAgIHBsYWNlbWVudDogJ2NvbnRhY3RfZm9ybSdcclxuICAgIH0pO1xyXG4gICAgc2V0U2hvd0ZpZWxkTW9kYWwodHJ1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRWRpdEZpZWxkID0gKGZpZWxkKSA9PiB7XHJcbiAgICBzZXRFZGl0aW5nRmllbGQoZmllbGQpO1xyXG4gICAgc2V0RmllbGRGb3JtKHtcclxuICAgICAgbmFtZTogZmllbGQ/Lm5hbWUsXHJcbiAgICAgIHR5cGU6IGZpZWxkPy50eXBlLFxyXG4gICAgICBlbnRpdHk6IGZpZWxkPy5lbnRpdHksXHJcbiAgICAgIHJlcXVpcmVkOiBmaWVsZD8ucmVxdWlyZWQsXHJcbiAgICAgIG9wdGlvbnM6IGZpZWxkPy5vcHRpb25zIHx8IFsnJ10sXHJcbiAgICAgIHZhbGlkYXRpb246IGZpZWxkPy52YWxpZGF0aW9uIHx8IHt9LFxyXG4gICAgICBwbGFjZW1lbnQ6IGZpZWxkPy5wbGFjZW1lbnRcclxuICAgIH0pO1xyXG4gICAgc2V0U2hvd0ZpZWxkTW9kYWwodHJ1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlRmllbGQgPSAoZmllbGRJZCkgPT4ge1xyXG4gICAgc2V0RmllbGRzKHByZXYgPT4gcHJldj8uZmlsdGVyKGZpZWxkID0+IGZpZWxkPy5pZCAhPT0gZmllbGRJZCkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVNhdmVGaWVsZCA9IChlKSA9PiB7XHJcbiAgICBlPy5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgXHJcbiAgICBpZiAoZWRpdGluZ0ZpZWxkKSB7XHJcbiAgICAgIHNldEZpZWxkcyhwcmV2ID0+XHJcbiAgICAgICAgcHJldj8ubWFwKGZpZWxkID0+XHJcbiAgICAgICAgICBmaWVsZD8uaWQgPT09IGVkaXRpbmdGaWVsZD8uaWRcclxuICAgICAgICAgICAgPyB7IC4uLmZpZWxkLCAuLi5maWVsZEZvcm0gfVxyXG4gICAgICAgICAgICA6IGZpZWxkXHJcbiAgICAgICAgKVxyXG4gICAgICApO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgY29uc3QgbmV3RmllbGQgPSB7XHJcbiAgICAgICAgaWQ6IERhdGUubm93KCksXHJcbiAgICAgICAgLi4uZmllbGRGb3JtLFxyXG4gICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKT8udG9JU09TdHJpbmcoKT8uc3BsaXQoJ1QnKT8uWzBdXHJcbiAgICAgIH07XHJcbiAgICAgIHNldEZpZWxkcyhwcmV2ID0+IFsuLi5wcmV2LCBuZXdGaWVsZF0pO1xyXG4gICAgfVxyXG4gICAgXHJcbiAgICBzZXRTaG93RmllbGRNb2RhbChmYWxzZSk7XHJcbiAgICBzZXRFZGl0aW5nRmllbGQobnVsbCk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgYWRkT3B0aW9uID0gKCkgPT4ge1xyXG4gICAgc2V0RmllbGRGb3JtKHByZXYgPT4gKHtcclxuICAgICAgLi4ucHJldixcclxuICAgICAgb3B0aW9uczogWy4uLnByZXY/Lm9wdGlvbnMsICcnXVxyXG4gICAgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHVwZGF0ZU9wdGlvbiA9IChpbmRleCwgdmFsdWUpID0+IHtcclxuICAgIHNldEZpZWxkRm9ybShwcmV2ID0+ICh7XHJcbiAgICAgIC4uLnByZXYsXHJcbiAgICAgIG9wdGlvbnM6IHByZXY/Lm9wdGlvbnM/Lm1hcCgob3B0aW9uLCBpKSA9PiBpID09PSBpbmRleCA/IHZhbHVlIDogb3B0aW9uKVxyXG4gICAgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHJlbW92ZU9wdGlvbiA9IChpbmRleCkgPT4ge1xyXG4gICAgc2V0RmllbGRGb3JtKHByZXYgPT4gKHtcclxuICAgICAgLi4ucHJldixcclxuICAgICAgb3B0aW9uczogcHJldj8ub3B0aW9ucz8uZmlsdGVyKChfLCBpKSA9PiBpICE9PSBpbmRleClcclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBnZXRUeXBlSWNvbiA9ICh0eXBlKSA9PiB7XHJcbiAgICBjb25zdCBmaWVsZFR5cGUgPSBmaWVsZFR5cGVzPy5maW5kKGZ0ID0+IGZ0Py52YWx1ZSA9PT0gdHlwZSk7XHJcbiAgICByZXR1cm4gZmllbGRUeXBlPy5pY29uIHx8ICdUeXBlJztcclxuICB9O1xyXG5cclxuICBjb25zdCBnZXRFbnRpdHlCYWRnZSA9IChlbnRpdHkpID0+IHtcclxuICAgIGNvbnN0IGNvbG9ycyA9IHtcclxuICAgICAgY29udGFjdDogJ2JnLXByaW1hcnktNTAgdGV4dC1wcmltYXJ5IGJvcmRlci1wcmltYXJ5LTEwMCcsXHJcbiAgICAgIGRlYWw6ICdiZy1zdWNjZXNzLTUwIHRleHQtc3VjY2VzcyBib3JkZXItc3VjY2Vzcy0xMDAnLFxyXG4gICAgICBhY3Rpdml0eTogJ2JnLWFjY2VudC01MCB0ZXh0LWFjY2VudCBib3JkZXItYWNjZW50LTEwMCdcclxuICAgIH07XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgcHgtMiBweS0xIHRleHQteHMgZm9udC1tZWRpdW0gcm91bmRlZCBib3JkZXIgJHtjb2xvcnM/LltlbnRpdHldIHx8ICdiZy1ncmF5LTUwIHRleHQtZ3JheS02MDAgYm9yZGVyLWdyYXktMTAwJ31gfT5cclxuICAgICAgICB7ZW50aXR5Py5jaGFyQXQoMCk/LnRvVXBwZXJDYXNlKCkgKyBlbnRpdHk/LnNsaWNlKDEpfVxyXG4gICAgICA8L3NwYW4+XHJcbiAgICApO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxyXG4gICAgICB7LyogSGVhZGVyICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtdGV4dC1wcmltYXJ5XCI+Q3VzdG9tIEZpZWxkczwvaDI+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5IG10LTFcIj5DcmVhdGUgYW5kIG1hbmFnZSBjdXN0b20gZmllbGRzIGZvciB5b3VyIGRhdGE8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgb25DbGljaz17aGFuZGxlQ3JlYXRlRmllbGR9XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJiZy1wcmltYXJ5IHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQtbGcgaG92ZXI6YmctcHJpbWFyeS02MDAgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwIGVhc2Utc21vb3RoIGZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMlwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPEljb24gbmFtZT1cIlBsdXNcIiBzaXplPXsxNn0gLz5cclxuICAgICAgICAgIDxzcGFuPkNyZWF0ZSBGaWVsZDwvc3Bhbj5cclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIHsvKiBGaWVsZHMgTGlzdCAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zdXJmYWNlIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ib3JkZXIgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG9cIj5cclxuICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWJhY2tncm91bmQgYm9yZGVyLWIgYm9yZGVyLWJvcmRlclwiPlxyXG4gICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgcHktMyBweC00IHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnlcIj5GaWVsZCBOYW1lPC90aD5cclxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgcHktMyBweC00IHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnlcIj5UeXBlPC90aD5cclxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgcHktMyBweC00IHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnlcIj5FbnRpdHk8L3RoPlxyXG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInRleHQtbGVmdCBweS0zIHB4LTQgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeVwiPlJlcXVpcmVkPC90aD5cclxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgcHktMyBweC00IHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnlcIj5QbGFjZW1lbnQ8L3RoPlxyXG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInRleHQtbGVmdCBweS0zIHB4LTQgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeVwiPkNyZWF0ZWQ8L3RoPlxyXG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInRleHQtbGVmdCBweS0zIHB4LTQgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeVwiPkFjdGlvbnM8L3RoPlxyXG4gICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgIDx0Ym9keT5cclxuICAgICAgICAgICAgICB7ZmllbGRzPy5tYXAoKGZpZWxkKSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8dHIga2V5PXtmaWVsZD8uaWR9IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ib3JkZXIgaG92ZXI6Ymctc3VyZmFjZS1ob3ZlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9e2dldFR5cGVJY29uKGZpZWxkPy50eXBlKX0gc2l6ZT17MTZ9IGNsYXNzTmFtZT1cInRleHQtdGV4dC10ZXJ0aWFyeVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeVwiPntmaWVsZD8ubmFtZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTQgdGV4dC1zbSB0ZXh0LXRleHQtc2Vjb25kYXJ5IGNhcGl0YWxpemVcIj57ZmllbGQ/LnR5cGV9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtNFwiPntnZXRFbnRpdHlCYWRnZShmaWVsZD8uZW50aXR5KX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2ZpZWxkPy5yZXF1aXJlZCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJDaGVja1wiIHNpemU9ezE2fSBjbGFzc05hbWU9XCJ0ZXh0LXN1Y2Nlc3NcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiWFwiIHNpemU9ezE2fSBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtdGVydGlhcnlcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTQgdGV4dC1zbSB0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3BsYWNlbWVudHM/LltmaWVsZD8uZW50aXR5XT8uZmluZChwID0+IHA/LnZhbHVlID09PSBmaWVsZD8ucGxhY2VtZW50KT8ubGFiZWwgfHwgZmllbGQ/LnBsYWNlbWVudH1cclxuICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtNCB0ZXh0LXNtIHRleHQtdGV4dC1zZWNvbmRhcnlcIj57ZmllbGQ/LmNyZWF0ZWRBdH08L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHNwYWNlLXgtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVFZGl0RmllbGQoZmllbGQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEgdGV4dC10ZXh0LXNlY29uZGFyeSBob3Zlcjp0ZXh0LXByaW1hcnkgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIkVkaXQzXCIgc2l6ZT17MTZ9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRGVsZXRlRmllbGQoZmllbGQ/LmlkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xIHRleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC1lcnJvciB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiVHJhc2gyXCIgc2l6ZT17MTZ9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgey8qIENyZWF0ZS9FZGl0IEZpZWxkIE1vZGFsICovfVxyXG4gICAgICB7c2hvd0ZpZWxkTW9kYWwgJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTEyMDAgb3ZlcmZsb3cteS1hdXRvXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG1pbi1oLXNjcmVlbiBweC00XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBiZy1ibGFjayBiZy1vcGFjaXR5LTUwXCIgb25DbGljaz17KCkgPT4gc2V0U2hvd0ZpZWxkTW9kYWwoZmFsc2UpfT48L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zdXJmYWNlIHJvdW5kZWQtbGcgc2hhZG93LXhsIG1heC13LTJ4bCB3LWZ1bGwgcmVsYXRpdmUgei0xMzAwIG1heC1oLXNjcmVlbiBvdmVyZmxvdy15LWF1dG9cIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNlwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtdGV4dC1wcmltYXJ5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2VkaXRpbmdGaWVsZCA/ICdFZGl0IEZpZWxkJyA6ICdDcmVhdGUgTmV3IEZpZWxkJ31cclxuICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dGaWVsZE1vZGFsKGZhbHNlKX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5IGhvdmVyOnRleHQtdGV4dC1wcmltYXJ5IHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiWFwiIHNpemU9ezIwfSAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU2F2ZUZpZWxkfSBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IG1iLTFcIj5GaWVsZCBOYW1lPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmaWVsZEZvcm0/Lm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RmllbGRGb3JtKHByZXYgPT4gKHsgLi4ucHJldiwgbmFtZTogZT8udGFyZ2V0Py52YWx1ZSB9KSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ib3JkZXIgcm91bmRlZC1sZyBmb2N1czpyaW5nLXByaW1hcnkgZm9jdXM6Ym9yZGVyLXByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIGZpZWxkIG5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItMVwiPkZpZWxkIFR5cGU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZmllbGRGb3JtPy50eXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZpZWxkRm9ybShwcmV2ID0+ICh7IC4uLnByZXYsIHR5cGU6IGU/LnRhcmdldD8udmFsdWUgfSkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1wcmltYXJ5IGZvY3VzOmJvcmRlci1wcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2ZpZWxkVHlwZXM/Lm1hcCh0eXBlID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17dHlwZT8udmFsdWV9IHZhbHVlPXt0eXBlPy52YWx1ZX0+e3R5cGU/LmxhYmVsfTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSBtYi0xXCI+QXBwbHkgVG88L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZmllbGRGb3JtPy5lbnRpdHl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RmllbGRGb3JtKHByZXYgPT4gKHsgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4ucHJldiwgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZW50aXR5OiBlPy50YXJnZXQ/LnZhbHVlLCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZW1lbnQ6IHBsYWNlbWVudHM/LltlPy50YXJnZXQ/LnZhbHVlXT8uWzBdPy52YWx1ZSB8fCAnJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ib3JkZXIgcm91bmRlZC1sZyBmb2N1czpyaW5nLXByaW1hcnkgZm9jdXM6Ym9yZGVyLXByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZW50aXRpZXM/Lm1hcChlbnRpdHkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtlbnRpdHk/LnZhbHVlfSB2YWx1ZT17ZW50aXR5Py52YWx1ZX0+e2VudGl0eT8ubGFiZWx9PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IG1iLTFcIj5QbGFjZW1lbnQ8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZmllbGRGb3JtPy5wbGFjZW1lbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RmllbGRGb3JtKHByZXYgPT4gKHsgLi4ucHJldiwgcGxhY2VtZW50OiBlPy50YXJnZXQ/LnZhbHVlIH0pKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLWxnIGZvY3VzOnJpbmctcHJpbWFyeSBmb2N1czpib3JkZXItcHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtwbGFjZW1lbnRzPy5bZmllbGRGb3JtPy5lbnRpdHldPy5tYXAocGxhY2VtZW50ID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17cGxhY2VtZW50Py52YWx1ZX0gdmFsdWU9e3BsYWNlbWVudD8udmFsdWV9PntwbGFjZW1lbnQ/LmxhYmVsfTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2ZpZWxkRm9ybT8ucmVxdWlyZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RmllbGRGb3JtKHByZXYgPT4gKHsgLi4ucHJldiwgcmVxdWlyZWQ6IGU/LnRhcmdldD8uY2hlY2tlZCB9KSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQgYm9yZGVyLWJvcmRlciB0ZXh0LXByaW1hcnkgZm9jdXM6cmluZy1wcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtdGV4dC1wcmltYXJ5XCI+UmVxdWlyZWQgZmllbGQ8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICB7KGZpZWxkRm9ybT8udHlwZSA9PT0gJ3NlbGVjdCcgfHwgZmllbGRGb3JtPy50eXBlID09PSAncmFkaW8nKSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IG1iLTFcIj5PcHRpb25zPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtmaWVsZEZvcm0/Lm9wdGlvbnM/Lm1hcCgob3B0aW9uLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpbmRleH0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17b3B0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZU9wdGlvbihpbmRleCwgZT8udGFyZ2V0Py52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ib3JkZXIgcm91bmRlZC1sZyBmb2N1czpyaW5nLXByaW1hcnkgZm9jdXM6Ym9yZGVyLXByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17YE9wdGlvbiAke2luZGV4ICsgMX1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmaWVsZEZvcm0/Lm9wdGlvbnM/Lmxlbmd0aCA+IDEgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcmVtb3ZlT3B0aW9uKGluZGV4KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgdGV4dC1lcnJvciBob3ZlcjpiZy1lcnJvci01MCByb3VuZGVkIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiWFwiIHNpemU9ezE2fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17YWRkT3B0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1wcmltYXJ5IGhvdmVyOnRleHQtcHJpbWFyeS02MDAgZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0xXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJQbHVzXCIgc2l6ZT17MTR9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+QWRkIE9wdGlvbjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBzcGFjZS14LTMgbXQtNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0ZpZWxkTW9kYWwoZmFsc2UpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC10ZXh0LXByaW1hcnkgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBDYW5jZWxcclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXByaW1hcnkgdGV4dC13aGl0ZSBweC00IHB5LTIgcm91bmRlZC1sZyBob3ZlcjpiZy1wcmltYXJ5LTYwMCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTAgZWFzZS1zbW9vdGhcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlZGl0aW5nRmllbGQgPyAnVXBkYXRlIEZpZWxkJyA6ICdDcmVhdGUgRmllbGQnfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgICAgey8qIFVzYWdlIEd1aWRlbGluZXMgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYmFja2dyb3VuZCBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLWxnIHAtNFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBzcGFjZS14LTNcIj5cclxuICAgICAgICAgIDxJY29uIG5hbWU9XCJJbmZvXCIgc2l6ZT17MTZ9IGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeSBtdC0wLjVcIiAvPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IHRleHQtc21cIj5DdXN0b20gRmllbGQgR3VpZGVsaW5lczwvaDQ+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtdGV4dC1zZWNvbmRhcnkgdGV4dC1zbSBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgQ3VzdG9tIGZpZWxkcyBhcHBlYXIgaW4gZm9ybXMgYW5kIGRldGFpbCB2aWV3cyBiYXNlZCBvbiB0aGVpciBwbGFjZW1lbnQgY29uZmlndXJhdGlvbi4gXHJcbiAgICAgICAgICAgICAgUmVxdWlyZWQgZmllbGRzIG11c3QgYmUgZmlsbGVkIGJlZm9yZSBzYXZpbmcuIEZpZWxkIGNoYW5nZXMgbWF5IHJlcXVpcmUgY2FjaGUgcmVmcmVzaC5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEN1c3RvbUZpZWxkczsiXSwiZmlsZSI6IkQ6L2N1cnJlbnQgcHJvamVjdHMvY2xhdWRlLWNvZGUvc3JjL3BhZ2VzL3NldHRpbmdzLWFkbWluaXN0cmF0aW9uL2NvbXBvbmVudHMvQ3VzdG9tRmllbGRzLmpzeCJ9