import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/contact-management/components/MergeDuplicatesModal.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import Icon from "/src/components/AppIcon.jsx";
import Image from "/src/components/AppImage.jsx";
const MergeDuplicatesModal = ({ contact1, contact2, onMerge, onClose }) => {
  _s();
  const [mergedContact, setMergedContact] = useState({
    id: Date.now(),
    firstName: contact1?.firstName,
    lastName: contact1?.lastName,
    email: contact1?.email,
    phone: contact1?.phone,
    company: contact1?.company,
    position: contact1?.position,
    avatar: contact1?.avatar,
    lastContactDate: (/* @__PURE__ */ new Date())?.toISOString(),
    status: contact1?.status,
    tags: [.../* @__PURE__ */ new Set([...contact1.tags, ...contact2.tags])],
    deals: [...contact1?.deals, ...contact2?.deals],
    notes: contact1?.notes && contact2?.notes ? `${contact1?.notes}

${contact2?.notes}` : contact1?.notes || contact2?.notes,
    socialProfiles: { ...contact1?.socialProfiles, ...contact2?.socialProfiles },
    activities: [...contact1?.activities, ...contact2?.activities]?.sort(
      (a, b) => new Date(b.date) - new Date(a.date)
    ),
    customFields: { ...contact1?.customFields }
  });
  const handleFieldSelect = (field, value) => {
    setMergedContact({
      ...mergedContact,
      [field]: value
    });
  };
  const renderFieldComparison = (field, label, contact1Value, contact2Value) => {
    return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:38:6", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "38", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22py-3%20border-b%20border-border%20last%3Aborder-b-0%22%7D", className: "py-3 border-b border-border last:border-b-0", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:39:8", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "39", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-sm%20font-medium%20text-text-secondary%20mb-2%22%7D", className: "text-sm font-medium text-text-secondary mb-2", children: label }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
        lineNumber: 39,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:40:8", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "40", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20flex-col%20sm%3Aflex-row%20gap-3%22%7D", className: "flex flex-col sm:flex-row gap-3", children: [
        /* @__PURE__ */ jsxDEV(
          "div",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:41:10",
            "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx",
            "data-component-line": "41",
            "data-component-file": "MergeDuplicatesModal.jsx",
            "data-component-name": "div",
            "data-component-content": "%7B%22elementName%22%3A%22div%22%7D",
            className: `flex-1 p-3 rounded-lg border ${mergedContact?.[field] === contact1Value ? "border-primary bg-primary-50" : "border-border hover:border-primary-100 cursor-pointer"}`,
            onClick: () => handleFieldSelect(field, contact1Value),
            children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:48:12", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "48", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%22%7D", className: "flex items-center", children: [
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:49:14", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "49", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex-1%22%7D", className: "flex-1", children: field === "avatar" ? /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:51:16", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "51", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-10%20h-10%20rounded-full%20overflow-hidden%22%7D", className: "w-10 h-10 rounded-full overflow-hidden", children: /* @__PURE__ */ jsxDEV(Image, { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:52:20", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "52", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "Image", "data-component-content": "%7B%22elementName%22%3A%22Image%22%2C%22src%22%3A%22%5Bvar%3Acontact1Value%5D%22%2C%22alt%22%3A%22Contact%201%22%2C%22className%22%3A%22w-full%20h-full%20object-cover%22%7D", src: contact1Value, alt: "Contact 1", className: "w-full h-full object-cover" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
                lineNumber: 52,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
                lineNumber: 51,
                columnNumber: 17
              }, this) : /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:55:16", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "55", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-text-primary%22%7D", className: "text-text-primary", children: contact1Value || "-" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
                lineNumber: 55,
                columnNumber: 17
              }, this) }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
                lineNumber: 49,
                columnNumber: 15
              }, this),
              mergedContact?.[field] === contact1Value && /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:59:14", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "59", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Check%22%2C%22className%22%3A%22text-primary%22%7D", name: "Check", size: 16, className: "text-primary" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
                lineNumber: 59,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
              lineNumber: 48,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
            lineNumber: 41,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "div",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:64:10",
            "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx",
            "data-component-line": "64",
            "data-component-file": "MergeDuplicatesModal.jsx",
            "data-component-name": "div",
            "data-component-content": "%7B%22elementName%22%3A%22div%22%7D",
            className: `flex-1 p-3 rounded-lg border ${mergedContact?.[field] === contact2Value ? "border-primary bg-primary-50" : "border-border hover:border-primary-100 cursor-pointer"}`,
            onClick: () => handleFieldSelect(field, contact2Value),
            children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:71:12", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "71", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%22%7D", className: "flex items-center", children: [
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:72:14", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "72", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex-1%22%7D", className: "flex-1", children: field === "avatar" ? /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:74:16", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "74", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-10%20h-10%20rounded-full%20overflow-hidden%22%7D", className: "w-10 h-10 rounded-full overflow-hidden", children: /* @__PURE__ */ jsxDEV(Image, { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:75:20", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "75", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "Image", "data-component-content": "%7B%22elementName%22%3A%22Image%22%2C%22src%22%3A%22%5Bvar%3Acontact2Value%5D%22%2C%22alt%22%3A%22Contact%202%22%2C%22className%22%3A%22w-full%20h-full%20object-cover%22%7D", src: contact2Value, alt: "Contact 2", className: "w-full h-full object-cover" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
                lineNumber: 75,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
                lineNumber: 74,
                columnNumber: 17
              }, this) : /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:78:16", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "78", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-text-primary%22%7D", className: "text-text-primary", children: contact2Value || "-" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
                lineNumber: 78,
                columnNumber: 17
              }, this) }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
                lineNumber: 72,
                columnNumber: 15
              }, this),
              mergedContact?.[field] === contact2Value && /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:82:14", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "82", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Check%22%2C%22className%22%3A%22text-primary%22%7D", name: "Check", size: 16, className: "text-primary" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
                lineNumber: 82,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
              lineNumber: 71,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
            lineNumber: 64,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
        lineNumber: 40,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
      lineNumber: 38,
      columnNumber: 7
    }, this);
  };
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:92:4", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "92", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20z-1100%20overflow-y-auto%22%7D", className: "fixed inset-0 z-1100 overflow-y-auto", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:93:6", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "93", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-center%20min-h-screen%20px-4%20pt-4%20pb-20%20text-center%20sm%3Ablock%20sm%3Ap-0%22%7D", className: "flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0", children: [
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:94:8", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "94", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20transition-opacity%22%7D", className: "fixed inset-0 transition-opacity", "aria-hidden": "true", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:95:10", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "95", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22absolute%20inset-0%20bg-black%20bg-opacity-50%22%7D", className: "absolute inset-0 bg-black bg-opacity-50" }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
      lineNumber: 95,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
      lineNumber: 94,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:98:8", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "98", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22hidden%20sm%3Ainline-block%20sm%3Aalign-middle%20sm%3Ah-screen%22%2C%22textContent%22%3A%22%E2%80%8B%22%7D", className: "hidden sm:inline-block sm:align-middle sm:h-screen", "aria-hidden": "true", children: "​" }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
      lineNumber: 98,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:100:8", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "100", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22inline-block%20align-bottom%20bg-surface%20rounded-lg%20text-left%20overflow-hidden%20shadow-xl%20transform%20transition-all%20sm%3Amy-8%20sm%3Aalign-middle%20sm%3Amax-w-lg%20sm%3Aw-full%20md%3Amax-w-2xl%22%7D", className: "inline-block align-bottom bg-surface rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full md:max-w-2xl", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:101:10", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "101", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22px-6%20py-4%20border-b%20border-border%20flex%20justify-between%20items-center%22%7D", className: "px-6 py-4 border-b border-border flex justify-between items-center", children: [
        /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:102:12", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "102", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%2C%22textContent%22%3A%22Merge%20Duplicate%20Contacts%22%7D", className: "text-lg font-semibold text-text-primary", children: "Merge Duplicate Contacts" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
          lineNumber: 102,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:103:12",
            "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx",
            "data-component-line": "103",
            "data-component-file": "MergeDuplicatesModal.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22text-text-secondary%20hover%3Atext-text-primary%22%7D",
            onClick: onClose,
            className: "text-text-secondary hover:text-text-primary",
            children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:107:14", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "107", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22X%22%7D", name: "X", size: 20 }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
              lineNumber: 107,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
            lineNumber: 103,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
        lineNumber: 101,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:111:10", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "111", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22px-6%20py-5%22%7D", className: "px-6 py-5", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:112:12", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "112", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22mb-6%22%7D", className: "mb-6", children: [
        /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:113:14", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "113", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20mb-4%22%2C%22textContent%22%3A%22Select%20which%20information%20to%20keep%20for%20the%20merged%20contact.%22%7D", className: "text-text-secondary mb-4", children: "Select which information to keep for the merged contact." }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
          lineNumber: 113,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:117:14", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "117", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-3%20gap-4%20mb-4%22%7D", className: "grid grid-cols-3 gap-4 mb-4", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:118:16", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "118", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
            lineNumber: 118,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:119:16", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "119", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-center%20text-sm%20font-medium%20text-text-primary%22%2C%22textContent%22%3A%22Contact%201%22%7D", className: "text-center text-sm font-medium text-text-primary", children: "Contact 1" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
            lineNumber: 119,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:120:16", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "120", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-center%20text-sm%20font-medium%20text-text-primary%22%2C%22textContent%22%3A%22Contact%202%22%7D", className: "text-center text-sm font-medium text-text-primary", children: "Contact 2" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
            lineNumber: 120,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
          lineNumber: 117,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:123:14", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "123", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22border%20border-border%20rounded-lg%20divide-y%20divide-border%22%7D", className: "border border-border rounded-lg divide-y divide-border", children: [
          renderFieldComparison("avatar", "Profile Picture", contact1?.avatar, contact2?.avatar),
          renderFieldComparison("firstName", "First Name", contact1?.firstName, contact2?.firstName),
          renderFieldComparison("lastName", "Last Name", contact1?.lastName, contact2?.lastName),
          renderFieldComparison("email", "Email", contact1?.email, contact2?.email),
          renderFieldComparison("phone", "Phone", contact1?.phone, contact2?.phone),
          renderFieldComparison("company", "Company", contact1?.company, contact2?.company),
          renderFieldComparison("position", "Position", contact1?.position, contact2?.position)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
          lineNumber: 123,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:133:14", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "133", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22mt-6%22%7D", className: "mt-6", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:134:16", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "134", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-primary-50%20border%20border-primary-100%20rounded-lg%20p-4%20text-sm%20text-primary%22%7D", className: "bg-primary-50 border border-primary-100 rounded-lg p-4 text-sm text-primary", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:135:18", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "135", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-start%22%7D", className: "flex items-start", children: [
          /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:136:20", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "136", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Info%22%2C%22className%22%3A%22mr-2%20mt-0.5%22%7D", name: "Info", size: 16, className: "mr-2 mt-0.5" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
            lineNumber: 136,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:137:20", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "137", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
            /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:138:22", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "138", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22font-medium%20mb-1%22%2C%22textContent%22%3A%22Additional%20Information%22%7D", className: "font-medium mb-1", children: "Additional Information" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
              lineNumber: 138,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:139:22", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "139", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22textContent%22%3A%22The%20following%20data%20will%20be%20combined%20from%20both%20contacts%3A%22%7D", children: "The following data will be combined from both contacts:" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
              lineNumber: 139,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("ul", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:140:22", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "140", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "ul", "data-component-content": "%7B%22elementName%22%3A%22ul%22%2C%22className%22%3A%22list-disc%20list-inside%20mt-1%20space-y-1%22%7D", className: "list-disc list-inside mt-1 space-y-1", children: [
              /* @__PURE__ */ jsxDEV("li", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:141:24", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "141", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "li", "data-component-content": "%7B%22elementName%22%3A%22li%22%2C%22textContent%22%3A%22Tags%20(%20total)%22%7D", children: [
                "Tags (",
                mergedContact?.tags?.length,
                " total)"
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
                lineNumber: 141,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("li", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:142:24", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "142", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "li", "data-component-content": "%7B%22elementName%22%3A%22li%22%2C%22textContent%22%3A%22Deals%20(%20total)%22%7D", children: [
                "Deals (",
                mergedContact?.deals?.length,
                " total)"
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
                lineNumber: 142,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("li", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:143:24", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "143", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "li", "data-component-content": "%7B%22elementName%22%3A%22li%22%2C%22textContent%22%3A%22Activities%20(%20total)%22%7D", children: [
                "Activities (",
                mergedContact?.activities?.length,
                " total)"
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
                lineNumber: 143,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("li", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:144:24", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "144", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "li", "data-component-content": "%7B%22elementName%22%3A%22li%22%2C%22textContent%22%3A%22Notes%20(will%20be%20concatenated)%22%7D", children: "Notes (will be concatenated)" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
                lineNumber: 144,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("li", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:145:24", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "145", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "li", "data-component-content": "%7B%22elementName%22%3A%22li%22%2C%22textContent%22%3A%22Social%20profiles%20(will%20be%20merged)%22%7D", children: "Social profiles (will be merged)" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
                lineNumber: 145,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
              lineNumber: 140,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
            lineNumber: 137,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
          lineNumber: 135,
          columnNumber: 19
        }, this) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
          lineNumber: 134,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
          lineNumber: 133,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
        lineNumber: 112,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
        lineNumber: 111,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:154:10", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "154", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22px-6%20py-4%20border-t%20border-border%20flex%20justify-end%20space-x-3%22%7D", className: "px-6 py-4 border-t border-border flex justify-end space-x-3", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:155:12",
            "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx",
            "data-component-line": "155",
            "data-component-file": "MergeDuplicatesModal.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22px-4%20py-2%20border%20border-border%20rounded-lg%20text-text-secondary%20hover%3Atext-text-primary%20hover%3Abg-surface-hover%20transition-all%20duration-150%20ease-out%22%2C%22textContent%22%3A%22Cancel%22%7D",
            onClick: onClose,
            className: "px-4 py-2 border border-border rounded-lg text-text-secondary hover:text-text-primary hover:bg-surface-hover transition-all duration-150 ease-out",
            children: "Cancel"
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
            lineNumber: 155,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:161:12",
            "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx",
            "data-component-line": "161",
            "data-component-file": "MergeDuplicatesModal.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22btn-primary%20inline-flex%20items-center%22%2C%22textContent%22%3A%22Merge%20Contacts%22%7D",
            onClick: () => onMerge(mergedContact),
            className: "btn-primary inline-flex items-center",
            children: [
              /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx:165:14", "data-component-path": "src\\pages\\contact-management\\components\\MergeDuplicatesModal.jsx", "data-component-line": "165", "data-component-file": "MergeDuplicatesModal.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22GitMerge%22%2C%22className%22%3A%22mr-2%22%7D", name: "GitMerge", size: 16, className: "mr-2" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
                lineNumber: 165,
                columnNumber: 15
              }, this),
              "Merge Contacts"
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
            lineNumber: 161,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
        lineNumber: 154,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
      lineNumber: 100,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
    lineNumber: 93,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx",
    lineNumber: 92,
    columnNumber: 5
  }, this);
};
_s(MergeDuplicatesModal, "B4wFkC4gSyz6NSfmjQshwsf4cuk=");
_c = MergeDuplicatesModal;
export default MergeDuplicatesModal;
var _c;
$RefreshReg$(_c, "MergeDuplicatesModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/contact-management/components/MergeDuplicatesModal.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0NROzJCQXRDUjtBQUFnQkEsTUFBUSxjQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3ZDLE9BQU9DLFVBQVU7QUFDakIsT0FBT0MsV0FBVztBQUVsQixNQUFNQyx1QkFBdUJBLENBQUMsRUFBRUMsVUFBVUMsVUFBVUMsU0FBU0MsUUFBUSxNQUFNO0FBQUFDLEtBQUE7QUFDekUsUUFBTSxDQUFDQyxlQUFlQyxnQkFBZ0IsSUFBSVYsU0FBUztBQUFBLElBQ2pEVyxJQUFJQyxLQUFLQyxJQUFJO0FBQUEsSUFDYkMsV0FBV1YsVUFBVVU7QUFBQUEsSUFDckJDLFVBQVVYLFVBQVVXO0FBQUFBLElBQ3BCQyxPQUFPWixVQUFVWTtBQUFBQSxJQUNqQkMsT0FBT2IsVUFBVWE7QUFBQUEsSUFDakJDLFNBQVNkLFVBQVVjO0FBQUFBLElBQ25CQyxVQUFVZixVQUFVZTtBQUFBQSxJQUNwQkMsUUFBUWhCLFVBQVVnQjtBQUFBQSxJQUNsQkMsa0JBQWlCLG9CQUFJVCxLQUFLLElBQUdVLFlBQVk7QUFBQSxJQUN6Q0MsUUFBUW5CLFVBQVVtQjtBQUFBQSxJQUNsQkMsTUFBTSxDQUFDLEdBQUcsb0JBQUlDLElBQUksQ0FBQyxHQUFHckIsU0FBU29CLE1BQU0sR0FBR25CLFNBQVNtQixJQUFJLENBQUMsQ0FBQztBQUFBLElBQ3ZERSxPQUFPLENBQUMsR0FBR3RCLFVBQVVzQixPQUFPLEdBQUdyQixVQUFVcUIsS0FBSztBQUFBLElBQzlDQyxPQUFPdkIsVUFBVXVCLFNBQVN0QixVQUFVc0IsUUFDaEMsR0FBR3ZCLFVBQVV1QixLQUFLO0FBQUE7QUFBQSxFQUFPdEIsVUFBVXNCLEtBQUssS0FDeEN2QixVQUFVdUIsU0FBU3RCLFVBQVVzQjtBQUFBQSxJQUNqQ0MsZ0JBQWdCLEVBQUUsR0FBR3hCLFVBQVV3QixnQkFBZ0IsR0FBR3ZCLFVBQVV1QixlQUFlO0FBQUEsSUFDM0VDLFlBQVksQ0FBQyxHQUFHekIsVUFBVXlCLFlBQVksR0FBR3hCLFVBQVV3QixVQUFVLEdBQUdDO0FBQUFBLE1BQUssQ0FBQ0MsR0FBR0MsTUFDdkUsSUFBSXBCLEtBQUtvQixFQUFFQyxJQUFJLElBQUksSUFBSXJCLEtBQUttQixFQUFFRSxJQUFJO0FBQUEsSUFDcEM7QUFBQSxJQUNBQyxjQUFjLEVBQUUsR0FBRzlCLFVBQVU4QixhQUFhO0FBQUEsRUFDNUMsQ0FBQztBQUVELFFBQU1DLG9CQUFvQkEsQ0FBQ0MsT0FBT0MsVUFBVTtBQUMxQzNCLHFCQUFpQjtBQUFBLE1BQ2YsR0FBR0Q7QUFBQUEsTUFDSCxDQUFDMkIsS0FBSyxHQUFHQztBQUFBQSxJQUNYLENBQUM7QUFBQSxFQUNIO0FBRUEsUUFBTUMsd0JBQXdCQSxDQUFDRixPQUFPRyxPQUFPQyxlQUFlQyxrQkFBa0I7QUFDNUUsV0FDRSx1QkFBQyx1Y0FBSSxXQUFVLCtDQUNiO0FBQUEsNkJBQUMsc2NBQUksV0FBVSxnREFBZ0RGLG1CQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFFO0FBQUEsTUFDckUsdUJBQUMsMmJBQUksV0FBVSxtQ0FDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFDQyxXQUFXLGdDQUNUOUIsZ0JBQWdCMkIsS0FBSyxNQUFNSSxnQkFDdkIsaUNBQWdDLHVEQUF1RDtBQUFBLFlBRTdGLFNBQVMsTUFBTUwsa0JBQWtCQyxPQUFPSSxhQUFhO0FBQUEsWUFFckQsaUNBQUMsd2FBQUksV0FBVSxxQkFDYjtBQUFBLHFDQUFDLDJaQUFJLFdBQVUsVUFDWkosb0JBQVUsV0FDVCx1QkFBQyxpY0FBSSxXQUFVLDBDQUNiLGlDQUFDLHFnQkFBTSxLQUFLSSxlQUFlLEtBQUksYUFBWSxXQUFVLGdDQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpRixLQURuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBLElBRUEsdUJBQUMseWFBQUssV0FBVSxxQkFBcUJBLDJCQUFpQixPQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwRCxLQU45RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVFBO0FBQUEsY0FDQy9CLGdCQUFnQjJCLEtBQUssTUFBTUksaUJBQzFCLHVCQUFDLDZiQUFLLE1BQUssU0FBUSxNQUFNLElBQUksV0FBVSxrQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUQ7QUFBQSxpQkFYekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFhQTtBQUFBO0FBQUEsVUFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBcUJBO0FBQUEsUUFFQTtBQUFBLFVBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBQ0MsV0FBVyxnQ0FDVC9CLGdCQUFnQjJCLEtBQUssTUFBTUssZ0JBQ3ZCLGlDQUFnQyx1REFBdUQ7QUFBQSxZQUU3RixTQUFTLE1BQU1OLGtCQUFrQkMsT0FBT0ssYUFBYTtBQUFBLFlBRXJELGlDQUFDLHdhQUFJLFdBQVUscUJBQ2I7QUFBQSxxQ0FBQywyWkFBSSxXQUFVLFVBQ1pMLG9CQUFVLFdBQ1QsdUJBQUMsaWNBQUksV0FBVSwwQ0FDYixpQ0FBQyxxZ0JBQU0sS0FBS0ssZUFBZSxLQUFJLGFBQVksV0FBVSxnQ0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUYsS0FEbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQSxJQUVBLHVCQUFDLHlhQUFLLFdBQVUscUJBQXFCQSwyQkFBaUIsT0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEQsS0FOOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFRQTtBQUFBLGNBQ0NoQyxnQkFBZ0IyQixLQUFLLE1BQU1LLGlCQUMxQix1QkFBQyw2YkFBSyxNQUFLLFNBQVEsTUFBTSxJQUFJLFdBQVUsa0JBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFEO0FBQUEsaUJBWHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBYUE7QUFBQTtBQUFBLFVBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQXFCQTtBQUFBLFdBN0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4Q0E7QUFBQSxTQWhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaURBO0FBQUEsRUFFSjtBQUVBLFNBQ0UsdUJBQUMsOGJBQUksV0FBVSx3Q0FDYixpQ0FBQyxtZ0JBQUksV0FBVSw2RkFDYjtBQUFBLDJCQUFDLHdiQUFJLFdBQVUsb0NBQW1DLGVBQVksUUFDNUQsaUNBQUMsa2NBQUksV0FBVSw2Q0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlELEtBRDNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBRUEsdUJBQUMsMmZBQUssV0FBVSxzREFBcUQsZUFBWSxRQUFPLGlCQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStGO0FBQUEsSUFFL0YsdUJBQUMsaW1CQUFJLFdBQVUsMktBQ2I7QUFBQSw2QkFBQyxxZUFBSSxXQUFVLHNFQUNiO0FBQUEsK0JBQUMsd2ZBQUcsV0FBVSwyQ0FBMEMsd0NBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0Y7QUFBQSxRQUNoRjtBQUFBLFVBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBQ0MsU0FBU2xDO0FBQUFBLFlBQ1QsV0FBVTtBQUFBLFlBRVYsaUNBQUMsb1pBQUssTUFBSyxLQUFJLE1BQU0sTUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0I7QUFBQTtBQUFBLFVBSjFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsV0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxNQUVBLHVCQUFDLGthQUFJLFdBQVUsYUFDYixpQ0FBQywyWkFBSSxXQUFVLFFBQ2I7QUFBQSwrQkFBQyxnaEJBQUUsV0FBVSw0QkFBMkIsd0VBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBRUEsdUJBQUMsd2JBQUksV0FBVSwrQkFDYjtBQUFBLGlDQUFDLDhYQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQUs7QUFBQSxVQUNMLHVCQUFDLHNmQUFJLFdBQVUscURBQW9ELHlCQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0RTtBQUFBLFVBQzVFLHVCQUFDLHNmQUFJLFdBQVUscURBQW9ELHlCQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0RTtBQUFBLGFBSDlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFFBRUEsdUJBQUMscWRBQUksV0FBVSwwREFDWitCO0FBQUFBLGdDQUFzQixVQUFVLG1CQUFtQmxDLFVBQVVnQixRQUFRZixVQUFVZSxNQUFNO0FBQUEsVUFDckZrQixzQkFBc0IsYUFBYSxjQUFjbEMsVUFBVVUsV0FBV1QsVUFBVVMsU0FBUztBQUFBLFVBQ3pGd0Isc0JBQXNCLFlBQVksYUFBYWxDLFVBQVVXLFVBQVVWLFVBQVVVLFFBQVE7QUFBQSxVQUNyRnVCLHNCQUFzQixTQUFTLFNBQVNsQyxVQUFVWSxPQUFPWCxVQUFVVyxLQUFLO0FBQUEsVUFDeEVzQixzQkFBc0IsU0FBUyxTQUFTbEMsVUFBVWEsT0FBT1osVUFBVVksS0FBSztBQUFBLFVBQ3hFcUIsc0JBQXNCLFdBQVcsV0FBV2xDLFVBQVVjLFNBQVNiLFVBQVVhLE9BQU87QUFBQSxVQUNoRm9CLHNCQUFzQixZQUFZLFlBQVlsQyxVQUFVZSxVQUFVZCxVQUFVYyxRQUFRO0FBQUEsYUFQdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFFQSx1QkFBQywyWkFBSSxXQUFVLFFBQ2IsaUNBQUMsOGVBQUksV0FBVSwrRUFDYixpQ0FBQyx5YUFBSSxXQUFVLG9CQUNiO0FBQUEsaUNBQUMsK2JBQUssTUFBSyxRQUFPLE1BQU0sSUFBSSxXQUFVLGlCQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRDtBQUFBLFVBQ25ELHVCQUFDLDRYQUNDO0FBQUEsbUNBQUMsd2RBQUUsV0FBVSxvQkFBbUIsc0NBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNEO0FBQUEsWUFDdEQsdUJBQUMsNGRBQUUsdUVBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEQ7QUFBQSxZQUMxRCx1QkFBQyw4YkFBRyxXQUFVLHdDQUNaO0FBQUEscUNBQUMsdWFBQUc7QUFBQTtBQUFBLGdCQUFPVixlQUFlZSxNQUFNa0I7QUFBQUEsZ0JBQU87QUFBQSxtQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEM7QUFBQSxjQUM5Qyx1QkFBQyx3YUFBRztBQUFBO0FBQUEsZ0JBQVFqQyxlQUFlaUIsT0FBT2dCO0FBQUFBLGdCQUFPO0FBQUEsbUJBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdEO0FBQUEsY0FDaEQsdUJBQUMsNmFBQUc7QUFBQTtBQUFBLGdCQUFhakMsZUFBZW9CLFlBQVlhO0FBQUFBLGdCQUFPO0FBQUEsbUJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBEO0FBQUEsY0FDMUQsdUJBQUMsd2JBQUcsNENBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0M7QUFBQSxjQUNoQyx1QkFBQyw4YkFBRyxnREFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvQztBQUFBLGlCQUx0QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU1BO0FBQUEsZUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsYUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYUEsS0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUEsS0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlCQTtBQUFBLFdBdENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF1Q0EsS0F4Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlDQTtBQUFBLE1BRUEsdUJBQUMsOGRBQUksV0FBVSwrREFDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFDQyxTQUFTbkM7QUFBQUEsWUFDVCxXQUFVO0FBQUEsWUFBbUo7QUFBQTtBQUFBLFVBRi9KO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNRCxRQUFRRyxhQUFhO0FBQUEsWUFDcEMsV0FBVTtBQUFBLFlBRVY7QUFBQSxxQ0FBQywwYkFBSyxNQUFLLFlBQVcsTUFBTSxJQUFJLFdBQVUsVUFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0Q7QUFBQSxjQUFHO0FBQUE7QUFBQTtBQUFBLFVBSnJEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsV0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBY0E7QUFBQSxTQXBFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUVBO0FBQUEsT0E1RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZFQSxLQTlFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBK0VBO0FBRUo7QUFBRUQsR0F4S0lMLHNCQUFvQjtBQUFBd0MsS0FBcEJ4QztBQTBLTixlQUFlQTtBQUFxQixJQUFBd0M7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiSWNvbiIsIkltYWdlIiwiTWVyZ2VEdXBsaWNhdGVzTW9kYWwiLCJjb250YWN0MSIsImNvbnRhY3QyIiwib25NZXJnZSIsIm9uQ2xvc2UiLCJfcyIsIm1lcmdlZENvbnRhY3QiLCJzZXRNZXJnZWRDb250YWN0IiwiaWQiLCJEYXRlIiwibm93IiwiZmlyc3ROYW1lIiwibGFzdE5hbWUiLCJlbWFpbCIsInBob25lIiwiY29tcGFueSIsInBvc2l0aW9uIiwiYXZhdGFyIiwibGFzdENvbnRhY3REYXRlIiwidG9JU09TdHJpbmciLCJzdGF0dXMiLCJ0YWdzIiwiU2V0IiwiZGVhbHMiLCJub3RlcyIsInNvY2lhbFByb2ZpbGVzIiwiYWN0aXZpdGllcyIsInNvcnQiLCJhIiwiYiIsImRhdGUiLCJjdXN0b21GaWVsZHMiLCJoYW5kbGVGaWVsZFNlbGVjdCIsImZpZWxkIiwidmFsdWUiLCJyZW5kZXJGaWVsZENvbXBhcmlzb24iLCJsYWJlbCIsImNvbnRhY3QxVmFsdWUiLCJjb250YWN0MlZhbHVlIiwibGVuZ3RoIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJNZXJnZUR1cGxpY2F0ZXNNb2RhbC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgSWNvbiBmcm9tICdjb21wb25lbnRzL0FwcEljb24nO1xyXG5pbXBvcnQgSW1hZ2UgZnJvbSAnY29tcG9uZW50cy9BcHBJbWFnZSc7XHJcblxyXG5jb25zdCBNZXJnZUR1cGxpY2F0ZXNNb2RhbCA9ICh7IGNvbnRhY3QxLCBjb250YWN0Miwgb25NZXJnZSwgb25DbG9zZSB9KSA9PiB7XHJcbiAgY29uc3QgW21lcmdlZENvbnRhY3QsIHNldE1lcmdlZENvbnRhY3RdID0gdXNlU3RhdGUoe1xyXG4gICAgaWQ6IERhdGUubm93KCksXHJcbiAgICBmaXJzdE5hbWU6IGNvbnRhY3QxPy5maXJzdE5hbWUsXHJcbiAgICBsYXN0TmFtZTogY29udGFjdDE/Lmxhc3ROYW1lLFxyXG4gICAgZW1haWw6IGNvbnRhY3QxPy5lbWFpbCxcclxuICAgIHBob25lOiBjb250YWN0MT8ucGhvbmUsXHJcbiAgICBjb21wYW55OiBjb250YWN0MT8uY29tcGFueSxcclxuICAgIHBvc2l0aW9uOiBjb250YWN0MT8ucG9zaXRpb24sXHJcbiAgICBhdmF0YXI6IGNvbnRhY3QxPy5hdmF0YXIsXHJcbiAgICBsYXN0Q29udGFjdERhdGU6IG5ldyBEYXRlKCk/LnRvSVNPU3RyaW5nKCksXHJcbiAgICBzdGF0dXM6IGNvbnRhY3QxPy5zdGF0dXMsXHJcbiAgICB0YWdzOiBbLi4ubmV3IFNldChbLi4uY29udGFjdDEudGFncywgLi4uY29udGFjdDIudGFnc10pXSxcclxuICAgIGRlYWxzOiBbLi4uY29udGFjdDE/LmRlYWxzLCAuLi5jb250YWN0Mj8uZGVhbHNdLFxyXG4gICAgbm90ZXM6IGNvbnRhY3QxPy5ub3RlcyAmJiBjb250YWN0Mj8ubm90ZXMgXHJcbiAgICAgID8gYCR7Y29udGFjdDE/Lm5vdGVzfVxcblxcbiR7Y29udGFjdDI/Lm5vdGVzfWBcclxuICAgICAgOiBjb250YWN0MT8ubm90ZXMgfHwgY29udGFjdDI/Lm5vdGVzLFxyXG4gICAgc29jaWFsUHJvZmlsZXM6IHsgLi4uY29udGFjdDE/LnNvY2lhbFByb2ZpbGVzLCAuLi5jb250YWN0Mj8uc29jaWFsUHJvZmlsZXMgfSxcclxuICAgIGFjdGl2aXRpZXM6IFsuLi5jb250YWN0MT8uYWN0aXZpdGllcywgLi4uY29udGFjdDI/LmFjdGl2aXRpZXNdPy5zb3J0KChhLCBiKSA9PiBcclxuICAgICAgbmV3IERhdGUoYi5kYXRlKSAtIG5ldyBEYXRlKGEuZGF0ZSlcclxuICAgICksXHJcbiAgICBjdXN0b21GaWVsZHM6IHsgLi4uY29udGFjdDE/LmN1c3RvbUZpZWxkcyB9XHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZUZpZWxkU2VsZWN0ID0gKGZpZWxkLCB2YWx1ZSkgPT4ge1xyXG4gICAgc2V0TWVyZ2VkQ29udGFjdCh7XHJcbiAgICAgIC4uLm1lcmdlZENvbnRhY3QsXHJcbiAgICAgIFtmaWVsZF06IHZhbHVlXHJcbiAgICB9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCByZW5kZXJGaWVsZENvbXBhcmlzb24gPSAoZmllbGQsIGxhYmVsLCBjb250YWN0MVZhbHVlLCBjb250YWN0MlZhbHVlKSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTMgYm9yZGVyLWIgYm9yZGVyLWJvcmRlciBsYXN0OmJvcmRlci1iLTBcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXNlY29uZGFyeSBtYi0yXCI+e2xhYmVsfTwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBnYXAtM1wiPlxyXG4gICAgICAgICAgPGRpdiBcclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleC0xIHAtMyByb3VuZGVkLWxnIGJvcmRlciAke1xyXG4gICAgICAgICAgICAgIG1lcmdlZENvbnRhY3Q/LltmaWVsZF0gPT09IGNvbnRhY3QxVmFsdWUgXHJcbiAgICAgICAgICAgICAgICA/ICdib3JkZXItcHJpbWFyeSBiZy1wcmltYXJ5LTUwJyA6J2JvcmRlci1ib3JkZXIgaG92ZXI6Ym9yZGVyLXByaW1hcnktMTAwIGN1cnNvci1wb2ludGVyJ1xyXG4gICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRmllbGRTZWxlY3QoZmllbGQsIGNvbnRhY3QxVmFsdWUpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgIHtmaWVsZCA9PT0gJ2F2YXRhcicgPyAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQtZnVsbCBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICA8SW1hZ2Ugc3JjPXtjb250YWN0MVZhbHVlfSBhbHQ9XCJDb250YWN0IDFcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsIG9iamVjdC1jb3ZlclwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC10ZXh0LXByaW1hcnlcIj57Y29udGFjdDFWYWx1ZSB8fCAnLSd9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICB7bWVyZ2VkQ29udGFjdD8uW2ZpZWxkXSA9PT0gY29udGFjdDFWYWx1ZSAmJiAoXHJcbiAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiQ2hlY2tcIiBzaXplPXsxNn0gY2xhc3NOYW1lPVwidGV4dC1wcmltYXJ5XCIgLz5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICA8ZGl2IFxyXG4gICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4LTEgcC0zIHJvdW5kZWQtbGcgYm9yZGVyICR7XHJcbiAgICAgICAgICAgICAgbWVyZ2VkQ29udGFjdD8uW2ZpZWxkXSA9PT0gY29udGFjdDJWYWx1ZSBcclxuICAgICAgICAgICAgICAgID8gJ2JvcmRlci1wcmltYXJ5IGJnLXByaW1hcnktNTAnIDonYm9yZGVyLWJvcmRlciBob3Zlcjpib3JkZXItcHJpbWFyeS0xMDAgY3Vyc29yLXBvaW50ZXInXHJcbiAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVGaWVsZFNlbGVjdChmaWVsZCwgY29udGFjdDJWYWx1ZSl9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAge2ZpZWxkID09PSAnYXZhdGFyJyA/IChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgcm91bmRlZC1mdWxsIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbWFnZSBzcmM9e2NvbnRhY3QyVmFsdWV9IGFsdD1cIkNvbnRhY3QgMlwiIGNsYXNzTmFtZT1cInctZnVsbCBoLWZ1bGwgb2JqZWN0LWNvdmVyXCIgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtcHJpbWFyeVwiPntjb250YWN0MlZhbHVlIHx8ICctJ308L3NwYW4+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIHttZXJnZWRDb250YWN0Py5bZmllbGRdID09PSBjb250YWN0MlZhbHVlICYmIChcclxuICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJDaGVja1wiIHNpemU9ezE2fSBjbGFzc05hbWU9XCJ0ZXh0LXByaW1hcnlcIiAvPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotMTEwMCBvdmVyZmxvdy15LWF1dG9cIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBtaW4taC1zY3JlZW4gcHgtNCBwdC00IHBiLTIwIHRleHQtY2VudGVyIHNtOmJsb2NrIHNtOnAtMFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB0cmFuc2l0aW9uLW9wYWNpdHlcIiBhcmlhLWhpZGRlbj1cInRydWVcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1ibGFjayBiZy1vcGFjaXR5LTUwXCI+PC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgXHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIHNtOmlubGluZS1ibG9jayBzbTphbGlnbi1taWRkbGUgc206aC1zY3JlZW5cIiBhcmlhLWhpZGRlbj1cInRydWVcIj4mIzgyMDM7PC9zcGFuPlxyXG4gICAgICAgIFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWJsb2NrIGFsaWduLWJvdHRvbSBiZy1zdXJmYWNlIHJvdW5kZWQtbGcgdGV4dC1sZWZ0IG92ZXJmbG93LWhpZGRlbiBzaGFkb3cteGwgdHJhbnNmb3JtIHRyYW5zaXRpb24tYWxsIHNtOm15LTggc206YWxpZ24tbWlkZGxlIHNtOm1heC13LWxnIHNtOnctZnVsbCBtZDptYXgtdy0yeGxcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS00IGJvcmRlci1iIGJvcmRlci1ib3JkZXIgZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC10ZXh0LXByaW1hcnlcIj5NZXJnZSBEdXBsaWNhdGUgQ29udGFjdHM8L2gzPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5IGhvdmVyOnRleHQtdGV4dC1wcmltYXJ5XCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJYXCIgc2l6ZT17MjB9IC8+XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS01XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtdGV4dC1zZWNvbmRhcnkgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgU2VsZWN0IHdoaWNoIGluZm9ybWF0aW9uIHRvIGtlZXAgZm9yIHRoZSBtZXJnZWQgY29udGFjdC5cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0zIGdhcC00IG1iLTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXY+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnlcIj5Db250YWN0IDE8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeVwiPkNvbnRhY3QgMjwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ib3JkZXIgcm91bmRlZC1sZyBkaXZpZGUteSBkaXZpZGUtYm9yZGVyXCI+XHJcbiAgICAgICAgICAgICAgICB7cmVuZGVyRmllbGRDb21wYXJpc29uKCdhdmF0YXInLCAnUHJvZmlsZSBQaWN0dXJlJywgY29udGFjdDE/LmF2YXRhciwgY29udGFjdDI/LmF2YXRhcil9XHJcbiAgICAgICAgICAgICAgICB7cmVuZGVyRmllbGRDb21wYXJpc29uKCdmaXJzdE5hbWUnLCAnRmlyc3QgTmFtZScsIGNvbnRhY3QxPy5maXJzdE5hbWUsIGNvbnRhY3QyPy5maXJzdE5hbWUpfVxyXG4gICAgICAgICAgICAgICAge3JlbmRlckZpZWxkQ29tcGFyaXNvbignbGFzdE5hbWUnLCAnTGFzdCBOYW1lJywgY29udGFjdDE/Lmxhc3ROYW1lLCBjb250YWN0Mj8ubGFzdE5hbWUpfVxyXG4gICAgICAgICAgICAgICAge3JlbmRlckZpZWxkQ29tcGFyaXNvbignZW1haWwnLCAnRW1haWwnLCBjb250YWN0MT8uZW1haWwsIGNvbnRhY3QyPy5lbWFpbCl9XHJcbiAgICAgICAgICAgICAgICB7cmVuZGVyRmllbGRDb21wYXJpc29uKCdwaG9uZScsICdQaG9uZScsIGNvbnRhY3QxPy5waG9uZSwgY29udGFjdDI/LnBob25lKX1cclxuICAgICAgICAgICAgICAgIHtyZW5kZXJGaWVsZENvbXBhcmlzb24oJ2NvbXBhbnknLCAnQ29tcGFueScsIGNvbnRhY3QxPy5jb21wYW55LCBjb250YWN0Mj8uY29tcGFueSl9XHJcbiAgICAgICAgICAgICAgICB7cmVuZGVyRmllbGRDb21wYXJpc29uKCdwb3NpdGlvbicsICdQb3NpdGlvbicsIGNvbnRhY3QxPy5wb3NpdGlvbiwgY29udGFjdDI/LnBvc2l0aW9uKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTZcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctcHJpbWFyeS01MCBib3JkZXIgYm9yZGVyLXByaW1hcnktMTAwIHJvdW5kZWQtbGcgcC00IHRleHQtc20gdGV4dC1wcmltYXJ5XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJJbmZvXCIgc2l6ZT17MTZ9IGNsYXNzTmFtZT1cIm1yLTIgbXQtMC41XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gbWItMVwiPkFkZGl0aW9uYWwgSW5mb3JtYXRpb248L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cD5UaGUgZm9sbG93aW5nIGRhdGEgd2lsbCBiZSBjb21iaW5lZCBmcm9tIGJvdGggY29udGFjdHM6PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImxpc3QtZGlzYyBsaXN0LWluc2lkZSBtdC0xIHNwYWNlLXktMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGk+VGFncyAoe21lcmdlZENvbnRhY3Q/LnRhZ3M/Lmxlbmd0aH0gdG90YWwpPC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxpPkRlYWxzICh7bWVyZ2VkQ29udGFjdD8uZGVhbHM/Lmxlbmd0aH0gdG90YWwpPC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxpPkFjdGl2aXRpZXMgKHttZXJnZWRDb250YWN0Py5hY3Rpdml0aWVzPy5sZW5ndGh9IHRvdGFsKTwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsaT5Ob3RlcyAod2lsbCBiZSBjb25jYXRlbmF0ZWQpPC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxpPlNvY2lhbCBwcm9maWxlcyAod2lsbCBiZSBtZXJnZWQpPC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS00IGJvcmRlci10IGJvcmRlci1ib3JkZXIgZmxleCBqdXN0aWZ5LWVuZCBzcGFjZS14LTNcIj5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbGcgdGV4dC10ZXh0LXNlY29uZGFyeSBob3Zlcjp0ZXh0LXRleHQtcHJpbWFyeSBob3ZlcjpiZy1zdXJmYWNlLWhvdmVyIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTE1MCBlYXNlLW91dFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBDYW5jZWxcclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbk1lcmdlKG1lcmdlZENvbnRhY3QpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5IGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlclwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiR2l0TWVyZ2VcIiBzaXplPXsxNn0gY2xhc3NOYW1lPVwibXItMlwiIC8+XHJcbiAgICAgICAgICAgICAgTWVyZ2UgQ29udGFjdHNcclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgTWVyZ2VEdXBsaWNhdGVzTW9kYWw7Il0sImZpbGUiOiJEOi9jdXJyZW50IHByb2plY3RzL2NsYXVkZS1jb2RlL3NyYy9wYWdlcy9jb250YWN0LW1hbmFnZW1lbnQvY29tcG9uZW50cy9NZXJnZUR1cGxpY2F0ZXNNb2RhbC5qc3gifQ==