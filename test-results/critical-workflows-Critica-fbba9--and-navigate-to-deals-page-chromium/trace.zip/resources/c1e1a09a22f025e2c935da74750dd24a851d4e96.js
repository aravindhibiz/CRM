import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/deal-management/components/DealActions.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/deal-management/components/DealActions.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import Icon from "/src/components/AppIcon.jsx";
const DealActions = ({ onSave, onDelete, onClone, onCreateTask, isSaving }) => {
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealActions.jsx:6:4", "data-component-path": "src\\pages\\deal-management\\components\\DealActions.jsx", "data-component-line": "6", "data-component-file": "DealActions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20flex-col%20sm%3Aflex-row%20items-stretch%20sm%3Aitems-center%20space-y-2%20sm%3Aspace-y-0%20sm%3Aspace-x-3%22%7D", className: "flex flex-col sm:flex-row items-stretch sm:items-center space-y-2 sm:space-y-0 sm:space-x-3", children: [
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealActions.jsx:8:6", "data-component-path": "src\\pages\\deal-management\\components\\DealActions.jsx", "data-component-line": "8", "data-component-file": "DealActions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20space-x-3%22%7D", className: "flex space-x-3", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          "data-component-id": "src\\pages\\deal-management\\components\\DealActions.jsx:9:8",
          "data-component-path": "src\\pages\\deal-management\\components\\DealActions.jsx",
          "data-component-line": "9",
          "data-component-file": "DealActions.jsx",
          "data-component-name": "button",
          "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22btn-primary%20disabled%3Aopacity-50%20disabled%3Acursor-not-allowed%20flex%20items-center%20space-x-2%22%7D",
          onClick: onSave,
          disabled: isSaving,
          className: "btn-primary disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2",
          children: isSaving ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealActions.jsx:16:14", "data-component-path": "src\\pages\\deal-management\\components\\DealActions.jsx", "data-component-line": "16", "data-component-file": "DealActions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22animate-spin%20rounded-full%20h-4%20w-4%20border-b-2%20border-white%22%7D", className: "animate-spin rounded-full h-4 w-4 border-b-2 border-white" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealActions.jsx",
              lineNumber: 16,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\DealActions.jsx:17:14", "data-component-path": "src\\pages\\deal-management\\components\\DealActions.jsx", "data-component-line": "17", "data-component-file": "DealActions.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Saving...%22%7D", children: "Saving..." }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealActions.jsx",
              lineNumber: 17,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealActions.jsx",
            lineNumber: 15,
            columnNumber: 11
          }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\deal-management\\components\\DealActions.jsx:21:14", "data-component-path": "src\\pages\\deal-management\\components\\DealActions.jsx", "data-component-line": "21", "data-component-file": "DealActions.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Save%22%7D", name: "Save", size: 16 }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealActions.jsx",
              lineNumber: 21,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\DealActions.jsx:22:14", "data-component-path": "src\\pages\\deal-management\\components\\DealActions.jsx", "data-component-line": "22", "data-component-file": "DealActions.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Save%20Deal%22%7D", children: "Save Deal" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealActions.jsx",
              lineNumber: 22,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealActions.jsx",
            lineNumber: 20,
            columnNumber: 11
          }, this)
        },
        void 0,
        false,
        {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealActions.jsx",
          lineNumber: 9,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          "data-component-id": "src\\pages\\deal-management\\components\\DealActions.jsx:27:8",
          "data-component-path": "src\\pages\\deal-management\\components\\DealActions.jsx",
          "data-component-line": "27",
          "data-component-file": "DealActions.jsx",
          "data-component-name": "button",
          "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22btn-secondary%20flex%20items-center%20space-x-2%22%7D",
          onClick: onCreateTask,
          className: "btn-secondary flex items-center space-x-2",
          children: [
            /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\deal-management\\components\\DealActions.jsx:31:10", "data-component-path": "src\\pages\\deal-management\\components\\DealActions.jsx", "data-component-line": "31", "data-component-file": "DealActions.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Plus%22%7D", name: "Plus", size: 16 }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealActions.jsx",
              lineNumber: 31,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\DealActions.jsx:32:10", "data-component-path": "src\\pages\\deal-management\\components\\DealActions.jsx", "data-component-line": "32", "data-component-file": "DealActions.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Create%20Task%22%7D", children: "Create Task" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealActions.jsx",
              lineNumber: 32,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealActions.jsx",
          lineNumber: 27,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealActions.jsx",
      lineNumber: 8,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealActions.jsx:37:6", "data-component-path": "src\\pages\\deal-management\\components\\DealActions.jsx", "data-component-line": "37", "data-component-file": "DealActions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20space-x-2%22%7D", className: "flex space-x-2", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          "data-component-id": "src\\pages\\deal-management\\components\\DealActions.jsx:38:8",
          "data-component-path": "src\\pages\\deal-management\\components\\DealActions.jsx",
          "data-component-line": "38",
          "data-component-file": "DealActions.jsx",
          "data-component-name": "button",
          "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%20px-4%20py-2%20border%20border-border%20rounded-lg%20text-text-secondary%20hover%3Atext-text-primary%20hover%3Abg-surface-hover%20transition-all%20duration-150%22%7D",
          onClick: onClone,
          className: "flex items-center space-x-2 px-4 py-2 border border-border rounded-lg text-text-secondary hover:text-text-primary hover:bg-surface-hover transition-all duration-150",
          title: "Clone Deal",
          children: [
            /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\deal-management\\components\\DealActions.jsx:43:10", "data-component-path": "src\\pages\\deal-management\\components\\DealActions.jsx", "data-component-line": "43", "data-component-file": "DealActions.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Copy%22%7D", name: "Copy", size: 16 }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealActions.jsx",
              lineNumber: 43,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\DealActions.jsx:44:10", "data-component-path": "src\\pages\\deal-management\\components\\DealActions.jsx", "data-component-line": "44", "data-component-file": "DealActions.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22hidden%20sm%3Ainline%22%2C%22textContent%22%3A%22Clone%22%7D", className: "hidden sm:inline", children: "Clone" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealActions.jsx",
              lineNumber: 44,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealActions.jsx",
          lineNumber: 38,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          "data-component-id": "src\\pages\\deal-management\\components\\DealActions.jsx:47:8",
          "data-component-path": "src\\pages\\deal-management\\components\\DealActions.jsx",
          "data-component-line": "47",
          "data-component-file": "DealActions.jsx",
          "data-component-name": "button",
          "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%20px-4%20py-2%20border%20border-error%20text-error%20rounded-lg%20hover%3Abg-error-50%20transition-all%20duration-150%22%7D",
          onClick: onDelete,
          className: "flex items-center space-x-2 px-4 py-2 border border-error text-error rounded-lg hover:bg-error-50 transition-all duration-150",
          title: "Delete Deal",
          children: [
            /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\deal-management\\components\\DealActions.jsx:52:10", "data-component-path": "src\\pages\\deal-management\\components\\DealActions.jsx", "data-component-line": "52", "data-component-file": "DealActions.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Trash2%22%7D", name: "Trash2", size: 16 }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealActions.jsx",
              lineNumber: 52,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\DealActions.jsx:53:10", "data-component-path": "src\\pages\\deal-management\\components\\DealActions.jsx", "data-component-line": "53", "data-component-file": "DealActions.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22hidden%20sm%3Ainline%22%2C%22textContent%22%3A%22Delete%22%7D", className: "hidden sm:inline", children: "Delete" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealActions.jsx",
              lineNumber: 53,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealActions.jsx",
          lineNumber: 47,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealActions.jsx",
      lineNumber: 37,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealActions.jsx",
    lineNumber: 6,
    columnNumber: 5
  }, this);
};
_c = DealActions;
export default DealActions;
var _c;
$RefreshReg$(_c, "DealActions");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/deal-management/components/DealActions.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/deal-management/components/DealActions.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBY1ksbUJBQ0UsY0FERjtBQWRaLE9BQU9BLG9CQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN6QixPQUFPQyxVQUFVO0FBRWpCLE1BQU1DLGNBQWNBLENBQUMsRUFBRUMsUUFBUUMsVUFBVUMsU0FBU0MsY0FBY0MsU0FBUyxNQUFNO0FBQzdFLFNBQ0UsdUJBQUMsa2VBQUksV0FBVSwrRkFFYjtBQUFBLDJCQUFDLGlZQUFJLFdBQVUsa0JBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBQ0MsU0FBU0o7QUFBQUEsVUFDVCxVQUFVSTtBQUFBQSxVQUNWLFdBQVU7QUFBQSxVQUVUQSxxQkFDQyxtQ0FDRTtBQUFBLG1DQUFDLHViQUFJLFdBQVUsK0RBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkU7QUFBQSxZQUMzRSx1QkFBQyxrWUFBSyx5QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFlO0FBQUEsZUFGakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQSxJQUVBLG1DQUNFO0FBQUEsbUNBQUMsb1hBQUssTUFBSyxRQUFPLE1BQU0sTUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkI7QUFBQSxZQUMzQix1QkFBQyxvWUFBSyx5QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFlO0FBQUEsZUFGakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBO0FBQUEsUUFkSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFnQkE7QUFBQSxNQUVBO0FBQUEsUUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFDQyxTQUFTRDtBQUFBQSxVQUNULFdBQVU7QUFBQSxVQUVWO0FBQUEsbUNBQUMsb1hBQUssTUFBSyxRQUFPLE1BQU0sTUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkI7QUFBQSxZQUMzQix1QkFBQyxzWUFBSywyQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQjtBQUFBO0FBQUE7QUFBQSxRQUxuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNQTtBQUFBLFNBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwQkE7QUFBQSxJQUdBLHVCQUFDLG1ZQUFJLFdBQVUsa0JBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBQ0MsU0FBU0Q7QUFBQUEsVUFDVCxXQUFVO0FBQUEsVUFDVixPQUFNO0FBQUEsVUFFTjtBQUFBLG1DQUFDLG9YQUFLLE1BQUssUUFBTyxNQUFNLE1BQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJCO0FBQUEsWUFDM0IsdUJBQUMsNmFBQUssV0FBVSxvQkFBbUIscUJBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdDO0FBQUE7QUFBQTtBQUFBLFFBTjFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9BO0FBQUEsTUFFQTtBQUFBLFFBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBQ0MsU0FBU0Q7QUFBQUEsVUFDVCxXQUFVO0FBQUEsVUFDVixPQUFNO0FBQUEsVUFFTjtBQUFBLG1DQUFDLHNYQUFLLE1BQUssVUFBUyxNQUFNLE1BQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZCO0FBQUEsWUFDN0IsdUJBQUMsOGFBQUssV0FBVSxvQkFBbUIsc0JBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlDO0FBQUE7QUFBQTtBQUFBLFFBTjNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9BO0FBQUEsU0FqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtCQTtBQUFBLE9BakRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrREE7QUFFSjtBQUFFSSxLQXRESU47QUF3RE4sZUFBZUE7QUFBWSxJQUFBTTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJJY29uIiwiRGVhbEFjdGlvbnMiLCJvblNhdmUiLCJvbkRlbGV0ZSIsIm9uQ2xvbmUiLCJvbkNyZWF0ZVRhc2siLCJpc1NhdmluZyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiRGVhbEFjdGlvbnMuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCBJY29uIGZyb20gJ2NvbXBvbmVudHMvQXBwSWNvbic7XHJcblxyXG5jb25zdCBEZWFsQWN0aW9ucyA9ICh7IG9uU2F2ZSwgb25EZWxldGUsIG9uQ2xvbmUsIG9uQ3JlYXRlVGFzaywgaXNTYXZpbmcgfSkgPT4ge1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgaXRlbXMtc3RyZXRjaCBzbTppdGVtcy1jZW50ZXIgc3BhY2UteS0yIHNtOnNwYWNlLXktMCBzbTpzcGFjZS14LTNcIj5cclxuICAgICAgey8qIFByaW1hcnkgQWN0aW9ucyAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHNwYWNlLXgtM1wiPlxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIG9uQ2xpY2s9e29uU2F2ZX1cclxuICAgICAgICAgIGRpc2FibGVkPXtpc1NhdmluZ31cclxuICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5IGRpc2FibGVkOm9wYWNpdHktNTAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkIGZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMlwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge2lzU2F2aW5nID8gKFxyXG4gICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluIHJvdW5kZWQtZnVsbCBoLTQgdy00IGJvcmRlci1iLTIgYm9yZGVyLXdoaXRlXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgPHNwYW4+U2F2aW5nLi4uPC9zcGFuPlxyXG4gICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgPEljb24gbmFtZT1cIlNhdmVcIiBzaXplPXsxNn0gLz5cclxuICAgICAgICAgICAgICA8c3Bhbj5TYXZlIERlYWw8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgb25DbGljaz17b25DcmVhdGVUYXNrfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLXNlY29uZGFyeSBmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTJcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxJY29uIG5hbWU9XCJQbHVzXCIgc2l6ZT17MTZ9IC8+XHJcbiAgICAgICAgICA8c3Bhbj5DcmVhdGUgVGFzazwvc3Bhbj5cclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogU2Vjb25kYXJ5IEFjdGlvbnMgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBzcGFjZS14LTJcIj5cclxuICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICBvbkNsaWNrPXtvbkNsb25lfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yIHB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLWxnIHRleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC10ZXh0LXByaW1hcnkgaG92ZXI6Ymctc3VyZmFjZS1ob3ZlciB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0xNTBcIlxyXG4gICAgICAgICAgdGl0bGU9XCJDbG9uZSBEZWFsXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8SWNvbiBuYW1lPVwiQ29weVwiIHNpemU9ezE2fSAvPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIHNtOmlubGluZVwiPkNsb25lPC9zcGFuPlxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICBvbkNsaWNrPXtvbkRlbGV0ZX1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMiBweC00IHB5LTIgYm9yZGVyIGJvcmRlci1lcnJvciB0ZXh0LWVycm9yIHJvdW5kZWQtbGcgaG92ZXI6YmctZXJyb3ItNTAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMTUwXCJcclxuICAgICAgICAgIHRpdGxlPVwiRGVsZXRlIERlYWxcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxJY29uIG5hbWU9XCJUcmFzaDJcIiBzaXplPXsxNn0gLz5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpZGRlbiBzbTppbmxpbmVcIj5EZWxldGU8L3NwYW4+XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IERlYWxBY3Rpb25zOyJdLCJmaWxlIjoiRDovY3VycmVudCBwcm9qZWN0cy9jbGF1ZGUtY29kZS9zcmMvcGFnZXMvZGVhbC1tYW5hZ2VtZW50L2NvbXBvbmVudHMvRGVhbEFjdGlvbnMuanN4In0=