import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ThemeToggle.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/components/ThemeToggle.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useContext = __vite__cjsImport3_react["useContext"];
import { ThemeContext } from "/src/contexts/ThemeContext.jsx";
import Icon from "/src/components/AppIcon.jsx";
const ThemeToggle = () => {
  _s();
  const { theme, toggleTheme } = useContext(ThemeContext);
  return /* @__PURE__ */ jsxDEV(
    "button",
    {
      "data-component-id": "src\\components\\ThemeToggle.jsx:10:4",
      "data-component-path": "src\\components\\ThemeToggle.jsx",
      "data-component-line": "10",
      "data-component-file": "ThemeToggle.jsx",
      "data-component-name": "button",
      "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22p-2%20text-text-secondary%20hover%3Atext-text-primary%20transition-colors%20duration-150%20ease-smooth%22%7D",
      onClick: toggleTheme,
      className: "p-2 text-text-secondary hover:text-text-primary transition-colors duration-150 ease-smooth",
      title: theme === "light" ? "Switch to Dark Mode" : "Switch to Light Mode",
      children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\components\\ThemeToggle.jsx:15:6", "data-component-path": "src\\components\\ThemeToggle.jsx", "data-component-line": "15", "data-component-file": "ThemeToggle.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%7D", name: theme === "light" ? "Moon" : "Sun", size: 20 }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/components/ThemeToggle.jsx",
        lineNumber: 15,
        columnNumber: 7
      }, this)
    },
    void 0,
    false,
    {
      fileName: "D:/current projects/claude-code/src/components/ThemeToggle.jsx",
      lineNumber: 10,
      columnNumber: 5
    },
    this
  );
};
_s(ThemeToggle, "EFRZgBTSn7R64yv9sbxwgPkwfJQ=");
_c = ThemeToggle;
export default ThemeToggle;
var _c;
$RefreshReg$(_c, "ThemeToggle");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/components/ThemeToggle.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/components/ThemeToggle.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBY007Ozs7Ozs7Ozs7Ozs7Ozs7O0FBYk4sT0FBT0EsU0FBU0Msa0JBQWtCO0FBQ2xDLFNBQVNDLG9CQUFvQjtBQUM3QixPQUFPQyxVQUFVO0FBRWpCLE1BQU1DLGNBQWNBLE1BQU07QUFBQUMsS0FBQTtBQUN4QixRQUFNLEVBQUVDLE9BQU9DLFlBQVksSUFBSU4sV0FBV0MsWUFBWTtBQUV0RCxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFDQyxTQUFTSztBQUFBQSxNQUNULFdBQVU7QUFBQSxNQUNWLE9BQU9ELFVBQVUsVUFBVSx3QkFBd0I7QUFBQSxNQUVuRCxpQ0FBQyx5U0FBSyxNQUFNQSxVQUFVLFVBQVUsU0FBUyxPQUFPLE1BQU0sTUFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5RDtBQUFBO0FBQUEsSUFMM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUE7QUFFSjtBQUFFRCxHQVpJRCxhQUFXO0FBQUFJLEtBQVhKO0FBY04sZUFBZUE7QUFBWSxJQUFBSTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJ1c2VDb250ZXh0IiwiVGhlbWVDb250ZXh0IiwiSWNvbiIsIlRoZW1lVG9nZ2xlIiwiX3MiLCJ0aGVtZSIsInRvZ2dsZVRoZW1lIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJUaGVtZVRvZ2dsZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiXHJcbmltcG9ydCBSZWFjdCwgeyB1c2VDb250ZXh0IH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBUaGVtZUNvbnRleHQgfSBmcm9tICcuLi9jb250ZXh0cy9UaGVtZUNvbnRleHQnO1xyXG5pbXBvcnQgSWNvbiBmcm9tICcuL0FwcEljb24nO1xyXG5cclxuY29uc3QgVGhlbWVUb2dnbGUgPSAoKSA9PiB7XHJcbiAgY29uc3QgeyB0aGVtZSwgdG9nZ2xlVGhlbWUgfSA9IHVzZUNvbnRleHQoVGhlbWVDb250ZXh0KTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxidXR0b25cclxuICAgICAgb25DbGljaz17dG9nZ2xlVGhlbWV9XHJcbiAgICAgIGNsYXNzTmFtZT1cInAtMiB0ZXh0LXRleHQtc2Vjb25kYXJ5IGhvdmVyOnRleHQtdGV4dC1wcmltYXJ5IHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MCBlYXNlLXNtb290aFwiXHJcbiAgICAgIHRpdGxlPXt0aGVtZSA9PT0gJ2xpZ2h0JyA/ICdTd2l0Y2ggdG8gRGFyayBNb2RlJyA6ICdTd2l0Y2ggdG8gTGlnaHQgTW9kZSd9XHJcbiAgICA+XHJcbiAgICAgIDxJY29uIG5hbWU9e3RoZW1lID09PSAnbGlnaHQnID8gJ01vb24nIDogJ1N1bid9IHNpemU9ezIwfSAvPlxyXG4gICAgPC9idXR0b24+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFRoZW1lVG9nZ2xlO1xyXG4iXSwiZmlsZSI6IkQ6L2N1cnJlbnQgcHJvamVjdHMvY2xhdWRlLWNvZGUvc3JjL2NvbXBvbmVudHMvVGhlbWVUb2dnbGUuanN4In0=