import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/deal-management/components/DocumentsSection.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useRef = __vite__cjsImport3_react["useRef"];
import Icon from "/src/components/AppIcon.jsx";
import dealDocumentsService from "/src/services/dealDocumentsService.js";
const DocumentsSection = ({
  documents = [],
  loading = false,
  dealId,
  onUploadDocument,
  onDeleteDocument
}) => {
  _s();
  const [uploading, setUploading] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef(null);
  const documentTypes = [
    { value: "proposal", label: "Proposal", icon: "FileText", color: "text-blue-600" },
    { value: "contract", label: "Contract", icon: "FileCheck", color: "text-green-600" },
    { value: "presentation", label: "Presentation", icon: "Presentation", color: "text-purple-600" },
    { value: "other", label: "Other", icon: "File", color: "text-gray-600" }
  ];
  const getFileIcon = (filename) => {
    const extension = dealDocumentsService?.getFileExtension(filename);
    const iconName = dealDocumentsService?.getFileIcon(filename);
    return iconName;
  };
  const handleFileSelect = (files) => {
    if (!files || files?.length === 0)
      return;
    Array.from(files)?.forEach((file) => {
      handleUpload(file);
    });
  };
  const handleUpload = async (file, documentType = "other") => {
    if (!dealId || !file)
      return;
    const maxSize = 10 * 1024 * 1024;
    if (file?.size > maxSize) {
      alert("File size must be less than 10MB");
      return;
    }
    setUploading(true);
    try {
      await onUploadDocument?.(file, documentType);
    } catch (err) {
      alert("Failed to upload document: " + (err?.message || "Unknown error"));
    } finally {
      setUploading(false);
    }
  };
  const handleDelete = async (doc) => {
    if (!window.confirm(`Are you sure you want to delete "${doc?.name}"?`)) {
      return;
    }
    try {
      await onDeleteDocument?.(doc?.id, doc?.fileUrl);
    } catch (err) {
      alert("Failed to delete document: " + (err?.message || "Unknown error"));
    }
  };
  const handleDownload = async (doc) => {
    try {
      const url = await dealDocumentsService?.getDocumentUrl(doc?.fileUrl);
      const link = document.createElement("a");
      link.href = url;
      link.download = doc?.name;
      document.body?.appendChild(link);
      link?.click();
      document.body?.removeChild(link);
    } catch (err) {
      alert("Failed to download document: " + (err?.message || "Unknown error"));
    }
  };
  const handleDrop = (e) => {
    e?.preventDefault();
    setDragOver(false);
    const files = e?.dataTransfer?.files;
    handleFileSelect(files);
  };
  const handleDragOver = (e) => {
    e?.preventDefault();
    setDragOver(true);
  };
  const handleDragLeave = (e) => {
    e?.preventDefault();
    setDragOver(false);
  };
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date?.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: date?.getFullYear() !== (/* @__PURE__ */ new Date())?.getFullYear() ? "numeric" : void 0
    });
  };
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:111:4", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "111", "data-component-file": "DocumentsSection.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20rounded-lg%20border%20border-border%22%7D", className: "bg-surface rounded-lg border border-border", children: [
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:113:6", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "113", "data-component-file": "DocumentsSection.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22p-6%20border-b%20border-border%22%7D", className: "p-6 border-b border-border", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:114:8", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "114", "data-component-file": "DocumentsSection.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:115:10", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "115", "data-component-file": "DocumentsSection.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%2C%22textContent%22%3A%22Documents%22%7D", className: "text-lg font-semibold text-text-primary", children: "Documents" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
        lineNumber: 115,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:116:10",
          "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx",
          "data-component-line": "116",
          "data-component-file": "DocumentsSection.jsx",
          "data-component-name": "button",
          "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%20px-3%20py-1%20bg-primary%20text-white%20rounded-lg%20hover%3Abg-primary-600%20disabled%3Aopacity-50%20disabled%3Acursor-not-allowed%20transition-colors%20duration-150%20text-sm%22%7D",
          onClick: () => fileInputRef?.current?.click(),
          disabled: uploading,
          className: "flex items-center space-x-2 px-3 py-1 bg-primary text-white rounded-lg hover:bg-primary-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-150 text-sm",
          children: [
            /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:121:12", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "121", "data-component-file": "DocumentsSection.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Upload%22%7D", name: "Upload", size: 16 }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
              lineNumber: 121,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:122:12", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "122", "data-component-file": "DocumentsSection.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Upload%22%7D", children: "Upload" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
              lineNumber: 122,
              columnNumber: 13
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
          lineNumber: 116,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
      lineNumber: 114,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
      lineNumber: 113,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:127:6", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "127", "data-component-file": "DocumentsSection.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22p-6%20border-b%20border-border%22%7D", className: "p-6 border-b border-border", children: [
      /* @__PURE__ */ jsxDEV(
        "div",
        {
          "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:128:8",
          "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx",
          "data-component-line": "128",
          "data-component-file": "DocumentsSection.jsx",
          "data-component-name": "div",
          "data-component-content": "%7B%22elementName%22%3A%22div%22%7D",
          onDrop: handleDrop,
          onDragOver: handleDragOver,
          onDragLeave: handleDragLeave,
          onClick: () => fileInputRef?.current?.click(),
          className: `border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors duration-150 ${dragOver ? "border-primary bg-primary-50" : "border-border hover:border-border-hover hover:bg-background"}`,
          children: [
            /* @__PURE__ */ jsxDEV(
              Icon,
              {
                "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:138:10",
                "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx",
                "data-component-line": "138",
                "data-component-file": "DocumentsSection.jsx",
                "data-component-name": "Icon",
                "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Upload%22%7D",
                name: "Upload",
                size: 24,
                className: `mx-auto mb-2 ${dragOver ? "text-primary" : "text-text-tertiary"}`
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
                lineNumber: 138,
                columnNumber: 11
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:143:10", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "143", "data-component-file": "DocumentsSection.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22Drop%20files%20here%20or%20click%20to%20browse%22%7D", className: "text-sm text-text-secondary", children: "Drop files here or click to browse" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
              lineNumber: 143,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:146:10", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "146", "data-component-file": "DocumentsSection.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-xs%20text-text-tertiary%20mt-1%22%2C%22textContent%22%3A%22Maximum%20file%20size%3A%2010MB%22%7D", className: "text-xs text-text-tertiary mt-1", children: "Maximum file size: 10MB" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
              lineNumber: 146,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
          lineNumber: 128,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:151:8",
          "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx",
          "data-component-line": "151",
          "data-component-file": "DocumentsSection.jsx",
          "data-component-name": "input",
          "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22file%22%2C%22className%22%3A%22hidden%22%7D",
          ref: fileInputRef,
          type: "file",
          multiple: true,
          onChange: (e) => handleFileSelect(e?.target?.files),
          className: "hidden",
          accept: ".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.jpg,.jpeg,.png,.gif,.txt,.zip,.rar"
        },
        void 0,
        false,
        {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
          lineNumber: 151,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
      lineNumber: 127,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:161:6", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "161", "data-component-file": "DocumentsSection.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22p-6%22%7D", className: "p-6", children: [
      uploading && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:163:8", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "163", "data-component-file": "DocumentsSection.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-3%20p-3%20bg-blue-50%20border%20border-blue-200%20rounded-lg%20mb-4%22%7D", className: "flex items-center space-x-3 p-3 bg-blue-50 border border-blue-200 rounded-lg mb-4", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:164:12", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "164", "data-component-file": "DocumentsSection.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22animate-spin%20rounded-full%20h-4%20w-4%20border-b-2%20border-blue-600%22%7D", className: "animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
          lineNumber: 164,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:165:12", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "165", "data-component-file": "DocumentsSection.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-blue-800%22%2C%22textContent%22%3A%22Uploading%20document...%22%7D", className: "text-sm text-blue-800", children: "Uploading document..." }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
          lineNumber: 165,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
        lineNumber: 163,
        columnNumber: 9
      }, this),
      loading ? /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:170:8", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "170", "data-component-file": "DocumentsSection.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-center%20py-8%22%7D", className: "flex items-center justify-center py-8", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:171:12", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "171", "data-component-file": "DocumentsSection.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22animate-spin%20rounded-full%20h-6%20w-6%20border-b-2%20border-primary%22%7D", className: "animate-spin rounded-full h-6 w-6 border-b-2 border-primary" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
          lineNumber: 171,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:172:12", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "172", "data-component-file": "DocumentsSection.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22ml-2%20text-text-secondary%22%2C%22textContent%22%3A%22Loading%20documents...%22%7D", className: "ml-2 text-text-secondary", children: "Loading documents..." }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
          lineNumber: 172,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
        lineNumber: 170,
        columnNumber: 9
      }, this) : documents?.length === 0 ? /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:175:8", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "175", "data-component-file": "DocumentsSection.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-center%20py-8%22%7D", className: "text-center py-8", children: [
        /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:176:12", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "176", "data-component-file": "DocumentsSection.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22FileText%22%2C%22className%22%3A%22text-text-tertiary%20mx-auto%20mb-2%22%7D", name: "FileText", size: 32, className: "text-text-tertiary mx-auto mb-2" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
          lineNumber: 176,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:177:12", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "177", "data-component-file": "DocumentsSection.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%22%2C%22textContent%22%3A%22No%20documents%20uploaded%22%7D", className: "text-text-secondary", children: "No documents uploaded" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
          lineNumber: 177,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:178:12", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "178", "data-component-file": "DocumentsSection.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%20text-text-tertiary%20mt-1%22%2C%22textContent%22%3A%22Upload%20your%20first%20document%20to%20get%20started%22%7D", className: "text-sm text-text-tertiary mt-1", children: "Upload your first document to get started" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
          lineNumber: 178,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
        lineNumber: 175,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:181:8", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "181", "data-component-file": "DocumentsSection.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-3%22%7D", className: "space-y-3", children: documents?.map((doc) => {
        const iconName = getFileIcon(doc?.name);
        return /* @__PURE__ */ jsxDEV(
          "div",
          {
            "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:186:14",
            "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx",
            "data-component-line": "186",
            "data-component-file": "DocumentsSection.jsx",
            "data-component-name": "div",
            "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-3%20p-3%20bg-background%20rounded-lg%20border%20border-border%20hover%3Aborder-border-hover%20transition-colors%20duration-150%22%7D",
            className: "flex items-center space-x-3 p-3 bg-background rounded-lg border border-border hover:border-border-hover transition-colors duration-150",
            children: [
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:191:18", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "191", "data-component-file": "DocumentsSection.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-10%20h-10%20bg-blue-100%20rounded-lg%20flex%20items-center%20justify-center%22%7D", className: "w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:192:20", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "192", "data-component-file": "DocumentsSection.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22%5Bvar%3AiconName%5D%22%2C%22className%22%3A%22text-blue-600%22%7D", name: iconName, size: 20, className: "text-blue-600" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
                lineNumber: 192,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
                lineNumber: 191,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:195:18", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "195", "data-component-file": "DocumentsSection.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex-1%20min-w-0%22%7D", className: "flex-1 min-w-0", children: [
                /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:196:20", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "196", "data-component-file": "DocumentsSection.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%22%7D", className: "flex items-center space-x-2", children: [
                  /* @__PURE__ */ jsxDEV("h4", { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:197:22", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "197", "data-component-file": "DocumentsSection.jsx", "data-component-name": "h4", "data-component-content": "%7B%22elementName%22%3A%22h4%22%2C%22className%22%3A%22text-sm%20font-medium%20text-text-primary%20truncate%22%7D", className: "text-sm font-medium text-text-primary truncate", children: doc?.name }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
                    lineNumber: 197,
                    columnNumber: 23
                  }, this),
                  doc?.documentType && doc?.documentType !== "other" && /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:201:20", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "201", "data-component-file": "DocumentsSection.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22px-2%20py-0.5%20bg-gray-100%20text-gray-800%20text-xs%20rounded-full%22%7D", className: "px-2 py-0.5 bg-gray-100 text-gray-800 text-xs rounded-full", children: documentTypes?.find((t) => t?.value === doc?.documentType)?.label || doc?.documentType }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
                    lineNumber: 201,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
                  lineNumber: 196,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:206:20", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "206", "data-component-file": "DocumentsSection.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%20text-xs%20text-text-tertiary%22%7D", className: "flex items-center space-x-2 text-xs text-text-tertiary", children: [
                  /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:207:22", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "207", "data-component-file": "DocumentsSection.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: doc?.size }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
                    lineNumber: 207,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:208:22", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "208", "data-component-file": "DocumentsSection.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22%E2%80%A2%22%7D", children: "•" }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
                    lineNumber: 208,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:209:22", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "209", "data-component-file": "DocumentsSection.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: doc?.uploadedBy }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
                    lineNumber: 209,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:210:22", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "210", "data-component-file": "DocumentsSection.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22%E2%80%A2%22%7D", children: "•" }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
                    lineNumber: 210,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:211:22", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "211", "data-component-file": "DocumentsSection.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: formatDate(doc?.uploadedAt) }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
                    lineNumber: 211,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
                  lineNumber: 206,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
                lineNumber: 195,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:215:18", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "215", "data-component-file": "DocumentsSection.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-1%22%7D", className: "flex items-center space-x-1", children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:216:20",
                    "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx",
                    "data-component-line": "216",
                    "data-component-file": "DocumentsSection.jsx",
                    "data-component-name": "button",
                    "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22p-2%20text-text-tertiary%20hover%3Atext-primary%20hover%3Abg-primary-50%20rounded-lg%20transition-colors%20duration-150%22%7D",
                    onClick: () => handleDownload(doc),
                    className: "p-2 text-text-tertiary hover:text-primary hover:bg-primary-50 rounded-lg transition-colors duration-150",
                    title: "Download",
                    children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:221:22", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "221", "data-component-file": "DocumentsSection.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Download%22%7D", name: "Download", size: 16 }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
                      lineNumber: 221,
                      columnNumber: 23
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
                    lineNumber: 216,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:223:20",
                    "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx",
                    "data-component-line": "223",
                    "data-component-file": "DocumentsSection.jsx",
                    "data-component-name": "button",
                    "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22p-2%20text-text-tertiary%20hover%3Atext-error%20hover%3Abg-error-50%20rounded-lg%20transition-colors%20duration-150%22%7D",
                    onClick: () => handleDelete(doc),
                    className: "p-2 text-text-tertiary hover:text-error hover:bg-error-50 rounded-lg transition-colors duration-150",
                    title: "Delete",
                    children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\deal-management\\components\\DocumentsSection.jsx:228:22", "data-component-path": "src\\pages\\deal-management\\components\\DocumentsSection.jsx", "data-component-line": "228", "data-component-file": "DocumentsSection.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Trash2%22%7D", name: "Trash2", size: 16 }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
                      lineNumber: 228,
                      columnNumber: 23
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
                    lineNumber: 223,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
                lineNumber: 215,
                columnNumber: 19
              }, this)
            ]
          },
          doc?.id,
          true,
          {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
            lineNumber: 186,
            columnNumber: 15
          },
          this
        );
      }) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
        lineNumber: 181,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
      lineNumber: 161,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx",
    lineNumber: 111,
    columnNumber: 5
  }, this);
};
_s(DocumentsSection, "8z4+Tvn4vGUAYPdMB+aw5ClA6bI=");
_c = DocumentsSection;
export default DocumentsSection;
var _c;
$RefreshReg$(_c, "DocumentsSection");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/deal-management/components/DocumentsSection.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0hVOzJCQWxIVjtBQUFnQkEsTUFBVUMsY0FBYyxPQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQy9DLE9BQU9DLFVBQVU7QUFDakIsT0FBT0MsMEJBQTBCO0FBRWpDLE1BQU1DLG1CQUFtQkEsQ0FBQztBQUFBLEVBQ3hCQyxZQUFZO0FBQUEsRUFDWkMsVUFBVTtBQUFBLEVBQ1ZDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ0YsTUFBTTtBQUFBQyxLQUFBO0FBQ0osUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUlaLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUNhLFVBQVVDLFdBQVcsSUFBSWQsU0FBUyxLQUFLO0FBQzlDLFFBQU1lLGVBQWVkLE9BQU8sSUFBSTtBQUVoQyxRQUFNZSxnQkFBZ0I7QUFBQSxJQUNwQixFQUFFQyxPQUFPLFlBQVlDLE9BQU8sWUFBWUMsTUFBTSxZQUFZQyxPQUFPLGdCQUFnQjtBQUFBLElBQ2pGLEVBQUVILE9BQU8sWUFBWUMsT0FBTyxZQUFZQyxNQUFNLGFBQWFDLE9BQU8saUJBQWlCO0FBQUEsSUFDbkYsRUFBRUgsT0FBTyxnQkFBZ0JDLE9BQU8sZ0JBQWdCQyxNQUFNLGdCQUFnQkMsT0FBTyxrQkFBa0I7QUFBQSxJQUMvRixFQUFFSCxPQUFPLFNBQVNDLE9BQU8sU0FBU0MsTUFBTSxRQUFRQyxPQUFPLGdCQUFnQjtBQUFBLEVBQUM7QUFHMUUsUUFBTUMsY0FBY0EsQ0FBQ0MsYUFBYTtBQUNoQyxVQUFNQyxZQUFZcEIsc0JBQXNCcUIsaUJBQWlCRixRQUFRO0FBQ2pFLFVBQU1HLFdBQVd0QixzQkFBc0JrQixZQUFZQyxRQUFRO0FBQzNELFdBQU9HO0FBQUFBLEVBQ1Q7QUFFQSxRQUFNQyxtQkFBbUJBLENBQUNDLFVBQVU7QUFDbEMsUUFBSSxDQUFDQSxTQUFTQSxPQUFPQyxXQUFXO0FBQUc7QUFFbkNDLFVBQU1DLEtBQUtILEtBQUssR0FBR0ksUUFBUSxDQUFBQyxTQUFRO0FBQ2pDQyxtQkFBYUQsSUFBSTtBQUFBLElBQ25CLENBQUM7QUFBQSxFQUNIO0FBRUEsUUFBTUMsZUFBZSxPQUFPRCxNQUFNRSxlQUFlLFlBQVk7QUFDM0QsUUFBSSxDQUFDM0IsVUFBVSxDQUFDeUI7QUFBTTtBQUd0QixVQUFNRyxVQUFVLEtBQUssT0FBTztBQUM1QixRQUFJSCxNQUFNSSxPQUFPRCxTQUFTO0FBQ3hCRSxZQUFNLGtDQUFrQztBQUN4QztBQUFBLElBQ0Y7QUFFQXpCLGlCQUFhLElBQUk7QUFDakIsUUFBSTtBQUNGLFlBQU1KLG1CQUFtQndCLE1BQU1FLFlBQVk7QUFBQSxJQUM3QyxTQUFTSSxLQUFLO0FBQ1pELFlBQU0saUNBQWlDQyxLQUFLQyxXQUFXLGdCQUFnQjtBQUFBLElBQ3pFLFVBQUM7QUFDQzNCLG1CQUFhLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNNEIsZUFBZSxPQUFPQyxRQUFRO0FBQ2xDLFFBQUksQ0FBQ0MsT0FBT0MsUUFBUSxvQ0FBb0NGLEtBQUtHLElBQUksSUFBSSxHQUFHO0FBQ3RFO0FBQUEsSUFDRjtBQUVBLFFBQUk7QUFDRixZQUFNbkMsbUJBQW1CZ0MsS0FBS0ksSUFBSUosS0FBS0ssT0FBTztBQUFBLElBQ2hELFNBQVNSLEtBQUs7QUFDWkQsWUFBTSxpQ0FBaUNDLEtBQUtDLFdBQVcsZ0JBQWdCO0FBQUEsSUFDekU7QUFBQSxFQUNGO0FBRUEsUUFBTVEsaUJBQWlCLE9BQU9OLFFBQVE7QUFDcEMsUUFBSTtBQUNGLFlBQU1PLE1BQU0sTUFBTTdDLHNCQUFzQjhDLGVBQWVSLEtBQUtLLE9BQU87QUFDbkUsWUFBTUksT0FBT0MsU0FBU0MsY0FBYyxHQUFHO0FBQ3ZDRixXQUFLRyxPQUFPTDtBQUNaRSxXQUFLSSxXQUFXYixLQUFLRztBQUNyQk8sZUFBU0ksTUFBTUMsWUFBWU4sSUFBSTtBQUMvQkEsWUFBTU8sTUFBTTtBQUNaTixlQUFTSSxNQUFNRyxZQUFZUixJQUFJO0FBQUEsSUFDakMsU0FBU1osS0FBSztBQUNaRCxZQUFNLG1DQUFtQ0MsS0FBS0MsV0FBVyxnQkFBZ0I7QUFBQSxJQUMzRTtBQUFBLEVBQ0Y7QUFFQSxRQUFNb0IsYUFBYUEsQ0FBQ0MsTUFBTTtBQUN4QkEsT0FBR0MsZUFBZTtBQUNsQi9DLGdCQUFZLEtBQUs7QUFFakIsVUFBTWEsUUFBUWlDLEdBQUdFLGNBQWNuQztBQUMvQkQscUJBQWlCQyxLQUFLO0FBQUEsRUFDeEI7QUFFQSxRQUFNb0MsaUJBQWlCQSxDQUFDSCxNQUFNO0FBQzVCQSxPQUFHQyxlQUFlO0FBQ2xCL0MsZ0JBQVksSUFBSTtBQUFBLEVBQ2xCO0FBRUEsUUFBTWtELGtCQUFrQkEsQ0FBQ0osTUFBTTtBQUM3QkEsT0FBR0MsZUFBZTtBQUNsQi9DLGdCQUFZLEtBQUs7QUFBQSxFQUNuQjtBQUVBLFFBQU1tRCxhQUFhQSxDQUFDQyxlQUFlO0FBQ2pDLFVBQU1DLE9BQU8sSUFBSUMsS0FBS0YsVUFBVTtBQUNoQyxXQUFPQyxNQUFNRSxtQkFBbUIsU0FBUztBQUFBLE1BQ3ZDQyxPQUFPO0FBQUEsTUFDUEMsS0FBSztBQUFBLE1BQ0xDLE1BQU1MLE1BQU1NLFlBQVksT0FBTSxvQkFBSUwsS0FBSyxJQUFHSyxZQUFZLElBQUksWUFBWUM7QUFBQUEsSUFDeEUsQ0FBQztBQUFBLEVBQ0g7QUFFQSxTQUNFLHVCQUFDLG9iQUFJLFdBQVUsOENBRWI7QUFBQSwyQkFBQyxrYUFBSSxXQUFVLDhCQUNiLGlDQUFDLHlhQUFJLFdBQVUscUNBQ2I7QUFBQSw2QkFBQyxtZEFBRyxXQUFVLDJDQUEwQyx5QkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRTtBQUFBLE1BQ2pFO0FBQUEsUUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFDQyxTQUFTLE1BQU0zRCxjQUFjNEQsU0FBU2xCLE1BQU07QUFBQSxVQUM1QyxVQUFVOUM7QUFBQUEsVUFDVixXQUFVO0FBQUEsVUFFVjtBQUFBLG1DQUFDLHVZQUFLLE1BQUssVUFBUyxNQUFNLE1BQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZCO0FBQUEsWUFDN0IsdUJBQUMsZ1pBQUssc0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBWTtBQUFBO0FBQUE7QUFBQSxRQU5kO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9BO0FBQUEsU0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUEsS0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUE7QUFBQSxJQUVBLHVCQUFDLGthQUFJLFdBQVUsOEJBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBQ0MsUUFBUWdEO0FBQUFBLFVBQ1IsWUFBWUk7QUFBQUEsVUFDWixhQUFhQztBQUFBQSxVQUNiLFNBQVMsTUFBTWpELGNBQWM0RCxTQUFTbEIsTUFBTTtBQUFBLFVBQzVDLFdBQVcsbUdBQ1Q1QyxXQUNJLGlDQUFnQyw2REFBNkQ7QUFBQSxVQUduRztBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQU07QUFBQSxnQkFDTixXQUFXLGdCQUFnQkEsV0FBVyxpQkFBaUIsb0JBQW9CO0FBQUE7QUFBQSxjQUg3RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFHZ0Y7QUFBQSxZQUVoRix1QkFBQyx1ZUFBRSxXQUFVLCtCQUE4QixrREFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsOGRBQUUsV0FBVSxtQ0FBa0MsdUNBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQTtBQUFBO0FBQUEsUUFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BcUJBO0FBQUEsTUFFQTtBQUFBLFFBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBQ0MsS0FBS0U7QUFBQUEsVUFDTCxNQUFLO0FBQUEsVUFDTDtBQUFBLFVBQ0EsVUFBVSxDQUFDNkMsTUFBTWxDLGlCQUFpQmtDLEdBQUdnQixRQUFRakQsS0FBSztBQUFBLFVBQ2xELFdBQVU7QUFBQSxVQUNWLFFBQU87QUFBQTtBQUFBLFFBTlQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTW9GO0FBQUEsU0E5QnRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQ0E7QUFBQSxJQUVBLHVCQUFDLHVZQUFJLFdBQVUsT0FDWmhCO0FBQUFBLG1CQUNDLHVCQUFDLHFlQUFJLFdBQVUscUZBQ2I7QUFBQSwrQkFBQywyY0FBSSxXQUFVLGtFQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEU7QUFBQSxRQUM5RSx1QkFBQyxtZEFBSyxXQUFVLHlCQUF3QixxQ0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2RDtBQUFBLFdBRi9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BR0RMLFVBQ0MsdUJBQUMsK2FBQUksV0FBVSx5Q0FDYjtBQUFBLCtCQUFDLDBjQUFJLFdBQVUsaUVBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2RTtBQUFBLFFBQzdFLHVCQUFDLHFkQUFLLFdBQVUsNEJBQTJCLG9DQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStEO0FBQUEsV0FGakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBLElBQ0VELFdBQVd1QixXQUFXLElBQ3hCLHVCQUFDLHNaQUFJLFdBQVUsb0JBQ2I7QUFBQSwrQkFBQyx1Y0FBSyxNQUFLLFlBQVcsTUFBTSxJQUFJLFdBQVUscUNBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkU7QUFBQSxRQUMzRSx1QkFBQyx3Y0FBRSxXQUFVLHVCQUFzQixxQ0FBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RDtBQUFBLFFBQ3hELHVCQUFDLG9mQUFFLFdBQVUsbUNBQWtDLHlEQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdGO0FBQUEsV0FIMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBLElBRUEsdUJBQUMsNllBQUksV0FBVSxhQUNadkIscUJBQVd3RSxJQUFJLENBQUNwQyxRQUFRO0FBQ3ZCLGNBQU1oQixXQUFXSixZQUFZb0IsS0FBS0csSUFBSTtBQUV0QyxlQUNFO0FBQUEsVUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFFQyxXQUFVO0FBQUEsWUFHVjtBQUFBLHFDQUFDLGtkQUFJLFdBQVUscUVBQ2IsaUNBQUMsNmJBQUssTUFBTW5CLFVBQVUsTUFBTSxJQUFJLFdBQVUsbUJBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlELEtBRDNEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUVBLHVCQUFDLHFaQUFJLFdBQVUsa0JBQ2I7QUFBQSx1Q0FBQyxvYUFBSSxXQUFVLCtCQUNiO0FBQUEseUNBQUMsc2JBQUcsV0FBVSxrREFDWGdCLGVBQUtHLFFBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNDSCxLQUFLUCxnQkFBZ0JPLEtBQUtQLGlCQUFpQixXQUMxQyx1QkFBQyw0Y0FBSyxXQUFVLDhEQUNibEIseUJBQWU4RCxLQUFLLENBQUFDLE1BQUtBLEdBQUc5RCxVQUFVd0IsS0FBS1AsWUFBWSxHQUFHaEIsU0FBU3VCLEtBQUtQLGdCQUQzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFTQTtBQUFBLGdCQUNBLHVCQUFDLG1jQUFJLFdBQVUsMERBQ2I7QUFBQSx5Q0FBQyw2V0FBTU8sZUFBS0wsUUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpQjtBQUFBLGtCQUNqQix1QkFBQyxtWkFBSyxpQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFPO0FBQUEsa0JBQ1AsdUJBQUMsNldBQU1LLGVBQUt1QyxjQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVCO0FBQUEsa0JBQ3ZCLHVCQUFDLG1aQUFLLGlCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQU87QUFBQSxrQkFDUCx1QkFBQyw2V0FBTWYscUJBQVd4QixLQUFLd0MsVUFBVSxLQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFtQztBQUFBLHFCQUxyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU1BO0FBQUEsbUJBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBa0JBO0FBQUEsY0FFQSx1QkFBQyxvYUFBSSxXQUFVLCtCQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBQ0MsU0FBUyxNQUFNbEMsZUFBZU4sR0FBRztBQUFBLG9CQUNqQyxXQUFVO0FBQUEsb0JBQ1YsT0FBTTtBQUFBLG9CQUVOLGlDQUFDLHlZQUFLLE1BQUssWUFBVyxNQUFNLE1BQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQStCO0FBQUE7QUFBQSxrQkFMakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1BO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBQ0MsU0FBUyxNQUFNRCxhQUFhQyxHQUFHO0FBQUEsb0JBQy9CLFdBQVU7QUFBQSxvQkFDVixPQUFNO0FBQUEsb0JBRU4saUNBQUMsdVlBQUssTUFBSyxVQUFTLE1BQU0sTUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBNkI7QUFBQTtBQUFBLGtCQUwvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQSxtQkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWVBO0FBQUE7QUFBQTtBQUFBLFVBM0NLQSxLQUFLSTtBQUFBQSxVQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUE2Q0E7QUFBQSxNQUVKLENBQUMsS0FwREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFEQTtBQUFBLFNBekVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyRUE7QUFBQSxPQTdIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBOEhBO0FBRUo7QUFBRW5DLEdBMU9JTixrQkFBZ0I7QUFBQThFLEtBQWhCOUU7QUE0T04sZUFBZUE7QUFBaUIsSUFBQThFO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZVJlZiIsIkljb24iLCJkZWFsRG9jdW1lbnRzU2VydmljZSIsIkRvY3VtZW50c1NlY3Rpb24iLCJkb2N1bWVudHMiLCJsb2FkaW5nIiwiZGVhbElkIiwib25VcGxvYWREb2N1bWVudCIsIm9uRGVsZXRlRG9jdW1lbnQiLCJfcyIsInVwbG9hZGluZyIsInNldFVwbG9hZGluZyIsImRyYWdPdmVyIiwic2V0RHJhZ092ZXIiLCJmaWxlSW5wdXRSZWYiLCJkb2N1bWVudFR5cGVzIiwidmFsdWUiLCJsYWJlbCIsImljb24iLCJjb2xvciIsImdldEZpbGVJY29uIiwiZmlsZW5hbWUiLCJleHRlbnNpb24iLCJnZXRGaWxlRXh0ZW5zaW9uIiwiaWNvbk5hbWUiLCJoYW5kbGVGaWxlU2VsZWN0IiwiZmlsZXMiLCJsZW5ndGgiLCJBcnJheSIsImZyb20iLCJmb3JFYWNoIiwiZmlsZSIsImhhbmRsZVVwbG9hZCIsImRvY3VtZW50VHlwZSIsIm1heFNpemUiLCJzaXplIiwiYWxlcnQiLCJlcnIiLCJtZXNzYWdlIiwiaGFuZGxlRGVsZXRlIiwiZG9jIiwid2luZG93IiwiY29uZmlybSIsIm5hbWUiLCJpZCIsImZpbGVVcmwiLCJoYW5kbGVEb3dubG9hZCIsInVybCIsImdldERvY3VtZW50VXJsIiwibGluayIsImRvY3VtZW50IiwiY3JlYXRlRWxlbWVudCIsImhyZWYiLCJkb3dubG9hZCIsImJvZHkiLCJhcHBlbmRDaGlsZCIsImNsaWNrIiwicmVtb3ZlQ2hpbGQiLCJoYW5kbGVEcm9wIiwiZSIsInByZXZlbnREZWZhdWx0IiwiZGF0YVRyYW5zZmVyIiwiaGFuZGxlRHJhZ092ZXIiLCJoYW5kbGVEcmFnTGVhdmUiLCJmb3JtYXREYXRlIiwiZGF0ZVN0cmluZyIsImRhdGUiLCJEYXRlIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwibW9udGgiLCJkYXkiLCJ5ZWFyIiwiZ2V0RnVsbFllYXIiLCJ1bmRlZmluZWQiLCJjdXJyZW50IiwidGFyZ2V0IiwibWFwIiwiZmluZCIsInQiLCJ1cGxvYWRlZEJ5IiwidXBsb2FkZWRBdCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiRG9jdW1lbnRzU2VjdGlvbi5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VSZWYgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCBJY29uIGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvQXBwSWNvbic7XHJcbmltcG9ydCBkZWFsRG9jdW1lbnRzU2VydmljZSBmcm9tICcuLi8uLi8uLi9zZXJ2aWNlcy9kZWFsRG9jdW1lbnRzU2VydmljZSc7XHJcblxyXG5jb25zdCBEb2N1bWVudHNTZWN0aW9uID0gKHsgXHJcbiAgZG9jdW1lbnRzID0gW10sIFxyXG4gIGxvYWRpbmcgPSBmYWxzZSwgXHJcbiAgZGVhbElkLCBcclxuICBvblVwbG9hZERvY3VtZW50LCBcclxuICBvbkRlbGV0ZURvY3VtZW50IFxyXG59KSA9PiB7XHJcbiAgY29uc3QgW3VwbG9hZGluZywgc2V0VXBsb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZHJhZ092ZXIsIHNldERyYWdPdmVyXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBmaWxlSW5wdXRSZWYgPSB1c2VSZWYobnVsbCk7XHJcblxyXG4gIGNvbnN0IGRvY3VtZW50VHlwZXMgPSBbXHJcbiAgICB7IHZhbHVlOiAncHJvcG9zYWwnLCBsYWJlbDogJ1Byb3Bvc2FsJywgaWNvbjogJ0ZpbGVUZXh0JywgY29sb3I6ICd0ZXh0LWJsdWUtNjAwJyB9LFxyXG4gICAgeyB2YWx1ZTogJ2NvbnRyYWN0JywgbGFiZWw6ICdDb250cmFjdCcsIGljb246ICdGaWxlQ2hlY2snLCBjb2xvcjogJ3RleHQtZ3JlZW4tNjAwJyB9LFxyXG4gICAgeyB2YWx1ZTogJ3ByZXNlbnRhdGlvbicsIGxhYmVsOiAnUHJlc2VudGF0aW9uJywgaWNvbjogJ1ByZXNlbnRhdGlvbicsIGNvbG9yOiAndGV4dC1wdXJwbGUtNjAwJyB9LFxyXG4gICAgeyB2YWx1ZTogJ290aGVyJywgbGFiZWw6ICdPdGhlcicsIGljb246ICdGaWxlJywgY29sb3I6ICd0ZXh0LWdyYXktNjAwJyB9XHJcbiAgXTtcclxuXHJcbiAgY29uc3QgZ2V0RmlsZUljb24gPSAoZmlsZW5hbWUpID0+IHtcclxuICAgIGNvbnN0IGV4dGVuc2lvbiA9IGRlYWxEb2N1bWVudHNTZXJ2aWNlPy5nZXRGaWxlRXh0ZW5zaW9uKGZpbGVuYW1lKTtcclxuICAgIGNvbnN0IGljb25OYW1lID0gZGVhbERvY3VtZW50c1NlcnZpY2U/LmdldEZpbGVJY29uKGZpbGVuYW1lKTtcclxuICAgIHJldHVybiBpY29uTmFtZTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVGaWxlU2VsZWN0ID0gKGZpbGVzKSA9PiB7XHJcbiAgICBpZiAoIWZpbGVzIHx8IGZpbGVzPy5sZW5ndGggPT09IDApIHJldHVybjtcclxuICAgIFxyXG4gICAgQXJyYXkuZnJvbShmaWxlcyk/LmZvckVhY2goZmlsZSA9PiB7XHJcbiAgICAgIGhhbmRsZVVwbG9hZChmaWxlKTtcclxuICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVVwbG9hZCA9IGFzeW5jIChmaWxlLCBkb2N1bWVudFR5cGUgPSAnb3RoZXInKSA9PiB7XHJcbiAgICBpZiAoIWRlYWxJZCB8fCAhZmlsZSkgcmV0dXJuO1xyXG5cclxuICAgIC8vIEZpbGUgdmFsaWRhdGlvblxyXG4gICAgY29uc3QgbWF4U2l6ZSA9IDEwICogMTAyNCAqIDEwMjQ7IC8vIDEwTUJcclxuICAgIGlmIChmaWxlPy5zaXplID4gbWF4U2l6ZSkge1xyXG4gICAgICBhbGVydCgnRmlsZSBzaXplIG11c3QgYmUgbGVzcyB0aGFuIDEwTUInKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHNldFVwbG9hZGluZyh0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IG9uVXBsb2FkRG9jdW1lbnQ/LihmaWxlLCBkb2N1bWVudFR5cGUpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGFsZXJ0KCdGYWlsZWQgdG8gdXBsb2FkIGRvY3VtZW50OiAnICsgKGVycj8ubWVzc2FnZSB8fCAnVW5rbm93biBlcnJvcicpKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldFVwbG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlID0gYXN5bmMgKGRvYykgPT4ge1xyXG4gICAgaWYgKCF3aW5kb3cuY29uZmlybShgQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIGRlbGV0ZSBcIiR7ZG9jPy5uYW1lfVwiP2ApKSB7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBvbkRlbGV0ZURvY3VtZW50Py4oZG9jPy5pZCwgZG9jPy5maWxlVXJsKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBhbGVydCgnRmFpbGVkIHRvIGRlbGV0ZSBkb2N1bWVudDogJyArIChlcnI/Lm1lc3NhZ2UgfHwgJ1Vua25vd24gZXJyb3InKSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRG93bmxvYWQgPSBhc3luYyAoZG9jKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCB1cmwgPSBhd2FpdCBkZWFsRG9jdW1lbnRzU2VydmljZT8uZ2V0RG9jdW1lbnRVcmwoZG9jPy5maWxlVXJsKTtcclxuICAgICAgY29uc3QgbGluayA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKTtcclxuICAgICAgbGluay5ocmVmID0gdXJsO1xyXG4gICAgICBsaW5rLmRvd25sb2FkID0gZG9jPy5uYW1lO1xyXG4gICAgICBkb2N1bWVudC5ib2R5Py5hcHBlbmRDaGlsZChsaW5rKTtcclxuICAgICAgbGluaz8uY2xpY2soKTtcclxuICAgICAgZG9jdW1lbnQuYm9keT8ucmVtb3ZlQ2hpbGQobGluayk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgYWxlcnQoJ0ZhaWxlZCB0byBkb3dubG9hZCBkb2N1bWVudDogJyArIChlcnI/Lm1lc3NhZ2UgfHwgJ1Vua25vd24gZXJyb3InKSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRHJvcCA9IChlKSA9PiB7XHJcbiAgICBlPy5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgc2V0RHJhZ092ZXIoZmFsc2UpO1xyXG4gICAgXHJcbiAgICBjb25zdCBmaWxlcyA9IGU/LmRhdGFUcmFuc2Zlcj8uZmlsZXM7XHJcbiAgICBoYW5kbGVGaWxlU2VsZWN0KGZpbGVzKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVEcmFnT3ZlciA9IChlKSA9PiB7XHJcbiAgICBlPy5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgc2V0RHJhZ092ZXIodHJ1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRHJhZ0xlYXZlID0gKGUpID0+IHtcclxuICAgIGU/LnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBzZXREcmFnT3ZlcihmYWxzZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZm9ybWF0RGF0ZSA9IChkYXRlU3RyaW5nKSA9PiB7XHJcbiAgICBjb25zdCBkYXRlID0gbmV3IERhdGUoZGF0ZVN0cmluZyk7XHJcbiAgICByZXR1cm4gZGF0ZT8udG9Mb2NhbGVEYXRlU3RyaW5nKCdlbi1VUycsIHtcclxuICAgICAgbW9udGg6ICdzaG9ydCcsXHJcbiAgICAgIGRheTogJ251bWVyaWMnLFxyXG4gICAgICB5ZWFyOiBkYXRlPy5nZXRGdWxsWWVhcigpICE9PSBuZXcgRGF0ZSgpPy5nZXRGdWxsWWVhcigpID8gJ251bWVyaWMnIDogdW5kZWZpbmVkXHJcbiAgICB9KTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zdXJmYWNlIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ib3JkZXJcIj5cclxuICAgICAgey8qIEhlYWRlciAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgYm9yZGVyLWIgYm9yZGVyLWJvcmRlclwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtdGV4dC1wcmltYXJ5XCI+RG9jdW1lbnRzPC9oMz5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gZmlsZUlucHV0UmVmPy5jdXJyZW50Py5jbGljaygpfVxyXG4gICAgICAgICAgICBkaXNhYmxlZD17dXBsb2FkaW5nfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTIgcHgtMyBweS0xIGJnLXByaW1hcnkgdGV4dC13aGl0ZSByb3VuZGVkLWxnIGhvdmVyOmJnLXByaW1hcnktNjAwIGRpc2FibGVkOm9wYWNpdHktNTAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MCB0ZXh0LXNtXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPEljb24gbmFtZT1cIlVwbG9hZFwiIHNpemU9ezE2fSAvPlxyXG4gICAgICAgICAgICA8c3Bhbj5VcGxvYWQ8L3NwYW4+XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIHsvKiBVcGxvYWQgQXJlYSAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgYm9yZGVyLWIgYm9yZGVyLWJvcmRlclwiPlxyXG4gICAgICAgIDxkaXZcclxuICAgICAgICAgIG9uRHJvcD17aGFuZGxlRHJvcH1cclxuICAgICAgICAgIG9uRHJhZ092ZXI9e2hhbmRsZURyYWdPdmVyfVxyXG4gICAgICAgICAgb25EcmFnTGVhdmU9e2hhbmRsZURyYWdMZWF2ZX1cclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGZpbGVJbnB1dFJlZj8uY3VycmVudD8uY2xpY2soKX1cclxuICAgICAgICAgIGNsYXNzTmFtZT17YGJvcmRlci0yIGJvcmRlci1kYXNoZWQgcm91bmRlZC1sZyBwLTYgdGV4dC1jZW50ZXIgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwICR7XHJcbiAgICAgICAgICAgIGRyYWdPdmVyIFxyXG4gICAgICAgICAgICAgID8gJ2JvcmRlci1wcmltYXJ5IGJnLXByaW1hcnktNTAnIDonYm9yZGVyLWJvcmRlciBob3Zlcjpib3JkZXItYm9yZGVyLWhvdmVyIGhvdmVyOmJnLWJhY2tncm91bmQnXHJcbiAgICAgICAgICB9YH1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8SWNvbiBcclxuICAgICAgICAgICAgbmFtZT1cIlVwbG9hZFwiIFxyXG4gICAgICAgICAgICBzaXplPXsyNH0gXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17YG14LWF1dG8gbWItMiAke2RyYWdPdmVyID8gJ3RleHQtcHJpbWFyeScgOiAndGV4dC10ZXh0LXRlcnRpYXJ5J31gfSBcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtdGV4dC1zZWNvbmRhcnlcIj5cclxuICAgICAgICAgICAgRHJvcCBmaWxlcyBoZXJlIG9yIGNsaWNrIHRvIGJyb3dzZVxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXRleHQtdGVydGlhcnkgbXQtMVwiPlxyXG4gICAgICAgICAgICBNYXhpbXVtIGZpbGUgc2l6ZTogMTBNQlxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8aW5wdXRcclxuICAgICAgICAgIHJlZj17ZmlsZUlucHV0UmVmfVxyXG4gICAgICAgICAgdHlwZT1cImZpbGVcIlxyXG4gICAgICAgICAgbXVsdGlwbGVcclxuICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRmlsZVNlbGVjdChlPy50YXJnZXQ/LmZpbGVzKX1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cImhpZGRlblwiXHJcbiAgICAgICAgICBhY2NlcHQ9XCIucGRmLC5kb2MsLmRvY3gsLnhscywueGxzeCwucHB0LC5wcHR4LC5qcGcsLmpwZWcsLnBuZywuZ2lmLC50eHQsLnppcCwucmFyXCJcclxuICAgICAgICAvPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgey8qIERvY3VtZW50cyBMaXN0ICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNlwiPlxyXG4gICAgICAgIHt1cGxvYWRpbmcgJiYgKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTMgcC0zIGJnLWJsdWUtNTAgYm9yZGVyIGJvcmRlci1ibHVlLTIwMCByb3VuZGVkLWxnIG1iLTRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW4gcm91bmRlZC1mdWxsIGgtNCB3LTQgYm9yZGVyLWItMiBib3JkZXItYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWJsdWUtODAwXCI+VXBsb2FkaW5nIGRvY3VtZW50Li4uPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuXHJcbiAgICAgICAge2xvYWRpbmcgPyAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHB5LThcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW4gcm91bmRlZC1mdWxsIGgtNiB3LTYgYm9yZGVyLWItMiBib3JkZXItcHJpbWFyeVwiPjwvZGl2PlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0yIHRleHQtdGV4dC1zZWNvbmRhcnlcIj5Mb2FkaW5nIGRvY3VtZW50cy4uLjwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkgOiBkb2N1bWVudHM/Lmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktOFwiPlxyXG4gICAgICAgICAgICA8SWNvbiBuYW1lPVwiRmlsZVRleHRcIiBzaXplPXszMn0gY2xhc3NOYW1lPVwidGV4dC10ZXh0LXRlcnRpYXJ5IG14LWF1dG8gbWItMlwiIC8+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtdGV4dC1zZWNvbmRhcnlcIj5ObyBkb2N1bWVudHMgdXBsb2FkZWQ8L3A+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC10ZXh0LXRlcnRpYXJ5IG10LTFcIj5VcGxvYWQgeW91ciBmaXJzdCBkb2N1bWVudCB0byBnZXQgc3RhcnRlZDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkgOiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxyXG4gICAgICAgICAgICB7ZG9jdW1lbnRzPy5tYXAoKGRvYykgPT4ge1xyXG4gICAgICAgICAgICAgIGNvbnN0IGljb25OYW1lID0gZ2V0RmlsZUljb24oZG9jPy5uYW1lKTtcclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBcclxuICAgICAgICAgICAgICAgICAga2V5PXtkb2M/LmlkfSBcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0zIHAtMyBiZy1iYWNrZ3JvdW5kIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ib3JkZXIgaG92ZXI6Ym9yZGVyLWJvcmRlci1ob3ZlciB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTBcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7LyogRmlsZSBJY29uICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCBiZy1ibHVlLTEwMCByb3VuZGVkLWxnIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT17aWNvbk5hbWV9IHNpemU9ezIwfSBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIHsvKiBGaWxlIEluZm8gKi99XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LTBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgdHJ1bmNhdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2RvYz8ubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvaDQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZG9jPy5kb2N1bWVudFR5cGUgJiYgZG9jPy5kb2N1bWVudFR5cGUgIT09ICdvdGhlcicgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0yIHB5LTAuNSBiZy1ncmF5LTEwMCB0ZXh0LWdyYXktODAwIHRleHQteHMgcm91bmRlZC1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2RvY3VtZW50VHlwZXM/LmZpbmQodCA9PiB0Py52YWx1ZSA9PT0gZG9jPy5kb2N1bWVudFR5cGUpPy5sYWJlbCB8fCBkb2M/LmRvY3VtZW50VHlwZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMiB0ZXh0LXhzIHRleHQtdGV4dC10ZXJ0aWFyeVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2RvYz8uc2l6ZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj7igKI8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57ZG9jPy51cGxvYWRlZEJ5fTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPuKAojwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntmb3JtYXREYXRlKGRvYz8udXBsb2FkZWRBdCl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgey8qIEFjdGlvbnMgKi99XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRG93bmxvYWQoZG9jKX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiB0ZXh0LXRleHQtdGVydGlhcnkgaG92ZXI6dGV4dC1wcmltYXJ5IGhvdmVyOmJnLXByaW1hcnktNTAgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJEb3dubG9hZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIkRvd25sb2FkXCIgc2l6ZT17MTZ9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRGVsZXRlKGRvYyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgdGV4dC10ZXh0LXRlcnRpYXJ5IGhvdmVyOnRleHQtZXJyb3IgaG92ZXI6YmctZXJyb3ItNTAgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJEZWxldGVcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJUcmFzaDJcIiBzaXplPXsxNn0gLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICB9KX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IERvY3VtZW50c1NlY3Rpb247Il0sImZpbGUiOiJEOi9jdXJyZW50IHByb2plY3RzL2NsYXVkZS1jb2RlL3NyYy9wYWdlcy9kZWFsLW1hbmFnZW1lbnQvY29tcG9uZW50cy9Eb2N1bWVudHNTZWN0aW9uLmpzeCJ9