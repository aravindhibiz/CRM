import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/sales-dashboard/components/RecentActivity.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import Icon from "/src/components/AppIcon.jsx";
import { useAuth } from "/src/contexts/AuthContext.jsx";
import activitiesService from "/src/services/activitiesService.js";
const RecentActivity = () => {
  _s();
  const { user } = useAuth();
  const [activities, setActivities] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  useEffect(() => {
    if (user) {
      loadRecentActivity();
    }
  }, [user]);
  const loadRecentActivity = async () => {
    try {
      setLoading(true);
      setError("");
      const data = await activitiesService?.getRecentActivity(10);
      setActivities(data || []);
    } catch (err) {
      console.error("Error loading recent activity:", err);
      setError("Failed to load activity");
    } finally {
      setLoading(false);
    }
  };
  const getActivityIcon = (type) => {
    const icons = {
      email: "Mail",
      call: "Phone",
      meeting: "Calendar",
      note: "FileText",
      task: "CheckSquare",
      demo: "Play",
      proposal_sent: "Send"
    };
    return icons?.[type] || "Activity";
  };
  const getActivityColor = (type) => {
    const colors = {
      email: "text-blue-600",
      call: "text-green-600",
      meeting: "text-purple-600",
      note: "text-gray-600",
      task: "text-orange-600",
      demo: "text-indigo-600",
      proposal_sent: "text-red-600"
    };
    return colors?.[type] || "text-gray-600";
  };
  const formatTimeAgo = (dateString) => {
    const now = /* @__PURE__ */ new Date();
    const activityDate = new Date(dateString);
    const diffInMinutes = Math.floor((now - activityDate) / (1e3 * 60));
    if (diffInMinutes < 1)
      return "Just now";
    if (diffInMinutes < 60)
      return `${diffInMinutes}m ago`;
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24)
      return `${diffInHours}h ago`;
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays < 7)
      return `${diffInDays}d ago`;
    return activityDate?.toLocaleDateString();
  };
  if (!user) {
    return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:77:6", "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx", "data-component-line": "77", "data-component-file": "RecentActivity.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-6%22%7D", className: "card p-6", children: [
      /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:78:8", "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx", "data-component-line": "78", "data-component-file": "RecentActivity.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%20mb-4%22%2C%22textContent%22%3A%22Recent%20Activity%22%7D", className: "text-lg font-semibold text-text-primary mb-4", children: "Recent Activity" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
        lineNumber: 78,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:79:8", "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx", "data-component-line": "79", "data-component-file": "RecentActivity.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-center%20py-8%22%7D", className: "text-center py-8", children: [
        /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:80:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx", "data-component-line": "80", "data-component-file": "RecentActivity.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Activity%22%2C%22className%22%3A%22text-text-tertiary%20mx-auto%20mb-3%22%7D", name: "Activity", size: 32, className: "text-text-tertiary mx-auto mb-3" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
          lineNumber: 80,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:81:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx", "data-component-line": "81", "data-component-file": "RecentActivity.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20text-sm%22%2C%22textContent%22%3A%22Sign%20in%20to%20view%20recent%20activity%22%7D", className: "text-text-secondary text-sm", children: "Sign in to view recent activity" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
          lineNumber: 81,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
        lineNumber: 79,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
      lineNumber: 77,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:88:4", "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx", "data-component-line": "88", "data-component-file": "RecentActivity.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-6%22%7D", className: "card p-6", children: [
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:89:6", "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx", "data-component-line": "89", "data-component-file": "RecentActivity.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%20mb-4%22%7D", className: "flex items-center justify-between mb-4", children: [
      /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:90:8", "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx", "data-component-line": "90", "data-component-file": "RecentActivity.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%2C%22textContent%22%3A%22Recent%20Activity%22%7D", className: "text-lg font-semibold text-text-primary", children: "Recent Activity" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
        lineNumber: 90,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:91:8",
          "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx",
          "data-component-line": "91",
          "data-component-file": "RecentActivity.jsx",
          "data-component-name": "button",
          "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22text-text-tertiary%20hover%3Atext-text-secondary%22%7D",
          onClick: loadRecentActivity,
          className: "text-text-tertiary hover:text-text-secondary",
          disabled: loading,
          children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:96:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx", "data-component-line": "96", "data-component-file": "RecentActivity.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22RefreshCw%22%7D", name: "RefreshCw", size: 16, className: loading ? "animate-spin" : "" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
            lineNumber: 96,
            columnNumber: 11
          }, this)
        },
        void 0,
        false,
        {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
          lineNumber: 91,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
      lineNumber: 89,
      columnNumber: 7
    }, this),
    error && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:100:6", "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx", "data-component-line": "100", "data-component-file": "RecentActivity.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-error-50%20text-error%20text-sm%20p-3%20rounded-lg%20mb-4%22%7D", className: "bg-error-50 text-error text-sm p-3 rounded-lg mb-4", children: error }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
      lineNumber: 100,
      columnNumber: 7
    }, this),
    loading ? /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:105:6", "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx", "data-component-line": "105", "data-component-file": "RecentActivity.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-3%22%7D", className: "space-y-3", children: [...Array(5)]?.map(
      (_, index) => /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:107:8", "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx", "data-component-line": "107", "data-component-file": "RecentActivity.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-3%20animate-pulse%22%7D", className: "flex items-center space-x-3 animate-pulse", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:108:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx", "data-component-line": "108", "data-component-file": "RecentActivity.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-8%20h-8%20bg-gray-200%20rounded-full%22%7D", className: "w-8 h-8 bg-gray-200 rounded-full" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
          lineNumber: 108,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:109:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx", "data-component-line": "109", "data-component-file": "RecentActivity.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex-1%22%7D", className: "flex-1", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:110:16", "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx", "data-component-line": "110", "data-component-file": "RecentActivity.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22h-3%20bg-gray-200%20rounded%20w-3%2F4%20mb-1%22%7D", className: "h-3 bg-gray-200 rounded w-3/4 mb-1" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
            lineNumber: 110,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:111:16", "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx", "data-component-line": "111", "data-component-file": "RecentActivity.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22h-2%20bg-gray-200%20rounded%20w-1%2F2%22%7D", className: "h-2 bg-gray-200 rounded w-1/2" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
            lineNumber: 111,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
          lineNumber: 109,
          columnNumber: 15
        }, this)
      ] }, index, true, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
        lineNumber: 107,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
      lineNumber: 105,
      columnNumber: 7
    }, this) : activities?.length === 0 ? /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:117:6", "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx", "data-component-line": "117", "data-component-file": "RecentActivity.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-center%20py-8%22%7D", className: "text-center py-8", children: [
      /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:118:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx", "data-component-line": "118", "data-component-file": "RecentActivity.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Activity%22%2C%22className%22%3A%22text-text-tertiary%20mx-auto%20mb-3%22%7D", name: "Activity", size: 32, className: "text-text-tertiary mx-auto mb-3" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
        lineNumber: 118,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:119:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx", "data-component-line": "119", "data-component-file": "RecentActivity.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20text-sm%22%2C%22textContent%22%3A%22No%20recent%20activity%22%7D", className: "text-text-secondary text-sm", children: "No recent activity" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
        lineNumber: 119,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
      lineNumber: 117,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:122:6", "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx", "data-component-line": "122", "data-component-file": "RecentActivity.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-4%22%7D", className: "space-y-4", children: [
      activities?.map(
        (activity) => /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:124:8", "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx", "data-component-line": "124", "data-component-file": "RecentActivity.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-start%20space-x-3%22%7D", className: "flex items-start space-x-3", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:125:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx", "data-component-line": "125", "data-component-file": "RecentActivity.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", className: `w-8 h-8 rounded-full flex items-center justify-center ${activity?.type === "email" ? "bg-blue-100" : activity?.type === "call" ? "bg-green-100" : activity?.type === "meeting" ? "bg-purple-100" : activity?.type === "note" ? "bg-gray-100" : "bg-orange-100"}`, children: /* @__PURE__ */ jsxDEV(
            Icon,
            {
              "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:131:16",
              "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx",
              "data-component-line": "131",
              "data-component-file": "RecentActivity.jsx",
              "data-component-name": "Icon",
              "data-component-content": "%7B%22elementName%22%3A%22Icon%22%7D",
              name: getActivityIcon(activity?.type),
              size: 16,
              className: getActivityColor(activity?.type)
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
              lineNumber: 131,
              columnNumber: 17
            },
            this
          ) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
            lineNumber: 125,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:138:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx", "data-component-line": "138", "data-component-file": "RecentActivity.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex-1%20min-w-0%22%7D", className: "flex-1 min-w-0", children: [
            /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:139:16", "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx", "data-component-line": "139", "data-component-file": "RecentActivity.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%20text-text-primary%20font-medium%20truncate%22%7D", className: "text-sm text-text-primary font-medium truncate", children: activity?.title }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
              lineNumber: 139,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:143:16", "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx", "data-component-line": "143", "data-component-file": "RecentActivity.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%20text-xs%20text-text-secondary%20mt-1%22%7D", className: "flex items-center space-x-2 text-xs text-text-secondary mt-1", children: [
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:144:18", "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx", "data-component-line": "144", "data-component-file": "RecentActivity.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: activity?.user }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
                lineNumber: 144,
                columnNumber: 19
              }, this),
              activity?.contact && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:147:22", "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx", "data-component-line": "147", "data-component-file": "RecentActivity.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22%E2%80%A2%22%7D", children: "•" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
                  lineNumber: 147,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:148:22", "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx", "data-component-line": "148", "data-component-file": "RecentActivity.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: activity?.contact }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
                  lineNumber: 148,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
                lineNumber: 146,
                columnNumber: 15
              }, this),
              activity?.company && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:153:22", "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx", "data-component-line": "153", "data-component-file": "RecentActivity.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22%E2%80%A2%22%7D", children: "•" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
                  lineNumber: 153,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:154:22", "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx", "data-component-line": "154", "data-component-file": "RecentActivity.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: activity?.company }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
                  lineNumber: 154,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
                lineNumber: 152,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
              lineNumber: 143,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:159:16", "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx", "data-component-line": "159", "data-component-file": "RecentActivity.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-xs%20text-text-tertiary%20mt-1%22%7D", className: "text-xs text-text-tertiary mt-1", children: formatTimeAgo(activity?.time) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
              lineNumber: 159,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
            lineNumber: 138,
            columnNumber: 15
          }, this)
        ] }, activity?.id, true, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
          lineNumber: 124,
          columnNumber: 9
        }, this)
      ),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:166:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx", "data-component-line": "166", "data-component-file": "RecentActivity.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22pt-3%20border-t%20border-border%22%7D", className: "pt-3 border-t border-border", children: /* @__PURE__ */ jsxDEV("button", { "data-component-id": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx:167:12", "data-component-path": "src\\pages\\sales-dashboard\\components\\RecentActivity.jsx", "data-component-line": "167", "data-component-file": "RecentActivity.jsx", "data-component-name": "button", "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22text-sm%20text-primary%20hover%3Atext-primary-600%20font-medium%22%2C%22textContent%22%3A%22View%20all%20activity%20%E2%86%92%22%7D", className: "text-sm text-primary hover:text-primary-600 font-medium", children: "View all activity →" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
        lineNumber: 167,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
        lineNumber: 166,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
      lineNumber: 122,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx",
    lineNumber: 88,
    columnNumber: 5
  }, this);
};
_s(RecentActivity, "jVTXZROGAFrJNEcN2V7s69VGJA4=", false, function() {
  return [useAuth];
});
_c = RecentActivity;
export default RecentActivity;
var _c;
$RefreshReg$(_c, "RecentActivity");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/sales-dashboard/components/RecentActivity.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkVRLFNBb0VZLFVBcEVaOzJCQTdFUjtBQUFnQkEsTUFBVUMsY0FBUyxPQUFRLHNCQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ2xELE9BQU9DLFVBQVU7QUFDakIsU0FBU0MsZUFBZTtBQUN4QixPQUFPQyx1QkFBdUI7QUFFOUIsTUFBTUMsaUJBQWlCQSxNQUFNO0FBQUFDLEtBQUE7QUFDM0IsUUFBTSxFQUFFQyxLQUFLLElBQUlKLFFBQVE7QUFDekIsUUFBTSxDQUFDSyxZQUFZQyxhQUFhLElBQUlULFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNVLFNBQVNDLFVBQVUsSUFBSVgsU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQ1ksT0FBT0MsUUFBUSxJQUFJYixTQUFTLEVBQUU7QUFFckNDLFlBQVUsTUFBTTtBQUNkLFFBQUlNLE1BQU07QUFDUk8seUJBQW1CO0FBQUEsSUFDckI7QUFBQSxFQUNGLEdBQUcsQ0FBQ1AsSUFBSSxDQUFDO0FBRVQsUUFBTU8scUJBQXFCLFlBQVk7QUFDckMsUUFBSTtBQUNGSCxpQkFBVyxJQUFJO0FBQ2ZFLGVBQVMsRUFBRTtBQUNYLFlBQU1FLE9BQU8sTUFBTVgsbUJBQW1CWSxrQkFBa0IsRUFBRTtBQUMxRFAsb0JBQWNNLFFBQVEsRUFBRTtBQUFBLElBQzFCLFNBQVNFLEtBQUs7QUFDWkMsY0FBUU4sTUFBTSxrQ0FBa0NLLEdBQUc7QUFDbkRKLGVBQVMseUJBQXlCO0FBQUEsSUFDcEMsVUFBQztBQUNDRixpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBRUEsUUFBTVEsa0JBQWtCQSxDQUFDQyxTQUFTO0FBQ2hDLFVBQU1DLFFBQVE7QUFBQSxNQUNaQyxPQUFPO0FBQUEsTUFDUEMsTUFBTTtBQUFBLE1BQ05DLFNBQVM7QUFBQSxNQUNUQyxNQUFNO0FBQUEsTUFDTkMsTUFBTTtBQUFBLE1BQ05DLE1BQU07QUFBQSxNQUNOQyxlQUFlO0FBQUEsSUFDakI7QUFDQSxXQUFPUCxRQUFRRCxJQUFJLEtBQUs7QUFBQSxFQUMxQjtBQUVBLFFBQU1TLG1CQUFtQkEsQ0FBQ1QsU0FBUztBQUNqQyxVQUFNVSxTQUFTO0FBQUEsTUFDYlIsT0FBTztBQUFBLE1BQ1BDLE1BQU07QUFBQSxNQUNOQyxTQUFTO0FBQUEsTUFDVEMsTUFBTTtBQUFBLE1BQ05DLE1BQU07QUFBQSxNQUNOQyxNQUFNO0FBQUEsTUFDTkMsZUFBZTtBQUFBLElBQ2pCO0FBQ0EsV0FBT0UsU0FBU1YsSUFBSSxLQUFLO0FBQUEsRUFDM0I7QUFFQSxRQUFNVyxnQkFBZ0JBLENBQUNDLGVBQWU7QUFDcEMsVUFBTUMsTUFBTSxvQkFBSUMsS0FBSztBQUNyQixVQUFNQyxlQUFlLElBQUlELEtBQUtGLFVBQVU7QUFDeEMsVUFBTUksZ0JBQWdCQyxLQUFLQyxPQUFPTCxNQUFNRSxpQkFBaUIsTUFBTyxHQUFHO0FBRW5FLFFBQUlDLGdCQUFnQjtBQUFHLGFBQU87QUFDOUIsUUFBSUEsZ0JBQWdCO0FBQUksYUFBTyxHQUFHQSxhQUFhO0FBRS9DLFVBQU1HLGNBQWNGLEtBQUtDLE1BQU1GLGdCQUFnQixFQUFFO0FBQ2pELFFBQUlHLGNBQWM7QUFBSSxhQUFPLEdBQUdBLFdBQVc7QUFFM0MsVUFBTUMsYUFBYUgsS0FBS0MsTUFBTUMsY0FBYyxFQUFFO0FBQzlDLFFBQUlDLGFBQWE7QUFBRyxhQUFPLEdBQUdBLFVBQVU7QUFFeEMsV0FBT0wsY0FBY00sbUJBQW1CO0FBQUEsRUFDMUM7QUFFQSxNQUFJLENBQUNsQyxNQUFNO0FBQ1QsV0FDRSx1QkFBQyxzWUFBSSxXQUFVLFlBQ2I7QUFBQSw2QkFBQyx5ZEFBRyxXQUFVLGdEQUErQywrQkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0RTtBQUFBLE1BQzVFLHVCQUFDLDhZQUFJLFdBQVUsb0JBQ2I7QUFBQSwrQkFBQywrYkFBSyxNQUFLLFlBQVcsTUFBTSxJQUFJLFdBQVUscUNBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkU7QUFBQSxRQUMzRSx1QkFBQywwZEFBRSxXQUFVLCtCQUE4QiwrQ0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRTtBQUFBLFdBRjVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BO0FBQUEsRUFFSjtBQUVBLFNBQ0UsdUJBQUMsc1lBQUksV0FBVSxZQUNiO0FBQUEsMkJBQUMsd2FBQUksV0FBVSwwQ0FDYjtBQUFBLDZCQUFDLGtkQUFHLFdBQVUsMkNBQTBDLCtCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVFO0FBQUEsTUFDdkU7QUFBQSxRQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUNDLFNBQVNPO0FBQUFBLFVBQ1QsV0FBVTtBQUFBLFVBQ1YsVUFBVUo7QUFBQUEsVUFFVixpQ0FBQyxrWUFBSyxNQUFLLGFBQVksTUFBTSxJQUFJLFdBQVdBLFVBQVUsaUJBQWlCLE1BQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBFO0FBQUE7QUFBQSxRQUw1RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNQTtBQUFBLFNBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFDQ0UsU0FDQyx1QkFBQywwYkFBSSxXQUFVLHNEQUNaQSxtQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUVERixVQUNDLHVCQUFDLHVZQUFJLFdBQVUsYUFDWixXQUFDLEdBQUdnQyxNQUFNLENBQUMsQ0FBQyxHQUFHQztBQUFBQSxNQUFJLENBQUNDLEdBQUdDLFVBQ3RCLHVCQUFDLDZhQUFnQixXQUFVLDZDQUN6QjtBQUFBLCtCQUFDLHFhQUFJLFdBQVUsc0NBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRDtBQUFBLFFBQ2xELHVCQUFDLHFZQUFJLFdBQVUsVUFDYjtBQUFBLGlDQUFDLDJhQUFJLFdBQVUsd0NBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Q7QUFBQSxVQUNwRCx1QkFBQyxvYUFBSSxXQUFVLG1DQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStDO0FBQUEsYUFGakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FMUUEsT0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUE7QUFBQSxJQUNELEtBVEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVBLElBQ0VyQyxZQUFZc0MsV0FBVyxJQUN6Qix1QkFBQyxnWkFBSSxXQUFVLG9CQUNiO0FBQUEsNkJBQUMsaWNBQUssTUFBSyxZQUFXLE1BQU0sSUFBSSxXQUFVLHFDQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJFO0FBQUEsTUFDM0UsdUJBQUMseWNBQUUsV0FBVSwrQkFBOEIsa0NBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkQ7QUFBQSxTQUYvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0EsSUFFQSx1QkFBQyx1WUFBSSxXQUFVLGFBQ1p0QztBQUFBQSxrQkFBWW1DO0FBQUFBLFFBQUksQ0FBQ0ksYUFDaEIsdUJBQUMsNFpBQXVCLFdBQVUsOEJBQ2hDO0FBQUEsaUNBQUMsb1dBQUksV0FBVyx5REFDZEEsVUFBVTNCLFNBQVMsVUFBVSxnQkFDN0IyQixVQUFVM0IsU0FBUyxTQUFTLGlCQUM1QjJCLFVBQVUzQixTQUFTLFlBQVksa0JBQy9CMkIsVUFBVTNCLFNBQVMsU0FBUSxnQkFBZ0IsZUFBZSxJQUUxRDtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsTUFBTUQsZ0JBQWdCNEIsVUFBVTNCLElBQUk7QUFBQSxjQUNwQyxNQUFNO0FBQUEsY0FDTixXQUFXUyxpQkFBaUJrQixVQUFVM0IsSUFBSTtBQUFBO0FBQUEsWUFINUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBRzhDLEtBVGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQSxVQUVBLHVCQUFDLCtZQUFJLFdBQVUsa0JBQ2I7QUFBQSxtQ0FBQyw2YUFBRSxXQUFVLGtEQUNWMkIsb0JBQVVDLFNBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBRUEsdUJBQUMscWNBQUksV0FBVSxnRUFDYjtBQUFBLHFDQUFDLHVXQUFNRCxvQkFBVXhDLFFBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNCO0FBQUEsY0FDckJ3QyxVQUFVRSxXQUNULG1DQUNFO0FBQUEsdUNBQUMsNllBQUssaUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBTztBQUFBLGdCQUNQLHVCQUFDLHVXQUFNRixvQkFBVUUsV0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUI7QUFBQSxtQkFGM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBRURGLFVBQVVHLFdBQ1QsbUNBQ0U7QUFBQSx1Q0FBQyw2WUFBSyxpQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFPO0FBQUEsZ0JBQ1AsdUJBQUMsdVdBQU1ILG9CQUFVRyxXQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5QjtBQUFBLG1CQUYzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsaUJBWko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFjQTtBQUFBLFlBRUEsdUJBQUMsNFpBQUUsV0FBVSxtQ0FDVm5CLHdCQUFjZ0IsVUFBVUksSUFBSSxLQUQvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3QkE7QUFBQSxhQXRDUUosVUFBVUssSUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXVDQTtBQUFBLE1BQ0Q7QUFBQSxNQUVELHVCQUFDLDhaQUFJLFdBQVUsK0JBQ2IsaUNBQUMscWdCQUFPLFdBQVUsMkRBQTBELG1DQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxTQWhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaURBO0FBQUEsT0FuRko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFGQTtBQUVKO0FBQUU5QyxHQXpLSUQsZ0JBQWM7QUFBQSxVQUNERixPQUFPO0FBQUE7QUFBQWtELEtBRHBCaEQ7QUEyS04sZUFBZUE7QUFBZSxJQUFBZ0Q7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwiSWNvbiIsInVzZUF1dGgiLCJhY3Rpdml0aWVzU2VydmljZSIsIlJlY2VudEFjdGl2aXR5IiwiX3MiLCJ1c2VyIiwiYWN0aXZpdGllcyIsInNldEFjdGl2aXRpZXMiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImVycm9yIiwic2V0RXJyb3IiLCJsb2FkUmVjZW50QWN0aXZpdHkiLCJkYXRhIiwiZ2V0UmVjZW50QWN0aXZpdHkiLCJlcnIiLCJjb25zb2xlIiwiZ2V0QWN0aXZpdHlJY29uIiwidHlwZSIsImljb25zIiwiZW1haWwiLCJjYWxsIiwibWVldGluZyIsIm5vdGUiLCJ0YXNrIiwiZGVtbyIsInByb3Bvc2FsX3NlbnQiLCJnZXRBY3Rpdml0eUNvbG9yIiwiY29sb3JzIiwiZm9ybWF0VGltZUFnbyIsImRhdGVTdHJpbmciLCJub3ciLCJEYXRlIiwiYWN0aXZpdHlEYXRlIiwiZGlmZkluTWludXRlcyIsIk1hdGgiLCJmbG9vciIsImRpZmZJbkhvdXJzIiwiZGlmZkluRGF5cyIsInRvTG9jYWxlRGF0ZVN0cmluZyIsIkFycmF5IiwibWFwIiwiXyIsImluZGV4IiwibGVuZ3RoIiwiYWN0aXZpdHkiLCJ0aXRsZSIsImNvbnRhY3QiLCJjb21wYW55IiwidGltZSIsImlkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSZWNlbnRBY3Rpdml0eS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCBJY29uIGZyb20gJ2NvbXBvbmVudHMvQXBwSWNvbic7XHJcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tICcuLi8uLi8uLi9jb250ZXh0cy9BdXRoQ29udGV4dCc7XHJcbmltcG9ydCBhY3Rpdml0aWVzU2VydmljZSBmcm9tICcuLi8uLi8uLi9zZXJ2aWNlcy9hY3Rpdml0aWVzU2VydmljZSc7XHJcblxyXG5jb25zdCBSZWNlbnRBY3Rpdml0eSA9ICgpID0+IHtcclxuICBjb25zdCB7IHVzZXIgfSA9IHVzZUF1dGgoKTtcclxuICBjb25zdCBbYWN0aXZpdGllcywgc2V0QWN0aXZpdGllc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoJycpO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKHVzZXIpIHtcclxuICAgICAgbG9hZFJlY2VudEFjdGl2aXR5KCk7XHJcbiAgICB9XHJcbiAgfSwgW3VzZXJdKTtcclxuXHJcbiAgY29uc3QgbG9hZFJlY2VudEFjdGl2aXR5ID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0TG9hZGluZyh0cnVlKTtcclxuICAgICAgc2V0RXJyb3IoJycpO1xyXG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgYWN0aXZpdGllc1NlcnZpY2U/LmdldFJlY2VudEFjdGl2aXR5KDEwKTtcclxuICAgICAgc2V0QWN0aXZpdGllcyhkYXRhIHx8IFtdKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBsb2FkaW5nIHJlY2VudCBhY3Rpdml0eTonLCBlcnIpO1xyXG4gICAgICBzZXRFcnJvcignRmFpbGVkIHRvIGxvYWQgYWN0aXZpdHknKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGdldEFjdGl2aXR5SWNvbiA9ICh0eXBlKSA9PiB7XHJcbiAgICBjb25zdCBpY29ucyA9IHtcclxuICAgICAgZW1haWw6ICdNYWlsJyxcclxuICAgICAgY2FsbDogJ1Bob25lJywgXHJcbiAgICAgIG1lZXRpbmc6ICdDYWxlbmRhcicsXHJcbiAgICAgIG5vdGU6ICdGaWxlVGV4dCcsXHJcbiAgICAgIHRhc2s6ICdDaGVja1NxdWFyZScsXHJcbiAgICAgIGRlbW86ICdQbGF5JyxcclxuICAgICAgcHJvcG9zYWxfc2VudDogJ1NlbmQnXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIGljb25zPy5bdHlwZV0gfHwgJ0FjdGl2aXR5JztcclxuICB9O1xyXG5cclxuICBjb25zdCBnZXRBY3Rpdml0eUNvbG9yID0gKHR5cGUpID0+IHtcclxuICAgIGNvbnN0IGNvbG9ycyA9IHtcclxuICAgICAgZW1haWw6ICd0ZXh0LWJsdWUtNjAwJyxcclxuICAgICAgY2FsbDogJ3RleHQtZ3JlZW4tNjAwJyxcclxuICAgICAgbWVldGluZzogJ3RleHQtcHVycGxlLTYwMCcsIFxyXG4gICAgICBub3RlOiAndGV4dC1ncmF5LTYwMCcsXHJcbiAgICAgIHRhc2s6ICd0ZXh0LW9yYW5nZS02MDAnLFxyXG4gICAgICBkZW1vOiAndGV4dC1pbmRpZ28tNjAwJyxcclxuICAgICAgcHJvcG9zYWxfc2VudDogJ3RleHQtcmVkLTYwMCdcclxuICAgIH07XHJcbiAgICByZXR1cm4gY29sb3JzPy5bdHlwZV0gfHwgJ3RleHQtZ3JheS02MDAnO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZvcm1hdFRpbWVBZ28gPSAoZGF0ZVN0cmluZykgPT4ge1xyXG4gICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKTtcclxuICAgIGNvbnN0IGFjdGl2aXR5RGF0ZSA9IG5ldyBEYXRlKGRhdGVTdHJpbmcpO1xyXG4gICAgY29uc3QgZGlmZkluTWludXRlcyA9IE1hdGguZmxvb3IoKG5vdyAtIGFjdGl2aXR5RGF0ZSkgLyAoMTAwMCAqIDYwKSk7XHJcbiAgICBcclxuICAgIGlmIChkaWZmSW5NaW51dGVzIDwgMSkgcmV0dXJuICdKdXN0IG5vdyc7XHJcbiAgICBpZiAoZGlmZkluTWludXRlcyA8IDYwKSByZXR1cm4gYCR7ZGlmZkluTWludXRlc31tIGFnb2A7XHJcbiAgICBcclxuICAgIGNvbnN0IGRpZmZJbkhvdXJzID0gTWF0aC5mbG9vcihkaWZmSW5NaW51dGVzIC8gNjApO1xyXG4gICAgaWYgKGRpZmZJbkhvdXJzIDwgMjQpIHJldHVybiBgJHtkaWZmSW5Ib3Vyc31oIGFnb2A7XHJcbiAgICBcclxuICAgIGNvbnN0IGRpZmZJbkRheXMgPSBNYXRoLmZsb29yKGRpZmZJbkhvdXJzIC8gMjQpO1xyXG4gICAgaWYgKGRpZmZJbkRheXMgPCA3KSByZXR1cm4gYCR7ZGlmZkluRGF5c31kIGFnb2A7XHJcbiAgICBcclxuICAgIHJldHVybiBhY3Rpdml0eURhdGU/LnRvTG9jYWxlRGF0ZVN0cmluZygpO1xyXG4gIH07XHJcblxyXG4gIGlmICghdXNlcikge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIHAtNlwiPlxyXG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC10ZXh0LXByaW1hcnkgbWItNFwiPlJlY2VudCBBY3Rpdml0eTwvaDM+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS04XCI+XHJcbiAgICAgICAgICA8SWNvbiBuYW1lPVwiQWN0aXZpdHlcIiBzaXplPXszMn0gY2xhc3NOYW1lPVwidGV4dC10ZXh0LXRlcnRpYXJ5IG14LWF1dG8gbWItM1wiIC8+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5IHRleHQtc21cIj5TaWduIGluIHRvIHZpZXcgcmVjZW50IGFjdGl2aXR5PC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIHAtNlwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi00XCI+XHJcbiAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXRleHQtcHJpbWFyeVwiPlJlY2VudCBBY3Rpdml0eTwvaDM+XHJcbiAgICAgICAgPGJ1dHRvbiBcclxuICAgICAgICAgIG9uQ2xpY2s9e2xvYWRSZWNlbnRBY3Rpdml0eX1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtdGV4dC10ZXJ0aWFyeSBob3Zlcjp0ZXh0LXRleHQtc2Vjb25kYXJ5XCJcclxuICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxJY29uIG5hbWU9XCJSZWZyZXNoQ3dcIiBzaXplPXsxNn0gY2xhc3NOYW1lPXtsb2FkaW5nID8gJ2FuaW1hdGUtc3BpbicgOiAnJ30gLz5cclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIHtlcnJvciAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1lcnJvci01MCB0ZXh0LWVycm9yIHRleHQtc20gcC0zIHJvdW5kZWQtbGcgbWItNFwiPlxyXG4gICAgICAgICAge2Vycm9yfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgICB7bG9hZGluZyA/IChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxyXG4gICAgICAgICAge1suLi5BcnJheSg1KV0/Lm1hcCgoXywgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgPGRpdiBrZXk9e2luZGV4fSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTMgYW5pbWF0ZS1wdWxzZVwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGgtOCBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGxcIj48L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTMgYmctZ3JheS0yMDAgcm91bmRlZCB3LTMvNCBtYi0xXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMiBiZy1ncmF5LTIwMCByb3VuZGVkIHctMS8yXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICkgOiBhY3Rpdml0aWVzPy5sZW5ndGggPT09IDAgPyAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS04XCI+XHJcbiAgICAgICAgICA8SWNvbiBuYW1lPVwiQWN0aXZpdHlcIiBzaXplPXszMn0gY2xhc3NOYW1lPVwidGV4dC10ZXh0LXRlcnRpYXJ5IG14LWF1dG8gbWItM1wiIC8+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5IHRleHQtc21cIj5ObyByZWNlbnQgYWN0aXZpdHk8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICkgOiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cclxuICAgICAgICAgIHthY3Rpdml0aWVzPy5tYXAoKGFjdGl2aXR5KSA9PiAoXHJcbiAgICAgICAgICAgIDxkaXYga2V5PXthY3Rpdml0eT8uaWR9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgc3BhY2UteC0zXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2B3LTggaC04IHJvdW5kZWQtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciAke1xyXG4gICAgICAgICAgICAgICAgYWN0aXZpdHk/LnR5cGUgPT09ICdlbWFpbCcgPyAnYmctYmx1ZS0xMDAnIDpcclxuICAgICAgICAgICAgICAgIGFjdGl2aXR5Py50eXBlID09PSAnY2FsbCcgPyAnYmctZ3JlZW4tMTAwJyA6XHJcbiAgICAgICAgICAgICAgICBhY3Rpdml0eT8udHlwZSA9PT0gJ21lZXRpbmcnID8gJ2JnLXB1cnBsZS0xMDAnIDpcclxuICAgICAgICAgICAgICAgIGFjdGl2aXR5Py50eXBlID09PSAnbm90ZSc/ICdiZy1ncmF5LTEwMCcgOiAnYmctb3JhbmdlLTEwMCdcclxuICAgICAgICAgICAgICB9YH0+XHJcbiAgICAgICAgICAgICAgICA8SWNvbiBcclxuICAgICAgICAgICAgICAgICAgbmFtZT17Z2V0QWN0aXZpdHlJY29uKGFjdGl2aXR5Py50eXBlKX0gXHJcbiAgICAgICAgICAgICAgICAgIHNpemU9ezE2fSBcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtnZXRBY3Rpdml0eUNvbG9yKGFjdGl2aXR5Py50eXBlKX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbWluLXctMFwiPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXRleHQtcHJpbWFyeSBmb250LW1lZGl1bSB0cnVuY2F0ZVwiPlxyXG4gICAgICAgICAgICAgICAgICB7YWN0aXZpdHk/LnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMiB0ZXh0LXhzIHRleHQtdGV4dC1zZWNvbmRhcnkgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3Bhbj57YWN0aXZpdHk/LnVzZXJ9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICB7YWN0aXZpdHk/LmNvbnRhY3QgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj7igKI8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57YWN0aXZpdHk/LmNvbnRhY3R9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICB7YWN0aXZpdHk/LmNvbXBhbnkgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj7igKI8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57YWN0aXZpdHk/LmNvbXBhbnl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC10ZXh0LXRlcnRpYXJ5IG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAge2Zvcm1hdFRpbWVBZ28oYWN0aXZpdHk/LnRpbWUpfVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICkpfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTMgYm9yZGVyLXQgYm9yZGVyLWJvcmRlclwiPlxyXG4gICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1wcmltYXJ5IGhvdmVyOnRleHQtcHJpbWFyeS02MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICBWaWV3IGFsbCBhY3Rpdml0eSDihpJcclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBSZWNlbnRBY3Rpdml0eTsiXSwiZmlsZSI6IkQ6L2N1cnJlbnQgcHJvamVjdHMvY2xhdWRlLWNvZGUvc3JjL3BhZ2VzL3NhbGVzLWRhc2hib2FyZC9jb21wb25lbnRzL1JlY2VudEFjdGl2aXR5LmpzeCJ9