import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/deal-management/components/DealForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import Icon from "/src/components/AppIcon.jsx";
import { useAuth } from "/src/contexts/AuthContext.jsx";
import dealsService from "/src/services/dealsService.js";
import contactsService from "/src/services/contactsService.js";
import companiesService from "/src/services/companiesService.js";
const DealForm = ({ deal = null, contacts = [], companies = [], stages = [], onSubmit, onCancel, isSaving = false }) => {
  _s();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    value: "",
    stage: "lead",
    probability: 10,
    expected_close_date: "",
    contact_id: "",
    company_id: "",
    lead_source: "website",
    next_step: "",
    competitor_info: "",
    tags: [],
    owner_id: user?.id || ""
  });
  const [errors, setErrors] = useState({});
  const [newTag, setNewTag] = useState("");
  useEffect(() => {
    if (deal) {
      setFormData({
        name: deal?.name || "",
        description: deal?.description || "",
        value: deal?.value?.toString() || "",
        stage: deal?.stage || "lead",
        probability: deal?.probability || 10,
        expected_close_date: deal?.expected_close_date || "",
        contact_id: deal?.contact_id || "",
        company_id: deal?.company_id || "",
        lead_source: deal?.lead_source || "website",
        next_step: deal?.next_step || "",
        competitor_info: deal?.competitor_info || "",
        tags: deal?.tags || [],
        owner_id: deal?.owner_id || user?.id || ""
      });
    } else {
      setFormData({
        name: "",
        description: "",
        value: "",
        stage: "lead",
        probability: 10,
        expected_close_date: "",
        contact_id: "",
        company_id: "",
        lead_source: "website",
        next_step: "",
        competitor_info: "",
        tags: [],
        owner_id: user?.id || ""
      });
    }
  }, [deal, user?.id]);
  const handleSubmit = async (e) => {
    e?.preventDefault();
    setLoading(true);
    setErrors({});
    try {
      const requiredFields = ["name", "value"];
      const validationErrors = {};
      requiredFields?.forEach((field) => {
        if (!formData?.[field]?.toString()?.trim()) {
          validationErrors[field] = `${field?.replace("_", " ")} is required`;
        }
      });
      if (formData?.value && (isNaN(formData?.value) || parseFloat(formData?.value) < 0)) {
        validationErrors.value = "Please enter a valid deal value";
      }
      if (formData?.expected_close_date && new Date(formData?.expected_close_date) < /* @__PURE__ */ new Date()) {
        validationErrors.expected_close_date = "Expected close date cannot be in the past";
      }
      if (Object.keys(validationErrors)?.length > 0) {
        setErrors(validationErrors);
        setLoading(false);
        return;
      }
      const submitData = {
        ...formData,
        value: parseFloat(formData?.value) || 0,
        expected_close_date: formData?.expected_close_date || null
      };
      let result;
      if (deal) {
        result = await dealsService?.updateDeal(deal?.id, submitData);
      } else {
        result = await dealsService?.createDeal(submitData);
      }
      onSubmit(result);
    } catch (err) {
      console.error("Error saving deal:", err);
      setErrors({
        submit: err?.message || "Failed to save deal. Please try again."
      });
    } finally {
      setLoading(false);
    }
  };
  const handleInputChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (field === "stage") {
      const stageProbs = {
        lead: 10,
        qualified: 25,
        proposal: 50,
        negotiation: 75,
        closed_won: 100,
        closed_lost: 0
      };
      setFormData((prev) => ({
        ...prev,
        [field]: value,
        probability: stageProbs?.[value] || prev?.probability
      }));
    }
    if (errors?.[field]) {
      setErrors((prev) => {
        const newErrors = { ...prev };
        delete newErrors?.[field];
        return newErrors;
      });
    }
  };
  const addTag = () => {
    if (newTag?.trim() && !formData?.tags?.includes(newTag?.trim())) {
      setFormData((prev) => ({
        ...prev,
        tags: [...prev?.tags || [], newTag?.trim()]
      }));
      setNewTag("");
    }
  };
  const removeTag = (tagToRemove) => {
    setFormData((prev) => ({
      ...prev,
      tags: prev?.tags?.filter((tag) => tag !== tagToRemove) || []
    }));
  };
  const handleContactChange = (contactId) => {
    const selectedContact = contacts?.find((c) => c?.id === contactId);
    setFormData((prev) => ({
      ...prev,
      contact_id: contactId,
      company_id: selectedContact?.company_id || prev?.company_id
    }));
  };
  const dealStages = stages.length > 0 ? stages : [
    { value: "lead", label: "Lead" },
    { value: "qualified", label: "Qualified" },
    { value: "proposal", label: "Proposal" },
    { value: "negotiation", label: "Negotiation" },
    { value: "closed_won", label: "Closed Won" },
    { value: "closed_lost", label: "Closed Lost" }
  ];
  const leadSources = [
    { value: "website", label: "Website" },
    { value: "referral", label: "Referral" },
    { value: "cold_call", label: "Cold Call" },
    { value: "email_campaign", label: "Email Campaign" },
    { value: "social_media", label: "Social Media" },
    { value: "event", label: "Event" },
    { value: "partner", label: "Partner" },
    { value: "other", label: "Other" }
  ];
  console.log("DealForm rendering - deal:", deal?.id, "contacts:", contacts.length, "companies:", companies.length, "stages:", stages.length);
  return /* @__PURE__ */ jsxDEV("form", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:207:4", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "207", "data-component-file": "DealForm.jsx", "data-component-name": "form", "data-component-content": "%7B%22elementName%22%3A%22form%22%2C%22className%22%3A%22space-y-6%22%7D", onSubmit: handleSubmit, className: "space-y-6", children: [
    errors?.submit && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:210:6", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "210", "data-component-file": "DealForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-error-50%20border%20border-error-200%20text-error%20p-4%20rounded-lg%20flex%20items-center%20space-x-2%22%7D", className: "bg-error-50 border border-error-200 text-error p-4 rounded-lg flex items-center space-x-2", children: [
      /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:211:10", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "211", "data-component-file": "DealForm.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22AlertCircle%22%7D", name: "AlertCircle", size: 20 }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
        lineNumber: 211,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:212:10", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "212", "data-component-file": "DealForm.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: errors?.submit }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
        lineNumber: 212,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
      lineNumber: 210,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:217:6", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "217", "data-component-file": "DealForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
      /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:218:8", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "218", "data-component-file": "DealForm.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Deal%20Name%20*%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Deal Name *" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
        lineNumber: 218,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:221:8",
          "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx",
          "data-component-line": "221",
          "data-component-file": "DealForm.jsx",
          "data-component-name": "input",
          "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22text%22%7D",
          type: "text",
          value: formData?.name,
          onChange: (e) => handleInputChange("name", e?.target?.value),
          className: `w-full px-3 py-2 border rounded-lg focus:ring-primary focus:border-primary ${errors?.name ? "border-error" : "border-border"}`,
          placeholder: "Enterprise Software License - Acme Corp",
          required: true
        },
        void 0,
        false,
        {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
          lineNumber: 221,
          columnNumber: 9
        },
        this
      ),
      errors?.name && /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:232:8", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "232", "data-component-file": "DealForm.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%20text-error%20mt-1%22%7D", className: "text-sm text-error mt-1", children: errors?.name }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
        lineNumber: 232,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
      lineNumber: 217,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:237:6", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "237", "data-component-file": "DealForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20md%3Agrid-cols-3%20gap-4%22%7D", className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:238:8", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "238", "data-component-file": "DealForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
        /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:239:10", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "239", "data-component-file": "DealForm.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Deal%20Value%20*%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Deal Value *" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
          lineNumber: 239,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:242:10", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "242", "data-component-file": "DealForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22relative%22%7D", className: "relative", children: [
          /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:243:12", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "243", "data-component-file": "DealForm.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22absolute%20left-3%20top-1%2F2%20transform%20-translate-y-1%2F2%20text-text-secondary%22%2C%22textContent%22%3A%22%24%22%7D", className: "absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary", children: "$" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
            lineNumber: 243,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:244:12",
              "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx",
              "data-component-line": "244",
              "data-component-file": "DealForm.jsx",
              "data-component-name": "input",
              "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22number%22%7D",
              type: "number",
              min: "0",
              step: "0.01",
              value: formData?.value,
              onChange: (e) => handleInputChange("value", e?.target?.value),
              className: `w-full pl-8 pr-3 py-2 border rounded-lg focus:ring-primary focus:border-primary ${errors?.value ? "border-error" : "border-border"}`,
              placeholder: "50000",
              required: true
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
              lineNumber: 244,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
          lineNumber: 242,
          columnNumber: 11
        }, this),
        errors?.value && /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:258:10", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "258", "data-component-file": "DealForm.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%20text-error%20mt-1%22%7D", className: "text-sm text-error mt-1", children: errors?.value }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
          lineNumber: 258,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
        lineNumber: 238,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:262:8", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "262", "data-component-file": "DealForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
        /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:263:10", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "263", "data-component-file": "DealForm.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Stage%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Stage" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
          lineNumber: 263,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "select",
          {
            "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:266:10",
            "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx",
            "data-component-line": "266",
            "data-component-file": "DealForm.jsx",
            "data-component-name": "select",
            "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
            value: formData?.stage,
            onChange: (e) => handleInputChange("stage", e?.target?.value),
            className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
            children: dealStages?.map(
              (stage) => /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:272:12", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "272", "data-component-file": "DealForm.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%7D", value: stage?.value, children: stage?.label }, stage?.value, false, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
                lineNumber: 272,
                columnNumber: 13
              }, this)
            )
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
            lineNumber: 266,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
        lineNumber: 262,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:279:8", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "279", "data-component-file": "DealForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
        /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:280:10", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "280", "data-component-file": "DealForm.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Probability%20(%25)%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Probability (%)" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
          lineNumber: 280,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:283:10",
            "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx",
            "data-component-line": "283",
            "data-component-file": "DealForm.jsx",
            "data-component-name": "input",
            "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22number%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
            type: "number",
            min: "0",
            max: "100",
            value: formData?.probability,
            onChange: (e) => handleInputChange("probability", parseInt(e?.target?.value) || 0),
            className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary"
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
            lineNumber: 283,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
        lineNumber: 279,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
      lineNumber: 237,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:295:6", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "295", "data-component-file": "DealForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20md%3Agrid-cols-2%20gap-4%22%7D", className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:296:8", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "296", "data-component-file": "DealForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
        /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:297:10", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "297", "data-component-file": "DealForm.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Primary%20Contact%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Primary Contact" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
          lineNumber: 297,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "select",
          {
            "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:300:10",
            "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx",
            "data-component-line": "300",
            "data-component-file": "DealForm.jsx",
            "data-component-name": "select",
            "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
            value: formData?.contact_id,
            onChange: (e) => handleContactChange(e?.target?.value),
            className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
            children: [
              /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:305:12", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "305", "data-component-file": "DealForm.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22%22%2C%22textContent%22%3A%22Select%20Contact%22%7D", value: "", children: "Select Contact" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
                lineNumber: 305,
                columnNumber: 13
              }, this),
              contacts?.map(
                (contact) => /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:307:12", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "307", "data-component-file": "DealForm.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22textContent%22%3A%22-%22%7D", value: contact?.id, children: [
                  contact?.full_name || `${contact?.first_name} ${contact?.last_name}`,
                  " - ",
                  contact?.company?.name
                ] }, contact?.id, true, {
                  fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
                  lineNumber: 307,
                  columnNumber: 13
                }, this)
              )
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
            lineNumber: 300,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
        lineNumber: 296,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:314:8", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "314", "data-component-file": "DealForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
        /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:315:10", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "315", "data-component-file": "DealForm.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Company%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Company" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
          lineNumber: 315,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "select",
          {
            "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:318:10",
            "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx",
            "data-component-line": "318",
            "data-component-file": "DealForm.jsx",
            "data-component-name": "select",
            "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
            value: formData?.company_id,
            onChange: (e) => handleInputChange("company_id", e?.target?.value),
            className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
            children: [
              /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:323:12", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "323", "data-component-file": "DealForm.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22%22%2C%22textContent%22%3A%22Select%20Company%22%7D", value: "", children: "Select Company" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
                lineNumber: 323,
                columnNumber: 13
              }, this),
              companies?.map(
                (company) => /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:325:12", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "325", "data-component-file": "DealForm.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%7D", value: company?.id, children: company?.name }, company?.id, false, {
                  fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
                  lineNumber: 325,
                  columnNumber: 13
                }, this)
              )
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
            lineNumber: 318,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
        lineNumber: 314,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
      lineNumber: 295,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:334:6", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "334", "data-component-file": "DealForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20md%3Agrid-cols-2%20gap-4%22%7D", className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:335:8", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "335", "data-component-file": "DealForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
        /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:336:10", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "336", "data-component-file": "DealForm.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Expected%20Close%20Date%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Expected Close Date" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
          lineNumber: 336,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:339:10",
            "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx",
            "data-component-line": "339",
            "data-component-file": "DealForm.jsx",
            "data-component-name": "input",
            "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22date%22%7D",
            type: "date",
            value: formData?.expected_close_date,
            onChange: (e) => handleInputChange("expected_close_date", e?.target?.value),
            className: `w-full px-3 py-2 border rounded-lg focus:ring-primary focus:border-primary ${errors?.expected_close_date ? "border-error" : "border-border"}`,
            min: (/* @__PURE__ */ new Date())?.toISOString()?.split("T")?.[0]
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
            lineNumber: 339,
            columnNumber: 11
          },
          this
        ),
        errors?.expected_close_date && /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:349:10", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "349", "data-component-file": "DealForm.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%20text-error%20mt-1%22%7D", className: "text-sm text-error mt-1", children: errors?.expected_close_date }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
          lineNumber: 349,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
        lineNumber: 335,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:353:8", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "353", "data-component-file": "DealForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
        /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:354:10", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "354", "data-component-file": "DealForm.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Lead%20Source%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Lead Source" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
          lineNumber: 354,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "select",
          {
            "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:357:10",
            "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx",
            "data-component-line": "357",
            "data-component-file": "DealForm.jsx",
            "data-component-name": "select",
            "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
            value: formData?.lead_source,
            onChange: (e) => handleInputChange("lead_source", e?.target?.value),
            className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
            children: leadSources?.map(
              (source) => /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:363:12", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "363", "data-component-file": "DealForm.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%7D", value: source?.value, children: source?.label }, source?.value, false, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
                lineNumber: 363,
                columnNumber: 13
              }, this)
            )
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
            lineNumber: 357,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
        lineNumber: 353,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
      lineNumber: 334,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:372:6", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "372", "data-component-file": "DealForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
      /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:373:8", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "373", "data-component-file": "DealForm.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Description%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Description" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
        lineNumber: 373,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "textarea",
        {
          "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:376:8",
          "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx",
          "data-component-line": "376",
          "data-component-file": "DealForm.jsx",
          "data-component-name": "textarea",
          "data-component-content": "%7B%22elementName%22%3A%22textarea%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
          value: formData?.description,
          onChange: (e) => handleInputChange("description", e?.target?.value),
          rows: 4,
          className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
          placeholder: "Describe the deal, requirements, and key details..."
        },
        void 0,
        false,
        {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
          lineNumber: 376,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
      lineNumber: 372,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:386:6", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "386", "data-component-file": "DealForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20md%3Agrid-cols-2%20gap-4%22%7D", className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:387:8", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "387", "data-component-file": "DealForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
        /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:388:10", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "388", "data-component-file": "DealForm.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Next%20Step%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Next Step" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
          lineNumber: 388,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:391:10",
            "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx",
            "data-component-line": "391",
            "data-component-file": "DealForm.jsx",
            "data-component-name": "input",
            "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22text%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
            type: "text",
            value: formData?.next_step,
            onChange: (e) => handleInputChange("next_step", e?.target?.value),
            className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
            placeholder: "Schedule demo, send proposal, etc."
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
            lineNumber: 391,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
        lineNumber: 387,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:400:8", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "400", "data-component-file": "DealForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
        /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:401:10", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "401", "data-component-file": "DealForm.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Competitor%20Information%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Competitor Information" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
          lineNumber: 401,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:404:10",
            "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx",
            "data-component-line": "404",
            "data-component-file": "DealForm.jsx",
            "data-component-name": "input",
            "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22text%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
            type: "text",
            value: formData?.competitor_info,
            onChange: (e) => handleInputChange("competitor_info", e?.target?.value),
            className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
            placeholder: "Competing against..."
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
            lineNumber: 404,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
        lineNumber: 400,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
      lineNumber: 386,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:415:6", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "415", "data-component-file": "DealForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
      /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:416:8", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "416", "data-component-file": "DealForm.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Tags%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Tags" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
        lineNumber: 416,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:419:8", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "419", "data-component-file": "DealForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20flex-wrap%20gap-2%20mb-2%22%7D", className: "flex flex-wrap gap-2 mb-2", children: formData?.tags?.map(
        (tag, index) => /* @__PURE__ */ jsxDEV(
          "span",
          {
            "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:421:10",
            "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx",
            "data-component-line": "421",
            "data-component-file": "DealForm.jsx",
            "data-component-name": "span",
            "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22inline-flex%20items-center%20px-2%20py-1%20rounded-full%20text-xs%20font-medium%20bg-primary-100%20text-primary-800%22%7D",
            className: "inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-primary-100 text-primary-800",
            children: [
              tag,
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:426:14",
                  "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx",
                  "data-component-line": "426",
                  "data-component-file": "DealForm.jsx",
                  "data-component-name": "button",
                  "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22button%22%2C%22className%22%3A%22ml-1%20text-primary-600%20hover%3Atext-primary-800%22%7D",
                  type: "button",
                  onClick: () => removeTag(tag),
                  className: "ml-1 text-primary-600 hover:text-primary-800",
                  children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:431:16", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "431", "data-component-file": "DealForm.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22X%22%7D", name: "X", size: 12 }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
                    lineNumber: 431,
                    columnNumber: 17
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
                  lineNumber: 426,
                  columnNumber: 15
                },
                this
              )
            ]
          },
          index,
          true,
          {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
            lineNumber: 421,
            columnNumber: 11
          },
          this
        )
      ) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
        lineNumber: 419,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:436:8", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "436", "data-component-file": "DealForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20space-x-2%22%7D", className: "flex space-x-2", children: [
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:437:10",
            "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx",
            "data-component-line": "437",
            "data-component-file": "DealForm.jsx",
            "data-component-name": "input",
            "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22text%22%2C%22value%22%3A%22%5Bvar%3AnewTag%5D%22%2C%22className%22%3A%22flex-1%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
            type: "text",
            value: newTag,
            onChange: (e) => setNewTag(e?.target?.value),
            onKeyPress: (e) => e?.key === "Enter" && (e?.preventDefault(), addTag()),
            className: "flex-1 px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
            placeholder: "Add a tag and press Enter"
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
            lineNumber: 437,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:445:10",
            "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx",
            "data-component-line": "445",
            "data-component-file": "DealForm.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22button%22%2C%22className%22%3A%22px-3%20py-2%20bg-text-secondary%20text-white%20rounded-lg%20hover%3Abg-text-primary%20transition-colors%20duration-150%22%2C%22textContent%22%3A%22Add%22%7D",
            type: "button",
            onClick: addTag,
            className: "px-3 py-2 bg-text-secondary text-white rounded-lg hover:bg-text-primary transition-colors duration-150",
            children: "Add"
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
            lineNumber: 445,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
        lineNumber: 436,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
      lineNumber: 415,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:456:6", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "456", "data-component-file": "DealForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20justify-end%20space-x-3%20pt-4%20border-t%20border-border%22%7D", className: "flex justify-end space-x-3 pt-4 border-t border-border", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:457:8",
          "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx",
          "data-component-line": "457",
          "data-component-file": "DealForm.jsx",
          "data-component-name": "button",
          "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22button%22%2C%22className%22%3A%22px-4%20py-2%20text-text-secondary%20hover%3Atext-text-primary%20transition-colors%20duration-150%22%2C%22textContent%22%3A%22Cancel%22%7D",
          type: "button",
          onClick: onCancel,
          className: "px-4 py-2 text-text-secondary hover:text-text-primary transition-colors duration-150",
          disabled: loading || isSaving,
          children: "Cancel"
        },
        void 0,
        false,
        {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
          lineNumber: 457,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:465:8",
          "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx",
          "data-component-line": "465",
          "data-component-file": "DealForm.jsx",
          "data-component-name": "button",
          "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22submit%22%2C%22className%22%3A%22bg-primary%20text-white%20px-4%20py-2%20rounded-lg%20hover%3Abg-primary-600%20transition-colors%20duration-150%20ease-smooth%20flex%20items-center%20space-x-2%22%7D",
          type: "submit",
          disabled: loading || isSaving,
          className: "bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary-600 transition-colors duration-150 ease-smooth flex items-center space-x-2",
          children: [
            (loading || isSaving) && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:470:36", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "470", "data-component-file": "DealForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22animate-spin%20rounded-full%20h-4%20w-4%20border-b-2%20border-white%22%7D", className: "animate-spin rounded-full h-4 w-4 border-b-2 border-white" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
              lineNumber: 470,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\DealForm.jsx:471:10", "data-component-path": "src\\pages\\deal-management\\components\\DealForm.jsx", "data-component-line": "471", "data-component-file": "DealForm.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: deal ? "Update Deal" : "Create Deal" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
              lineNumber: 471,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
          lineNumber: 465,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
      lineNumber: 456,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx",
    lineNumber: 207,
    columnNumber: 5
  }, this);
};
_s(DealForm, "TO07HaKHkQ5t29YgS+Zsy7COnJU=", false, function() {
  return [useAuth];
});
_c = DealForm;
export default DealForm;
var _c;
$RefreshReg$(_c, "DealForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/deal-management/components/DealForm.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa05VOzJCQWxOVjtBQUFnQkEsTUFBVUMsY0FBUyxPQUFRLHNCQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ2xELE9BQU9DLFVBQVU7QUFDakIsU0FBU0MsZUFBZTtBQUN4QixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0MscUJBQXFCO0FBQzVCLE9BQU9DLHNCQUFzQjtBQUU3QixNQUFNQyxXQUFXQSxDQUFDLEVBQUVDLE9BQU8sTUFBTUMsV0FBVyxJQUFJQyxZQUFZLElBQUlDLFNBQVMsSUFBSUMsVUFBVUMsVUFBVUMsV0FBVyxNQUFNLE1BQU07QUFBQUMsS0FBQTtBQUN0SCxRQUFNLEVBQUVDLEtBQUssSUFBSWIsUUFBUTtBQUN6QixRQUFNLENBQUNjLFNBQVNDLFVBQVUsSUFBSWxCLFNBQVMsS0FBSztBQUM1QyxRQUFNLENBQUNtQixVQUFVQyxXQUFXLElBQUlwQixTQUFTO0FBQUEsSUFDdkNxQixNQUFNO0FBQUEsSUFDTkMsYUFBYTtBQUFBLElBQ2JDLE9BQU87QUFBQSxJQUNQQyxPQUFPO0FBQUEsSUFDUEMsYUFBYTtBQUFBLElBQ2JDLHFCQUFxQjtBQUFBLElBQ3JCQyxZQUFZO0FBQUEsSUFDWkMsWUFBWTtBQUFBLElBQ1pDLGFBQWE7QUFBQSxJQUNiQyxXQUFXO0FBQUEsSUFDWEMsaUJBQWlCO0FBQUEsSUFDakJDLE1BQU07QUFBQSxJQUNOQyxVQUFVakIsTUFBTWtCLE1BQU07QUFBQSxFQUN4QixDQUFDO0FBQ0QsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUlwQyxTQUFTLENBQUMsQ0FBQztBQUN2QyxRQUFNLENBQUNxQyxRQUFRQyxTQUFTLElBQUl0QyxTQUFTLEVBQUU7QUFHdkNDLFlBQVUsTUFBTTtBQUNkLFFBQUlPLE1BQU07QUFDUlksa0JBQVk7QUFBQSxRQUNWQyxNQUFNYixNQUFNYSxRQUFRO0FBQUEsUUFDcEJDLGFBQWFkLE1BQU1jLGVBQWU7QUFBQSxRQUNsQ0MsT0FBT2YsTUFBTWUsT0FBT2dCLFNBQVMsS0FBSztBQUFBLFFBQ2xDZixPQUFPaEIsTUFBTWdCLFNBQVM7QUFBQSxRQUN0QkMsYUFBYWpCLE1BQU1pQixlQUFlO0FBQUEsUUFDbENDLHFCQUFxQmxCLE1BQU1rQix1QkFBdUI7QUFBQSxRQUNsREMsWUFBWW5CLE1BQU1tQixjQUFjO0FBQUEsUUFDaENDLFlBQVlwQixNQUFNb0IsY0FBYztBQUFBLFFBQ2hDQyxhQUFhckIsTUFBTXFCLGVBQWU7QUFBQSxRQUNsQ0MsV0FBV3RCLE1BQU1zQixhQUFhO0FBQUEsUUFDOUJDLGlCQUFpQnZCLE1BQU11QixtQkFBbUI7QUFBQSxRQUMxQ0MsTUFBTXhCLE1BQU13QixRQUFRO0FBQUEsUUFDcEJDLFVBQVV6QixNQUFNeUIsWUFBWWpCLE1BQU1rQixNQUFNO0FBQUEsTUFDMUMsQ0FBQztBQUFBLElBQ0gsT0FBTztBQUVMZCxrQkFBWTtBQUFBLFFBQ1ZDLE1BQU07QUFBQSxRQUNOQyxhQUFhO0FBQUEsUUFDYkMsT0FBTztBQUFBLFFBQ1BDLE9BQU87QUFBQSxRQUNQQyxhQUFhO0FBQUEsUUFDYkMscUJBQXFCO0FBQUEsUUFDckJDLFlBQVk7QUFBQSxRQUNaQyxZQUFZO0FBQUEsUUFDWkMsYUFBYTtBQUFBLFFBQ2JDLFdBQVc7QUFBQSxRQUNYQyxpQkFBaUI7QUFBQSxRQUNqQkMsTUFBTTtBQUFBLFFBQ05DLFVBQVVqQixNQUFNa0IsTUFBTTtBQUFBLE1BQ3hCLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRixHQUFHLENBQUMxQixNQUFNUSxNQUFNa0IsRUFBRSxDQUFDO0FBRW5CLFFBQU1NLGVBQWUsT0FBT0MsTUFBTTtBQUNoQ0EsT0FBR0MsZUFBZTtBQUNsQnhCLGVBQVcsSUFBSTtBQUNma0IsY0FBVSxDQUFDLENBQUM7QUFFWixRQUFJO0FBRUYsWUFBTU8saUJBQWlCLENBQUMsUUFBUSxPQUFPO0FBQ3ZDLFlBQU1DLG1CQUFtQixDQUFDO0FBRTFCRCxzQkFBZ0JFLFFBQVEsQ0FBQUMsVUFBUztBQUMvQixZQUFJLENBQUMzQixXQUFXMkIsS0FBSyxHQUFHUCxTQUFTLEdBQUdRLEtBQUssR0FBRztBQUMxQ0gsMkJBQWlCRSxLQUFLLElBQUksR0FBR0EsT0FBT0UsUUFBUSxLQUFLLEdBQUcsQ0FBQztBQUFBLFFBQ3ZEO0FBQUEsTUFDRixDQUFDO0FBR0QsVUFBSTdCLFVBQVVJLFVBQVUwQixNQUFNOUIsVUFBVUksS0FBSyxLQUFLMkIsV0FBVy9CLFVBQVVJLEtBQUssSUFBSSxJQUFJO0FBQ2xGcUIseUJBQWlCckIsUUFBUTtBQUFBLE1BQzNCO0FBR0EsVUFBSUosVUFBVU8sdUJBQXVCLElBQUl5QixLQUFLaEMsVUFBVU8sbUJBQW1CLElBQUksb0JBQUl5QixLQUFLLEdBQUc7QUFDekZQLHlCQUFpQmxCLHNCQUFzQjtBQUFBLE1BQ3pDO0FBRUEsVUFBSTBCLE9BQU9DLEtBQUtULGdCQUFnQixHQUFHVSxTQUFTLEdBQUc7QUFDN0NsQixrQkFBVVEsZ0JBQWdCO0FBQzFCMUIsbUJBQVcsS0FBSztBQUNoQjtBQUFBLE1BQ0Y7QUFHQSxZQUFNcUMsYUFBYTtBQUFBLFFBQ2pCLEdBQUdwQztBQUFBQSxRQUNISSxPQUFPMkIsV0FBVy9CLFVBQVVJLEtBQUssS0FBSztBQUFBLFFBQ3RDRyxxQkFBcUJQLFVBQVVPLHVCQUF1QjtBQUFBLE1BQ3hEO0FBRUEsVUFBSThCO0FBQ0osVUFBSWhELE1BQU07QUFFUmdELGlCQUFTLE1BQU1wRCxjQUFjcUQsV0FBV2pELE1BQU0wQixJQUFJcUIsVUFBVTtBQUFBLE1BQzlELE9BQU87QUFFTEMsaUJBQVMsTUFBTXBELGNBQWNzRCxXQUFXSCxVQUFVO0FBQUEsTUFDcEQ7QUFFQTNDLGVBQVM0QyxNQUFNO0FBQUEsSUFDakIsU0FBU0csS0FBSztBQUNaQyxjQUFRQyxNQUFNLHNCQUFzQkYsR0FBRztBQUN2Q3ZCLGdCQUFVO0FBQUEsUUFDUjBCLFFBQVFILEtBQUtJLFdBQVc7QUFBQSxNQUMxQixDQUFDO0FBQUEsSUFDSCxVQUFDO0FBQ0M3QyxpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBRUEsUUFBTThDLG9CQUFvQkEsQ0FBQ2xCLE9BQU92QixVQUFVO0FBQzFDSCxnQkFBWSxDQUFBNkMsVUFBUyxFQUFFLEdBQUdBLE1BQU0sQ0FBQ25CLEtBQUssR0FBR3ZCLE1BQU0sRUFBRTtBQUdqRCxRQUFJdUIsVUFBVSxTQUFTO0FBQ3JCLFlBQU1vQixhQUFhO0FBQUEsUUFDakJDLE1BQU07QUFBQSxRQUNOQyxXQUFXO0FBQUEsUUFDWEMsVUFBVTtBQUFBLFFBQ1ZDLGFBQWE7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsYUFBYTtBQUFBLE1BQ2Y7QUFDQXBELGtCQUFZLENBQUE2QyxVQUFTO0FBQUEsUUFDbkIsR0FBR0E7QUFBQUEsUUFDSCxDQUFDbkIsS0FBSyxHQUFHdkI7QUFBQUEsUUFDVEUsYUFBYXlDLGFBQWEzQyxLQUFLLEtBQUswQyxNQUFNeEM7QUFBQUEsTUFDNUMsRUFBRTtBQUFBLElBQ0o7QUFHQSxRQUFJVSxTQUFTVyxLQUFLLEdBQUc7QUFDbkJWLGdCQUFVLENBQUE2QixTQUFRO0FBQ2hCLGNBQU1RLFlBQVksRUFBRSxHQUFHUixLQUFLO0FBQzVCLGVBQU9RLFlBQVkzQixLQUFLO0FBQ3hCLGVBQU8yQjtBQUFBQSxNQUNULENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUVBLFFBQU1DLFNBQVNBLE1BQU07QUFDbkIsUUFBSXJDLFFBQVFVLEtBQUssS0FBSyxDQUFDNUIsVUFBVWEsTUFBTTJDLFNBQVN0QyxRQUFRVSxLQUFLLENBQUMsR0FBRztBQUMvRDNCLGtCQUFZLENBQUE2QyxVQUFTO0FBQUEsUUFDbkIsR0FBR0E7QUFBQUEsUUFDSGpDLE1BQU0sQ0FBQyxHQUFJaUMsTUFBTWpDLFFBQVEsSUFBS0ssUUFBUVUsS0FBSyxDQUFDO0FBQUEsTUFDOUMsRUFBRTtBQUNGVCxnQkFBVSxFQUFFO0FBQUEsSUFDZDtBQUFBLEVBQ0Y7QUFFQSxRQUFNc0MsWUFBWUEsQ0FBQ0MsZ0JBQWdCO0FBQ2pDekQsZ0JBQVksQ0FBQTZDLFVBQVM7QUFBQSxNQUNuQixHQUFHQTtBQUFBQSxNQUNIakMsTUFBTWlDLE1BQU1qQyxNQUFNOEMsT0FBTyxDQUFBQyxRQUFPQSxRQUFRRixXQUFXLEtBQUs7QUFBQSxJQUMxRCxFQUFFO0FBQUEsRUFDSjtBQUdBLFFBQU1HLHNCQUFzQkEsQ0FBQ0MsY0FBYztBQUN6QyxVQUFNQyxrQkFBa0J6RSxVQUFVMEUsS0FBSyxDQUFBQyxNQUFLQSxHQUFHbEQsT0FBTytDLFNBQVM7QUFDL0Q3RCxnQkFBWSxDQUFBNkMsVUFBUztBQUFBLE1BQ25CLEdBQUdBO0FBQUFBLE1BQ0h0QyxZQUFZc0Q7QUFBQUEsTUFDWnJELFlBQVlzRCxpQkFBaUJ0RCxjQUFjcUMsTUFBTXJDO0FBQUFBLElBQ25ELEVBQUU7QUFBQSxFQUNKO0FBR0EsUUFBTXlELGFBQWExRSxPQUFPMkMsU0FBUyxJQUFJM0MsU0FBUztBQUFBLElBQzlDLEVBQUVZLE9BQU8sUUFBUStELE9BQU8sT0FBTztBQUFBLElBQy9CLEVBQUUvRCxPQUFPLGFBQWErRCxPQUFPLFlBQVk7QUFBQSxJQUN6QyxFQUFFL0QsT0FBTyxZQUFZK0QsT0FBTyxXQUFXO0FBQUEsSUFDdkMsRUFBRS9ELE9BQU8sZUFBZStELE9BQU8sY0FBYztBQUFBLElBQzdDLEVBQUUvRCxPQUFPLGNBQWMrRCxPQUFPLGFBQWE7QUFBQSxJQUMzQyxFQUFFL0QsT0FBTyxlQUFlK0QsT0FBTyxjQUFjO0FBQUEsRUFBQztBQUdoRCxRQUFNQyxjQUFjO0FBQUEsSUFDbEIsRUFBRWhFLE9BQU8sV0FBVytELE9BQU8sVUFBVTtBQUFBLElBQ3JDLEVBQUUvRCxPQUFPLFlBQVkrRCxPQUFPLFdBQVc7QUFBQSxJQUN2QyxFQUFFL0QsT0FBTyxhQUFhK0QsT0FBTyxZQUFZO0FBQUEsSUFDekMsRUFBRS9ELE9BQU8sa0JBQWtCK0QsT0FBTyxpQkFBaUI7QUFBQSxJQUNuRCxFQUFFL0QsT0FBTyxnQkFBZ0IrRCxPQUFPLGVBQWU7QUFBQSxJQUMvQyxFQUFFL0QsT0FBTyxTQUFTK0QsT0FBTyxRQUFRO0FBQUEsSUFDakMsRUFBRS9ELE9BQU8sV0FBVytELE9BQU8sVUFBVTtBQUFBLElBQ3JDLEVBQUUvRCxPQUFPLFNBQVMrRCxPQUFPLFFBQVE7QUFBQSxFQUFDO0FBR3BDMUIsVUFBUTRCLElBQUksOEJBQThCaEYsTUFBTTBCLElBQUksYUFBYXpCLFNBQVM2QyxRQUFRLGNBQWM1QyxVQUFVNEMsUUFBUSxXQUFXM0MsT0FBTzJDLE1BQU07QUFFMUksU0FDRSx1QkFBQyx3WEFBSyxVQUFVZCxjQUFjLFdBQVUsYUFFckNMO0FBQUFBLFlBQVEyQixVQUNQLHVCQUFDLHFkQUFJLFdBQVUsNkZBQ2I7QUFBQSw2QkFBQyxvWEFBSyxNQUFLLGVBQWMsTUFBTSxNQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtDO0FBQUEsTUFDbEMsdUJBQUMscVZBQU0zQixrQkFBUTJCLFVBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzQjtBQUFBLFNBRnhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBSUYsdUJBQUMsaVZBQ0M7QUFBQSw2QkFBQyxzZEFBTSxXQUFVLG9EQUFtRCwyQkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsT0FBTzNDLFVBQVVFO0FBQUFBLFVBQ2pCLFVBQVUsQ0FBQ29CLE1BQU11QixrQkFBa0IsUUFBUXZCLEdBQUdnRCxRQUFRbEUsS0FBSztBQUFBLFVBQzNELFdBQVcsOEVBQ1RZLFFBQVFkLE9BQU8saUJBQWlCLGVBQWU7QUFBQSxVQUVqRCxhQUFZO0FBQUEsVUFDWixVQUFRO0FBQUE7QUFBQSxRQVJWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVFVO0FBQUEsTUFFVGMsUUFBUWQsUUFDUCx1QkFBQyxpWUFBRSxXQUFVLDJCQUEyQmMsa0JBQVFkLFFBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUQ7QUFBQSxTQWZ6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUJBO0FBQUEsSUFHQSx1QkFBQyx5WkFBSSxXQUFVLHlDQUNiO0FBQUEsNkJBQUMsaVZBQ0M7QUFBQSwrQkFBQyx3ZEFBTSxXQUFVLG9EQUFtRCw0QkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxxWEFBSSxXQUFVLFlBQ2I7QUFBQSxpQ0FBQyxvZUFBSyxXQUFVLDBFQUF5RSxpQkFBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEY7QUFBQSxVQUMxRjtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsS0FBSTtBQUFBLGNBQ0osTUFBSztBQUFBLGNBQ0wsT0FBT0YsVUFBVUk7QUFBQUEsY0FDakIsVUFBVSxDQUFDa0IsTUFBTXVCLGtCQUFrQixTQUFTdkIsR0FBR2dELFFBQVFsRSxLQUFLO0FBQUEsY0FDNUQsV0FBVyxtRkFDVFksUUFBUVosUUFBUSxpQkFBaUIsZUFBZTtBQUFBLGNBRWxELGFBQVk7QUFBQSxjQUNaLFVBQVE7QUFBQTtBQUFBLFlBVlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBVVU7QUFBQSxhQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFjQTtBQUFBLFFBQ0NZLFFBQVFaLFNBQ1AsdUJBQUMsa1lBQUUsV0FBVSwyQkFBMkJZLGtCQUFRWixTQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNEO0FBQUEsV0FwQjFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzQkE7QUFBQSxNQUVBLHVCQUFDLGlWQUNDO0FBQUEsK0JBQUMsNmNBQU0sV0FBVSxvREFBbUQscUJBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUNDLE9BQU9KLFVBQVVLO0FBQUFBLFlBQ2pCLFVBQVUsQ0FBQ2lCLE1BQU11QixrQkFBa0IsU0FBU3ZCLEdBQUdnRCxRQUFRbEUsS0FBSztBQUFBLFlBQzVELFdBQVU7QUFBQSxZQUVUOEQsc0JBQVlLO0FBQUFBLGNBQUksQ0FBQWxFLFVBQ2YsdUJBQUMsMlZBQTBCLE9BQU9BLE9BQU9ELE9BQ3RDQyxpQkFBTzhELFNBREc5RCxPQUFPRCxPQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsWUFDRDtBQUFBO0FBQUEsVUFUSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFVQTtBQUFBLFdBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWVBO0FBQUEsTUFFQSx1QkFBQyxpVkFDQztBQUFBLCtCQUFDLDJkQUFNLFdBQVUsb0RBQW1ELCtCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxLQUFJO0FBQUEsWUFDSixLQUFJO0FBQUEsWUFDSixPQUFPSixVQUFVTTtBQUFBQSxZQUNqQixVQUFVLENBQUNnQixNQUFNdUIsa0JBQWtCLGVBQWUyQixTQUFTbEQsR0FBR2dELFFBQVFsRSxLQUFLLEtBQUssQ0FBQztBQUFBLFlBQ2pGLFdBQVU7QUFBQTtBQUFBLFVBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTXNHO0FBQUEsV0FWeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsU0F0REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVEQTtBQUFBLElBR0EsdUJBQUMseVpBQUksV0FBVSx5Q0FDYjtBQUFBLDZCQUFDLGlWQUNDO0FBQUEsK0JBQUMseWRBQU0sV0FBVSxvREFBbUQsK0JBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUNDLE9BQU9KLFVBQVVRO0FBQUFBLFlBQ2pCLFVBQVUsQ0FBQ2MsTUFBTXVDLG9CQUFvQnZDLEdBQUdnRCxRQUFRbEUsS0FBSztBQUFBLFlBQ3JELFdBQVU7QUFBQSxZQUVWO0FBQUEscUNBQUMsK1pBQU8sT0FBTSxJQUFHLDhCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQjtBQUFBLGNBQzlCZCxVQUFVaUY7QUFBQUEsZ0JBQUksQ0FBQUUsWUFDYix1QkFBQyx5WEFBeUIsT0FBT0EsU0FBUzFELElBQ3ZDMEQ7QUFBQUEsMkJBQVNDLGFBQWEsR0FBR0QsU0FBU0UsVUFBVSxJQUFJRixTQUFTRyxTQUFTO0FBQUEsa0JBQUc7QUFBQSxrQkFBSUgsU0FBU0ksU0FBUzNFO0FBQUFBLHFCQURqRnVFLFNBQVMxRCxJQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsY0FDRDtBQUFBO0FBQUE7QUFBQSxVQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVdBO0FBQUEsV0FmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0JBO0FBQUEsTUFFQSx1QkFBQyxpVkFDQztBQUFBLCtCQUFDLCtjQUFNLFdBQVUsb0RBQW1ELHVCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFDQyxPQUFPZixVQUFVUztBQUFBQSxZQUNqQixVQUFVLENBQUNhLE1BQU11QixrQkFBa0IsY0FBY3ZCLEdBQUdnRCxRQUFRbEUsS0FBSztBQUFBLFlBQ2pFLFdBQVU7QUFBQSxZQUVWO0FBQUEscUNBQUMsK1pBQU8sT0FBTSxJQUFHLDhCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQjtBQUFBLGNBQzlCYixXQUFXZ0Y7QUFBQUEsZ0JBQUksQ0FBQU0sWUFDZCx1QkFBQywyVkFBeUIsT0FBT0EsU0FBUzlELElBQ3ZDOEQsbUJBQVMzRSxRQURDMkUsU0FBUzlELElBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxjQUNEO0FBQUE7QUFBQTtBQUFBLFVBVkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBV0E7QUFBQSxXQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnQkE7QUFBQSxTQW5DRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb0NBO0FBQUEsSUFHQSx1QkFBQyx5WkFBSSxXQUFVLHlDQUNiO0FBQUEsNkJBQUMsaVZBQ0M7QUFBQSwrQkFBQywrZEFBTSxXQUFVLG9EQUFtRCxtQ0FBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsT0FBT2YsVUFBVU87QUFBQUEsWUFDakIsVUFBVSxDQUFDZSxNQUFNdUIsa0JBQWtCLHVCQUF1QnZCLEdBQUdnRCxRQUFRbEUsS0FBSztBQUFBLFlBQzFFLFdBQVcsOEVBQ1RZLFFBQVFULHNCQUFzQixpQkFBaUIsZUFBZTtBQUFBLFlBRWhFLE1BQUssb0JBQUl5QixLQUFLLElBQUc4QyxZQUFZLEdBQUdDLE1BQU0sR0FBRyxJQUFJLENBQUM7QUFBQTtBQUFBLFVBUGhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9rRDtBQUFBLFFBRWpEL0QsUUFBUVQsdUJBQ1AsdUJBQUMsa1lBQUUsV0FBVSwyQkFBMkJTLGtCQUFRVCx1QkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRTtBQUFBLFdBZHhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnQkE7QUFBQSxNQUVBLHVCQUFDLGlWQUNDO0FBQUEsK0JBQUMscWRBQU0sV0FBVSxvREFBbUQsMkJBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUNDLE9BQU9QLFVBQVVVO0FBQUFBLFlBQ2pCLFVBQVUsQ0FBQ1ksTUFBTXVCLGtCQUFrQixlQUFldkIsR0FBR2dELFFBQVFsRSxLQUFLO0FBQUEsWUFDbEUsV0FBVTtBQUFBLFlBRVRnRSx1QkFBYUc7QUFBQUEsY0FBSSxDQUFBUyxXQUNoQix1QkFBQywyVkFBMkIsT0FBT0EsUUFBUTVFLE9BQ3hDNEUsa0JBQVFiLFNBREVhLFFBQVE1RSxPQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsWUFDRDtBQUFBO0FBQUEsVUFUSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFVQTtBQUFBLFdBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWVBO0FBQUEsU0FsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1DQTtBQUFBLElBR0EsdUJBQUMsaVZBQ0M7QUFBQSw2QkFBQyxrZEFBTSxXQUFVLG9EQUFtRCwyQkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBQ0MsT0FBT0osVUFBVUc7QUFBQUEsVUFDakIsVUFBVSxDQUFDbUIsTUFBTXVCLGtCQUFrQixlQUFldkIsR0FBR2dELFFBQVFsRSxLQUFLO0FBQUEsVUFDbEUsTUFBTTtBQUFBLFVBQ04sV0FBVTtBQUFBLFVBQ1YsYUFBWTtBQUFBO0FBQUEsUUFMZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLbUU7QUFBQSxTQVRyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0E7QUFBQSxJQUdBLHVCQUFDLHlaQUFJLFdBQVUseUNBQ2I7QUFBQSw2QkFBQyxpVkFDQztBQUFBLCtCQUFDLG1kQUFNLFdBQVUsb0RBQW1ELHlCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxPQUFPSixVQUFVVztBQUFBQSxZQUNqQixVQUFVLENBQUNXLE1BQU11QixrQkFBa0IsYUFBYXZCLEdBQUdnRCxRQUFRbEUsS0FBSztBQUFBLFlBQ2hFLFdBQVU7QUFBQSxZQUNWLGFBQVk7QUFBQTtBQUFBLFVBTGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS2tEO0FBQUEsV0FUcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsTUFFQSx1QkFBQyxpVkFDQztBQUFBLCtCQUFDLGdlQUFNLFdBQVUsb0RBQW1ELHNDQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxPQUFPSixVQUFVWTtBQUFBQSxZQUNqQixVQUFVLENBQUNVLE1BQU11QixrQkFBa0IsbUJBQW1CdkIsR0FBR2dELFFBQVFsRSxLQUFLO0FBQUEsWUFDdEUsV0FBVTtBQUFBLFlBQ1YsYUFBWTtBQUFBO0FBQUEsVUFMZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLb0M7QUFBQSxXQVR0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxTQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMEJBO0FBQUEsSUFHQSx1QkFBQyxpVkFDQztBQUFBLDZCQUFDLDJjQUFNLFdBQVUsb0RBQW1ELG9CQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLDJZQUFJLFdBQVUsNkJBQ1pKLG9CQUFVYSxNQUFNMEQ7QUFBQUEsUUFBSSxDQUFDWCxLQUFLcUIsVUFDekI7QUFBQSxVQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUVDLFdBQVU7QUFBQSxZQUVUckI7QUFBQUE7QUFBQUEsY0FDRDtBQUFBLGdCQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsU0FBUyxNQUFNSCxVQUFVRyxHQUFHO0FBQUEsa0JBQzVCLFdBQVU7QUFBQSxrQkFFVixpQ0FBQywwV0FBSyxNQUFLLEtBQUksTUFBTSxNQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF3QjtBQUFBO0FBQUEsZ0JBTDFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1BO0FBQUE7QUFBQTtBQUFBLFVBVktxQjtBQUFBQSxVQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFZQTtBQUFBLE1BQ0QsS0FmSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0JBO0FBQUEsTUFDQSx1QkFBQyw0WEFBSSxXQUFVLGtCQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLE9BQU8vRDtBQUFBQSxZQUNQLFVBQVUsQ0FBQ0ksTUFBTUgsVUFBVUcsR0FBR2dELFFBQVFsRSxLQUFLO0FBQUEsWUFDM0MsWUFBWSxDQUFDa0IsTUFBTUEsR0FBRzRELFFBQVEsWUFBWTVELEdBQUdDLGVBQWUsR0FBR2dDLE9BQU87QUFBQSxZQUN0RSxXQUFVO0FBQUEsWUFDVixhQUFZO0FBQUE7QUFBQSxVQU5kO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU15QztBQUFBLFFBRXpDO0FBQUEsVUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTQTtBQUFBQSxZQUNULFdBQVU7QUFBQSxZQUF3RztBQUFBO0FBQUEsVUFIcEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUE7QUFBQSxXQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnQkE7QUFBQSxTQXJDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0NBO0FBQUEsSUFHQSx1QkFBQyw0YUFBSSxXQUFVLDBEQUNiO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFNBQVM3RDtBQUFBQSxVQUNULFdBQVU7QUFBQSxVQUNWLFVBQVVJLFdBQVdIO0FBQUFBLFVBQVM7QUFBQTtBQUFBLFFBSmhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9BO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsVUFBVUcsV0FBV0g7QUFBQUEsVUFDckIsV0FBVTtBQUFBLFVBRVJHO0FBQUFBLHdCQUFXSCxhQUFhLHVCQUFDLGdiQUFJLFdBQVUsK0RBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkU7QUFBQSxZQUNyRyx1QkFBQyxxVkFBTU4saUJBQU8sZ0JBQWdCLGlCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0QztBQUFBO0FBQUE7QUFBQSxRQU45QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFPQTtBQUFBLFNBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpQkE7QUFBQSxPQTFRRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMlFBO0FBRUo7QUFBRU8sR0FwZElSLFVBQVE7QUFBQSxVQUNLSixPQUFPO0FBQUE7QUFBQW1HLEtBRHBCL0Y7QUFzZE4sZUFBZUE7QUFBUyxJQUFBK0Y7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwiSWNvbiIsInVzZUF1dGgiLCJkZWFsc1NlcnZpY2UiLCJjb250YWN0c1NlcnZpY2UiLCJjb21wYW5pZXNTZXJ2aWNlIiwiRGVhbEZvcm0iLCJkZWFsIiwiY29udGFjdHMiLCJjb21wYW5pZXMiLCJzdGFnZXMiLCJvblN1Ym1pdCIsIm9uQ2FuY2VsIiwiaXNTYXZpbmciLCJfcyIsInVzZXIiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJuYW1lIiwiZGVzY3JpcHRpb24iLCJ2YWx1ZSIsInN0YWdlIiwicHJvYmFiaWxpdHkiLCJleHBlY3RlZF9jbG9zZV9kYXRlIiwiY29udGFjdF9pZCIsImNvbXBhbnlfaWQiLCJsZWFkX3NvdXJjZSIsIm5leHRfc3RlcCIsImNvbXBldGl0b3JfaW5mbyIsInRhZ3MiLCJvd25lcl9pZCIsImlkIiwiZXJyb3JzIiwic2V0RXJyb3JzIiwibmV3VGFnIiwic2V0TmV3VGFnIiwidG9TdHJpbmciLCJoYW5kbGVTdWJtaXQiLCJlIiwicHJldmVudERlZmF1bHQiLCJyZXF1aXJlZEZpZWxkcyIsInZhbGlkYXRpb25FcnJvcnMiLCJmb3JFYWNoIiwiZmllbGQiLCJ0cmltIiwicmVwbGFjZSIsImlzTmFOIiwicGFyc2VGbG9hdCIsIkRhdGUiLCJPYmplY3QiLCJrZXlzIiwibGVuZ3RoIiwic3VibWl0RGF0YSIsInJlc3VsdCIsInVwZGF0ZURlYWwiLCJjcmVhdGVEZWFsIiwiZXJyIiwiY29uc29sZSIsImVycm9yIiwic3VibWl0IiwibWVzc2FnZSIsImhhbmRsZUlucHV0Q2hhbmdlIiwicHJldiIsInN0YWdlUHJvYnMiLCJsZWFkIiwicXVhbGlmaWVkIiwicHJvcG9zYWwiLCJuZWdvdGlhdGlvbiIsImNsb3NlZF93b24iLCJjbG9zZWRfbG9zdCIsIm5ld0Vycm9ycyIsImFkZFRhZyIsImluY2x1ZGVzIiwicmVtb3ZlVGFnIiwidGFnVG9SZW1vdmUiLCJmaWx0ZXIiLCJ0YWciLCJoYW5kbGVDb250YWN0Q2hhbmdlIiwiY29udGFjdElkIiwic2VsZWN0ZWRDb250YWN0IiwiZmluZCIsImMiLCJkZWFsU3RhZ2VzIiwibGFiZWwiLCJsZWFkU291cmNlcyIsImxvZyIsInRhcmdldCIsIm1hcCIsInBhcnNlSW50IiwiY29udGFjdCIsImZ1bGxfbmFtZSIsImZpcnN0X25hbWUiLCJsYXN0X25hbWUiLCJjb21wYW55IiwidG9JU09TdHJpbmciLCJzcGxpdCIsInNvdXJjZSIsImluZGV4Iiwia2V5IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJEZWFsRm9ybS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCBJY29uIGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvQXBwSWNvbic7XHJcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tICcuLi8uLi8uLi9jb250ZXh0cy9BdXRoQ29udGV4dCc7XHJcbmltcG9ydCBkZWFsc1NlcnZpY2UgZnJvbSAnLi4vLi4vLi4vc2VydmljZXMvZGVhbHNTZXJ2aWNlJztcclxuaW1wb3J0IGNvbnRhY3RzU2VydmljZSBmcm9tICcuLi8uLi8uLi9zZXJ2aWNlcy9jb250YWN0c1NlcnZpY2UnO1xyXG5pbXBvcnQgY29tcGFuaWVzU2VydmljZSBmcm9tICcuLi8uLi8uLi9zZXJ2aWNlcy9jb21wYW5pZXNTZXJ2aWNlJztcclxuXHJcbmNvbnN0IERlYWxGb3JtID0gKHsgZGVhbCA9IG51bGwsIGNvbnRhY3RzID0gW10sIGNvbXBhbmllcyA9IFtdLCBzdGFnZXMgPSBbXSwgb25TdWJtaXQsIG9uQ2FuY2VsLCBpc1NhdmluZyA9IGZhbHNlIH0pID0+IHtcclxuICBjb25zdCB7IHVzZXIgfSA9IHVzZUF1dGgoKTtcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBuYW1lOiAnJyxcclxuICAgIGRlc2NyaXB0aW9uOiAnJyxcclxuICAgIHZhbHVlOiAnJyxcclxuICAgIHN0YWdlOiAnbGVhZCcsXHJcbiAgICBwcm9iYWJpbGl0eTogMTAsXHJcbiAgICBleHBlY3RlZF9jbG9zZV9kYXRlOiAnJyxcclxuICAgIGNvbnRhY3RfaWQ6ICcnLFxyXG4gICAgY29tcGFueV9pZDogJycsXHJcbiAgICBsZWFkX3NvdXJjZTogJ3dlYnNpdGUnLFxyXG4gICAgbmV4dF9zdGVwOiAnJyxcclxuICAgIGNvbXBldGl0b3JfaW5mbzogJycsXHJcbiAgICB0YWdzOiBbXSxcclxuICAgIG93bmVyX2lkOiB1c2VyPy5pZCB8fCAnJ1xyXG4gIH0pO1xyXG4gIGNvbnN0IFtlcnJvcnMsIHNldEVycm9yc10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW25ld1RhZywgc2V0TmV3VGFnXSA9IHVzZVN0YXRlKCcnKTtcclxuXHJcbiAgLy8gUG9wdWxhdGUgZm9ybSB3aGVuIGRlYWwgcHJvcCBjaGFuZ2VzXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChkZWFsKSB7XHJcbiAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICBuYW1lOiBkZWFsPy5uYW1lIHx8ICcnLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uOiBkZWFsPy5kZXNjcmlwdGlvbiB8fCAnJyxcclxuICAgICAgICB2YWx1ZTogZGVhbD8udmFsdWU/LnRvU3RyaW5nKCkgfHwgJycsXHJcbiAgICAgICAgc3RhZ2U6IGRlYWw/LnN0YWdlIHx8ICdsZWFkJyxcclxuICAgICAgICBwcm9iYWJpbGl0eTogZGVhbD8ucHJvYmFiaWxpdHkgfHwgMTAsXHJcbiAgICAgICAgZXhwZWN0ZWRfY2xvc2VfZGF0ZTogZGVhbD8uZXhwZWN0ZWRfY2xvc2VfZGF0ZSB8fCAnJyxcclxuICAgICAgICBjb250YWN0X2lkOiBkZWFsPy5jb250YWN0X2lkIHx8ICcnLFxyXG4gICAgICAgIGNvbXBhbnlfaWQ6IGRlYWw/LmNvbXBhbnlfaWQgfHwgJycsXHJcbiAgICAgICAgbGVhZF9zb3VyY2U6IGRlYWw/LmxlYWRfc291cmNlIHx8ICd3ZWJzaXRlJyxcclxuICAgICAgICBuZXh0X3N0ZXA6IGRlYWw/Lm5leHRfc3RlcCB8fCAnJyxcclxuICAgICAgICBjb21wZXRpdG9yX2luZm86IGRlYWw/LmNvbXBldGl0b3JfaW5mbyB8fCAnJyxcclxuICAgICAgICB0YWdzOiBkZWFsPy50YWdzIHx8IFtdLFxyXG4gICAgICAgIG93bmVyX2lkOiBkZWFsPy5vd25lcl9pZCB8fCB1c2VyPy5pZCB8fCAnJ1xyXG4gICAgICB9KTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIC8vIFJlc2V0IGZvcm0gZm9yIG5ldyBkZWFsXHJcbiAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICBuYW1lOiAnJyxcclxuICAgICAgICBkZXNjcmlwdGlvbjogJycsXHJcbiAgICAgICAgdmFsdWU6ICcnLFxyXG4gICAgICAgIHN0YWdlOiAnbGVhZCcsXHJcbiAgICAgICAgcHJvYmFiaWxpdHk6IDEwLFxyXG4gICAgICAgIGV4cGVjdGVkX2Nsb3NlX2RhdGU6ICcnLFxyXG4gICAgICAgIGNvbnRhY3RfaWQ6ICcnLFxyXG4gICAgICAgIGNvbXBhbnlfaWQ6ICcnLFxyXG4gICAgICAgIGxlYWRfc291cmNlOiAnd2Vic2l0ZScsXHJcbiAgICAgICAgbmV4dF9zdGVwOiAnJyxcclxuICAgICAgICBjb21wZXRpdG9yX2luZm86ICcnLFxyXG4gICAgICAgIHRhZ3M6IFtdLFxyXG4gICAgICAgIG93bmVyX2lkOiB1c2VyPy5pZCB8fCAnJ1xyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9LCBbZGVhbCwgdXNlcj8uaWRdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGU/LnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4gICAgc2V0RXJyb3JzKHt9KTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICAvLyBWYWxpZGF0ZSByZXF1aXJlZCBmaWVsZHNcclxuICAgICAgY29uc3QgcmVxdWlyZWRGaWVsZHMgPSBbJ25hbWUnLCAndmFsdWUnXTtcclxuICAgICAgY29uc3QgdmFsaWRhdGlvbkVycm9ycyA9IHt9O1xyXG4gICAgICBcclxuICAgICAgcmVxdWlyZWRGaWVsZHM/LmZvckVhY2goZmllbGQgPT4ge1xyXG4gICAgICAgIGlmICghZm9ybURhdGE/LltmaWVsZF0/LnRvU3RyaW5nKCk/LnRyaW0oKSkge1xyXG4gICAgICAgICAgdmFsaWRhdGlvbkVycm9yc1tmaWVsZF0gPSBgJHtmaWVsZD8ucmVwbGFjZSgnXycsICcgJyl9IGlzIHJlcXVpcmVkYDtcclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgLy8gVmFsdWUgdmFsaWRhdGlvblxyXG4gICAgICBpZiAoZm9ybURhdGE/LnZhbHVlICYmIChpc05hTihmb3JtRGF0YT8udmFsdWUpIHx8IHBhcnNlRmxvYXQoZm9ybURhdGE/LnZhbHVlKSA8IDApKSB7XHJcbiAgICAgICAgdmFsaWRhdGlvbkVycm9ycy52YWx1ZSA9ICdQbGVhc2UgZW50ZXIgYSB2YWxpZCBkZWFsIHZhbHVlJztcclxuICAgICAgfVxyXG5cclxuICAgICAgLy8gRGF0ZSB2YWxpZGF0aW9uXHJcbiAgICAgIGlmIChmb3JtRGF0YT8uZXhwZWN0ZWRfY2xvc2VfZGF0ZSAmJiBuZXcgRGF0ZShmb3JtRGF0YT8uZXhwZWN0ZWRfY2xvc2VfZGF0ZSkgPCBuZXcgRGF0ZSgpKSB7XHJcbiAgICAgICAgdmFsaWRhdGlvbkVycm9ycy5leHBlY3RlZF9jbG9zZV9kYXRlID0gJ0V4cGVjdGVkIGNsb3NlIGRhdGUgY2Fubm90IGJlIGluIHRoZSBwYXN0JztcclxuICAgICAgfVxyXG5cclxuICAgICAgaWYgKE9iamVjdC5rZXlzKHZhbGlkYXRpb25FcnJvcnMpPy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgc2V0RXJyb3JzKHZhbGlkYXRpb25FcnJvcnMpO1xyXG4gICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgICAgIHJldHVybjtcclxuICAgICAgfVxyXG5cclxuICAgICAgLy8gUHJlcGFyZSBkYXRhIGZvciBzdWJtaXNzaW9uXHJcbiAgICAgIGNvbnN0IHN1Ym1pdERhdGEgPSB7XHJcbiAgICAgICAgLi4uZm9ybURhdGEsXHJcbiAgICAgICAgdmFsdWU6IHBhcnNlRmxvYXQoZm9ybURhdGE/LnZhbHVlKSB8fCAwLFxyXG4gICAgICAgIGV4cGVjdGVkX2Nsb3NlX2RhdGU6IGZvcm1EYXRhPy5leHBlY3RlZF9jbG9zZV9kYXRlIHx8IG51bGxcclxuICAgICAgfTtcclxuXHJcbiAgICAgIGxldCByZXN1bHQ7XHJcbiAgICAgIGlmIChkZWFsKSB7XHJcbiAgICAgICAgLy8gVXBkYXRlIGV4aXN0aW5nIGRlYWxcclxuICAgICAgICByZXN1bHQgPSBhd2FpdCBkZWFsc1NlcnZpY2U/LnVwZGF0ZURlYWwoZGVhbD8uaWQsIHN1Ym1pdERhdGEpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIC8vIENyZWF0ZSBuZXcgZGVhbFxyXG4gICAgICAgIHJlc3VsdCA9IGF3YWl0IGRlYWxzU2VydmljZT8uY3JlYXRlRGVhbChzdWJtaXREYXRhKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgb25TdWJtaXQocmVzdWx0KTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBzYXZpbmcgZGVhbDonLCBlcnIpO1xyXG4gICAgICBzZXRFcnJvcnMoeyBcclxuICAgICAgICBzdWJtaXQ6IGVycj8ubWVzc2FnZSB8fCAnRmFpbGVkIHRvIHNhdmUgZGVhbC4gUGxlYXNlIHRyeSBhZ2Fpbi4nIFxyXG4gICAgICB9KTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUlucHV0Q2hhbmdlID0gKGZpZWxkLCB2YWx1ZSkgPT4ge1xyXG4gICAgc2V0Rm9ybURhdGEocHJldiA9PiAoeyAuLi5wcmV2LCBbZmllbGRdOiB2YWx1ZSB9KSk7XHJcbiAgICBcclxuICAgIC8vIFVwZGF0ZSBwcm9iYWJpbGl0eSBiYXNlZCBvbiBzdGFnZVxyXG4gICAgaWYgKGZpZWxkID09PSAnc3RhZ2UnKSB7XHJcbiAgICAgIGNvbnN0IHN0YWdlUHJvYnMgPSB7XHJcbiAgICAgICAgbGVhZDogMTAsXHJcbiAgICAgICAgcXVhbGlmaWVkOiAyNSxcclxuICAgICAgICBwcm9wb3NhbDogNTAsXHJcbiAgICAgICAgbmVnb3RpYXRpb246IDc1LFxyXG4gICAgICAgIGNsb3NlZF93b246IDEwMCxcclxuICAgICAgICBjbG9zZWRfbG9zdDogMFxyXG4gICAgICB9O1xyXG4gICAgICBzZXRGb3JtRGF0YShwcmV2ID0+ICh7IFxyXG4gICAgICAgIC4uLnByZXYsIFxyXG4gICAgICAgIFtmaWVsZF06IHZhbHVlLFxyXG4gICAgICAgIHByb2JhYmlsaXR5OiBzdGFnZVByb2JzPy5bdmFsdWVdIHx8IHByZXY/LnByb2JhYmlsaXR5XHJcbiAgICAgIH0pKTtcclxuICAgIH1cclxuICAgIFxyXG4gICAgLy8gQ2xlYXIgZmllbGQgZXJyb3Igd2hlbiB1c2VyIHN0YXJ0cyB0eXBpbmdcclxuICAgIGlmIChlcnJvcnM/LltmaWVsZF0pIHtcclxuICAgICAgc2V0RXJyb3JzKHByZXYgPT4ge1xyXG4gICAgICAgIGNvbnN0IG5ld0Vycm9ycyA9IHsgLi4ucHJldiB9O1xyXG4gICAgICAgIGRlbGV0ZSBuZXdFcnJvcnM/LltmaWVsZF07XHJcbiAgICAgICAgcmV0dXJuIG5ld0Vycm9ycztcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgYWRkVGFnID0gKCkgPT4ge1xyXG4gICAgaWYgKG5ld1RhZz8udHJpbSgpICYmICFmb3JtRGF0YT8udGFncz8uaW5jbHVkZXMobmV3VGFnPy50cmltKCkpKSB7XHJcbiAgICAgIHNldEZvcm1EYXRhKHByZXYgPT4gKHtcclxuICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgIHRhZ3M6IFsuLi4ocHJldj8udGFncyB8fCBbXSksIG5ld1RhZz8udHJpbSgpXVxyXG4gICAgICB9KSk7XHJcbiAgICAgIHNldE5ld1RhZygnJyk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgcmVtb3ZlVGFnID0gKHRhZ1RvUmVtb3ZlKSA9PiB7XHJcbiAgICBzZXRGb3JtRGF0YShwcmV2ID0+ICh7XHJcbiAgICAgIC4uLnByZXYsXHJcbiAgICAgIHRhZ3M6IHByZXY/LnRhZ3M/LmZpbHRlcih0YWcgPT4gdGFnICE9PSB0YWdUb1JlbW92ZSkgfHwgW11cclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuICAvLyBIYW5kbGUgY29udGFjdCBjaGFuZ2UgYW5kIGF1dG8tcG9wdWxhdGUgY29tcGFueVxyXG4gIGNvbnN0IGhhbmRsZUNvbnRhY3RDaGFuZ2UgPSAoY29udGFjdElkKSA9PiB7XHJcbiAgICBjb25zdCBzZWxlY3RlZENvbnRhY3QgPSBjb250YWN0cz8uZmluZChjID0+IGM/LmlkID09PSBjb250YWN0SWQpO1xyXG4gICAgc2V0Rm9ybURhdGEocHJldiA9PiAoe1xyXG4gICAgICAuLi5wcmV2LFxyXG4gICAgICBjb250YWN0X2lkOiBjb250YWN0SWQsXHJcbiAgICAgIGNvbXBhbnlfaWQ6IHNlbGVjdGVkQ29udGFjdD8uY29tcGFueV9pZCB8fCBwcmV2Py5jb21wYW55X2lkXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuXHJcbiAgLy8gVXNlIHN0YWdlcyBwcm9wIG9yIGZhbGxiYWNrIHRvIGRlZmF1bHQgc3RhZ2VzXHJcbiAgY29uc3QgZGVhbFN0YWdlcyA9IHN0YWdlcy5sZW5ndGggPiAwID8gc3RhZ2VzIDogW1xyXG4gICAgeyB2YWx1ZTogJ2xlYWQnLCBsYWJlbDogJ0xlYWQnIH0sXHJcbiAgICB7IHZhbHVlOiAncXVhbGlmaWVkJywgbGFiZWw6ICdRdWFsaWZpZWQnIH0sXHJcbiAgICB7IHZhbHVlOiAncHJvcG9zYWwnLCBsYWJlbDogJ1Byb3Bvc2FsJyB9LFxyXG4gICAgeyB2YWx1ZTogJ25lZ290aWF0aW9uJywgbGFiZWw6ICdOZWdvdGlhdGlvbicgfSxcclxuICAgIHsgdmFsdWU6ICdjbG9zZWRfd29uJywgbGFiZWw6ICdDbG9zZWQgV29uJyB9LFxyXG4gICAgeyB2YWx1ZTogJ2Nsb3NlZF9sb3N0JywgbGFiZWw6ICdDbG9zZWQgTG9zdCcgfVxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGxlYWRTb3VyY2VzID0gW1xyXG4gICAgeyB2YWx1ZTogJ3dlYnNpdGUnLCBsYWJlbDogJ1dlYnNpdGUnIH0sXHJcbiAgICB7IHZhbHVlOiAncmVmZXJyYWwnLCBsYWJlbDogJ1JlZmVycmFsJyB9LFxyXG4gICAgeyB2YWx1ZTogJ2NvbGRfY2FsbCcsIGxhYmVsOiAnQ29sZCBDYWxsJyB9LFxyXG4gICAgeyB2YWx1ZTogJ2VtYWlsX2NhbXBhaWduJywgbGFiZWw6ICdFbWFpbCBDYW1wYWlnbicgfSxcclxuICAgIHsgdmFsdWU6ICdzb2NpYWxfbWVkaWEnLCBsYWJlbDogJ1NvY2lhbCBNZWRpYScgfSxcclxuICAgIHsgdmFsdWU6ICdldmVudCcsIGxhYmVsOiAnRXZlbnQnIH0sXHJcbiAgICB7IHZhbHVlOiAncGFydG5lcicsIGxhYmVsOiAnUGFydG5lcicgfSxcclxuICAgIHsgdmFsdWU6ICdvdGhlcicsIGxhYmVsOiAnT3RoZXInIH1cclxuICBdO1xyXG5cclxuICBjb25zb2xlLmxvZygnRGVhbEZvcm0gcmVuZGVyaW5nIC0gZGVhbDonLCBkZWFsPy5pZCwgJ2NvbnRhY3RzOicsIGNvbnRhY3RzLmxlbmd0aCwgJ2NvbXBhbmllczonLCBjb21wYW5pZXMubGVuZ3RoLCAnc3RhZ2VzOicsIHN0YWdlcy5sZW5ndGgpO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XHJcbiAgICAgIHsvKiBFcnJvciBNZXNzYWdlcyAqL31cclxuICAgICAge2Vycm9ycz8uc3VibWl0ICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWVycm9yLTUwIGJvcmRlciBib3JkZXItZXJyb3ItMjAwIHRleHQtZXJyb3IgcC00IHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCI+XHJcbiAgICAgICAgICA8SWNvbiBuYW1lPVwiQWxlcnRDaXJjbGVcIiBzaXplPXsyMH0gLz5cclxuICAgICAgICAgIDxzcGFuPntlcnJvcnM/LnN1Ym1pdH08L3NwYW4+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7LyogQmFzaWMgSW5mb3JtYXRpb24gKi99XHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItMVwiPlxyXG4gICAgICAgICAgRGVhbCBOYW1lICpcclxuICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5uYW1lfVxyXG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVJbnB1dENoYW5nZSgnbmFtZScsIGU/LnRhcmdldD8udmFsdWUpfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIHB4LTMgcHktMiBib3JkZXIgcm91bmRlZC1sZyBmb2N1czpyaW5nLXByaW1hcnkgZm9jdXM6Ym9yZGVyLXByaW1hcnkgJHtcclxuICAgICAgICAgICAgZXJyb3JzPy5uYW1lID8gJ2JvcmRlci1lcnJvcicgOiAnYm9yZGVyLWJvcmRlcidcclxuICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlcnByaXNlIFNvZnR3YXJlIExpY2Vuc2UgLSBBY21lIENvcnBcIlxyXG4gICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAvPlxyXG4gICAgICAgIHtlcnJvcnM/Lm5hbWUgJiYgKFxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWVycm9yIG10LTFcIj57ZXJyb3JzPy5uYW1lfTwvcD5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBWYWx1ZSBhbmQgUHJvYmFiaWxpdHkgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNFwiPlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSBtYi0xXCI+XHJcbiAgICAgICAgICAgIERlYWwgVmFsdWUgKlxyXG4gICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgbGVmdC0zIHRvcC0xLzIgdHJhbnNmb3JtIC10cmFuc2xhdGUteS0xLzIgdGV4dC10ZXh0LXNlY29uZGFyeVwiPiQ8L3NwYW4+XHJcbiAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgIG1pbj1cIjBcIlxyXG4gICAgICAgICAgICAgIHN0ZXA9XCIwLjAxXCJcclxuICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LnZhbHVlfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlSW5wdXRDaGFuZ2UoJ3ZhbHVlJywgZT8udGFyZ2V0Py52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIHBsLTggcHItMyBweS0yIGJvcmRlciByb3VuZGVkLWxnIGZvY3VzOnJpbmctcHJpbWFyeSBmb2N1czpib3JkZXItcHJpbWFyeSAke1xyXG4gICAgICAgICAgICAgICAgZXJyb3JzPy52YWx1ZSA/ICdib3JkZXItZXJyb3InIDogJ2JvcmRlci1ib3JkZXInXHJcbiAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCI1MDAwMFwiXHJcbiAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAge2Vycm9ycz8udmFsdWUgJiYgKFxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZXJyb3IgbXQtMVwiPntlcnJvcnM/LnZhbHVlfTwvcD5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSBtYi0xXCI+XHJcbiAgICAgICAgICAgIFN0YWdlXHJcbiAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LnN0YWdlfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUlucHV0Q2hhbmdlKCdzdGFnZScsIGU/LnRhcmdldD8udmFsdWUpfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1wcmltYXJ5IGZvY3VzOmJvcmRlci1wcmltYXJ5XCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge2RlYWxTdGFnZXM/Lm1hcChzdGFnZSA9PiAoXHJcbiAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3N0YWdlPy52YWx1ZX0gdmFsdWU9e3N0YWdlPy52YWx1ZX0+XHJcbiAgICAgICAgICAgICAgICB7c3RhZ2U/LmxhYmVsfVxyXG4gICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItMVwiPlxyXG4gICAgICAgICAgICBQcm9iYWJpbGl0eSAoJSlcclxuICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgIG1pbj1cIjBcIlxyXG4gICAgICAgICAgICBtYXg9XCIxMDBcIlxyXG4gICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LnByb2JhYmlsaXR5fVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUlucHV0Q2hhbmdlKCdwcm9iYWJpbGl0eScsIHBhcnNlSW50KGU/LnRhcmdldD8udmFsdWUpIHx8IDApfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1wcmltYXJ5IGZvY3VzOmJvcmRlci1wcmltYXJ5XCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIENvbnRhY3QgYW5kIENvbXBhbnkgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSBtYi0xXCI+XHJcbiAgICAgICAgICAgIFByaW1hcnkgQ29udGFjdFxyXG4gICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5jb250YWN0X2lkfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUNvbnRhY3RDaGFuZ2UoZT8udGFyZ2V0Py52YWx1ZSl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ib3JkZXIgcm91bmRlZC1sZyBmb2N1czpyaW5nLXByaW1hcnkgZm9jdXM6Ym9yZGVyLXByaW1hcnlcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IENvbnRhY3Q8L29wdGlvbj5cclxuICAgICAgICAgICAge2NvbnRhY3RzPy5tYXAoY29udGFjdCA9PiAoXHJcbiAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2NvbnRhY3Q/LmlkfSB2YWx1ZT17Y29udGFjdD8uaWR9PlxyXG4gICAgICAgICAgICAgICAge2NvbnRhY3Q/LmZ1bGxfbmFtZSB8fCBgJHtjb250YWN0Py5maXJzdF9uYW1lfSAke2NvbnRhY3Q/Lmxhc3RfbmFtZX1gfSAtIHtjb250YWN0Py5jb21wYW55Py5uYW1lfVxyXG4gICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItMVwiPlxyXG4gICAgICAgICAgICBDb21wYW55XHJcbiAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LmNvbXBhbnlfaWR9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlSW5wdXRDaGFuZ2UoJ2NvbXBhbnlfaWQnLCBlPy50YXJnZXQ/LnZhbHVlKX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLWxnIGZvY3VzOnJpbmctcHJpbWFyeSBmb2N1czpib3JkZXItcHJpbWFyeVwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY3QgQ29tcGFueTwvb3B0aW9uPlxyXG4gICAgICAgICAgICB7Y29tcGFuaWVzPy5tYXAoY29tcGFueSA9PiAoXHJcbiAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2NvbXBhbnk/LmlkfSB2YWx1ZT17Y29tcGFueT8uaWR9PlxyXG4gICAgICAgICAgICAgICAge2NvbXBhbnk/Lm5hbWV9XHJcbiAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIFRpbWVsaW5lICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItMVwiPlxyXG4gICAgICAgICAgICBFeHBlY3RlZCBDbG9zZSBEYXRlXHJcbiAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5leHBlY3RlZF9jbG9zZV9kYXRlfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUlucHV0Q2hhbmdlKCdleHBlY3RlZF9jbG9zZV9kYXRlJywgZT8udGFyZ2V0Py52YWx1ZSl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCBweC0zIHB5LTIgYm9yZGVyIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1wcmltYXJ5IGZvY3VzOmJvcmRlci1wcmltYXJ5ICR7XHJcbiAgICAgICAgICAgICAgZXJyb3JzPy5leHBlY3RlZF9jbG9zZV9kYXRlID8gJ2JvcmRlci1lcnJvcicgOiAnYm9yZGVyLWJvcmRlcidcclxuICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgIG1pbj17bmV3IERhdGUoKT8udG9JU09TdHJpbmcoKT8uc3BsaXQoJ1QnKT8uWzBdfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIHtlcnJvcnM/LmV4cGVjdGVkX2Nsb3NlX2RhdGUgJiYgKFxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZXJyb3IgbXQtMVwiPntlcnJvcnM/LmV4cGVjdGVkX2Nsb3NlX2RhdGV9PC9wPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IG1iLTFcIj5cclxuICAgICAgICAgICAgTGVhZCBTb3VyY2VcclxuICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8ubGVhZF9zb3VyY2V9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlSW5wdXRDaGFuZ2UoJ2xlYWRfc291cmNlJywgZT8udGFyZ2V0Py52YWx1ZSl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ib3JkZXIgcm91bmRlZC1sZyBmb2N1czpyaW5nLXByaW1hcnkgZm9jdXM6Ym9yZGVyLXByaW1hcnlcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7bGVhZFNvdXJjZXM/Lm1hcChzb3VyY2UgPT4gKFxyXG4gICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtzb3VyY2U/LnZhbHVlfSB2YWx1ZT17c291cmNlPy52YWx1ZX0+XHJcbiAgICAgICAgICAgICAgICB7c291cmNlPy5sYWJlbH1cclxuICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogRGVzY3JpcHRpb24gKi99XHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItMVwiPlxyXG4gICAgICAgICAgRGVzY3JpcHRpb25cclxuICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgIDx0ZXh0YXJlYVxyXG4gICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5kZXNjcmlwdGlvbn1cclxuICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlSW5wdXRDaGFuZ2UoJ2Rlc2NyaXB0aW9uJywgZT8udGFyZ2V0Py52YWx1ZSl9XHJcbiAgICAgICAgICByb3dzPXs0fVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLWxnIGZvY3VzOnJpbmctcHJpbWFyeSBmb2N1czpib3JkZXItcHJpbWFyeVwiXHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIkRlc2NyaWJlIHRoZSBkZWFsLCByZXF1aXJlbWVudHMsIGFuZCBrZXkgZGV0YWlscy4uLlwiXHJcbiAgICAgICAgLz5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogTmV4dCBTdGVwIGFuZCBDb21wZXRpdG9yIEluZm8gKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSBtYi0xXCI+XHJcbiAgICAgICAgICAgIE5leHQgU3RlcFxyXG4gICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8ubmV4dF9zdGVwfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUlucHV0Q2hhbmdlKCduZXh0X3N0ZXAnLCBlPy50YXJnZXQ/LnZhbHVlKX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLWxnIGZvY3VzOnJpbmctcHJpbWFyeSBmb2N1czpib3JkZXItcHJpbWFyeVwiXHJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2NoZWR1bGUgZGVtbywgc2VuZCBwcm9wb3NhbCwgZXRjLlwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItMVwiPlxyXG4gICAgICAgICAgICBDb21wZXRpdG9yIEluZm9ybWF0aW9uXHJcbiAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5jb21wZXRpdG9yX2luZm99XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlSW5wdXRDaGFuZ2UoJ2NvbXBldGl0b3JfaW5mbycsIGU/LnRhcmdldD8udmFsdWUpfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1wcmltYXJ5IGZvY3VzOmJvcmRlci1wcmltYXJ5XCJcclxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJDb21wZXRpbmcgYWdhaW5zdC4uLlwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBUYWdzICovfVxyXG4gICAgICA8ZGl2PlxyXG4gICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IG1iLTFcIj5cclxuICAgICAgICAgIFRhZ3NcclxuICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTIgbWItMlwiPlxyXG4gICAgICAgICAge2Zvcm1EYXRhPy50YWdzPy5tYXAoKHRhZywgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICBrZXk9e2luZGV4fVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0yIHB5LTEgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1tZWRpdW0gYmctcHJpbWFyeS0xMDAgdGV4dC1wcmltYXJ5LTgwMFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7dGFnfVxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcmVtb3ZlVGFnKHRhZyl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtbC0xIHRleHQtcHJpbWFyeS02MDAgaG92ZXI6dGV4dC1wcmltYXJ5LTgwMFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIlhcIiBzaXplPXsxMn0gLz5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHNwYWNlLXgtMlwiPlxyXG4gICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgdmFsdWU9e25ld1RhZ31cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROZXdUYWcoZT8udGFyZ2V0Py52YWx1ZSl9XHJcbiAgICAgICAgICAgIG9uS2V5UHJlc3M9eyhlKSA9PiBlPy5rZXkgPT09ICdFbnRlcicgJiYgKGU/LnByZXZlbnREZWZhdWx0KCksIGFkZFRhZygpKX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLWxnIGZvY3VzOnJpbmctcHJpbWFyeSBmb2N1czpib3JkZXItcHJpbWFyeVwiXHJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQWRkIGEgdGFnIGFuZCBwcmVzcyBFbnRlclwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgb25DbGljaz17YWRkVGFnfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTIgYmctdGV4dC1zZWNvbmRhcnkgdGV4dC13aGl0ZSByb3VuZGVkLWxnIGhvdmVyOmJnLXRleHQtcHJpbWFyeSB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTBcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBBZGRcclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBGb3JtIEFjdGlvbnMgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBzcGFjZS14LTMgcHQtNCBib3JkZXItdCBib3JkZXItYm9yZGVyXCI+XHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICBvbkNsaWNrPXtvbkNhbmNlbH1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LXRleHQtc2Vjb25kYXJ5IGhvdmVyOnRleHQtdGV4dC1wcmltYXJ5IHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MFwiXHJcbiAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZyB8fCBpc1NhdmluZ31cclxuICAgICAgICA+XHJcbiAgICAgICAgICBDYW5jZWxcclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nIHx8IGlzU2F2aW5nfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiYmctcHJpbWFyeSB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkLWxnIGhvdmVyOmJnLXByaW1hcnktNjAwIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MCBlYXNlLXNtb290aCBmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTJcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIHsobG9hZGluZyB8fCBpc1NhdmluZykgJiYgPGRpdiBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW4gcm91bmRlZC1mdWxsIGgtNCB3LTQgYm9yZGVyLWItMiBib3JkZXItd2hpdGVcIj48L2Rpdj59XHJcbiAgICAgICAgICA8c3Bhbj57ZGVhbCA/ICdVcGRhdGUgRGVhbCcgOiAnQ3JlYXRlIERlYWwnfTwvc3Bhbj5cclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Zvcm0+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IERlYWxGb3JtOyJdLCJmaWxlIjoiRDovY3VycmVudCBwcm9qZWN0cy9jbGF1ZGUtY29kZS9zcmMvcGFnZXMvZGVhbC1tYW5hZ2VtZW50L2NvbXBvbmVudHMvRGVhbEZvcm0uanN4In0=