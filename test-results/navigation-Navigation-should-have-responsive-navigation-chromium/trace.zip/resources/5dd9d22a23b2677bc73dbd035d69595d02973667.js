import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/Routes.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/Routes.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { BrowserRouter, Routes as RouterRoutes, Route } from "/node_modules/.vite/deps/react-router-dom.js?v=44ab9529";
import ScrollToTop from "/src/components/ScrollToTop.jsx";
import ErrorBoundary from "/src/components/ErrorBoundary.jsx";
import ProtectedRoute from "/src/components/ProtectedRoute.jsx";
import Login from "/src/pages/login/index.jsx";
import SalesDashboard from "/src/pages/sales-dashboard/index.jsx";
import DealManagement from "/src/pages/deal-management/index.jsx";
import ContactManagement from "/src/pages/contact-management/index.jsx";
import PipelineAnalytics from "/src/pages/pipeline-analytics/index.jsx";
import ActivityTimeline from "/src/pages/activity-timeline/index.jsx";
import SettingsAdministration from "/src/pages/settings-administration/index.jsx";
const Routes = () => {
  return /* @__PURE__ */ jsxDEV(BrowserRouter, { "data-component-id": "src\\Routes.jsx:18:4", "data-component-path": "src\\Routes.jsx", "data-component-line": "18", "data-component-file": "Routes.jsx", "data-component-name": "BrowserRouter", "data-component-content": "%7B%22elementName%22%3A%22BrowserRouter%22%7D", children: /* @__PURE__ */ jsxDEV(ErrorBoundary, { "data-component-id": "src\\Routes.jsx:19:6", "data-component-path": "src\\Routes.jsx", "data-component-line": "19", "data-component-file": "Routes.jsx", "data-component-name": "ErrorBoundary", "data-component-content": "%7B%22elementName%22%3A%22ErrorBoundary%22%7D", children: [
    /* @__PURE__ */ jsxDEV(ScrollToTop, { "data-component-id": "src\\Routes.jsx:20:8", "data-component-path": "src\\Routes.jsx", "data-component-line": "20", "data-component-file": "Routes.jsx", "data-component-name": "ScrollToTop", "data-component-content": "%7B%22elementName%22%3A%22ScrollToTop%22%7D" }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/Routes.jsx",
      lineNumber: 20,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(RouterRoutes, { "data-component-id": "src\\Routes.jsx:21:8", "data-component-path": "src\\Routes.jsx", "data-component-line": "21", "data-component-file": "Routes.jsx", "data-component-name": "RouterRoutes", "data-component-content": "%7B%22elementName%22%3A%22RouterRoutes%22%7D", children: [
      /* @__PURE__ */ jsxDEV(Route, { "data-component-id": "src\\Routes.jsx:22:10", "data-component-path": "src\\Routes.jsx", "data-component-line": "22", "data-component-file": "Routes.jsx", "data-component-name": "Route", "data-component-content": "%7B%22elementName%22%3A%22Route%22%7D", path: "/login", element: /* @__PURE__ */ jsxDEV(Login, { "data-component-id": "src\\Routes.jsx:22:40", "data-component-path": "src\\Routes.jsx", "data-component-line": "22", "data-component-file": "Routes.jsx", "data-component-name": "Login", "data-component-content": "%7B%22elementName%22%3A%22Login%22%7D" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/Routes.jsx",
        lineNumber: 22,
        columnNumber: 268
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/Routes.jsx",
        lineNumber: 22,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { "data-component-id": "src\\Routes.jsx:23:10", "data-component-path": "src\\Routes.jsx", "data-component-line": "23", "data-component-file": "Routes.jsx", "data-component-name": "Route", "data-component-content": "%7B%22elementName%22%3A%22Route%22%7D", path: "/", element: /* @__PURE__ */ jsxDEV(Login, { "data-component-id": "src\\Routes.jsx:23:35", "data-component-path": "src\\Routes.jsx", "data-component-line": "23", "data-component-file": "Routes.jsx", "data-component-name": "Login", "data-component-content": "%7B%22elementName%22%3A%22Login%22%7D" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/Routes.jsx",
        lineNumber: 23,
        columnNumber: 263
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/Routes.jsx",
        lineNumber: 23,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        Route,
        {
          "data-component-id": "src\\Routes.jsx:26:10",
          "data-component-path": "src\\Routes.jsx",
          "data-component-line": "26",
          "data-component-file": "Routes.jsx",
          "data-component-name": "Route",
          "data-component-content": "%7B%22elementName%22%3A%22Route%22%7D",
          path: "/sales-dashboard",
          element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { "data-component-id": "src\\Routes.jsx:29:12", "data-component-path": "src\\Routes.jsx", "data-component-line": "29", "data-component-file": "Routes.jsx", "data-component-name": "ProtectedRoute", "data-component-content": "%7B%22elementName%22%3A%22ProtectedRoute%22%7D", children: /* @__PURE__ */ jsxDEV(SalesDashboard, { "data-component-id": "src\\Routes.jsx:30:16", "data-component-path": "src\\Routes.jsx", "data-component-line": "30", "data-component-file": "Routes.jsx", "data-component-name": "SalesDashboard", "data-component-content": "%7B%22elementName%22%3A%22SalesDashboard%22%7D" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/Routes.jsx",
            lineNumber: 30,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/Routes.jsx",
            lineNumber: 29,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "D:/current projects/claude-code/src/Routes.jsx",
          lineNumber: 26,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Route,
        {
          "data-component-id": "src\\Routes.jsx:34:10",
          "data-component-path": "src\\Routes.jsx",
          "data-component-line": "34",
          "data-component-file": "Routes.jsx",
          "data-component-name": "Route",
          "data-component-content": "%7B%22elementName%22%3A%22Route%22%7D",
          path: "/deal-management",
          element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { "data-component-id": "src\\Routes.jsx:37:12", "data-component-path": "src\\Routes.jsx", "data-component-line": "37", "data-component-file": "Routes.jsx", "data-component-name": "ProtectedRoute", "data-component-content": "%7B%22elementName%22%3A%22ProtectedRoute%22%7D", children: /* @__PURE__ */ jsxDEV(DealManagement, { "data-component-id": "src\\Routes.jsx:38:16", "data-component-path": "src\\Routes.jsx", "data-component-line": "38", "data-component-file": "Routes.jsx", "data-component-name": "DealManagement", "data-component-content": "%7B%22elementName%22%3A%22DealManagement%22%7D" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/Routes.jsx",
            lineNumber: 38,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/Routes.jsx",
            lineNumber: 37,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "D:/current projects/claude-code/src/Routes.jsx",
          lineNumber: 34,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Route,
        {
          "data-component-id": "src\\Routes.jsx:42:10",
          "data-component-path": "src\\Routes.jsx",
          "data-component-line": "42",
          "data-component-file": "Routes.jsx",
          "data-component-name": "Route",
          "data-component-content": "%7B%22elementName%22%3A%22Route%22%7D",
          path: "/deal-management/new",
          element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { "data-component-id": "src\\Routes.jsx:45:12", "data-component-path": "src\\Routes.jsx", "data-component-line": "45", "data-component-file": "Routes.jsx", "data-component-name": "ProtectedRoute", "data-component-content": "%7B%22elementName%22%3A%22ProtectedRoute%22%7D", children: /* @__PURE__ */ jsxDEV(DealManagement, { "data-component-id": "src\\Routes.jsx:46:16", "data-component-path": "src\\Routes.jsx", "data-component-line": "46", "data-component-file": "Routes.jsx", "data-component-name": "DealManagement", "data-component-content": "%7B%22elementName%22%3A%22DealManagement%22%7D" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/Routes.jsx",
            lineNumber: 46,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/Routes.jsx",
            lineNumber: 45,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "D:/current projects/claude-code/src/Routes.jsx",
          lineNumber: 42,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Route,
        {
          "data-component-id": "src\\Routes.jsx:50:10",
          "data-component-path": "src\\Routes.jsx",
          "data-component-line": "50",
          "data-component-file": "Routes.jsx",
          "data-component-name": "Route",
          "data-component-content": "%7B%22elementName%22%3A%22Route%22%7D",
          path: "/deal-management/:dealId",
          element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { "data-component-id": "src\\Routes.jsx:53:12", "data-component-path": "src\\Routes.jsx", "data-component-line": "53", "data-component-file": "Routes.jsx", "data-component-name": "ProtectedRoute", "data-component-content": "%7B%22elementName%22%3A%22ProtectedRoute%22%7D", children: /* @__PURE__ */ jsxDEV(DealManagement, { "data-component-id": "src\\Routes.jsx:54:16", "data-component-path": "src\\Routes.jsx", "data-component-line": "54", "data-component-file": "Routes.jsx", "data-component-name": "DealManagement", "data-component-content": "%7B%22elementName%22%3A%22DealManagement%22%7D" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/Routes.jsx",
            lineNumber: 54,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/Routes.jsx",
            lineNumber: 53,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "D:/current projects/claude-code/src/Routes.jsx",
          lineNumber: 50,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Route,
        {
          "data-component-id": "src\\Routes.jsx:58:10",
          "data-component-path": "src\\Routes.jsx",
          "data-component-line": "58",
          "data-component-file": "Routes.jsx",
          "data-component-name": "Route",
          "data-component-content": "%7B%22elementName%22%3A%22Route%22%7D",
          path: "/contact-management",
          element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { "data-component-id": "src\\Routes.jsx:61:12", "data-component-path": "src\\Routes.jsx", "data-component-line": "61", "data-component-file": "Routes.jsx", "data-component-name": "ProtectedRoute", "data-component-content": "%7B%22elementName%22%3A%22ProtectedRoute%22%7D", children: /* @__PURE__ */ jsxDEV(ContactManagement, { "data-component-id": "src\\Routes.jsx:62:16", "data-component-path": "src\\Routes.jsx", "data-component-line": "62", "data-component-file": "Routes.jsx", "data-component-name": "ContactManagement", "data-component-content": "%7B%22elementName%22%3A%22ContactManagement%22%7D" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/Routes.jsx",
            lineNumber: 62,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/Routes.jsx",
            lineNumber: 61,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "D:/current projects/claude-code/src/Routes.jsx",
          lineNumber: 58,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Route,
        {
          "data-component-id": "src\\Routes.jsx:66:10",
          "data-component-path": "src\\Routes.jsx",
          "data-component-line": "66",
          "data-component-file": "Routes.jsx",
          "data-component-name": "Route",
          "data-component-content": "%7B%22elementName%22%3A%22Route%22%7D",
          path: "/pipeline-analytics",
          element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { "data-component-id": "src\\Routes.jsx:69:12", "data-component-path": "src\\Routes.jsx", "data-component-line": "69", "data-component-file": "Routes.jsx", "data-component-name": "ProtectedRoute", "data-component-content": "%7B%22elementName%22%3A%22ProtectedRoute%22%7D", children: /* @__PURE__ */ jsxDEV(PipelineAnalytics, { "data-component-id": "src\\Routes.jsx:70:16", "data-component-path": "src\\Routes.jsx", "data-component-line": "70", "data-component-file": "Routes.jsx", "data-component-name": "PipelineAnalytics", "data-component-content": "%7B%22elementName%22%3A%22PipelineAnalytics%22%7D" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/Routes.jsx",
            lineNumber: 70,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/Routes.jsx",
            lineNumber: 69,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "D:/current projects/claude-code/src/Routes.jsx",
          lineNumber: 66,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Route,
        {
          "data-component-id": "src\\Routes.jsx:74:10",
          "data-component-path": "src\\Routes.jsx",
          "data-component-line": "74",
          "data-component-file": "Routes.jsx",
          "data-component-name": "Route",
          "data-component-content": "%7B%22elementName%22%3A%22Route%22%7D",
          path: "/activity-timeline",
          element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { "data-component-id": "src\\Routes.jsx:77:12", "data-component-path": "src\\Routes.jsx", "data-component-line": "77", "data-component-file": "Routes.jsx", "data-component-name": "ProtectedRoute", "data-component-content": "%7B%22elementName%22%3A%22ProtectedRoute%22%7D", children: /* @__PURE__ */ jsxDEV(ActivityTimeline, { "data-component-id": "src\\Routes.jsx:78:16", "data-component-path": "src\\Routes.jsx", "data-component-line": "78", "data-component-file": "Routes.jsx", "data-component-name": "ActivityTimeline", "data-component-content": "%7B%22elementName%22%3A%22ActivityTimeline%22%7D" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/Routes.jsx",
            lineNumber: 78,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/Routes.jsx",
            lineNumber: 77,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "D:/current projects/claude-code/src/Routes.jsx",
          lineNumber: 74,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Route,
        {
          "data-component-id": "src\\Routes.jsx:82:10",
          "data-component-path": "src\\Routes.jsx",
          "data-component-line": "82",
          "data-component-file": "Routes.jsx",
          "data-component-name": "Route",
          "data-component-content": "%7B%22elementName%22%3A%22Route%22%7D",
          path: "/settings-administration",
          element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { "data-component-id": "src\\Routes.jsx:85:12", "data-component-path": "src\\Routes.jsx", "data-component-line": "85", "data-component-file": "Routes.jsx", "data-component-name": "ProtectedRoute", "data-component-content": "%7B%22elementName%22%3A%22ProtectedRoute%22%7D", children: /* @__PURE__ */ jsxDEV(SettingsAdministration, { "data-component-id": "src\\Routes.jsx:86:16", "data-component-path": "src\\Routes.jsx", "data-component-line": "86", "data-component-file": "Routes.jsx", "data-component-name": "SettingsAdministration", "data-component-content": "%7B%22elementName%22%3A%22SettingsAdministration%22%7D" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/Routes.jsx",
            lineNumber: 86,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/Routes.jsx",
            lineNumber: 85,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "D:/current projects/claude-code/src/Routes.jsx",
          lineNumber: 82,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/Routes.jsx",
      lineNumber: 21,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/Routes.jsx",
    lineNumber: 19,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "D:/current projects/claude-code/src/Routes.jsx",
    lineNumber: 18,
    columnNumber: 5
  }, this);
};
_c = Routes;
export default Routes;
var _c;
$RefreshReg$(_c, "Routes");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/Routes.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/Routes.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUJRO0FBbkJSLE9BQU9BLG9CQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN6QixTQUFTQyxlQUFlQyxVQUFVQyxjQUFjQyxhQUFhO0FBQzdELE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxtQkFBbUI7QUFDMUIsT0FBT0Msb0JBQW9CO0FBRzNCLE9BQU9DLFdBQVc7QUFDbEIsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyx1QkFBdUI7QUFDOUIsT0FBT0MsdUJBQXVCO0FBQzlCLE9BQU9DLHNCQUFzQjtBQUM3QixPQUFPQyw0QkFBNEI7QUFFbkMsTUFBTVosU0FBU0EsTUFBTTtBQUNuQixTQUNFLHVCQUFDLDZSQUNDLGlDQUFDLDZSQUNDO0FBQUEsMkJBQUMseVJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFZO0FBQUEsSUFDWix1QkFBQywwUkFDQztBQUFBLDZCQUFDLHNRQUFNLE1BQUssVUFBUyxTQUFTLHVCQUFDLHdRQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBTSxLQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdDO0FBQUEsTUFDeEMsdUJBQUMsc1FBQU0sTUFBSyxLQUFJLFNBQVMsdUJBQUMsd1FBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFNLEtBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUM7QUFBQSxNQUduQztBQUFBLFFBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsU0FDRSx1QkFBQyxpU0FDQyxpQ0FBQyxtU0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFlLEtBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQTtBQUFBLFFBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUc7QUFBQSxNQUVIO0FBQUEsUUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxTQUNFLHVCQUFDLGlTQUNDLGlDQUFDLG1TQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWUsS0FEakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBO0FBQUEsUUFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNRztBQUFBLE1BRUg7QUFBQSxRQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFNBQ0UsdUJBQUMsaVNBQ0MsaUNBQUMsbVNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZSxLQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUE7QUFBQSxRQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1HO0FBQUEsTUFFSDtBQUFBLFFBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsU0FDRSx1QkFBQyxpU0FDQyxpQ0FBQyxtU0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFlLEtBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQTtBQUFBLFFBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUc7QUFBQSxNQUVIO0FBQUEsUUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxTQUNFLHVCQUFDLGlTQUNDLGlDQUFDLDRTQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtCLEtBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQTtBQUFBLFFBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUc7QUFBQSxNQUVIO0FBQUEsUUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxTQUNFLHVCQUFDLGlTQUNDLGlDQUFDLDRTQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtCLEtBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQTtBQUFBLFFBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUc7QUFBQSxNQUVIO0FBQUEsUUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxTQUNFLHVCQUFDLGlTQUNDLGlDQUFDLHlTQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlCLEtBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQTtBQUFBLFFBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUc7QUFBQSxNQUVIO0FBQUEsUUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxTQUNFLHVCQUFDLGlTQUNDLGlDQUFDLDJUQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVCLEtBRHpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQTtBQUFBLFFBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUc7QUFBQSxTQW5FTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUVBO0FBQUEsT0F2RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXdFQSxLQXpFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMEVBO0FBRUo7QUFBRWEsS0E5RUliO0FBZ0ZOLGVBQWVBO0FBQU8sSUFBQWE7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwiQnJvd3NlclJvdXRlciIsIlJvdXRlcyIsIlJvdXRlclJvdXRlcyIsIlJvdXRlIiwiU2Nyb2xsVG9Ub3AiLCJFcnJvckJvdW5kYXJ5IiwiUHJvdGVjdGVkUm91dGUiLCJMb2dpbiIsIlNhbGVzRGFzaGJvYXJkIiwiRGVhbE1hbmFnZW1lbnQiLCJDb250YWN0TWFuYWdlbWVudCIsIlBpcGVsaW5lQW5hbHl0aWNzIiwiQWN0aXZpdHlUaW1lbGluZSIsIlNldHRpbmdzQWRtaW5pc3RyYXRpb24iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJvdXRlcy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBCcm93c2VyUm91dGVyLCBSb3V0ZXMgYXMgUm91dGVyUm91dGVzLCBSb3V0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCBTY3JvbGxUb1RvcCBmcm9tIFwiY29tcG9uZW50cy9TY3JvbGxUb1RvcFwiO1xyXG5pbXBvcnQgRXJyb3JCb3VuZGFyeSBmcm9tIFwiY29tcG9uZW50cy9FcnJvckJvdW5kYXJ5XCI7XHJcbmltcG9ydCBQcm90ZWN0ZWRSb3V0ZSBmcm9tIFwiLi9jb21wb25lbnRzL1Byb3RlY3RlZFJvdXRlXCI7XHJcblxyXG4vLyBQYWdlIGltcG9ydHNcclxuaW1wb3J0IExvZ2luIGZyb20gXCJwYWdlcy9sb2dpblwiO1xyXG5pbXBvcnQgU2FsZXNEYXNoYm9hcmQgZnJvbSBcInBhZ2VzL3NhbGVzLWRhc2hib2FyZFwiO1xyXG5pbXBvcnQgRGVhbE1hbmFnZW1lbnQgZnJvbSBcInBhZ2VzL2RlYWwtbWFuYWdlbWVudFwiO1xyXG5pbXBvcnQgQ29udGFjdE1hbmFnZW1lbnQgZnJvbSBcInBhZ2VzL2NvbnRhY3QtbWFuYWdlbWVudFwiO1xyXG5pbXBvcnQgUGlwZWxpbmVBbmFseXRpY3MgZnJvbSBcInBhZ2VzL3BpcGVsaW5lLWFuYWx5dGljc1wiO1xyXG5pbXBvcnQgQWN0aXZpdHlUaW1lbGluZSBmcm9tIFwicGFnZXMvYWN0aXZpdHktdGltZWxpbmVcIjtcclxuaW1wb3J0IFNldHRpbmdzQWRtaW5pc3RyYXRpb24gZnJvbSBcInBhZ2VzL3NldHRpbmdzLWFkbWluaXN0cmF0aW9uXCI7XHJcblxyXG5jb25zdCBSb3V0ZXMgPSAoKSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxCcm93c2VyUm91dGVyPlxyXG4gICAgICA8RXJyb3JCb3VuZGFyeT5cclxuICAgICAgICA8U2Nyb2xsVG9Ub3AgLz5cclxuICAgICAgICA8Um91dGVyUm91dGVzPlxyXG4gICAgICAgICAgPFJvdXRlIHBhdGg9XCIvbG9naW5cIiBlbGVtZW50PXs8TG9naW4gLz59IC8+XHJcbiAgICAgICAgICA8Um91dGUgcGF0aD1cIi9cIiBlbGVtZW50PXs8TG9naW4gLz59IC8+XHJcblxyXG4gICAgICAgICAgey8qIFByb3RlY3RlZCBSb3V0ZXMgKi99XHJcbiAgICAgICAgICA8Um91dGVcclxuICAgICAgICAgICAgcGF0aD1cIi9zYWxlcy1kYXNoYm9hcmRcIlxyXG4gICAgICAgICAgICBlbGVtZW50PXtcclxuICAgICAgICAgICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgICAgICAgICA8U2FsZXNEYXNoYm9hcmQgLz5cclxuICAgICAgICAgICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPFJvdXRlXHJcbiAgICAgICAgICAgIHBhdGg9XCIvZGVhbC1tYW5hZ2VtZW50XCJcclxuICAgICAgICAgICAgZWxlbWVudD17XHJcbiAgICAgICAgICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgICAgICAgICAgPERlYWxNYW5hZ2VtZW50IC8+XHJcbiAgICAgICAgICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxSb3V0ZVxyXG4gICAgICAgICAgICBwYXRoPVwiL2RlYWwtbWFuYWdlbWVudC9uZXdcIlxyXG4gICAgICAgICAgICBlbGVtZW50PXtcclxuICAgICAgICAgICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgICAgICAgICA8RGVhbE1hbmFnZW1lbnQgLz5cclxuICAgICAgICAgICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPFJvdXRlXHJcbiAgICAgICAgICAgIHBhdGg9XCIvZGVhbC1tYW5hZ2VtZW50LzpkZWFsSWRcIlxyXG4gICAgICAgICAgICBlbGVtZW50PXtcclxuICAgICAgICAgICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgICAgICAgICA8RGVhbE1hbmFnZW1lbnQgLz5cclxuICAgICAgICAgICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPFJvdXRlXHJcbiAgICAgICAgICAgIHBhdGg9XCIvY29udGFjdC1tYW5hZ2VtZW50XCJcclxuICAgICAgICAgICAgZWxlbWVudD17XHJcbiAgICAgICAgICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgICAgICAgICAgPENvbnRhY3RNYW5hZ2VtZW50IC8+XHJcbiAgICAgICAgICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxSb3V0ZVxyXG4gICAgICAgICAgICBwYXRoPVwiL3BpcGVsaW5lLWFuYWx5dGljc1wiXHJcbiAgICAgICAgICAgIGVsZW1lbnQ9e1xyXG4gICAgICAgICAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICAgICAgICAgIDxQaXBlbGluZUFuYWx5dGljcyAvPlxyXG4gICAgICAgICAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8Um91dGVcclxuICAgICAgICAgICAgcGF0aD1cIi9hY3Rpdml0eS10aW1lbGluZVwiXHJcbiAgICAgICAgICAgIGVsZW1lbnQ9e1xyXG4gICAgICAgICAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICAgICAgICAgIDxBY3Rpdml0eVRpbWVsaW5lIC8+XHJcbiAgICAgICAgICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxSb3V0ZVxyXG4gICAgICAgICAgICBwYXRoPVwiL3NldHRpbmdzLWFkbWluaXN0cmF0aW9uXCJcclxuICAgICAgICAgICAgZWxlbWVudD17XHJcbiAgICAgICAgICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgICAgICAgICAgPFNldHRpbmdzQWRtaW5pc3RyYXRpb24gLz5cclxuICAgICAgICAgICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvUm91dGVyUm91dGVzPlxyXG4gICAgICA8L0Vycm9yQm91bmRhcnk+XHJcbiAgICA8L0Jyb3dzZXJSb3V0ZXI+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFJvdXRlczsiXSwiZmlsZSI6IkQ6L2N1cnJlbnQgcHJvamVjdHMvY2xhdWRlLWNvZGUvc3JjL1JvdXRlcy5qc3gifQ==