import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/contexts/ThemeContext.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/contexts/ThemeContext.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const createContext = __vite__cjsImport3_react["createContext"]; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
export const ThemeContext = createContext({ theme: "light", toggleTheme: () => {
} });
export const ThemeProvider = ({ children }) => {
  _s();
  const getInitialTheme = () => {
    try {
      const stored = localStorage.getItem("theme");
      if (stored)
        return stored;
      if (typeof window !== "undefined" && window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) {
        return "dark";
      }
    } catch (e) {
    }
    return "light";
  };
  const [theme, setTheme] = useState(getInitialTheme);
  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === "dark") {
      root.classList.add("dark");
    } else {
      root.classList.remove("dark");
    }
    try {
      root.setAttribute("data-theme", theme);
      localStorage.setItem("theme", theme);
    } catch (e) {
    }
  }, [theme]);
  const toggleTheme = () => setTheme((prev) => prev === "light" ? "dark" : "light");
  return /* @__PURE__ */ jsxDEV(ThemeContext.Provider, { "data-component-id": "src\\contexts\\ThemeContext.jsx:45:4", "data-component-path": "src\\contexts\\ThemeContext.jsx", "data-component-line": "45", "data-component-file": "ThemeContext.jsx", "data-component-name": "ThemeContext.Provider", "data-component-content": "%7B%22elementName%22%3A%22ThemeContext.Provider%22%7D", value: { theme, toggleTheme }, children }, void 0, false, {
    fileName: "D:/current projects/claude-code/src/contexts/ThemeContext.jsx",
    lineNumber: 45,
    columnNumber: 5
  }, this);
};
_s(ThemeProvider, "DZ93y6MoushHNJ3xDqNSOypNhgY=");
_c = ThemeProvider;
var _c;
$RefreshReg$(_c, "ThemeProvider");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/contexts/ThemeContext.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/contexts/ThemeContext.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNENJOzs7Ozs7Ozs7Ozs7Ozs7OztBQTNDSixPQUFPQSxTQUFTQyxlQUFlQyxVQUFVQyxpQkFBaUI7QUFFbkQsYUFBTUMsZUFBZUgsY0FBYyxFQUFFSSxPQUFPLFNBQVNDLGFBQWFBLE1BQU07QUFBQyxFQUFFLENBQUM7QUFFNUUsYUFBTUMsZ0JBQWdCQSxDQUFDLEVBQUVDLFNBQVMsTUFBTTtBQUFBQyxLQUFBO0FBRTdDLFFBQU1DLGtCQUFrQkEsTUFBTTtBQUM1QixRQUFJO0FBQ0YsWUFBTUMsU0FBU0MsYUFBYUMsUUFBUSxPQUFPO0FBQzNDLFVBQUlGO0FBQVEsZUFBT0E7QUFDbkIsVUFBSSxPQUFPRyxXQUFXLGVBQWVBLE9BQU9DLGNBQWNELE9BQU9DLFdBQVcsOEJBQThCLEVBQUVDLFNBQVM7QUFDbkgsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGLFNBQVNDLEdBQUc7QUFBQSxJQUNWO0FBRUYsV0FBTztBQUFBLEVBQ1Q7QUFFQSxRQUFNLENBQUNaLE9BQU9hLFFBQVEsSUFBSWhCLFNBQVNRLGVBQWU7QUFFbERQLFlBQVUsTUFBTTtBQUNkLFVBQU1nQixPQUFPTCxPQUFPTSxTQUFTQztBQUc3QixRQUFJaEIsVUFBVSxRQUFRO0FBQ3BCYyxXQUFLRyxVQUFVQyxJQUFJLE1BQU07QUFBQSxJQUMzQixPQUFPO0FBQ0xKLFdBQUtHLFVBQVVFLE9BQU8sTUFBTTtBQUFBLElBQzlCO0FBR0EsUUFBSTtBQUNGTCxXQUFLTSxhQUFhLGNBQWNwQixLQUFLO0FBQ3JDTyxtQkFBYWMsUUFBUSxTQUFTckIsS0FBSztBQUFBLElBQ3JDLFNBQVNZLEdBQUc7QUFBQSxJQUNWO0FBQUEsRUFFSixHQUFHLENBQUNaLEtBQUssQ0FBQztBQUVWLFFBQU1DLGNBQWNBLE1BQU1ZLFNBQVMsQ0FBQVMsU0FBU0EsU0FBUyxVQUFVLFNBQVMsT0FBUTtBQUVoRixTQUNFLHVCQUFDLGFBQWEsVUFBYixFQUFhLGtVQUFTLE9BQU8sRUFBRXRCLE9BQU9DLFlBQVksR0FDaERFLFlBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBO0FBRUo7QUFBRUMsR0EzQ1dGLGVBQWE7QUFBQXFCLEtBQWJyQjtBQUFhLElBQUFxQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJjcmVhdGVDb250ZXh0IiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJUaGVtZUNvbnRleHQiLCJ0aGVtZSIsInRvZ2dsZVRoZW1lIiwiVGhlbWVQcm92aWRlciIsImNoaWxkcmVuIiwiX3MiLCJnZXRJbml0aWFsVGhlbWUiLCJzdG9yZWQiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwid2luZG93IiwibWF0Y2hNZWRpYSIsIm1hdGNoZXMiLCJlIiwic2V0VGhlbWUiLCJyb290IiwiZG9jdW1lbnQiLCJkb2N1bWVudEVsZW1lbnQiLCJjbGFzc0xpc3QiLCJhZGQiLCJyZW1vdmUiLCJzZXRBdHRyaWJ1dGUiLCJzZXRJdGVtIiwicHJldiIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiVGhlbWVDb250ZXh0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJcclxuaW1wb3J0IFJlYWN0LCB7IGNyZWF0ZUNvbnRleHQsIHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XHJcblxyXG5leHBvcnQgY29uc3QgVGhlbWVDb250ZXh0ID0gY3JlYXRlQ29udGV4dCh7IHRoZW1lOiAnbGlnaHQnLCB0b2dnbGVUaGVtZTogKCkgPT4ge30gfSk7XHJcblxyXG5leHBvcnQgY29uc3QgVGhlbWVQcm92aWRlciA9ICh7IGNoaWxkcmVuIH0pID0+IHtcclxuICAvLyByZWFkIHN0b3JlZCBwcmVmZXJlbmNlIG9yIHN5c3RlbSBwcmVmZXJlbmNlXHJcbiAgY29uc3QgZ2V0SW5pdGlhbFRoZW1lID0gKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3Qgc3RvcmVkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3RoZW1lJyk7XHJcbiAgICAgIGlmIChzdG9yZWQpIHJldHVybiBzdG9yZWQ7XHJcbiAgICAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyAmJiB3aW5kb3cubWF0Y2hNZWRpYSAmJiB3aW5kb3cubWF0Y2hNZWRpYSgnKHByZWZlcnMtY29sb3Itc2NoZW1lOiBkYXJrKScpLm1hdGNoZXMpIHtcclxuICAgICAgICByZXR1cm4gJ2RhcmsnO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgIC8vIGlnbm9yZVxyXG4gICAgfVxyXG4gICAgcmV0dXJuICdsaWdodCc7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgW3RoZW1lLCBzZXRUaGVtZV0gPSB1c2VTdGF0ZShnZXRJbml0aWFsVGhlbWUpO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3Qgcm9vdCA9IHdpbmRvdy5kb2N1bWVudC5kb2N1bWVudEVsZW1lbnQ7XHJcblxyXG4gICAgLy8gVGFpbHdpbmQgdXNlcyB0aGUgJ2RhcmsnIGNsYXNzIG9uIDxodG1sPiB3aGVuIGRhcmtNb2RlOiAnY2xhc3MnXHJcbiAgICBpZiAodGhlbWUgPT09ICdkYXJrJykge1xyXG4gICAgICByb290LmNsYXNzTGlzdC5hZGQoJ2RhcmsnKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJvb3QuY2xhc3NMaXN0LnJlbW92ZSgnZGFyaycpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIFNvbWUgVUkgbGlicyAoZGFpc3lVSSwgZXRjLikgcmVhZCBkYXRhLXRoZW1lXHJcbiAgICB0cnkge1xyXG4gICAgICByb290LnNldEF0dHJpYnV0ZSgnZGF0YS10aGVtZScsIHRoZW1lKTtcclxuICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3RoZW1lJywgdGhlbWUpO1xyXG4gICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAvLyBpZ25vcmUgc3RvcmFnZSBlcnJvcnNcclxuICAgIH1cclxuICB9LCBbdGhlbWVdKTtcclxuXHJcbiAgY29uc3QgdG9nZ2xlVGhlbWUgPSAoKSA9PiBzZXRUaGVtZShwcmV2ID0+IChwcmV2ID09PSAnbGlnaHQnID8gJ2RhcmsnIDogJ2xpZ2h0JykpO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPFRoZW1lQ29udGV4dC5Qcm92aWRlciB2YWx1ZT17eyB0aGVtZSwgdG9nZ2xlVGhlbWUgfX0+XHJcbiAgICAgIHtjaGlsZHJlbn1cclxuICAgIDwvVGhlbWVDb250ZXh0LlByb3ZpZGVyPlxyXG4gICk7XHJcbn07XHJcbiJdLCJmaWxlIjoiRDovY3VycmVudCBwcm9qZWN0cy9jbGF1ZGUtY29kZS9zcmMvY29udGV4dHMvVGhlbWVDb250ZXh0LmpzeCJ9