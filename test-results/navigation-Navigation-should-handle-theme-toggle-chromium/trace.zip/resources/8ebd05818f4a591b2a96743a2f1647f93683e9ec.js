import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/App.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { Toaster } from "/node_modules/.vite/deps/react-hot-toast.js?v=44ab9529";
import { AuthProvider } from "/src/contexts/AuthContext.jsx";
import { ThemeProvider } from "/src/contexts/ThemeContext.jsx";
import Routes from "/src/Routes.jsx";
function App() {
  return /* @__PURE__ */ jsxDEV(AuthProvider, { "data-component-id": "src\\App.jsx:9:4", "data-component-path": "src\\App.jsx", "data-component-line": "9", "data-component-file": "App.jsx", "data-component-name": "AuthProvider", "data-component-content": "%7B%22elementName%22%3A%22AuthProvider%22%7D", children: /* @__PURE__ */ jsxDEV(ThemeProvider, { "data-component-id": "src\\App.jsx:10:6", "data-component-path": "src\\App.jsx", "data-component-line": "10", "data-component-file": "App.jsx", "data-component-name": "ThemeProvider", "data-component-content": "%7B%22elementName%22%3A%22ThemeProvider%22%7D", children: /* @__PURE__ */ jsxDEV(AppContent, { "data-component-id": "src\\App.jsx:11:8", "data-component-path": "src\\App.jsx", "data-component-line": "11", "data-component-file": "App.jsx", "data-component-name": "AppContent", "data-component-content": "%7B%22elementName%22%3A%22AppContent%22%7D" }, void 0, false, {
    fileName: "D:/current projects/claude-code/src/App.jsx",
    lineNumber: 11,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "D:/current projects/claude-code/src/App.jsx",
    lineNumber: 10,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "D:/current projects/claude-code/src/App.jsx",
    lineNumber: 9,
    columnNumber: 5
  }, this);
}
_c = App;
function AppContent() {
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\App.jsx:20:4", "data-component-path": "src\\App.jsx", "data-component-line": "20", "data-component-file": "App.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22min-h-screen%20bg-background%20text-text-primary%20transition-colors%20duration-300%22%7D", className: "min-h-screen bg-background text-text-primary transition-colors duration-300", children: [
    /* @__PURE__ */ jsxDEV(Routes, { "data-component-id": "src\\App.jsx:21:6", "data-component-path": "src\\App.jsx", "data-component-line": "21", "data-component-file": "App.jsx", "data-component-name": "Routes", "data-component-content": "%7B%22elementName%22%3A%22Routes%22%7D" }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/App.jsx",
      lineNumber: 21,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Toaster,
      {
        "data-component-id": "src\\App.jsx:22:6",
        "data-component-path": "src\\App.jsx",
        "data-component-line": "22",
        "data-component-file": "App.jsx",
        "data-component-name": "Toaster",
        "data-component-content": "%7B%22elementName%22%3A%22Toaster%22%7D",
        position: "top-right",
        toastOptions: {
          duration: 4e3,
          className: "",
          style: {
            background: "#ffffff",
            color: "#1f2937",
            border: "1px solid #e5e7eb",
            boxShadow: "0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)",
            borderRadius: "8px",
            fontSize: "14px",
            fontWeight: "500"
          },
          success: {
            style: {
              background: "#f0fdf4",
              color: "#166534",
              border: "1px solid #bbf7d0"
            },
            iconTheme: {
              primary: "#16a34a",
              secondary: "#ffffff"
            }
          },
          error: {
            style: {
              background: "#fef2f2",
              color: "#991b1b",
              border: "1px solid #fecaca"
            },
            iconTheme: {
              primary: "#dc2626",
              secondary: "#ffffff"
            }
          }
        }
      },
      void 0,
      false,
      {
        fileName: "D:/current projects/claude-code/src/App.jsx",
        lineNumber: 22,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/App.jsx",
    lineNumber: 20,
    columnNumber: 5
  }, this);
}
_c2 = AppContent;
export default App;
var _c, _c2;
$RefreshReg$(_c, "App");
$RefreshReg$(_c2, "AppContent");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVVE7QUFWUixPQUFPQSxvQkFBa0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDekIsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MscUJBQXFCO0FBQzlCLE9BQU9DLFlBQVk7QUFFbkIsU0FBU0MsTUFBTTtBQUNiLFNBQ0UsdUJBQUMsK1FBQ0MsaUNBQUMsb1JBQ0MsaUNBQUMsNlFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFXLEtBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUlBO0FBRUo7QUFBQ0MsS0FSUUQ7QUFVVCxTQUFTRSxhQUFhO0FBRXBCLFNBQ0UsdUJBQUMsc1dBQUksV0FBVSwrRUFDYjtBQUFBLDJCQUFDLGlRQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBTztBQUFBLElBQ1A7QUFBQSxNQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUNDLFVBQVM7QUFBQSxRQUNULGNBQWM7QUFBQSxVQUNaQyxVQUFVO0FBQUEsVUFDVkMsV0FBVztBQUFBLFVBQ1hDLE9BQU87QUFBQSxZQUNMQyxZQUFZO0FBQUEsWUFDWkMsT0FBTztBQUFBLFlBQ1BDLFFBQVE7QUFBQSxZQUNSQyxXQUFXO0FBQUEsWUFDWEMsY0FBYztBQUFBLFlBQ2RDLFVBQVU7QUFBQSxZQUNWQyxZQUFZO0FBQUEsVUFDZDtBQUFBLFVBQ0FDLFNBQVM7QUFBQSxZQUNQUixPQUFPO0FBQUEsY0FDTEMsWUFBWTtBQUFBLGNBQ1pDLE9BQU87QUFBQSxjQUNQQyxRQUFRO0FBQUEsWUFDVjtBQUFBLFlBQ0FNLFdBQVc7QUFBQSxjQUNUQyxTQUFTO0FBQUEsY0FDVEMsV0FBVztBQUFBLFlBQ2I7QUFBQSxVQUNGO0FBQUEsVUFDQUMsT0FBTztBQUFBLFlBQ0xaLE9BQU87QUFBQSxjQUNMQyxZQUFZO0FBQUEsY0FDWkMsT0FBTztBQUFBLGNBQ1BDLFFBQVE7QUFBQSxZQUNWO0FBQUEsWUFDQU0sV0FBVztBQUFBLGNBQ1RDLFNBQVM7QUFBQSxjQUNUQyxXQUFXO0FBQUEsWUFDYjtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUE7QUFBQSxNQXBDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFvQ0k7QUFBQSxPQXRDTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBd0NBO0FBRUo7QUFBQ0UsTUE3Q1FoQjtBQStDVCxlQUFlRjtBQUFJLElBQUFDLElBQUFpQjtBQUFBQyxhQUFBbEIsSUFBQTtBQUFBa0IsYUFBQUQsS0FBQSIsIm5hbWVzIjpbIlJlYWN0IiwiVG9hc3RlciIsIkF1dGhQcm92aWRlciIsIlRoZW1lUHJvdmlkZXIiLCJSb3V0ZXMiLCJBcHAiLCJfYyIsIkFwcENvbnRlbnQiLCJkdXJhdGlvbiIsImNsYXNzTmFtZSIsInN0eWxlIiwiYmFja2dyb3VuZCIsImNvbG9yIiwiYm9yZGVyIiwiYm94U2hhZG93IiwiYm9yZGVyUmFkaXVzIiwiZm9udFNpemUiLCJmb250V2VpZ2h0Iiwic3VjY2VzcyIsImljb25UaGVtZSIsInByaW1hcnkiLCJzZWNvbmRhcnkiLCJlcnJvciIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFwcC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgVG9hc3RlciB9IGZyb20gJ3JlYWN0LWhvdC10b2FzdCc7XHJcbmltcG9ydCB7IEF1dGhQcm92aWRlciB9IGZyb20gJy4vY29udGV4dHMvQXV0aENvbnRleHQnO1xyXG5pbXBvcnQgeyBUaGVtZVByb3ZpZGVyIH0gZnJvbSAnLi9jb250ZXh0cy9UaGVtZUNvbnRleHQnO1xyXG5pbXBvcnQgUm91dGVzIGZyb20gJy4vUm91dGVzJztcclxuXHJcbmZ1bmN0aW9uIEFwcCgpIHtcclxuICByZXR1cm4gKFxyXG4gICAgPEF1dGhQcm92aWRlcj5cclxuICAgICAgPFRoZW1lUHJvdmlkZXI+XHJcbiAgICAgICAgPEFwcENvbnRlbnQgLz5cclxuICAgICAgPC9UaGVtZVByb3ZpZGVyPlxyXG4gICAgPC9BdXRoUHJvdmlkZXI+XHJcbiAgKTtcclxufVxyXG5cclxuZnVuY3Rpb24gQXBwQ29udGVudCgpIHtcclxuICAvLyBTaW1wbGUgYXBwcm9hY2ggd2l0aCBDU1MgY3VzdG9tIHByb3BlcnRpZXMgdGhhdCB3b3JrIHdpdGggb3VyIGV4aXN0aW5nIHRoZW1lIHN5c3RlbVxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy1iYWNrZ3JvdW5kIHRleHQtdGV4dC1wcmltYXJ5IHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTMwMFwiPlxyXG4gICAgICA8Um91dGVzIC8+XHJcbiAgICAgIDxUb2FzdGVyXHJcbiAgICAgICAgcG9zaXRpb249XCJ0b3AtcmlnaHRcIlxyXG4gICAgICAgIHRvYXN0T3B0aW9ucz17e1xyXG4gICAgICAgICAgZHVyYXRpb246IDQwMDAsXHJcbiAgICAgICAgICBjbGFzc05hbWU6ICcnLFxyXG4gICAgICAgICAgc3R5bGU6IHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogJyNmZmZmZmYnLFxyXG4gICAgICAgICAgICBjb2xvcjogJyMxZjI5MzcnLFxyXG4gICAgICAgICAgICBib3JkZXI6ICcxcHggc29saWQgI2U1ZTdlYicsXHJcbiAgICAgICAgICAgIGJveFNoYWRvdzogJzAgMTBweCAxNXB4IC0zcHggcmdiYSgwLCAwLCAwLCAwLjEpLCAwIDRweCA2cHggLTJweCByZ2JhKDAsIDAsIDAsIDAuMDUpJyxcclxuICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAnOHB4JyxcclxuICAgICAgICAgICAgZm9udFNpemU6ICcxNHB4JyxcclxuICAgICAgICAgICAgZm9udFdlaWdodDogJzUwMCcsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgc3VjY2Vzczoge1xyXG4gICAgICAgICAgICBzdHlsZToge1xyXG4gICAgICAgICAgICAgIGJhY2tncm91bmQ6ICcjZjBmZGY0JyxcclxuICAgICAgICAgICAgICBjb2xvcjogJyMxNjY1MzQnLFxyXG4gICAgICAgICAgICAgIGJvcmRlcjogJzFweCBzb2xpZCAjYmJmN2QwJyxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgaWNvblRoZW1lOiB7XHJcbiAgICAgICAgICAgICAgcHJpbWFyeTogJyMxNmEzNGEnLFxyXG4gICAgICAgICAgICAgIHNlY29uZGFyeTogJyNmZmZmZmYnLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIGVycm9yOiB7XHJcbiAgICAgICAgICAgIHN0eWxlOiB7XHJcbiAgICAgICAgICAgICAgYmFja2dyb3VuZDogJyNmZWYyZjInLFxyXG4gICAgICAgICAgICAgIGNvbG9yOiAnIzk5MWIxYicsXHJcbiAgICAgICAgICAgICAgYm9yZGVyOiAnMXB4IHNvbGlkICNmZWNhY2EnLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBpY29uVGhlbWU6IHtcclxuICAgICAgICAgICAgICBwcmltYXJ5OiAnI2RjMjYyNicsXHJcbiAgICAgICAgICAgICAgc2Vjb25kYXJ5OiAnI2ZmZmZmZicsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH19XHJcbiAgICAgIC8+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBBcHA7Il0sImZpbGUiOiJEOi9jdXJyZW50IHByb2plY3RzL2NsYXVkZS1jb2RlL3NyYy9BcHAuanN4In0=