import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/deal-management/index.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/deal-management/index.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useCallback = __vite__cjsImport3_react["useCallback"];
import { useParams, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=44ab9529";
import toast from "/node_modules/.vite/deps/react-hot-toast.js?v=44ab9529";
import { useAuth } from "/src/contexts/AuthContext.jsx";
import Header from "/src/components/ui/Header.jsx";
import Breadcrumb from "/src/components/ui/Breadcrumb.jsx";
import Icon from "/src/components/AppIcon.jsx";
import DealForm from "/src/pages/deal-management/components/DealForm.jsx";
import ActivityTimeline from "/src/pages/deal-management/components/ActivityTimeline.jsx";
import DocumentsSection from "/src/pages/deal-management/components/DocumentsSection.jsx";
import DealActions from "/src/pages/deal-management/components/DealActions.jsx";
import DealsGridView from "/src/pages/deal-management/components/DealsGridView.jsx";
import dealsService from "/src/services/dealsService.js";
import contactsService from "/src/services/contactsService.js";
import companiesService from "/src/services/companiesService.js";
import dealActivitiesService from "/src/services/dealActivitiesService.js";
import dealDocumentsService from "/src/services/dealDocumentsService.js";
const DealManagement = () => {
  _s();
  const { dealId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [selectedDeal, setSelectedDeal] = useState(null);
  const [allDeals, setAllDeals] = useState([]);
  const [contacts, setContacts] = useState([]);
  const [companies, setCompanies] = useState([]);
  const [activities, setActivities] = useState([]);
  const [documents, setDocuments] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [isListView, setIsListView] = useState(true);
  const [isGridView, setIsGridView] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isLoadingActivities, setIsLoadingActivities] = useState(false);
  const [isLoadingDocuments, setIsLoadingDocuments] = useState(false);
  const [error, setError] = useState(null);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [selectedStageFilter, setSelectedStageFilter] = useState("all");
  const [activityChannel, setActivityChannel] = useState(null);
  const [documentChannel, setDocumentChannel] = useState(null);
  const stages = [
    { value: "lead", label: "Lead", color: "bg-gray-100 text-gray-800" },
    { value: "qualified", label: "Qualified", color: "bg-blue-100 text-blue-800" },
    { value: "proposal", label: "Proposal", color: "bg-yellow-100 text-yellow-800" },
    { value: "negotiation", label: "Negotiation", color: "bg-orange-100 text-orange-800" },
    { value: "closed_won", label: "Closed Won", color: "bg-green-100 text-green-800" },
    { value: "closed_lost", label: "Closed Lost", color: "bg-red-100 text-red-800" }
  ];
  const filteredDeals = selectedStageFilter === "all" ? allDeals : allDeals.filter((deal) => deal.stage === selectedStageFilter);
  useEffect(() => {
    if (!user)
      return;
    const loadInitialData = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const [dealsData, contactsData, companiesData] = await Promise.all(
          [
            dealsService?.getUserDeals(),
            contactsService?.getUserContacts(),
            companiesService?.getAllCompanies()
          ]
        );
        setAllDeals(dealsData || []);
        setContacts(contactsData || []);
        setCompanies(companiesData || []);
        if (dealId && dealId !== "new") {
          setIsListView(false);
          setShowForm(true);
          await loadDeal(dealId);
        } else if (dealId === "new") {
          setIsListView(false);
          setShowForm(true);
          setSelectedDeal(null);
        } else {
          setIsListView(true);
          setShowForm(false);
        }
      } catch (err) {
        console.error("Error loading initial data:", err);
        setError("Failed to load data. Please refresh the page.");
      } finally {
        setIsLoading(false);
      }
    };
    loadInitialData();
  }, [dealId, user]);
  const loadDeal = async (id) => {
    try {
      const dealData = await dealsService?.getDealById(id);
      if (!dealData) {
        setError("Deal not found");
        setIsLoading(false);
        return;
      }
      setSelectedDeal(dealData);
      await Promise.all(
        [
          loadActivities(id),
          loadDocuments(id)
        ]
      );
      setupRealtimeSubscriptions(id);
    } catch (err) {
      console.error("Error loading deal:", err);
      if (err?.code === "PGRST116" || err?.message?.includes("not found")) {
        setError("Deal not found. It may have been deleted or you may not have permission to view it.");
      } else if (err?.message?.toLowerCase().includes("permission") || err?.message?.toLowerCase().includes("policy")) {
        setError("Permission denied. You may not have access to view this deal.");
      } else if (err?.message?.includes("company") || err?.message?.includes("schema cache")) {
        setError("Could not load deal information. Please check your database connection and try refreshing the page.");
      } else {
        setError("Failed to load deal. Please try again.");
      }
    } finally {
      setIsLoading(false);
    }
  };
  const loadActivities = async (id) => {
    setIsLoadingActivities(true);
    try {
      const activitiesData = await dealActivitiesService?.getDealActivities(id);
      setActivities(activitiesData || []);
    } catch (err) {
      console.error("Error loading activities:", err);
    } finally {
      setIsLoadingActivities(false);
    }
  };
  const loadDocuments = async (id) => {
    setIsLoadingDocuments(true);
    try {
      const documentsData = await dealDocumentsService?.getDealDocuments(id);
      setDocuments(documentsData || []);
    } catch (err) {
      console.error("Error loading documents:", err);
    } finally {
      setIsLoadingDocuments(false);
    }
  };
  const setupRealtimeSubscriptions = (id) => {
    const activitySub = dealActivitiesService?.subscribeToActivityChanges(id, (payload) => {
      handleActivityChange(payload);
    });
    setActivityChannel(activitySub);
    const documentSub = dealDocumentsService?.subscribeToDocumentChanges(id, (payload) => {
      handleDocumentChange(payload);
    });
    setDocumentChannel(documentSub);
  };
  const handleActivityChange = useCallback((payload) => {
    const { eventType, new: newRecord, old: oldRecord } = payload;
    setActivities((prev) => {
      switch (eventType) {
        case "INSERT":
          const newActivity = {
            id: newRecord?.id,
            type: newRecord?.type,
            title: newRecord?.subject,
            description: newRecord?.description,
            timestamp: newRecord?.created_at,
            user: "Unknown User",
            // Will be populated by reload
            dealId: newRecord?.deal_id
          };
          return [newActivity, ...prev];
        case "DELETE":
          return prev?.filter((activity) => activity?.id !== oldRecord?.id);
        case "UPDATE":
          return prev?.map(
            (activity) => activity?.id === newRecord?.id ? { ...activity, ...newRecord } : activity
          );
        default:
          return prev;
      }
    });
  }, []);
  const handleDocumentChange = useCallback((payload) => {
    const { eventType, new: newRecord, old: oldRecord } = payload;
    setDocuments((prev) => {
      switch (eventType) {
        case "INSERT":
          const newDocument = {
            id: newRecord?.id,
            name: newRecord?.name,
            size: dealDocumentsService?.formatFileSize(newRecord?.file_size),
            type: dealDocumentsService?.getFileExtension(newRecord?.name),
            uploadedAt: newRecord?.created_at,
            uploadedBy: "Unknown User",
            // Will be populated by reload
            dealId: newRecord?.deal_id,
            fileUrl: newRecord?.file_url
          };
          return [newDocument, ...prev];
        case "DELETE":
          return prev?.filter((doc) => doc?.id !== oldRecord?.id);
        default:
          return prev;
      }
    });
  }, []);
  useEffect(() => {
    return () => {
      if (activityChannel) {
        dealActivitiesService?.unsubscribeFromActivityChanges(activityChannel);
      }
      if (documentChannel) {
        dealDocumentsService?.unsubscribeFromDocumentChanges(documentChannel);
      }
    };
  }, [activityChannel, documentChannel]);
  const handleCreateNewDeal = () => {
    setSelectedDeal(null);
    setShowForm(true);
    setIsListView(false);
    navigate("/deal-management/new");
  };
  const handleEditDeal = (deal) => {
    setSelectedDeal(deal);
    setShowForm(true);
    setIsListView(false);
    navigate(`/deal-management/${deal.id}`);
  };
  const handleBackToList = () => {
    setShowForm(false);
    setIsListView(true);
    setSelectedDeal(null);
    setError(null);
    navigate("/deal-management");
  };
  const loadAllDeals = async () => {
    try {
      const dealsData = await dealsService?.getUserDeals();
      setAllDeals(dealsData || []);
    } catch (err) {
      console.error("Error loading deals:", err);
    }
  };
  const handleSaveDeal = async (dealData) => {
    if (!user?.id) {
      setError("You must be logged in to save deals");
      return;
    }
    setIsSaving(true);
    setError(null);
    try {
      let result;
      if (selectedDeal?.id) {
        result = await dealsService?.updateDeal(selectedDeal?.id, {
          ...dealData,
          owner_id: user?.id
        });
        if (result) {
          setSelectedDeal(result);
          setAllDeals((prev) => prev.map(
            (deal) => deal.id === result.id ? result : deal
          ));
          toast.success(`Deal "${result.name || "Untitled Deal"}" updated successfully!`);
        }
      } else {
        result = await dealsService?.createDeal({
          ...dealData,
          owner_id: user?.id
        });
        if (result?.id) {
          toast.success(`Deal "${dealData.name || "Untitled Deal"}" created successfully!`);
          setAllDeals((prev) => [result, ...prev]);
        } else {
          throw new Error("Deal created but no ID returned");
        }
      }
      if (!selectedDeal?.id) {
        setIsSaving(false);
        handleBackToList();
        return;
      }
    } catch (err) {
      console.error("Error saving deal:", err);
      if (err?.code === "23503") {
        const errorMsg = "The selected company or contact is no longer available. Please refresh the page and select valid options.";
        setError(errorMsg);
        toast.error(errorMsg);
      } else if (err?.code === "PGRST116" || err?.message?.includes("not found")) {
        const errorMsg = "Deal not found. It may have been deleted by another user.";
        setError(errorMsg);
        toast.error(errorMsg);
        navigate("/deal-management");
        return;
      } else if (err?.message?.toLowerCase().includes("permission") || err?.message?.toLowerCase().includes("policy")) {
        const errorMsg = "Permission denied. You may not have access to modify this deal.";
        setError(errorMsg);
        toast.error(errorMsg);
      } else if (err?.message?.includes("company") || err?.message?.includes("schema cache")) {
        const errorMsg = "There was an issue accessing company information. Please refresh the page and try again.";
        setError(errorMsg);
        toast.error(errorMsg);
      } else {
        const errorMsg = err?.message || "Failed to save deal. Please try again.";
        setError(errorMsg);
        toast.error(errorMsg);
      }
    } finally {
      setIsSaving(false);
    }
  };
  const handleDeleteDeal = async () => {
    if (!selectedDeal?.id || !user?.id)
      return;
    try {
      await dealsService?.deleteDeal(selectedDeal?.id);
      toast.success(`Deal "${selectedDeal.name || "Untitled Deal"}" deleted successfully!`);
      setAllDeals((prev) => prev.filter((deal) => deal.id !== selectedDeal.id));
      navigate("/deal-management");
    } catch (err) {
      console.error("Error deleting deal:", err);
      const errorMsg = "Failed to delete deal. Please try again.";
      setError(errorMsg);
      toast.error(errorMsg);
    }
    setShowDeleteModal(false);
  };
  const handleCloneDeal = async () => {
    if (!selectedDeal || !user?.id)
      return;
    try {
      const clonedDealData = {
        name: `${selectedDeal?.name} (Copy)`,
        description: selectedDeal?.description,
        value: selectedDeal?.value,
        stage: "lead",
        probability: 10,
        contact_id: selectedDeal?.contact_id,
        company_id: selectedDeal?.company_id,
        lead_source: selectedDeal?.lead_source,
        owner_id: user?.id
      };
      let result = await dealsService?.createDeal(clonedDealData);
      if (result?.id) {
        toast.success(`Deal "${clonedDealData.name}" cloned successfully!`);
        setAllDeals((prev) => [result, ...prev]);
        navigate(`/deal-management/${result?.id}`);
      }
    } catch (err) {
      console.error("Error cloning deal:", err);
      const errorMsg = "Failed to clone deal. Please try again.";
      setError(errorMsg);
      toast.error(errorMsg);
    }
  };
  const handleCreateTask = () => {
  };
  const handleAddActivity = async (activityData) => {
    if (!selectedDeal?.id)
      return;
    try {
      const newActivity = await dealActivitiesService?.createActivity({
        ...activityData,
        dealId: selectedDeal?.id,
        contactId: selectedDeal?.contact_id
      });
      setActivities((prev) => [newActivity, ...prev]);
    } catch (err) {
      console.error("Error adding activity:", err);
      setError("Failed to add activity. Please try again.");
    }
  };
  const handleDeleteActivity = async (activityId) => {
    try {
      await dealActivitiesService?.deleteActivity(activityId);
      setActivities((prev) => prev?.filter((activity) => activity?.id !== activityId));
    } catch (err) {
      console.error("Error deleting activity:", err);
      setError("Failed to delete activity. Please try again.");
    }
  };
  const handleUploadDocument = async (file, documentType = "other") => {
    if (!selectedDeal?.id)
      return;
    try {
      const newDocument = await dealDocumentsService?.uploadDocument(
        file,
        selectedDeal?.id,
        documentType
      );
      setDocuments((prev) => [newDocument, ...prev]);
    } catch (err) {
      console.error("Error uploading document:", err);
      setError("Failed to upload document. Please try again.");
      throw err;
    }
  };
  const handleDeleteDocument = async (documentId, filePath) => {
    try {
      await dealDocumentsService?.deleteDocument(documentId, filePath);
      setDocuments((prev) => prev?.filter((doc) => doc?.id !== documentId));
    } catch (err) {
      console.error("Error deleting document:", err);
      setError("Failed to delete document. Please try again.");
    }
  };
  if (isLoading) {
    return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:542:6", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "542", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22min-h-screen%20bg-background%22%7D", className: "min-h-screen bg-background", children: [
      /* @__PURE__ */ jsxDEV(Header, { "data-component-id": "src\\pages\\deal-management\\index.jsx:543:8", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "543", "data-component-file": "index.jsx", "data-component-name": "Header", "data-component-content": "%7B%22elementName%22%3A%22Header%22%7D" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
        lineNumber: 543,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("main", { "data-component-id": "src\\pages\\deal-management\\index.jsx:544:8", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "544", "data-component-file": "index.jsx", "data-component-name": "main", "data-component-content": "%7B%22elementName%22%3A%22main%22%2C%22className%22%3A%22pt-16%22%7D", className: "pt-16", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:545:10", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "545", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22px-6%20py-8%22%7D", className: "px-6 py-8", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:546:12", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "546", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22max-w-7xl%20mx-auto%22%7D", className: "max-w-7xl mx-auto", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:547:14", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "547", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-center%20h-96%22%7D", className: "flex items-center justify-center h-96", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:548:16", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "548", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-3%22%7D", className: "flex items-center space-x-3", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:549:18", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "549", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22animate-spin%20rounded-full%20h-8%20w-8%20border-b-2%20border-primary%22%7D", className: "animate-spin rounded-full h-8 w-8 border-b-2 border-primary" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
          lineNumber: 549,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\index.jsx:550:18", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "550", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-text-secondary%22%2C%22textContent%22%3A%22Loading%20deal...%22%7D", className: "text-text-secondary", children: "Loading deal..." }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
          lineNumber: 550,
          columnNumber: 19
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
        lineNumber: 548,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
        lineNumber: 547,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
        lineNumber: 546,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
        lineNumber: 545,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
        lineNumber: 544,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
      lineNumber: 542,
      columnNumber: 7
    }, this);
  }
  if (error && !selectedDeal && !isListView) {
    return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:566:6", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "566", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22min-h-screen%20bg-background%22%7D", className: "min-h-screen bg-background", children: [
      /* @__PURE__ */ jsxDEV(Header, { "data-component-id": "src\\pages\\deal-management\\index.jsx:567:8", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "567", "data-component-file": "index.jsx", "data-component-name": "Header", "data-component-content": "%7B%22elementName%22%3A%22Header%22%7D" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
        lineNumber: 567,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("main", { "data-component-id": "src\\pages\\deal-management\\index.jsx:568:8", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "568", "data-component-file": "index.jsx", "data-component-name": "main", "data-component-content": "%7B%22elementName%22%3A%22main%22%2C%22className%22%3A%22pt-16%22%7D", className: "pt-16", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:569:10", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "569", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22px-6%20py-8%22%7D", className: "px-6 py-8", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:570:12", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "570", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22max-w-7xl%20mx-auto%22%7D", className: "max-w-7xl mx-auto", children: [
        /* @__PURE__ */ jsxDEV(Breadcrumb, { "data-component-id": "src\\pages\\deal-management\\index.jsx:571:14", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "571", "data-component-file": "index.jsx", "data-component-name": "Breadcrumb", "data-component-content": "%7B%22elementName%22%3A%22Breadcrumb%22%7D" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
          lineNumber: 571,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:572:14", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "572", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-center%20py-12%22%7D", className: "text-center py-12", children: [
          /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\deal-management\\index.jsx:573:16", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "573", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22AlertCircle%22%2C%22className%22%3A%22text-text-tertiary%20mx-auto%20mb-4%22%7D", name: "AlertCircle", size: 48, className: "text-text-tertiary mx-auto mb-4" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
            lineNumber: 573,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { "data-component-id": "src\\pages\\deal-management\\index.jsx:574:16", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "574", "data-component-file": "index.jsx", "data-component-name": "h2", "data-component-content": "%7B%22elementName%22%3A%22h2%22%2C%22className%22%3A%22text-xl%20font-semibold%20text-text-primary%20mb-2%22%7D", className: "text-xl font-semibold text-text-primary mb-2", children: selectedDeal === null && dealId !== "new" ? "Deal Not Found" : "Error" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
            lineNumber: 574,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\deal-management\\index.jsx:577:16", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "577", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20mb-6%22%7D", className: "text-text-secondary mb-6", children: error }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
            lineNumber: 577,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\deal-management\\index.jsx:578:16",
              "data-component-path": "src\\pages\\deal-management\\index.jsx",
              "data-component-line": "578",
              "data-component-file": "index.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22btn-primary%22%2C%22textContent%22%3A%22Back%20to%20Dashboard%22%7D",
              onClick: () => navigate("/sales-dashboard"),
              className: "btn-primary",
              children: "Back to Dashboard"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
              lineNumber: 578,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
          lineNumber: 572,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
        lineNumber: 570,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
        lineNumber: 569,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
        lineNumber: 568,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
      lineNumber: 566,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:595:4", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "595", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22min-h-screen%20bg-background%22%7D", className: "min-h-screen bg-background", children: [
    /* @__PURE__ */ jsxDEV(Header, { "data-component-id": "src\\pages\\deal-management\\index.jsx:596:6", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "596", "data-component-file": "index.jsx", "data-component-name": "Header", "data-component-content": "%7B%22elementName%22%3A%22Header%22%7D" }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
      lineNumber: 596,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("main", { "data-component-id": "src\\pages\\deal-management\\index.jsx:597:6", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "597", "data-component-file": "index.jsx", "data-component-name": "main", "data-component-content": "%7B%22elementName%22%3A%22main%22%2C%22className%22%3A%22pt-16%22%7D", className: "pt-16", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:598:8", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "598", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22px-6%20py-8%22%7D", className: "px-6 py-8", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:599:10", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "599", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22max-w-7xl%20mx-auto%22%7D", className: "max-w-7xl mx-auto", children: [
      /* @__PURE__ */ jsxDEV(Breadcrumb, { "data-component-id": "src\\pages\\deal-management\\index.jsx:600:12", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "600", "data-component-file": "index.jsx", "data-component-name": "Breadcrumb", "data-component-content": "%7B%22elementName%22%3A%22Breadcrumb%22%7D" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
        lineNumber: 600,
        columnNumber: 13
      }, this),
      error && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:604:12", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "604", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-error-50%20border%20border-error-200%20text-error%20p-4%20rounded-lg%20flex%20items-center%20justify-between%20mb-6%22%7D", className: "bg-error-50 border border-error-200 text-error p-4 rounded-lg flex items-center justify-between mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:605:16", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "605", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%22%7D", className: "flex items-center space-x-2", children: [
          /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\deal-management\\index.jsx:606:18", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "606", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22AlertCircle%22%7D", name: "AlertCircle", size: 20 }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
            lineNumber: 606,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\index.jsx:607:18", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "607", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: error }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
            lineNumber: 607,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
          lineNumber: 605,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\deal-management\\index.jsx:609:16",
            "data-component-path": "src\\pages\\deal-management\\index.jsx",
            "data-component-line": "609",
            "data-component-file": "index.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22text-error%20hover%3Atext-error-600%22%7D",
            onClick: () => setError(null),
            className: "text-error hover:text-error-600",
            children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\deal-management\\index.jsx:613:18", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "613", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22X%22%7D", name: "X", size: 16 }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
              lineNumber: 613,
              columnNumber: 19
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
            lineNumber: 609,
            columnNumber: 17
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
        lineNumber: 604,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:619:12", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "619", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20flex-col%20lg%3Aflex-row%20lg%3Aitems-center%20lg%3Ajustify-between%20mb-8%22%7D", className: "flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:620:14", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "620", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22mb-4%20lg%3Amb-0%22%7D", className: "mb-4 lg:mb-0", children: [
          /* @__PURE__ */ jsxDEV("h1", { "data-component-id": "src\\pages\\deal-management\\index.jsx:621:16", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "621", "data-component-file": "index.jsx", "data-component-name": "h1", "data-component-content": "%7B%22elementName%22%3A%22h1%22%2C%22className%22%3A%22text-3xl%20font-bold%20text-text-primary%20mb-2%22%7D", className: "text-3xl font-bold text-text-primary mb-2", children: isListView ? "Deal Management" : selectedDeal?.name || "New Deal" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
            lineNumber: 621,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:624:16", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "624", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-4%20text-sm%20text-text-secondary%22%7D", className: "flex items-center space-x-4 text-sm text-text-secondary", children: isListView ? /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\index.jsx:626:18", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "626", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Manage%20all%20your%20deals%22%7D", children: "Manage all your deals" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
            lineNumber: 626,
            columnNumber: 19
          }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
            selectedDeal?.id && /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\index.jsx:631:26", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "631", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Deal%20ID%3A%20%23%22%7D", children: [
                "Deal ID: #",
                selectedDeal?.id
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                lineNumber: 631,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\index.jsx:632:26", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "632", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22%E2%80%A2%22%7D", children: "•" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                lineNumber: 632,
                columnNumber: 27
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
              lineNumber: 630,
              columnNumber: 21
            }, this),
            selectedDeal?.created_at && /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\index.jsx:637:26", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "637", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Created%3A%22%7D", children: [
                "Created: ",
                new Date(selectedDeal.created_at)?.toLocaleDateString()
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                lineNumber: 637,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\index.jsx:638:26", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "638", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22%E2%80%A2%22%7D", children: "•" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                lineNumber: 638,
                columnNumber: 27
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
              lineNumber: 636,
              columnNumber: 21
            }, this),
            selectedDeal?.updated_at && /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\index.jsx:642:20", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "642", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Last%20updated%3A%22%7D", children: [
              "Last updated: ",
              new Date(selectedDeal.updated_at)?.toLocaleDateString()
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
              lineNumber: 642,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
            lineNumber: 628,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
            lineNumber: 624,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
          lineNumber: 620,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:649:14", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "649", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-3%22%7D", className: "flex items-center space-x-3", children: isListView ? /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\deal-management\\index.jsx:651:16",
            "data-component-path": "src\\pages\\deal-management\\index.jsx",
            "data-component-line": "651",
            "data-component-file": "index.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22btn-primary%20flex%20items-center%20space-x-2%22%7D",
            onClick: handleCreateNewDeal,
            className: "btn-primary flex items-center space-x-2",
            children: [
              /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\deal-management\\index.jsx:655:20", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "655", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Plus%22%7D", name: "Plus", size: 16 }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                lineNumber: 655,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\index.jsx:656:20", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "656", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Create%20Deal%22%7D", children: "Create Deal" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                lineNumber: 656,
                columnNumber: 21
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
            lineNumber: 651,
            columnNumber: 17
          },
          this
        ) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\deal-management\\index.jsx:660:20",
              "data-component-path": "src\\pages\\deal-management\\index.jsx",
              "data-component-line": "660",
              "data-component-file": "index.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22btn-secondary%20flex%20items-center%20space-x-2%22%7D",
              onClick: handleBackToList,
              className: "btn-secondary flex items-center space-x-2",
              children: [
                /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\deal-management\\index.jsx:664:22", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "664", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22ArrowLeft%22%7D", name: "ArrowLeft", size: 16 }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                  lineNumber: 664,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\index.jsx:665:22", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "665", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Back%20to%20List%22%7D", children: "Back to List" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                  lineNumber: 665,
                  columnNumber: 23
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
              lineNumber: 660,
              columnNumber: 21
            },
            this
          ),
          selectedDeal?.id && /* @__PURE__ */ jsxDEV(
            DealActions,
            {
              "data-component-id": "src\\pages\\deal-management\\index.jsx:668:18",
              "data-component-path": "src\\pages\\deal-management\\index.jsx",
              "data-component-line": "668",
              "data-component-file": "index.jsx",
              "data-component-name": "DealActions",
              "data-component-content": "%7B%22elementName%22%3A%22DealActions%22%7D",
              onSave: () => handleSaveDeal(selectedDeal),
              onDelete: () => setShowDeleteModal(true),
              onClone: handleCloneDeal,
              onCreateTask: handleCreateTask,
              isSaving
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
              lineNumber: 668,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
          lineNumber: 659,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
          lineNumber: 649,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
        lineNumber: 619,
        columnNumber: 13
      }, this),
      isListView ? (
        // Deals List View
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:684:12", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "684", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20rounded-lg%20border%20border-border%22%7D", className: "bg-surface rounded-lg border border-border", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:685:16", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "685", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22p-6%20border-b%20border-border%22%7D", className: "p-6 border-b border-border", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:686:18", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "686", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("h2", { "data-component-id": "src\\pages\\deal-management\\index.jsx:687:20", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "687", "data-component-file": "index.jsx", "data-component-name": "h2", "data-component-content": "%7B%22elementName%22%3A%22h2%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%2C%22textContent%22%3A%22All%20Deals%22%7D", className: "text-lg font-semibold text-text-primary", children: "All Deals" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                lineNumber: 687,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:688:20", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "688", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-4%22%7D", className: "flex items-center space-x-4", children: [
                /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:690:22", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "690", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20bg-gray-100%20rounded-lg%20p-1%22%7D", className: "flex items-center bg-gray-100 rounded-lg p-1", children: [
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      "data-component-id": "src\\pages\\deal-management\\index.jsx:691:24",
                      "data-component-path": "src\\pages\\deal-management\\index.jsx",
                      "data-component-line": "691",
                      "data-component-file": "index.jsx",
                      "data-component-name": "button",
                      "data-component-content": "%7B%22elementName%22%3A%22button%22%7D",
                      onClick: () => setIsGridView(false),
                      className: `flex items-center space-x-1 px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${!isGridView ? "bg-white text-primary shadow-sm" : "text-gray-600 hover:text-gray-900"}`,
                      children: [
                        /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\deal-management\\index.jsx:699:26", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "699", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22List%22%7D", name: "List", size: 16 }, void 0, false, {
                          fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                          lineNumber: 699,
                          columnNumber: 27
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\index.jsx:700:26", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "700", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22List%22%7D", children: "List" }, void 0, false, {
                          fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                          lineNumber: 700,
                          columnNumber: 27
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                      lineNumber: 691,
                      columnNumber: 25
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      "data-component-id": "src\\pages\\deal-management\\index.jsx:702:24",
                      "data-component-path": "src\\pages\\deal-management\\index.jsx",
                      "data-component-line": "702",
                      "data-component-file": "index.jsx",
                      "data-component-name": "button",
                      "data-component-content": "%7B%22elementName%22%3A%22button%22%7D",
                      onClick: () => setIsGridView(true),
                      className: `flex items-center space-x-1 px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${isGridView ? "bg-white text-primary shadow-sm" : "text-gray-600 hover:text-gray-900"}`,
                      children: [
                        /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\deal-management\\index.jsx:710:26", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "710", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Grid%22%7D", name: "Grid", size: 16 }, void 0, false, {
                          fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                          lineNumber: 710,
                          columnNumber: 27
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\index.jsx:711:26", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "711", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Grid%22%7D", children: "Grid" }, void 0, false, {
                          fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                          lineNumber: 711,
                          columnNumber: 27
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                      lineNumber: 702,
                      columnNumber: 25
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                  lineNumber: 690,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:714:22", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "714", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22deal%22%7D", className: "text-sm text-text-secondary", children: [
                  filteredDeals.length,
                  " deal",
                  filteredDeals.length !== 1 ? "s" : "",
                  selectedStageFilter !== "all" && ` (${allDeals.length} total)`
                ] }, void 0, true, {
                  fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                  lineNumber: 714,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                lineNumber: 688,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
              lineNumber: 686,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:722:18", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "722", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22mt-4%22%7D", className: "mt-4", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:723:20", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "723", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20flex-wrap%20gap-2%22%7D", className: "flex flex-wrap gap-2", children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  "data-component-id": "src\\pages\\deal-management\\index.jsx:724:22",
                  "data-component-path": "src\\pages\\deal-management\\index.jsx",
                  "data-component-line": "724",
                  "data-component-file": "index.jsx",
                  "data-component-name": "button",
                  "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22textContent%22%3A%22All%20Stages%20(%20)%22%7D",
                  onClick: () => setSelectedStageFilter("all"),
                  className: `px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${selectedStageFilter === "all" ? "bg-primary text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`,
                  children: [
                    "All Stages (",
                    allDeals.length,
                    ")"
                  ]
                },
                void 0,
                true,
                {
                  fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                  lineNumber: 724,
                  columnNumber: 23
                },
                this
              ),
              stages.map((stage) => {
                const stageCount = allDeals.filter((deal) => deal.stage === stage.value).length;
                return /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    "data-component-id": "src\\pages\\deal-management\\index.jsx:737:24",
                    "data-component-path": "src\\pages\\deal-management\\index.jsx",
                    "data-component-line": "737",
                    "data-component-file": "index.jsx",
                    "data-component-name": "button",
                    "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22textContent%22%3A%22(%20)%22%7D",
                    onClick: () => setSelectedStageFilter(stage.value),
                    className: `px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${selectedStageFilter === stage.value ? "bg-primary text-white" : `${stage.color} hover:opacity-80`}`,
                    children: [
                      stage.label,
                      " (",
                      stageCount,
                      ")"
                    ]
                  },
                  stage.value,
                  true,
                  {
                    fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                    lineNumber: 737,
                    columnNumber: 25
                  },
                  this
                );
              })
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
              lineNumber: 723,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
              lineNumber: 722,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
            lineNumber: 685,
            columnNumber: 17
          }, this),
          isLoading ? /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:755:14", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "755", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22p-8%20text-center%22%7D", className: "p-8 text-center", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:756:20", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "756", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22animate-spin%20rounded-full%20h-8%20w-8%20border-b-2%20border-primary%20mx-auto%20mb-4%22%7D", className: "animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
              lineNumber: 756,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\deal-management\\index.jsx:757:20", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "757", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%22%2C%22textContent%22%3A%22Loading%20deals...%22%7D", className: "text-text-secondary", children: "Loading deals..." }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
              lineNumber: 757,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
            lineNumber: 755,
            columnNumber: 15
          }, this) : filteredDeals.length === 0 ? /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:760:14", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "760", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22p-8%20text-center%22%7D", className: "p-8 text-center", children: [
            /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\deal-management\\index.jsx:761:20", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "761", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Package%22%2C%22className%22%3A%22text-text-tertiary%20mx-auto%20mb-4%22%7D", name: "Package", size: 48, className: "text-text-tertiary mx-auto mb-4" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
              lineNumber: 761,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\deal-management\\index.jsx:762:20", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "762", "data-component-file": "index.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-medium%20text-text-primary%20mb-2%22%7D", className: "text-lg font-medium text-text-primary mb-2", children: selectedStageFilter === "all" ? "No deals yet" : `No deals in ${stages.find((s) => s.value === selectedStageFilter)?.label} stage` }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
              lineNumber: 762,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\deal-management\\index.jsx:765:20", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "765", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20mb-4%22%7D", className: "text-text-secondary mb-4", children: selectedStageFilter === "all" ? "Create your first deal to get started" : "Try selecting a different stage or create a new deal" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
              lineNumber: 765,
              columnNumber: 21
            }, this),
            selectedStageFilter === "all" && /* @__PURE__ */ jsxDEV(
              "button",
              {
                "data-component-id": "src\\pages\\deal-management\\index.jsx:772:16",
                "data-component-path": "src\\pages\\deal-management\\index.jsx",
                "data-component-line": "772",
                "data-component-file": "index.jsx",
                "data-component-name": "button",
                "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22btn-primary%22%2C%22textContent%22%3A%22Create%20Deal%22%7D",
                onClick: handleCreateNewDeal,
                className: "btn-primary",
                children: "Create Deal"
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                lineNumber: 772,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
            lineNumber: 760,
            columnNumber: 15
          }, this) : isGridView ? /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:781:14", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "781", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22p-6%22%7D", className: "p-6", children: /* @__PURE__ */ jsxDEV(
            DealsGridView,
            {
              "data-component-id": "src\\pages\\deal-management\\index.jsx:782:20",
              "data-component-path": "src\\pages\\deal-management\\index.jsx",
              "data-component-line": "782",
              "data-component-file": "index.jsx",
              "data-component-name": "DealsGridView",
              "data-component-content": "%7B%22elementName%22%3A%22DealsGridView%22%7D",
              deals: filteredDeals,
              stages,
              onEditDeal: handleEditDeal
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
              lineNumber: 782,
              columnNumber: 21
            },
            this
          ) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
            lineNumber: 781,
            columnNumber: 15
          }, this) : /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:789:14", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "789", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22overflow-x-auto%22%7D", className: "overflow-x-auto", children: /* @__PURE__ */ jsxDEV("table", { "data-component-id": "src\\pages\\deal-management\\index.jsx:790:20", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "790", "data-component-file": "index.jsx", "data-component-name": "table", "data-component-content": "%7B%22elementName%22%3A%22table%22%2C%22className%22%3A%22w-full%22%7D", className: "w-full", children: [
            /* @__PURE__ */ jsxDEV("thead", { "data-component-id": "src\\pages\\deal-management\\index.jsx:791:22", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "791", "data-component-file": "index.jsx", "data-component-name": "thead", "data-component-content": "%7B%22elementName%22%3A%22thead%22%2C%22className%22%3A%22bg-gray-50%22%7D", className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { "data-component-id": "src\\pages\\deal-management\\index.jsx:792:24", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "792", "data-component-file": "index.jsx", "data-component-name": "tr", "data-component-content": "%7B%22elementName%22%3A%22tr%22%7D", children: [
              /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\deal-management\\index.jsx:793:26", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "793", "data-component-file": "index.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22px-6%20py-3%20text-left%20text-xs%20font-medium%20text-text-secondary%20uppercase%20tracking-wider%22%2C%22textContent%22%3A%22Deal%22%7D", className: "px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider", children: "Deal" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                lineNumber: 793,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\deal-management\\index.jsx:794:26", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "794", "data-component-file": "index.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22px-6%20py-3%20text-left%20text-xs%20font-medium%20text-text-secondary%20uppercase%20tracking-wider%22%2C%22textContent%22%3A%22Stage%22%7D", className: "px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider", children: "Stage" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                lineNumber: 794,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\deal-management\\index.jsx:795:26", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "795", "data-component-file": "index.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22px-6%20py-3%20text-left%20text-xs%20font-medium%20text-text-secondary%20uppercase%20tracking-wider%22%2C%22textContent%22%3A%22Value%22%7D", className: "px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider", children: "Value" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                lineNumber: 795,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\deal-management\\index.jsx:796:26", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "796", "data-component-file": "index.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22px-6%20py-3%20text-left%20text-xs%20font-medium%20text-text-secondary%20uppercase%20tracking-wider%22%2C%22textContent%22%3A%22Probability%22%7D", className: "px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider", children: "Probability" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                lineNumber: 796,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\deal-management\\index.jsx:797:26", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "797", "data-component-file": "index.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22px-6%20py-3%20text-left%20text-xs%20font-medium%20text-text-secondary%20uppercase%20tracking-wider%22%2C%22textContent%22%3A%22Created%22%7D", className: "px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider", children: "Created" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                lineNumber: 797,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\deal-management\\index.jsx:798:26", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "798", "data-component-file": "index.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22px-6%20py-3%20text-right%20text-xs%20font-medium%20text-text-secondary%20uppercase%20tracking-wider%22%2C%22textContent%22%3A%22Actions%22%7D", className: "px-6 py-3 text-right text-xs font-medium text-text-secondary uppercase tracking-wider", children: "Actions" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                lineNumber: 798,
                columnNumber: 27
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
              lineNumber: 792,
              columnNumber: 25
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
              lineNumber: 791,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("tbody", { "data-component-id": "src\\pages\\deal-management\\index.jsx:801:22", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "801", "data-component-file": "index.jsx", "data-component-name": "tbody", "data-component-content": "%7B%22elementName%22%3A%22tbody%22%2C%22className%22%3A%22bg-white%20divide-y%20divide-border%22%7D", className: "bg-white divide-y divide-border", children: filteredDeals.map(
              (deal) => /* @__PURE__ */ jsxDEV("tr", { "data-component-id": "src\\pages\\deal-management\\index.jsx:803:20", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "803", "data-component-file": "index.jsx", "data-component-name": "tr", "data-component-content": "%7B%22elementName%22%3A%22tr%22%2C%22className%22%3A%22hover%3Abg-gray-50%22%7D", className: "hover:bg-gray-50", children: [
                /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\deal-management\\index.jsx:804:28", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "804", "data-component-file": "index.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22px-6%20py-4%20whitespace-nowrap%22%7D", className: "px-6 py-4 whitespace-nowrap", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:805:30", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "805", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
                  /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:806:32", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "806", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-sm%20font-medium%20text-text-primary%22%7D", className: "text-sm font-medium text-text-primary", children: deal.name || "Untitled Deal" }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                    lineNumber: 806,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:807:32", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "807", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-sm%20text-text-secondary%20truncate%20max-w-xs%22%7D", className: "text-sm text-text-secondary truncate max-w-xs", children: deal.description || "No description" }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                    lineNumber: 807,
                    columnNumber: 33
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                  lineNumber: 805,
                  columnNumber: 31
                }, this) }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                  lineNumber: 804,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\deal-management\\index.jsx:810:28", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "810", "data-component-file": "index.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22px-6%20py-4%20whitespace-nowrap%22%7D", className: "px-6 py-4 whitespace-nowrap", children: /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\index.jsx:811:30", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "811", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", className: `px-2 py-1 text-xs font-medium rounded-full ${stages.find((s) => s.value === deal.stage)?.color || "bg-gray-100 text-gray-800"}`, children: stages.find((s) => s.value === deal.stage)?.label || deal.stage }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                  lineNumber: 811,
                  columnNumber: 31
                }, this) }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                  lineNumber: 810,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\deal-management\\index.jsx:817:28", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "817", "data-component-file": "index.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22px-6%20py-4%20whitespace-nowrap%20text-sm%20text-text-primary%22%2C%22textContent%22%3A%22%24%22%7D", className: "px-6 py-4 whitespace-nowrap text-sm text-text-primary", children: [
                  "$",
                  (deal.value || 0).toLocaleString()
                ] }, void 0, true, {
                  fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                  lineNumber: 817,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\deal-management\\index.jsx:820:28", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "820", "data-component-file": "index.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22px-6%20py-4%20whitespace-nowrap%20text-sm%20text-text-primary%22%2C%22textContent%22%3A%22%25%22%7D", className: "px-6 py-4 whitespace-nowrap text-sm text-text-primary", children: [
                  deal.probability || 0,
                  "%"
                ] }, void 0, true, {
                  fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                  lineNumber: 820,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\deal-management\\index.jsx:823:28", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "823", "data-component-file": "index.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22px-6%20py-4%20whitespace-nowrap%20text-sm%20text-text-secondary%22%7D", className: "px-6 py-4 whitespace-nowrap text-sm text-text-secondary", children: new Date(deal.created_at).toLocaleDateString() }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                  lineNumber: 823,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\deal-management\\index.jsx:826:28", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "826", "data-component-file": "index.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22px-6%20py-4%20whitespace-nowrap%20text-right%20text-sm%20font-medium%22%7D", className: "px-6 py-4 whitespace-nowrap text-right text-sm font-medium", children: /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    "data-component-id": "src\\pages\\deal-management\\index.jsx:827:30",
                    "data-component-path": "src\\pages\\deal-management\\index.jsx",
                    "data-component-line": "827",
                    "data-component-file": "index.jsx",
                    "data-component-name": "button",
                    "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22text-primary%20hover%3Atext-primary-600%20mr-3%22%2C%22textContent%22%3A%22Edit%22%7D",
                    onClick: () => handleEditDeal(deal),
                    className: "text-primary hover:text-primary-600 mr-3",
                    children: "Edit"
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                    lineNumber: 827,
                    columnNumber: 31
                  },
                  this
                ) }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                  lineNumber: 826,
                  columnNumber: 29
                }, this)
              ] }, deal.id, true, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                lineNumber: 803,
                columnNumber: 21
              }, this)
            ) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
              lineNumber: 801,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
            lineNumber: 790,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
            lineNumber: 789,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
          lineNumber: 684,
          columnNumber: 13
        }, this)
      ) : (
        // Deal Form View - Show loading or form
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:843:12", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "843", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20xl%3Agrid-cols-12%20gap-8%22%7D", className: "grid grid-cols-1 xl:grid-cols-12 gap-8", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:845:16", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "845", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22xl%3Acol-span-8%22%7D", className: "xl:col-span-8", children: isLoading ? /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:847:16", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "847", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20rounded-lg%20border%20border-border%20p-8%22%7D", className: "bg-surface rounded-lg border border-border p-8", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:848:22", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "848", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-center%22%7D", className: "text-center", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:849:24", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "849", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22animate-spin%20rounded-full%20h-8%20w-8%20border-b-2%20border-primary%20mx-auto%20mb-4%22%7D", className: "animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
              lineNumber: 849,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\deal-management\\index.jsx:850:24", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "850", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%22%2C%22textContent%22%3A%22Loading%20deal%20form...%22%7D", className: "text-text-secondary", children: "Loading deal form..." }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
              lineNumber: 850,
              columnNumber: 25
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
            lineNumber: 848,
            columnNumber: 23
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
            lineNumber: 847,
            columnNumber: 17
          }, this) : /* @__PURE__ */ jsxDEV(
            DealForm,
            {
              "data-component-id": "src\\pages\\deal-management\\index.jsx:854:16",
              "data-component-path": "src\\pages\\deal-management\\index.jsx",
              "data-component-line": "854",
              "data-component-file": "index.jsx",
              "data-component-name": "DealForm",
              "data-component-content": "%7B%22elementName%22%3A%22DealForm%22%7D",
              deal: selectedDeal,
              contacts,
              companies,
              stages,
              onSubmit: handleSaveDeal,
              onCancel: handleBackToList,
              isSaving
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
              lineNumber: 854,
              columnNumber: 17
            },
            this
          ) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
            lineNumber: 845,
            columnNumber: 17
          }, this),
          selectedDeal?.id && !isLoading && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:868:14", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "868", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22xl%3Acol-span-4%20space-y-6%22%7D", className: "xl:col-span-4 space-y-6", children: [
            /* @__PURE__ */ jsxDEV(
              ActivityTimeline,
              {
                "data-component-id": "src\\pages\\deal-management\\index.jsx:869:20",
                "data-component-path": "src\\pages\\deal-management\\index.jsx",
                "data-component-line": "869",
                "data-component-file": "index.jsx",
                "data-component-name": "ActivityTimeline",
                "data-component-content": "%7B%22elementName%22%3A%22ActivityTimeline%22%7D",
                activities,
                loading: isLoadingActivities,
                contact: selectedDeal?.contact,
                onAddActivity: handleAddActivity,
                onDeleteActivity: handleDeleteActivity
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                lineNumber: 869,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              DocumentsSection,
              {
                "data-component-id": "src\\pages\\deal-management\\index.jsx:877:20",
                "data-component-path": "src\\pages\\deal-management\\index.jsx",
                "data-component-line": "877",
                "data-component-file": "index.jsx",
                "data-component-name": "DocumentsSection",
                "data-component-content": "%7B%22elementName%22%3A%22DocumentsSection%22%7D",
                documents,
                loading: isLoadingDocuments,
                dealId: selectedDeal?.id,
                onUploadDocument: handleUploadDocument,
                onDeleteDocument: handleDeleteDocument
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
                lineNumber: 877,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
            lineNumber: 868,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
          lineNumber: 843,
          columnNumber: 13
        }, this)
      )
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
      lineNumber: 599,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
      lineNumber: 598,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
      lineNumber: 597,
      columnNumber: 7
    }, this),
    showDeleteModal && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:893:6", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "893", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20bg-black%20bg-opacity-50%20flex%20items-center%20justify-center%20z-50%22%7D", className: "fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:894:10", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "894", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20rounded-lg%20p-6%20max-w-md%20w-full%20mx-4%22%7D", className: "bg-surface rounded-lg p-6 max-w-md w-full mx-4", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:895:12", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "895", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-3%20mb-4%22%7D", className: "flex items-center space-x-3 mb-4", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:896:14", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "896", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-10%20h-10%20bg-error-50%20rounded-full%20flex%20items-center%20justify-center%22%7D", className: "w-10 h-10 bg-error-50 rounded-full flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\deal-management\\index.jsx:897:16", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "897", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22AlertTriangle%22%2C%22className%22%3A%22text-error%22%7D", name: "AlertTriangle", size: 20, className: "text-error" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
          lineNumber: 897,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
          lineNumber: 896,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\deal-management\\index.jsx:899:14", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "899", "data-component-file": "index.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%2C%22textContent%22%3A%22Delete%20Deal%22%7D", className: "text-lg font-semibold text-text-primary", children: "Delete Deal" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
          lineNumber: 899,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
        lineNumber: 895,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\deal-management\\index.jsx:902:12", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "902", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20mb-6%22%2C%22textContent%22%3A%22Are%20you%20sure%20you%20want%20to%20delete%20%5C%22%20%5C%22%3F%20This%20action%20cannot%20be%20undone.%22%7D", className: "text-text-secondary mb-6", children: [
        'Are you sure you want to delete "',
        selectedDeal?.name,
        '"? This action cannot be undone.'
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
        lineNumber: 902,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\index.jsx:906:12", "data-component-path": "src\\pages\\deal-management\\index.jsx", "data-component-line": "906", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20space-x-3%22%7D", className: "flex space-x-3", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\deal-management\\index.jsx:907:14",
            "data-component-path": "src\\pages\\deal-management\\index.jsx",
            "data-component-line": "907",
            "data-component-file": "index.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22flex-1%20px-4%20py-2%20border%20border-border%20rounded-lg%20text-text-secondary%20hover%3Atext-text-primary%20hover%3Abg-surface-hover%20transition-colors%20duration-150%22%2C%22textContent%22%3A%22Cancel%22%7D",
            onClick: () => setShowDeleteModal(false),
            className: "flex-1 px-4 py-2 border border-border rounded-lg text-text-secondary hover:text-text-primary hover:bg-surface-hover transition-colors duration-150",
            children: "Cancel"
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
            lineNumber: 907,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\deal-management\\index.jsx:913:14",
            "data-component-path": "src\\pages\\deal-management\\index.jsx",
            "data-component-line": "913",
            "data-component-file": "index.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22flex-1%20px-4%20py-2%20bg-error%20text-white%20rounded-lg%20hover%3Abg-error-600%20transition-colors%20duration-150%22%2C%22textContent%22%3A%22Delete%20Deal%22%7D",
            onClick: handleDeleteDeal,
            className: "flex-1 px-4 py-2 bg-error text-white rounded-lg hover:bg-error-600 transition-colors duration-150",
            children: "Delete Deal"
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
            lineNumber: 913,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
        lineNumber: 906,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
      lineNumber: 894,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
      lineNumber: 893,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/deal-management/index.jsx",
    lineNumber: 595,
    columnNumber: 5
  }, this);
};
_s(DealManagement, "DaMhHXamrzd7iPp5KPw354Wg+ns=", false, function() {
  return [useParams, useNavigate, useAuth];
});
_c = DealManagement;
export default DealManagement;
var _c;
$RefreshReg$(_c, "DealManagement");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/deal-management/index.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/deal-management/index.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOGhCUSxTQXVGZ0IsVUF2RmhCOzJCQTloQlI7QUFBZ0JBLE1BQVVDLGNBQVdDLE9BQVcsc0JBQWU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDL0QsU0FBU0MsV0FBV0MsbUJBQW1CO0FBQ3ZDLE9BQU9DLFdBQVc7QUFDbEIsU0FBU0MsZUFBZTtBQUN4QixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGdCQUFnQjtBQUN2QixPQUFPQyxVQUFVO0FBRWpCLE9BQU9DLGNBQWM7QUFDckIsT0FBT0Msc0JBQXNCO0FBQzdCLE9BQU9DLHNCQUFzQjtBQUM3QixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0MsbUJBQW1CO0FBRTFCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxxQkFBcUI7QUFDNUIsT0FBT0Msc0JBQXNCO0FBQzdCLE9BQU9DLDJCQUEyQjtBQUNsQyxPQUFPQywwQkFBMEI7QUFFakMsTUFBTUMsaUJBQWlCQSxNQUFNO0FBQUFDLEtBQUE7QUFDM0IsUUFBTSxFQUFFQyxPQUFPLElBQUluQixVQUFVO0FBQzdCLFFBQU1vQixXQUFXbkIsWUFBWTtBQUM3QixRQUFNLEVBQUVvQixLQUFLLElBQUlsQixRQUFRO0FBR3pCLFFBQU0sQ0FBQ21CLGNBQWNDLGVBQWUsSUFBSTFCLFNBQVMsSUFBSTtBQUNyRCxRQUFNLENBQUMyQixVQUFVQyxXQUFXLElBQUk1QixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDNkIsVUFBVUMsV0FBVyxJQUFJOUIsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQytCLFdBQVdDLFlBQVksSUFBSWhDLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNpQyxZQUFZQyxhQUFhLElBQUlsQyxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDbUMsV0FBV0MsWUFBWSxJQUFJcEMsU0FBUyxFQUFFO0FBRzdDLFFBQU0sQ0FBQ3FDLFVBQVVDLFdBQVcsSUFBSXRDLFNBQVMsS0FBSztBQUM5QyxRQUFNLENBQUN1QyxZQUFZQyxhQUFhLElBQUl4QyxTQUFTLElBQUk7QUFDakQsUUFBTSxDQUFDeUMsWUFBWUMsYUFBYSxJQUFJMUMsU0FBUyxLQUFLO0FBR2xELFFBQU0sQ0FBQzJDLFdBQVdDLFlBQVksSUFBSTVDLFNBQVMsSUFBSTtBQUMvQyxRQUFNLENBQUM2QyxVQUFVQyxXQUFXLElBQUk5QyxTQUFTLEtBQUs7QUFDOUMsUUFBTSxDQUFDK0MscUJBQXFCQyxzQkFBc0IsSUFBSWhELFNBQVMsS0FBSztBQUNwRSxRQUFNLENBQUNpRCxvQkFBb0JDLHFCQUFxQixJQUFJbEQsU0FBUyxLQUFLO0FBR2xFLFFBQU0sQ0FBQ21ELE9BQU9DLFFBQVEsSUFBSXBELFNBQVMsSUFBSTtBQUN2QyxRQUFNLENBQUNxRCxpQkFBaUJDLGtCQUFrQixJQUFJdEQsU0FBUyxLQUFLO0FBRzVELFFBQU0sQ0FBQ3VELHFCQUFxQkMsc0JBQXNCLElBQUl4RCxTQUFTLEtBQUs7QUFHcEUsUUFBTSxDQUFDeUQsaUJBQWlCQyxrQkFBa0IsSUFBSTFELFNBQVMsSUFBSTtBQUMzRCxRQUFNLENBQUMyRCxpQkFBaUJDLGtCQUFrQixJQUFJNUQsU0FBUyxJQUFJO0FBRzNELFFBQU02RCxTQUFTO0FBQUEsSUFDYixFQUFFQyxPQUFPLFFBQVFDLE9BQU8sUUFBUUMsT0FBTyw0QkFBNEI7QUFBQSxJQUNuRSxFQUFFRixPQUFPLGFBQWFDLE9BQU8sYUFBYUMsT0FBTyw0QkFBNEI7QUFBQSxJQUM3RSxFQUFFRixPQUFPLFlBQVlDLE9BQU8sWUFBWUMsT0FBTyxnQ0FBZ0M7QUFBQSxJQUMvRSxFQUFFRixPQUFPLGVBQWVDLE9BQU8sZUFBZUMsT0FBTyxnQ0FBZ0M7QUFBQSxJQUNyRixFQUFFRixPQUFPLGNBQWNDLE9BQU8sY0FBY0MsT0FBTyw4QkFBOEI7QUFBQSxJQUNqRixFQUFFRixPQUFPLGVBQWVDLE9BQU8sZUFBZUMsT0FBTywwQkFBMEI7QUFBQSxFQUFDO0FBSWxGLFFBQU1DLGdCQUFnQlYsd0JBQXdCLFFBQzFDNUIsV0FDQUEsU0FBU3VDLE9BQU8sQ0FBQUMsU0FBUUEsS0FBS0MsVUFBVWIsbUJBQW1CO0FBRzlEdEQsWUFBVSxNQUFNO0FBRWQsUUFBSSxDQUFDdUI7QUFBTTtBQUVYLFVBQU02QyxrQkFBa0IsWUFBWTtBQUVsQ3pCLG1CQUFhLElBQUk7QUFDakJRLGVBQVMsSUFBSTtBQUViLFVBQUk7QUFFRixjQUFNLENBQUNrQixXQUFXQyxjQUFjQyxhQUFhLElBQUksTUFBTUMsUUFBUUM7QUFBQUEsVUFBSTtBQUFBLFlBQ2pFM0QsY0FBYzRELGFBQWE7QUFBQSxZQUMzQjNELGlCQUFpQjRELGdCQUFnQjtBQUFBLFlBQ2pDM0Qsa0JBQWtCNEQsZ0JBQWdCO0FBQUEsVUFBQztBQUFBLFFBQ3BDO0FBSURqRCxvQkFBWTBDLGFBQWEsRUFBRTtBQUMzQnhDLG9CQUFZeUMsZ0JBQWdCLEVBQUU7QUFDOUJ2QyxxQkFBYXdDLGlCQUFpQixFQUFFO0FBR2hDLFlBQUlsRCxVQUFVQSxXQUFXLE9BQU87QUFFOUJrQix3QkFBYyxLQUFLO0FBQ25CRixzQkFBWSxJQUFJO0FBQ2hCLGdCQUFNd0MsU0FBU3hELE1BQU07QUFBQSxRQUN2QixXQUFXQSxXQUFXLE9BQU87QUFFM0JrQix3QkFBYyxLQUFLO0FBQ25CRixzQkFBWSxJQUFJO0FBQ2hCWiwwQkFBZ0IsSUFBSTtBQUFBLFFBQ3RCLE9BQU87QUFFTGMsd0JBQWMsSUFBSTtBQUNsQkYsc0JBQVksS0FBSztBQUFBLFFBQ25CO0FBQUEsTUFFRixTQUFTeUMsS0FBSztBQUNaQyxnQkFBUTdCLE1BQU0sK0JBQStCNEIsR0FBRztBQUNoRDNCLGlCQUFTLCtDQUErQztBQUFBLE1BQzFELFVBQUM7QUFDQ1IscUJBQWEsS0FBSztBQUFBLE1BRXBCO0FBQUEsSUFDRjtBQUVBeUIsb0JBQWdCO0FBQUEsRUFDbEIsR0FBRyxDQUFDL0MsUUFBUUUsSUFBSSxDQUFDO0FBR2pCLFFBQU1zRCxXQUFXLE9BQU9HLE9BQU87QUFDN0IsUUFBSTtBQUNGLFlBQU1DLFdBQVcsTUFBTW5FLGNBQWNvRSxZQUFZRixFQUFFO0FBQ25ELFVBQUksQ0FBQ0MsVUFBVTtBQUNiOUIsaUJBQVMsZ0JBQWdCO0FBQ3pCUixxQkFBYSxLQUFLO0FBQ2xCO0FBQUEsTUFDRjtBQUVBbEIsc0JBQWdCd0QsUUFBUTtBQUd4QixZQUFNVCxRQUFRQztBQUFBQSxRQUFJO0FBQUEsVUFDaEJVLGVBQWVILEVBQUU7QUFBQSxVQUNqQkksY0FBY0osRUFBRTtBQUFBLFFBQUM7QUFBQSxNQUNsQjtBQUdESyxpQ0FBMkJMLEVBQUU7QUFBQSxJQUUvQixTQUFTRixLQUFLO0FBQ1pDLGNBQVE3QixNQUFNLHVCQUF1QjRCLEdBQUc7QUFHeEMsVUFBSUEsS0FBS1EsU0FBUyxjQUFjUixLQUFLUyxTQUFTQyxTQUFTLFdBQVcsR0FBRztBQUNuRXJDLGlCQUFTLHFGQUFxRjtBQUFBLE1BQ2hHLFdBQVcyQixLQUFLUyxTQUFTRSxZQUFZLEVBQUVELFNBQVMsWUFBWSxLQUFLVixLQUFLUyxTQUFTRSxZQUFZLEVBQUVELFNBQVMsUUFBUSxHQUFHO0FBQy9HckMsaUJBQVMsK0RBQStEO0FBQUEsTUFDMUUsV0FBVzJCLEtBQUtTLFNBQVNDLFNBQVMsU0FBUyxLQUFLVixLQUFLUyxTQUFTQyxTQUFTLGNBQWMsR0FBRztBQUN0RnJDLGlCQUFTLHFHQUFxRztBQUFBLE1BQ2hILE9BQU87QUFDTEEsaUJBQVMsd0NBQXdDO0FBQUEsTUFDbkQ7QUFBQSxJQUNGLFVBQUM7QUFDQ1IsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUdBLFFBQU13QyxpQkFBaUIsT0FBT0gsT0FBTztBQUNuQ2pDLDJCQUF1QixJQUFJO0FBQzNCLFFBQUk7QUFDRixZQUFNMkMsaUJBQWlCLE1BQU16RSx1QkFBdUIwRSxrQkFBa0JYLEVBQUU7QUFDeEUvQyxvQkFBY3lELGtCQUFrQixFQUFFO0FBQUEsSUFDcEMsU0FBU1osS0FBSztBQUNaQyxjQUFRN0IsTUFBTSw2QkFBNkI0QixHQUFHO0FBQUEsSUFDaEQsVUFBQztBQUNDL0IsNkJBQXVCLEtBQUs7QUFBQSxJQUM5QjtBQUFBLEVBQ0Y7QUFHQSxRQUFNcUMsZ0JBQWdCLE9BQU9KLE9BQU87QUFDbEMvQiwwQkFBc0IsSUFBSTtBQUMxQixRQUFJO0FBQ0YsWUFBTTJDLGdCQUFnQixNQUFNMUUsc0JBQXNCMkUsaUJBQWlCYixFQUFFO0FBQ3JFN0MsbUJBQWF5RCxpQkFBaUIsRUFBRTtBQUFBLElBQ2xDLFNBQVNkLEtBQUs7QUFDWkMsY0FBUTdCLE1BQU0sNEJBQTRCNEIsR0FBRztBQUFBLElBQy9DLFVBQUM7QUFDQzdCLDRCQUFzQixLQUFLO0FBQUEsSUFDN0I7QUFBQSxFQUNGO0FBR0EsUUFBTW9DLDZCQUE2QkEsQ0FBQ0wsT0FBTztBQUV6QyxVQUFNYyxjQUFjN0UsdUJBQXVCOEUsMkJBQTJCZixJQUFJLENBQUNnQixZQUFZO0FBQ3JGQywyQkFBcUJELE9BQU87QUFBQSxJQUM5QixDQUFDO0FBQ0R2Qyx1QkFBbUJxQyxXQUFXO0FBRzlCLFVBQU1JLGNBQWNoRixzQkFBc0JpRiwyQkFBMkJuQixJQUFJLENBQUNnQixZQUFZO0FBQ3BGSSwyQkFBcUJKLE9BQU87QUFBQSxJQUM5QixDQUFDO0FBQ0RyQyx1QkFBbUJ1QyxXQUFXO0FBQUEsRUFDaEM7QUFHQSxRQUFNRCx1QkFBdUJoRyxZQUFZLENBQUMrRixZQUFZO0FBQ3BELFVBQU0sRUFBRUssV0FBV0MsS0FBS0MsV0FBV0MsS0FBS0MsVUFBVSxJQUFJVDtBQUV0RC9ELGtCQUFjLENBQUF5RSxTQUFRO0FBQ3BCLGNBQVFMLFdBQVM7QUFBQSxRQUNmLEtBQUs7QUFFSCxnQkFBTU0sY0FBYztBQUFBLFlBQ2xCM0IsSUFBSXVCLFdBQVd2QjtBQUFBQSxZQUNmNEIsTUFBTUwsV0FBV0s7QUFBQUEsWUFDakJDLE9BQU9OLFdBQVdPO0FBQUFBLFlBQ2xCQyxhQUFhUixXQUFXUTtBQUFBQSxZQUN4QkMsV0FBV1QsV0FBV1U7QUFBQUEsWUFDdEIxRixNQUFNO0FBQUE7QUFBQSxZQUNORixRQUFRa0YsV0FBV1c7QUFBQUEsVUFDckI7QUFDQSxpQkFBTyxDQUFDUCxhQUFhLEdBQUdELElBQUk7QUFBQSxRQUU5QixLQUFLO0FBQ0gsaUJBQU9BLE1BQU16QyxPQUFPLENBQUFrRCxhQUFZQSxVQUFVbkMsT0FBT3lCLFdBQVd6QixFQUFFO0FBQUEsUUFFaEUsS0FBSztBQUNILGlCQUFPMEIsTUFBTVU7QUFBQUEsWUFBSSxDQUFBRCxhQUNmQSxVQUFVbkMsT0FBT3VCLFdBQVd2QixLQUN4QixFQUFFLEdBQUdtQyxVQUFVLEdBQUdaLFVBQVUsSUFDNUJZO0FBQUFBLFVBQ047QUFBQSxRQUVGO0FBQ0UsaUJBQU9UO0FBQUFBLE1BQ1g7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNILEdBQUcsRUFBRTtBQUdMLFFBQU1OLHVCQUF1Qm5HLFlBQVksQ0FBQytGLFlBQVk7QUFDcEQsVUFBTSxFQUFFSyxXQUFXQyxLQUFLQyxXQUFXQyxLQUFLQyxVQUFVLElBQUlUO0FBRXREN0QsaUJBQWEsQ0FBQXVFLFNBQVE7QUFDbkIsY0FBUUwsV0FBUztBQUFBLFFBQ2YsS0FBSztBQUVILGdCQUFNZ0IsY0FBYztBQUFBLFlBQ2xCckMsSUFBSXVCLFdBQVd2QjtBQUFBQSxZQUNmc0MsTUFBTWYsV0FBV2U7QUFBQUEsWUFDakJDLE1BQU1yRyxzQkFBc0JzRyxlQUFlakIsV0FBV2tCLFNBQVM7QUFBQSxZQUMvRGIsTUFBTTFGLHNCQUFzQndHLGlCQUFpQm5CLFdBQVdlLElBQUk7QUFBQSxZQUM1REssWUFBWXBCLFdBQVdVO0FBQUFBLFlBQ3ZCVyxZQUFZO0FBQUE7QUFBQSxZQUNadkcsUUFBUWtGLFdBQVdXO0FBQUFBLFlBQ25CVyxTQUFTdEIsV0FBV3VCO0FBQUFBLFVBQ3RCO0FBQ0EsaUJBQU8sQ0FBQ1QsYUFBYSxHQUFHWCxJQUFJO0FBQUEsUUFFOUIsS0FBSztBQUNILGlCQUFPQSxNQUFNekMsT0FBTyxDQUFBOEQsUUFBT0EsS0FBSy9DLE9BQU95QixXQUFXekIsRUFBRTtBQUFBLFFBRXREO0FBQ0UsaUJBQU8wQjtBQUFBQSxNQUNYO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSCxHQUFHLEVBQUU7QUFHTDFHLFlBQVUsTUFBTTtBQUNkLFdBQU8sTUFBTTtBQUNYLFVBQUl3RCxpQkFBaUI7QUFDbkJ2QywrQkFBdUIrRywrQkFBK0J4RSxlQUFlO0FBQUEsTUFDdkU7QUFDQSxVQUFJRSxpQkFBaUI7QUFDbkJ4Qyw4QkFBc0IrRywrQkFBK0J2RSxlQUFlO0FBQUEsTUFDdEU7QUFBQSxJQUNGO0FBQUEsRUFDRixHQUFHLENBQUNGLGlCQUFpQkUsZUFBZSxDQUFDO0FBR3JDLFFBQU13RSxzQkFBc0JBLE1BQU07QUFDaEN6RyxvQkFBZ0IsSUFBSTtBQUNwQlksZ0JBQVksSUFBSTtBQUNoQkUsa0JBQWMsS0FBSztBQUNuQmpCLGFBQVMsc0JBQXNCO0FBQUEsRUFDakM7QUFHQSxRQUFNNkcsaUJBQWlCQSxDQUFDakUsU0FBUztBQUMvQnpDLG9CQUFnQnlDLElBQUk7QUFDcEI3QixnQkFBWSxJQUFJO0FBQ2hCRSxrQkFBYyxLQUFLO0FBQ25CakIsYUFBUyxvQkFBb0I0QyxLQUFLYyxFQUFFLEVBQUU7QUFBQSxFQUN4QztBQUdBLFFBQU1vRCxtQkFBbUJBLE1BQU07QUFDN0IvRixnQkFBWSxLQUFLO0FBQ2pCRSxrQkFBYyxJQUFJO0FBQ2xCZCxvQkFBZ0IsSUFBSTtBQUNwQjBCLGFBQVMsSUFBSTtBQUNiN0IsYUFBUyxrQkFBa0I7QUFBQSxFQUU3QjtBQUdBLFFBQU0rRyxlQUFlLFlBQVk7QUFDL0IsUUFBSTtBQUNGLFlBQU1oRSxZQUFZLE1BQU12RCxjQUFjNEQsYUFBYTtBQUNuRC9DLGtCQUFZMEMsYUFBYSxFQUFFO0FBQUEsSUFDN0IsU0FBU1MsS0FBSztBQUNaQyxjQUFRN0IsTUFBTSx3QkFBd0I0QixHQUFHO0FBQUEsSUFDM0M7QUFBQSxFQUNGO0FBR0EsUUFBTXdELGlCQUFpQixPQUFPckQsYUFBYTtBQUN6QyxRQUFJLENBQUMxRCxNQUFNeUQsSUFBSTtBQUNiN0IsZUFBUyxxQ0FBcUM7QUFDOUM7QUFBQSxJQUNGO0FBRUFOLGdCQUFZLElBQUk7QUFDaEJNLGFBQVMsSUFBSTtBQUViLFFBQUk7QUFDRixVQUFJb0Y7QUFFSixVQUFJL0csY0FBY3dELElBQUk7QUFFcEJ1RCxpQkFBUyxNQUFNekgsY0FBYzBILFdBQVdoSCxjQUFjd0QsSUFBSTtBQUFBLFVBQ3hELEdBQUdDO0FBQUFBLFVBQ0h3RCxVQUFVbEgsTUFBTXlEO0FBQUFBLFFBQ2xCLENBQUM7QUFFRCxZQUFJdUQsUUFBUTtBQUNWOUcsMEJBQWdCOEcsTUFBTTtBQUV0QjVHLHNCQUFZLENBQUErRSxTQUFRQSxLQUFLVTtBQUFBQSxZQUFJLENBQUFsRCxTQUMzQkEsS0FBS2MsT0FBT3VELE9BQU92RCxLQUFLdUQsU0FBU3JFO0FBQUFBLFVBQ25DLENBQUM7QUFHRDlELGdCQUFNc0ksUUFBUSxTQUFTSCxPQUFPakIsUUFBUSxlQUFlLHlCQUF5QjtBQUFBLFFBQ2hGO0FBQUEsTUFDRixPQUFPO0FBRUxpQixpQkFBUyxNQUFNekgsY0FBYzZILFdBQVc7QUFBQSxVQUN0QyxHQUFHMUQ7QUFBQUEsVUFDSHdELFVBQVVsSCxNQUFNeUQ7QUFBQUEsUUFDbEIsQ0FBQztBQUVELFlBQUl1RCxRQUFRdkQsSUFBSTtBQUVkNUUsZ0JBQU1zSSxRQUFRLFNBQVN6RCxTQUFTcUMsUUFBUSxlQUFlLHlCQUF5QjtBQUdoRjNGLHNCQUFZLENBQUErRSxTQUFRLENBQUM2QixRQUFRLEdBQUc3QixJQUFJLENBQUM7QUFBQSxRQUN2QyxPQUFPO0FBQ0wsZ0JBQU0sSUFBSWtDLE1BQU0saUNBQWlDO0FBQUEsUUFDbkQ7QUFBQSxNQUNGO0FBR0EsVUFBSSxDQUFDcEgsY0FBY3dELElBQUk7QUFFckJuQyxvQkFBWSxLQUFLO0FBQ2pCdUYseUJBQWlCO0FBQ2pCO0FBQUEsTUFDRjtBQUFBLElBRUYsU0FBU3RELEtBQUs7QUFDWkMsY0FBUTdCLE1BQU0sc0JBQXNCNEIsR0FBRztBQUd2QyxVQUFJQSxLQUFLUSxTQUFTLFNBQVM7QUFDekIsY0FBTXVELFdBQVc7QUFDakIxRixpQkFBUzBGLFFBQVE7QUFDakJ6SSxjQUFNOEMsTUFBTTJGLFFBQVE7QUFBQSxNQUN0QixXQUFXL0QsS0FBS1EsU0FBUyxjQUFjUixLQUFLUyxTQUFTQyxTQUFTLFdBQVcsR0FBRztBQUMxRSxjQUFNcUQsV0FBVztBQUNqQjFGLGlCQUFTMEYsUUFBUTtBQUNqQnpJLGNBQU04QyxNQUFNMkYsUUFBUTtBQUNwQnZILGlCQUFTLGtCQUFrQjtBQUMzQjtBQUFBLE1BQ0YsV0FBV3dELEtBQUtTLFNBQVNFLFlBQVksRUFBRUQsU0FBUyxZQUFZLEtBQUtWLEtBQUtTLFNBQVNFLFlBQVksRUFBRUQsU0FBUyxRQUFRLEdBQUc7QUFDL0csY0FBTXFELFdBQVc7QUFDakIxRixpQkFBUzBGLFFBQVE7QUFDakJ6SSxjQUFNOEMsTUFBTTJGLFFBQVE7QUFBQSxNQUN0QixXQUFXL0QsS0FBS1MsU0FBU0MsU0FBUyxTQUFTLEtBQUtWLEtBQUtTLFNBQVNDLFNBQVMsY0FBYyxHQUFHO0FBQ3RGLGNBQU1xRCxXQUFXO0FBQ2pCMUYsaUJBQVMwRixRQUFRO0FBQ2pCekksY0FBTThDLE1BQU0yRixRQUFRO0FBQUEsTUFDdEIsT0FBTztBQUNMLGNBQU1BLFdBQVcvRCxLQUFLUyxXQUFXO0FBQ2pDcEMsaUJBQVMwRixRQUFRO0FBQ2pCekksY0FBTThDLE1BQU0yRixRQUFRO0FBQUEsTUFDdEI7QUFBQSxJQUVGLFVBQUM7QUFDQ2hHLGtCQUFZLEtBQUs7QUFBQSxJQUNuQjtBQUFBLEVBQ0Y7QUFHQSxRQUFNaUcsbUJBQW1CLFlBQVk7QUFDbkMsUUFBSSxDQUFDdEgsY0FBY3dELE1BQU0sQ0FBQ3pELE1BQU15RDtBQUFJO0FBRXBDLFFBQUk7QUFDRixZQUFNbEUsY0FBY2lJLFdBQVd2SCxjQUFjd0QsRUFBRTtBQUcvQzVFLFlBQU1zSSxRQUFRLFNBQVNsSCxhQUFhOEYsUUFBUSxlQUFlLHlCQUF5QjtBQUdwRjNGLGtCQUFZLENBQUErRSxTQUFRQSxLQUFLekMsT0FBTyxDQUFBQyxTQUFRQSxLQUFLYyxPQUFPeEQsYUFBYXdELEVBQUUsQ0FBQztBQUVwRTFELGVBQVMsa0JBQWtCO0FBQUEsSUFDN0IsU0FBU3dELEtBQUs7QUFDWkMsY0FBUTdCLE1BQU0sd0JBQXdCNEIsR0FBRztBQUN6QyxZQUFNK0QsV0FBVztBQUNqQjFGLGVBQVMwRixRQUFRO0FBQ2pCekksWUFBTThDLE1BQU0yRixRQUFRO0FBQUEsSUFDdEI7QUFDQXhGLHVCQUFtQixLQUFLO0FBQUEsRUFDMUI7QUFHQSxRQUFNMkYsa0JBQWtCLFlBQVk7QUFDbEMsUUFBSSxDQUFDeEgsZ0JBQWdCLENBQUNELE1BQU15RDtBQUFJO0FBRWhDLFFBQUk7QUFDRixZQUFNaUUsaUJBQWlCO0FBQUEsUUFDckIzQixNQUFNLEdBQUc5RixjQUFjOEYsSUFBSTtBQUFBLFFBQzNCUCxhQUFhdkYsY0FBY3VGO0FBQUFBLFFBQzNCbEQsT0FBT3JDLGNBQWNxQztBQUFBQSxRQUNyQk0sT0FBTztBQUFBLFFBQ1ArRSxhQUFhO0FBQUEsUUFDYkMsWUFBWTNILGNBQWMySDtBQUFBQSxRQUMxQkMsWUFBWTVILGNBQWM0SDtBQUFBQSxRQUMxQkMsYUFBYTdILGNBQWM2SDtBQUFBQSxRQUMzQlosVUFBVWxILE1BQU15RDtBQUFBQSxNQUNsQjtBQUVBLFVBQUl1RCxTQUFTLE1BQU16SCxjQUFjNkgsV0FBV00sY0FBYztBQUMxRCxVQUFJVixRQUFRdkQsSUFBSTtBQUVkNUUsY0FBTXNJLFFBQVEsU0FBU08sZUFBZTNCLElBQUksd0JBQXdCO0FBR2xFM0Ysb0JBQVksQ0FBQStFLFNBQVEsQ0FBQzZCLFFBQVEsR0FBRzdCLElBQUksQ0FBQztBQUVyQ3BGLGlCQUFTLG9CQUFvQmlILFFBQVF2RCxFQUFFLEVBQUU7QUFBQSxNQUMzQztBQUFBLElBQ0YsU0FBU0YsS0FBSztBQUNaQyxjQUFRN0IsTUFBTSx1QkFBdUI0QixHQUFHO0FBQ3hDLFlBQU0rRCxXQUFXO0FBQ2pCMUYsZUFBUzBGLFFBQVE7QUFDakJ6SSxZQUFNOEMsTUFBTTJGLFFBQVE7QUFBQSxJQUN0QjtBQUFBLEVBQ0Y7QUFHQSxRQUFNUyxtQkFBbUJBLE1BQU07QUFBQSxFQUc3QjtBQUlGLFFBQU1DLG9CQUFvQixPQUFPQyxpQkFBaUI7QUFDaEQsUUFBSSxDQUFDaEksY0FBY3dEO0FBQUk7QUFFdkIsUUFBSTtBQUNGLFlBQU0yQixjQUFjLE1BQU0xRix1QkFBdUJ3SSxlQUFlO0FBQUEsUUFDOUQsR0FBR0Q7QUFBQUEsUUFDSG5JLFFBQVFHLGNBQWN3RDtBQUFBQSxRQUN0QjBFLFdBQVdsSSxjQUFjMkg7QUFBQUEsTUFDM0IsQ0FBQztBQUdEbEgsb0JBQWMsQ0FBQXlFLFNBQVEsQ0FBQ0MsYUFBYSxHQUFHRCxJQUFJLENBQUM7QUFBQSxJQUU5QyxTQUFTNUIsS0FBSztBQUNaQyxjQUFRN0IsTUFBTSwwQkFBMEI0QixHQUFHO0FBQzNDM0IsZUFBUywyQ0FBMkM7QUFBQSxJQUN0RDtBQUFBLEVBQ0Y7QUFHQSxRQUFNd0csdUJBQXVCLE9BQU9DLGVBQWU7QUFDakQsUUFBSTtBQUNGLFlBQU0zSSx1QkFBdUI0SSxlQUFlRCxVQUFVO0FBR3REM0gsb0JBQWMsQ0FBQXlFLFNBQVFBLE1BQU16QyxPQUFPLENBQUFrRCxhQUFZQSxVQUFVbkMsT0FBTzRFLFVBQVUsQ0FBQztBQUFBLElBRTdFLFNBQVM5RSxLQUFLO0FBQ1pDLGNBQVE3QixNQUFNLDRCQUE0QjRCLEdBQUc7QUFDN0MzQixlQUFTLDhDQUE4QztBQUFBLElBQ3pEO0FBQUEsRUFDRjtBQUdBLFFBQU0yRyx1QkFBdUIsT0FBT0MsTUFBTUMsZUFBZSxZQUFZO0FBQ25FLFFBQUksQ0FBQ3hJLGNBQWN3RDtBQUFJO0FBRXZCLFFBQUk7QUFDRixZQUFNcUMsY0FBYyxNQUFNbkcsc0JBQXNCK0k7QUFBQUEsUUFDOUNGO0FBQUFBLFFBQ0F2SSxjQUFjd0Q7QUFBQUEsUUFDZGdGO0FBQUFBLE1BQ0Y7QUFHQTdILG1CQUFhLENBQUF1RSxTQUFRLENBQUNXLGFBQWEsR0FBR1gsSUFBSSxDQUFDO0FBQUEsSUFFN0MsU0FBUzVCLEtBQUs7QUFDWkMsY0FBUTdCLE1BQU0sNkJBQTZCNEIsR0FBRztBQUM5QzNCLGVBQVMsOENBQThDO0FBQ3ZELFlBQU0yQjtBQUFBQSxJQUNSO0FBQUEsRUFDRjtBQUdBLFFBQU1vRix1QkFBdUIsT0FBT0MsWUFBWUMsYUFBYTtBQUMzRCxRQUFJO0FBQ0YsWUFBTWxKLHNCQUFzQm1KLGVBQWVGLFlBQVlDLFFBQVE7QUFHL0RqSSxtQkFBYSxDQUFBdUUsU0FBUUEsTUFBTXpDLE9BQU8sQ0FBQThELFFBQU9BLEtBQUsvQyxPQUFPbUYsVUFBVSxDQUFDO0FBQUEsSUFFbEUsU0FBU3JGLEtBQUs7QUFDWkMsY0FBUTdCLE1BQU0sNEJBQTRCNEIsR0FBRztBQUM3QzNCLGVBQVMsOENBQThDO0FBQUEsSUFDekQ7QUFBQSxFQUNGO0FBR0EsTUFBSVQsV0FBVztBQUNiLFdBQ0UsdUJBQUMsdVdBQUksV0FBVSw4QkFDYjtBQUFBLDZCQUFDLHlUQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBTztBQUFBLE1BQ1AsdUJBQUMsbVZBQUssV0FBVSxTQUNkLGlDQUFDLHVWQUFJLFdBQVUsYUFDYixpQ0FBQywrVkFBSSxXQUFVLHFCQUNiLGlDQUFDLHVYQUFJLFdBQVUseUNBQ2IsaUNBQUMsMldBQUksV0FBVSwrQkFDYjtBQUFBLCtCQUFDLGlaQUFJLFdBQVUsaUVBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2RTtBQUFBLFFBQzdFLHVCQUFDLGdaQUFLLFdBQVUsdUJBQXNCLCtCQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFEO0FBQUEsV0FGdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BLEtBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBLEtBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsU0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBY0E7QUFBQSxFQUVKO0FBS0EsTUFBSVEsU0FBUyxDQUFDMUIsZ0JBQWdCLENBQUNjLFlBQVk7QUFFekMsV0FDRSx1QkFBQyx1V0FBSSxXQUFVLDhCQUNiO0FBQUEsNkJBQUMseVRBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFPO0FBQUEsTUFDUCx1QkFBQyxtVkFBSyxXQUFVLFNBQ2QsaUNBQUMsdVZBQUksV0FBVSxhQUNiLGlDQUFDLCtWQUFJLFdBQVUscUJBQ2I7QUFBQSwrQkFBQyxzVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVc7QUFBQSxRQUNYLHVCQUFDLCtWQUFJLFdBQVUscUJBQ2I7QUFBQSxpQ0FBQyxpWkFBSyxNQUFLLGVBQWMsTUFBTSxJQUFJLFdBQVUscUNBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThFO0FBQUEsVUFDOUUsdUJBQUMsMlhBQUcsV0FBVSxnREFDWGQsMkJBQWlCLFFBQVFILFdBQVcsUUFBUSxtQkFBbUIsV0FEbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsZ1dBQUUsV0FBVSw0QkFBNEI2QixtQkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0M7QUFBQSxVQUMvQztBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNNUIsU0FBUyxrQkFBa0I7QUFBQSxjQUMxQyxXQUFVO0FBQUEsY0FBYTtBQUFBO0FBQUEsWUFGekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxhQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQTtBQUFBLFdBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWVBLEtBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpQkEsS0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1CQTtBQUFBLFNBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzQkE7QUFBQSxFQUVKO0FBSUEsU0FDRSx1QkFBQyx1V0FBSSxXQUFVLDhCQUNiO0FBQUEsMkJBQUMseVRBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFPO0FBQUEsSUFDUCx1QkFBQyxtVkFBSyxXQUFVLFNBQ2QsaUNBQUMsc1ZBQUksV0FBVSxhQUNiLGlDQUFDLCtWQUFJLFdBQVUscUJBQ2I7QUFBQSw2QkFBQyxzVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVc7QUFBQSxNQUdWNEIsU0FDQyx1QkFBQyxrY0FBSSxXQUFVLHdHQUNiO0FBQUEsK0JBQUMsMldBQUksV0FBVSwrQkFDYjtBQUFBLGlDQUFDLG1WQUFLLE1BQUssZUFBYyxNQUFNLE1BQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtDO0FBQUEsVUFDbEMsdUJBQUMsb1RBQU1BLG1CQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWE7QUFBQSxhQUZmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTUMsU0FBUyxJQUFJO0FBQUEsWUFDNUIsV0FBVTtBQUFBLFlBRVYsaUNBQUMseVVBQUssTUFBSyxLQUFJLE1BQU0sTUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0I7QUFBQTtBQUFBLFVBSjFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsV0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxNQUlGLHVCQUFDLDZaQUFJLFdBQVUscUVBQ2I7QUFBQSwrQkFBQyw0VkFBSSxXQUFVLGdCQUNiO0FBQUEsaUNBQUMsd1hBQUcsV0FBVSw2Q0FDWGIsdUJBQWEsb0JBQXFCZCxjQUFjOEYsUUFBUSxjQUQzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQywyWUFBSSxXQUFVLDJEQUNaaEYsdUJBQ0MsdUJBQUMsNFdBQUsscUNBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkIsSUFFM0IsbUNBQ0dkO0FBQUFBLDBCQUFjd0QsTUFDYixtQ0FDRTtBQUFBLHFDQUFDLG1XQUFLO0FBQUE7QUFBQSxnQkFBV3hELGNBQWN3RDtBQUFBQSxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0M7QUFBQSxjQUNsQyx1QkFBQywwVkFBSyxpQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFPO0FBQUEsaUJBRlQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBRUR4RCxjQUFjeUYsY0FDYixtQ0FDRTtBQUFBLHFDQUFDLDJWQUFLO0FBQUE7QUFBQSxnQkFBVSxJQUFJcUQsS0FBSzlJLGFBQWF5RixVQUFVLEdBQUdzRCxtQkFBbUI7QUFBQSxtQkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0U7QUFBQSxjQUN4RSx1QkFBQywwVkFBSyxpQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFPO0FBQUEsaUJBRlQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBRUQvSSxjQUFjZ0osY0FDYix1QkFBQyxrV0FBSztBQUFBO0FBQUEsY0FBZSxJQUFJRixLQUFLOUksYUFBYWdKLFVBQVUsR0FBR0QsbUJBQW1CO0FBQUEsaUJBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZFO0FBQUEsZUFkakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkEsS0FwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFzQkE7QUFBQSxhQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMkJBO0FBQUEsUUFFQSx1QkFBQywyV0FBSSxXQUFVLCtCQUNaakksdUJBQ0M7QUFBQSxVQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUNDLFNBQVM0RjtBQUFBQSxZQUNULFdBQVU7QUFBQSxZQUVWO0FBQUEscUNBQUMsNFVBQUssTUFBSyxRQUFPLE1BQU0sTUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkI7QUFBQSxjQUMzQix1QkFBQyw4VkFBSywyQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpQjtBQUFBO0FBQUE7QUFBQSxVQUxuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQSxJQUVBLG1DQUNFO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUNDLFNBQVNFO0FBQUFBLGNBQ1QsV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxpVkFBSyxNQUFLLGFBQVksTUFBTSxNQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQztBQUFBLGdCQUNoQyx1QkFBQyxpV0FBSyw0QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrQjtBQUFBO0FBQUE7QUFBQSxZQUxwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLFVBQ0M1RyxjQUFjd0QsTUFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsUUFBUSxNQUFNc0QsZUFBZTlHLFlBQVk7QUFBQSxjQUN6QyxVQUFVLE1BQU02QixtQkFBbUIsSUFBSTtBQUFBLGNBQ3ZDLFNBQVMyRjtBQUFBQSxjQUNULGNBQWNNO0FBQUFBLGNBQ2Q7QUFBQTtBQUFBLFlBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS3FCO0FBQUEsYUFkekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlCQSxLQTNCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNkJBO0FBQUEsV0EzREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTREQTtBQUFBLE1BR0NoSDtBQUFBQTtBQUFBQSxRQUVDLHVCQUFDLDRYQUFJLFdBQVUsOENBQ2I7QUFBQSxpQ0FBQywwV0FBSSxXQUFVLDhCQUNiO0FBQUEsbUNBQUMsaVhBQUksV0FBVSxxQ0FDYjtBQUFBLHFDQUFDLDRaQUFHLFdBQVUsMkNBQTBDLHlCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpRTtBQUFBLGNBQ2pFLHVCQUFDLDJXQUFJLFdBQVUsK0JBRWI7QUFBQSx1Q0FBQyxnWUFBSSxXQUFVLGdEQUNiO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBQ0MsU0FBUyxNQUFNRyxjQUFjLEtBQUs7QUFBQSxzQkFDbEMsV0FBVyw0RkFDVCxDQUFDRCxhQUNHLG9DQUNBLG1DQUFtQztBQUFBLHNCQUd6QztBQUFBLCtDQUFDLDRVQUFLLE1BQUssUUFBTyxNQUFNLE1BQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQTJCO0FBQUEsd0JBQzNCLHVCQUFDLHFWQUFLLG9CQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQVU7QUFBQTtBQUFBO0FBQUEsb0JBVFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBQ0MsU0FBUyxNQUFNQyxjQUFjLElBQUk7QUFBQSxzQkFDakMsV0FBVyw0RkFDVEQsYUFDSSxvQ0FDQSxtQ0FBbUM7QUFBQSxzQkFHekM7QUFBQSwrQ0FBQyw0VUFBSyxNQUFLLFFBQU8sTUFBTSxNQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUEyQjtBQUFBLHdCQUMzQix1QkFBQyxxVkFBSyxvQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFVO0FBQUE7QUFBQTtBQUFBLG9CQVRaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFVQTtBQUFBLHFCQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXVCQTtBQUFBLGdCQUNBLHVCQUFDLDBZQUFJLFdBQVUsK0JBQ1p3QjtBQUFBQSxnQ0FBY3lHO0FBQUFBLGtCQUFPO0FBQUEsa0JBQU16RyxjQUFjeUcsV0FBVyxJQUFJLE1BQU07QUFBQSxrQkFDOURuSCx3QkFBd0IsU0FBUyxLQUFLNUIsU0FBUytJLE1BQU07QUFBQSxxQkFGeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLG1CQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQThCQTtBQUFBLGlCQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlDQTtBQUFBLFlBR0EsdUJBQUMsZ1ZBQUksV0FBVSxRQUNiLGlDQUFDLG9XQUFJLFdBQVUsd0JBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFDQyxTQUFTLE1BQU1sSCx1QkFBdUIsS0FBSztBQUFBLGtCQUMzQyxXQUFXLGdFQUNURCx3QkFBd0IsUUFDcEIsMEJBQ0EsNkNBQTZDO0FBQUEsa0JBQ2hEO0FBQUE7QUFBQSxvQkFFVTVCLFNBQVMrSTtBQUFBQSxvQkFBTztBQUFBO0FBQUE7QUFBQSxnQkFSL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBU0E7QUFBQSxjQUNDN0csT0FBT3dELElBQUksQ0FBQWpELFVBQVM7QUFDbkIsc0JBQU11RyxhQUFhaEosU0FBU3VDLE9BQU8sQ0FBQUMsU0FBUUEsS0FBS0MsVUFBVUEsTUFBTU4sS0FBSyxFQUFFNEc7QUFDdkUsdUJBQ0U7QUFBQSxrQkFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBRUMsU0FBUyxNQUFNbEgsdUJBQXVCWSxNQUFNTixLQUFLO0FBQUEsb0JBQ2pELFdBQVcsZ0VBQ1RQLHdCQUF3QmEsTUFBTU4sUUFDMUIsMEJBQ0EsR0FBR00sTUFBTUosS0FBSyxtQkFBbUI7QUFBQSxvQkFHdENJO0FBQUFBLDRCQUFNTDtBQUFBQSxzQkFBTTtBQUFBLHNCQUFHNEc7QUFBQUEsc0JBQVc7QUFBQTtBQUFBO0FBQUEsa0JBUnRCdkcsTUFBTU47QUFBQUEsa0JBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFVQTtBQUFBLGNBRUosQ0FBQztBQUFBLGlCQTFCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTJCQSxLQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTZCQTtBQUFBLGVBbEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUVBO0FBQUEsVUFFQ25CLFlBQ0MsdUJBQUMsNlZBQUksV0FBVSxtQkFDYjtBQUFBLG1DQUFDLGthQUFJLFdBQVUsOEVBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEY7QUFBQSxZQUMxRix1QkFBQyx3WUFBRSxXQUFVLHVCQUFzQixnQ0FBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUQ7QUFBQSxlQUZyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBLElBQ0VzQixjQUFjeUcsV0FBVyxJQUMzQix1QkFBQyw2VkFBSSxXQUFVLG1CQUNiO0FBQUEsbUNBQUMsNllBQUssTUFBSyxXQUFVLE1BQU0sSUFBSSxXQUFVLHFDQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRTtBQUFBLFlBQzFFLHVCQUFDLHlYQUFHLFdBQVUsOENBQ1huSCxrQ0FBd0IsUUFBUSxpQkFBaUIsZUFBZU0sT0FBTytHLEtBQUssQ0FBQUMsTUFBS0EsRUFBRS9HLFVBQVVQLG1CQUFtQixHQUFHUSxLQUFLLFlBRDNIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLGdXQUFFLFdBQVUsNEJBQ1ZSLGtDQUF3QixRQUNyQiwwQ0FDQSwwREFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsWUFDQ0Esd0JBQXdCLFNBQ3ZCO0FBQUEsY0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ0MsU0FBUzRFO0FBQUFBLGdCQUNULFdBQVU7QUFBQSxnQkFBYTtBQUFBO0FBQUEsY0FGekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxlQWpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1CQSxJQUNFMUYsYUFDRix1QkFBQywrVUFBSSxXQUFVLE9BQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUNDLE9BQU93QjtBQUFBQSxjQUNQO0FBQUEsY0FDQSxZQUFZbUU7QUFBQUE7QUFBQUEsWUFIZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFHNkIsS0FKL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQSxJQUVBLHVCQUFDLDJWQUFJLFdBQVUsbUJBQ2IsaUNBQUMsd1ZBQU0sV0FBVSxVQUNmO0FBQUEsbUNBQUMsNFZBQU0sV0FBVSxjQUNmLGlDQUFDLDhTQUNDO0FBQUEscUNBQUMsNGNBQUcsV0FBVSx3RkFBdUYsb0JBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlHO0FBQUEsY0FDekcsdUJBQUMsNmNBQUcsV0FBVSx3RkFBdUYscUJBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBHO0FBQUEsY0FDMUcsdUJBQUMsNmNBQUcsV0FBVSx3RkFBdUYscUJBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBHO0FBQUEsY0FDMUcsdUJBQUMsbWRBQUcsV0FBVSx3RkFBdUYsMkJBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdIO0FBQUEsY0FDaEgsdUJBQUMsK2NBQUcsV0FBVSx3RkFBdUYsdUJBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRHO0FBQUEsY0FDNUcsdUJBQUMsZ2RBQUcsV0FBVSx5RkFBd0YsdUJBQXRHO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZHO0FBQUEsaUJBTi9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0EsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUEsWUFDQSx1QkFBQyxxWEFBTSxXQUFVLG1DQUNkbkUsd0JBQWNvRDtBQUFBQSxjQUFJLENBQUNsRCxTQUNsQix1QkFBQywyVkFBaUIsV0FBVSxvQkFDMUI7QUFBQSx1Q0FBQyx3V0FBRyxXQUFVLCtCQUNaLGlDQUFDLGlUQUNDO0FBQUEseUNBQUMscVhBQUksV0FBVSx5Q0FBeUNBLGVBQUtvRCxRQUFRLG1CQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFxRjtBQUFBLGtCQUNyRix1QkFBQywrWEFBSSxXQUFVLGlEQUFpRHBELGVBQUs2QyxlQUFlLG9CQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFxRztBQUFBLHFCQUZ2RztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLQTtBQUFBLGdCQUNBLHVCQUFDLHdXQUFHLFdBQVUsK0JBQ1osaUNBQUMsb1RBQUssV0FBVyw4Q0FDZm5ELE9BQU8rRyxLQUFLLENBQUFDLE1BQUtBLEVBQUUvRyxVQUFVSyxLQUFLQyxLQUFLLEdBQUdKLFNBQVMsMkJBQTJCLElBRTdFSCxpQkFBTytHLEtBQUssQ0FBQUMsTUFBS0EsRUFBRS9HLFVBQVVLLEtBQUtDLEtBQUssR0FBR0wsU0FBU0ksS0FBS0MsU0FIM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQSxLQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBTUE7QUFBQSxnQkFDQSx1QkFBQyxzYUFBRyxXQUFVLHlEQUF3RDtBQUFBO0FBQUEsbUJBQ2pFRCxLQUFLTCxTQUFTLEdBQUdnSCxlQUFlO0FBQUEscUJBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxzYUFBRyxXQUFVLHlEQUNYM0c7QUFBQUEsdUJBQUtnRixlQUFlO0FBQUEsa0JBQUU7QUFBQSxxQkFEekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLHdZQUFHLFdBQVUsMkRBQ1gsY0FBSW9CLEtBQUtwRyxLQUFLK0MsVUFBVSxFQUFFc0QsbUJBQW1CLEtBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyw2WUFBRyxXQUFVLDhEQUNaO0FBQUEsa0JBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUNDLFNBQVMsTUFBTXBDLGVBQWVqRSxJQUFJO0FBQUEsb0JBQ2xDLFdBQVU7QUFBQSxvQkFBMEM7QUFBQTtBQUFBLGtCQUZ0RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU9BO0FBQUEsbUJBOUJPQSxLQUFLYyxJQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBK0JBO0FBQUEsWUFDRCxLQWxDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW1DQTtBQUFBLGVBOUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBK0NBLEtBaERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaURBO0FBQUEsYUExSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTRKQTtBQUFBO0FBQUE7QUFBQSxRQUdBLHVCQUFDLDBYQUFJLFdBQVUsMENBRWI7QUFBQSxpQ0FBQywyVkFBSSxXQUFVLGlCQUNadEMsc0JBQ0MsdUJBQUMsa1lBQUksV0FBVSxrREFDYixpQ0FBQyx1VkFBSSxXQUFVLGVBQ2I7QUFBQSxtQ0FBQyxrYUFBSSxXQUFVLDhFQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBGO0FBQUEsWUFDMUYsdUJBQUMsOFlBQUUsV0FBVSx1QkFBc0Isb0NBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVEO0FBQUEsZUFGekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0EsSUFFQTtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsTUFBTWxCO0FBQUFBLGNBQ047QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBLGNBQ0EsVUFBVThHO0FBQUFBLGNBQ1YsVUFBVUY7QUFBQUEsY0FDVjtBQUFBO0FBQUEsWUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPcUIsS0FoQnpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsVUFHQzVHLGNBQWN3RCxNQUFNLENBQUN0QyxhQUNwQix1QkFBQyx1V0FBSSxXQUFVLDJCQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFDQztBQUFBLGdCQUNBLFNBQVNJO0FBQUFBLGdCQUNULFNBQVN0QixjQUFjc0o7QUFBQUEsZ0JBQ3ZCLGVBQWV2QjtBQUFBQSxnQkFDZixrQkFBa0JJO0FBQUFBO0FBQUFBLGNBTHBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUt5QztBQUFBLFlBR3pDO0FBQUEsY0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ0M7QUFBQSxnQkFDQSxTQUFTM0c7QUFBQUEsZ0JBQ1QsUUFBUXhCLGNBQWN3RDtBQUFBQSxnQkFDdEIsa0JBQWtCOEU7QUFBQUEsZ0JBQ2xCLGtCQUFrQkk7QUFBQUE7QUFBQUEsY0FMcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS3lDO0FBQUEsZUFkM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkE7QUFBQSxhQXpDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMkNBO0FBQUE7QUFBQSxTQS9SSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaVNBLEtBbFNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtU0EsS0FwU0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFTQTtBQUFBLElBRUM5RyxtQkFDQyx1QkFBQyxtYUFBSSxXQUFVLDhFQUNiLGlDQUFDLG9ZQUFJLFdBQVUsa0RBQ2I7QUFBQSw2QkFBQyxrWEFBSSxXQUFVLG9DQUNiO0FBQUEsK0JBQUMsMlpBQUksV0FBVSx1RUFDYixpQ0FBQywwWEFBSyxNQUFLLGlCQUFnQixNQUFNLElBQUksV0FBVSxnQkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRCxLQUQ3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLDhaQUFHLFdBQVUsMkNBQTBDLDJCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1FO0FBQUEsV0FKckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFFQSx1QkFBQyxxZUFBRSxXQUFVLDRCQUEyQjtBQUFBO0FBQUEsUUFDSjVCLGNBQWM4RjtBQUFBQSxRQUFLO0FBQUEsV0FEdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFQSx1QkFBQyw0VkFBSSxXQUFVLGtCQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTWpFLG1CQUFtQixLQUFLO0FBQUEsWUFDdkMsV0FBVTtBQUFBLFlBQW9KO0FBQUE7QUFBQSxVQUZoSztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUNDLFNBQVN5RjtBQUFBQSxZQUNULFdBQVU7QUFBQSxZQUFtRztBQUFBO0FBQUEsVUFGL0c7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxXQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFhQTtBQUFBLFNBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwQkEsS0EzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTRCQTtBQUFBLE9BdFVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3VUE7QUFFSjtBQUFFMUgsR0F4NEJJRCxnQkFBYztBQUFBLFVBQ0NqQixXQUNGQyxhQUNBRSxPQUFPO0FBQUE7QUFBQTBLLEtBSHBCNUo7QUEwNEJOLGVBQWVBO0FBQWUsSUFBQTRKO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZUNhbGxiYWNrIiwidXNlUGFyYW1zIiwidXNlTmF2aWdhdGUiLCJ0b2FzdCIsInVzZUF1dGgiLCJIZWFkZXIiLCJCcmVhZGNydW1iIiwiSWNvbiIsIkRlYWxGb3JtIiwiQWN0aXZpdHlUaW1lbGluZSIsIkRvY3VtZW50c1NlY3Rpb24iLCJEZWFsQWN0aW9ucyIsIkRlYWxzR3JpZFZpZXciLCJkZWFsc1NlcnZpY2UiLCJjb250YWN0c1NlcnZpY2UiLCJjb21wYW5pZXNTZXJ2aWNlIiwiZGVhbEFjdGl2aXRpZXNTZXJ2aWNlIiwiZGVhbERvY3VtZW50c1NlcnZpY2UiLCJEZWFsTWFuYWdlbWVudCIsIl9zIiwiZGVhbElkIiwibmF2aWdhdGUiLCJ1c2VyIiwic2VsZWN0ZWREZWFsIiwic2V0U2VsZWN0ZWREZWFsIiwiYWxsRGVhbHMiLCJzZXRBbGxEZWFscyIsImNvbnRhY3RzIiwic2V0Q29udGFjdHMiLCJjb21wYW5pZXMiLCJzZXRDb21wYW5pZXMiLCJhY3Rpdml0aWVzIiwic2V0QWN0aXZpdGllcyIsImRvY3VtZW50cyIsInNldERvY3VtZW50cyIsInNob3dGb3JtIiwic2V0U2hvd0Zvcm0iLCJpc0xpc3RWaWV3Iiwic2V0SXNMaXN0VmlldyIsImlzR3JpZFZpZXciLCJzZXRJc0dyaWRWaWV3IiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwiaXNTYXZpbmciLCJzZXRJc1NhdmluZyIsImlzTG9hZGluZ0FjdGl2aXRpZXMiLCJzZXRJc0xvYWRpbmdBY3Rpdml0aWVzIiwiaXNMb2FkaW5nRG9jdW1lbnRzIiwic2V0SXNMb2FkaW5nRG9jdW1lbnRzIiwiZXJyb3IiLCJzZXRFcnJvciIsInNob3dEZWxldGVNb2RhbCIsInNldFNob3dEZWxldGVNb2RhbCIsInNlbGVjdGVkU3RhZ2VGaWx0ZXIiLCJzZXRTZWxlY3RlZFN0YWdlRmlsdGVyIiwiYWN0aXZpdHlDaGFubmVsIiwic2V0QWN0aXZpdHlDaGFubmVsIiwiZG9jdW1lbnRDaGFubmVsIiwic2V0RG9jdW1lbnRDaGFubmVsIiwic3RhZ2VzIiwidmFsdWUiLCJsYWJlbCIsImNvbG9yIiwiZmlsdGVyZWREZWFscyIsImZpbHRlciIsImRlYWwiLCJzdGFnZSIsImxvYWRJbml0aWFsRGF0YSIsImRlYWxzRGF0YSIsImNvbnRhY3RzRGF0YSIsImNvbXBhbmllc0RhdGEiLCJQcm9taXNlIiwiYWxsIiwiZ2V0VXNlckRlYWxzIiwiZ2V0VXNlckNvbnRhY3RzIiwiZ2V0QWxsQ29tcGFuaWVzIiwibG9hZERlYWwiLCJlcnIiLCJjb25zb2xlIiwiaWQiLCJkZWFsRGF0YSIsImdldERlYWxCeUlkIiwibG9hZEFjdGl2aXRpZXMiLCJsb2FkRG9jdW1lbnRzIiwic2V0dXBSZWFsdGltZVN1YnNjcmlwdGlvbnMiLCJjb2RlIiwibWVzc2FnZSIsImluY2x1ZGVzIiwidG9Mb3dlckNhc2UiLCJhY3Rpdml0aWVzRGF0YSIsImdldERlYWxBY3Rpdml0aWVzIiwiZG9jdW1lbnRzRGF0YSIsImdldERlYWxEb2N1bWVudHMiLCJhY3Rpdml0eVN1YiIsInN1YnNjcmliZVRvQWN0aXZpdHlDaGFuZ2VzIiwicGF5bG9hZCIsImhhbmRsZUFjdGl2aXR5Q2hhbmdlIiwiZG9jdW1lbnRTdWIiLCJzdWJzY3JpYmVUb0RvY3VtZW50Q2hhbmdlcyIsImhhbmRsZURvY3VtZW50Q2hhbmdlIiwiZXZlbnRUeXBlIiwibmV3IiwibmV3UmVjb3JkIiwib2xkIiwib2xkUmVjb3JkIiwicHJldiIsIm5ld0FjdGl2aXR5IiwidHlwZSIsInRpdGxlIiwic3ViamVjdCIsImRlc2NyaXB0aW9uIiwidGltZXN0YW1wIiwiY3JlYXRlZF9hdCIsImRlYWxfaWQiLCJhY3Rpdml0eSIsIm1hcCIsIm5ld0RvY3VtZW50IiwibmFtZSIsInNpemUiLCJmb3JtYXRGaWxlU2l6ZSIsImZpbGVfc2l6ZSIsImdldEZpbGVFeHRlbnNpb24iLCJ1cGxvYWRlZEF0IiwidXBsb2FkZWRCeSIsImZpbGVVcmwiLCJmaWxlX3VybCIsImRvYyIsInVuc3Vic2NyaWJlRnJvbUFjdGl2aXR5Q2hhbmdlcyIsInVuc3Vic2NyaWJlRnJvbURvY3VtZW50Q2hhbmdlcyIsImhhbmRsZUNyZWF0ZU5ld0RlYWwiLCJoYW5kbGVFZGl0RGVhbCIsImhhbmRsZUJhY2tUb0xpc3QiLCJsb2FkQWxsRGVhbHMiLCJoYW5kbGVTYXZlRGVhbCIsInJlc3VsdCIsInVwZGF0ZURlYWwiLCJvd25lcl9pZCIsInN1Y2Nlc3MiLCJjcmVhdGVEZWFsIiwiRXJyb3IiLCJlcnJvck1zZyIsImhhbmRsZURlbGV0ZURlYWwiLCJkZWxldGVEZWFsIiwiaGFuZGxlQ2xvbmVEZWFsIiwiY2xvbmVkRGVhbERhdGEiLCJwcm9iYWJpbGl0eSIsImNvbnRhY3RfaWQiLCJjb21wYW55X2lkIiwibGVhZF9zb3VyY2UiLCJoYW5kbGVDcmVhdGVUYXNrIiwiaGFuZGxlQWRkQWN0aXZpdHkiLCJhY3Rpdml0eURhdGEiLCJjcmVhdGVBY3Rpdml0eSIsImNvbnRhY3RJZCIsImhhbmRsZURlbGV0ZUFjdGl2aXR5IiwiYWN0aXZpdHlJZCIsImRlbGV0ZUFjdGl2aXR5IiwiaGFuZGxlVXBsb2FkRG9jdW1lbnQiLCJmaWxlIiwiZG9jdW1lbnRUeXBlIiwidXBsb2FkRG9jdW1lbnQiLCJoYW5kbGVEZWxldGVEb2N1bWVudCIsImRvY3VtZW50SWQiLCJmaWxlUGF0aCIsImRlbGV0ZURvY3VtZW50IiwiRGF0ZSIsInRvTG9jYWxlRGF0ZVN0cmluZyIsInVwZGF0ZWRfYXQiLCJsZW5ndGgiLCJzdGFnZUNvdW50IiwiZmluZCIsInMiLCJ0b0xvY2FsZVN0cmluZyIsImNvbnRhY3QiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbImluZGV4LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlQ2FsbGJhY2sgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IHVzZVBhcmFtcywgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0IHRvYXN0IGZyb20gJ3JlYWN0LWhvdC10b2FzdCc7XHJcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tICcuLi8uLi9jb250ZXh0cy9BdXRoQ29udGV4dCc7XHJcbmltcG9ydCBIZWFkZXIgZnJvbSAnY29tcG9uZW50cy91aS9IZWFkZXInO1xyXG5pbXBvcnQgQnJlYWRjcnVtYiBmcm9tICdjb21wb25lbnRzL3VpL0JyZWFkY3J1bWInO1xyXG5pbXBvcnQgSWNvbiBmcm9tICdjb21wb25lbnRzL0FwcEljb24nO1xyXG5cclxuaW1wb3J0IERlYWxGb3JtIGZyb20gJy4vY29tcG9uZW50cy9EZWFsRm9ybSc7XHJcbmltcG9ydCBBY3Rpdml0eVRpbWVsaW5lIGZyb20gJy4vY29tcG9uZW50cy9BY3Rpdml0eVRpbWVsaW5lJztcclxuaW1wb3J0IERvY3VtZW50c1NlY3Rpb24gZnJvbSAnLi9jb21wb25lbnRzL0RvY3VtZW50c1NlY3Rpb24nO1xyXG5pbXBvcnQgRGVhbEFjdGlvbnMgZnJvbSAnLi9jb21wb25lbnRzL0RlYWxBY3Rpb25zJztcclxuaW1wb3J0IERlYWxzR3JpZFZpZXcgZnJvbSAnLi9jb21wb25lbnRzL0RlYWxzR3JpZFZpZXcnO1xyXG5cclxuaW1wb3J0IGRlYWxzU2VydmljZSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9kZWFsc1NlcnZpY2UnO1xyXG5pbXBvcnQgY29udGFjdHNTZXJ2aWNlIGZyb20gJy4uLy4uL3NlcnZpY2VzL2NvbnRhY3RzU2VydmljZSc7XHJcbmltcG9ydCBjb21wYW5pZXNTZXJ2aWNlIGZyb20gJy4uLy4uL3NlcnZpY2VzL2NvbXBhbmllc1NlcnZpY2UnO1xyXG5pbXBvcnQgZGVhbEFjdGl2aXRpZXNTZXJ2aWNlIGZyb20gJy4uLy4uL3NlcnZpY2VzL2RlYWxBY3Rpdml0aWVzU2VydmljZSc7XHJcbmltcG9ydCBkZWFsRG9jdW1lbnRzU2VydmljZSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9kZWFsRG9jdW1lbnRzU2VydmljZSc7XHJcblxyXG5jb25zdCBEZWFsTWFuYWdlbWVudCA9ICgpID0+IHtcclxuICBjb25zdCB7IGRlYWxJZCB9ID0gdXNlUGFyYW1zKCk7XHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG4gIGNvbnN0IHsgdXNlciB9ID0gdXNlQXV0aCgpO1xyXG4gIFxyXG4gIC8vIFN0YXRlIG1hbmFnZW1lbnRcclxuICBjb25zdCBbc2VsZWN0ZWREZWFsLCBzZXRTZWxlY3RlZERlYWxdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2FsbERlYWxzLCBzZXRBbGxEZWFsc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2NvbnRhY3RzLCBzZXRDb250YWN0c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2NvbXBhbmllcywgc2V0Q29tcGFuaWVzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbYWN0aXZpdGllcywgc2V0QWN0aXZpdGllc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2RvY3VtZW50cywgc2V0RG9jdW1lbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBcclxuICAvLyBVSSBzdGF0ZVxyXG4gIGNvbnN0IFtzaG93Rm9ybSwgc2V0U2hvd0Zvcm1dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtpc0xpc3RWaWV3LCBzZXRJc0xpc3RWaWV3XSA9IHVzZVN0YXRlKHRydWUpO1xyXG4gIGNvbnN0IFtpc0dyaWRWaWV3LCBzZXRJc0dyaWRWaWV3XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBcclxuICAvLyBMb2FkaW5nIHN0YXRlc1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcclxuICBjb25zdCBbaXNTYXZpbmcsIHNldElzU2F2aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbaXNMb2FkaW5nQWN0aXZpdGllcywgc2V0SXNMb2FkaW5nQWN0aXZpdGllc10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2lzTG9hZGluZ0RvY3VtZW50cywgc2V0SXNMb2FkaW5nRG9jdW1lbnRzXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBcclxuICAvLyBFcnJvciBhbmQgVUkgc3RhdGVzXHJcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbc2hvd0RlbGV0ZU1vZGFsLCBzZXRTaG93RGVsZXRlTW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIFxyXG4gIC8vIEZpbHRlciBzdGF0ZVxyXG4gIGNvbnN0IFtzZWxlY3RlZFN0YWdlRmlsdGVyLCBzZXRTZWxlY3RlZFN0YWdlRmlsdGVyXSA9IHVzZVN0YXRlKCdhbGwnKTtcclxuICBcclxuICAvLyBSZWFsLXRpbWUgc3Vic2NyaXB0aW9uIGNoYW5uZWxzXHJcbiAgY29uc3QgW2FjdGl2aXR5Q2hhbm5lbCwgc2V0QWN0aXZpdHlDaGFubmVsXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtkb2N1bWVudENoYW5uZWwsIHNldERvY3VtZW50Q2hhbm5lbF0gPSB1c2VTdGF0ZShudWxsKTtcclxuXHJcbiAgLy8gRGVhbCBzdGFnZXMgYW5kIHNhbGVzIHJlcHMgY29uZmlndXJhdGlvblxyXG4gIGNvbnN0IHN0YWdlcyA9IFtcclxuICAgIHsgdmFsdWU6IFwibGVhZFwiLCBsYWJlbDogXCJMZWFkXCIsIGNvbG9yOiBcImJnLWdyYXktMTAwIHRleHQtZ3JheS04MDBcIiB9LFxyXG4gICAgeyB2YWx1ZTogXCJxdWFsaWZpZWRcIiwgbGFiZWw6IFwiUXVhbGlmaWVkXCIsIGNvbG9yOiBcImJnLWJsdWUtMTAwIHRleHQtYmx1ZS04MDBcIiB9LFxyXG4gICAgeyB2YWx1ZTogXCJwcm9wb3NhbFwiLCBsYWJlbDogXCJQcm9wb3NhbFwiLCBjb2xvcjogXCJiZy15ZWxsb3ctMTAwIHRleHQteWVsbG93LTgwMFwiIH0sXHJcbiAgICB7IHZhbHVlOiBcIm5lZ290aWF0aW9uXCIsIGxhYmVsOiBcIk5lZ290aWF0aW9uXCIsIGNvbG9yOiBcImJnLW9yYW5nZS0xMDAgdGV4dC1vcmFuZ2UtODAwXCIgfSxcclxuICAgIHsgdmFsdWU6IFwiY2xvc2VkX3dvblwiLCBsYWJlbDogXCJDbG9zZWQgV29uXCIsIGNvbG9yOiBcImJnLWdyZWVuLTEwMCB0ZXh0LWdyZWVuLTgwMFwiIH0sXHJcbiAgICB7IHZhbHVlOiBcImNsb3NlZF9sb3N0XCIsIGxhYmVsOiBcIkNsb3NlZCBMb3N0XCIsIGNvbG9yOiBcImJnLXJlZC0xMDAgdGV4dC1yZWQtODAwXCIgfVxyXG4gIF07XHJcblxyXG4gIC8vIEZpbHRlciBkZWFscyBiYXNlZCBvbiBzZWxlY3RlZCBzdGFnZVxyXG4gIGNvbnN0IGZpbHRlcmVkRGVhbHMgPSBzZWxlY3RlZFN0YWdlRmlsdGVyID09PSAnYWxsJyBcclxuICAgID8gYWxsRGVhbHMgXHJcbiAgICA6IGFsbERlYWxzLmZpbHRlcihkZWFsID0+IGRlYWwuc3RhZ2UgPT09IHNlbGVjdGVkU3RhZ2VGaWx0ZXIpO1xyXG5cclxuICAvLyBMb2FkIGluaXRpYWwgZGF0YVxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBcclxuICAgIGlmICghdXNlcikgcmV0dXJuO1xyXG4gICAgXHJcbiAgICBjb25zdCBsb2FkSW5pdGlhbERhdGEgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIFxyXG4gICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIHNldEVycm9yKG51bGwpO1xyXG4gICAgICBcclxuICAgICAgdHJ5IHtcclxuICAgICAgICAvLyBMb2FkIGFsbCBkZWFscywgY29udGFjdHMgYW5kIGNvbXBhbmllcyBpbiBwYXJhbGxlbFxyXG4gICAgICAgIGNvbnN0IFtkZWFsc0RhdGEsIGNvbnRhY3RzRGF0YSwgY29tcGFuaWVzRGF0YV0gPSBhd2FpdCBQcm9taXNlLmFsbChbXHJcbiAgICAgICAgICBkZWFsc1NlcnZpY2U/LmdldFVzZXJEZWFscygpLFxyXG4gICAgICAgICAgY29udGFjdHNTZXJ2aWNlPy5nZXRVc2VyQ29udGFjdHMoKSxcclxuICAgICAgICAgIGNvbXBhbmllc1NlcnZpY2U/LmdldEFsbENvbXBhbmllcygpXHJcbiAgICAgICAgXSk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgXHJcbiAgICAgICAgXHJcbiAgICAgICAgc2V0QWxsRGVhbHMoZGVhbHNEYXRhIHx8IFtdKTtcclxuICAgICAgICBzZXRDb250YWN0cyhjb250YWN0c0RhdGEgfHwgW10pO1xyXG4gICAgICAgIHNldENvbXBhbmllcyhjb21wYW5pZXNEYXRhIHx8IFtdKTtcclxuICAgICAgICBcclxuICAgICAgICAvLyBIYW5kbGUgc3BlY2lmaWMgZGVhbCBJRCBpbiBVUkxcclxuICAgICAgICBpZiAoZGVhbElkICYmIGRlYWxJZCAhPT0gJ25ldycpIHtcclxuICAgICAgICAgIFxyXG4gICAgICAgICAgc2V0SXNMaXN0VmlldyhmYWxzZSk7XHJcbiAgICAgICAgICBzZXRTaG93Rm9ybSh0cnVlKTtcclxuICAgICAgICAgIGF3YWl0IGxvYWREZWFsKGRlYWxJZCk7XHJcbiAgICAgICAgfSBlbHNlIGlmIChkZWFsSWQgPT09ICduZXcnKSB7XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIHNldElzTGlzdFZpZXcoZmFsc2UpO1xyXG4gICAgICAgICAgc2V0U2hvd0Zvcm0odHJ1ZSk7XHJcbiAgICAgICAgICBzZXRTZWxlY3RlZERlYWwobnVsbCk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIFxyXG4gICAgICAgICAgc2V0SXNMaXN0Vmlldyh0cnVlKTtcclxuICAgICAgICAgIHNldFNob3dGb3JtKGZhbHNlKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGxvYWRpbmcgaW5pdGlhbCBkYXRhOicsIGVycik7XHJcbiAgICAgICAgc2V0RXJyb3IoJ0ZhaWxlZCB0byBsb2FkIGRhdGEuIFBsZWFzZSByZWZyZXNoIHRoZSBwYWdlLicpO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgXHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgbG9hZEluaXRpYWxEYXRhKCk7XHJcbiAgfSwgW2RlYWxJZCwgdXNlcl0pO1xyXG5cclxuICAvLyBMb2FkIHNwZWNpZmljIGRlYWwgZGF0YVxyXG4gIGNvbnN0IGxvYWREZWFsID0gYXN5bmMgKGlkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBkZWFsRGF0YSA9IGF3YWl0IGRlYWxzU2VydmljZT8uZ2V0RGVhbEJ5SWQoaWQpO1xyXG4gICAgICBpZiAoIWRlYWxEYXRhKSB7XHJcbiAgICAgICAgc2V0RXJyb3IoJ0RlYWwgbm90IGZvdW5kJyk7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgICByZXR1cm47XHJcbiAgICAgIH1cclxuICAgICAgXHJcbiAgICAgIHNldFNlbGVjdGVkRGVhbChkZWFsRGF0YSk7XHJcbiAgICAgIFxyXG4gICAgICAvLyBMb2FkIGFjdGl2aXRpZXMgYW5kIGRvY3VtZW50cyBpbiBwYXJhbGxlbFxyXG4gICAgICBhd2FpdCBQcm9taXNlLmFsbChbXHJcbiAgICAgICAgbG9hZEFjdGl2aXRpZXMoaWQpLFxyXG4gICAgICAgIGxvYWREb2N1bWVudHMoaWQpXHJcbiAgICAgIF0pO1xyXG4gICAgICBcclxuICAgICAgLy8gU2V0IHVwIHJlYWwtdGltZSBzdWJzY3JpcHRpb25zXHJcbiAgICAgIHNldHVwUmVhbHRpbWVTdWJzY3JpcHRpb25zKGlkKTtcclxuICAgICAgXHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgbG9hZGluZyBkZWFsOicsIGVycik7XHJcbiAgICAgIFxyXG4gICAgICAvLyBIYW5kbGUgc3BlY2lmaWMgZXJyb3IgY2FzZXMgd2l0aCBtb3JlIHByZWNpc2UgZGV0ZWN0aW9uXHJcbiAgICAgIGlmIChlcnI/LmNvZGUgPT09ICdQR1JTVDExNicgfHwgZXJyPy5tZXNzYWdlPy5pbmNsdWRlcygnbm90IGZvdW5kJykpIHtcclxuICAgICAgICBzZXRFcnJvcignRGVhbCBub3QgZm91bmQuIEl0IG1heSBoYXZlIGJlZW4gZGVsZXRlZCBvciB5b3UgbWF5IG5vdCBoYXZlIHBlcm1pc3Npb24gdG8gdmlldyBpdC4nKTtcclxuICAgICAgfSBlbHNlIGlmIChlcnI/Lm1lc3NhZ2U/LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoJ3Blcm1pc3Npb24nKSB8fCBlcnI/Lm1lc3NhZ2U/LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoJ3BvbGljeScpKSB7XHJcbiAgICAgICAgc2V0RXJyb3IoJ1Blcm1pc3Npb24gZGVuaWVkLiBZb3UgbWF5IG5vdCBoYXZlIGFjY2VzcyB0byB2aWV3IHRoaXMgZGVhbC4nKTtcclxuICAgICAgfSBlbHNlIGlmIChlcnI/Lm1lc3NhZ2U/LmluY2x1ZGVzKCdjb21wYW55JykgfHwgZXJyPy5tZXNzYWdlPy5pbmNsdWRlcygnc2NoZW1hIGNhY2hlJykpIHtcclxuICAgICAgICBzZXRFcnJvcignQ291bGQgbm90IGxvYWQgZGVhbCBpbmZvcm1hdGlvbi4gUGxlYXNlIGNoZWNrIHlvdXIgZGF0YWJhc2UgY29ubmVjdGlvbiBhbmQgdHJ5IHJlZnJlc2hpbmcgdGhlIHBhZ2UuJyk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0RXJyb3IoJ0ZhaWxlZCB0byBsb2FkIGRlYWwuIFBsZWFzZSB0cnkgYWdhaW4uJyk7XHJcbiAgICAgIH1cclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gTG9hZCBkZWFsIGFjdGl2aXRpZXNcclxuICBjb25zdCBsb2FkQWN0aXZpdGllcyA9IGFzeW5jIChpZCkgPT4ge1xyXG4gICAgc2V0SXNMb2FkaW5nQWN0aXZpdGllcyh0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IGFjdGl2aXRpZXNEYXRhID0gYXdhaXQgZGVhbEFjdGl2aXRpZXNTZXJ2aWNlPy5nZXREZWFsQWN0aXZpdGllcyhpZCk7XHJcbiAgICAgIHNldEFjdGl2aXRpZXMoYWN0aXZpdGllc0RhdGEgfHwgW10pO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGxvYWRpbmcgYWN0aXZpdGllczonLCBlcnIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nQWN0aXZpdGllcyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gTG9hZCBkZWFsIGRvY3VtZW50c1xyXG4gIGNvbnN0IGxvYWREb2N1bWVudHMgPSBhc3luYyAoaWQpID0+IHtcclxuICAgIHNldElzTG9hZGluZ0RvY3VtZW50cyh0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IGRvY3VtZW50c0RhdGEgPSBhd2FpdCBkZWFsRG9jdW1lbnRzU2VydmljZT8uZ2V0RGVhbERvY3VtZW50cyhpZCk7XHJcbiAgICAgIHNldERvY3VtZW50cyhkb2N1bWVudHNEYXRhIHx8IFtdKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBsb2FkaW5nIGRvY3VtZW50czonLCBlcnIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nRG9jdW1lbnRzKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyBTZXQgdXAgcmVhbC10aW1lIHN1YnNjcmlwdGlvbnNcclxuICBjb25zdCBzZXR1cFJlYWx0aW1lU3Vic2NyaXB0aW9ucyA9IChpZCkgPT4ge1xyXG4gICAgLy8gU3Vic2NyaWJlIHRvIGFjdGl2aXR5IGNoYW5nZXNcclxuICAgIGNvbnN0IGFjdGl2aXR5U3ViID0gZGVhbEFjdGl2aXRpZXNTZXJ2aWNlPy5zdWJzY3JpYmVUb0FjdGl2aXR5Q2hhbmdlcyhpZCwgKHBheWxvYWQpID0+IHtcclxuICAgICAgaGFuZGxlQWN0aXZpdHlDaGFuZ2UocGF5bG9hZCk7XHJcbiAgICB9KTtcclxuICAgIHNldEFjdGl2aXR5Q2hhbm5lbChhY3Rpdml0eVN1Yik7XHJcblxyXG4gICAgLy8gU3Vic2NyaWJlIHRvIGRvY3VtZW50IGNoYW5nZXNcclxuICAgIGNvbnN0IGRvY3VtZW50U3ViID0gZGVhbERvY3VtZW50c1NlcnZpY2U/LnN1YnNjcmliZVRvRG9jdW1lbnRDaGFuZ2VzKGlkLCAocGF5bG9hZCkgPT4ge1xyXG4gICAgICBoYW5kbGVEb2N1bWVudENoYW5nZShwYXlsb2FkKTtcclxuICAgIH0pO1xyXG4gICAgc2V0RG9jdW1lbnRDaGFubmVsKGRvY3VtZW50U3ViKTtcclxuICB9O1xyXG5cclxuICAvLyBIYW5kbGUgcmVhbC10aW1lIGFjdGl2aXR5IGNoYW5nZXNcclxuICBjb25zdCBoYW5kbGVBY3Rpdml0eUNoYW5nZSA9IHVzZUNhbGxiYWNrKChwYXlsb2FkKSA9PiB7XHJcbiAgICBjb25zdCB7IGV2ZW50VHlwZSwgbmV3OiBuZXdSZWNvcmQsIG9sZDogb2xkUmVjb3JkIH0gPSBwYXlsb2FkO1xyXG4gICAgXHJcbiAgICBzZXRBY3Rpdml0aWVzKHByZXYgPT4ge1xyXG4gICAgICBzd2l0Y2ggKGV2ZW50VHlwZSkge1xyXG4gICAgICAgIGNhc2UgJ0lOU0VSVCc6XHJcbiAgICAgICAgICAvLyBUcmFuc2Zvcm0gbmV3IHJlY29yZCBmb3IgVUlcclxuICAgICAgICAgIGNvbnN0IG5ld0FjdGl2aXR5ID0ge1xyXG4gICAgICAgICAgICBpZDogbmV3UmVjb3JkPy5pZCxcclxuICAgICAgICAgICAgdHlwZTogbmV3UmVjb3JkPy50eXBlLFxyXG4gICAgICAgICAgICB0aXRsZTogbmV3UmVjb3JkPy5zdWJqZWN0LFxyXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogbmV3UmVjb3JkPy5kZXNjcmlwdGlvbixcclxuICAgICAgICAgICAgdGltZXN0YW1wOiBuZXdSZWNvcmQ/LmNyZWF0ZWRfYXQsXHJcbiAgICAgICAgICAgIHVzZXI6ICdVbmtub3duIFVzZXInLCAvLyBXaWxsIGJlIHBvcHVsYXRlZCBieSByZWxvYWRcclxuICAgICAgICAgICAgZGVhbElkOiBuZXdSZWNvcmQ/LmRlYWxfaWRcclxuICAgICAgICAgIH07XHJcbiAgICAgICAgICByZXR1cm4gW25ld0FjdGl2aXR5LCAuLi5wcmV2XTtcclxuICAgICAgICAgIFxyXG4gICAgICAgIGNhc2UgJ0RFTEVURSc6XHJcbiAgICAgICAgICByZXR1cm4gcHJldj8uZmlsdGVyKGFjdGl2aXR5ID0+IGFjdGl2aXR5Py5pZCAhPT0gb2xkUmVjb3JkPy5pZCk7XHJcbiAgICAgICAgICBcclxuICAgICAgICBjYXNlICdVUERBVEUnOlxyXG4gICAgICAgICAgcmV0dXJuIHByZXY/Lm1hcChhY3Rpdml0eSA9PiBcclxuICAgICAgICAgICAgYWN0aXZpdHk/LmlkID09PSBuZXdSZWNvcmQ/LmlkIFxyXG4gICAgICAgICAgICAgID8geyAuLi5hY3Rpdml0eSwgLi4ubmV3UmVjb3JkIH1cclxuICAgICAgICAgICAgICA6IGFjdGl2aXR5XHJcbiAgICAgICAgICApO1xyXG4gICAgICAgICAgXHJcbiAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgIHJldHVybiBwcmV2O1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICB9LCBbXSk7XHJcblxyXG4gIC8vIEhhbmRsZSByZWFsLXRpbWUgZG9jdW1lbnQgY2hhbmdlc1xyXG4gIGNvbnN0IGhhbmRsZURvY3VtZW50Q2hhbmdlID0gdXNlQ2FsbGJhY2soKHBheWxvYWQpID0+IHtcclxuICAgIGNvbnN0IHsgZXZlbnRUeXBlLCBuZXc6IG5ld1JlY29yZCwgb2xkOiBvbGRSZWNvcmQgfSA9IHBheWxvYWQ7XHJcbiAgICBcclxuICAgIHNldERvY3VtZW50cyhwcmV2ID0+IHtcclxuICAgICAgc3dpdGNoIChldmVudFR5cGUpIHtcclxuICAgICAgICBjYXNlICdJTlNFUlQnOlxyXG4gICAgICAgICAgLy8gVHJhbnNmb3JtIG5ldyByZWNvcmQgZm9yIFVJXHJcbiAgICAgICAgICBjb25zdCBuZXdEb2N1bWVudCA9IHtcclxuICAgICAgICAgICAgaWQ6IG5ld1JlY29yZD8uaWQsXHJcbiAgICAgICAgICAgIG5hbWU6IG5ld1JlY29yZD8ubmFtZSxcclxuICAgICAgICAgICAgc2l6ZTogZGVhbERvY3VtZW50c1NlcnZpY2U/LmZvcm1hdEZpbGVTaXplKG5ld1JlY29yZD8uZmlsZV9zaXplKSxcclxuICAgICAgICAgICAgdHlwZTogZGVhbERvY3VtZW50c1NlcnZpY2U/LmdldEZpbGVFeHRlbnNpb24obmV3UmVjb3JkPy5uYW1lKSxcclxuICAgICAgICAgICAgdXBsb2FkZWRBdDogbmV3UmVjb3JkPy5jcmVhdGVkX2F0LFxyXG4gICAgICAgICAgICB1cGxvYWRlZEJ5OiAnVW5rbm93biBVc2VyJywgLy8gV2lsbCBiZSBwb3B1bGF0ZWQgYnkgcmVsb2FkXHJcbiAgICAgICAgICAgIGRlYWxJZDogbmV3UmVjb3JkPy5kZWFsX2lkLFxyXG4gICAgICAgICAgICBmaWxlVXJsOiBuZXdSZWNvcmQ/LmZpbGVfdXJsXHJcbiAgICAgICAgICB9O1xyXG4gICAgICAgICAgcmV0dXJuIFtuZXdEb2N1bWVudCwgLi4ucHJldl07XHJcbiAgICAgICAgICBcclxuICAgICAgICBjYXNlICdERUxFVEUnOlxyXG4gICAgICAgICAgcmV0dXJuIHByZXY/LmZpbHRlcihkb2MgPT4gZG9jPy5pZCAhPT0gb2xkUmVjb3JkPy5pZCk7XHJcbiAgICAgICAgICBcclxuICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgcmV0dXJuIHByZXY7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgLy8gQ2xlYW51cCBzdWJzY3JpcHRpb25zIG9uIHVubW91bnRcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgaWYgKGFjdGl2aXR5Q2hhbm5lbCkge1xyXG4gICAgICAgIGRlYWxBY3Rpdml0aWVzU2VydmljZT8udW5zdWJzY3JpYmVGcm9tQWN0aXZpdHlDaGFuZ2VzKGFjdGl2aXR5Q2hhbm5lbCk7XHJcbiAgICAgIH1cclxuICAgICAgaWYgKGRvY3VtZW50Q2hhbm5lbCkge1xyXG4gICAgICAgIGRlYWxEb2N1bWVudHNTZXJ2aWNlPy51bnN1YnNjcmliZUZyb21Eb2N1bWVudENoYW5nZXMoZG9jdW1lbnRDaGFubmVsKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICB9LCBbYWN0aXZpdHlDaGFubmVsLCBkb2N1bWVudENoYW5uZWxdKTtcclxuXHJcbiAgLy8gSGFuZGxlIGNyZWF0aW5nIG5ldyBkZWFsXHJcbiAgY29uc3QgaGFuZGxlQ3JlYXRlTmV3RGVhbCA9ICgpID0+IHtcclxuICAgIHNldFNlbGVjdGVkRGVhbChudWxsKTtcclxuICAgIHNldFNob3dGb3JtKHRydWUpO1xyXG4gICAgc2V0SXNMaXN0VmlldyhmYWxzZSk7XHJcbiAgICBuYXZpZ2F0ZSgnL2RlYWwtbWFuYWdlbWVudC9uZXcnKTtcclxuICB9O1xyXG5cclxuICAvLyBIYW5kbGUgZWRpdGluZyBleGlzdGluZyBkZWFsXHJcbiAgY29uc3QgaGFuZGxlRWRpdERlYWwgPSAoZGVhbCkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWREZWFsKGRlYWwpO1xyXG4gICAgc2V0U2hvd0Zvcm0odHJ1ZSk7XHJcbiAgICBzZXRJc0xpc3RWaWV3KGZhbHNlKTtcclxuICAgIG5hdmlnYXRlKGAvZGVhbC1tYW5hZ2VtZW50LyR7ZGVhbC5pZH1gKTtcclxuICB9O1xyXG5cclxuICAvLyBIYW5kbGUgZ29pbmcgYmFjayB0byBsaXN0IHZpZXdcclxuICBjb25zdCBoYW5kbGVCYWNrVG9MaXN0ID0gKCkgPT4ge1xyXG4gICAgc2V0U2hvd0Zvcm0oZmFsc2UpO1xyXG4gICAgc2V0SXNMaXN0Vmlldyh0cnVlKTtcclxuICAgIHNldFNlbGVjdGVkRGVhbChudWxsKTtcclxuICAgIHNldEVycm9yKG51bGwpO1xyXG4gICAgbmF2aWdhdGUoJy9kZWFsLW1hbmFnZW1lbnQnKTtcclxuICAgIC8vIE5vIG5lZWQgdG8gcmVmcmVzaCBkZWFscyBsaXN0IHNpbmNlIHdlIHVwZGF0ZSBzdGF0ZSBpbW1lZGlhdGVseVxyXG4gIH07XHJcblxyXG4gIC8vIExvYWQgYWxsIGRlYWxzXHJcbiAgY29uc3QgbG9hZEFsbERlYWxzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgZGVhbHNEYXRhID0gYXdhaXQgZGVhbHNTZXJ2aWNlPy5nZXRVc2VyRGVhbHMoKTtcclxuICAgICAgc2V0QWxsRGVhbHMoZGVhbHNEYXRhIHx8IFtdKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBsb2FkaW5nIGRlYWxzOicsIGVycik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gSGFuZGxlIHNhdmluZyBkZWFsIChjcmVhdGUgb3IgdXBkYXRlKVxyXG4gIGNvbnN0IGhhbmRsZVNhdmVEZWFsID0gYXN5bmMgKGRlYWxEYXRhKSA9PiB7XHJcbiAgICBpZiAoIXVzZXI/LmlkKSB7XHJcbiAgICAgIHNldEVycm9yKCdZb3UgbXVzdCBiZSBsb2dnZWQgaW4gdG8gc2F2ZSBkZWFscycpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgc2V0SXNTYXZpbmcodHJ1ZSk7XHJcbiAgICBzZXRFcnJvcihudWxsKTtcclxuICAgIFxyXG4gICAgdHJ5IHtcclxuICAgICAgbGV0IHJlc3VsdDtcclxuICAgICAgXHJcbiAgICAgIGlmIChzZWxlY3RlZERlYWw/LmlkKSB7XHJcbiAgICAgICAgLy8gVXBkYXRlIGV4aXN0aW5nIGRlYWxcclxuICAgICAgICByZXN1bHQgPSBhd2FpdCBkZWFsc1NlcnZpY2U/LnVwZGF0ZURlYWwoc2VsZWN0ZWREZWFsPy5pZCwge1xyXG4gICAgICAgICAgLi4uZGVhbERhdGEsXHJcbiAgICAgICAgICBvd25lcl9pZDogdXNlcj8uaWRcclxuICAgICAgICB9KTtcclxuICAgICAgICBcclxuICAgICAgICBpZiAocmVzdWx0KSB7XHJcbiAgICAgICAgICBzZXRTZWxlY3RlZERlYWwocmVzdWx0KTtcclxuICAgICAgICAgIC8vIFVwZGF0ZSBpbiBkZWFscyBsaXN0XHJcbiAgICAgICAgICBzZXRBbGxEZWFscyhwcmV2ID0+IHByZXYubWFwKGRlYWwgPT4gXHJcbiAgICAgICAgICAgIGRlYWwuaWQgPT09IHJlc3VsdC5pZCA/IHJlc3VsdCA6IGRlYWxcclxuICAgICAgICAgICkpO1xyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAvLyBTaG93IHN1Y2Nlc3MgdG9hc3RcclxuICAgICAgICAgIHRvYXN0LnN1Y2Nlc3MoYERlYWwgXCIke3Jlc3VsdC5uYW1lIHx8ICdVbnRpdGxlZCBEZWFsJ31cIiB1cGRhdGVkIHN1Y2Nlc3NmdWxseSFgKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgLy8gQ3JlYXRlIG5ldyBkZWFsXHJcbiAgICAgICAgcmVzdWx0ID0gYXdhaXQgZGVhbHNTZXJ2aWNlPy5jcmVhdGVEZWFsKHtcclxuICAgICAgICAgIC4uLmRlYWxEYXRhLFxyXG4gICAgICAgICAgb3duZXJfaWQ6IHVzZXI/LmlkXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgaWYgKHJlc3VsdD8uaWQpIHtcclxuICAgICAgICAgIC8vIFNob3cgc3VjY2VzcyB0b2FzdFxyXG4gICAgICAgICAgdG9hc3Quc3VjY2VzcyhgRGVhbCBcIiR7ZGVhbERhdGEubmFtZSB8fCAnVW50aXRsZWQgRGVhbCd9XCIgY3JlYXRlZCBzdWNjZXNzZnVsbHkhYCk7XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC8vIEFkZCB0byBsb2NhbCBzdGF0ZSBpbW1lZGlhdGVseSBmb3IgYmV0dGVyIFVYXHJcbiAgICAgICAgICBzZXRBbGxEZWFscyhwcmV2ID0+IFtyZXN1bHQsIC4uLnByZXZdKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdEZWFsIGNyZWF0ZWQgYnV0IG5vIElEIHJldHVybmVkJyk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIFxyXG4gICAgICAvLyBJZiB3ZSBnZXQgaGVyZSwgZXZlcnl0aGluZyB3YXMgc3VjY2Vzc2Z1bFxyXG4gICAgICBpZiAoIXNlbGVjdGVkRGVhbD8uaWQpIHtcclxuICAgICAgICAvLyBGb3IgbmV3IGRlYWxzLCBuYXZpZ2F0ZSBiYWNrIHRvIGxpc3QgYWZ0ZXIgc3VjY2Vzc2Z1bCBjcmVhdGlvblxyXG4gICAgICAgIHNldElzU2F2aW5nKGZhbHNlKTtcclxuICAgICAgICBoYW5kbGVCYWNrVG9MaXN0KCk7XHJcbiAgICAgICAgcmV0dXJuO1xyXG4gICAgICB9XHJcbiAgICAgIFxyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIHNhdmluZyBkZWFsOicsIGVycik7XHJcbiAgICAgIFxyXG4gICAgICAvLyBIYW5kbGUgc3BlY2lmaWMgZXJyb3IgY2FzZXMgd2l0aCBtb3JlIHByZWNpc2UgZXJyb3IgZGV0ZWN0aW9uXHJcbiAgICAgIGlmIChlcnI/LmNvZGUgPT09ICcyMzUwMycpIHsgLy8gRm9yZWlnbiBrZXkgdmlvbGF0aW9uXHJcbiAgICAgICAgY29uc3QgZXJyb3JNc2cgPSAnVGhlIHNlbGVjdGVkIGNvbXBhbnkgb3IgY29udGFjdCBpcyBubyBsb25nZXIgYXZhaWxhYmxlLiBQbGVhc2UgcmVmcmVzaCB0aGUgcGFnZSBhbmQgc2VsZWN0IHZhbGlkIG9wdGlvbnMuJztcclxuICAgICAgICBzZXRFcnJvcihlcnJvck1zZyk7XHJcbiAgICAgICAgdG9hc3QuZXJyb3IoZXJyb3JNc2cpO1xyXG4gICAgICB9IGVsc2UgaWYgKGVycj8uY29kZSA9PT0gJ1BHUlNUMTE2JyB8fCBlcnI/Lm1lc3NhZ2U/LmluY2x1ZGVzKCdub3QgZm91bmQnKSkge1xyXG4gICAgICAgIGNvbnN0IGVycm9yTXNnID0gJ0RlYWwgbm90IGZvdW5kLiBJdCBtYXkgaGF2ZSBiZWVuIGRlbGV0ZWQgYnkgYW5vdGhlciB1c2VyLic7XHJcbiAgICAgICAgc2V0RXJyb3IoZXJyb3JNc2cpO1xyXG4gICAgICAgIHRvYXN0LmVycm9yKGVycm9yTXNnKTtcclxuICAgICAgICBuYXZpZ2F0ZSgnL2RlYWwtbWFuYWdlbWVudCcpO1xyXG4gICAgICAgIHJldHVybjtcclxuICAgICAgfSBlbHNlIGlmIChlcnI/Lm1lc3NhZ2U/LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoJ3Blcm1pc3Npb24nKSB8fCBlcnI/Lm1lc3NhZ2U/LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoJ3BvbGljeScpKSB7XHJcbiAgICAgICAgY29uc3QgZXJyb3JNc2cgPSAnUGVybWlzc2lvbiBkZW5pZWQuIFlvdSBtYXkgbm90IGhhdmUgYWNjZXNzIHRvIG1vZGlmeSB0aGlzIGRlYWwuJztcclxuICAgICAgICBzZXRFcnJvcihlcnJvck1zZyk7XHJcbiAgICAgICAgdG9hc3QuZXJyb3IoZXJyb3JNc2cpO1xyXG4gICAgICB9IGVsc2UgaWYgKGVycj8ubWVzc2FnZT8uaW5jbHVkZXMoJ2NvbXBhbnknKSB8fCBlcnI/Lm1lc3NhZ2U/LmluY2x1ZGVzKCdzY2hlbWEgY2FjaGUnKSkge1xyXG4gICAgICAgIGNvbnN0IGVycm9yTXNnID0gJ1RoZXJlIHdhcyBhbiBpc3N1ZSBhY2Nlc3NpbmcgY29tcGFueSBpbmZvcm1hdGlvbi4gUGxlYXNlIHJlZnJlc2ggdGhlIHBhZ2UgYW5kIHRyeSBhZ2Fpbi4nO1xyXG4gICAgICAgIHNldEVycm9yKGVycm9yTXNnKTtcclxuICAgICAgICB0b2FzdC5lcnJvcihlcnJvck1zZyk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgY29uc3QgZXJyb3JNc2cgPSBlcnI/Lm1lc3NhZ2UgfHwgJ0ZhaWxlZCB0byBzYXZlIGRlYWwuIFBsZWFzZSB0cnkgYWdhaW4uJztcclxuICAgICAgICBzZXRFcnJvcihlcnJvck1zZyk7XHJcbiAgICAgICAgdG9hc3QuZXJyb3IoZXJyb3JNc2cpO1xyXG4gICAgICB9XHJcbiAgICAgIFxyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNTYXZpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIEhhbmRsZSBkZWxldGluZyBkZWFsXHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlRGVhbCA9IGFzeW5jICgpID0+IHtcclxuICAgIGlmICghc2VsZWN0ZWREZWFsPy5pZCB8fCAhdXNlcj8uaWQpIHJldHVybjtcclxuICAgIFxyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgZGVhbHNTZXJ2aWNlPy5kZWxldGVEZWFsKHNlbGVjdGVkRGVhbD8uaWQpO1xyXG4gICAgICBcclxuICAgICAgLy8gU2hvdyBzdWNjZXNzIHRvYXN0XHJcbiAgICAgIHRvYXN0LnN1Y2Nlc3MoYERlYWwgXCIke3NlbGVjdGVkRGVhbC5uYW1lIHx8ICdVbnRpdGxlZCBEZWFsJ31cIiBkZWxldGVkIHN1Y2Nlc3NmdWxseSFgKTtcclxuICAgICAgXHJcbiAgICAgIC8vIFJlbW92ZSBmcm9tIGxvY2FsIHN0YXRlXHJcbiAgICAgIHNldEFsbERlYWxzKHByZXYgPT4gcHJldi5maWx0ZXIoZGVhbCA9PiBkZWFsLmlkICE9PSBzZWxlY3RlZERlYWwuaWQpKTtcclxuICAgICAgXHJcbiAgICAgIG5hdmlnYXRlKCcvZGVhbC1tYW5hZ2VtZW50Jyk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgZGVsZXRpbmcgZGVhbDonLCBlcnIpO1xyXG4gICAgICBjb25zdCBlcnJvck1zZyA9ICdGYWlsZWQgdG8gZGVsZXRlIGRlYWwuIFBsZWFzZSB0cnkgYWdhaW4uJztcclxuICAgICAgc2V0RXJyb3IoZXJyb3JNc2cpO1xyXG4gICAgICB0b2FzdC5lcnJvcihlcnJvck1zZyk7XHJcbiAgICB9XHJcbiAgICBzZXRTaG93RGVsZXRlTW9kYWwoZmFsc2UpO1xyXG4gIH07XHJcblxyXG4gIC8vIEhhbmRsZSBjbG9uaW5nIGRlYWxcclxuICBjb25zdCBoYW5kbGVDbG9uZURlYWwgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoIXNlbGVjdGVkRGVhbCB8fCAhdXNlcj8uaWQpIHJldHVybjtcclxuICAgIFxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgY2xvbmVkRGVhbERhdGEgPSB7XHJcbiAgICAgICAgbmFtZTogYCR7c2VsZWN0ZWREZWFsPy5uYW1lfSAoQ29weSlgLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uOiBzZWxlY3RlZERlYWw/LmRlc2NyaXB0aW9uLFxyXG4gICAgICAgIHZhbHVlOiBzZWxlY3RlZERlYWw/LnZhbHVlLFxyXG4gICAgICAgIHN0YWdlOiAnbGVhZCcsXHJcbiAgICAgICAgcHJvYmFiaWxpdHk6IDEwLFxyXG4gICAgICAgIGNvbnRhY3RfaWQ6IHNlbGVjdGVkRGVhbD8uY29udGFjdF9pZCxcclxuICAgICAgICBjb21wYW55X2lkOiBzZWxlY3RlZERlYWw/LmNvbXBhbnlfaWQsXHJcbiAgICAgICAgbGVhZF9zb3VyY2U6IHNlbGVjdGVkRGVhbD8ubGVhZF9zb3VyY2UsXHJcbiAgICAgICAgb3duZXJfaWQ6IHVzZXI/LmlkXHJcbiAgICAgIH07XHJcbiAgICAgIFxyXG4gICAgICBsZXQgcmVzdWx0ID0gYXdhaXQgZGVhbHNTZXJ2aWNlPy5jcmVhdGVEZWFsKGNsb25lZERlYWxEYXRhKTtcclxuICAgICAgaWYgKHJlc3VsdD8uaWQpIHtcclxuICAgICAgICAvLyBTaG93IHN1Y2Nlc3MgdG9hc3RcclxuICAgICAgICB0b2FzdC5zdWNjZXNzKGBEZWFsIFwiJHtjbG9uZWREZWFsRGF0YS5uYW1lfVwiIGNsb25lZCBzdWNjZXNzZnVsbHkhYCk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy8gQWRkIHRvIGxvY2FsIHN0YXRlXHJcbiAgICAgICAgc2V0QWxsRGVhbHMocHJldiA9PiBbcmVzdWx0LCAuLi5wcmV2XSk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgbmF2aWdhdGUoYC9kZWFsLW1hbmFnZW1lbnQvJHtyZXN1bHQ/LmlkfWApO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgY2xvbmluZyBkZWFsOicsIGVycik7XHJcbiAgICAgIGNvbnN0IGVycm9yTXNnID0gJ0ZhaWxlZCB0byBjbG9uZSBkZWFsLiBQbGVhc2UgdHJ5IGFnYWluLic7XHJcbiAgICAgIHNldEVycm9yKGVycm9yTXNnKTtcclxuICAgICAgdG9hc3QuZXJyb3IoZXJyb3JNc2cpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIEhhbmRsZSBjcmVhdGluZyB0YXNrIChwbGFjZWhvbGRlcilcclxuICBjb25zdCBoYW5kbGVDcmVhdGVUYXNrID0gKCkgPT4ge1xyXG4gICAgLy8gVE9ETzogSW1wbGVtZW50IHRhc2sgY3JlYXRpb24gZnVuY3Rpb25hbGl0eVxyXG4gICAgXHJcbiAgICAvLyBUaGlzIHdvdWxkIHR5cGljYWxseSBvcGVuIGEgdGFzayBjcmVhdGlvbiBtb2RhbFxyXG4gIH07XHJcblxyXG4gIC8vIEhhbmRsZSBhZGRpbmcgYWN0aXZpdHlcclxuICBjb25zdCBoYW5kbGVBZGRBY3Rpdml0eSA9IGFzeW5jIChhY3Rpdml0eURhdGEpID0+IHtcclxuICAgIGlmICghc2VsZWN0ZWREZWFsPy5pZCkgcmV0dXJuO1xyXG4gICAgXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBuZXdBY3Rpdml0eSA9IGF3YWl0IGRlYWxBY3Rpdml0aWVzU2VydmljZT8uY3JlYXRlQWN0aXZpdHkoe1xyXG4gICAgICAgIC4uLmFjdGl2aXR5RGF0YSxcclxuICAgICAgICBkZWFsSWQ6IHNlbGVjdGVkRGVhbD8uaWQsXHJcbiAgICAgICAgY29udGFjdElkOiBzZWxlY3RlZERlYWw/LmNvbnRhY3RfaWRcclxuICAgICAgfSk7XHJcbiAgICAgIFxyXG4gICAgICAvLyBPcHRpbWlzdGljYWxseSBhZGQgdG8gbG9jYWwgc3RhdGUgKHJlYWwtdGltZSBzdWJzY3JpcHRpb24gd2lsbCBhbHNvIHVwZGF0ZSlcclxuICAgICAgc2V0QWN0aXZpdGllcyhwcmV2ID0+IFtuZXdBY3Rpdml0eSwgLi4ucHJldl0pO1xyXG4gICAgICBcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBhZGRpbmcgYWN0aXZpdHk6JywgZXJyKTtcclxuICAgICAgc2V0RXJyb3IoJ0ZhaWxlZCB0byBhZGQgYWN0aXZpdHkuIFBsZWFzZSB0cnkgYWdhaW4uJyk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gSGFuZGxlIGRlbGV0aW5nIGFjdGl2aXR5XHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlQWN0aXZpdHkgPSBhc3luYyAoYWN0aXZpdHlJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgZGVhbEFjdGl2aXRpZXNTZXJ2aWNlPy5kZWxldGVBY3Rpdml0eShhY3Rpdml0eUlkKTtcclxuICAgICAgXHJcbiAgICAgIC8vIE9wdGltaXN0aWNhbGx5IHJlbW92ZSBmcm9tIGxvY2FsIHN0YXRlXHJcbiAgICAgIHNldEFjdGl2aXRpZXMocHJldiA9PiBwcmV2Py5maWx0ZXIoYWN0aXZpdHkgPT4gYWN0aXZpdHk/LmlkICE9PSBhY3Rpdml0eUlkKSk7XHJcbiAgICAgIFxyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGRlbGV0aW5nIGFjdGl2aXR5OicsIGVycik7XHJcbiAgICAgIHNldEVycm9yKCdGYWlsZWQgdG8gZGVsZXRlIGFjdGl2aXR5LiBQbGVhc2UgdHJ5IGFnYWluLicpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIEhhbmRsZSB1cGxvYWRpbmcgZG9jdW1lbnRcclxuICBjb25zdCBoYW5kbGVVcGxvYWREb2N1bWVudCA9IGFzeW5jIChmaWxlLCBkb2N1bWVudFR5cGUgPSAnb3RoZXInKSA9PiB7XHJcbiAgICBpZiAoIXNlbGVjdGVkRGVhbD8uaWQpIHJldHVybjtcclxuICAgIFxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgbmV3RG9jdW1lbnQgPSBhd2FpdCBkZWFsRG9jdW1lbnRzU2VydmljZT8udXBsb2FkRG9jdW1lbnQoXHJcbiAgICAgICAgZmlsZSwgXHJcbiAgICAgICAgc2VsZWN0ZWREZWFsPy5pZCwgXHJcbiAgICAgICAgZG9jdW1lbnRUeXBlXHJcbiAgICAgICk7XHJcbiAgICAgIFxyXG4gICAgICAvLyBPcHRpbWlzdGljYWxseSBhZGQgdG8gbG9jYWwgc3RhdGVcclxuICAgICAgc2V0RG9jdW1lbnRzKHByZXYgPT4gW25ld0RvY3VtZW50LCAuLi5wcmV2XSk7XHJcbiAgICAgIFxyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIHVwbG9hZGluZyBkb2N1bWVudDonLCBlcnIpO1xyXG4gICAgICBzZXRFcnJvcignRmFpbGVkIHRvIHVwbG9hZCBkb2N1bWVudC4gUGxlYXNlIHRyeSBhZ2Fpbi4nKTtcclxuICAgICAgdGhyb3cgZXJyOyAvLyBSZS10aHJvdyBmb3IgY29tcG9uZW50IGhhbmRsaW5nXHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gSGFuZGxlIGRlbGV0aW5nIGRvY3VtZW50XHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlRG9jdW1lbnQgPSBhc3luYyAoZG9jdW1lbnRJZCwgZmlsZVBhdGgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGRlYWxEb2N1bWVudHNTZXJ2aWNlPy5kZWxldGVEb2N1bWVudChkb2N1bWVudElkLCBmaWxlUGF0aCk7XHJcbiAgICAgIFxyXG4gICAgICAvLyBPcHRpbWlzdGljYWxseSByZW1vdmUgZnJvbSBsb2NhbCBzdGF0ZVxyXG4gICAgICBzZXREb2N1bWVudHMocHJldiA9PiBwcmV2Py5maWx0ZXIoZG9jID0+IGRvYz8uaWQgIT09IGRvY3VtZW50SWQpKTtcclxuICAgICAgXHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgZGVsZXRpbmcgZG9jdW1lbnQ6JywgZXJyKTtcclxuICAgICAgc2V0RXJyb3IoJ0ZhaWxlZCB0byBkZWxldGUgZG9jdW1lbnQuIFBsZWFzZSB0cnkgYWdhaW4uJyk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gTG9hZGluZyBzdGF0ZVxyXG4gIGlmIChpc0xvYWRpbmcpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGJnLWJhY2tncm91bmRcIj5cclxuICAgICAgICA8SGVhZGVyIC8+XHJcbiAgICAgICAgPG1haW4gY2xhc3NOYW1lPVwicHQtMTZcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS04XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctN3hsIG14LWF1dG9cIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGgtOTZcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluIHJvdW5kZWQtZnVsbCBoLTggdy04IGJvcmRlci1iLTIgYm9yZGVyLXByaW1hcnlcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC10ZXh0LXNlY29uZGFyeVwiPkxvYWRpbmcgZGVhbC4uLjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvbWFpbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgLy8gRXJyb3Igc3RhdGVcclxuICBcclxuXHJcbiAgaWYgKGVycm9yICYmICFzZWxlY3RlZERlYWwgJiYgIWlzTGlzdFZpZXcpIHtcclxuICAgIFxyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctYmFja2dyb3VuZFwiPlxyXG4gICAgICAgIDxIZWFkZXIgLz5cclxuICAgICAgICA8bWFpbiBjbGFzc05hbWU9XCJwdC0xNlwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC02IHB5LThcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy03eGwgbXgtYXV0b1wiPlxyXG4gICAgICAgICAgICAgIDxCcmVhZGNydW1iIC8+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS0xMlwiPlxyXG4gICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIkFsZXJ0Q2lyY2xlXCIgc2l6ZT17NDh9IGNsYXNzTmFtZT1cInRleHQtdGV4dC10ZXJ0aWFyeSBteC1hdXRvIG1iLTRcIiAvPlxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LXRleHQtcHJpbWFyeSBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZERlYWwgPT09IG51bGwgJiYgZGVhbElkICE9PSAnbmV3JyA/ICdEZWFsIE5vdCBGb3VuZCcgOiAnRXJyb3InfVxyXG4gICAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtdGV4dC1zZWNvbmRhcnkgbWItNlwiPntlcnJvcn08L3A+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKCcvc2FsZXMtZGFzaGJvYXJkJyl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQmFjayB0byBEYXNoYm9hcmRcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvbWFpbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy1iYWNrZ3JvdW5kXCI+XHJcbiAgICAgIDxIZWFkZXIgLz5cclxuICAgICAgPG1haW4gY2xhc3NOYW1lPVwicHQtMTZcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcHktOFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy03eGwgbXgtYXV0b1wiPlxyXG4gICAgICAgICAgICA8QnJlYWRjcnVtYiAvPlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgey8qIEVycm9yIEFsZXJ0ICovfVxyXG4gICAgICAgICAgICB7ZXJyb3IgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZXJyb3ItNTAgYm9yZGVyIGJvcmRlci1lcnJvci0yMDAgdGV4dC1lcnJvciBwLTQgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIkFsZXJ0Q2lyY2xlXCIgc2l6ZT17MjB9IC8+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuPntlcnJvcn08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEVycm9yKG51bGwpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWVycm9yIGhvdmVyOnRleHQtZXJyb3ItNjAwXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIlhcIiBzaXplPXsxNn0gLz5cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgey8qIFBhZ2UgSGVhZGVyICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbGc6ZmxleC1yb3cgbGc6aXRlbXMtY2VudGVyIGxnOmp1c3RpZnktYmV0d2VlbiBtYi04XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00IGxnOm1iLTBcIj5cclxuICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC10ZXh0LXByaW1hcnkgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICB7aXNMaXN0VmlldyA/ICdEZWFsIE1hbmFnZW1lbnQnIDogKHNlbGVjdGVkRGVhbD8ubmFtZSB8fCAnTmV3IERlYWwnKX1cclxuICAgICAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtNCB0ZXh0LXNtIHRleHQtdGV4dC1zZWNvbmRhcnlcIj5cclxuICAgICAgICAgICAgICAgICAge2lzTGlzdFZpZXcgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+TWFuYWdlIGFsbCB5b3VyIGRlYWxzPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWREZWFsPy5pZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+RGVhbCBJRDogI3tzZWxlY3RlZERlYWw/LmlkfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj7igKI8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZERlYWw/LmNyZWF0ZWRfYXQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkNyZWF0ZWQ6IHtuZXcgRGF0ZShzZWxlY3RlZERlYWwuY3JlYXRlZF9hdCk/LnRvTG9jYWxlRGF0ZVN0cmluZygpfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj7igKI8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZERlYWw/LnVwZGF0ZWRfYXQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5MYXN0IHVwZGF0ZWQ6IHtuZXcgRGF0ZShzZWxlY3RlZERlYWwudXBkYXRlZF9hdCk/LnRvTG9jYWxlRGF0ZVN0cmluZygpfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtM1wiPlxyXG4gICAgICAgICAgICAgICAge2lzTGlzdFZpZXcgPyAoXHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDcmVhdGVOZXdEZWFsfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5IGZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMlwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiUGx1c1wiIHNpemU9ezE2fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPkNyZWF0ZSBEZWFsPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQmFja1RvTGlzdH1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1zZWNvbmRhcnkgZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiQXJyb3dMZWZ0XCIgc2l6ZT17MTZ9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5CYWNrIHRvIExpc3Q8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkRGVhbD8uaWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPERlYWxBY3Rpb25zXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uU2F2ZT17KCkgPT4gaGFuZGxlU2F2ZURlYWwoc2VsZWN0ZWREZWFsKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25EZWxldGU9eygpID0+IHNldFNob3dEZWxldGVNb2RhbCh0cnVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbG9uZT17aGFuZGxlQ2xvbmVEZWFsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNyZWF0ZVRhc2s9e2hhbmRsZUNyZWF0ZVRhc2t9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzU2F2aW5nPXtpc1NhdmluZ31cclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBNYWluIENvbnRlbnQgKi99XHJcbiAgICAgICAgICAgIHtpc0xpc3RWaWV3ID8gKFxyXG4gICAgICAgICAgICAgIC8vIERlYWxzIExpc3QgVmlld1xyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc3VyZmFjZSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItYm9yZGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNiBib3JkZXItYiBib3JkZXItYm9yZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXRleHQtcHJpbWFyeVwiPkFsbCBEZWFsczwvaDI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBWaWV3IFRvZ2dsZSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgYmctZ3JheS0xMDAgcm91bmRlZC1sZyBwLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzR3JpZFZpZXcoZmFsc2UpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMSBweC0zIHB5LTEuNSByb3VuZGVkLW1kIHRleHQtc20gZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1jb2xvcnMgJHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICFpc0dyaWRWaWV3XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXdoaXRlIHRleHQtcHJpbWFyeSBzaGFkb3ctc20nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ3RleHQtZ3JheS02MDAgaG92ZXI6dGV4dC1ncmF5LTkwMCdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJMaXN0XCIgc2l6ZT17MTZ9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+TGlzdDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc0dyaWRWaWV3KHRydWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMSBweC0zIHB5LTEuNSByb3VuZGVkLW1kIHRleHQtc20gZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1jb2xvcnMgJHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzR3JpZFZpZXdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctd2hpdGUgdGV4dC1wcmltYXJ5IHNoYWRvdy1zbSdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAndGV4dC1ncmF5LTYwMCBob3Zlcjp0ZXh0LWdyYXktOTAwJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIkdyaWRcIiBzaXplPXsxNn0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5HcmlkPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtdGV4dC1zZWNvbmRhcnlcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2ZpbHRlcmVkRGVhbHMubGVuZ3RofSBkZWFse2ZpbHRlcmVkRGVhbHMubGVuZ3RoICE9PSAxID8gJ3MnIDogJyd9IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRTdGFnZUZpbHRlciAhPT0gJ2FsbCcgJiYgYCAoJHthbGxEZWFscy5sZW5ndGh9IHRvdGFsKWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICB7LyogU3RhZ2UgRmlsdGVyICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkU3RhZ2VGaWx0ZXIoJ2FsbCcpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0zIHB5LTEuNSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHJvdW5kZWQtbWQgdHJhbnNpdGlvbi1jb2xvcnMgJHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZFN0YWdlRmlsdGVyID09PSAnYWxsJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctcHJpbWFyeSB0ZXh0LXdoaXRlJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctZ3JheS0xMDAgdGV4dC1ncmF5LTcwMCBob3ZlcjpiZy1ncmF5LTIwMCdcclxuICAgICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEFsbCBTdGFnZXMgKHthbGxEZWFscy5sZW5ndGh9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7c3RhZ2VzLm1hcChzdGFnZSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHN0YWdlQ291bnQgPSBhbGxEZWFscy5maWx0ZXIoZGVhbCA9PiBkZWFsLnN0YWdlID09PSBzdGFnZS52YWx1ZSkubGVuZ3RoO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17c3RhZ2UudmFsdWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZFN0YWdlRmlsdGVyKHN0YWdlLnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTMgcHktMS41IHRleHQtc20gZm9udC1tZWRpdW0gcm91bmRlZC1tZCB0cmFuc2l0aW9uLWNvbG9ycyAke1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZFN0YWdlRmlsdGVyID09PSBzdGFnZS52YWx1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXByaW1hcnkgdGV4dC13aGl0ZSdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IGAke3N0YWdlLmNvbG9yfSBob3ZlcjpvcGFjaXR5LTgwYFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3N0YWdlLmxhYmVsfSAoe3N0YWdlQ291bnR9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIHtpc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC04IHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW4gcm91bmRlZC1mdWxsIGgtOCB3LTggYm9yZGVyLWItMiBib3JkZXItcHJpbWFyeSBteC1hdXRvIG1iLTRcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+TG9hZGluZyBkZWFscy4uLjwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApIDogZmlsdGVyZWREZWFscy5sZW5ndGggPT09IDAgPyAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC04IHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIlBhY2thZ2VcIiBzaXplPXs0OH0gY2xhc3NOYW1lPVwidGV4dC10ZXh0LXRlcnRpYXJ5IG14LWF1dG8gbWItNFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkU3RhZ2VGaWx0ZXIgPT09ICdhbGwnID8gJ05vIGRlYWxzIHlldCcgOiBgTm8gZGVhbHMgaW4gJHtzdGFnZXMuZmluZChzID0+IHMudmFsdWUgPT09IHNlbGVjdGVkU3RhZ2VGaWx0ZXIpPy5sYWJlbH0gc3RhZ2VgfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC10ZXh0LXNlY29uZGFyeSBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRTdGFnZUZpbHRlciA9PT0gJ2FsbCcgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gJ0NyZWF0ZSB5b3VyIGZpcnN0IGRlYWwgdG8gZ2V0IHN0YXJ0ZWQnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogJ1RyeSBzZWxlY3RpbmcgYSBkaWZmZXJlbnQgc3RhZ2Ugb3IgY3JlYXRlIGEgbmV3IGRlYWwnXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZFN0YWdlRmlsdGVyID09PSAnYWxsJyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUNyZWF0ZU5ld0RlYWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQ3JlYXRlIERlYWxcclxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKSA6IGlzR3JpZFZpZXcgPyAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPERlYWxzR3JpZFZpZXdcclxuICAgICAgICAgICAgICAgICAgICAgIGRlYWxzPXtmaWx0ZXJlZERlYWxzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgc3RhZ2VzPXtzdGFnZXN9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkVkaXREZWFsPXtoYW5kbGVFZGl0RGVhbH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC02IHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC10ZXh0LXNlY29uZGFyeSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5EZWFsPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNiBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1zZWNvbmRhcnkgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+U3RhZ2U8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC02IHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC10ZXh0LXNlY29uZGFyeSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5WYWx1ZTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTYgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXRleHQtc2Vjb25kYXJ5IHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlByb2JhYmlsaXR5PC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNiBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1zZWNvbmRhcnkgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+Q3JlYXRlZDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTYgcHktMyB0ZXh0LXJpZ2h0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC10ZXh0LXNlY29uZGFyeSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5BY3Rpb25zPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGl2aWRlLXkgZGl2aWRlLWJvcmRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZmlsdGVyZWREZWFscy5tYXAoKGRlYWwpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtkZWFsLmlkfSBjbGFzc05hbWU9XCJob3ZlcjpiZy1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNiBweS00IHdoaXRlc3BhY2Utbm93cmFwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5XCI+e2RlYWwubmFtZSB8fCAnVW50aXRsZWQgRGVhbCd9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtdGV4dC1zZWNvbmRhcnkgdHJ1bmNhdGUgbWF4LXcteHNcIj57ZGVhbC5kZXNjcmlwdGlvbiB8fCAnTm8gZGVzY3JpcHRpb24nfTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNiBweS00IHdoaXRlc3BhY2Utbm93cmFwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHB4LTIgcHktMSB0ZXh0LXhzIGZvbnQtbWVkaXVtIHJvdW5kZWQtZnVsbCAke1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0YWdlcy5maW5kKHMgPT4gcy52YWx1ZSA9PT0gZGVhbC5zdGFnZSk/LmNvbG9yIHx8ICdiZy1ncmF5LTEwMCB0ZXh0LWdyYXktODAwJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3N0YWdlcy5maW5kKHMgPT4gcy52YWx1ZSA9PT0gZGVhbC5zdGFnZSk/LmxhYmVsIHx8IGRlYWwuc3RhZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNiBweS00IHdoaXRlc3BhY2Utbm93cmFwIHRleHQtc20gdGV4dC10ZXh0LXByaW1hcnlcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJHsoZGVhbC52YWx1ZSB8fCAwKS50b0xvY2FsZVN0cmluZygpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC02IHB5LTQgd2hpdGVzcGFjZS1ub3dyYXAgdGV4dC1zbSB0ZXh0LXRleHQtcHJpbWFyeVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZGVhbC5wcm9iYWJpbGl0eSB8fCAwfSVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNiBweS00IHdoaXRlc3BhY2Utbm93cmFwIHRleHQtc20gdGV4dC10ZXh0LXNlY29uZGFyeVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bmV3IERhdGUoZGVhbC5jcmVhdGVkX2F0KS50b0xvY2FsZURhdGVTdHJpbmcoKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNiBweS00IHdoaXRlc3BhY2Utbm93cmFwIHRleHQtcmlnaHQgdGV4dC1zbSBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRWRpdERlYWwoZGVhbCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1wcmltYXJ5IGhvdmVyOnRleHQtcHJpbWFyeS02MDAgbXItM1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBFZGl0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgIC8vIERlYWwgRm9ybSBWaWV3IC0gU2hvdyBsb2FkaW5nIG9yIGZvcm1cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgeGw6Z3JpZC1jb2xzLTEyIGdhcC04XCI+XHJcbiAgICAgICAgICAgICAgICB7LyogTGVmdCBQYW5lbCAtIERlYWwgRm9ybSAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwieGw6Y29sLXNwYW4tOFwiPlxyXG4gICAgICAgICAgICAgICAgICB7aXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc3VyZmFjZSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItYm9yZGVyIHAtOFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFuaW1hdGUtc3BpbiByb3VuZGVkLWZ1bGwgaC04IHctOCBib3JkZXItYi0yIGJvcmRlci1wcmltYXJ5IG14LWF1dG8gbWItNFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+TG9hZGluZyBkZWFsIGZvcm0uLi48L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICA8RGVhbEZvcm1cclxuICAgICAgICAgICAgICAgICAgICAgIGRlYWw9e3NlbGVjdGVkRGVhbH1cclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnRhY3RzPXtjb250YWN0c31cclxuICAgICAgICAgICAgICAgICAgICAgIGNvbXBhbmllcz17Y29tcGFuaWVzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgc3RhZ2VzPXtzdGFnZXN9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvblN1Ym1pdD17aGFuZGxlU2F2ZURlYWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNhbmNlbD17aGFuZGxlQmFja1RvTGlzdH1cclxuICAgICAgICAgICAgICAgICAgICAgIGlzU2F2aW5nPXtpc1NhdmluZ31cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIFJpZ2h0IFBhbmVsIC0gQWN0aXZpdHkgJiBEb2N1bWVudHMgKi99XHJcbiAgICAgICAgICAgICAgICB7c2VsZWN0ZWREZWFsPy5pZCAmJiAhaXNMb2FkaW5nICYmIChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ4bDpjb2wtc3Bhbi00IHNwYWNlLXktNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxBY3Rpdml0eVRpbWVsaW5lXHJcbiAgICAgICAgICAgICAgICAgICAgICBhY3Rpdml0aWVzPXthY3Rpdml0aWVzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgbG9hZGluZz17aXNMb2FkaW5nQWN0aXZpdGllc31cclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnRhY3Q9e3NlbGVjdGVkRGVhbD8uY29udGFjdH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQWRkQWN0aXZpdHk9e2hhbmRsZUFkZEFjdGl2aXR5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25EZWxldGVBY3Rpdml0eT17aGFuZGxlRGVsZXRlQWN0aXZpdHl9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICA8RG9jdW1lbnRzU2VjdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnRzPXtkb2N1bWVudHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICBsb2FkaW5nPXtpc0xvYWRpbmdEb2N1bWVudHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICBkZWFsSWQ9e3NlbGVjdGVkRGVhbD8uaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvblVwbG9hZERvY3VtZW50PXtoYW5kbGVVcGxvYWREb2N1bWVudH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uRGVsZXRlRG9jdW1lbnQ9e2hhbmRsZURlbGV0ZURvY3VtZW50fVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L21haW4+XHJcbiAgICAgIHsvKiBEZWxldGUgQ29uZmlybWF0aW9uIE1vZGFsICovfVxyXG4gICAgICB7c2hvd0RlbGV0ZU1vZGFsICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctYmxhY2sgYmctb3BhY2l0eS01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB6LTUwXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXN1cmZhY2Ugcm91bmRlZC1sZyBwLTYgbWF4LXctbWQgdy1mdWxsIG14LTRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTMgbWItNFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIGJnLWVycm9yLTUwIHJvdW5kZWQtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIkFsZXJ0VHJpYW5nbGVcIiBzaXplPXsyMH0gY2xhc3NOYW1lPVwidGV4dC1lcnJvclwiIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXRleHQtcHJpbWFyeVwiPkRlbGV0ZSBEZWFsPC9oMz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5IG1iLTZcIj5cclxuICAgICAgICAgICAgICBBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gZGVsZXRlIFwie3NlbGVjdGVkRGVhbD8ubmFtZX1cIj8gVGhpcyBhY3Rpb24gY2Fubm90IGJlIHVuZG9uZS5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHNwYWNlLXgtM1wiPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dEZWxldGVNb2RhbChmYWxzZSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgcHgtNCBweS0yIGJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbGcgdGV4dC10ZXh0LXNlY29uZGFyeSBob3Zlcjp0ZXh0LXRleHQtcHJpbWFyeSBob3ZlcjpiZy1zdXJmYWNlLWhvdmVyIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRGVsZXRlRGVhbH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBweC00IHB5LTIgYmctZXJyb3IgdGV4dC13aGl0ZSByb3VuZGVkLWxnIGhvdmVyOmJnLWVycm9yLTYwMCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTBcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIERlbGV0ZSBEZWFsXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgRGVhbE1hbmFnZW1lbnQ7Il0sImZpbGUiOiJEOi9jdXJyZW50IHByb2plY3RzL2NsYXVkZS1jb2RlL3NyYy9wYWdlcy9kZWFsLW1hbmFnZW1lbnQvaW5kZXguanN4In0=