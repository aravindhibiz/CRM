import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/pipeline-analytics/index.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import Header from "/src/components/ui/Header.jsx";
import Breadcrumb from "/src/components/ui/Breadcrumb.jsx";
import Icon from "/src/components/AppIcon.jsx";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell, FunnelChart, Funnel, LabelList } from "/node_modules/.vite/deps/recharts.js?v=44ab9529";
import dealsService from "/src/services/dealsService.js";
import { Loader2 } from "/node_modules/.vite/deps/lucide-react.js?v=44ab9529";
const PipelineAnalytics = () => {
  _s();
  const [selectedDateRange, setSelectedDateRange] = useState("last30days");
  const [selectedTerritory, setSelectedTerritory] = useState("all");
  const [selectedRep, setSelectedRep] = useState("all");
  const [activeTab, setActiveTab] = useState("overview");
  const [isExportMenuOpen, setIsExportMenuOpen] = useState(false);
  const [pipelineFunnelData, setPipelineFunnelData] = useState([]);
  const [revenueTrendData, setRevenueTrendData] = useState([]);
  const [winRateData, setWinRateData] = useState([]);
  const [velocityMetrics, setVelocityMetrics] = useState([]);
  const [territoryData, setTerritoryData] = useState([]);
  const [repPerformanceData, setRepPerformanceData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const [pipeline, revenue, performance, winRate] = await Promise.all(
          [
            dealsService.getPipelineDeals(),
            dealsService.getRevenueData(),
            dealsService.getPerformanceMetrics(),
            dealsService.getWinRateData()
          ]
        );
        const transformedPipeline = Object.values(pipeline).map((stage) => ({
          name: stage.title,
          value: stage.deals.reduce((sum, deal) => sum + deal.value, 0),
          count: stage.deals.length,
          fill: stage.id === "lead" ? "#3B82F6" : stage.id === "qualified" ? "#6366F1" : stage.id === "proposal" ? "#8B5CF6" : stage.id === "negotiation" ? "#A855F7" : stage.id === "closed_won" ? "#10B981" : "#EF4444"
          // closed_lost
        }));
        setPipelineFunnelData(transformedPipeline);
        setRevenueTrendData(revenue);
        setWinRateData(winRate);
        setVelocityMetrics(
          [
            { metric: "Avg Deal Size", value: `${performance.avgDealSize.toLocaleString()}`, change: "", trend: "up" },
            { metric: "Win Rate", value: `${performance.conversionRate}%`, change: "", trend: "up" },
            { metric: "Deals Won", value: performance.dealsWon, change: "", trend: "up" },
            { metric: "Deals Lost", value: performance.dealsLost, change: "", trend: "down" }
          ]
        );
        setTerritoryData(
          [
            {
              name: "Global Territory",
              revenue: performance.achieved,
              deals: performance.dealsWon + performance.dealsLost,
              winRate: performance.conversionRate,
              avgDealSize: performance.avgDealSize
            }
          ]
        );
        setRepPerformanceData(
          [
            {
              name: "Current User",
              revenue: performance.achieved,
              deals: performance.dealsWon,
              quota: performance.quota,
              attainment: performance.percentage
            }
          ]
        );
      } catch (err) {
        console.error("Failed to fetch analytics data:", err);
        setError("Failed to load analytics data. Please try again.");
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);
  if (loading) {
    return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:105:6", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "105", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22min-h-screen%20bg-background%20flex%20justify-center%20items-center%22%7D", className: "min-h-screen bg-background flex justify-center items-center", children: [
      /* @__PURE__ */ jsxDEV(Loader2, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:106:8", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "106", "data-component-file": "index.jsx", "data-component-name": "Loader2", "data-component-content": "%7B%22elementName%22%3A%22Loader2%22%2C%22className%22%3A%22h-10%20w-10%20animate-spin%20text-primary%22%7D", className: "h-10 w-10 animate-spin text-primary" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
        lineNumber: 106,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:107:8", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "107", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22ml-4%20text-text-secondary%22%2C%22textContent%22%3A%22Loading%20analytics%20data...%22%7D", className: "ml-4 text-text-secondary", children: "Loading analytics data..." }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
        lineNumber: 107,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
      lineNumber: 105,
      columnNumber: 7
    }, this);
  }
  if (error) {
    return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:114:6", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "114", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22min-h-screen%20bg-background%20flex%20justify-center%20items-center%22%7D", className: "min-h-screen bg-background flex justify-center items-center", children: /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:115:8", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "115", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-error%20text-lg%22%7D", className: "text-error text-lg", children: error }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
      lineNumber: 115,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
      lineNumber: 114,
      columnNumber: 7
    }, this);
  }
  const dateRangeOptions = [
    { value: "last7days", label: "Last 7 Days" },
    { value: "last30days", label: "Last 30 Days" },
    { value: "last90days", label: "Last 90 Days" },
    { value: "thisquarter", label: "This Quarter" },
    { value: "lastyear", label: "Last Year" },
    { value: "custom", label: "Custom Range" }
  ];
  const territoryOptions = [
    { value: "all", label: "All Territories" },
    { value: "north-america", label: "North America" },
    { value: "europe", label: "Europe" },
    { value: "asia-pacific", label: "Asia Pacific" },
    { value: "latin-america", label: "Latin America" }
  ];
  const repOptions = [
    { value: "all", label: "All Representatives" },
    { value: "sarah-johnson", label: "Sarah Johnson" },
    { value: "michael-chen", label: "Michael Chen" },
    { value: "david-rodriguez", label: "David Rodriguez" },
    { value: "emily-davis", label: "Emily Davis" },
    { value: "james-wilson", label: "James Wilson" }
  ];
  const tabOptions = [
    { id: "overview", label: "Overview", icon: "BarChart3" },
    { id: "pipeline", label: "Pipeline", icon: "TrendingUp" },
    { id: "performance", label: "Performance", icon: "Target" },
    { id: "forecasting", label: "Forecasting", icon: "Calendar" }
  ];
  const exportOptions = [
    { label: "Export as PDF", icon: "FileText" },
    { label: "Export as Excel", icon: "Download" },
    { label: "Schedule Email Report", icon: "Mail" },
    { label: "Create Dashboard Widget", icon: "Plus" }
  ];
  const formatCurrency = (value) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    })?.format(value);
  };
  const formatPercentage = (value) => {
    return `${value?.toFixed(1)}%`;
  };
  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload?.length) {
      return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:176:8", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "176", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20border%20border-border%20rounded-lg%20shadow-lg%20p-3%22%7D", className: "bg-surface border border-border rounded-lg shadow-lg p-3", children: [
        /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:177:10", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "177", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%20font-normal%20text-text-primary%20mb-2%22%7D", className: "text-sm font-normal text-text-primary mb-2", children: label }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
          lineNumber: 177,
          columnNumber: 11
        }, this),
        payload?.map(
          (entry, index) => /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:179:10", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "179", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%22%2C%22textContent%22%3A%22%3A%22%7D", className: "text-sm", style: { color: entry?.color }, children: [
            entry?.name,
            ": ",
            typeof entry?.value === "number" && entry?.value > 1e3 ? formatCurrency(entry?.value) : entry?.value
          ] }, index, true, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 179,
            columnNumber: 11
          }, this)
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
        lineNumber: 176,
        columnNumber: 9
      }, this);
    }
    return null;
  };
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:190:4", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "190", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22min-h-screen%20bg-background%22%7D", className: "min-h-screen bg-background", children: [
    /* @__PURE__ */ jsxDEV(Header, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:191:6", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "191", "data-component-file": "index.jsx", "data-component-name": "Header", "data-component-content": "%7B%22elementName%22%3A%22Header%22%7D" }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
      lineNumber: 191,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("main", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:192:6", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "192", "data-component-file": "index.jsx", "data-component-name": "main", "data-component-content": "%7B%22elementName%22%3A%22main%22%2C%22className%22%3A%22pt-16%22%7D", className: "pt-16", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:193:8", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "193", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22px-6%20py-8%22%7D", className: "px-6 py-8", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:194:10", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "194", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22max-w-7xl%20mx-auto%22%7D", className: "max-w-7xl mx-auto", children: [
      /* @__PURE__ */ jsxDEV(Breadcrumb, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:195:12", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "195", "data-component-file": "index.jsx", "data-component-name": "Breadcrumb", "data-component-content": "%7B%22elementName%22%3A%22Breadcrumb%22%7D" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
        lineNumber: 195,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:198:12", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "198", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20flex-col%20lg%3Aflex-row%20lg%3Aitems-center%20lg%3Ajustify-between%20mb-8%22%7D", className: "flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:199:14", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "199", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("h1", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:200:16", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "200", "data-component-file": "index.jsx", "data-component-name": "h1", "data-component-content": "%7B%22elementName%22%3A%22h1%22%2C%22className%22%3A%22text-3xl%20font-bold%20text-text-primary%20mb-2%22%2C%22textContent%22%3A%22Pipeline%20Analytics%22%7D", className: "text-3xl font-bold text-text-primary mb-2", children: "Pipeline Analytics" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 200,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:201:16", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "201", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%22%2C%22textContent%22%3A%22Comprehensive%20sales%20performance%20insights%20and%20forecasting%22%7D", className: "text-text-secondary", children: "Comprehensive sales performance insights and forecasting" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 201,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
          lineNumber: 199,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:204:14", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "204", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-3%20mt-4%20lg%3Amt-0%22%7D", className: "flex items-center space-x-3 mt-4 lg:mt-0", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:205:16", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "205", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22relative%22%7D", className: "relative", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:206:18",
                "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx",
                "data-component-line": "206",
                "data-component-file": "index.jsx",
                "data-component-name": "button",
                "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22btn-primary%20flex%20items-center%20space-x-2%22%7D",
                onClick: () => setIsExportMenuOpen(!isExportMenuOpen),
                className: "btn-primary flex items-center space-x-2",
                children: [
                  /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:210:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "210", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Download%22%7D", name: "Download", size: 16 }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                    lineNumber: 210,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:211:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "211", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Export%22%7D", children: "Export" }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                    lineNumber: 211,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:212:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "212", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22ChevronDown%22%7D", name: "ChevronDown", size: 14 }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                    lineNumber: 212,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 206,
                columnNumber: 19
              },
              this
            ),
            isExportMenuOpen && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:216:18", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "216", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22absolute%20right-0%20mt-2%20w-56%20bg-surface%20rounded-lg%20shadow-lg%20border%20border-border%20z-50%22%7D", className: "absolute right-0 mt-2 w-56 bg-surface rounded-lg shadow-lg border border-border z-50", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:217:22", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "217", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22py-2%22%7D", className: "py-2", children: exportOptions?.map(
              (option) => /* @__PURE__ */ jsxDEV(
                "button",
                {
                  "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:219:22",
                  "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx",
                  "data-component-line": "219",
                  "data-component-file": "index.jsx",
                  "data-component-name": "button",
                  "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22w-full%20flex%20items-center%20space-x-3%20px-4%20py-2%20text-sm%20text-text-secondary%20hover%3Atext-text-primary%20hover%3Abg-surface-hover%20transition-colors%20duration-150%22%7D",
                  className: "w-full flex items-center space-x-3 px-4 py-2 text-sm text-text-secondary hover:text-text-primary hover:bg-surface-hover transition-colors duration-150",
                  onClick: () => setIsExportMenuOpen(false),
                  children: [
                    /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:224:28", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "224", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%7D", name: option?.icon, size: 16 }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                      lineNumber: 224,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:225:28", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "225", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: option?.label }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                      lineNumber: 225,
                      columnNumber: 29
                    }, this)
                  ]
                },
                option?.label,
                true,
                {
                  fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                  lineNumber: 219,
                  columnNumber: 23
                },
                this
              )
            ) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 217,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 216,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 205,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("button", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:233:16", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "233", "data-component-file": "index.jsx", "data-component-name": "button", "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22px-4%20py-2%20border%20border-border%20rounded-lg%20text-text-secondary%20hover%3Atext-text-primary%20hover%3Abg-surface-hover%20transition-all%20duration-150%20flex%20items-center%20space-x-2%22%7D", className: "px-4 py-2 border border-border rounded-lg text-text-secondary hover:text-text-primary hover:bg-surface-hover transition-all duration-150 flex items-center space-x-2", children: [
            /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:234:18", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "234", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Settings%22%7D", name: "Settings", size: 16 }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 234,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:235:18", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "235", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Customize%22%7D", children: "Customize" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 235,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 233,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
          lineNumber: 204,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
        lineNumber: 198,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:241:12", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "241", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-6%20mb-8%22%7D", className: "card p-6 mb-8", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:242:14", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "242", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20md%3Agrid-cols-2%20lg%3Agrid-cols-4%20gap-4%22%7D", className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:243:16", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "243", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:244:18", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "244", "data-component-file": "index.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-normal%20text-text-primary%20mb-2%22%2C%22textContent%22%3A%22Date%20Range%22%7D", className: "block text-sm font-normal text-text-primary mb-2", children: "Date Range" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 244,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:245:18",
              "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx",
              "data-component-line": "245",
              "data-component-file": "index.jsx",
              "data-component-name": "select",
              "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22value%22%3A%22%5Bvar%3AselectedDateRange%5D%22%2C%22className%22%3A%22input-field%22%7D",
              value: selectedDateRange,
              onChange: (e) => setSelectedDateRange(e?.target?.value),
              className: "input-field",
              children: dateRangeOptions?.map(
                (option) => /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:251:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "251", "data-component-file": "index.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%7D", value: option?.value, children: option?.label }, option?.value, false, {
                  fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                  lineNumber: 251,
                  columnNumber: 21
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 245,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
          lineNumber: 243,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:258:16", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "258", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:259:18", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "259", "data-component-file": "index.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-normal%20text-text-primary%20mb-2%22%2C%22textContent%22%3A%22Territory%22%7D", className: "block text-sm font-normal text-text-primary mb-2", children: "Territory" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 259,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:260:18",
              "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx",
              "data-component-line": "260",
              "data-component-file": "index.jsx",
              "data-component-name": "select",
              "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22value%22%3A%22%5Bvar%3AselectedTerritory%5D%22%2C%22className%22%3A%22input-field%22%7D",
              value: selectedTerritory,
              onChange: (e) => setSelectedTerritory(e?.target?.value),
              className: "input-field",
              children: territoryOptions?.map(
                (option) => /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:266:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "266", "data-component-file": "index.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%7D", value: option?.value, children: option?.label }, option?.value, false, {
                  fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                  lineNumber: 266,
                  columnNumber: 21
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 260,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
          lineNumber: 258,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:273:16", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "273", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:274:18", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "274", "data-component-file": "index.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-normal%20text-text-primary%20mb-2%22%2C%22textContent%22%3A%22Sales%20Rep%22%7D", className: "block text-sm font-normal text-text-primary mb-2", children: "Sales Rep" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 274,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:275:18",
              "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx",
              "data-component-line": "275",
              "data-component-file": "index.jsx",
              "data-component-name": "select",
              "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22value%22%3A%22%5Bvar%3AselectedRep%5D%22%2C%22className%22%3A%22input-field%22%7D",
              value: selectedRep,
              onChange: (e) => setSelectedRep(e?.target?.value),
              className: "input-field",
              children: repOptions?.map(
                (option) => /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:281:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "281", "data-component-file": "index.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%7D", value: option?.value, children: option?.label }, option?.value, false, {
                  fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                  lineNumber: 281,
                  columnNumber: 21
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 275,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
          lineNumber: 273,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:288:16", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "288", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-end%22%7D", className: "flex items-end", children: /* @__PURE__ */ jsxDEV("button", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:289:18", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "289", "data-component-file": "index.jsx", "data-component-name": "button", "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22btn-secondary%20w-full%20flex%20items-center%20justify-center%20space-x-2%22%7D", className: "btn-secondary w-full flex items-center justify-center space-x-2", children: [
          /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:290:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "290", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Search%22%7D", name: "Search", size: 16 }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 290,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:291:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "291", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Apply%20Filters%22%7D", children: "Apply Filters" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 291,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
          lineNumber: 289,
          columnNumber: 19
        }, this) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
          lineNumber: 288,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
        lineNumber: 242,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
        lineNumber: 241,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:298:12", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "298", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22border-b%20border-border%20mb-8%22%7D", className: "border-b border-border mb-8", children: /* @__PURE__ */ jsxDEV("nav", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:299:14", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "299", "data-component-file": "index.jsx", "data-component-name": "nav", "data-component-content": "%7B%22elementName%22%3A%22nav%22%2C%22className%22%3A%22flex%20space-x-8%22%7D", className: "flex space-x-8", children: tabOptions?.map(
        (tab) => /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:301:16",
            "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx",
            "data-component-line": "301",
            "data-component-file": "index.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%7D",
            onClick: () => setActiveTab(tab?.id),
            className: `flex items-center space-x-2 py-4 px-1 border-b-2 font-normal text-sm transition-colors duration-150 ${activeTab === tab?.id ? "border-primary text-primary" : "border-transparent text-text-secondary hover:text-text-primary hover:border-border-dark"}`,
            children: [
              /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:309:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "309", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%7D", name: tab?.icon, size: 16 }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 309,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:310:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "310", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: tab?.label }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 310,
                columnNumber: 21
              }, this)
            ]
          },
          tab?.id,
          true,
          {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 301,
            columnNumber: 17
          },
          this
        )
      ) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
        lineNumber: 299,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
        lineNumber: 298,
        columnNumber: 13
      }, this),
      activeTab === "overview" && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:318:12", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "318", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-8%22%7D", className: "space-y-8", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:320:16", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "320", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20md%3Agrid-cols-2%20lg%3Agrid-cols-4%20gap-6%22%7D", className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6", children: velocityMetrics?.map(
          (metric) => /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:322:16", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "322", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-6%22%7D", className: "card p-6", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:323:22", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "323", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%20mb-2%22%7D", className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:324:24", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "324", "data-component-file": "index.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-sm%20font-normal%20text-text-secondary%22%7D", className: "text-sm font-normal text-text-secondary", children: metric?.metric }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 324,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:325:24", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "325", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", className: `flex items-center space-x-1 ${metric?.trend === "up" ? "text-success" : "text-error"}`, children: [
                /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:328:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "328", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%7D", name: metric?.trend === "up" ? "TrendingUp" : "TrendingDown", size: 14 }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                  lineNumber: 328,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:329:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "329", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-xs%20font-normal%22%7D", className: "text-xs font-normal", children: metric?.change }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                  lineNumber: 329,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 325,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 323,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:332:22", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "332", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-2xl%20font-normal%20text-text-primary%22%7D", className: "text-2xl font-normal text-text-primary", children: metric?.value }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 332,
              columnNumber: 23
            }, this)
          ] }, metric?.metric, true, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 322,
            columnNumber: 17
          }, this)
        ) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
          lineNumber: 320,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:338:16", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "338", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20lg%3Agrid-cols-2%20gap-8%22%7D", className: "grid grid-cols-1 lg:grid-cols-2 gap-8", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:340:18", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "340", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-6%22%7D", className: "card p-6", children: [
            /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:341:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "341", "data-component-file": "index.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-normal%20text-text-primary%20mb-6%22%2C%22textContent%22%3A%22Pipeline%20Funnel%22%7D", className: "text-lg font-normal text-text-primary mb-6", children: "Pipeline Funnel" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 341,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:342:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "342", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22h-80%22%7D", className: "h-80", children: /* @__PURE__ */ jsxDEV(ResponsiveContainer, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:343:22", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "343", "data-component-file": "index.jsx", "data-component-name": "ResponsiveContainer", "data-component-content": "%7B%22elementName%22%3A%22ResponsiveContainer%22%7D", width: "100%", height: "100%", children: /* @__PURE__ */ jsxDEV(FunnelChart, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:344:24", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "344", "data-component-file": "index.jsx", "data-component-name": "FunnelChart", "data-component-content": "%7B%22elementName%22%3A%22FunnelChart%22%7D", children: [
              /* @__PURE__ */ jsxDEV(Tooltip, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:345:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "345", "data-component-file": "index.jsx", "data-component-name": "Tooltip", "data-component-content": "%7B%22elementName%22%3A%22Tooltip%22%7D", content: /* @__PURE__ */ jsxDEV(CustomTooltip, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:345:44", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "345", "data-component-file": "index.jsx", "data-component-name": "CustomTooltip", "data-component-content": "%7B%22elementName%22%3A%22CustomTooltip%22%7D" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 345,
                columnNumber: 325
              }, this) }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 345,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV(
                Funnel,
                {
                  "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:346:26",
                  "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx",
                  "data-component-line": "346",
                  "data-component-file": "index.jsx",
                  "data-component-name": "Funnel",
                  "data-component-content": "%7B%22elementName%22%3A%22Funnel%22%7D",
                  dataKey: "value",
                  data: pipelineFunnelData,
                  isAnimationActive: true,
                  children: /* @__PURE__ */ jsxDEV(LabelList, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:351:28", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "351", "data-component-file": "index.jsx", "data-component-name": "LabelList", "data-component-content": "%7B%22elementName%22%3A%22LabelList%22%7D", position: "center", fill: "#fff", stroke: "none" }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                    lineNumber: 351,
                    columnNumber: 29
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                  lineNumber: 346,
                  columnNumber: 27
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 344,
              columnNumber: 25
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 343,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 342,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 340,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:359:18", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "359", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-6%22%7D", className: "card p-6", children: [
            /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:360:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "360", "data-component-file": "index.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-normal%20text-text-primary%20mb-6%22%2C%22textContent%22%3A%22Revenue%20Trend%22%7D", className: "text-lg font-normal text-text-primary mb-6", children: "Revenue Trend" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 360,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:361:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "361", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22h-80%22%7D", className: "h-80", children: /* @__PURE__ */ jsxDEV(ResponsiveContainer, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:362:22", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "362", "data-component-file": "index.jsx", "data-component-name": "ResponsiveContainer", "data-component-content": "%7B%22elementName%22%3A%22ResponsiveContainer%22%7D", width: "100%", height: "100%", children: /* @__PURE__ */ jsxDEV(LineChart, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:363:24", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "363", "data-component-file": "index.jsx", "data-component-name": "LineChart", "data-component-content": "%7B%22elementName%22%3A%22LineChart%22%7D", data: revenueTrendData, children: [
              /* @__PURE__ */ jsxDEV(CartesianGrid, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:364:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "364", "data-component-file": "index.jsx", "data-component-name": "CartesianGrid", "data-component-content": "%7B%22elementName%22%3A%22CartesianGrid%22%7D", strokeDasharray: "3 3", stroke: "#E5E7EB" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 364,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV(XAxis, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:365:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "365", "data-component-file": "index.jsx", "data-component-name": "XAxis", "data-component-content": "%7B%22elementName%22%3A%22XAxis%22%7D", dataKey: "month", stroke: "#6B7280" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 365,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV(YAxis, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:366:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "366", "data-component-file": "index.jsx", "data-component-name": "YAxis", "data-component-content": "%7B%22elementName%22%3A%22YAxis%22%7D", stroke: "#6B7280", tickFormatter: (value) => `$${value / 1e3}k` }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 366,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV(Tooltip, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:367:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "367", "data-component-file": "index.jsx", "data-component-name": "Tooltip", "data-component-content": "%7B%22elementName%22%3A%22Tooltip%22%7D", content: /* @__PURE__ */ jsxDEV(CustomTooltip, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:367:44", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "367", "data-component-file": "index.jsx", "data-component-name": "CustomTooltip", "data-component-content": "%7B%22elementName%22%3A%22CustomTooltip%22%7D" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 367,
                columnNumber: 325
              }, this) }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 367,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV(Line, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:368:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "368", "data-component-file": "index.jsx", "data-component-name": "Line", "data-component-content": "%7B%22elementName%22%3A%22Line%22%2C%22type%22%3A%22monotone%22%2C%22name%22%3A%22Actual%22%7D", type: "monotone", dataKey: "actual", stroke: "#3B82F6", strokeWidth: 3, name: "Actual" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 368,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV(Line, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:369:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "369", "data-component-file": "index.jsx", "data-component-name": "Line", "data-component-content": "%7B%22elementName%22%3A%22Line%22%2C%22type%22%3A%22monotone%22%2C%22name%22%3A%22Forecast%22%7D", type: "monotone", dataKey: "forecast", stroke: "#6366F1", strokeWidth: 2, strokeDasharray: "5 5", name: "Forecast" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 369,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV(Line, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:370:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "370", "data-component-file": "index.jsx", "data-component-name": "Line", "data-component-content": "%7B%22elementName%22%3A%22Line%22%2C%22type%22%3A%22monotone%22%2C%22name%22%3A%22Target%22%7D", type: "monotone", dataKey: "target", stroke: "#10B981", strokeWidth: 2, name: "Target" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 370,
                columnNumber: 27
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 363,
              columnNumber: 25
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 362,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 361,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 359,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
          lineNumber: 338,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:378:16", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "378", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-6%22%7D", className: "card p-6", children: [
          /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:379:18", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "379", "data-component-file": "index.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-normal%20text-text-primary%20mb-6%22%2C%22textContent%22%3A%22Win%20Rate%20Analysis%22%7D", className: "text-lg font-normal text-text-primary mb-6", children: "Win Rate Analysis" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 379,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:380:18", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "380", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22h-80%22%7D", className: "h-80", children: /* @__PURE__ */ jsxDEV(ResponsiveContainer, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:381:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "381", "data-component-file": "index.jsx", "data-component-name": "ResponsiveContainer", "data-component-content": "%7B%22elementName%22%3A%22ResponsiveContainer%22%7D", width: "100%", height: "100%", children: /* @__PURE__ */ jsxDEV(BarChart, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:382:22", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "382", "data-component-file": "index.jsx", "data-component-name": "BarChart", "data-component-content": "%7B%22elementName%22%3A%22BarChart%22%7D", data: winRateData, children: [
            /* @__PURE__ */ jsxDEV(CartesianGrid, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:383:24", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "383", "data-component-file": "index.jsx", "data-component-name": "CartesianGrid", "data-component-content": "%7B%22elementName%22%3A%22CartesianGrid%22%7D", strokeDasharray: "3 3", stroke: "#E5E7EB" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 383,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(XAxis, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:384:24", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "384", "data-component-file": "index.jsx", "data-component-name": "XAxis", "data-component-content": "%7B%22elementName%22%3A%22XAxis%22%7D", dataKey: "period", stroke: "#6B7280" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 384,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(YAxis, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:385:24", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "385", "data-component-file": "index.jsx", "data-component-name": "YAxis", "data-component-content": "%7B%22elementName%22%3A%22YAxis%22%7D", stroke: "#6B7280", tickFormatter: (value) => `${value}%` }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 385,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(Tooltip, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:386:24", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "386", "data-component-file": "index.jsx", "data-component-name": "Tooltip", "data-component-content": "%7B%22elementName%22%3A%22Tooltip%22%7D", content: /* @__PURE__ */ jsxDEV(CustomTooltip, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:386:42", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "386", "data-component-file": "index.jsx", "data-component-name": "CustomTooltip", "data-component-content": "%7B%22elementName%22%3A%22CustomTooltip%22%7D" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 386,
              columnNumber: 323
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 386,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(Bar, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:387:24", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "387", "data-component-file": "index.jsx", "data-component-name": "Bar", "data-component-content": "%7B%22elementName%22%3A%22Bar%22%2C%22name%22%3A%22Win%20Rate%20%25%22%7D", dataKey: "winRate", fill: "#3B82F6", name: "Win Rate %" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 387,
              columnNumber: 25
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 382,
            columnNumber: 23
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 381,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 380,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
          lineNumber: 378,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
        lineNumber: 318,
        columnNumber: 13
      }, this),
      activeTab === "pipeline" && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:397:12", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "397", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-8%22%7D", className: "space-y-8", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:398:16", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "398", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20lg%3Agrid-cols-3%20gap-8%22%7D", className: "grid grid-cols-1 lg:grid-cols-3 gap-8", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:400:18", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "400", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22lg%3Acol-span-2%20card%20p-6%22%7D", className: "lg:col-span-2 card p-6", children: [
            /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:401:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "401", "data-component-file": "index.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-normal%20text-text-primary%20mb-6%22%2C%22textContent%22%3A%22Pipeline%20Value%20by%20Stage%22%7D", className: "text-lg font-normal text-text-primary mb-6", children: "Pipeline Value by Stage" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 401,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:402:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "402", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22h-80%22%7D", className: "h-80", children: /* @__PURE__ */ jsxDEV(ResponsiveContainer, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:403:22", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "403", "data-component-file": "index.jsx", "data-component-name": "ResponsiveContainer", "data-component-content": "%7B%22elementName%22%3A%22ResponsiveContainer%22%7D", width: "100%", height: "100%", children: /* @__PURE__ */ jsxDEV(BarChart, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:404:24", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "404", "data-component-file": "index.jsx", "data-component-name": "BarChart", "data-component-content": "%7B%22elementName%22%3A%22BarChart%22%7D", data: pipelineFunnelData, children: [
              /* @__PURE__ */ jsxDEV(CartesianGrid, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:405:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "405", "data-component-file": "index.jsx", "data-component-name": "CartesianGrid", "data-component-content": "%7B%22elementName%22%3A%22CartesianGrid%22%7D", strokeDasharray: "3 3", stroke: "#E5E7EB" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 405,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV(XAxis, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:406:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "406", "data-component-file": "index.jsx", "data-component-name": "XAxis", "data-component-content": "%7B%22elementName%22%3A%22XAxis%22%7D", dataKey: "name", stroke: "#6B7280" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 406,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV(YAxis, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:407:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "407", "data-component-file": "index.jsx", "data-component-name": "YAxis", "data-component-content": "%7B%22elementName%22%3A%22YAxis%22%7D", stroke: "#6B7280" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 407,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV(Tooltip, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:408:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "408", "data-component-file": "index.jsx", "data-component-name": "Tooltip", "data-component-content": "%7B%22elementName%22%3A%22Tooltip%22%7D", content: /* @__PURE__ */ jsxDEV(CustomTooltip, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:408:44", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "408", "data-component-file": "index.jsx", "data-component-name": "CustomTooltip", "data-component-content": "%7B%22elementName%22%3A%22CustomTooltip%22%7D" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 408,
                columnNumber: 325
              }, this) }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 408,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV(Bar, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:409:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "409", "data-component-file": "index.jsx", "data-component-name": "Bar", "data-component-content": "%7B%22elementName%22%3A%22Bar%22%7D", dataKey: "value", fill: "#3B82F6" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 409,
                columnNumber: 27
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 404,
              columnNumber: 25
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 403,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 402,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 400,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:416:18", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "416", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-6%22%7D", className: "card p-6", children: [
            /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:417:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "417", "data-component-file": "index.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-normal%20text-text-primary%20mb-6%22%2C%22textContent%22%3A%22Pipeline%20Health%22%7D", className: "text-lg font-normal text-text-primary mb-6", children: "Pipeline Health" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 417,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:418:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "418", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-4%22%7D", className: "space-y-4", children: [
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:419:22", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "419", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:420:24", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "420", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22Total%20Pipeline%22%7D", className: "text-sm text-text-secondary", children: "Total Pipeline" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                  lineNumber: 420,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:421:24", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "421", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-lg%20font-normal%20text-text-primary%22%7D", className: "text-lg font-normal text-text-primary", children: formatCurrency((pipelineFunnelData || []).reduce((sum, stage) => sum + (stage?.value || 0), 0)) }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                  lineNumber: 421,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 419,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:423:22", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "423", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:424:24", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "424", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22Weighted%20Pipeline%22%7D", className: "text-sm text-text-secondary", children: "Weighted Pipeline" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                  lineNumber: 424,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:425:24", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "425", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-lg%20font-normal%20text-text-primary%22%7D", className: "text-lg font-normal text-text-primary", children: formatCurrency((pipelineFunnelData || []).reduce((sum, stage) => sum + (stage?.value || 0) * (stage?.name === "Leads" ? 0.1 : stage?.name === "Qualified" ? 0.25 : stage?.name === "Proposal" ? 0.5 : stage?.name === "Negotiation" ? 0.75 : 1), 0)) }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                  lineNumber: 425,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 423,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:427:22", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "427", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:428:24", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "428", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22Best%20Case%22%7D", className: "text-sm text-text-secondary", children: "Best Case" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                  lineNumber: 428,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:429:24", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "429", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-lg%20font-normal%20text-success%22%7D", className: "text-lg font-normal text-success", children: formatCurrency((pipelineFunnelData || []).reduce((sum, stage) => sum + (stage?.value || 0), 0) * 1.1) }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                  lineNumber: 429,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 427,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:431:22", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "431", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:432:24", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "432", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22Worst%20Case%22%7D", className: "text-sm text-text-secondary", children: "Worst Case" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                  lineNumber: 432,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:433:24", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "433", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-lg%20font-normal%20text-error%22%7D", className: "text-lg font-normal text-error", children: formatCurrency((pipelineFunnelData || []).reduce((sum, stage) => sum + (stage?.value || 0), 0) * 0.8) }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                  lineNumber: 433,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 431,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:435:22", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "435", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22pt-4%20border-t%20border-border%22%7D", className: "pt-4 border-t border-border", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:436:24", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "436", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:437:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "437", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22Coverage%20Ratio%22%7D", className: "text-sm text-text-secondary", children: "Coverage Ratio" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                  lineNumber: 437,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:438:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "438", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-lg%20font-normal%20text-primary%22%2C%22textContent%22%3A%22x%22%7D", className: "text-lg font-normal text-primary", children: [
                  ((pipelineFunnelData || []).reduce((sum, stage) => sum + (stage?.value || 0), 0) / 25e5).toFixed(1),
                  "x"
                ] }, void 0, true, {
                  fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                  lineNumber: 438,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 436,
                columnNumber: 25
              }, this) }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 435,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 418,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 416,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
          lineNumber: 398,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:446:16", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "446", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-6%22%7D", className: "card p-6", children: [
          /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:447:18", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "447", "data-component-file": "index.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-normal%20text-text-primary%20mb-6%22%2C%22textContent%22%3A%22Territory%20Performance%22%7D", className: "text-lg font-normal text-text-primary mb-6", children: "Territory Performance" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 447,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:448:18", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "448", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22overflow-x-auto%22%7D", className: "overflow-x-auto", children: /* @__PURE__ */ jsxDEV("table", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:449:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "449", "data-component-file": "index.jsx", "data-component-name": "table", "data-component-content": "%7B%22elementName%22%3A%22table%22%2C%22className%22%3A%22w-full%22%7D", className: "w-full", children: [
            /* @__PURE__ */ jsxDEV("thead", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:450:22", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "450", "data-component-file": "index.jsx", "data-component-name": "thead", "data-component-content": "%7B%22elementName%22%3A%22thead%22%7D", children: /* @__PURE__ */ jsxDEV("tr", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:451:24", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "451", "data-component-file": "index.jsx", "data-component-name": "tr", "data-component-content": "%7B%22elementName%22%3A%22tr%22%2C%22className%22%3A%22border-b%20border-border%22%7D", className: "border-b border-border", children: [
              /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:452:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "452", "data-component-file": "index.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22text-left%20py-3%20px-4%20text-sm%20font-normal%20text-text-secondary%22%2C%22textContent%22%3A%22Territory%22%7D", className: "text-left py-3 px-4 text-sm font-normal text-text-secondary", children: "Territory" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 452,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:453:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "453", "data-component-file": "index.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22text-right%20py-3%20px-4%20text-sm%20font-normal%20text-text-secondary%22%2C%22textContent%22%3A%22Revenue%22%7D", className: "text-right py-3 px-4 text-sm font-normal text-text-secondary", children: "Revenue" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 453,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:454:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "454", "data-component-file": "index.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22text-right%20py-3%20px-4%20text-sm%20font-normal%20text-text-secondary%22%2C%22textContent%22%3A%22Deals%22%7D", className: "text-right py-3 px-4 text-sm font-normal text-text-secondary", children: "Deals" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 454,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:455:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "455", "data-component-file": "index.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22text-right%20py-3%20px-4%20text-sm%20font-normal%20text-text-secondary%22%2C%22textContent%22%3A%22Win%20Rate%22%7D", className: "text-right py-3 px-4 text-sm font-normal text-text-secondary", children: "Win Rate" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 455,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:456:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "456", "data-component-file": "index.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22text-right%20py-3%20px-4%20text-sm%20font-normal%20text-text-secondary%22%2C%22textContent%22%3A%22Avg%20Deal%20Size%22%7D", className: "text-right py-3 px-4 text-sm font-normal text-text-secondary", children: "Avg Deal Size" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 456,
                columnNumber: 27
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 451,
              columnNumber: 25
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 450,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("tbody", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:459:22", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "459", "data-component-file": "index.jsx", "data-component-name": "tbody", "data-component-content": "%7B%22elementName%22%3A%22tbody%22%7D", children: territoryData?.map(
              (territory) => /* @__PURE__ */ jsxDEV("tr", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:461:22", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "461", "data-component-file": "index.jsx", "data-component-name": "tr", "data-component-content": "%7B%22elementName%22%3A%22tr%22%2C%22className%22%3A%22border-b%20border-border-light%20hover%3Abg-surface-hover%22%7D", className: "border-b border-border-light hover:bg-surface-hover", children: [
                /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:462:28", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "462", "data-component-file": "index.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22py-3%20px-4%20text-sm%20font-normal%20text-text-primary%22%7D", className: "py-3 px-4 text-sm font-normal text-text-primary", children: territory?.name }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                  lineNumber: 462,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:463:28", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "463", "data-component-file": "index.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22py-3%20px-4%20text-sm%20text-text-primary%20text-right%22%7D", className: "py-3 px-4 text-sm text-text-primary text-right", children: formatCurrency(territory?.revenue) }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                  lineNumber: 463,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:464:28", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "464", "data-component-file": "index.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22py-3%20px-4%20text-sm%20text-text-primary%20text-right%22%7D", className: "py-3 px-4 text-sm text-text-primary text-right", children: territory?.deals }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                  lineNumber: 464,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:465:28", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "465", "data-component-file": "index.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22py-3%20px-4%20text-sm%20text-text-primary%20text-right%22%7D", className: "py-3 px-4 text-sm text-text-primary text-right", children: formatPercentage(territory?.winRate) }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                  lineNumber: 465,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:466:28", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "466", "data-component-file": "index.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22py-3%20px-4%20text-sm%20text-text-primary%20text-right%22%7D", className: "py-3 px-4 text-sm text-text-primary text-right", children: formatCurrency(territory?.avgDealSize || territory?.revenue / territory?.deals || 0) }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                  lineNumber: 466,
                  columnNumber: 29
                }, this)
              ] }, territory?.name, true, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 461,
                columnNumber: 23
              }, this)
            ) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 459,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 449,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 448,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
          lineNumber: 446,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
        lineNumber: 397,
        columnNumber: 13
      }, this),
      activeTab === "performance" && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:478:12", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "478", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-8%22%7D", className: "space-y-8", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:480:16", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "480", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-6%22%7D", className: "card p-6", children: [
          /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:481:18", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "481", "data-component-file": "index.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-normal%20text-text-primary%20mb-6%22%2C%22textContent%22%3A%22Sales%20Representative%20Performance%22%7D", className: "text-lg font-normal text-text-primary mb-6", children: "Sales Representative Performance" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 481,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:482:18", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "482", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22overflow-x-auto%22%7D", className: "overflow-x-auto", children: /* @__PURE__ */ jsxDEV("table", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:483:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "483", "data-component-file": "index.jsx", "data-component-name": "table", "data-component-content": "%7B%22elementName%22%3A%22table%22%2C%22className%22%3A%22w-full%22%7D", className: "w-full", children: [
            /* @__PURE__ */ jsxDEV("thead", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:484:22", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "484", "data-component-file": "index.jsx", "data-component-name": "thead", "data-component-content": "%7B%22elementName%22%3A%22thead%22%7D", children: /* @__PURE__ */ jsxDEV("tr", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:485:24", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "485", "data-component-file": "index.jsx", "data-component-name": "tr", "data-component-content": "%7B%22elementName%22%3A%22tr%22%2C%22className%22%3A%22border-b%20border-border%22%7D", className: "border-b border-border", children: [
              /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:486:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "486", "data-component-file": "index.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22text-left%20py-3%20px-4%20text-sm%20font-normal%20text-text-secondary%22%2C%22textContent%22%3A%22Representative%22%7D", className: "text-left py-3 px-4 text-sm font-normal text-text-secondary", children: "Representative" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 486,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:487:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "487", "data-component-file": "index.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22text-right%20py-3%20px-4%20text-sm%20font-normal%20text-text-secondary%22%2C%22textContent%22%3A%22Revenue%22%7D", className: "text-right py-3 px-4 text-sm font-normal text-text-secondary", children: "Revenue" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 487,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:488:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "488", "data-component-file": "index.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22text-right%20py-3%20px-4%20text-sm%20font-normal%20text-text-secondary%22%2C%22textContent%22%3A%22Deals%22%7D", className: "text-right py-3 px-4 text-sm font-normal text-text-secondary", children: "Deals" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 488,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:489:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "489", "data-component-file": "index.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22text-right%20py-3%20px-4%20text-sm%20font-normal%20text-text-secondary%22%2C%22textContent%22%3A%22Quota%22%7D", className: "text-right py-3 px-4 text-sm font-normal text-text-secondary", children: "Quota" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 489,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:490:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "490", "data-component-file": "index.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22text-right%20py-3%20px-4%20text-sm%20font-normal%20text-text-secondary%22%2C%22textContent%22%3A%22Attainment%22%7D", className: "text-right py-3 px-4 text-sm font-normal text-text-secondary", children: "Attainment" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 490,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:491:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "491", "data-component-file": "index.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22text-right%20py-3%20px-4%20text-sm%20font-normal%20text-text-secondary%22%2C%22textContent%22%3A%22Progress%22%7D", className: "text-right py-3 px-4 text-sm font-normal text-text-secondary", children: "Progress" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 491,
                columnNumber: 27
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 485,
              columnNumber: 25
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 484,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("tbody", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:494:22", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "494", "data-component-file": "index.jsx", "data-component-name": "tbody", "data-component-content": "%7B%22elementName%22%3A%22tbody%22%7D", children: repPerformanceData?.map(
              (rep) => /* @__PURE__ */ jsxDEV("tr", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:496:22", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "496", "data-component-file": "index.jsx", "data-component-name": "tr", "data-component-content": "%7B%22elementName%22%3A%22tr%22%2C%22className%22%3A%22border-b%20border-border-light%20hover%3Abg-surface-hover%22%7D", className: "border-b border-border-light hover:bg-surface-hover", children: [
                /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:497:28", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "497", "data-component-file": "index.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22py-3%20px-4%20text-sm%20font-normal%20text-text-primary%22%7D", className: "py-3 px-4 text-sm font-normal text-text-primary", children: rep?.name }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                  lineNumber: 497,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:498:28", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "498", "data-component-file": "index.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22py-3%20px-4%20text-sm%20text-text-primary%20text-right%22%7D", className: "py-3 px-4 text-sm text-text-primary text-right", children: formatCurrency(rep?.revenue) }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                  lineNumber: 498,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:499:28", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "499", "data-component-file": "index.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22py-3%20px-4%20text-sm%20text-text-primary%20text-right%22%7D", className: "py-3 px-4 text-sm text-text-primary text-right", children: rep?.deals }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                  lineNumber: 499,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:500:28", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "500", "data-component-file": "index.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22py-3%20px-4%20text-sm%20text-text-primary%20text-right%22%7D", className: "py-3 px-4 text-sm text-text-primary text-right", children: formatCurrency(rep?.quota) }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                  lineNumber: 500,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:501:28", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "501", "data-component-file": "index.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22py-3%20px-4%20text-sm%20text-text-primary%20text-right%22%2C%22textContent%22%3A%22%25%22%7D", className: "py-3 px-4 text-sm text-text-primary text-right", children: [
                  rep?.attainment,
                  "%"
                ] }, void 0, true, {
                  fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                  lineNumber: 501,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:502:28", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "502", "data-component-file": "index.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22py-3%20px-4%20text-right%22%7D", className: "py-3 px-4 text-right", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:503:30", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "503", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-20%20bg-border-light%20rounded-full%20h-2%22%7D", className: "w-20 bg-border-light rounded-full h-2", children: /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:504:32",
                    "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx",
                    "data-component-line": "504",
                    "data-component-file": "index.jsx",
                    "data-component-name": "div",
                    "data-component-content": "%7B%22elementName%22%3A%22div%22%7D",
                    className: `h-2 rounded-full ${rep?.attainment >= 100 ? "bg-success" : rep?.attainment >= 80 ? "bg-warning" : "bg-primary"}`,
                    style: { width: `${Math.min(rep?.attainment, 100)}%` }
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                    lineNumber: 504,
                    columnNumber: 33
                  },
                  this
                ) }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                  lineNumber: 503,
                  columnNumber: 31
                }, this) }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                  lineNumber: 502,
                  columnNumber: 29
                }, this)
              ] }, rep?.name, true, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 496,
                columnNumber: 23
              }, this)
            ) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 494,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 483,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 482,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
          lineNumber: 480,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:518:16", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "518", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20lg%3Agrid-cols-2%20gap-8%22%7D", className: "grid grid-cols-1 lg:grid-cols-2 gap-8", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:519:18", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "519", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-6%22%7D", className: "card p-6", children: [
            /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:520:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "520", "data-component-file": "index.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-normal%20text-text-primary%20mb-6%22%2C%22textContent%22%3A%22Quota%20Attainment%22%7D", className: "text-lg font-normal text-text-primary mb-6", children: "Quota Attainment" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 520,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:521:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "521", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22h-80%22%7D", className: "h-80", children: /* @__PURE__ */ jsxDEV(ResponsiveContainer, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:522:22", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "522", "data-component-file": "index.jsx", "data-component-name": "ResponsiveContainer", "data-component-content": "%7B%22elementName%22%3A%22ResponsiveContainer%22%7D", width: "100%", height: "100%", children: /* @__PURE__ */ jsxDEV(BarChart, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:523:24", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "523", "data-component-file": "index.jsx", "data-component-name": "BarChart", "data-component-content": "%7B%22elementName%22%3A%22BarChart%22%7D", data: repPerformanceData, children: [
              /* @__PURE__ */ jsxDEV(CartesianGrid, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:524:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "524", "data-component-file": "index.jsx", "data-component-name": "CartesianGrid", "data-component-content": "%7B%22elementName%22%3A%22CartesianGrid%22%7D", strokeDasharray: "3 3", stroke: "#E5E7EB" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 524,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV(XAxis, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:525:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "525", "data-component-file": "index.jsx", "data-component-name": "XAxis", "data-component-content": "%7B%22elementName%22%3A%22XAxis%22%7D", dataKey: "name", stroke: "#6B7280", angle: -45, textAnchor: "end", height: 80 }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 525,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV(YAxis, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:526:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "526", "data-component-file": "index.jsx", "data-component-name": "YAxis", "data-component-content": "%7B%22elementName%22%3A%22YAxis%22%7D", stroke: "#6B7280", tickFormatter: (value) => `${value}%` }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 526,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV(Tooltip, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:527:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "527", "data-component-file": "index.jsx", "data-component-name": "Tooltip", "data-component-content": "%7B%22elementName%22%3A%22Tooltip%22%7D", content: /* @__PURE__ */ jsxDEV(CustomTooltip, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:527:44", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "527", "data-component-file": "index.jsx", "data-component-name": "CustomTooltip", "data-component-content": "%7B%22elementName%22%3A%22CustomTooltip%22%7D" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 527,
                columnNumber: 325
              }, this) }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 527,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV(Bar, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:528:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "528", "data-component-file": "index.jsx", "data-component-name": "Bar", "data-component-content": "%7B%22elementName%22%3A%22Bar%22%2C%22name%22%3A%22Attainment%20%25%22%7D", dataKey: "attainment", fill: "#3B82F6", name: "Attainment %" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 528,
                columnNumber: 27
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 523,
              columnNumber: 25
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 522,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 521,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 519,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:534:18", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "534", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-6%22%7D", className: "card p-6", children: [
            /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:535:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "535", "data-component-file": "index.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-normal%20text-text-primary%20mb-6%22%2C%22textContent%22%3A%22Revenue%20by%20Rep%22%7D", className: "text-lg font-normal text-text-primary mb-6", children: "Revenue by Rep" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 535,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:536:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "536", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22h-80%22%7D", className: "h-80", children: /* @__PURE__ */ jsxDEV(ResponsiveContainer, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:537:22", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "537", "data-component-file": "index.jsx", "data-component-name": "ResponsiveContainer", "data-component-content": "%7B%22elementName%22%3A%22ResponsiveContainer%22%7D", width: "100%", height: "100%", children: /* @__PURE__ */ jsxDEV(PieChart, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:538:24", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "538", "data-component-file": "index.jsx", "data-component-name": "PieChart", "data-component-content": "%7B%22elementName%22%3A%22PieChart%22%7D", children: [
              /* @__PURE__ */ jsxDEV(
                Pie,
                {
                  "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:539:26",
                  "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx",
                  "data-component-line": "539",
                  "data-component-file": "index.jsx",
                  "data-component-name": "Pie",
                  "data-component-content": "%7B%22elementName%22%3A%22Pie%22%7D",
                  data: repPerformanceData,
                  cx: "50%",
                  cy: "50%",
                  outerRadius: 100,
                  fill: "#3B82F6",
                  dataKey: "revenue",
                  label: ({ name, percent }) => `${name}: ${(percent * 100)?.toFixed(0)}%`,
                  children: repPerformanceData?.map(
                    (entry, index) => /* @__PURE__ */ jsxDEV(Cell, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:549:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "549", "data-component-file": "index.jsx", "data-component-name": "Cell", "data-component-content": "%7B%22elementName%22%3A%22Cell%22%7D", fill: `hsl(${220 + index * 30}, 70%, ${50 + index * 10}%)` }, `cell-${index}`, false, {
                      fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                      lineNumber: 549,
                      columnNumber: 27
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                  lineNumber: 539,
                  columnNumber: 27
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(Tooltip, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:552:26", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "552", "data-component-file": "index.jsx", "data-component-name": "Tooltip", "data-component-content": "%7B%22elementName%22%3A%22Tooltip%22%7D", content: /* @__PURE__ */ jsxDEV(CustomTooltip, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:552:44", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "552", "data-component-file": "index.jsx", "data-component-name": "CustomTooltip", "data-component-content": "%7B%22elementName%22%3A%22CustomTooltip%22%7D" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 552,
                columnNumber: 325
              }, this) }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 552,
                columnNumber: 27
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 538,
              columnNumber: 25
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 537,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 536,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 534,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
          lineNumber: 518,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
        lineNumber: 478,
        columnNumber: 13
      }, this),
      activeTab === "forecasting" && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:563:12", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "563", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-8%22%7D", className: "space-y-8", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:565:16", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "565", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20md%3Agrid-cols-3%20gap-6%22%7D", className: "grid grid-cols-1 md:grid-cols-3 gap-6", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:566:18", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "566", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-6%20text-center%22%7D", className: "card p-6 text-center", children: [
            /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:567:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "567", "data-component-file": "index.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-sm%20font-normal%20text-text-secondary%20mb-2%22%2C%22textContent%22%3A%22Total%20Forecast%22%7D", className: "text-sm font-normal text-text-secondary mb-2", children: "Total Forecast" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 567,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:568:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "568", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-3xl%20font-normal%20text-primary%20mb-1%22%7D", className: "text-3xl font-normal text-primary mb-1", children: formatCurrency((revenueTrendData || []).reduce((sum, month) => sum + (month?.forecast || 0), 0)) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 568,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:569:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "569", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%20text-success%20flex%20items-center%20justify-center%20space-x-1%22%7D", className: "text-sm text-success flex items-center justify-center space-x-1", children: [
              /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:570:22", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "570", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22TrendingUp%22%7D", name: "TrendingUp", size: 14 }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 570,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:571:22", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "571", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Based%20on%20expected%20close%20dates%22%7D", children: "Based on expected close dates" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
                lineNumber: 571,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 569,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 566,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:575:18", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "575", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-6%20text-center%22%7D", className: "card p-6 text-center", children: [
            /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:576:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "576", "data-component-file": "index.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-sm%20font-normal%20text-text-secondary%20mb-2%22%2C%22textContent%22%3A%22Total%20Actual%20Revenue%22%7D", className: "text-sm font-normal text-text-secondary mb-2", children: "Total Actual Revenue" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 576,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:577:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "577", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-3xl%20font-normal%20text-secondary%20mb-1%22%7D", className: "text-3xl font-normal text-secondary mb-1", children: formatCurrency((revenueTrendData || []).reduce((sum, month) => sum + (month?.actual || 0), 0)) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 577,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:578:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "578", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22From%20closed%20won%20deals%22%7D", className: "text-sm text-text-secondary", children: "From closed won deals" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 578,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 575,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:581:18", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "581", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-6%20text-center%22%7D", className: "card p-6 text-center", children: [
            /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:582:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "582", "data-component-file": "index.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-sm%20font-normal%20text-text-secondary%20mb-2%22%2C%22textContent%22%3A%22Overall%20Win%20Rate%22%7D", className: "text-sm font-normal text-text-secondary mb-2", children: "Overall Win Rate" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 582,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:583:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "583", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-3xl%20font-normal%20text-accent%20mb-1%22%7D", className: "text-3xl font-normal text-accent mb-1", children: velocityMetrics?.find((m) => m.metric === "Win Rate")?.value || "0%" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 583,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:584:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "584", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22Of%20all%20deals%22%7D", className: "text-sm text-text-secondary", children: "Of all deals" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 584,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 581,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
          lineNumber: 565,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:589:16", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "589", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-6%22%7D", className: "card p-6", children: [
          /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:590:18", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "590", "data-component-file": "index.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-normal%20text-text-primary%20mb-6%22%2C%22textContent%22%3A%22Revenue%20Forecast%20vs%20Actual%22%7D", className: "text-lg font-normal text-text-primary mb-6", children: "Revenue Forecast vs Actual" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 590,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:591:18", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "591", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22h-80%22%7D", className: "h-80", children: /* @__PURE__ */ jsxDEV(ResponsiveContainer, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:592:20", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "592", "data-component-file": "index.jsx", "data-component-name": "ResponsiveContainer", "data-component-content": "%7B%22elementName%22%3A%22ResponsiveContainer%22%7D", width: "100%", height: "100%", children: /* @__PURE__ */ jsxDEV(LineChart, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:593:22", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "593", "data-component-file": "index.jsx", "data-component-name": "LineChart", "data-component-content": "%7B%22elementName%22%3A%22LineChart%22%7D", data: revenueTrendData, children: [
            /* @__PURE__ */ jsxDEV(CartesianGrid, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:594:24", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "594", "data-component-file": "index.jsx", "data-component-name": "CartesianGrid", "data-component-content": "%7B%22elementName%22%3A%22CartesianGrid%22%7D", strokeDasharray: "3 3", stroke: "#E5E7EB" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 594,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(XAxis, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:595:24", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "595", "data-component-file": "index.jsx", "data-component-name": "XAxis", "data-component-content": "%7B%22elementName%22%3A%22XAxis%22%7D", dataKey: "month", stroke: "#6B7280" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 595,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(YAxis, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:596:24", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "596", "data-component-file": "index.jsx", "data-component-name": "YAxis", "data-component-content": "%7B%22elementName%22%3A%22YAxis%22%7D", stroke: "#6B7280", tickFormatter: (value) => `$${value / 1e3}k` }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 596,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(Tooltip, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:597:24", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "597", "data-component-file": "index.jsx", "data-component-name": "Tooltip", "data-component-content": "%7B%22elementName%22%3A%22Tooltip%22%7D", content: /* @__PURE__ */ jsxDEV(CustomTooltip, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:597:42", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "597", "data-component-file": "index.jsx", "data-component-name": "CustomTooltip", "data-component-content": "%7B%22elementName%22%3A%22CustomTooltip%22%7D" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 597,
              columnNumber: 323
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 597,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(Line, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:598:24", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "598", "data-component-file": "index.jsx", "data-component-name": "Line", "data-component-content": "%7B%22elementName%22%3A%22Line%22%2C%22type%22%3A%22monotone%22%2C%22name%22%3A%22Actual%20Revenue%22%7D", type: "monotone", dataKey: "actual", stroke: "#3B82F6", strokeWidth: 3, name: "Actual Revenue" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 598,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(Line, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:599:24", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "599", "data-component-file": "index.jsx", "data-component-name": "Line", "data-component-content": "%7B%22elementName%22%3A%22Line%22%2C%22type%22%3A%22monotone%22%2C%22name%22%3A%22Forecast%22%7D", type: "monotone", dataKey: "forecast", stroke: "#6366F1", strokeWidth: 2, strokeDasharray: "5 5", name: "Forecast" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 599,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(Line, { "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:600:24", "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx", "data-component-line": "600", "data-component-file": "index.jsx", "data-component-name": "Line", "data-component-content": "%7B%22elementName%22%3A%22Line%22%2C%22type%22%3A%22monotone%22%2C%22name%22%3A%22Target%22%7D", type: "monotone", dataKey: "target", stroke: "#10B981", strokeWidth: 2, name: "Target" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
              lineNumber: 600,
              columnNumber: 25
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 593,
            columnNumber: 23
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 592,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
            lineNumber: 591,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
          lineNumber: 589,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
        lineNumber: 563,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
      lineNumber: 194,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
      lineNumber: 193,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
      lineNumber: 192,
      columnNumber: 7
    }, this),
    isExportMenuOpen && /* @__PURE__ */ jsxDEV(
      "div",
      {
        "data-component-id": "src\\pages\\pipeline-analytics\\index.jsx:614:6",
        "data-component-path": "src\\pages\\pipeline-analytics\\index.jsx",
        "data-component-line": "614",
        "data-component-file": "index.jsx",
        "data-component-name": "div",
        "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20z-40%22%7D",
        className: "fixed inset-0 z-40",
        onClick: () => setIsExportMenuOpen(false)
      },
      void 0,
      false,
      {
        fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
        lineNumber: 614,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx",
    lineNumber: 190,
    columnNumber: 5
  }, this);
};
_s(PipelineAnalytics, "HZWsulFR9WH+HYEL3LGBqDTMdTI=");
_c = PipelineAnalytics;
export default PipelineAnalytics;
var _c;
$RefreshReg$(_c, "PipelineAnalytics");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/pipeline-analytics/index.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUdROzJCQXpHUjtBQUFnQkEsTUFBV0MsY0FBVUMsT0FBTyxzQkFBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMzRCxPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGdCQUFnQjtBQUN2QixPQUFPQyxVQUFVO0FBQ2pCLFNBQVNDLFVBQVVDLEtBQUtDLE9BQU9DLE9BQU9DLGVBQWVDLFNBQVNDLHFCQUFxQkMsV0FBV0MsTUFBTUMsVUFBVUMsS0FBS0MsTUFBTUMsYUFBYUMsUUFBUUMsaUJBQWlCO0FBQy9KLE9BQU9DLGtCQUFrQjtBQUN6QixTQUFTQyxlQUFlO0FBRXhCLE1BQU1DLG9CQUFvQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzlCLFFBQU0sQ0FBQ0MsbUJBQW1CQyxvQkFBb0IsSUFBSXpCLFNBQVMsWUFBWTtBQUN2RSxRQUFNLENBQUMwQixtQkFBbUJDLG9CQUFvQixJQUFJM0IsU0FBUyxLQUFLO0FBQ2hFLFFBQU0sQ0FBQzRCLGFBQWFDLGNBQWMsSUFBSTdCLFNBQVMsS0FBSztBQUNwRCxRQUFNLENBQUM4QixXQUFXQyxZQUFZLElBQUkvQixTQUFTLFVBQVU7QUFDckQsUUFBTSxDQUFDZ0Msa0JBQWtCQyxtQkFBbUIsSUFBSWpDLFNBQVMsS0FBSztBQUc5RCxRQUFNLENBQUNrQyxvQkFBb0JDLHFCQUFxQixJQUFJbkMsU0FBUyxFQUFFO0FBQy9ELFFBQU0sQ0FBQ29DLGtCQUFrQkMsbUJBQW1CLElBQUlyQyxTQUFTLEVBQUU7QUFDM0QsUUFBTSxDQUFDc0MsYUFBYUMsY0FBYyxJQUFJdkMsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQ3dDLGlCQUFpQkMsa0JBQWtCLElBQUl6QyxTQUFTLEVBQUU7QUFDekQsUUFBTSxDQUFDMEMsZUFBZUMsZ0JBQWdCLElBQUkzQyxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDNEMsb0JBQW9CQyxxQkFBcUIsSUFBSTdDLFNBQVMsRUFBRTtBQUMvRCxRQUFNLENBQUM4QyxTQUFTQyxVQUFVLElBQUkvQyxTQUFTLElBQUk7QUFDM0MsUUFBTSxDQUFDZ0QsT0FBT0MsUUFBUSxJQUFJakQsU0FBUyxJQUFJO0FBRXZDRCxZQUFVLE1BQU07QUFDZCxVQUFNbUQsWUFBWSxZQUFZO0FBQzVCLFVBQUk7QUFDRkgsbUJBQVcsSUFBSTtBQUVmLGNBQU0sQ0FBQ0ksVUFBVUMsU0FBU0MsYUFBYUMsT0FBTyxJQUFJLE1BQU1DLFFBQVFDO0FBQUFBLFVBQUk7QUFBQSxZQUNsRXBDLGFBQWFxQyxpQkFBaUI7QUFBQSxZQUM5QnJDLGFBQWFzQyxlQUFlO0FBQUEsWUFDNUJ0QyxhQUFhdUMsc0JBQXNCO0FBQUEsWUFDbkN2QyxhQUFhd0MsZUFBZTtBQUFBLFVBQUM7QUFBQSxRQUM5QjtBQUdELGNBQU1DLHNCQUFzQkMsT0FBT0MsT0FBT1osUUFBUSxFQUFFYSxJQUFJLENBQUFDLFdBQVU7QUFBQSxVQUNoRUMsTUFBTUQsTUFBTUU7QUFBQUEsVUFDWkMsT0FBT0gsTUFBTUksTUFBTUMsT0FBTyxDQUFDQyxLQUFLQyxTQUFTRCxNQUFNQyxLQUFLSixPQUFPLENBQUM7QUFBQSxVQUM1REssT0FBT1IsTUFBTUksTUFBTUs7QUFBQUEsVUFDbkJDLE1BQU1WLE1BQU1XLE9BQU8sU0FBUyxZQUN0QlgsTUFBTVcsT0FBTyxjQUFjLFlBQzNCWCxNQUFNVyxPQUFPLGFBQWEsWUFDMUJYLE1BQU1XLE9BQU8sZ0JBQWdCLFlBQzdCWCxNQUFNVyxPQUFPLGVBQWUsWUFBWTtBQUFBO0FBQUEsUUFDaEQsRUFBRTtBQUVGekMsOEJBQXNCMEIsbUJBQW1CO0FBQ3pDeEIsNEJBQW9CZSxPQUFPO0FBQzNCYix1QkFBZWUsT0FBTztBQVV0QmI7QUFBQUEsVUFBbUI7QUFBQSxZQUNqQixFQUFFb0MsUUFBUSxpQkFBaUJULE9BQU8sR0FBR2YsWUFBWXlCLFlBQVlDLGVBQWUsQ0FBQyxJQUFJQyxRQUFRLElBQUlDLE9BQU8sS0FBSztBQUFBLFlBQ3pHLEVBQUVKLFFBQVEsWUFBWVQsT0FBTyxHQUFHZixZQUFZNkIsY0FBYyxLQUFLRixRQUFRLElBQUlDLE9BQU8sS0FBSztBQUFBLFlBQ3ZGLEVBQUVKLFFBQVEsYUFBYVQsT0FBT2YsWUFBWThCLFVBQVVILFFBQVEsSUFBSUMsT0FBTyxLQUFLO0FBQUEsWUFDNUUsRUFBRUosUUFBUSxjQUFjVCxPQUFPZixZQUFZK0IsV0FBV0osUUFBUSxJQUFJQyxPQUFPLE9BQU87QUFBQSxVQUFDO0FBQUEsUUFDbEY7QUFJRHRDO0FBQUFBLFVBQWlCO0FBQUEsWUFDZjtBQUFBLGNBQ0V1QixNQUFNO0FBQUEsY0FDTmQsU0FBU0MsWUFBWWdDO0FBQUFBLGNBQ3JCaEIsT0FBT2hCLFlBQVk4QixXQUFXOUIsWUFBWStCO0FBQUFBLGNBQzFDOUIsU0FBU0QsWUFBWTZCO0FBQUFBLGNBQ3JCSixhQUFhekIsWUFBWXlCO0FBQUFBLFlBQzNCO0FBQUEsVUFBQztBQUFBLFFBQ0Y7QUFFRGpDO0FBQUFBLFVBQXNCO0FBQUEsWUFDcEI7QUFBQSxjQUNFcUIsTUFBTTtBQUFBLGNBQ05kLFNBQVNDLFlBQVlnQztBQUFBQSxjQUNyQmhCLE9BQU9oQixZQUFZOEI7QUFBQUEsY0FDbkJHLE9BQU9qQyxZQUFZaUM7QUFBQUEsY0FDbkJDLFlBQVlsQyxZQUFZbUM7QUFBQUEsWUFDMUI7QUFBQSxVQUFDO0FBQUEsUUFDRjtBQUFBLE1BR0gsU0FBU0MsS0FBSztBQUNaQyxnQkFBUTFDLE1BQU0sbUNBQW1DeUMsR0FBRztBQUNwRHhDLGlCQUFTLGtEQUFrRDtBQUFBLE1BQzdELFVBQUM7QUFDQ0YsbUJBQVcsS0FBSztBQUFBLE1BQ2xCO0FBQUEsSUFDRjtBQUVBRyxjQUFVO0FBQUEsRUFDWixHQUFHLEVBQUU7QUFFTCxNQUFJSixTQUFTO0FBQ1gsV0FDRSx1QkFBQyxvWkFBSSxXQUFVLCtEQUNiO0FBQUEsNkJBQUMsb1lBQVEsV0FBVSx5Q0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3RDtBQUFBLE1BQ3hELHVCQUFDLCtaQUFFLFdBQVUsNEJBQTJCLHlDQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlFO0FBQUEsU0FGbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsRUFFSjtBQUVBLE1BQUlFLE9BQU87QUFDVCxXQUNFLHVCQUFDLG9aQUFJLFdBQVUsK0RBQ2IsaUNBQUMsK1ZBQUUsV0FBVSxzQkFBc0JBLG1CQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlDLEtBRDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFFQSxRQUFNMkMsbUJBQW1CO0FBQUEsSUFDdkIsRUFBRXZCLE9BQU8sYUFBYXdCLE9BQU8sY0FBYztBQUFBLElBQzNDLEVBQUV4QixPQUFPLGNBQWN3QixPQUFPLGVBQWU7QUFBQSxJQUM3QyxFQUFFeEIsT0FBTyxjQUFjd0IsT0FBTyxlQUFlO0FBQUEsSUFDN0MsRUFBRXhCLE9BQU8sZUFBZXdCLE9BQU8sZUFBZTtBQUFBLElBQzlDLEVBQUV4QixPQUFPLFlBQVl3QixPQUFPLFlBQVk7QUFBQSxJQUN4QyxFQUFFeEIsT0FBTyxVQUFVd0IsT0FBTyxlQUFlO0FBQUEsRUFBQztBQUc1QyxRQUFNQyxtQkFBbUI7QUFBQSxJQUN2QixFQUFFekIsT0FBTyxPQUFPd0IsT0FBTyxrQkFBa0I7QUFBQSxJQUN6QyxFQUFFeEIsT0FBTyxpQkFBaUJ3QixPQUFPLGdCQUFnQjtBQUFBLElBQ2pELEVBQUV4QixPQUFPLFVBQVV3QixPQUFPLFNBQVM7QUFBQSxJQUNuQyxFQUFFeEIsT0FBTyxnQkFBZ0J3QixPQUFPLGVBQWU7QUFBQSxJQUMvQyxFQUFFeEIsT0FBTyxpQkFBaUJ3QixPQUFPLGdCQUFnQjtBQUFBLEVBQUM7QUFHcEQsUUFBTUUsYUFBYTtBQUFBLElBQ2pCLEVBQUUxQixPQUFPLE9BQU93QixPQUFPLHNCQUFzQjtBQUFBLElBQzdDLEVBQUV4QixPQUFPLGlCQUFpQndCLE9BQU8sZ0JBQWdCO0FBQUEsSUFDakQsRUFBRXhCLE9BQU8sZ0JBQWdCd0IsT0FBTyxlQUFlO0FBQUEsSUFDL0MsRUFBRXhCLE9BQU8sbUJBQW1Cd0IsT0FBTyxrQkFBa0I7QUFBQSxJQUNyRCxFQUFFeEIsT0FBTyxlQUFld0IsT0FBTyxjQUFjO0FBQUEsSUFDN0MsRUFBRXhCLE9BQU8sZ0JBQWdCd0IsT0FBTyxlQUFlO0FBQUEsRUFBQztBQUdsRCxRQUFNRyxhQUFhO0FBQUEsSUFDakIsRUFBRW5CLElBQUksWUFBWWdCLE9BQU8sWUFBWUksTUFBTSxZQUFZO0FBQUEsSUFDdkQsRUFBRXBCLElBQUksWUFBWWdCLE9BQU8sWUFBWUksTUFBTSxhQUFhO0FBQUEsSUFDeEQsRUFBRXBCLElBQUksZUFBZWdCLE9BQU8sZUFBZUksTUFBTSxTQUFTO0FBQUEsSUFDMUQsRUFBRXBCLElBQUksZUFBZWdCLE9BQU8sZUFBZUksTUFBTSxXQUFXO0FBQUEsRUFBQztBQUcvRCxRQUFNQyxnQkFBZ0I7QUFBQSxJQUNwQixFQUFFTCxPQUFPLGlCQUFpQkksTUFBTSxXQUFXO0FBQUEsSUFDM0MsRUFBRUosT0FBTyxtQkFBbUJJLE1BQU0sV0FBVztBQUFBLElBQzdDLEVBQUVKLE9BQU8seUJBQXlCSSxNQUFNLE9BQU87QUFBQSxJQUMvQyxFQUFFSixPQUFPLDJCQUEyQkksTUFBTSxPQUFPO0FBQUEsRUFBQztBQUdwRCxRQUFNRSxpQkFBaUJBLENBQUM5QixVQUFVO0FBQ2hDLFdBQU8sSUFBSStCLEtBQUtDLGFBQWEsU0FBUztBQUFBLE1BQ3BDQyxPQUFPO0FBQUEsTUFDUEMsVUFBVTtBQUFBLE1BQ1ZDLHVCQUF1QjtBQUFBLE1BQ3ZCQyx1QkFBdUI7QUFBQSxJQUN6QixDQUFDLEdBQUdDLE9BQU9yQyxLQUFLO0FBQUEsRUFDbEI7QUFFQSxRQUFNc0MsbUJBQW1CQSxDQUFDdEMsVUFBVTtBQUNsQyxXQUFPLEdBQUdBLE9BQU91QyxRQUFRLENBQUMsQ0FBQztBQUFBLEVBQzdCO0FBRUEsUUFBTUMsZ0JBQWdCQSxDQUFDLEVBQUVDLFFBQVFDLFNBQVNsQixNQUFNLE1BQU07QUFDcEQsUUFBSWlCLFVBQVVDLFdBQVdBLFNBQVNwQyxRQUFRO0FBQ3hDLGFBQ0UsdUJBQUMsbVpBQUksV0FBVSw0REFDYjtBQUFBLCtCQUFDLDRYQUFFLFdBQVUsOENBQThDa0IsbUJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUU7QUFBQSxRQUNoRWtCLFNBQVM5QztBQUFBQSxVQUFJLENBQUMrQyxPQUFPQyxVQUNwQix1QkFBQyxtWEFBYyxXQUFVLFdBQVUsT0FBTyxFQUFFQyxPQUFPRixPQUFPRSxNQUFNLEdBQzdERjtBQUFBQSxtQkFBTzdDO0FBQUFBLFlBQUs7QUFBQSxZQUFHLE9BQU82QyxPQUFPM0MsVUFBVSxZQUFZMkMsT0FBTzNDLFFBQVEsTUFBTzhCLGVBQWVhLE9BQU8zQyxLQUFLLElBQUkyQyxPQUFPM0M7QUFBQUEsZUFEMUc0QyxPQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxRQUNEO0FBQUEsV0FOSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxJQUVKO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFFQSxTQUNFLHVCQUFDLDZXQUFJLFdBQVUsOEJBQ2I7QUFBQSwyQkFBQywrVEFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU87QUFBQSxJQUNQLHVCQUFDLHlWQUFLLFdBQVUsU0FDZCxpQ0FBQyw0VkFBSSxXQUFVLGFBQ2IsaUNBQUMscVdBQUksV0FBVSxxQkFDYjtBQUFBLDZCQUFDLDRVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBVztBQUFBLE1BR1gsdUJBQUMsbWFBQUksV0FBVSxxRUFDYjtBQUFBLCtCQUFDLHVUQUNDO0FBQUEsaUNBQUMsK2FBQUcsV0FBVSw2Q0FBNEMsa0NBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRFO0FBQUEsVUFDNUUsdUJBQUMsOGJBQUUsV0FBVSx1QkFBc0Isd0VBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJGO0FBQUEsYUFGN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFFQSx1QkFBQyxvWUFBSSxXQUFVLDRDQUNiO0FBQUEsaUNBQUMsMFZBQUksV0FBVSxZQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFDQyxTQUFTLE1BQU0vRSxvQkFBb0IsQ0FBQ0QsZ0JBQWdCO0FBQUEsZ0JBQ3BELFdBQVU7QUFBQSxnQkFFVjtBQUFBLHlDQUFDLHNWQUFLLE1BQUssWUFBVyxNQUFNLE1BQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQStCO0FBQUEsa0JBQy9CLHVCQUFDLDZWQUFLLHNCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQVk7QUFBQSxrQkFDWix1QkFBQyx5VkFBSyxNQUFLLGVBQWMsTUFBTSxNQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFrQztBQUFBO0FBQUE7QUFBQSxjQU5wQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPQTtBQUFBLFlBRUNBLG9CQUNDLHVCQUFDLHdiQUFJLFdBQVUsd0ZBQ2IsaUNBQUMsc1ZBQUksV0FBVSxRQUNaaUUseUJBQWVqQztBQUFBQSxjQUFJLENBQUNrRCxXQUNuQjtBQUFBLGdCQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFFQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUyxNQUFNakYsb0JBQW9CLEtBQUs7QUFBQSxrQkFFeEM7QUFBQSwyQ0FBQyx3VEFBSyxNQUFNaUYsUUFBUWxCLE1BQU0sTUFBTSxNQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFtQztBQUFBLG9CQUNuQyx1QkFBQywwVEFBTWtCLGtCQUFRdEIsU0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFxQjtBQUFBO0FBQUE7QUFBQSxnQkFMaEJzQixRQUFRdEI7QUFBQUEsZ0JBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU9BO0FBQUEsWUFDRCxLQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBV0EsS0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWFBO0FBQUEsZUF4Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEwQkE7QUFBQSxVQUVBLHVCQUFDLDJoQkFBTyxXQUFVLHdLQUNoQjtBQUFBLG1DQUFDLHNWQUFLLE1BQUssWUFBVyxNQUFNLE1BQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStCO0FBQUEsWUFDL0IsdUJBQUMsZ1dBQUsseUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZTtBQUFBLGVBRmpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUNBO0FBQUEsV0F2Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXdDQTtBQUFBLE1BR0EsdUJBQUMsbVdBQUksV0FBVSxpQkFDYixpQ0FBQyxrWkFBSSxXQUFVLHdEQUNiO0FBQUEsK0JBQUMsdVRBQ0M7QUFBQSxpQ0FBQyx5YkFBTSxXQUFVLG9EQUFtRCwwQkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEU7QUFBQSxVQUM5RTtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsT0FBT3BFO0FBQUFBLGNBQ1AsVUFBVSxDQUFDMkYsTUFBTTFGLHFCQUFxQjBGLEdBQUdDLFFBQVFoRCxLQUFLO0FBQUEsY0FDdEQsV0FBVTtBQUFBLGNBRVR1Qiw0QkFBa0IzQjtBQUFBQSxnQkFBSSxDQUFDa0QsV0FDdEIsdUJBQUMsZ1VBQTJCLE9BQU9BLFFBQVE5QyxPQUN4QzhDLGtCQUFRdEIsU0FERXNCLFFBQVE5QyxPQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsY0FDRDtBQUFBO0FBQUEsWUFUSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFVQTtBQUFBLGFBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWFBO0FBQUEsUUFFQSx1QkFBQyx1VEFDQztBQUFBLGlDQUFDLHNiQUFNLFdBQVUsb0RBQW1ELHlCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RTtBQUFBLFVBQzdFO0FBQUEsWUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FDQyxPQUFPMUM7QUFBQUEsY0FDUCxVQUFVLENBQUN5RixNQUFNeEYscUJBQXFCd0YsR0FBR0MsUUFBUWhELEtBQUs7QUFBQSxjQUN0RCxXQUFVO0FBQUEsY0FFVHlCLDRCQUFrQjdCO0FBQUFBLGdCQUFJLENBQUNrRCxXQUN0Qix1QkFBQyxnVUFBMkIsT0FBT0EsUUFBUTlDLE9BQ3hDOEMsa0JBQVF0QixTQURFc0IsUUFBUTlDLE9BQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxjQUNEO0FBQUE7QUFBQSxZQVRIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVVBO0FBQUEsYUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYUE7QUFBQSxRQUVBLHVCQUFDLHVUQUNDO0FBQUEsaUNBQUMsd2JBQU0sV0FBVSxvREFBbUQseUJBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZFO0FBQUEsVUFDN0U7QUFBQSxZQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUNDLE9BQU94QztBQUFBQSxjQUNQLFVBQVUsQ0FBQ3VGLE1BQU10RixlQUFlc0YsR0FBR0MsUUFBUWhELEtBQUs7QUFBQSxjQUNoRCxXQUFVO0FBQUEsY0FFVDBCLHNCQUFZOUI7QUFBQUEsZ0JBQUksQ0FBQ2tELFdBQ2hCLHVCQUFDLGdVQUEyQixPQUFPQSxRQUFROUMsT0FDeEM4QyxrQkFBUXRCLFNBREVzQixRQUFROUMsT0FBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGNBQ0Q7QUFBQTtBQUFBLFlBVEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBVUE7QUFBQSxhQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLFFBRUEsdUJBQUMsa1dBQUksV0FBVSxrQkFDYixpQ0FBQyxvYUFBTyxXQUFVLG1FQUNoQjtBQUFBLGlDQUFDLG9WQUFLLE1BQUssVUFBUyxNQUFNLE1BQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZCO0FBQUEsVUFDN0IsdUJBQUMsc1dBQUssNkJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUI7QUFBQSxhQUZyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxXQW5ERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBb0RBLEtBckRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzREE7QUFBQSxNQUdBLHVCQUFDLGlYQUFJLFdBQVUsK0JBQ2IsaUNBQUMsa1dBQUksV0FBVSxrQkFDWjJCLHNCQUFZL0I7QUFBQUEsUUFBSSxDQUFDcUQsUUFDaEI7QUFBQSxVQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUVDLFNBQVMsTUFBTXRGLGFBQWFzRixLQUFLekMsRUFBRTtBQUFBLFlBQ25DLFdBQVcsdUdBQ1Q5QyxjQUFjdUYsS0FBS3pDLEtBQ2YsZ0NBQStCLHlGQUF5RjtBQUFBLFlBRzlIO0FBQUEscUNBQUMsd1RBQUssTUFBTXlDLEtBQUtyQixNQUFNLE1BQU0sTUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0M7QUFBQSxjQUNoQyx1QkFBQywwVEFBTXFCLGVBQUt6QixTQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtCO0FBQUE7QUFBQTtBQUFBLFVBUmJ5QixLQUFLekM7QUFBQUEsVUFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBVUE7QUFBQSxNQUNELEtBYkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWNBLEtBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdCQTtBQUFBLE1BR0M5QyxjQUFjLGNBQ2IsdUJBQUMsMlZBQUksV0FBVSxhQUViO0FBQUEsK0JBQUMsa1pBQUksV0FBVSx3REFDWlUsMkJBQWlCd0I7QUFBQUEsVUFBSSxDQUFDYSxXQUNyQix1QkFBQyw0VkFBeUIsV0FBVSxZQUNsQztBQUFBLG1DQUFDLDhYQUFJLFdBQVUsMENBQ2I7QUFBQSxxQ0FBQywwWEFBRyxXQUFVLDJDQUEyQ0Esa0JBQVFBLFVBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdFO0FBQUEsY0FDeEUsdUJBQUMsdVRBQUksV0FBVywrQkFDZEEsUUFBUUksVUFBVSxPQUFPLGlCQUFpQixZQUFZLElBRXREO0FBQUEsdUNBQUMsd1RBQUssTUFBTUosUUFBUUksVUFBVSxPQUFPLGVBQWUsZ0JBQWdCLE1BQU0sTUFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkU7QUFBQSxnQkFDN0UsdUJBQUMsMFdBQUssV0FBVSx1QkFBdUJKLGtCQUFRRyxVQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzRDtBQUFBLG1CQUp4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsaUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLFlBQ0EsdUJBQUMsc1hBQUUsV0FBVSwwQ0FBMENILGtCQUFRVCxTQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRTtBQUFBLGVBVjdEUyxRQUFRQSxRQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVdBO0FBQUEsUUFDRCxLQWRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQTtBQUFBLFFBR0EsdUJBQUMsK1hBQUksV0FBVSx5Q0FFYjtBQUFBLGlDQUFDLDRWQUFJLFdBQVUsWUFDYjtBQUFBLG1DQUFDLDZhQUFHLFdBQVUsOENBQTZDLCtCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRTtBQUFBLFlBQzFFLHVCQUFDLHNWQUFJLFdBQVUsUUFDYixpQ0FBQyxxV0FBb0IsT0FBTSxRQUFPLFFBQU8sUUFDdkMsaUNBQUMsNlVBQ0M7QUFBQSxxQ0FBQyxpVUFBUSxTQUFTLHVCQUFDLHFWQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWMsS0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0M7QUFBQSxjQUNwQztBQUFBLGdCQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFDQyxTQUFRO0FBQUEsa0JBQ1IsTUFBTTNDO0FBQUFBLGtCQUNOLG1CQUFpQjtBQUFBLGtCQUVqQixpQ0FBQyx1VUFBVSxVQUFTLFVBQVMsTUFBSyxRQUFPLFFBQU8sVUFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBc0Q7QUFBQTtBQUFBLGdCQUx4RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNQTtBQUFBLGlCQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBU0EsS0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVdBLEtBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFhQTtBQUFBLGVBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkE7QUFBQSxVQUdBLHVCQUFDLDRWQUFJLFdBQVUsWUFDYjtBQUFBLG1DQUFDLDJhQUFHLFdBQVUsOENBQTZDLDZCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RTtBQUFBLFlBQ3hFLHVCQUFDLHNWQUFJLFdBQVUsUUFDYixpQ0FBQyxxV0FBb0IsT0FBTSxRQUFPLFFBQU8sUUFDdkMsaUNBQUMsdVVBQVUsTUFBTUUsa0JBQ2Y7QUFBQSxxQ0FBQyxtVkFBYyxpQkFBZ0IsT0FBTSxRQUFPLGFBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFEO0FBQUEsY0FDckQsdUJBQUMsMlRBQU0sU0FBUSxTQUFRLFFBQU8sYUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUM7QUFBQSxjQUN2Qyx1QkFBQywyVEFBTSxRQUFPLFdBQVUsZUFBZSxDQUFDZ0MsVUFBVSxJQUFJQSxRQUFNLEdBQUksT0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0U7QUFBQSxjQUNwRSx1QkFBQyxpVUFBUSxTQUFTLHVCQUFDLHFWQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWMsS0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0M7QUFBQSxjQUNwQyx1QkFBQyxrWEFBSyxNQUFLLFlBQVcsU0FBUSxVQUFTLFFBQU8sV0FBVSxhQUFhLEdBQUcsTUFBSyxZQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxRjtBQUFBLGNBQ3JGLHVCQUFDLG9YQUFLLE1BQUssWUFBVyxTQUFRLFlBQVcsUUFBTyxXQUFVLGFBQWEsR0FBRyxpQkFBZ0IsT0FBTSxNQUFLLGNBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStHO0FBQUEsY0FDL0csdUJBQUMsa1hBQUssTUFBSyxZQUFXLFNBQVEsVUFBUyxRQUFPLFdBQVUsYUFBYSxHQUFHLE1BQUssWUFBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUY7QUFBQSxpQkFQdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVUEsS0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVlBO0FBQUEsZUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWVBO0FBQUEsYUFwQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXFDQTtBQUFBLFFBR0EsdUJBQUMsNFZBQUksV0FBVSxZQUNiO0FBQUEsaUNBQUMsaWJBQUcsV0FBVSw4Q0FBNkMsaUNBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRFO0FBQUEsVUFDNUUsdUJBQUMsc1ZBQUksV0FBVSxRQUNiLGlDQUFDLHFXQUFvQixPQUFNLFFBQU8sUUFBTyxRQUN2QyxpQ0FBQyxvVUFBUyxNQUFNOUIsYUFDZDtBQUFBLG1DQUFDLG1WQUFjLGlCQUFnQixPQUFNLFFBQU8sYUFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUQ7QUFBQSxZQUNyRCx1QkFBQywyVEFBTSxTQUFRLFVBQVMsUUFBTyxhQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3QztBQUFBLFlBQ3hDLHVCQUFDLDJUQUFNLFFBQU8sV0FBVSxlQUFlLENBQUM4QixVQUFVLEdBQUdBLEtBQUssT0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEQ7QUFBQSxZQUM5RCx1QkFBQyxpVUFBUSxTQUFTLHVCQUFDLHFWQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWMsS0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0M7QUFBQSxZQUNwQyx1QkFBQywyVkFBSSxTQUFRLFdBQVUsTUFBSyxXQUFVLE1BQUssZ0JBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVEO0FBQUEsZUFMekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsYUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYUE7QUFBQSxXQXpFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMEVBO0FBQUEsTUFJRHRDLGNBQWMsY0FDYix1QkFBQywyVkFBSSxXQUFVLGFBQ2I7QUFBQSwrQkFBQywrWEFBSSxXQUFVLHlDQUViO0FBQUEsaUNBQUMsOFdBQUksV0FBVSwwQkFDYjtBQUFBLG1DQUFDLHliQUFHLFdBQVUsOENBQTZDLHVDQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRjtBQUFBLFlBQ2xGLHVCQUFDLHNWQUFJLFdBQVUsUUFDYixpQ0FBQyxxV0FBb0IsT0FBTSxRQUFPLFFBQU8sUUFDdkMsaUNBQUMsb1VBQVMsTUFBTUksb0JBQ2Q7QUFBQSxxQ0FBQyxtVkFBYyxpQkFBZ0IsT0FBTSxRQUFPLGFBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFEO0FBQUEsY0FDckQsdUJBQUMsMlRBQU0sU0FBUSxRQUFPLFFBQU8sYUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0M7QUFBQSxjQUN0Qyx1QkFBQywyVEFBTSxRQUFPLGFBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUI7QUFBQSxjQUN2Qix1QkFBQyxpVUFBUSxTQUFTLHVCQUFDLHFWQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWMsS0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0M7QUFBQSxjQUNwQyx1QkFBQyxxVEFBSSxTQUFRLFNBQVEsTUFBSyxhQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtQztBQUFBLGlCQUxyQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVUE7QUFBQSxlQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUE7QUFBQSxVQUdBLHVCQUFDLDRWQUFJLFdBQVUsWUFDYjtBQUFBLG1DQUFDLDZhQUFHLFdBQVUsOENBQTZDLCtCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRTtBQUFBLFlBQzFFLHVCQUFDLDJWQUFJLFdBQVUsYUFDYjtBQUFBLHFDQUFDLHVYQUFJLFdBQVUscUNBQ2I7QUFBQSx1Q0FBQywrWkFBSyxXQUFVLCtCQUE4Qiw4QkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNEQ7QUFBQSxnQkFDNUQsdUJBQUMsOFhBQUssV0FBVSx5Q0FBeUNnRSwwQkFBZ0JoRSxzQkFBc0IsSUFBSW9DLE9BQU8sQ0FBQ0MsS0FBS04sVUFBVU0sT0FBT04sT0FBT0csU0FBUyxJQUFJLENBQUMsQ0FBQyxLQUF2SjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5SjtBQUFBLG1CQUYzSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyx1WEFBSSxXQUFVLHFDQUNiO0FBQUEsdUNBQUMsa2FBQUssV0FBVSwrQkFBOEIsaUNBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStEO0FBQUEsZ0JBQy9ELHVCQUFDLDhYQUFLLFdBQVUseUNBQXlDOEIsMEJBQWdCaEUsc0JBQXNCLElBQUlvQyxPQUFPLENBQUNDLEtBQUtOLFVBQVVNLE9BQVFOLE9BQU9HLFNBQVMsTUFBTUgsT0FBT0MsU0FBUyxVQUFVLE1BQU1ELE9BQU9DLFNBQVMsY0FBYyxPQUFPRCxPQUFPQyxTQUFTLGFBQWEsTUFBTUQsT0FBT0MsU0FBUyxnQkFBZ0IsT0FBTyxJQUFLLENBQUMsQ0FBQyxLQUE5UztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnVDtBQUFBLG1CQUZsVDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyx1WEFBSSxXQUFVLHFDQUNiO0FBQUEsdUNBQUMsMFpBQUssV0FBVSwrQkFBOEIseUJBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVEO0FBQUEsZ0JBQ3ZELHVCQUFDLHlYQUFLLFdBQVUsb0NBQW9DZ0MsMEJBQWdCaEUsc0JBQXNCLElBQUlvQyxPQUFPLENBQUNDLEtBQUtOLFVBQVVNLE9BQU9OLE9BQU9HLFNBQVMsSUFBSSxDQUFDLElBQUksR0FBRyxLQUF4SjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwSjtBQUFBLG1CQUY1SjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyx1WEFBSSxXQUFVLHFDQUNiO0FBQUEsdUNBQUMsMlpBQUssV0FBVSwrQkFBOEIsMEJBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdEO0FBQUEsZ0JBQ3hELHVCQUFDLHVYQUFLLFdBQVUsa0NBQWtDOEIsMEJBQWdCaEUsc0JBQXNCLElBQUlvQyxPQUFPLENBQUNDLEtBQUtOLFVBQVVNLE9BQU9OLE9BQU9HLFNBQVMsSUFBSSxDQUFDLElBQUksR0FBRyxLQUF0SjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3SjtBQUFBLG1CQUYxSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxpWEFBSSxXQUFVLCtCQUNiLGlDQUFDLHVYQUFJLFdBQVUscUNBQ2I7QUFBQSx1Q0FBQywrWkFBSyxXQUFVLCtCQUE4Qiw4QkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNEQ7QUFBQSxnQkFDNUQsdUJBQUMsdVpBQUssV0FBVSxvQ0FBc0NsQztBQUFBQSwwQ0FBc0IsSUFBSW9DLE9BQU8sQ0FBQ0MsS0FBS04sVUFBVU0sT0FBT04sT0FBT0csU0FBUyxJQUFJLENBQUMsSUFBSSxNQUFTdUMsUUFBUSxDQUFDO0FBQUEsa0JBQUU7QUFBQSxxQkFBM0o7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNEo7QUFBQSxtQkFGOUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxpQkF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF1QkE7QUFBQSxlQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTBCQTtBQUFBLGFBNUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE2Q0E7QUFBQSxRQUdBLHVCQUFDLDRWQUFJLFdBQVUsWUFDYjtBQUFBLGlDQUFDLG1iQUFHLFdBQVUsOENBQTZDLHFDQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRjtBQUFBLFVBQ2hGLHVCQUFDLGlXQUFJLFdBQVUsbUJBQ2IsaUNBQUMsOFZBQU0sV0FBVSxVQUNmO0FBQUEsbUNBQUMsNlRBQ0MsaUNBQUMsdVdBQUcsV0FBVSwwQkFDWjtBQUFBLHFDQUFDLDBiQUFHLFdBQVUsK0RBQThELHlCQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxRjtBQUFBLGNBQ3JGLHVCQUFDLHliQUFHLFdBQVUsZ0VBQStELHVCQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvRjtBQUFBLGNBQ3BGLHVCQUFDLHViQUFHLFdBQVUsZ0VBQStELHFCQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrRjtBQUFBLGNBQ2xGLHVCQUFDLDRiQUFHLFdBQVUsZ0VBQStELHdCQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxRjtBQUFBLGNBQ3JGLHVCQUFDLG1jQUFHLFdBQVUsZ0VBQStELDZCQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwRjtBQUFBLGlCQUw1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLFlBQ0EsdUJBQUMsNlRBQ0VqRSx5QkFBZXNCO0FBQUFBLGNBQUksQ0FBQ3NELGNBQ25CLHVCQUFDLHdZQUF5QixXQUFVLHVEQUNsQztBQUFBLHVDQUFDLHNZQUFHLFdBQVUsbURBQW1EQSxxQkFBV3BELFFBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlGO0FBQUEsZ0JBQ2pGLHVCQUFDLHFZQUFHLFdBQVUsa0RBQWtEZ0MseUJBQWVvQixXQUFXbEUsT0FBTyxLQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtRztBQUFBLGdCQUNuRyx1QkFBQyxxWUFBRyxXQUFVLGtEQUFrRGtFLHFCQUFXakQsU0FBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUY7QUFBQSxnQkFDakYsdUJBQUMscVlBQUcsV0FBVSxrREFBa0RxQywyQkFBaUJZLFdBQVdoRSxPQUFPLEtBQW5HO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFHO0FBQUEsZ0JBQ3JHLHVCQUFDLHFZQUFHLFdBQVUsa0RBQWtENEMseUJBQWVvQixXQUFXeEMsZUFBZ0J3QyxXQUFXbEUsVUFBVWtFLFdBQVdqRCxTQUFVLENBQUMsS0FBcko7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUo7QUFBQSxtQkFMaEppRCxXQUFXcEQsTUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFNQTtBQUFBLFlBQ0QsS0FUSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVVBO0FBQUEsZUFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQkEsS0F0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF1QkE7QUFBQSxhQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMEJBO0FBQUEsV0EzRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTRFQTtBQUFBLE1BSURwQyxjQUFjLGlCQUNiLHVCQUFDLDJWQUFJLFdBQVUsYUFFYjtBQUFBLCtCQUFDLDRWQUFJLFdBQVUsWUFDYjtBQUFBLGlDQUFDLGdjQUFHLFdBQVUsOENBQTZDLGdEQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRjtBQUFBLFVBQzNGLHVCQUFDLGlXQUFJLFdBQVUsbUJBQ2IsaUNBQUMsOFZBQU0sV0FBVSxVQUNmO0FBQUEsbUNBQUMsNlRBQ0MsaUNBQUMsdVdBQUcsV0FBVSwwQkFDWjtBQUFBLHFDQUFDLCtiQUFHLFdBQVUsK0RBQThELDhCQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwRjtBQUFBLGNBQzFGLHVCQUFDLHliQUFHLFdBQVUsZ0VBQStELHVCQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvRjtBQUFBLGNBQ3BGLHVCQUFDLHViQUFHLFdBQVUsZ0VBQStELHFCQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrRjtBQUFBLGNBQ2xGLHVCQUFDLHViQUFHLFdBQVUsZ0VBQStELHFCQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrRjtBQUFBLGNBQ2xGLHVCQUFDLDRiQUFHLFdBQVUsZ0VBQStELDBCQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1RjtBQUFBLGNBQ3ZGLHVCQUFDLDBiQUFHLFdBQVUsZ0VBQStELHdCQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxRjtBQUFBLGlCQU52RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BLEtBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFTQTtBQUFBLFlBQ0EsdUJBQUMsNlRBQ0VjLDhCQUFvQm9CO0FBQUFBLGNBQUksQ0FBQ3VELFFBQ3hCLHVCQUFDLHdZQUFtQixXQUFVLHVEQUM1QjtBQUFBLHVDQUFDLHNZQUFHLFdBQVUsbURBQW1EQSxlQUFLckQsUUFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkU7QUFBQSxnQkFDM0UsdUJBQUMscVlBQUcsV0FBVSxrREFBa0RnQyx5QkFBZXFCLEtBQUtuRSxPQUFPLEtBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZGO0FBQUEsZ0JBQzdGLHVCQUFDLHFZQUFHLFdBQVUsa0RBQWtEbUUsZUFBS2xELFNBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJFO0FBQUEsZ0JBQzNFLHVCQUFDLHFZQUFHLFdBQVUsa0RBQWtENkIseUJBQWVxQixLQUFLakMsS0FBSyxLQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyRjtBQUFBLGdCQUMzRix1QkFBQyxxYUFBRyxXQUFVLGtEQUFrRGlDO0FBQUFBLHVCQUFLaEM7QUFBQUEsa0JBQVc7QUFBQSxxQkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUY7QUFBQSxnQkFDakYsdUJBQUMsdVdBQUcsV0FBVSx3QkFDWixpQ0FBQyw2WEFBSSxXQUFVLHlDQUNiO0FBQUEsa0JBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUNDLFdBQVcsb0JBQW9CZ0MsS0FBS2hDLGNBQWMsTUFBTSxlQUFlZ0MsS0FBS2hDLGNBQWMsS0FBSyxlQUFlLFlBQVk7QUFBQSxvQkFDMUgsT0FBTyxFQUFFaUMsT0FBTyxHQUFHQyxLQUFLQyxJQUFJSCxLQUFLaEMsWUFBWSxHQUFHLENBQUMsSUFBSTtBQUFBO0FBQUEsa0JBRnZEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFHQyxLQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU9BO0FBQUEsbUJBYk9nQyxLQUFLckQsTUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWNBO0FBQUEsWUFDRCxLQWpCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWtCQTtBQUFBLGVBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBOEJBLEtBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0NBO0FBQUEsYUFsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1DQTtBQUFBLFFBR0EsdUJBQUMsK1hBQUksV0FBVSx5Q0FDYjtBQUFBLGlDQUFDLDRWQUFJLFdBQVUsWUFDYjtBQUFBLG1DQUFDLDhhQUFHLFdBQVUsOENBQTZDLGdDQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyRTtBQUFBLFlBQzNFLHVCQUFDLHNWQUFJLFdBQVUsUUFDYixpQ0FBQyxxV0FBb0IsT0FBTSxRQUFPLFFBQU8sUUFDdkMsaUNBQUMsb1VBQVMsTUFBTXRCLG9CQUNkO0FBQUEscUNBQUMsbVZBQWMsaUJBQWdCLE9BQU0sUUFBTyxhQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxRDtBQUFBLGNBQ3JELHVCQUFDLDJUQUFNLFNBQVEsUUFBTyxRQUFPLFdBQVUsT0FBTyxLQUFLLFlBQVcsT0FBTSxRQUFRLE1BQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStFO0FBQUEsY0FDL0UsdUJBQUMsMlRBQU0sUUFBTyxXQUFVLGVBQWUsQ0FBQ3dCLFVBQVUsR0FBR0EsS0FBSyxPQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4RDtBQUFBLGNBQzlELHVCQUFDLGlVQUFRLFNBQVMsdUJBQUMscVZBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBYyxLQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvQztBQUFBLGNBQ3BDLHVCQUFDLDJWQUFJLFNBQVEsY0FBYSxNQUFLLFdBQVUsTUFBSyxrQkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEQ7QUFBQSxpQkFMOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVVBO0FBQUEsZUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBO0FBQUEsVUFFQSx1QkFBQyw0VkFBSSxXQUFVLFlBQ2I7QUFBQSxtQ0FBQyw4YUFBRyxXQUFVLDhDQUE2Qyw4QkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUU7QUFBQSxZQUN6RSx1QkFBQyxzVkFBSSxXQUFVLFFBQ2IsaUNBQUMscVdBQW9CLE9BQU0sUUFBTyxRQUFPLFFBQ3ZDLGlDQUFDLG9VQUNDO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBQ0MsTUFBTXhCO0FBQUFBLGtCQUNOLElBQUc7QUFBQSxrQkFDSCxJQUFHO0FBQUEsa0JBQ0gsYUFBYTtBQUFBLGtCQUNiLE1BQUs7QUFBQSxrQkFDTCxTQUFRO0FBQUEsa0JBQ1IsT0FBTyxDQUFDLEVBQUVzQixNQUFNeUQsUUFBUSxNQUFNLEdBQUd6RCxJQUFJLE1BQU15RCxVQUFVLE1BQU1oQixRQUFRLENBQUMsQ0FBQztBQUFBLGtCQUVwRS9ELDhCQUFvQm9CO0FBQUFBLG9CQUFJLENBQUMrQyxPQUFPQyxVQUMvQix1QkFBQyx3VEFBMkIsTUFBTSxPQUFPLE1BQU1BLFFBQVEsRUFBRSxVQUFVLEtBQUtBLFFBQVEsRUFBRSxRQUF2RSxRQUFRQSxLQUFLLElBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXVGO0FBQUEsa0JBQ3hGO0FBQUE7QUFBQSxnQkFYSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FZQTtBQUFBLGNBQ0EsdUJBQUMsaVVBQVEsU0FBUyx1QkFBQyxxVkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFjLEtBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9DO0FBQUEsaUJBZHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZUEsS0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQkEsS0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFtQkE7QUFBQSxlQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXNCQTtBQUFBLGFBdENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF1Q0E7QUFBQSxXQS9FRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0ZBO0FBQUEsTUFJRGxGLGNBQWMsaUJBQ2IsdUJBQUMsMlZBQUksV0FBVSxhQUViO0FBQUEsK0JBQUMsK1hBQUksV0FBVSx5Q0FDYjtBQUFBLGlDQUFDLDBXQUFJLFdBQVUsd0JBQ2I7QUFBQSxtQ0FBQyw4YUFBRyxXQUFVLGdEQUErQyw4QkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkU7QUFBQSxZQUMzRSx1QkFBQyx3WEFBRSxXQUFVLDBDQUEwQ29FLDBCQUFnQjlELG9CQUFvQixJQUFJa0MsT0FBTyxDQUFDQyxLQUFLcUQsVUFBVXJELE9BQU9xRCxPQUFPQyxZQUFZLElBQUksQ0FBQyxDQUFDLEtBQXRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdKO0FBQUEsWUFDeEosdUJBQUMscVpBQUUsV0FBVSxtRUFDWDtBQUFBLHFDQUFDLHdWQUFLLE1BQUssY0FBYSxNQUFNLE1BQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlDO0FBQUEsY0FDakMsdUJBQUMsNFhBQUssNkNBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUM7QUFBQSxpQkFGckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLGVBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBRUEsdUJBQUMsMFdBQUksV0FBVSx3QkFDYjtBQUFBLG1DQUFDLHNiQUFHLFdBQVUsZ0RBQStDLG9DQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRjtBQUFBLFlBQ2pGLHVCQUFDLDBYQUFFLFdBQVUsNENBQTRDM0IsMEJBQWdCOUQsb0JBQW9CLElBQUlrQyxPQUFPLENBQUNDLEtBQUtxRCxVQUFVckQsT0FBT3FELE9BQU9FLFVBQVUsSUFBSSxDQUFDLENBQUMsS0FBdEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0o7QUFBQSxZQUN4Six1QkFBQyxpYUFBRSxXQUFVLCtCQUE4QixxQ0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0U7QUFBQSxlQUhsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsVUFFQSx1QkFBQywwV0FBSSxXQUFVLHdCQUNiO0FBQUEsbUNBQUMsa2JBQUcsV0FBVSxnREFBK0MsZ0NBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZFO0FBQUEsWUFDN0UsdUJBQUMsdVhBQUUsV0FBVSx5Q0FBeUN0RiwyQkFBaUJ1RixLQUFLLENBQUFDLE1BQUtBLEVBQUVuRCxXQUFXLFVBQVUsR0FBR1QsU0FBUyxRQUFwSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5SDtBQUFBLFlBQ3pILHVCQUFDLHNaQUFFLFdBQVUsK0JBQThCLDRCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RDtBQUFBLGVBSHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxhQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBcUJBO0FBQUEsUUFHQSx1QkFBQyw0VkFBSSxXQUFVLFlBQ2I7QUFBQSxpQ0FBQyw0YkFBRyxXQUFVLDhDQUE2QywwQ0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUY7QUFBQSxVQUNyRix1QkFBQyxzVkFBSSxXQUFVLFFBQ2IsaUNBQUMscVdBQW9CLE9BQU0sUUFBTyxRQUFPLFFBQ3ZDLGlDQUFDLHVVQUFVLE1BQU1oQyxrQkFDZjtBQUFBLG1DQUFDLG1WQUFjLGlCQUFnQixPQUFNLFFBQU8sYUFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUQ7QUFBQSxZQUNyRCx1QkFBQywyVEFBTSxTQUFRLFNBQVEsUUFBTyxhQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1QztBQUFBLFlBQ3ZDLHVCQUFDLDJUQUFNLFFBQU8sV0FBVSxlQUFlLENBQUNnQyxVQUFVLElBQUlBLFFBQU0sR0FBSSxPQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRTtBQUFBLFlBQ3BFLHVCQUFDLGlVQUFRLFNBQVMsdUJBQUMscVZBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBYyxLQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvQztBQUFBLFlBQ3BDLHVCQUFDLDRYQUFLLE1BQUssWUFBVyxTQUFRLFVBQVMsUUFBTyxXQUFVLGFBQWEsR0FBRyxNQUFLLG9CQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RjtBQUFBLFlBQzdGLHVCQUFDLG9YQUFLLE1BQUssWUFBVyxTQUFRLFlBQVcsUUFBTyxXQUFVLGFBQWEsR0FBRyxpQkFBZ0IsT0FBTSxNQUFLLGNBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStHO0FBQUEsWUFDL0csdUJBQUMsa1hBQUssTUFBSyxZQUFXLFNBQVEsVUFBUyxRQUFPLFdBQVUsYUFBYSxHQUFHLE1BQUssWUFBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUY7QUFBQSxlQVB2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQSxLQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxhQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQTtBQUFBLFdBekNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE0Q0E7QUFBQSxTQTdaSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBK1pBLEtBaGFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpYUEsS0FsYUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1hQTtBQUFBLElBRUNwQyxvQkFDQztBQUFBLE1BQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBQ0MsV0FBVTtBQUFBLFFBQ1YsU0FBUyxNQUFNQyxvQkFBb0IsS0FBSztBQUFBO0FBQUEsTUFGMUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBR0M7QUFBQSxPQTNhTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNmFBO0FBRUo7QUFBRVYsR0FwbUJJRCxtQkFBaUI7QUFBQTJHLEtBQWpCM0c7QUFzbUJOLGVBQWVBO0FBQWtCLElBQUEyRztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJ1c2VNZW1vIiwiSGVhZGVyIiwiQnJlYWRjcnVtYiIsIkljb24iLCJCYXJDaGFydCIsIkJhciIsIlhBeGlzIiwiWUF4aXMiLCJDYXJ0ZXNpYW5HcmlkIiwiVG9vbHRpcCIsIlJlc3BvbnNpdmVDb250YWluZXIiLCJMaW5lQ2hhcnQiLCJMaW5lIiwiUGllQ2hhcnQiLCJQaWUiLCJDZWxsIiwiRnVubmVsQ2hhcnQiLCJGdW5uZWwiLCJMYWJlbExpc3QiLCJkZWFsc1NlcnZpY2UiLCJMb2FkZXIyIiwiUGlwZWxpbmVBbmFseXRpY3MiLCJfcyIsInNlbGVjdGVkRGF0ZVJhbmdlIiwic2V0U2VsZWN0ZWREYXRlUmFuZ2UiLCJzZWxlY3RlZFRlcnJpdG9yeSIsInNldFNlbGVjdGVkVGVycml0b3J5Iiwic2VsZWN0ZWRSZXAiLCJzZXRTZWxlY3RlZFJlcCIsImFjdGl2ZVRhYiIsInNldEFjdGl2ZVRhYiIsImlzRXhwb3J0TWVudU9wZW4iLCJzZXRJc0V4cG9ydE1lbnVPcGVuIiwicGlwZWxpbmVGdW5uZWxEYXRhIiwic2V0UGlwZWxpbmVGdW5uZWxEYXRhIiwicmV2ZW51ZVRyZW5kRGF0YSIsInNldFJldmVudWVUcmVuZERhdGEiLCJ3aW5SYXRlRGF0YSIsInNldFdpblJhdGVEYXRhIiwidmVsb2NpdHlNZXRyaWNzIiwic2V0VmVsb2NpdHlNZXRyaWNzIiwidGVycml0b3J5RGF0YSIsInNldFRlcnJpdG9yeURhdGEiLCJyZXBQZXJmb3JtYW5jZURhdGEiLCJzZXRSZXBQZXJmb3JtYW5jZURhdGEiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImVycm9yIiwic2V0RXJyb3IiLCJmZXRjaERhdGEiLCJwaXBlbGluZSIsInJldmVudWUiLCJwZXJmb3JtYW5jZSIsIndpblJhdGUiLCJQcm9taXNlIiwiYWxsIiwiZ2V0UGlwZWxpbmVEZWFscyIsImdldFJldmVudWVEYXRhIiwiZ2V0UGVyZm9ybWFuY2VNZXRyaWNzIiwiZ2V0V2luUmF0ZURhdGEiLCJ0cmFuc2Zvcm1lZFBpcGVsaW5lIiwiT2JqZWN0IiwidmFsdWVzIiwibWFwIiwic3RhZ2UiLCJuYW1lIiwidGl0bGUiLCJ2YWx1ZSIsImRlYWxzIiwicmVkdWNlIiwic3VtIiwiZGVhbCIsImNvdW50IiwibGVuZ3RoIiwiZmlsbCIsImlkIiwibWV0cmljIiwiYXZnRGVhbFNpemUiLCJ0b0xvY2FsZVN0cmluZyIsImNoYW5nZSIsInRyZW5kIiwiY29udmVyc2lvblJhdGUiLCJkZWFsc1dvbiIsImRlYWxzTG9zdCIsImFjaGlldmVkIiwicXVvdGEiLCJhdHRhaW5tZW50IiwicGVyY2VudGFnZSIsImVyciIsImNvbnNvbGUiLCJkYXRlUmFuZ2VPcHRpb25zIiwibGFiZWwiLCJ0ZXJyaXRvcnlPcHRpb25zIiwicmVwT3B0aW9ucyIsInRhYk9wdGlvbnMiLCJpY29uIiwiZXhwb3J0T3B0aW9ucyIsImZvcm1hdEN1cnJlbmN5IiwiSW50bCIsIk51bWJlckZvcm1hdCIsInN0eWxlIiwiY3VycmVuY3kiLCJtaW5pbXVtRnJhY3Rpb25EaWdpdHMiLCJtYXhpbXVtRnJhY3Rpb25EaWdpdHMiLCJmb3JtYXQiLCJmb3JtYXRQZXJjZW50YWdlIiwidG9GaXhlZCIsIkN1c3RvbVRvb2x0aXAiLCJhY3RpdmUiLCJwYXlsb2FkIiwiZW50cnkiLCJpbmRleCIsImNvbG9yIiwib3B0aW9uIiwiZSIsInRhcmdldCIsInRhYiIsInRlcnJpdG9yeSIsInJlcCIsIndpZHRoIiwiTWF0aCIsIm1pbiIsInBlcmNlbnQiLCJtb250aCIsImZvcmVjYXN0IiwiYWN0dWFsIiwiZmluZCIsIm0iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbImluZGV4LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSwgdXNlTWVtbyB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IEhlYWRlciBmcm9tICdjb21wb25lbnRzL3VpL0hlYWRlcic7XHJcbmltcG9ydCBCcmVhZGNydW1iIGZyb20gJ2NvbXBvbmVudHMvdWkvQnJlYWRjcnVtYic7XHJcbmltcG9ydCBJY29uIGZyb20gJ2NvbXBvbmVudHMvQXBwSWNvbic7XHJcbmltcG9ydCB7IEJhckNoYXJ0LCBCYXIsIFhBeGlzLCBZQXhpcywgQ2FydGVzaWFuR3JpZCwgVG9vbHRpcCwgUmVzcG9uc2l2ZUNvbnRhaW5lciwgTGluZUNoYXJ0LCBMaW5lLCBQaWVDaGFydCwgUGllLCBDZWxsLCBGdW5uZWxDaGFydCwgRnVubmVsLCBMYWJlbExpc3QgfSBmcm9tICdyZWNoYXJ0cyc7XHJcbmltcG9ydCBkZWFsc1NlcnZpY2UgZnJvbSAnLi4vLi4vc2VydmljZXMvZGVhbHNTZXJ2aWNlJzsgLy8gSW1wb3J0IGRlYWxzU2VydmljZVxyXG5pbXBvcnQgeyBMb2FkZXIyIH0gZnJvbSAnbHVjaWRlLXJlYWN0JzsgLy8gQXNzdW1pbmcgbHVjaWRlLXJlYWN0IGZvciBpY29uc1xyXG5cclxuY29uc3QgUGlwZWxpbmVBbmFseXRpY3MgPSAoKSA9PiB7XHJcbiAgY29uc3QgW3NlbGVjdGVkRGF0ZVJhbmdlLCBzZXRTZWxlY3RlZERhdGVSYW5nZV0gPSB1c2VTdGF0ZSgnbGFzdDMwZGF5cycpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFRlcnJpdG9yeSwgc2V0U2VsZWN0ZWRUZXJyaXRvcnldID0gdXNlU3RhdGUoJ2FsbCcpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFJlcCwgc2V0U2VsZWN0ZWRSZXBdID0gdXNlU3RhdGUoJ2FsbCcpO1xyXG4gIGNvbnN0IFthY3RpdmVUYWIsIHNldEFjdGl2ZVRhYl0gPSB1c2VTdGF0ZSgnb3ZlcnZpZXcnKTtcclxuICBjb25zdCBbaXNFeHBvcnRNZW51T3Blbiwgc2V0SXNFeHBvcnRNZW51T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIC8vIFN0YXRlIGZvciBhY3R1YWwgZGF0YVxyXG4gIGNvbnN0IFtwaXBlbGluZUZ1bm5lbERhdGEsIHNldFBpcGVsaW5lRnVubmVsRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3JldmVudWVUcmVuZERhdGEsIHNldFJldmVudWVUcmVuZERhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFt3aW5SYXRlRGF0YSwgc2V0V2luUmF0ZURhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFt2ZWxvY2l0eU1ldHJpY3MsIHNldFZlbG9jaXR5TWV0cmljc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3RlcnJpdG9yeURhdGEsIHNldFRlcnJpdG9yeURhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtyZXBQZXJmb3JtYW5jZURhdGEsIHNldFJlcFBlcmZvcm1hbmNlRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XHJcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZShudWxsKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoRGF0YSA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgIC8vIEZldGNoIGFsbCBhbmFseXRpY3MgZGF0YSBmcm9tIFN1cGFiYXNlIC0gbm8gbW9jay9zdGFsZSBkYXRhXHJcbiAgICAgICAgY29uc3QgW3BpcGVsaW5lLCByZXZlbnVlLCBwZXJmb3JtYW5jZSwgd2luUmF0ZV0gPSBhd2FpdCBQcm9taXNlLmFsbChbXHJcbiAgICAgICAgICBkZWFsc1NlcnZpY2UuZ2V0UGlwZWxpbmVEZWFscygpLFxyXG4gICAgICAgICAgZGVhbHNTZXJ2aWNlLmdldFJldmVudWVEYXRhKCksXHJcbiAgICAgICAgICBkZWFsc1NlcnZpY2UuZ2V0UGVyZm9ybWFuY2VNZXRyaWNzKCksXHJcbiAgICAgICAgICBkZWFsc1NlcnZpY2UuZ2V0V2luUmF0ZURhdGEoKSxcclxuICAgICAgICBdKTtcclxuXHJcbiAgICAgICAgLy8gVHJhbnNmb3JtIHBpcGVsaW5lIGRhdGEgZm9yIGZ1bm5lbCBjaGFydFxyXG4gICAgICAgIGNvbnN0IHRyYW5zZm9ybWVkUGlwZWxpbmUgPSBPYmplY3QudmFsdWVzKHBpcGVsaW5lKS5tYXAoc3RhZ2UgPT4gKHtcclxuICAgICAgICAgIG5hbWU6IHN0YWdlLnRpdGxlLFxyXG4gICAgICAgICAgdmFsdWU6IHN0YWdlLmRlYWxzLnJlZHVjZSgoc3VtLCBkZWFsKSA9PiBzdW0gKyBkZWFsLnZhbHVlLCAwKSxcclxuICAgICAgICAgIGNvdW50OiBzdGFnZS5kZWFscy5sZW5ndGgsXHJcbiAgICAgICAgICBmaWxsOiBzdGFnZS5pZCA9PT0gJ2xlYWQnID8gJyMzQjgyRjYnIDpcclxuICAgICAgICAgICAgICAgIHN0YWdlLmlkID09PSAncXVhbGlmaWVkJyA/ICcjNjM2NkYxJyA6XHJcbiAgICAgICAgICAgICAgICBzdGFnZS5pZCA9PT0gJ3Byb3Bvc2FsJyA/ICcjOEI1Q0Y2JyA6XHJcbiAgICAgICAgICAgICAgICBzdGFnZS5pZCA9PT0gJ25lZ290aWF0aW9uJyA/ICcjQTg1NUY3JyA6XHJcbiAgICAgICAgICAgICAgICBzdGFnZS5pZCA9PT0gJ2Nsb3NlZF93b24nID8gJyMxMEI5ODEnIDogJyNFRjQ0NDQnIC8vIGNsb3NlZF9sb3N0XHJcbiAgICAgICAgfSkpO1xyXG5cclxuICAgICAgICBzZXRQaXBlbGluZUZ1bm5lbERhdGEodHJhbnNmb3JtZWRQaXBlbGluZSk7XHJcbiAgICAgICAgc2V0UmV2ZW51ZVRyZW5kRGF0YShyZXZlbnVlKTtcclxuICAgICAgICBzZXRXaW5SYXRlRGF0YSh3aW5SYXRlKTtcclxuICAgICAgICAvLyBGb3IgcGVyZm9ybWFuY2UgbWV0cmljcywgd2UgbmVlZCB0byBhZGFwdCB0aGUgc3RydWN0dXJlIHRvIG1hdGNoIHRoZSBleGlzdGluZyBVSSBleHBlY3RhdGlvbnNcclxuICAgICAgICAvLyBUaGUgZ2V0UGVyZm9ybWFuY2VNZXRyaWNzIHJldHVybnM6IHsgcXVvdGEsIGFjaGlldmVkLCBwZXJjZW50YWdlLCBkZWFsc1dvbiwgZGVhbHNMb3N0LCBhdmdEZWFsU2l6ZSwgY29udmVyc2lvblJhdGUgfVxyXG4gICAgICAgIC8vIFRoZSBVSSBleHBlY3RzIHZlbG9jaXR5TWV0cmljcywgdGVycml0b3J5RGF0YSwgcmVwUGVyZm9ybWFuY2VEYXRhXHJcbiAgICAgICAgLy8gVGhpcyB3aWxsIHJlcXVpcmUgbW9yZSBjb21wbGV4IG1hcHBpbmcgb3IgYWRkaXRpb25hbCBzZXJ2aWNlIGNhbGxzLlxyXG4gICAgICAgIC8vIEZvciBub3csIGxldCdzIGp1c3Qgc2V0IHRoZSBwZXJmb3JtYW5jZU1ldHJpY3MgZGlyZWN0bHkgYW5kIGFkYXB0IHRoZSBVSSBsYXRlciBpZiBuZWVkZWQuXHJcbiAgICAgICAgLy8gT3IsIHdlIGNhbiBjcmVhdGUgZHVtbXkgZGF0YSBiYXNlZCBvbiB0aGUgZmV0Y2hlZCBwZXJmb3JtYW5jZSBmb3Igbm93LlxyXG4gICAgICAgIC8vIExldCdzIGNyZWF0ZSBkdW1teSBkYXRhIGZvciB2ZWxvY2l0eU1ldHJpY3MsIHRlcnJpdG9yeURhdGEsIHJlcFBlcmZvcm1hbmNlRGF0YSBiYXNlZCBvbiB0aGUgZmV0Y2hlZCBwZXJmb3JtYW5jZS5cclxuXHJcbiAgICAgICAgLy8gRHVtbXkgdmVsb2NpdHlNZXRyaWNzIGJhc2VkIG9uIGZldGNoZWQgcGVyZm9ybWFuY2VcclxuICAgICAgICBzZXRWZWxvY2l0eU1ldHJpY3MoW1xyXG4gICAgICAgICAgeyBtZXRyaWM6ICdBdmcgRGVhbCBTaXplJywgdmFsdWU6IGAke3BlcmZvcm1hbmNlLmF2Z0RlYWxTaXplLnRvTG9jYWxlU3RyaW5nKCl9YCwgY2hhbmdlOiAnJywgdHJlbmQ6ICd1cCcgfSxcclxuICAgICAgICAgIHsgbWV0cmljOiAnV2luIFJhdGUnLCB2YWx1ZTogYCR7cGVyZm9ybWFuY2UuY29udmVyc2lvblJhdGV9JWAsIGNoYW5nZTogJycsIHRyZW5kOiAndXAnIH0sXHJcbiAgICAgICAgICB7IG1ldHJpYzogJ0RlYWxzIFdvbicsIHZhbHVlOiBwZXJmb3JtYW5jZS5kZWFsc1dvbiwgY2hhbmdlOiAnJywgdHJlbmQ6ICd1cCcgfSxcclxuICAgICAgICAgIHsgbWV0cmljOiAnRGVhbHMgTG9zdCcsIHZhbHVlOiBwZXJmb3JtYW5jZS5kZWFsc0xvc3QsIGNoYW5nZTogJycsIHRyZW5kOiAnZG93bicgfSxcclxuICAgICAgICBdKTtcclxuXHJcbiAgICAgICAgLy8gVXNlIGFjdHVhbCBkYXRhIGZyb20gU3VwYWJhc2UgZm9yIHRlcnJpdG9yaWVzIGFuZCByZXBzXHJcbiAgICAgICAgLy8gRm9yIG5vdywgd2UnbGwgdXNlIHRoZSBnbG9iYWwgZGF0YSBhcyBhIHNpbmdsZSB0ZXJyaXRvcnkvcmVwIHNpbmNlIHdlIGRvbid0IGhhdmUgc2VwYXJhdGUgdGVycml0b3J5L3JlcCBkYXRhIGluIHRoZSBEQiB5ZXRcclxuICAgICAgICBzZXRUZXJyaXRvcnlEYXRhKFtcclxuICAgICAgICAgIHsgXHJcbiAgICAgICAgICAgIG5hbWU6ICdHbG9iYWwgVGVycml0b3J5JywgXHJcbiAgICAgICAgICAgIHJldmVudWU6IHBlcmZvcm1hbmNlLmFjaGlldmVkLCBcclxuICAgICAgICAgICAgZGVhbHM6IHBlcmZvcm1hbmNlLmRlYWxzV29uICsgcGVyZm9ybWFuY2UuZGVhbHNMb3N0LCBcclxuICAgICAgICAgICAgd2luUmF0ZTogcGVyZm9ybWFuY2UuY29udmVyc2lvblJhdGUsXHJcbiAgICAgICAgICAgIGF2Z0RlYWxTaXplOiBwZXJmb3JtYW5jZS5hdmdEZWFsU2l6ZVxyXG4gICAgICAgICAgfSxcclxuICAgICAgICBdKTtcclxuXHJcbiAgICAgICAgc2V0UmVwUGVyZm9ybWFuY2VEYXRhKFtcclxuICAgICAgICAgIHsgXHJcbiAgICAgICAgICAgIG5hbWU6ICdDdXJyZW50IFVzZXInLCBcclxuICAgICAgICAgICAgcmV2ZW51ZTogcGVyZm9ybWFuY2UuYWNoaWV2ZWQsIFxyXG4gICAgICAgICAgICBkZWFsczogcGVyZm9ybWFuY2UuZGVhbHNXb24sIFxyXG4gICAgICAgICAgICBxdW90YTogcGVyZm9ybWFuY2UucXVvdGEsIFxyXG4gICAgICAgICAgICBhdHRhaW5tZW50OiBwZXJmb3JtYW5jZS5wZXJjZW50YWdlIFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICBdKTtcclxuXHJcblxyXG4gICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIGZldGNoIGFuYWx5dGljcyBkYXRhOlwiLCBlcnIpO1xyXG4gICAgICAgIHNldEVycm9yKFwiRmFpbGVkIHRvIGxvYWQgYW5hbHl0aWNzIGRhdGEuIFBsZWFzZSB0cnkgYWdhaW4uXCIpO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGZldGNoRGF0YSgpO1xyXG4gIH0sIFtdKTsgLy8gRW1wdHkgZGVwZW5kZW5jeSBhcnJheSBtZWFucyB0aGlzIHJ1bnMgb25jZSBvbiBtb3VudFxyXG5cclxuICBpZiAobG9hZGluZykge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctYmFja2dyb3VuZCBmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgIDxMb2FkZXIyIGNsYXNzTmFtZT1cImgtMTAgdy0xMCBhbmltYXRlLXNwaW4gdGV4dC1wcmltYXJ5XCIgLz5cclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJtbC00IHRleHQtdGV4dC1zZWNvbmRhcnlcIj5Mb2FkaW5nIGFuYWx5dGljcyBkYXRhLi4uPC9wPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICBpZiAoZXJyb3IpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGJnLWJhY2tncm91bmQgZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWVycm9yIHRleHQtbGdcIj57ZXJyb3J9PC9wPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICBjb25zdCBkYXRlUmFuZ2VPcHRpb25zID0gW1xyXG4gICAgeyB2YWx1ZTogJ2xhc3Q3ZGF5cycsIGxhYmVsOiAnTGFzdCA3IERheXMnIH0sXHJcbiAgICB7IHZhbHVlOiAnbGFzdDMwZGF5cycsIGxhYmVsOiAnTGFzdCAzMCBEYXlzJyB9LFxyXG4gICAgeyB2YWx1ZTogJ2xhc3Q5MGRheXMnLCBsYWJlbDogJ0xhc3QgOTAgRGF5cycgfSxcclxuICAgIHsgdmFsdWU6ICd0aGlzcXVhcnRlcicsIGxhYmVsOiAnVGhpcyBRdWFydGVyJyB9LFxyXG4gICAgeyB2YWx1ZTogJ2xhc3R5ZWFyJywgbGFiZWw6ICdMYXN0IFllYXInIH0sXHJcbiAgICB7IHZhbHVlOiAnY3VzdG9tJywgbGFiZWw6ICdDdXN0b20gUmFuZ2UnIH1cclxuICBdO1xyXG5cclxuICBjb25zdCB0ZXJyaXRvcnlPcHRpb25zID0gW1xyXG4gICAgeyB2YWx1ZTogJ2FsbCcsIGxhYmVsOiAnQWxsIFRlcnJpdG9yaWVzJyB9LFxyXG4gICAgeyB2YWx1ZTogJ25vcnRoLWFtZXJpY2EnLCBsYWJlbDogJ05vcnRoIEFtZXJpY2EnIH0sXHJcbiAgICB7IHZhbHVlOiAnZXVyb3BlJywgbGFiZWw6ICdFdXJvcGUnIH0sXHJcbiAgICB7IHZhbHVlOiAnYXNpYS1wYWNpZmljJywgbGFiZWw6ICdBc2lhIFBhY2lmaWMnIH0sXHJcbiAgICB7IHZhbHVlOiAnbGF0aW4tYW1lcmljYScsIGxhYmVsOiAnTGF0aW4gQW1lcmljYScgfVxyXG4gIF07XHJcblxyXG4gIGNvbnN0IHJlcE9wdGlvbnMgPSBbXHJcbiAgICB7IHZhbHVlOiAnYWxsJywgbGFiZWw6ICdBbGwgUmVwcmVzZW50YXRpdmVzJyB9LFxyXG4gICAgeyB2YWx1ZTogJ3NhcmFoLWpvaG5zb24nLCBsYWJlbDogJ1NhcmFoIEpvaG5zb24nIH0sXHJcbiAgICB7IHZhbHVlOiAnbWljaGFlbC1jaGVuJywgbGFiZWw6ICdNaWNoYWVsIENoZW4nIH0sXHJcbiAgICB7IHZhbHVlOiAnZGF2aWQtcm9kcmlndWV6JywgbGFiZWw6ICdEYXZpZCBSb2RyaWd1ZXonIH0sXHJcbiAgICB7IHZhbHVlOiAnZW1pbHktZGF2aXMnLCBsYWJlbDogJ0VtaWx5IERhdmlzJyB9LFxyXG4gICAgeyB2YWx1ZTogJ2phbWVzLXdpbHNvbicsIGxhYmVsOiAnSmFtZXMgV2lsc29uJyB9XHJcbiAgXTtcclxuXHJcbiAgY29uc3QgdGFiT3B0aW9ucyA9IFtcclxuICAgIHsgaWQ6ICdvdmVydmlldycsIGxhYmVsOiAnT3ZlcnZpZXcnLCBpY29uOiAnQmFyQ2hhcnQzJyB9LFxyXG4gICAgeyBpZDogJ3BpcGVsaW5lJywgbGFiZWw6ICdQaXBlbGluZScsIGljb246ICdUcmVuZGluZ1VwJyB9LFxyXG4gICAgeyBpZDogJ3BlcmZvcm1hbmNlJywgbGFiZWw6ICdQZXJmb3JtYW5jZScsIGljb246ICdUYXJnZXQnIH0sXHJcbiAgICB7IGlkOiAnZm9yZWNhc3RpbmcnLCBsYWJlbDogJ0ZvcmVjYXN0aW5nJywgaWNvbjogJ0NhbGVuZGFyJyB9XHJcbiAgXTtcclxuXHJcbiAgY29uc3QgZXhwb3J0T3B0aW9ucyA9IFtcclxuICAgIHsgbGFiZWw6ICdFeHBvcnQgYXMgUERGJywgaWNvbjogJ0ZpbGVUZXh0JyB9LFxyXG4gICAgeyBsYWJlbDogJ0V4cG9ydCBhcyBFeGNlbCcsIGljb246ICdEb3dubG9hZCcgfSxcclxuICAgIHsgbGFiZWw6ICdTY2hlZHVsZSBFbWFpbCBSZXBvcnQnLCBpY29uOiAnTWFpbCcgfSxcclxuICAgIHsgbGFiZWw6ICdDcmVhdGUgRGFzaGJvYXJkIFdpZGdldCcsIGljb246ICdQbHVzJyB9XHJcbiAgXTtcclxuXHJcbiAgY29uc3QgZm9ybWF0Q3VycmVuY3kgPSAodmFsdWUpID0+IHtcclxuICAgIHJldHVybiBuZXcgSW50bC5OdW1iZXJGb3JtYXQoJ2VuLVVTJywge1xyXG4gICAgICBzdHlsZTogJ2N1cnJlbmN5JyxcclxuICAgICAgY3VycmVuY3k6ICdVU0QnLFxyXG4gICAgICBtaW5pbXVtRnJhY3Rpb25EaWdpdHM6IDAsXHJcbiAgICAgIG1heGltdW1GcmFjdGlvbkRpZ2l0czogMFxyXG4gICAgfSk/LmZvcm1hdCh2YWx1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZm9ybWF0UGVyY2VudGFnZSA9ICh2YWx1ZSkgPT4ge1xyXG4gICAgcmV0dXJuIGAke3ZhbHVlPy50b0ZpeGVkKDEpfSVgO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IEN1c3RvbVRvb2x0aXAgPSAoeyBhY3RpdmUsIHBheWxvYWQsIGxhYmVsIH0pID0+IHtcclxuICAgIGlmIChhY3RpdmUgJiYgcGF5bG9hZCAmJiBwYXlsb2FkPy5sZW5ndGgpIHtcclxuICAgICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXN1cmZhY2UgYm9yZGVyIGJvcmRlci1ib3JkZXIgcm91bmRlZC1sZyBzaGFkb3ctbGcgcC0zXCI+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbm9ybWFsIHRleHQtdGV4dC1wcmltYXJ5IG1iLTJcIj57bGFiZWx9PC9wPlxyXG4gICAgICAgICAge3BheWxvYWQ/Lm1hcCgoZW50cnksIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgIDxwIGtleT17aW5kZXh9IGNsYXNzTmFtZT1cInRleHQtc21cIiBzdHlsZT17eyBjb2xvcjogZW50cnk/LmNvbG9yIH19PlxyXG4gICAgICAgICAgICAgIHtlbnRyeT8ubmFtZX06IHt0eXBlb2YgZW50cnk/LnZhbHVlID09PSAnbnVtYmVyJyAmJiBlbnRyeT8udmFsdWUgPiAxMDAwID8gZm9ybWF0Q3VycmVuY3koZW50cnk/LnZhbHVlKSA6IGVudHJ5Py52YWx1ZX1cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gbnVsbDtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctYmFja2dyb3VuZFwiPlxyXG4gICAgICA8SGVhZGVyIC8+XHJcbiAgICAgIDxtYWluIGNsYXNzTmFtZT1cInB0LTE2XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC02IHB5LThcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctN3hsIG14LWF1dG9cIj5cclxuICAgICAgICAgICAgPEJyZWFkY3J1bWIgLz5cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIHsvKiBQYWdlIEhlYWRlciAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGxnOmZsZXgtcm93IGxnOml0ZW1zLWNlbnRlciBsZzpqdXN0aWZ5LWJldHdlZW4gbWItOFwiPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtdGV4dC1wcmltYXJ5IG1iLTJcIj5QaXBlbGluZSBBbmFseXRpY3M8L2gxPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC10ZXh0LXNlY29uZGFyeVwiPkNvbXByZWhlbnNpdmUgc2FsZXMgcGVyZm9ybWFuY2UgaW5zaWdodHMgYW5kIGZvcmVjYXN0aW5nPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0zIG10LTQgbGc6bXQtMFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNFeHBvcnRNZW51T3BlbighaXNFeHBvcnRNZW51T3Blbil9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLXByaW1hcnkgZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJEb3dubG9hZFwiIHNpemU9ezE2fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPkV4cG9ydDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiQ2hldnJvbkRvd25cIiBzaXplPXsxNH0gLz5cclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICB7aXNFeHBvcnRNZW51T3BlbiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC0wIG10LTIgdy01NiBiZy1zdXJmYWNlIHJvdW5kZWQtbGcgc2hhZG93LWxnIGJvcmRlciBib3JkZXItYm9yZGVyIHotNTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXhwb3J0T3B0aW9ucz8ubWFwKChvcHRpb24pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e29wdGlvbj8ubGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0zIHB4LTQgcHktMiB0ZXh0LXNtIHRleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC10ZXh0LXByaW1hcnkgaG92ZXI6Ymctc3VyZmFjZS1ob3ZlciB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNFeHBvcnRNZW51T3BlbihmYWxzZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT17b3B0aW9uPy5pY29ufSBzaXplPXsxNn0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntvcHRpb24/LmxhYmVsfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLWxnIHRleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC10ZXh0LXByaW1hcnkgaG92ZXI6Ymctc3VyZmFjZS1ob3ZlciB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0xNTAgZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJTZXR0aW5nc1wiIHNpemU9ezE2fSAvPlxyXG4gICAgICAgICAgICAgICAgICA8c3Bhbj5DdXN0b21pemU8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogRmlsdGVycyAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIHAtNiBtYi04XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW5vcm1hbCB0ZXh0LXRleHQtcHJpbWFyeSBtYi0yXCI+RGF0ZSBSYW5nZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWREYXRlUmFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWxlY3RlZERhdGVSYW5nZShlPy50YXJnZXQ/LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbnB1dC1maWVsZFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7ZGF0ZVJhbmdlT3B0aW9ucz8ubWFwKChvcHRpb24pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtvcHRpb24/LnZhbHVlfSB2YWx1ZT17b3B0aW9uPy52YWx1ZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtvcHRpb24/LmxhYmVsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbm9ybWFsIHRleHQtdGV4dC1wcmltYXJ5IG1iLTJcIj5UZXJyaXRvcnk8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkVGVycml0b3J5fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VsZWN0ZWRUZXJyaXRvcnkoZT8udGFyZ2V0Py52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5wdXQtZmllbGRcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge3RlcnJpdG9yeU9wdGlvbnM/Lm1hcCgob3B0aW9uKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17b3B0aW9uPy52YWx1ZX0gdmFsdWU9e29wdGlvbj8udmFsdWV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7b3B0aW9uPy5sYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW5vcm1hbCB0ZXh0LXRleHQtcHJpbWFyeSBtYi0yXCI+U2FsZXMgUmVwPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZFJlcH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlbGVjdGVkUmVwKGU/LnRhcmdldD8udmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlucHV0LWZpZWxkXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtyZXBPcHRpb25zPy5tYXAoKG9wdGlvbikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e29wdGlvbj8udmFsdWV9IHZhbHVlPXtvcHRpb24/LnZhbHVlfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge29wdGlvbj8ubGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWVuZFwiPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0bi1zZWNvbmRhcnkgdy1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHNwYWNlLXgtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJTZWFyY2hcIiBzaXplPXsxNn0gLz5cclxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5BcHBseSBGaWx0ZXJzPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBUYWIgTmF2aWdhdGlvbiAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItYm9yZGVyIG1iLThcIj5cclxuICAgICAgICAgICAgICA8bmF2IGNsYXNzTmFtZT1cImZsZXggc3BhY2UteC04XCI+XHJcbiAgICAgICAgICAgICAgICB7dGFiT3B0aW9ucz8ubWFwKCh0YWIpID0+IChcclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIGtleT17dGFiPy5pZH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIodGFiPy5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yIHB5LTQgcHgtMSBib3JkZXItYi0yIGZvbnQtbm9ybWFsIHRleHQtc20gdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwICR7XHJcbiAgICAgICAgICAgICAgICAgICAgICBhY3RpdmVUYWIgPT09IHRhYj8uaWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyAnYm9yZGVyLXByaW1hcnkgdGV4dC1wcmltYXJ5JyA6J2JvcmRlci10cmFuc3BhcmVudCB0ZXh0LXRleHQtc2Vjb25kYXJ5IGhvdmVyOnRleHQtdGV4dC1wcmltYXJ5IGhvdmVyOmJvcmRlci1ib3JkZXItZGFyaydcclxuICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9e3RhYj8uaWNvbn0gc2l6ZT17MTZ9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3RhYj8ubGFiZWx9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDwvbmF2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBPdmVydmlldyBUYWIgKi99XHJcbiAgICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdvdmVydmlldycgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS04XCI+XHJcbiAgICAgICAgICAgICAgICB7LyogS2V5IE1ldHJpY3MgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLTZcIj5cclxuICAgICAgICAgICAgICAgICAge3ZlbG9jaXR5TWV0cmljcz8ubWFwKChtZXRyaWMpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17bWV0cmljPy5tZXRyaWN9IGNsYXNzTmFtZT1cImNhcmQgcC02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbm9ybWFsIHRleHQtdGV4dC1zZWNvbmRhcnlcIj57bWV0cmljPy5tZXRyaWN9PC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTEgJHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBtZXRyaWM/LnRyZW5kID09PSAndXAnID8gJ3RleHQtc3VjY2VzcycgOiAndGV4dC1lcnJvcidcclxuICAgICAgICAgICAgICAgICAgICAgICAgfWB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9e21ldHJpYz8udHJlbmQgPT09ICd1cCcgPyAnVHJlbmRpbmdVcCcgOiAnVHJlbmRpbmdEb3duJ30gc2l6ZT17MTR9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW5vcm1hbFwiPnttZXRyaWM/LmNoYW5nZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LW5vcm1hbCB0ZXh0LXRleHQtcHJpbWFyeVwiPnttZXRyaWM/LnZhbHVlfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogQ2hhcnRzIEdyaWQgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbGc6Z3JpZC1jb2xzLTIgZ2FwLThcIj5cclxuICAgICAgICAgICAgICAgICAgey8qIFBpcGVsaW5lIEZ1bm5lbCAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIHAtNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbm9ybWFsIHRleHQtdGV4dC1wcmltYXJ5IG1iLTZcIj5QaXBlbGluZSBGdW5uZWw8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC04MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFJlc3BvbnNpdmVDb250YWluZXIgd2lkdGg9XCIxMDAlXCIgaGVpZ2h0PVwiMTAwJVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8RnVubmVsQ2hhcnQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFRvb2x0aXAgY29udGVudD17PEN1c3RvbVRvb2x0aXAgLz59IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPEZ1bm5lbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YUtleT1cInZhbHVlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGE9e3BpcGVsaW5lRnVubmVsRGF0YX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzQW5pbWF0aW9uQWN0aXZlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPExhYmVsTGlzdCBwb3NpdGlvbj1cImNlbnRlclwiIGZpbGw9XCIjZmZmXCIgc3Ryb2tlPVwibm9uZVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9GdW5uZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvRnVubmVsQ2hhcnQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1Jlc3BvbnNpdmVDb250YWluZXI+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIFJldmVudWUgVHJlbmQgKi99XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZCBwLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW5vcm1hbCB0ZXh0LXRleHQtcHJpbWFyeSBtYi02XCI+UmV2ZW51ZSBUcmVuZDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTgwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8UmVzcG9uc2l2ZUNvbnRhaW5lciB3aWR0aD1cIjEwMCVcIiBoZWlnaHQ9XCIxMDAlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5lQ2hhcnQgZGF0YT17cmV2ZW51ZVRyZW5kRGF0YX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPENhcnRlc2lhbkdyaWQgc3Ryb2tlRGFzaGFycmF5PVwiMyAzXCIgc3Ryb2tlPVwiI0U1RTdFQlwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFhBeGlzIGRhdGFLZXk9XCJtb250aFwiIHN0cm9rZT1cIiM2QjcyODBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxZQXhpcyBzdHJva2U9XCIjNkI3MjgwXCIgdGlja0Zvcm1hdHRlcj17KHZhbHVlKSA9PiBgJCR7dmFsdWUvMTAwMH1rYH0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8VG9vbHRpcCBjb250ZW50PXs8Q3VzdG9tVG9vbHRpcCAvPn0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8TGluZSB0eXBlPVwibW9ub3RvbmVcIiBkYXRhS2V5PVwiYWN0dWFsXCIgc3Ryb2tlPVwiIzNCODJGNlwiIHN0cm9rZVdpZHRoPXszfSBuYW1lPVwiQWN0dWFsXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8TGluZSB0eXBlPVwibW9ub3RvbmVcIiBkYXRhS2V5PVwiZm9yZWNhc3RcIiBzdHJva2U9XCIjNjM2NkYxXCIgc3Ryb2tlV2lkdGg9ezJ9IHN0cm9rZURhc2hhcnJheT1cIjUgNVwiIG5hbWU9XCJGb3JlY2FzdFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmUgdHlwZT1cIm1vbm90b25lXCIgZGF0YUtleT1cInRhcmdldFwiIHN0cm9rZT1cIiMxMEI5ODFcIiBzdHJva2VXaWR0aD17Mn0gbmFtZT1cIlRhcmdldFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluZUNoYXJ0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9SZXNwb25zaXZlQ29udGFpbmVyPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBXaW4gUmF0ZSBBbmFseXNpcyAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZCBwLTZcIj5cclxuICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ub3JtYWwgdGV4dC10ZXh0LXByaW1hcnkgbWItNlwiPldpbiBSYXRlIEFuYWx5c2lzPC9oMz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTgwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFJlc3BvbnNpdmVDb250YWluZXIgd2lkdGg9XCIxMDAlXCIgaGVpZ2h0PVwiMTAwJVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEJhckNoYXJ0IGRhdGE9e3dpblJhdGVEYXRhfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPENhcnRlc2lhbkdyaWQgc3Ryb2tlRGFzaGFycmF5PVwiMyAzXCIgc3Ryb2tlPVwiI0U1RTdFQlwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxYQXhpcyBkYXRhS2V5PVwicGVyaW9kXCIgc3Ryb2tlPVwiIzZCNzI4MFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxZQXhpcyBzdHJva2U9XCIjNkI3MjgwXCIgdGlja0Zvcm1hdHRlcj17KHZhbHVlKSA9PiBgJHt2YWx1ZX0lYH0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFRvb2x0aXAgY29udGVudD17PEN1c3RvbVRvb2x0aXAgLz59IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCYXIgZGF0YUtleT1cIndpblJhdGVcIiBmaWxsPVwiIzNCODJGNlwiIG5hbWU9XCJXaW4gUmF0ZSAlXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvQmFyQ2hhcnQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9SZXNwb25zaXZlQ29udGFpbmVyPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgey8qIFBpcGVsaW5lIFRhYiAqL31cclxuICAgICAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ3BpcGVsaW5lJyAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LThcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBsZzpncmlkLWNvbHMtMyBnYXAtOFwiPlxyXG4gICAgICAgICAgICAgICAgICB7LyogUGlwZWxpbmUgVmFsdWUgYnkgU3RhZ2UgKi99XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6Y29sLXNwYW4tMiBjYXJkIHAtNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbm9ybWFsIHRleHQtdGV4dC1wcmltYXJ5IG1iLTZcIj5QaXBlbGluZSBWYWx1ZSBieSBTdGFnZTwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTgwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8UmVzcG9uc2l2ZUNvbnRhaW5lciB3aWR0aD1cIjEwMCVcIiBoZWlnaHQ9XCIxMDAlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCYXJDaGFydCBkYXRhPXtwaXBlbGluZUZ1bm5lbERhdGF9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxDYXJ0ZXNpYW5HcmlkIHN0cm9rZURhc2hhcnJheT1cIjMgM1wiIHN0cm9rZT1cIiNFNUU3RUJcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxYQXhpcyBkYXRhS2V5PVwibmFtZVwiIHN0cm9rZT1cIiM2QjcyODBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxZQXhpcyBzdHJva2U9XCIjNkI3MjgwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8VG9vbHRpcCBjb250ZW50PXs8Q3VzdG9tVG9vbHRpcCAvPn0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8QmFyIGRhdGFLZXk9XCJ2YWx1ZVwiIGZpbGw9XCIjM0I4MkY2XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9CYXJDaGFydD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvUmVzcG9uc2l2ZUNvbnRhaW5lcj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7LyogUGlwZWxpbmUgSGVhbHRoICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgcC02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ub3JtYWwgdGV4dC10ZXh0LXByaW1hcnkgbWItNlwiPlBpcGVsaW5lIEhlYWx0aDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC10ZXh0LXNlY29uZGFyeVwiPlRvdGFsIFBpcGVsaW5lPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbm9ybWFsIHRleHQtdGV4dC1wcmltYXJ5XCI+e2Zvcm1hdEN1cnJlbmN5KChwaXBlbGluZUZ1bm5lbERhdGEgfHwgW10pLnJlZHVjZSgoc3VtLCBzdGFnZSkgPT4gc3VtICsgKHN0YWdlPy52YWx1ZSB8fCAwKSwgMCkpfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+V2VpZ2h0ZWQgUGlwZWxpbmU8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ub3JtYWwgdGV4dC10ZXh0LXByaW1hcnlcIj57Zm9ybWF0Q3VycmVuY3koKHBpcGVsaW5lRnVubmVsRGF0YSB8fCBbXSkucmVkdWNlKChzdW0sIHN0YWdlKSA9PiBzdW0gKyAoKHN0YWdlPy52YWx1ZSB8fCAwKSAqIChzdGFnZT8ubmFtZSA9PT0gJ0xlYWRzJyA/IDAuMSA6IHN0YWdlPy5uYW1lID09PSAnUXVhbGlmaWVkJyA/IDAuMjUgOiBzdGFnZT8ubmFtZSA9PT0gJ1Byb3Bvc2FsJyA/IDAuNSA6IHN0YWdlPy5uYW1lID09PSAnTmVnb3RpYXRpb24nID8gMC43NSA6IDEpKSwgMCkpfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+QmVzdCBDYXNlPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbm9ybWFsIHRleHQtc3VjY2Vzc1wiPntmb3JtYXRDdXJyZW5jeSgocGlwZWxpbmVGdW5uZWxEYXRhIHx8IFtdKS5yZWR1Y2UoKHN1bSwgc3RhZ2UpID0+IHN1bSArIChzdGFnZT8udmFsdWUgfHwgMCksIDApICogMS4xKX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC10ZXh0LXNlY29uZGFyeVwiPldvcnN0IENhc2U8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ub3JtYWwgdGV4dC1lcnJvclwiPntmb3JtYXRDdXJyZW5jeSgocGlwZWxpbmVGdW5uZWxEYXRhIHx8IFtdKS5yZWR1Y2UoKHN1bSwgc3RhZ2UpID0+IHN1bSArIChzdGFnZT8udmFsdWUgfHwgMCksIDApICogMC44KX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtNCBib3JkZXItdCBib3JkZXItYm9yZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+Q292ZXJhZ2UgUmF0aW88L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW5vcm1hbCB0ZXh0LXByaW1hcnlcIj57KChwaXBlbGluZUZ1bm5lbERhdGEgfHwgW10pLnJlZHVjZSgoc3VtLCBzdGFnZSkgPT4gc3VtICsgKHN0YWdlPy52YWx1ZSB8fCAwKSwgMCkgLyAyNTAwMDAwKS50b0ZpeGVkKDEpfXg8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIFRlcnJpdG9yeSBQZXJmb3JtYW5jZSAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZCBwLTZcIj5cclxuICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ub3JtYWwgdGV4dC10ZXh0LXByaW1hcnkgbWItNlwiPlRlcnJpdG9yeSBQZXJmb3JtYW5jZTwvaDM+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRoZWFkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLWJvcmRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgcHktMyBweC00IHRleHQtc20gZm9udC1ub3JtYWwgdGV4dC10ZXh0LXNlY29uZGFyeVwiPlRlcnJpdG9yeTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInRleHQtcmlnaHQgcHktMyBweC00IHRleHQtc20gZm9udC1ub3JtYWwgdGV4dC10ZXh0LXNlY29uZGFyeVwiPlJldmVudWU8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0IHB5LTMgcHgtNCB0ZXh0LXNtIGZvbnQtbm9ybWFsIHRleHQtdGV4dC1zZWNvbmRhcnlcIj5EZWFsczwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInRleHQtcmlnaHQgcHktMyBweC00IHRleHQtc20gZm9udC1ub3JtYWwgdGV4dC10ZXh0LXNlY29uZGFyeVwiPldpbiBSYXRlPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwidGV4dC1yaWdodCBweS0zIHB4LTQgdGV4dC1zbSBmb250LW5vcm1hbCB0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+QXZnIERlYWwgU2l6ZTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRib2R5PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7dGVycml0b3J5RGF0YT8ubWFwKCh0ZXJyaXRvcnkpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXt0ZXJyaXRvcnk/Lm5hbWV9IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ib3JkZXItbGlnaHQgaG92ZXI6Ymctc3VyZmFjZS1ob3ZlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtNCB0ZXh0LXNtIGZvbnQtbm9ybWFsIHRleHQtdGV4dC1wcmltYXJ5XCI+e3RlcnJpdG9yeT8ubmFtZX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtNCB0ZXh0LXNtIHRleHQtdGV4dC1wcmltYXJ5IHRleHQtcmlnaHRcIj57Zm9ybWF0Q3VycmVuY3kodGVycml0b3J5Py5yZXZlbnVlKX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtNCB0ZXh0LXNtIHRleHQtdGV4dC1wcmltYXJ5IHRleHQtcmlnaHRcIj57dGVycml0b3J5Py5kZWFsc308L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtNCB0ZXh0LXNtIHRleHQtdGV4dC1wcmltYXJ5IHRleHQtcmlnaHRcIj57Zm9ybWF0UGVyY2VudGFnZSh0ZXJyaXRvcnk/LndpblJhdGUpfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC00IHRleHQtc20gdGV4dC10ZXh0LXByaW1hcnkgdGV4dC1yaWdodFwiPntmb3JtYXRDdXJyZW5jeSh0ZXJyaXRvcnk/LmF2Z0RlYWxTaXplIHx8ICh0ZXJyaXRvcnk/LnJldmVudWUgLyB0ZXJyaXRvcnk/LmRlYWxzKSB8fCAwKX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgey8qIFBlcmZvcm1hbmNlIFRhYiAqL31cclxuICAgICAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ3BlcmZvcm1hbmNlJyAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LThcIj5cclxuICAgICAgICAgICAgICAgIHsvKiBSZXAgUGVyZm9ybWFuY2UgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgcC02XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbm9ybWFsIHRleHQtdGV4dC1wcmltYXJ5IG1iLTZcIj5TYWxlcyBSZXByZXNlbnRhdGl2ZSBQZXJmb3JtYW5jZTwvaDM+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRoZWFkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLWJvcmRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgcHktMyBweC00IHRleHQtc20gZm9udC1ub3JtYWwgdGV4dC10ZXh0LXNlY29uZGFyeVwiPlJlcHJlc2VudGF0aXZlPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwidGV4dC1yaWdodCBweS0zIHB4LTQgdGV4dC1zbSBmb250LW5vcm1hbCB0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+UmV2ZW51ZTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInRleHQtcmlnaHQgcHktMyBweC00IHRleHQtc20gZm9udC1ub3JtYWwgdGV4dC10ZXh0LXNlY29uZGFyeVwiPkRlYWxzPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwidGV4dC1yaWdodCBweS0zIHB4LTQgdGV4dC1zbSBmb250LW5vcm1hbCB0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+UXVvdGE8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0IHB5LTMgcHgtNCB0ZXh0LXNtIGZvbnQtbm9ybWFsIHRleHQtdGV4dC1zZWNvbmRhcnlcIj5BdHRhaW5tZW50PC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwidGV4dC1yaWdodCBweS0zIHB4LTQgdGV4dC1zbSBmb250LW5vcm1hbCB0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+UHJvZ3Jlc3M8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3JlcFBlcmZvcm1hbmNlRGF0YT8ubWFwKChyZXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtyZXA/Lm5hbWV9IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ib3JkZXItbGlnaHQgaG92ZXI6Ymctc3VyZmFjZS1ob3ZlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtNCB0ZXh0LXNtIGZvbnQtbm9ybWFsIHRleHQtdGV4dC1wcmltYXJ5XCI+e3JlcD8ubmFtZX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtNCB0ZXh0LXNtIHRleHQtdGV4dC1wcmltYXJ5IHRleHQtcmlnaHRcIj57Zm9ybWF0Q3VycmVuY3kocmVwPy5yZXZlbnVlKX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtNCB0ZXh0LXNtIHRleHQtdGV4dC1wcmltYXJ5IHRleHQtcmlnaHRcIj57cmVwPy5kZWFsc308L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtNCB0ZXh0LXNtIHRleHQtdGV4dC1wcmltYXJ5IHRleHQtcmlnaHRcIj57Zm9ybWF0Q3VycmVuY3kocmVwPy5xdW90YSl9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTQgdGV4dC1zbSB0ZXh0LXRleHQtcHJpbWFyeSB0ZXh0LXJpZ2h0XCI+e3JlcD8uYXR0YWlubWVudH0lPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTQgdGV4dC1yaWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMjAgYmctYm9yZGVyLWxpZ2h0IHJvdW5kZWQtZnVsbCBoLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BoLTIgcm91bmRlZC1mdWxsICR7cmVwPy5hdHRhaW5tZW50ID49IDEwMCA/ICdiZy1zdWNjZXNzJyA6IHJlcD8uYXR0YWlubWVudCA+PSA4MCA/ICdiZy13YXJuaW5nJyA6ICdiZy1wcmltYXJ5J31gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IGAke01hdGgubWluKHJlcD8uYXR0YWlubWVudCwgMTAwKX0lYCB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBQZXJmb3JtYW5jZSBDaGFydHMgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbGc6Z3JpZC1jb2xzLTIgZ2FwLThcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIHAtNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbm9ybWFsIHRleHQtdGV4dC1wcmltYXJ5IG1iLTZcIj5RdW90YSBBdHRhaW5tZW50PC9oMz5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtODBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxSZXNwb25zaXZlQ29udGFpbmVyIHdpZHRoPVwiMTAwJVwiIGhlaWdodD1cIjEwMCVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEJhckNoYXJ0IGRhdGE9e3JlcFBlcmZvcm1hbmNlRGF0YX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPENhcnRlc2lhbkdyaWQgc3Ryb2tlRGFzaGFycmF5PVwiMyAzXCIgc3Ryb2tlPVwiI0U1RTdFQlwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFhBeGlzIGRhdGFLZXk9XCJuYW1lXCIgc3Ryb2tlPVwiIzZCNzI4MFwiIGFuZ2xlPXstNDV9IHRleHRBbmNob3I9XCJlbmRcIiBoZWlnaHQ9ezgwfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxZQXhpcyBzdHJva2U9XCIjNkI3MjgwXCIgdGlja0Zvcm1hdHRlcj17KHZhbHVlKSA9PiBgJHt2YWx1ZX0lYH0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8VG9vbHRpcCBjb250ZW50PXs8Q3VzdG9tVG9vbHRpcCAvPn0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8QmFyIGRhdGFLZXk9XCJhdHRhaW5tZW50XCIgZmlsbD1cIiMzQjgyRjZcIiBuYW1lPVwiQXR0YWlubWVudCAlXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9CYXJDaGFydD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvUmVzcG9uc2l2ZUNvbnRhaW5lcj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgcC02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ub3JtYWwgdGV4dC10ZXh0LXByaW1hcnkgbWItNlwiPlJldmVudWUgYnkgUmVwPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtODBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxSZXNwb25zaXZlQ29udGFpbmVyIHdpZHRoPVwiMTAwJVwiIGhlaWdodD1cIjEwMCVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFBpZUNoYXJ0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxQaWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGE9e3JlcFBlcmZvcm1hbmNlRGF0YX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN4PVwiNTAlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN5PVwiNTAlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG91dGVyUmFkaXVzPXsxMDB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWxsPVwiIzNCODJGNlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhS2V5PVwicmV2ZW51ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD17KHsgbmFtZSwgcGVyY2VudCB9KSA9PiBgJHtuYW1lfTogJHsocGVyY2VudCAqIDEwMCk/LnRvRml4ZWQoMCl9JWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3JlcFBlcmZvcm1hbmNlRGF0YT8ubWFwKChlbnRyeSwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENlbGwga2V5PXtgY2VsbC0ke2luZGV4fWB9IGZpbGw9e2Boc2woJHsyMjAgKyBpbmRleCAqIDMwfSwgNzAlLCAkezUwICsgaW5kZXggKiAxMH0lKWB9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L1BpZT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8VG9vbHRpcCBjb250ZW50PXs8Q3VzdG9tVG9vbHRpcCAvPn0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9QaWVDaGFydD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvUmVzcG9uc2l2ZUNvbnRhaW5lcj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHsvKiBGb3JlY2FzdGluZyBUYWIgKi99XHJcbiAgICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdmb3JlY2FzdGluZycgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS04XCI+XHJcbiAgICAgICAgICAgICAgICB7LyogRm9yZWNhc3QgU3VtbWFyeSAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNlwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgcC02IHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ub3JtYWwgdGV4dC10ZXh0LXNlY29uZGFyeSBtYi0yXCI+VG90YWwgRm9yZWNhc3Q8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtbm9ybWFsIHRleHQtcHJpbWFyeSBtYi0xXCI+e2Zvcm1hdEN1cnJlbmN5KChyZXZlbnVlVHJlbmREYXRhIHx8IFtdKS5yZWR1Y2UoKHN1bSwgbW9udGgpID0+IHN1bSArIChtb250aD8uZm9yZWNhc3QgfHwgMCksIDApKX08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXN1Y2Nlc3MgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgc3BhY2UteC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiVHJlbmRpbmdVcFwiIHNpemU9ezE0fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+QmFzZWQgb24gZXhwZWN0ZWQgY2xvc2UgZGF0ZXM8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZCBwLTYgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW5vcm1hbCB0ZXh0LXRleHQtc2Vjb25kYXJ5IG1iLTJcIj5Ub3RhbCBBY3R1YWwgUmV2ZW51ZTwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ub3JtYWwgdGV4dC1zZWNvbmRhcnkgbWItMVwiPntmb3JtYXRDdXJyZW5jeSgocmV2ZW51ZVRyZW5kRGF0YSB8fCBbXSkucmVkdWNlKChzdW0sIG1vbnRoKSA9PiBzdW0gKyAobW9udGg/LmFjdHVhbCB8fCAwKSwgMCkpfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtdGV4dC1zZWNvbmRhcnlcIj5Gcm9tIGNsb3NlZCB3b24gZGVhbHM8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIHAtNiB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbm9ybWFsIHRleHQtdGV4dC1zZWNvbmRhcnkgbWItMlwiPk92ZXJhbGwgV2luIFJhdGU8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtbm9ybWFsIHRleHQtYWNjZW50IG1iLTFcIj57dmVsb2NpdHlNZXRyaWNzPy5maW5kKG0gPT4gbS5tZXRyaWMgPT09ICdXaW4gUmF0ZScpPy52YWx1ZSB8fCAnMCUnfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtdGV4dC1zZWNvbmRhcnlcIj5PZiBhbGwgZGVhbHM8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIEZvcmVjYXN0IENoYXJ0ICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIHAtNlwiPlxyXG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW5vcm1hbCB0ZXh0LXRleHQtcHJpbWFyeSBtYi02XCI+UmV2ZW51ZSBGb3JlY2FzdCB2cyBBY3R1YWw8L2gzPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtODBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8UmVzcG9uc2l2ZUNvbnRhaW5lciB3aWR0aD1cIjEwMCVcIiBoZWlnaHQ9XCIxMDAlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8TGluZUNoYXJ0IGRhdGE9e3JldmVudWVUcmVuZERhdGF9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Q2FydGVzaWFuR3JpZCBzdHJva2VEYXNoYXJyYXk9XCIzIDNcIiBzdHJva2U9XCIjRTVFN0VCXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFhBeGlzIGRhdGFLZXk9XCJtb250aFwiIHN0cm9rZT1cIiM2QjcyODBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8WUF4aXMgc3Ryb2tlPVwiIzZCNzI4MFwiIHRpY2tGb3JtYXR0ZXI9eyh2YWx1ZSkgPT4gYCQke3ZhbHVlLzEwMDB9a2B9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxUb29sdGlwIGNvbnRlbnQ9ezxDdXN0b21Ub29sdGlwIC8+fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8TGluZSB0eXBlPVwibW9ub3RvbmVcIiBkYXRhS2V5PVwiYWN0dWFsXCIgc3Ryb2tlPVwiIzNCODJGNlwiIHN0cm9rZVdpZHRoPXszfSBuYW1lPVwiQWN0dWFsIFJldmVudWVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8TGluZSB0eXBlPVwibW9ub3RvbmVcIiBkYXRhS2V5PVwiZm9yZWNhc3RcIiBzdHJva2U9XCIjNjM2NkYxXCIgc3Ryb2tlV2lkdGg9ezJ9IHN0cm9rZURhc2hhcnJheT1cIjUgNVwiIG5hbWU9XCJGb3JlY2FzdFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5lIHR5cGU9XCJtb25vdG9uZVwiIGRhdGFLZXk9XCJ0YXJnZXRcIiBzdHJva2U9XCIjMTBCOTgxXCIgc3Ryb2tlV2lkdGg9ezJ9IG5hbWU9XCJUYXJnZXRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9MaW5lQ2hhcnQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9SZXNwb25zaXZlQ29udGFpbmVyPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvbWFpbj5cclxuICAgICAgey8qIENsaWNrIG91dHNpZGUgaGFuZGxlciBmb3IgZXhwb3J0IG1lbnUgKi99XHJcbiAgICAgIHtpc0V4cG9ydE1lbnVPcGVuICYmIChcclxuICAgICAgICA8ZGl2XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNDBcIlxyXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNFeHBvcnRNZW51T3BlbihmYWxzZSl9XHJcbiAgICAgICAgPjwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFBpcGVsaW5lQW5hbHl0aWNzOyJdLCJmaWxlIjoiRDovY3VycmVudCBwcm9qZWN0cy9jbGF1ZGUtY29kZS9zcmMvcGFnZXMvcGlwZWxpbmUtYW5hbHl0aWNzL2luZGV4LmpzeCJ9