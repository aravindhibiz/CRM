import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/contact-management/components/AddActivityModal.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import toast from "/node_modules/.vite/deps/react-hot-toast.js?v=44ab9529";
import { useAuth } from "/src/contexts/AuthContext.jsx";
import Icon from "/src/components/AppIcon.jsx";
const AddActivityModal = ({ contact, onClose, onActivityAdded }) => {
  _s();
  const { user } = useAuth();
  const [activityData, setActivityData] = useState({
    type: "note",
    subject: "",
    description: "",
    scheduled_at: (/* @__PURE__ */ new Date()).toISOString().slice(0, 16),
    // Format: YYYY-MM-DDThh:mm
    duration_minutes: 30
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const activityTypes = [
    { value: "note", label: "Note", icon: "FileText" },
    { value: "call", label: "Call", icon: "Phone" },
    { value: "email", label: "Email", icon: "Mail" },
    { value: "meeting", label: "Meeting", icon: "Calendar" },
    { value: "task", label: "Task", icon: "CheckSquare" },
    { value: "demo", label: "Demo", icon: "Monitor" },
    { value: "proposal_sent", label: "Proposal Sent", icon: "FileText" },
    { value: "document_shared", label: "Document Shared", icon: "Share" }
  ];
  const handleChange = (e) => {
    const { name, value } = e.target;
    setActivityData({
      ...activityData,
      [name]: value
    });
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!activityData.subject.trim()) {
      toast.error("Please enter a subject for the activity");
      return;
    }
    setIsSubmitting(true);
    try {
      const activityPayload = {
        type: activityData.type,
        subject: activityData.subject,
        description: activityData.description,
        duration_minutes: activityData.duration_minutes,
        scheduled_at: new Date(activityData.scheduled_at).toISOString(),
        contact_id: contact?.id,
        user_id: user?.id
      };
      await onActivityAdded(activityPayload);
      toast.success(`${activityData.type.charAt(0).toUpperCase() + activityData.type.slice(1)} activity logged successfully!`);
      onClose();
    } catch (error) {
      console.error("Error adding activity:", error);
      toast.error("Failed to log activity. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };
  const selectedType = activityTypes.find((type) => type.value === activityData.type);
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:71:4", "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx", "data-component-line": "71", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20z-1100%20overflow-y-auto%22%7D", className: "fixed inset-0 z-1100 overflow-y-auto", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:72:6", "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx", "data-component-line": "72", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-center%20min-h-screen%20px-4%20pt-4%20pb-20%20text-center%20sm%3Ablock%20sm%3Ap-0%22%7D", className: "flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0", children: [
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:73:8", "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx", "data-component-line": "73", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20transition-opacity%22%7D", className: "fixed inset-0 transition-opacity", "aria-hidden": "true", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:74:10", "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx", "data-component-line": "74", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22absolute%20inset-0%20bg-black%20bg-opacity-50%22%7D", className: "absolute inset-0 bg-black bg-opacity-50" }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
      lineNumber: 74,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
      lineNumber: 73,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:77:8", "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx", "data-component-line": "77", "data-component-file": "AddActivityModal.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22hidden%20sm%3Ainline-block%20sm%3Aalign-middle%20sm%3Ah-screen%22%2C%22textContent%22%3A%22%E2%80%8B%22%7D", className: "hidden sm:inline-block sm:align-middle sm:h-screen", "aria-hidden": "true", children: "​" }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
      lineNumber: 77,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:79:8", "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx", "data-component-line": "79", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22inline-block%20align-bottom%20bg-surface%20rounded-lg%20text-left%20overflow-hidden%20shadow-xl%20transform%20transition-all%20sm%3Amy-8%20sm%3Aalign-middle%20sm%3Amax-w-lg%20sm%3Aw-full%22%7D", className: "inline-block align-bottom bg-surface rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full", children: /* @__PURE__ */ jsxDEV("form", { "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:80:10", "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx", "data-component-line": "80", "data-component-file": "AddActivityModal.jsx", "data-component-name": "form", "data-component-content": "%7B%22elementName%22%3A%22form%22%7D", onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:81:12", "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx", "data-component-line": "81", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22px-6%20py-4%20border-b%20border-border%20flex%20justify-between%20items-center%22%7D", className: "px-6 py-4 border-b border-border flex justify-between items-center", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:82:14", "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx", "data-component-line": "82", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%22%7D", className: "flex items-center space-x-2", children: [
          /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:83:16", "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx", "data-component-line": "83", "data-component-file": "AddActivityModal.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22className%22%3A%22text-primary%22%7D", name: selectedType?.icon, size: 20, className: "text-primary" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
            lineNumber: 83,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:84:16", "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx", "data-component-line": "84", "data-component-file": "AddActivityModal.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%2C%22textContent%22%3A%22Log%20Activity%22%7D", className: "text-lg font-semibold text-text-primary", children: "Log Activity" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
            lineNumber: 84,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
          lineNumber: 82,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:86:14",
            "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx",
            "data-component-line": "86",
            "data-component-file": "AddActivityModal.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22button%22%2C%22className%22%3A%22text-text-secondary%20hover%3Atext-text-primary%22%7D",
            type: "button",
            onClick: onClose,
            className: "text-text-secondary hover:text-text-primary",
            children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:91:16", "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx", "data-component-line": "91", "data-component-file": "AddActivityModal.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22X%22%7D", name: "X", size: 20 }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
              lineNumber: 91,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
            lineNumber: 86,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
        lineNumber: 81,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:95:12", "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx", "data-component-line": "95", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22px-6%20py-4%20space-y-4%22%7D", className: "px-6 py-4 space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:97:14", "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx", "data-component-line": "97", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-gray-50%20p-3%20rounded-lg%22%7D", className: "bg-gray-50 p-3 rounded-lg", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:98:16", "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx", "data-component-line": "98", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22Contact%22%7D", className: "text-sm text-text-secondary", children: "Contact" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
            lineNumber: 98,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:99:16", "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx", "data-component-line": "99", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22font-medium%20text-text-primary%22%7D", className: "font-medium text-text-primary", children: [
            contact?.first_name,
            " ",
            contact?.last_name
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
            lineNumber: 99,
            columnNumber: 17
          }, this),
          contact?.email && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:103:16", "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx", "data-component-line": "103", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%7D", className: "text-sm text-text-secondary", children: contact.email }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
            lineNumber: 103,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
          lineNumber: 97,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:108:14", "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx", "data-component-line": "108", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:109:16", "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx", "data-component-line": "109", "data-component-file": "AddActivityModal.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Activity%20Type%22%7D", htmlFor: "type", className: "block text-sm font-medium text-text-primary mb-1", children: "Activity Type" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
            lineNumber: 109,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:112:16",
              "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx",
              "data-component-line": "112",
              "data-component-file": "AddActivityModal.jsx",
              "data-component-name": "select",
              "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22id%22%3A%22type%22%2C%22name%22%3A%22type%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-md%20focus%3Aoutline-none%20focus%3Aring-2%20focus%3Aring-primary%20focus%3Aborder-transparent%22%7D",
              id: "type",
              name: "type",
              value: activityData.type,
              onChange: handleChange,
              className: "w-full px-3 py-2 border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent",
              required: true,
              children: activityTypes.map(
                (type) => /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:121:18", "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx", "data-component-line": "121", "data-component-file": "AddActivityModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%7D", value: type.value, children: type.label }, type.value, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
                  lineNumber: 121,
                  columnNumber: 19
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
              lineNumber: 112,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
          lineNumber: 108,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:129:14", "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx", "data-component-line": "129", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:130:16", "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx", "data-component-line": "130", "data-component-file": "AddActivityModal.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Subject%20*%22%7D", htmlFor: "subject", className: "block text-sm font-medium text-text-primary mb-1", children: "Subject *" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
            lineNumber: 130,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:133:16",
              "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx",
              "data-component-line": "133",
              "data-component-file": "AddActivityModal.jsx",
              "data-component-name": "input",
              "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22text%22%2C%22id%22%3A%22subject%22%2C%22name%22%3A%22subject%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-md%20focus%3Aoutline-none%20focus%3Aring-2%20focus%3Aring-primary%20focus%3Aborder-transparent%22%7D",
              type: "text",
              id: "subject",
              name: "subject",
              value: activityData.subject,
              onChange: handleChange,
              placeholder: "Enter activity subject...",
              className: "w-full px-3 py-2 border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent",
              required: true
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
              lineNumber: 133,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
          lineNumber: 129,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:146:14", "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx", "data-component-line": "146", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:147:16", "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx", "data-component-line": "147", "data-component-file": "AddActivityModal.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Description%22%7D", htmlFor: "description", className: "block text-sm font-medium text-text-primary mb-1", children: "Description" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
            lineNumber: 147,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "textarea",
            {
              "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:150:16",
              "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx",
              "data-component-line": "150",
              "data-component-file": "AddActivityModal.jsx",
              "data-component-name": "textarea",
              "data-component-content": "%7B%22elementName%22%3A%22textarea%22%2C%22id%22%3A%22description%22%2C%22name%22%3A%22description%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-md%20focus%3Aoutline-none%20focus%3Aring-2%20focus%3Aring-primary%20focus%3Aborder-transparent%22%7D",
              id: "description",
              name: "description",
              value: activityData.description,
              onChange: handleChange,
              rows: 3,
              placeholder: "Enter activity details...",
              className: "w-full px-3 py-2 border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
              lineNumber: 150,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
          lineNumber: 146,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:162:14", "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx", "data-component-line": "162", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:163:16", "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx", "data-component-line": "163", "data-component-file": "AddActivityModal.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Scheduled%20Date%20%26%20Time%22%7D", htmlFor: "scheduled_at", className: "block text-sm font-medium text-text-primary mb-1", children: "Scheduled Date & Time" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
            lineNumber: 163,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:166:16",
              "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx",
              "data-component-line": "166",
              "data-component-file": "AddActivityModal.jsx",
              "data-component-name": "input",
              "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22datetime-local%22%2C%22id%22%3A%22scheduled_at%22%2C%22name%22%3A%22scheduled_at%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-md%20focus%3Aoutline-none%20focus%3Aring-2%20focus%3Aring-primary%20focus%3Aborder-transparent%22%7D",
              type: "datetime-local",
              id: "scheduled_at",
              name: "scheduled_at",
              value: activityData.scheduled_at,
              onChange: handleChange,
              className: "w-full px-3 py-2 border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent",
              required: true
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
              lineNumber: 166,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
          lineNumber: 162,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:178:14", "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx", "data-component-line": "178", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:179:16", "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx", "data-component-line": "179", "data-component-file": "AddActivityModal.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Duration%20(minutes)%22%7D", htmlFor: "duration_minutes", className: "block text-sm font-medium text-text-primary mb-1", children: "Duration (minutes)" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
            lineNumber: 179,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:182:16",
              "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx",
              "data-component-line": "182",
              "data-component-file": "AddActivityModal.jsx",
              "data-component-name": "input",
              "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22number%22%2C%22id%22%3A%22duration_minutes%22%2C%22name%22%3A%22duration_minutes%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-md%20focus%3Aoutline-none%20focus%3Aring-2%20focus%3Aring-primary%20focus%3Aborder-transparent%22%7D",
              type: "number",
              id: "duration_minutes",
              name: "duration_minutes",
              value: activityData.duration_minutes,
              onChange: handleChange,
              min: "5",
              max: "480",
              placeholder: "30",
              className: "w-full px-3 py-2 border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
              lineNumber: 182,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
          lineNumber: 178,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
        lineNumber: 95,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:196:12", "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx", "data-component-line": "196", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22px-6%20py-4%20bg-gray-50%20flex%20justify-end%20space-x-3%22%7D", className: "px-6 py-4 bg-gray-50 flex justify-end space-x-3", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:197:14",
            "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx",
            "data-component-line": "197",
            "data-component-file": "AddActivityModal.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22button%22%2C%22className%22%3A%22px-4%20py-2%20text-sm%20font-medium%20text-text-secondary%20bg-white%20border%20border-border%20rounded-md%20hover%3Abg-gray-50%20focus%3Aoutline-none%20focus%3Aring-2%20focus%3Aring-primary%22%2C%22textContent%22%3A%22Cancel%22%7D",
            type: "button",
            onClick: onClose,
            className: "px-4 py-2 text-sm font-medium text-text-secondary bg-white border border-border rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-primary",
            disabled: isSubmitting,
            children: "Cancel"
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
            lineNumber: 197,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:205:14",
            "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx",
            "data-component-line": "205",
            "data-component-file": "AddActivityModal.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22submit%22%2C%22className%22%3A%22px-4%20py-2%20text-sm%20font-medium%20text-white%20bg-primary%20border%20border-transparent%20rounded-md%20hover%3Abg-primary-600%20focus%3Aoutline-none%20focus%3Aring-2%20focus%3Aring-primary%20disabled%3Aopacity-50%20disabled%3Acursor-not-allowed%22%7D",
            type: "submit",
            className: "px-4 py-2 text-sm font-medium text-white bg-primary border border-transparent rounded-md hover:bg-primary-600 focus:outline-none focus:ring-2 focus:ring-primary disabled:opacity-50 disabled:cursor-not-allowed",
            disabled: isSubmitting,
            children: isSubmitting ? /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:211:16", "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx", "data-component-line": "211", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%22%7D", className: "flex items-center space-x-2", children: [
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:212:20", "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx", "data-component-line": "212", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22animate-spin%20rounded-full%20h-4%20w-4%20border-b-2%20border-white%22%7D", className: "animate-spin rounded-full h-4 w-4 border-b-2 border-white" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
                lineNumber: 212,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\AddActivityModal.jsx:213:20", "data-component-path": "src\\pages\\contact-management\\components\\AddActivityModal.jsx", "data-component-line": "213", "data-component-file": "AddActivityModal.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Logging...%22%7D", children: "Logging..." }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
                lineNumber: 213,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
              lineNumber: 211,
              columnNumber: 17
            }, this) : "Log Activity"
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
            lineNumber: 205,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
        lineNumber: 196,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
      lineNumber: 80,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
      lineNumber: 79,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
    lineNumber: 72,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx",
    lineNumber: 71,
    columnNumber: 5
  }, this);
};
_s(AddActivityModal, "OUFojoCUN9V2NESOas/SNxjFWRg=", false, function() {
  return [useAuth];
});
_c = AddActivityModal;
export default AddActivityModal;
var _c;
$RefreshReg$(_c, "AddActivityModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/contact-management/components/AddActivityModal.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUVVOzJCQXpFVjtBQUFnQkEsTUFBUSxjQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3ZDLE9BQU9DLFdBQVc7QUFDbEIsU0FBU0MsZUFBZTtBQUN4QixPQUFPQyxVQUFVO0FBRWpCLE1BQU1DLG1CQUFtQkEsQ0FBQyxFQUFFQyxTQUFTQyxTQUFTQyxnQkFBZ0IsTUFBTTtBQUFBQyxLQUFBO0FBQ2xFLFFBQU0sRUFBRUMsS0FBSyxJQUFJUCxRQUFRO0FBQ3pCLFFBQU0sQ0FBQ1EsY0FBY0MsZUFBZSxJQUFJWCxTQUFTO0FBQUEsSUFDL0NZLE1BQU07QUFBQSxJQUNOQyxTQUFTO0FBQUEsSUFDVEMsYUFBYTtBQUFBLElBQ2JDLGVBQWMsb0JBQUlDLEtBQUssR0FBRUMsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRTtBQUFBO0FBQUEsSUFDbERDLGtCQUFrQjtBQUFBLEVBQ3BCLENBQUM7QUFDRCxRQUFNLENBQUNDLGNBQWNDLGVBQWUsSUFBSXJCLFNBQVMsS0FBSztBQUV0RCxRQUFNc0IsZ0JBQWdCO0FBQUEsSUFDcEIsRUFBRUMsT0FBTyxRQUFRQyxPQUFPLFFBQVFDLE1BQU0sV0FBVztBQUFBLElBQ2pELEVBQUVGLE9BQU8sUUFBUUMsT0FBTyxRQUFRQyxNQUFNLFFBQVE7QUFBQSxJQUM5QyxFQUFFRixPQUFPLFNBQVNDLE9BQU8sU0FBU0MsTUFBTSxPQUFPO0FBQUEsSUFDL0MsRUFBRUYsT0FBTyxXQUFXQyxPQUFPLFdBQVdDLE1BQU0sV0FBVztBQUFBLElBQ3ZELEVBQUVGLE9BQU8sUUFBUUMsT0FBTyxRQUFRQyxNQUFNLGNBQWM7QUFBQSxJQUNwRCxFQUFFRixPQUFPLFFBQVFDLE9BQU8sUUFBUUMsTUFBTSxVQUFVO0FBQUEsSUFDaEQsRUFBRUYsT0FBTyxpQkFBaUJDLE9BQU8saUJBQWlCQyxNQUFNLFdBQVc7QUFBQSxJQUNuRSxFQUFFRixPQUFPLG1CQUFtQkMsT0FBTyxtQkFBbUJDLE1BQU0sUUFBUTtBQUFBLEVBQUM7QUFHdkUsUUFBTUMsZUFBZUEsQ0FBQ0MsTUFBTTtBQUMxQixVQUFNLEVBQUVDLE1BQU1MLE1BQU0sSUFBSUksRUFBRUU7QUFDMUJsQixvQkFBZ0I7QUFBQSxNQUNkLEdBQUdEO0FBQUFBLE1BQ0gsQ0FBQ2tCLElBQUksR0FBR0w7QUFBQUEsSUFDVixDQUFDO0FBQUEsRUFDSDtBQUVBLFFBQU1PLGVBQWUsT0FBT0gsTUFBTTtBQUNoQ0EsTUFBRUksZUFBZTtBQUVqQixRQUFJLENBQUNyQixhQUFhRyxRQUFRbUIsS0FBSyxHQUFHO0FBQ2hDL0IsWUFBTWdDLE1BQU0seUNBQXlDO0FBQ3JEO0FBQUEsSUFDRjtBQUVBWixvQkFBZ0IsSUFBSTtBQUVwQixRQUFJO0FBQ0YsWUFBTWEsa0JBQWtCO0FBQUEsUUFDdEJ0QixNQUFNRixhQUFhRTtBQUFBQSxRQUNuQkMsU0FBU0gsYUFBYUc7QUFBQUEsUUFDdEJDLGFBQWFKLGFBQWFJO0FBQUFBLFFBQzFCSyxrQkFBa0JULGFBQWFTO0FBQUFBLFFBQy9CSixjQUFjLElBQUlDLEtBQUtOLGFBQWFLLFlBQVksRUFBRUUsWUFBWTtBQUFBLFFBQzlEa0IsWUFBWTlCLFNBQVMrQjtBQUFBQSxRQUNyQkMsU0FBUzVCLE1BQU0yQjtBQUFBQSxNQUNqQjtBQUVBLFlBQU03QixnQkFBZ0IyQixlQUFlO0FBQ3JDakMsWUFBTXFDLFFBQVEsR0FBRzVCLGFBQWFFLEtBQUsyQixPQUFPLENBQUMsRUFBRUMsWUFBWSxJQUFJOUIsYUFBYUUsS0FBS00sTUFBTSxDQUFDLENBQUMsZ0NBQWdDO0FBQ3ZIWixjQUFRO0FBQUEsSUFDVixTQUFTMkIsT0FBTztBQUNkUSxjQUFRUixNQUFNLDBCQUEwQkEsS0FBSztBQUM3Q2hDLFlBQU1nQyxNQUFNLDJDQUEyQztBQUFBLElBQ3pELFVBQUM7QUFDQ1osc0JBQWdCLEtBQUs7QUFBQSxJQUN2QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNcUIsZUFBZXBCLGNBQWNxQixLQUFLLENBQUEvQixTQUFRQSxLQUFLVyxVQUFVYixhQUFhRSxJQUFJO0FBRWhGLFNBQ0UsdUJBQUMsa2JBQUksV0FBVSx3Q0FDYixpQ0FBQyx1ZkFBSSxXQUFVLDZGQUNiO0FBQUEsMkJBQUMsNGFBQUksV0FBVSxvQ0FBbUMsZUFBWSxRQUM1RCxpQ0FBQyxzYkFBSSxXQUFVLDZDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUQsS0FEM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFFQSx1QkFBQywrZUFBSyxXQUFVLHNEQUFxRCxlQUFZLFFBQU8saUJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0Y7QUFBQSxJQUUvRix1QkFBQyxra0JBQUksV0FBVSw4SkFDYixpQ0FBQyxpWEFBSyxVQUFVa0IsY0FDZDtBQUFBLDZCQUFDLHVkQUFJLFdBQVUsc0VBQ2I7QUFBQSwrQkFBQyx3YUFBSSxXQUFVLCtCQUNiO0FBQUEsaUNBQUMsc1pBQUssTUFBTVksY0FBY2pCLE1BQU0sTUFBTSxJQUFJLFdBQVUsa0JBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtFO0FBQUEsVUFDbEUsdUJBQUMsNGRBQUcsV0FBVSwyQ0FBMEMsNEJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9FO0FBQUEsYUFGdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBU25CO0FBQUFBLFlBQ1QsV0FBVTtBQUFBLFlBRVYsaUNBQUMsc1lBQUssTUFBSyxLQUFJLE1BQU0sTUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0I7QUFBQTtBQUFBLFVBTDFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsV0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBWUE7QUFBQSxNQUVBLHVCQUFDLGdhQUFJLFdBQVUsdUJBRWI7QUFBQSwrQkFBQyxzYUFBSSxXQUFVLDZCQUNiO0FBQUEsaUNBQUMsMGNBQUksV0FBVSwrQkFBOEIsdUJBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9EO0FBQUEsVUFDcEQsdUJBQUMsd2FBQUksV0FBVSxpQ0FDWkQ7QUFBQUEscUJBQVN1QztBQUFBQSxZQUFXO0FBQUEsWUFBRXZDLFNBQVN3QztBQUFBQSxlQURsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQ3hDLFNBQVN5QyxTQUNSLHVCQUFDLHdhQUFJLFdBQVUsK0JBQStCekMsa0JBQVF5QyxTQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0RDtBQUFBLGFBTmhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBR0EsdUJBQUMsZ1hBQ0M7QUFBQSxpQ0FBQyxxZkFBTSxTQUFRLFFBQU8sV0FBVSxvREFBbUQsNkJBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FDQyxJQUFHO0FBQUEsY0FDSCxNQUFLO0FBQUEsY0FDTCxPQUFPcEMsYUFBYUU7QUFBQUEsY0FDcEIsVUFBVWM7QUFBQUEsY0FDVixXQUFVO0FBQUEsY0FDVixVQUFRO0FBQUEsY0FFUEosd0JBQWN5QjtBQUFBQSxnQkFBSSxDQUFBbkMsU0FDakIsdUJBQUMseVhBQXdCLE9BQU9BLEtBQUtXLE9BQ2xDWCxlQUFLWSxTQURLWixLQUFLVyxPQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsY0FDRDtBQUFBO0FBQUEsWUFaSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFhQTtBQUFBLGFBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQkE7QUFBQSxRQUdBLHVCQUFDLGdYQUNDO0FBQUEsaUNBQUMsaWZBQU0sU0FBUSxXQUFVLFdBQVUsb0RBQW1ELHlCQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsSUFBRztBQUFBLGNBQ0gsTUFBSztBQUFBLGNBQ0wsT0FBT2IsYUFBYUc7QUFBQUEsY0FDcEIsVUFBVWE7QUFBQUEsY0FDVixhQUFZO0FBQUEsY0FDWixXQUFVO0FBQUEsY0FDVixVQUFRO0FBQUE7QUFBQSxZQVJWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFVO0FBQUEsYUFaWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBY0E7QUFBQSxRQUdBLHVCQUFDLGdYQUNDO0FBQUEsaUNBQUMsaWZBQU0sU0FBUSxlQUFjLFdBQVUsb0RBQW1ELDJCQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsSUFBRztBQUFBLGNBQ0gsTUFBSztBQUFBLGNBQ0wsT0FBT2hCLGFBQWFJO0FBQUFBLGNBQ3BCLFVBQVVZO0FBQUFBLGNBQ1YsTUFBTTtBQUFBLGNBQ04sYUFBWTtBQUFBLGNBQ1osV0FBVTtBQUFBO0FBQUEsWUFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPMEk7QUFBQSxhQVg1STtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYUE7QUFBQSxRQUdBLHVCQUFDLGdYQUNDO0FBQUEsaUNBQUMsbWdCQUFNLFNBQVEsZ0JBQWUsV0FBVSxvREFBbUQscUNBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxJQUFHO0FBQUEsY0FDSCxNQUFLO0FBQUEsY0FDTCxPQUFPaEIsYUFBYUs7QUFBQUEsY0FDcEIsVUFBVVc7QUFBQUEsY0FDVixXQUFVO0FBQUEsY0FDVixVQUFRO0FBQUE7QUFBQSxZQVBWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9VO0FBQUEsYUFYWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYUE7QUFBQSxRQUdBLHVCQUFDLGdYQUNDO0FBQUEsaUNBQUMsMGZBQU0sU0FBUSxvQkFBbUIsV0FBVSxvREFBbUQsa0NBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxJQUFHO0FBQUEsY0FDSCxNQUFLO0FBQUEsY0FDTCxPQUFPaEIsYUFBYVM7QUFBQUEsY0FDcEIsVUFBVU87QUFBQUEsY0FDVixLQUFJO0FBQUEsY0FDSixLQUFJO0FBQUEsY0FDSixhQUFZO0FBQUEsY0FDWixXQUFVO0FBQUE7QUFBQSxZQVRaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVMwSTtBQUFBLGFBYjVJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQTtBQUFBLFdBbEdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFtR0E7QUFBQSxNQUVBLHVCQUFDLG9jQUFJLFdBQVUsbURBQ2I7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBU3BCO0FBQUFBLFlBQ1QsV0FBVTtBQUFBLFlBQ1YsVUFBVWM7QUFBQUEsWUFBYTtBQUFBO0FBQUEsVUFKekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBT0E7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxXQUFVO0FBQUEsWUFDVixVQUFVQTtBQUFBQSxZQUVUQSx5QkFDQyx1QkFBQywwYUFBSSxXQUFVLCtCQUNiO0FBQUEscUNBQUMsOGNBQUksV0FBVSwrREFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyRTtBQUFBLGNBQzNFLHVCQUFDLDBaQUFLLDBCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdCO0FBQUEsaUJBRmxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0EsSUFFQTtBQUFBO0FBQUEsVUFYSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFhQTtBQUFBLFdBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF1QkE7QUFBQSxTQTNJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNElBLEtBN0lGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4SUE7QUFBQSxPQXJKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBc0pBLEtBdkpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3SkE7QUFFSjtBQUFFWixHQTNOSUosa0JBQWdCO0FBQUEsVUFDSEYsT0FBTztBQUFBO0FBQUE4QyxLQURwQjVDO0FBNk5OLGVBQWVBO0FBQWlCLElBQUE0QztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ0b2FzdCIsInVzZUF1dGgiLCJJY29uIiwiQWRkQWN0aXZpdHlNb2RhbCIsImNvbnRhY3QiLCJvbkNsb3NlIiwib25BY3Rpdml0eUFkZGVkIiwiX3MiLCJ1c2VyIiwiYWN0aXZpdHlEYXRhIiwic2V0QWN0aXZpdHlEYXRhIiwidHlwZSIsInN1YmplY3QiLCJkZXNjcmlwdGlvbiIsInNjaGVkdWxlZF9hdCIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsInNsaWNlIiwiZHVyYXRpb25fbWludXRlcyIsImlzU3VibWl0dGluZyIsInNldElzU3VibWl0dGluZyIsImFjdGl2aXR5VHlwZXMiLCJ2YWx1ZSIsImxhYmVsIiwiaWNvbiIsImhhbmRsZUNoYW5nZSIsImUiLCJuYW1lIiwidGFyZ2V0IiwiaGFuZGxlU3VibWl0IiwicHJldmVudERlZmF1bHQiLCJ0cmltIiwiZXJyb3IiLCJhY3Rpdml0eVBheWxvYWQiLCJjb250YWN0X2lkIiwiaWQiLCJ1c2VyX2lkIiwic3VjY2VzcyIsImNoYXJBdCIsInRvVXBwZXJDYXNlIiwiY29uc29sZSIsInNlbGVjdGVkVHlwZSIsImZpbmQiLCJmaXJzdF9uYW1lIiwibGFzdF9uYW1lIiwiZW1haWwiLCJtYXAiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFkZEFjdGl2aXR5TW9kYWwuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHRvYXN0IGZyb20gJ3JlYWN0LWhvdC10b2FzdCc7XHJcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tICcuLi8uLi8uLi9jb250ZXh0cy9BdXRoQ29udGV4dCc7XHJcbmltcG9ydCBJY29uIGZyb20gJ2NvbXBvbmVudHMvQXBwSWNvbic7XHJcblxyXG5jb25zdCBBZGRBY3Rpdml0eU1vZGFsID0gKHsgY29udGFjdCwgb25DbG9zZSwgb25BY3Rpdml0eUFkZGVkIH0pID0+IHtcclxuICBjb25zdCB7IHVzZXIgfSA9IHVzZUF1dGgoKTtcclxuICBjb25zdCBbYWN0aXZpdHlEYXRhLCBzZXRBY3Rpdml0eURhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgdHlwZTogJ25vdGUnLFxyXG4gICAgc3ViamVjdDogJycsXHJcbiAgICBkZXNjcmlwdGlvbjogJycsXHJcbiAgICBzY2hlZHVsZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxNiksIC8vIEZvcm1hdDogWVlZWS1NTS1ERFRoaDptbVxyXG4gICAgZHVyYXRpb25fbWludXRlczogMzBcclxuICB9KTtcclxuICBjb25zdCBbaXNTdWJtaXR0aW5nLCBzZXRJc1N1Ym1pdHRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBhY3Rpdml0eVR5cGVzID0gW1xyXG4gICAgeyB2YWx1ZTogJ25vdGUnLCBsYWJlbDogJ05vdGUnLCBpY29uOiAnRmlsZVRleHQnIH0sXHJcbiAgICB7IHZhbHVlOiAnY2FsbCcsIGxhYmVsOiAnQ2FsbCcsIGljb246ICdQaG9uZScgfSxcclxuICAgIHsgdmFsdWU6ICdlbWFpbCcsIGxhYmVsOiAnRW1haWwnLCBpY29uOiAnTWFpbCcgfSxcclxuICAgIHsgdmFsdWU6ICdtZWV0aW5nJywgbGFiZWw6ICdNZWV0aW5nJywgaWNvbjogJ0NhbGVuZGFyJyB9LFxyXG4gICAgeyB2YWx1ZTogJ3Rhc2snLCBsYWJlbDogJ1Rhc2snLCBpY29uOiAnQ2hlY2tTcXVhcmUnIH0sXHJcbiAgICB7IHZhbHVlOiAnZGVtbycsIGxhYmVsOiAnRGVtbycsIGljb246ICdNb25pdG9yJyB9LFxyXG4gICAgeyB2YWx1ZTogJ3Byb3Bvc2FsX3NlbnQnLCBsYWJlbDogJ1Byb3Bvc2FsIFNlbnQnLCBpY29uOiAnRmlsZVRleHQnIH0sXHJcbiAgICB7IHZhbHVlOiAnZG9jdW1lbnRfc2hhcmVkJywgbGFiZWw6ICdEb2N1bWVudCBTaGFyZWQnLCBpY29uOiAnU2hhcmUnIH1cclxuICBdO1xyXG5cclxuICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRBY3Rpdml0eURhdGEoe1xyXG4gICAgICAuLi5hY3Rpdml0eURhdGEsXHJcbiAgICAgIFtuYW1lXTogdmFsdWVcclxuICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBcclxuICAgIGlmICghYWN0aXZpdHlEYXRhLnN1YmplY3QudHJpbSgpKSB7XHJcbiAgICAgIHRvYXN0LmVycm9yKCdQbGVhc2UgZW50ZXIgYSBzdWJqZWN0IGZvciB0aGUgYWN0aXZpdHknKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHNldElzU3VibWl0dGluZyh0cnVlKTtcclxuICAgIFxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgYWN0aXZpdHlQYXlsb2FkID0ge1xyXG4gICAgICAgIHR5cGU6IGFjdGl2aXR5RGF0YS50eXBlLFxyXG4gICAgICAgIHN1YmplY3Q6IGFjdGl2aXR5RGF0YS5zdWJqZWN0LFxyXG4gICAgICAgIGRlc2NyaXB0aW9uOiBhY3Rpdml0eURhdGEuZGVzY3JpcHRpb24sXHJcbiAgICAgICAgZHVyYXRpb25fbWludXRlczogYWN0aXZpdHlEYXRhLmR1cmF0aW9uX21pbnV0ZXMsXHJcbiAgICAgICAgc2NoZWR1bGVkX2F0OiBuZXcgRGF0ZShhY3Rpdml0eURhdGEuc2NoZWR1bGVkX2F0KS50b0lTT1N0cmluZygpLFxyXG4gICAgICAgIGNvbnRhY3RfaWQ6IGNvbnRhY3Q/LmlkLFxyXG4gICAgICAgIHVzZXJfaWQ6IHVzZXI/LmlkXHJcbiAgICAgIH07XHJcblxyXG4gICAgICBhd2FpdCBvbkFjdGl2aXR5QWRkZWQoYWN0aXZpdHlQYXlsb2FkKTtcclxuICAgICAgdG9hc3Quc3VjY2VzcyhgJHthY3Rpdml0eURhdGEudHlwZS5jaGFyQXQoMCkudG9VcHBlckNhc2UoKSArIGFjdGl2aXR5RGF0YS50eXBlLnNsaWNlKDEpfSBhY3Rpdml0eSBsb2dnZWQgc3VjY2Vzc2Z1bGx5IWApO1xyXG4gICAgICBvbkNsb3NlKCk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBhZGRpbmcgYWN0aXZpdHk6JywgZXJyb3IpO1xyXG4gICAgICB0b2FzdC5lcnJvcignRmFpbGVkIHRvIGxvZyBhY3Rpdml0eS4gUGxlYXNlIHRyeSBhZ2Fpbi4nKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzU3VibWl0dGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgc2VsZWN0ZWRUeXBlID0gYWN0aXZpdHlUeXBlcy5maW5kKHR5cGUgPT4gdHlwZS52YWx1ZSA9PT0gYWN0aXZpdHlEYXRhLnR5cGUpO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotMTEwMCBvdmVyZmxvdy15LWF1dG9cIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBtaW4taC1zY3JlZW4gcHgtNCBwdC00IHBiLTIwIHRleHQtY2VudGVyIHNtOmJsb2NrIHNtOnAtMFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB0cmFuc2l0aW9uLW9wYWNpdHlcIiBhcmlhLWhpZGRlbj1cInRydWVcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1ibGFjayBiZy1vcGFjaXR5LTUwXCI+PC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgXHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIHNtOmlubGluZS1ibG9jayBzbTphbGlnbi1taWRkbGUgc206aC1zY3JlZW5cIiBhcmlhLWhpZGRlbj1cInRydWVcIj4mIzgyMDM7PC9zcGFuPlxyXG4gICAgICAgIFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWJsb2NrIGFsaWduLWJvdHRvbSBiZy1zdXJmYWNlIHJvdW5kZWQtbGcgdGV4dC1sZWZ0IG92ZXJmbG93LWhpZGRlbiBzaGFkb3cteGwgdHJhbnNmb3JtIHRyYW5zaXRpb24tYWxsIHNtOm15LTggc206YWxpZ24tbWlkZGxlIHNtOm1heC13LWxnIHNtOnctZnVsbFwiPlxyXG4gICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS00IGJvcmRlci1iIGJvcmRlci1ib3JkZXIgZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTJcIj5cclxuICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9e3NlbGVjdGVkVHlwZT8uaWNvbn0gc2l6ZT17MjB9IGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeVwiIC8+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtdGV4dC1wcmltYXJ5XCI+TG9nIEFjdGl2aXR5PC9oMz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5IGhvdmVyOnRleHQtdGV4dC1wcmltYXJ5XCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiWFwiIHNpemU9ezIwfSAvPlxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS00IHNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgICAgIHsvKiBDb250YWN0IEluZm8gKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHAtMyByb3VuZGVkLWxnXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC10ZXh0LXNlY29uZGFyeVwiPkNvbnRhY3Q8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnlcIj5cclxuICAgICAgICAgICAgICAgICAge2NvbnRhY3Q/LmZpcnN0X25hbWV9IHtjb250YWN0Py5sYXN0X25hbWV9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIHtjb250YWN0Py5lbWFpbCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+e2NvbnRhY3QuZW1haWx9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogQWN0aXZpdHkgVHlwZSAqL31cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJ0eXBlXCIgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIEFjdGl2aXR5IFR5cGVcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIGlkPVwidHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJ0eXBlXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2FjdGl2aXR5RGF0YS50eXBlfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbWQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXByaW1hcnkgZm9jdXM6Ym9yZGVyLXRyYW5zcGFyZW50XCJcclxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge2FjdGl2aXR5VHlwZXMubWFwKHR5cGUgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXt0eXBlLnZhbHVlfSB2YWx1ZT17dHlwZS52YWx1ZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7dHlwZS5sYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIFN1YmplY3QgKi99XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwic3ViamVjdFwiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICBTdWJqZWN0ICpcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBpZD1cInN1YmplY3RcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwic3ViamVjdFwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXthY3Rpdml0eURhdGEuc3ViamVjdH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBhY3Rpdml0eSBzdWJqZWN0Li4uXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLW1kIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1wcmltYXJ5IGZvY3VzOmJvcmRlci10cmFuc3BhcmVudFwiXHJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogQ29udGVudC9EZXNjcmlwdGlvbiAqL31cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJkZXNjcmlwdGlvblwiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICBEZXNjcmlwdGlvblxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxyXG4gICAgICAgICAgICAgICAgICBpZD1cImRlc2NyaXB0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cImRlc2NyaXB0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2FjdGl2aXR5RGF0YS5kZXNjcmlwdGlvbn1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgcm93cz17M31cclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBhY3Rpdml0eSBkZXRhaWxzLi4uXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLW1kIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1wcmltYXJ5IGZvY3VzOmJvcmRlci10cmFuc3BhcmVudFwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogRGF0ZSBhbmQgVGltZSAqL31cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJzY2hlZHVsZWRfYXRcIiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgU2NoZWR1bGVkIERhdGUgJiBUaW1lXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRldGltZS1sb2NhbFwiXHJcbiAgICAgICAgICAgICAgICAgIGlkPVwic2NoZWR1bGVkX2F0XCJcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cInNjaGVkdWxlZF9hdFwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXthY3Rpdml0eURhdGEuc2NoZWR1bGVkX2F0fVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbWQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXByaW1hcnkgZm9jdXM6Ym9yZGVyLXRyYW5zcGFyZW50XCJcclxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBEdXJhdGlvbiAqL31cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJkdXJhdGlvbl9taW51dGVzXCIgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIER1cmF0aW9uIChtaW51dGVzKVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgaWQ9XCJkdXJhdGlvbl9taW51dGVzXCJcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cImR1cmF0aW9uX21pbnV0ZXNcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17YWN0aXZpdHlEYXRhLmR1cmF0aW9uX21pbnV0ZXN9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgIG1pbj1cIjVcIlxyXG4gICAgICAgICAgICAgICAgICBtYXg9XCI0ODBcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjMwXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLW1kIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1wcmltYXJ5IGZvY3VzOmJvcmRlci10cmFuc3BhcmVudFwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS00IGJnLWdyYXktNTAgZmxleCBqdXN0aWZ5LWVuZCBzcGFjZS14LTNcIj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtc2Vjb25kYXJ5IGJnLXdoaXRlIGJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbWQgaG92ZXI6YmctZ3JheS01MCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctcHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNTdWJtaXR0aW5nfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC13aGl0ZSBiZy1wcmltYXJ5IGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgcm91bmRlZC1tZCBob3ZlcjpiZy1wcmltYXJ5LTYwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctcHJpbWFyeSBkaXNhYmxlZDpvcGFjaXR5LTUwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZFwiXHJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNTdWJtaXR0aW5nfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtpc1N1Ym1pdHRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW4gcm91bmRlZC1mdWxsIGgtNCB3LTQgYm9yZGVyLWItMiBib3JkZXItd2hpdGVcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5Mb2dnaW5nLi4uPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICdMb2cgQWN0aXZpdHknXHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQWRkQWN0aXZpdHlNb2RhbDtcclxuIl0sImZpbGUiOiJEOi9jdXJyZW50IHByb2plY3RzL2NsYXVkZS1jb2RlL3NyYy9wYWdlcy9jb250YWN0LW1hbmFnZW1lbnQvY29tcG9uZW50cy9BZGRBY3Rpdml0eU1vZGFsLmpzeCJ9