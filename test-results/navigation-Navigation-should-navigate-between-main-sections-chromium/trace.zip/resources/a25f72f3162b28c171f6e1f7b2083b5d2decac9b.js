import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/contact-management/index.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/contact-management/index.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import Icon from "/src/components/AppIcon.jsx";
import Header from "/src/components/ui/Header.jsx";
import Breadcrumb from "/src/components/ui/Breadcrumb.jsx";
import ContactList from "/src/pages/contact-management/components/ContactList.jsx";
import ContactDetail from "/src/pages/contact-management/components/ContactDetail.jsx";
import ContactForm from "/src/pages/contact-management/components/ContactForm.jsx";
import ImportContactsModal from "/src/pages/contact-management/components/ImportContactsModal.jsx";
import ExportContactsModal from "/src/pages/contact-management/components/ExportContactsModal.jsx";
import MergeDuplicatesModal from "/src/pages/contact-management/components/MergeDuplicatesModal.jsx";
import FilterPanel from "/src/pages/contact-management/components/FilterPanel.jsx";
import contactsService from "/src/services/contactsService.js";
import { useAuth } from "/src/contexts/AuthContext.jsx";
const ContactManagement = () => {
  _s();
  const { user } = useAuth();
  const [contacts, setContacts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedContact, setSelectedContact] = useState(null);
  const [selectedContacts, setSelectedContacts] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [isFilterPanelOpen, setIsFilterPanelOpen] = useState(false);
  const [isAddingContact, setIsAddingContact] = useState(false);
  const [isEditingContact, setIsEditingContact] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isMergeModalOpen, setIsMergeModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("all");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [filters, setFilters] = useState({
    company: [],
    dealStage: [],
    lastContactDate: null,
    tags: []
  });
  const loadContacts = async () => {
    try {
      setLoading(true);
      setError("");
      let contactsData = [];
      if (searchQuery) {
        contactsData = await contactsService?.searchContacts(searchQuery);
      } else {
        const filterParams = {};
        if (filters?.company?.length > 0) {
          filterParams.companies = filters?.company;
        }
        if (filters?.dealStage?.length > 0) {
          filterParams.dealStages = filters?.dealStage;
        }
        if (filters?.tags?.length > 0) {
          filterParams.tags = filters?.tags;
        }
        if (filters?.lastContactDate) {
          filterParams.dateRange = filters?.lastContactDate;
        }
        if (Object.keys(filterParams)?.length > 0) {
          contactsData = await contactsService?.filterContacts(filterParams);
        } else {
          contactsData = await contactsService?.getUserContacts();
        }
      }
      setContacts(contactsData || []);
      if (contactsData?.length > 0 && window.innerWidth >= 1024 && !selectedContact) {
        setSelectedContact(contactsData?.[0]);
      }
    } catch (err) {
      console.error("Error loading contacts:", err);
      if (err?.message?.includes("Failed to fetch") || err?.message?.includes("NetworkError")) {
        setError("Cannot connect to database. Your Supabase project may be paused or inactive. Please check your Supabase dashboard and resume your project if needed.");
      } else {
        setError("Failed to load contacts. Please try again.");
      }
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    if (user) {
      loadContacts();
    }
  }, [user, searchQuery, filters, activeTab]);
  useEffect(() => {
    if (error || success) {
      const timer = setTimeout(() => {
        setError("");
        setSuccess("");
      }, 5e3);
      return () => clearTimeout(timer);
    }
  }, [error, success]);
  const filteredContacts = contacts?.filter((contact) => {
    if (activeTab === "active") {
      return contact?.status === "active";
    } else if (activeTab === "inactive") {
      return contact?.status === "inactive";
    }
    return true;
  });
  const handleContactSelect = (contact) => {
    console.log("handleContactSelect called with:", contact);
    try {
      setSelectedContact(contact);
      setIsAddingContact(false);
      setIsEditingContact(false);
    } catch (error2) {
      console.error("Error in handleContactSelect:", error2);
      setError("Something went wrong while selecting the contact. Please try again.");
    }
  };
  const handleContactMultiSelect = (contactId) => {
    console.log("handleContactMultiSelect called with:", contactId);
    try {
      setSelectedContacts((prev) => {
        const newSelected = prev?.includes(contactId) ? prev?.filter((id) => id !== contactId) : [...prev || [], contactId];
        console.log("Updated selectedContacts:", newSelected);
        return newSelected;
      });
    } catch (error2) {
      console.error("Error in handleContactMultiSelect:", error2);
      setError("Something went wrong while selecting contacts. Please try again.");
    }
  };
  const handleSelectAll = () => {
    if (selectedContacts?.length === filteredContacts?.length) {
      setSelectedContacts([]);
    } else {
      setSelectedContacts(filteredContacts?.map((contact) => contact?.id));
    }
  };
  const handleAddContact = () => {
    setSelectedContact(null);
    setIsAddingContact(true);
    setIsEditingContact(false);
  };
  const handleEditContact = () => {
    setIsAddingContact(false);
    setIsEditingContact(true);
  };
  const handleSaveContact = async (contactData) => {
    try {
      setError("");
      let result;
      if (isAddingContact) {
        result = contactData;
        setSuccess("Contact created successfully!");
      } else if (isEditingContact && selectedContact) {
        result = contactData;
        setSuccess("Contact updated successfully!");
      }
      setSelectedContact(result);
      setIsAddingContact(false);
      setIsEditingContact(false);
      loadContacts();
    } catch (err) {
      console.error("Error saving contact:", err);
      setError("Failed to save contact. Please try again.");
    }
  };
  const handleCancelForm = () => {
    setIsAddingContact(false);
    setIsEditingContact(false);
    if (selectedContact === null && contacts?.length > 0) {
      setSelectedContact(contacts?.[0]);
    }
  };
  const handleDeleteContact = async (contactId) => {
    try {
      setError("");
      await contactsService?.deleteContact(contactId);
      setSuccess("Contact deleted successfully!");
      const updatedContacts = contacts?.filter((contact) => contact?.id !== contactId);
      setContacts(updatedContacts);
      if (selectedContact && selectedContact?.id === contactId) {
        setSelectedContact(updatedContacts?.length > 0 ? updatedContacts?.[0] : null);
      }
      setSelectedContacts((prev) => prev?.filter((id) => id !== contactId));
    } catch (err) {
      console.error("Error deleting contact:", err);
      setError("Failed to delete contact. Please try again.");
    }
  };
  const handleBulkDelete = async () => {
    try {
      setError("");
      await contactsService?.deleteContacts(selectedContacts);
      setSuccess(`${selectedContacts?.length} contact(s) deleted successfully!`);
      const updatedContacts = contacts?.filter((contact) => !selectedContacts?.includes(contact?.id));
      setContacts(updatedContacts);
      if (selectedContact && selectedContacts?.includes(selectedContact?.id)) {
        setSelectedContact(updatedContacts?.length > 0 ? updatedContacts?.[0] : null);
      }
      setSelectedContacts([]);
    } catch (err) {
      console.error("Error deleting contacts:", err);
      setError("Failed to delete contacts. Please try again.");
    }
  };
  const handleContactUpdate = (updatedContact) => {
    const updatedContacts = contacts.map(
      (contact) => contact.id === updatedContact.id ? updatedContact : contact
    );
    setContacts(updatedContacts);
    if (selectedContact && selectedContact.id === updatedContact.id) {
      setSelectedContact(updatedContact);
    }
  };
  const handleImportContacts = async (importedContacts) => {
    try {
      setError("");
      await contactsService?.importContacts(importedContacts);
      setSuccess(`${importedContacts?.length} contact(s) imported successfully!`);
      setIsImportModalOpen(false);
      loadContacts();
    } catch (err) {
      console.error("Error importing contacts:", err);
      setError("Failed to import contacts. Please try again.");
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\index.jsx:272:4", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "272", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22min-h-screen%20bg-background%22%7D", className: "min-h-screen bg-background", children: [
    /* @__PURE__ */ jsxDEV(Header, { "data-component-id": "src\\pages\\contact-management\\index.jsx:273:6", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "273", "data-component-file": "index.jsx", "data-component-name": "Header", "data-component-content": "%7B%22elementName%22%3A%22Header%22%7D" }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
      lineNumber: 273,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("main", { "data-component-id": "src\\pages\\contact-management\\index.jsx:274:6", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "274", "data-component-file": "index.jsx", "data-component-name": "main", "data-component-content": "%7B%22elementName%22%3A%22main%22%2C%22className%22%3A%22pt-16%22%7D", className: "pt-16", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\index.jsx:275:8", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "275", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22px-6%20py-8%22%7D", className: "px-6 py-8", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\index.jsx:276:10", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "276", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22max-w-7xl%20mx-auto%22%7D", className: "max-w-7xl mx-auto", children: [
      /* @__PURE__ */ jsxDEV(Breadcrumb, { "data-component-id": "src\\pages\\contact-management\\index.jsx:277:12", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "277", "data-component-file": "index.jsx", "data-component-name": "Breadcrumb", "data-component-content": "%7B%22elementName%22%3A%22Breadcrumb%22%7D" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
        lineNumber: 277,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\index.jsx:279:12", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "279", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20flex-col%20md%3Aflex-row%20justify-between%20items-start%20md%3Aitems-center%20mb-6%22%7D", className: "flex flex-col md:flex-row justify-between items-start md:items-center mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\index.jsx:280:14", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "280", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("h1", { "data-component-id": "src\\pages\\contact-management\\index.jsx:281:16", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "281", "data-component-file": "index.jsx", "data-component-name": "h1", "data-component-content": "%7B%22elementName%22%3A%22h1%22%2C%22className%22%3A%22text-2xl%20md%3Atext-3xl%20font-bold%20text-text-primary%22%2C%22textContent%22%3A%22Contact%20Management%22%7D", className: "text-2xl md:text-3xl font-bold text-text-primary", children: "Contact Management" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
            lineNumber: 281,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\contact-management\\index.jsx:282:16", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "282", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20mt-1%22%2C%22textContent%22%3A%22Manage%20your%20customer%20relationships%20and%20communication%20history%22%7D", className: "text-text-secondary mt-1", children: "Manage your customer relationships and communication history" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
            lineNumber: 282,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
          lineNumber: 280,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\index.jsx:285:14", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "285", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20flex-wrap%20gap-3%20mt-4%20md%3Amt-0%22%7D", className: "flex flex-wrap gap-3 mt-4 md:mt-0", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\contact-management\\index.jsx:286:16",
              "data-component-path": "src\\pages\\contact-management\\index.jsx",
              "data-component-line": "286",
              "data-component-file": "index.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22btn-primary%20inline-flex%20items-center%20space-x-2%22%7D",
              onClick: handleAddContact,
              className: "btn-primary inline-flex items-center space-x-2",
              children: [
                /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\index.jsx:290:18", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "290", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22UserPlus%22%7D", name: "UserPlus", size: 18 }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
                  lineNumber: 290,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\index.jsx:291:18", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "291", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Add%20Contact%22%7D", children: "Add Contact" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
                  lineNumber: 291,
                  columnNumber: 19
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
              lineNumber: 286,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\contact-management\\index.jsx:294:16",
              "data-component-path": "src\\pages\\contact-management\\index.jsx",
              "data-component-line": "294",
              "data-component-file": "index.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22inline-flex%20items-center%20space-x-2%20px-4%20py-2%20border%20border-border%20rounded-lg%20text-text-secondary%20hover%3Atext-text-primary%20hover%3Abg-surface-hover%20transition-all%20duration-150%20ease-out%22%7D",
              onClick: () => setIsImportModalOpen(true),
              className: "inline-flex items-center space-x-2 px-4 py-2 border border-border rounded-lg text-text-secondary hover:text-text-primary hover:bg-surface-hover transition-all duration-150 ease-out",
              children: [
                /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\index.jsx:298:18", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "298", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Upload%22%7D", name: "Upload", size: 18 }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
                  lineNumber: 298,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\index.jsx:299:18", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "299", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Import%22%7D", children: "Import" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
                  lineNumber: 299,
                  columnNumber: 19
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
              lineNumber: 294,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\contact-management\\index.jsx:302:16",
              "data-component-path": "src\\pages\\contact-management\\index.jsx",
              "data-component-line": "302",
              "data-component-file": "index.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%7D",
              onClick: () => setIsFilterPanelOpen(!isFilterPanelOpen),
              className: `inline-flex items-center space-x-2 px-4 py-2 border rounded-lg transition-all duration-150 ease-out ${Object.values(filters)?.some((f) => Array.isArray(f) ? f?.length > 0 : f !== null) || isFilterPanelOpen ? "border-primary-500 bg-primary-50 text-primary" : "border-border text-text-secondary hover:text-text-primary hover:bg-surface-hover"}`,
              children: [
                /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\index.jsx:309:18", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "309", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Filter%22%7D", name: "Filter", size: 18 }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
                  lineNumber: 309,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\index.jsx:310:18", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "310", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Filter%22%7D", children: "Filter" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
                  lineNumber: 310,
                  columnNumber: 19
                }, this),
                Object.values(filters)?.some((f) => Array.isArray(f) ? f?.length > 0 : f !== null) && /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\index.jsx:312:18", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "312", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22w-5%20h-5%20bg-primary%20text-white%20text-xs%20rounded-full%20flex%20items-center%20justify-center%22%7D", className: "w-5 h-5 bg-primary text-white text-xs rounded-full flex items-center justify-center", children: Object.values(filters)?.reduce((count, f) => count + (Array.isArray(f) ? f?.length : f !== null ? 1 : 0), 0) }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
                  lineNumber: 312,
                  columnNumber: 19
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
              lineNumber: 302,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
          lineNumber: 285,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
        lineNumber: 279,
        columnNumber: 13
      }, this),
      success && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\index.jsx:322:12", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "322", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-success-50%20border%20border-success-200%20text-success%20p-4%20rounded-lg%20flex%20items-center%20space-x-2%20mb-6%22%7D", className: "bg-success-50 border border-success-200 text-success p-4 rounded-lg flex items-center space-x-2 mb-6", children: [
        /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\index.jsx:323:16", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "323", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22CheckCircle%22%7D", name: "CheckCircle", size: 20 }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
          lineNumber: 323,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\index.jsx:324:16", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "324", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: success }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
          lineNumber: 324,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\contact-management\\index.jsx:325:16",
            "data-component-path": "src\\pages\\contact-management\\index.jsx",
            "data-component-line": "325",
            "data-component-file": "index.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22ml-auto%20text-success%20hover%3Atext-success-600%22%7D",
            onClick: () => setSuccess(""),
            className: "ml-auto text-success hover:text-success-600",
            children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\index.jsx:329:18", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "329", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22X%22%7D", name: "X", size: 16 }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
              lineNumber: 329,
              columnNumber: 19
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
            lineNumber: 325,
            columnNumber: 17
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
        lineNumber: 322,
        columnNumber: 13
      }, this),
      error && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\index.jsx:334:12", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "334", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-error-50%20border%20border-error-200%20text-error%20p-4%20rounded-lg%20flex%20items-center%20space-x-2%20mb-6%22%7D", className: "bg-error-50 border border-error-200 text-error p-4 rounded-lg flex items-center space-x-2 mb-6", children: [
        /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\index.jsx:335:16", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "335", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22AlertCircle%22%7D", name: "AlertCircle", size: 20 }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
          lineNumber: 335,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\index.jsx:336:16", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "336", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: error }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
          lineNumber: 336,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\contact-management\\index.jsx:337:16",
            "data-component-path": "src\\pages\\contact-management\\index.jsx",
            "data-component-line": "337",
            "data-component-file": "index.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22ml-auto%20text-error%20hover%3Atext-error-600%22%7D",
            onClick: () => setError(""),
            className: "ml-auto text-error hover:text-error-600",
            children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\index.jsx:341:18", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "341", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22X%22%7D", name: "X", size: 16 }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
              lineNumber: 341,
              columnNumber: 19
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
            lineNumber: 337,
            columnNumber: 17
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
        lineNumber: 334,
        columnNumber: 13
      }, this),
      isFilterPanelOpen && /* @__PURE__ */ jsxDEV(
        FilterPanel,
        {
          "data-component-id": "src\\pages\\contact-management\\index.jsx:348:12",
          "data-component-path": "src\\pages\\contact-management\\index.jsx",
          "data-component-line": "348",
          "data-component-file": "index.jsx",
          "data-component-name": "FilterPanel",
          "data-component-content": "%7B%22elementName%22%3A%22FilterPanel%22%7D",
          filters,
          setFilters,
          onClose: () => setIsFilterPanelOpen(false)
        },
        void 0,
        false,
        {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
          lineNumber: 348,
          columnNumber: 13
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\index.jsx:356:12", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "356", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22mb-6%22%7D", className: "mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\index.jsx:357:14", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "357", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22relative%20mb-4%22%7D", className: "relative mb-4", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\index.jsx:358:16", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "358", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22absolute%20inset-y-0%20left-0%20pl-3%20flex%20items-center%20pointer-events-none%22%7D", className: "absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none", children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\index.jsx:359:18", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "359", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Search%22%2C%22className%22%3A%22text-text-tertiary%22%7D", name: "Search", size: 18, className: "text-text-tertiary" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
            lineNumber: 359,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
            lineNumber: 358,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              "data-component-id": "src\\pages\\contact-management\\index.jsx:361:16",
              "data-component-path": "src\\pages\\contact-management\\index.jsx",
              "data-component-line": "361",
              "data-component-file": "index.jsx",
              "data-component-name": "input",
              "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22text%22%2C%22value%22%3A%22%5Bvar%3AsearchQuery%5D%22%2C%22className%22%3A%22input-field%20pl-10%22%7D",
              type: "text",
              placeholder: "Search contacts by name, email, or company...",
              value: searchQuery,
              onChange: (e) => setSearchQuery(e?.target?.value),
              className: "input-field pl-10"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
              lineNumber: 361,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
          lineNumber: 357,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\index.jsx:370:14", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "370", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20border-b%20border-border%22%7D", className: "flex border-b border-border", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\contact-management\\index.jsx:371:16",
              "data-component-path": "src\\pages\\contact-management\\index.jsx",
              "data-component-line": "371",
              "data-component-file": "index.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22textContent%22%3A%22All%20Contacts%22%7D",
              onClick: () => setActiveTab("all"),
              className: `px-4 py-2 text-sm font-medium ${activeTab === "all" ? "text-primary border-b-2 border-primary" : "text-text-secondary hover:text-text-primary"}`,
              children: "All Contacts"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
              lineNumber: 371,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\contact-management\\index.jsx:379:16",
              "data-component-path": "src\\pages\\contact-management\\index.jsx",
              "data-component-line": "379",
              "data-component-file": "index.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22textContent%22%3A%22Active%22%7D",
              onClick: () => setActiveTab("active"),
              className: `px-4 py-2 text-sm font-medium ${activeTab === "active" ? "text-primary border-b-2 border-primary" : "text-text-secondary hover:text-text-primary"}`,
              children: "Active"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
              lineNumber: 379,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\contact-management\\index.jsx:387:16",
              "data-component-path": "src\\pages\\contact-management\\index.jsx",
              "data-component-line": "387",
              "data-component-file": "index.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22textContent%22%3A%22Inactive%22%7D",
              onClick: () => setActiveTab("inactive"),
              className: `px-4 py-2 text-sm font-medium ${activeTab === "inactive" ? "text-primary border-b-2 border-primary" : "text-text-secondary hover:text-text-primary"}`,
              children: "Inactive"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
              lineNumber: 387,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
          lineNumber: 370,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
        lineNumber: 356,
        columnNumber: 13
      }, this),
      loading ? /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\index.jsx:400:12", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "400", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-center%20py-12%22%7D", className: "flex items-center justify-center py-12", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\index.jsx:401:16", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "401", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-3%22%7D", className: "flex items-center space-x-3", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\index.jsx:402:18", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "402", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22animate-spin%20rounded-full%20h-8%20w-8%20border-b-2%20border-primary%22%7D", className: "animate-spin rounded-full h-8 w-8 border-b-2 border-primary" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
          lineNumber: 402,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\index.jsx:403:18", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "403", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-text-secondary%22%2C%22textContent%22%3A%22Loading%20contacts...%22%7D", className: "text-text-secondary", children: "Loading contacts..." }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
          lineNumber: 403,
          columnNumber: 19
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
        lineNumber: 401,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
        lineNumber: 400,
        columnNumber: 13
      }, this) : (
        /* Main Content Area */
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\index.jsx:408:12", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "408", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20flex-col%20lg%3Aflex-row%20gap-6%22%7D", className: "flex flex-col lg:flex-row gap-6", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\index.jsx:410:16", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "410", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-full%20lg%3Aw-1%2F3%20xl%3Aw-1%2F4%22%7D", className: "w-full lg:w-1/3 xl:w-1/4", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\index.jsx:411:18", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "411", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20rounded-lg%20border%20border-border%20shadow-sm%22%7D", className: "bg-surface rounded-lg border border-border shadow-sm", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\index.jsx:413:20", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "413", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22p-4%20border-b%20border-border%20flex%20items-center%20justify-between%22%7D", className: "p-4 border-b border-border flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\index.jsx:414:22", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "414", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%22%7D", className: "flex items-center", children: [
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    "data-component-id": "src\\pages\\contact-management\\index.jsx:415:24",
                    "data-component-path": "src\\pages\\contact-management\\index.jsx",
                    "data-component-line": "415",
                    "data-component-file": "index.jsx",
                    "data-component-name": "input",
                    "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22checkbox%22%2C%22className%22%3A%22h-4%20w-4%20text-primary%20border-border%20rounded%20focus%3Aring-primary%22%7D",
                    type: "checkbox",
                    checked: selectedContacts?.length === filteredContacts?.length && filteredContacts?.length > 0,
                    onChange: handleSelectAll,
                    className: "h-4 w-4 text-primary border-border rounded focus:ring-primary"
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
                    lineNumber: 415,
                    columnNumber: 25
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\index.jsx:421:24", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "421", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22ml-3%20text-sm%20text-text-secondary%22%7D", className: "ml-3 text-sm text-text-secondary", children: selectedContacts?.length > 0 ? `${selectedContacts?.length} selected` : `${filteredContacts?.length} contacts` }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
                  lineNumber: 421,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
                lineNumber: 414,
                columnNumber: 23
              }, this),
              selectedContacts?.length > 0 && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\index.jsx:427:20", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "427", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20space-x-2%22%7D", className: "flex space-x-2", children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    "data-component-id": "src\\pages\\contact-management\\index.jsx:428:26",
                    "data-component-path": "src\\pages\\contact-management\\index.jsx",
                    "data-component-line": "428",
                    "data-component-file": "index.jsx",
                    "data-component-name": "button",
                    "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22text-text-secondary%20hover%3Atext-text-primary%22%7D",
                    onClick: () => setIsExportModalOpen(true),
                    className: "text-text-secondary hover:text-text-primary",
                    title: "Export Selected",
                    children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\index.jsx:433:28", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "433", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Download%22%7D", name: "Download", size: 16 }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
                      lineNumber: 433,
                      columnNumber: 29
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
                    lineNumber: 428,
                    columnNumber: 27
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    "data-component-id": "src\\pages\\contact-management\\index.jsx:435:26",
                    "data-component-path": "src\\pages\\contact-management\\index.jsx",
                    "data-component-line": "435",
                    "data-component-file": "index.jsx",
                    "data-component-name": "button",
                    "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22text-error%20hover%3Atext-error-600%22%7D",
                    onClick: handleBulkDelete,
                    className: "text-error hover:text-error-600",
                    title: "Delete Selected",
                    children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\index.jsx:440:28", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "440", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Trash2%22%7D", name: "Trash2", size: 16 }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
                      lineNumber: 440,
                      columnNumber: 29
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
                    lineNumber: 435,
                    columnNumber: 27
                  },
                  this
                ),
                selectedContacts?.length === 2 && /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    "data-component-id": "src\\pages\\contact-management\\index.jsx:443:22",
                    "data-component-path": "src\\pages\\contact-management\\index.jsx",
                    "data-component-line": "443",
                    "data-component-file": "index.jsx",
                    "data-component-name": "button",
                    "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22text-text-secondary%20hover%3Atext-text-primary%22%7D",
                    onClick: () => setIsMergeModalOpen(true),
                    className: "text-text-secondary hover:text-text-primary",
                    title: "Merge Contacts",
                    children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\index.jsx:448:30", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "448", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22GitMerge%22%7D", name: "GitMerge", size: 16 }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
                      lineNumber: 448,
                      columnNumber: 31
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
                    lineNumber: 443,
                    columnNumber: 23
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
                lineNumber: 427,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
              lineNumber: 413,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              ContactList,
              {
                "data-component-id": "src\\pages\\contact-management\\index.jsx:456:20",
                "data-component-path": "src\\pages\\contact-management\\index.jsx",
                "data-component-line": "456",
                "data-component-file": "index.jsx",
                "data-component-name": "ContactList",
                "data-component-content": "%7B%22elementName%22%3A%22ContactList%22%7D",
                contacts: filteredContacts,
                selectedContact,
                selectedContacts,
                onContactSelect: handleContactSelect,
                onContactMultiSelect: handleContactMultiSelect,
                onDeleteContact: handleDeleteContact
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
                lineNumber: 456,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
            lineNumber: 411,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
            lineNumber: 410,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\index.jsx:468:16", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "468", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-full%20lg%3Aw-2%2F3%20xl%3Aw-3%2F4%22%7D", className: "w-full lg:w-2/3 xl:w-3/4", children: isAddingContact || isEditingContact ? /* @__PURE__ */ jsxDEV(
            ContactForm,
            {
              "data-component-id": "src\\pages\\contact-management\\index.jsx:470:16",
              "data-component-path": "src\\pages\\contact-management\\index.jsx",
              "data-component-line": "470",
              "data-component-file": "index.jsx",
              "data-component-name": "ContactForm",
              "data-component-content": "%7B%22elementName%22%3A%22ContactForm%22%7D",
              contact: isEditingContact ? selectedContact : null,
              onSubmit: handleSaveContact,
              onCancel: handleCancelForm,
              isEditing: isEditingContact
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
              lineNumber: 470,
              columnNumber: 17
            },
            this
          ) : selectedContact ? /* @__PURE__ */ jsxDEV(
            ContactDetail,
            {
              "data-component-id": "src\\pages\\contact-management\\index.jsx:477:16",
              "data-component-path": "src\\pages\\contact-management\\index.jsx",
              "data-component-line": "477",
              "data-component-file": "index.jsx",
              "data-component-name": "ContactDetail",
              "data-component-content": "%7B%22elementName%22%3A%22ContactDetail%22%7D",
              contact: selectedContact,
              onEdit: handleEditContact,
              onDelete: () => handleDeleteContact(selectedContact?.id),
              onContactUpdate: handleContactUpdate
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
              lineNumber: 477,
              columnNumber: 17
            },
            this
          ) : /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\index.jsx:484:16", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "484", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20rounded-lg%20border%20border-border%20shadow-sm%20p-8%20text-center%22%7D", className: "bg-surface rounded-lg border border-border shadow-sm p-8 text-center", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\index.jsx:485:22", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "485", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-16%20h-16%20bg-primary-50%20rounded-full%20flex%20items-center%20justify-center%20mx-auto%20mb-4%22%7D", className: "w-16 h-16 bg-primary-50 rounded-full flex items-center justify-center mx-auto mb-4", children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\index.jsx:486:24", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "486", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Users%22%2C%22className%22%3A%22text-primary%22%7D", name: "Users", size: 24, className: "text-primary" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
              lineNumber: 486,
              columnNumber: 25
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
              lineNumber: 485,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\contact-management\\index.jsx:488:22", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "488", "data-component-file": "index.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-xl%20font-semibold%20text-text-primary%20mb-2%22%2C%22textContent%22%3A%22No%20Contact%20Selected%22%7D", className: "text-xl font-semibold text-text-primary mb-2", children: "No Contact Selected" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
              lineNumber: 488,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\contact-management\\index.jsx:489:22", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "489", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20mb-6%22%2C%22textContent%22%3A%22Select%20a%20contact%20from%20the%20list%20or%20add%20a%20new%20one%20to%20get%20started.%22%7D", className: "text-text-secondary mb-6", children: "Select a contact from the list or add a new one to get started." }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
              lineNumber: 489,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                "data-component-id": "src\\pages\\contact-management\\index.jsx:490:22",
                "data-component-path": "src\\pages\\contact-management\\index.jsx",
                "data-component-line": "490",
                "data-component-file": "index.jsx",
                "data-component-name": "button",
                "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22btn-primary%20inline-flex%20items-center%20space-x-2%22%7D",
                onClick: handleAddContact,
                className: "btn-primary inline-flex items-center space-x-2",
                children: [
                  /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\index.jsx:494:24", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "494", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22UserPlus%22%7D", name: "UserPlus", size: 18 }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
                    lineNumber: 494,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\index.jsx:495:24", "data-component-path": "src\\pages\\contact-management\\index.jsx", "data-component-line": "495", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Add%20New%20Contact%22%7D", children: "Add New Contact" }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
                    lineNumber: 495,
                    columnNumber: 25
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
                lineNumber: 490,
                columnNumber: 23
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
            lineNumber: 484,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
            lineNumber: 468,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
          lineNumber: 408,
          columnNumber: 13
        }, this)
      )
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
      lineNumber: 276,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
      lineNumber: 275,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
      lineNumber: 274,
      columnNumber: 7
    }, this),
    isImportModalOpen && /* @__PURE__ */ jsxDEV(
      ImportContactsModal,
      {
        "data-component-id": "src\\pages\\contact-management\\index.jsx:507:6",
        "data-component-path": "src\\pages\\contact-management\\index.jsx",
        "data-component-line": "507",
        "data-component-file": "index.jsx",
        "data-component-name": "ImportContactsModal",
        "data-component-content": "%7B%22elementName%22%3A%22ImportContactsModal%22%7D",
        onImport: handleImportContacts,
        onClose: () => setIsImportModalOpen(false)
      },
      void 0,
      false,
      {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
        lineNumber: 507,
        columnNumber: 7
      },
      this
    ),
    isExportModalOpen && /* @__PURE__ */ jsxDEV(
      ExportContactsModal,
      {
        "data-component-id": "src\\pages\\contact-management\\index.jsx:513:6",
        "data-component-path": "src\\pages\\contact-management\\index.jsx",
        "data-component-line": "513",
        "data-component-file": "index.jsx",
        "data-component-name": "ExportContactsModal",
        "data-component-content": "%7B%22elementName%22%3A%22ExportContactsModal%22%7D",
        contacts: contacts?.filter((contact) => selectedContacts?.includes(contact?.id)),
        onClose: () => setIsExportModalOpen(false)
      },
      void 0,
      false,
      {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
        lineNumber: 513,
        columnNumber: 7
      },
      this
    ),
    isMergeModalOpen && selectedContacts?.length === 2 && /* @__PURE__ */ jsxDEV(
      MergeDuplicatesModal,
      {
        "data-component-id": "src\\pages\\contact-management\\index.jsx:519:6",
        "data-component-path": "src\\pages\\contact-management\\index.jsx",
        "data-component-line": "519",
        "data-component-file": "index.jsx",
        "data-component-name": "MergeDuplicatesModal",
        "data-component-content": "%7B%22elementName%22%3A%22MergeDuplicatesModal%22%7D",
        contact1: contacts?.find((c) => c?.id === selectedContacts?.[0]),
        contact2: contacts?.find((c) => c?.id === selectedContacts?.[1]),
        onMerge: (mergedContact) => {
          const updatedContacts = contacts?.filter((c) => !selectedContacts?.includes(c?.id));
          setContacts([...updatedContacts, mergedContact]);
          setSelectedContact(mergedContact);
          setSelectedContacts([]);
          setIsMergeModalOpen(false);
        },
        onClose: () => setIsMergeModalOpen(false)
      },
      void 0,
      false,
      {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
        lineNumber: 519,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/contact-management/index.jsx",
    lineNumber: 272,
    columnNumber: 5
  }, this);
};
_s(ContactManagement, "LAQKFsHeYA/4eab4Q4ZXIa3pivw=", false, function() {
  return [useAuth];
});
_c = ContactManagement;
export default ContactManagement;
var _c;
$RefreshReg$(_c, "ContactManagement");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/contact-management/index.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/contact-management/index.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ1JNOzJCQWhSTjtBQUFnQkEsTUFBVUMsY0FBUyxPQUFRLHNCQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRWxELE9BQU9DLFVBQVU7QUFFakIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxnQkFBZ0I7QUFDdkIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLG1CQUFtQjtBQUMxQixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0MseUJBQXlCO0FBQ2hDLE9BQU9DLHlCQUF5QjtBQUNoQyxPQUFPQywwQkFBMEI7QUFDakMsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLHFCQUFxQjtBQUM1QixTQUFTQyxlQUFlO0FBRXhCLE1BQU1DLG9CQUFvQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzlCLFFBQU0sRUFBRUMsS0FBSyxJQUFJSCxRQUFRO0FBQ3pCLFFBQU0sQ0FBQ0ksVUFBVUMsV0FBVyxJQUFJbEIsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ21CLFNBQVNDLFVBQVUsSUFBSXBCLFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUNxQixpQkFBaUJDLGtCQUFrQixJQUFJdEIsU0FBUyxJQUFJO0FBQzNELFFBQU0sQ0FBQ3VCLGtCQUFrQkMsbUJBQW1CLElBQUl4QixTQUFTLEVBQUU7QUFDM0QsUUFBTSxDQUFDeUIsYUFBYUMsY0FBYyxJQUFJMUIsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQzJCLG1CQUFtQkMsb0JBQW9CLElBQUk1QixTQUFTLEtBQUs7QUFDaEUsUUFBTSxDQUFDNkIsaUJBQWlCQyxrQkFBa0IsSUFBSTlCLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUMrQixrQkFBa0JDLG1CQUFtQixJQUFJaEMsU0FBUyxLQUFLO0FBQzlELFFBQU0sQ0FBQ2lDLG1CQUFtQkMsb0JBQW9CLElBQUlsQyxTQUFTLEtBQUs7QUFDaEUsUUFBTSxDQUFDbUMsbUJBQW1CQyxvQkFBb0IsSUFBSXBDLFNBQVMsS0FBSztBQUNoRSxRQUFNLENBQUNxQyxrQkFBa0JDLG1CQUFtQixJQUFJdEMsU0FBUyxLQUFLO0FBQzlELFFBQU0sQ0FBQ3VDLFdBQVdDLFlBQVksSUFBSXhDLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUN5QyxPQUFPQyxRQUFRLElBQUkxQyxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDMkMsU0FBU0MsVUFBVSxJQUFJNUMsU0FBUyxFQUFFO0FBQ3pDLFFBQU0sQ0FBQzZDLFNBQVNDLFVBQVUsSUFBSTlDLFNBQVM7QUFBQSxJQUNyQytDLFNBQVM7QUFBQSxJQUNUQyxXQUFXO0FBQUEsSUFDWEMsaUJBQWlCO0FBQUEsSUFDakJDLE1BQU07QUFBQSxFQUNSLENBQUM7QUFHRCxRQUFNQyxlQUFlLFlBQVk7QUFDL0IsUUFBSTtBQUNGL0IsaUJBQVcsSUFBSTtBQUNmc0IsZUFBUyxFQUFFO0FBRVgsVUFBSVUsZUFBZTtBQUNuQixVQUFJM0IsYUFBYTtBQUNmMkIsdUJBQWUsTUFBTXhDLGlCQUFpQnlDLGVBQWU1QixXQUFXO0FBQUEsTUFDbEUsT0FBTztBQUNMLGNBQU02QixlQUFlLENBQUM7QUFFdEIsWUFBSVQsU0FBU0UsU0FBU1EsU0FBUyxHQUFHO0FBQ2hDRCx1QkFBYUUsWUFBWVgsU0FBU0U7QUFBQUEsUUFDcEM7QUFFQSxZQUFJRixTQUFTRyxXQUFXTyxTQUFTLEdBQUc7QUFDbENELHVCQUFhRyxhQUFhWixTQUFTRztBQUFBQSxRQUNyQztBQUVBLFlBQUlILFNBQVNLLE1BQU1LLFNBQVMsR0FBRztBQUM3QkQsdUJBQWFKLE9BQU9MLFNBQVNLO0FBQUFBLFFBQy9CO0FBRUEsWUFBSUwsU0FBU0ksaUJBQWlCO0FBQzVCSyx1QkFBYUksWUFBWWIsU0FBU0k7QUFBQUEsUUFDcEM7QUFFQSxZQUFJVSxPQUFPQyxLQUFLTixZQUFZLEdBQUdDLFNBQVMsR0FBRztBQUN6Q0gseUJBQWUsTUFBTXhDLGlCQUFpQmlELGVBQWVQLFlBQVk7QUFBQSxRQUNuRSxPQUFPO0FBQ0xGLHlCQUFlLE1BQU14QyxpQkFBaUJrRCxnQkFBZ0I7QUFBQSxRQUN4RDtBQUFBLE1BQ0Y7QUFFQTVDLGtCQUFZa0MsZ0JBQWdCLEVBQUU7QUFHOUIsVUFBSUEsY0FBY0csU0FBUyxLQUFLUSxPQUFPQyxjQUFjLFFBQVEsQ0FBQzNDLGlCQUFpQjtBQUM3RUMsMkJBQW1COEIsZUFBZSxDQUFDLENBQUM7QUFBQSxNQUN0QztBQUFBLElBQ0YsU0FBU2EsS0FBSztBQUNaQyxjQUFRekIsTUFBTSwyQkFBMkJ3QixHQUFHO0FBQzVDLFVBQUlBLEtBQUtFLFNBQVNDLFNBQVMsaUJBQWlCLEtBQ3hDSCxLQUFLRSxTQUFTQyxTQUFTLGNBQWMsR0FBRztBQUMxQzFCLGlCQUFTLHNKQUFzSjtBQUFBLE1BQ2pLLE9BQU87QUFDTEEsaUJBQVMsNENBQTRDO0FBQUEsTUFDdkQ7QUFBQSxJQUNGLFVBQUM7QUFDQ3RCLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQW5CLFlBQVUsTUFBTTtBQUNkLFFBQUllLE1BQU07QUFDUm1DLG1CQUFhO0FBQUEsSUFDZjtBQUFBLEVBQ0YsR0FBRyxDQUFDbkMsTUFBTVMsYUFBYW9CLFNBQVNOLFNBQVMsQ0FBQztBQUcxQ3RDLFlBQVUsTUFBTTtBQUNkLFFBQUl3QyxTQUFTRSxTQUFTO0FBQ3BCLFlBQU0wQixRQUFRQyxXQUFXLE1BQU07QUFDN0I1QixpQkFBUyxFQUFFO0FBQ1hFLG1CQUFXLEVBQUU7QUFBQSxNQUNmLEdBQUcsR0FBSTtBQUNQLGFBQU8sTUFBTTJCLGFBQWFGLEtBQUs7QUFBQSxJQUNqQztBQUFBLEVBQ0YsR0FBRyxDQUFDNUIsT0FBT0UsT0FBTyxDQUFDO0FBR25CLFFBQU02QixtQkFBbUJ2RCxVQUFVd0QsT0FBTyxDQUFBQyxZQUFXO0FBRW5ELFFBQUluQyxjQUFjLFVBQVU7QUFDMUIsYUFBT21DLFNBQVNDLFdBQVc7QUFBQSxJQUM3QixXQUFXcEMsY0FBYyxZQUFZO0FBQ25DLGFBQU9tQyxTQUFTQyxXQUFXO0FBQUEsSUFDN0I7QUFDQSxXQUFPO0FBQUEsRUFDVCxDQUFDO0FBRUQsUUFBTUMsc0JBQXNCQSxDQUFDRixZQUFZO0FBRXZDUixZQUFRVyxJQUFJLG9DQUFvQ0gsT0FBTztBQUN2RCxRQUFJO0FBQ0ZwRCx5QkFBbUJvRCxPQUFPO0FBQzFCNUMseUJBQW1CLEtBQUs7QUFDeEJFLDBCQUFvQixLQUFLO0FBQUEsSUFDM0IsU0FBU1MsUUFBTztBQUNkeUIsY0FBUXpCLE1BQU0saUNBQWlDQSxNQUFLO0FBQ3BEQyxlQUFTLHFFQUFxRTtBQUFBLElBQ2hGO0FBQUEsRUFDRjtBQUVBLFFBQU1vQywyQkFBMkJBLENBQUNDLGNBQWM7QUFDOUNiLFlBQVFXLElBQUkseUNBQXlDRSxTQUFTO0FBQzlELFFBQUk7QUFDRnZELDBCQUFvQixDQUFBd0QsU0FBUTtBQUMxQixjQUFNQyxjQUFjRCxNQUFNWixTQUFTVyxTQUFTLElBQ3hDQyxNQUFNUCxPQUFPLENBQUFTLE9BQU1BLE9BQU9ILFNBQVMsSUFDbkMsQ0FBQyxHQUFJQyxRQUFRLElBQUtELFNBQVM7QUFDL0JiLGdCQUFRVyxJQUFJLDZCQUE2QkksV0FBVztBQUNwRCxlQUFPQTtBQUFBQSxNQUNULENBQUM7QUFBQSxJQUNILFNBQVN4QyxRQUFPO0FBQ2R5QixjQUFRekIsTUFBTSxzQ0FBc0NBLE1BQUs7QUFDekRDLGVBQVMsa0VBQWtFO0FBQUEsSUFDN0U7QUFBQSxFQUNGO0FBRUEsUUFBTXlDLGtCQUFrQkEsTUFBTTtBQUM1QixRQUFJNUQsa0JBQWtCZ0MsV0FBV2lCLGtCQUFrQmpCLFFBQVE7QUFDekQvQiwwQkFBb0IsRUFBRTtBQUFBLElBQ3hCLE9BQU87QUFDTEEsMEJBQW9CZ0Qsa0JBQWtCWSxJQUFJLENBQUFWLFlBQVdBLFNBQVNRLEVBQUUsQ0FBQztBQUFBLElBQ25FO0FBQUEsRUFDRjtBQUVBLFFBQU1HLG1CQUFtQkEsTUFBTTtBQUM3Qi9ELHVCQUFtQixJQUFJO0FBQ3ZCUSx1QkFBbUIsSUFBSTtBQUN2QkUsd0JBQW9CLEtBQUs7QUFBQSxFQUMzQjtBQUVBLFFBQU1zRCxvQkFBb0JBLE1BQU07QUFDOUJ4RCx1QkFBbUIsS0FBSztBQUN4QkUsd0JBQW9CLElBQUk7QUFBQSxFQUMxQjtBQUVBLFFBQU11RCxvQkFBb0IsT0FBT0MsZ0JBQWdCO0FBQy9DLFFBQUk7QUFDRjlDLGVBQVMsRUFBRTtBQUNYLFVBQUkrQztBQUVKLFVBQUk1RCxpQkFBaUI7QUFDbkI0RCxpQkFBU0Q7QUFDVDVDLG1CQUFXLCtCQUErQjtBQUFBLE1BQzVDLFdBQVdiLG9CQUFvQlYsaUJBQWlCO0FBQzlDb0UsaUJBQVNEO0FBQ1Q1QyxtQkFBVywrQkFBK0I7QUFBQSxNQUM1QztBQUVBdEIseUJBQW1CbUUsTUFBTTtBQUN6QjNELHlCQUFtQixLQUFLO0FBQ3hCRSwwQkFBb0IsS0FBSztBQUd6Qm1CLG1CQUFhO0FBQUEsSUFDZixTQUFTYyxLQUFLO0FBQ1pDLGNBQVF6QixNQUFNLHlCQUF5QndCLEdBQUc7QUFDMUN2QixlQUFTLDJDQUEyQztBQUFBLElBQ3REO0FBQUEsRUFDRjtBQUVBLFFBQU1nRCxtQkFBbUJBLE1BQU07QUFDN0I1RCx1QkFBbUIsS0FBSztBQUN4QkUsd0JBQW9CLEtBQUs7QUFDekIsUUFBSVgsb0JBQW9CLFFBQVFKLFVBQVVzQyxTQUFTLEdBQUc7QUFDcERqQyx5QkFBbUJMLFdBQVcsQ0FBQyxDQUFDO0FBQUEsSUFDbEM7QUFBQSxFQUNGO0FBRUEsUUFBTTBFLHNCQUFzQixPQUFPWixjQUFjO0FBQy9DLFFBQUk7QUFDRnJDLGVBQVMsRUFBRTtBQUNYLFlBQU05QixpQkFBaUJnRixjQUFjYixTQUFTO0FBQzlDbkMsaUJBQVcsK0JBQStCO0FBRzFDLFlBQU1pRCxrQkFBa0I1RSxVQUFVd0QsT0FBTyxDQUFBQyxZQUFXQSxTQUFTUSxPQUFPSCxTQUFTO0FBQzdFN0Qsa0JBQVkyRSxlQUFlO0FBRTNCLFVBQUl4RSxtQkFBbUJBLGlCQUFpQjZELE9BQU9ILFdBQVc7QUFDeER6RCwyQkFBbUJ1RSxpQkFBaUJ0QyxTQUFTLElBQUlzQyxrQkFBa0IsQ0FBQyxJQUFJLElBQUk7QUFBQSxNQUM5RTtBQUVBckUsMEJBQW9CLENBQUF3RCxTQUFRQSxNQUFNUCxPQUFPLENBQUFTLE9BQU1BLE9BQU9ILFNBQVMsQ0FBQztBQUFBLElBQ2xFLFNBQVNkLEtBQUs7QUFDWkMsY0FBUXpCLE1BQU0sMkJBQTJCd0IsR0FBRztBQUM1Q3ZCLGVBQVMsNkNBQTZDO0FBQUEsSUFDeEQ7QUFBQSxFQUNGO0FBRUEsUUFBTW9ELG1CQUFtQixZQUFZO0FBQ25DLFFBQUk7QUFDRnBELGVBQVMsRUFBRTtBQUNYLFlBQU05QixpQkFBaUJtRixlQUFleEUsZ0JBQWdCO0FBQ3REcUIsaUJBQVcsR0FBR3JCLGtCQUFrQmdDLE1BQU0sbUNBQW1DO0FBR3pFLFlBQU1zQyxrQkFBa0I1RSxVQUFVd0QsT0FBTyxDQUFBQyxZQUFXLENBQUNuRCxrQkFBa0I2QyxTQUFTTSxTQUFTUSxFQUFFLENBQUM7QUFDNUZoRSxrQkFBWTJFLGVBQWU7QUFFM0IsVUFBSXhFLG1CQUFtQkUsa0JBQWtCNkMsU0FBUy9DLGlCQUFpQjZELEVBQUUsR0FBRztBQUN0RTVELDJCQUFtQnVFLGlCQUFpQnRDLFNBQVMsSUFBSXNDLGtCQUFrQixDQUFDLElBQUksSUFBSTtBQUFBLE1BQzlFO0FBRUFyRSwwQkFBb0IsRUFBRTtBQUFBLElBQ3hCLFNBQVN5QyxLQUFLO0FBQ1pDLGNBQVF6QixNQUFNLDRCQUE0QndCLEdBQUc7QUFDN0N2QixlQUFTLDhDQUE4QztBQUFBLElBQ3pEO0FBQUEsRUFDRjtBQUVBLFFBQU1zRCxzQkFBc0JBLENBQUNDLG1CQUFtQjtBQUU5QyxVQUFNSixrQkFBa0I1RSxTQUFTbUU7QUFBQUEsTUFBSSxDQUFBVixZQUNuQ0EsUUFBUVEsT0FBT2UsZUFBZWYsS0FBS2UsaUJBQWlCdkI7QUFBQUEsSUFDdEQ7QUFDQXhELGdCQUFZMkUsZUFBZTtBQUczQixRQUFJeEUsbUJBQW1CQSxnQkFBZ0I2RCxPQUFPZSxlQUFlZixJQUFJO0FBQy9ENUQseUJBQW1CMkUsY0FBYztBQUFBLElBQ25DO0FBQUEsRUFDRjtBQUVBLFFBQU1DLHVCQUF1QixPQUFPQyxxQkFBcUI7QUFDdkQsUUFBSTtBQUNGekQsZUFBUyxFQUFFO0FBQ1gsWUFBTTlCLGlCQUFpQndGLGVBQWVELGdCQUFnQjtBQUN0RHZELGlCQUFXLEdBQUd1RCxrQkFBa0I1QyxNQUFNLG9DQUFvQztBQUMxRXJCLDJCQUFxQixLQUFLO0FBQzFCaUIsbUJBQWE7QUFBQSxJQUNmLFNBQVNjLEtBQUs7QUFDWkMsY0FBUXpCLE1BQU0sNkJBQTZCd0IsR0FBRztBQUM5Q3ZCLGVBQVMsOENBQThDO0FBQUEsSUFDekQ7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyw2V0FBSSxXQUFVLDhCQUNiO0FBQUEsMkJBQUMsK1RBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFPO0FBQUEsSUFDUCx1QkFBQyx5VkFBSyxXQUFVLFNBQ2QsaUNBQUMsNFZBQUksV0FBVSxhQUNiLGlDQUFDLHFXQUFJLFdBQVUscUJBQ2I7QUFBQSw2QkFBQyw0VUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVc7QUFBQSxNQUVYLHVCQUFDLDRhQUFJLFdBQVUsOEVBQ2I7QUFBQSwrQkFBQyx1VEFDQztBQUFBLGlDQUFDLHdiQUFHLFdBQVUsb0RBQW1ELGtDQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRjtBQUFBLFVBQ25GLHVCQUFDLDJjQUFFLFdBQVUsNEJBQTJCLDRFQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRztBQUFBLGFBRnRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBRUEsdUJBQUMsNlhBQUksV0FBVSxxQ0FDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FDQyxTQUFTMkM7QUFBQUEsY0FDVCxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLHNWQUFLLE1BQUssWUFBVyxNQUFNLE1BQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStCO0FBQUEsZ0JBQy9CLHVCQUFDLG9XQUFLLDJCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlCO0FBQUE7QUFBQTtBQUFBLFlBTG5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsVUFFQTtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNbkQscUJBQXFCLElBQUk7QUFBQSxjQUN4QyxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLG9WQUFLLE1BQUssVUFBUyxNQUFNLE1BQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZCO0FBQUEsZ0JBQzdCLHVCQUFDLDZWQUFLLHNCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQVk7QUFBQTtBQUFBO0FBQUEsWUFMZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLFVBRUE7QUFBQSxZQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUNDLFNBQVMsTUFBTU4scUJBQXFCLENBQUNELGlCQUFpQjtBQUFBLGNBQ3RELFdBQVcsdUdBQ1RnQyxPQUFPMEMsT0FBT3hELE9BQU8sR0FBR3lELEtBQUssQ0FBQUMsTUFBS0MsTUFBTUMsUUFBUUYsQ0FBQyxJQUFJQSxHQUFHaEQsU0FBUyxJQUFJZ0QsTUFBTSxJQUFJLEtBQUs1RSxvQkFDaEYsa0RBQWlELGtGQUFrRjtBQUFBLGNBR3pJO0FBQUEsdUNBQUMsb1ZBQUssTUFBSyxVQUFTLE1BQU0sTUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkI7QUFBQSxnQkFDN0IsdUJBQUMsNlZBQUssc0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBWTtBQUFBLGdCQUNYZ0MsT0FBTzBDLE9BQU94RCxPQUFPLEdBQUd5RCxLQUFLLENBQUFDLE1BQUtDLE1BQU1DLFFBQVFGLENBQUMsSUFBSUEsR0FBR2hELFNBQVMsSUFBSWdELE1BQU0sSUFBSSxLQUM5RSx1QkFBQyx3YkFBSyxXQUFVLHVGQUNiNUMsaUJBQU8wQyxPQUFPeEQsT0FBTyxHQUFHNkQsT0FBTyxDQUFDQyxPQUFPSixNQUFNSSxTQUFTSCxNQUFNQyxRQUFRRixDQUFDLElBQUlBLEdBQUdoRCxTQUFVZ0QsTUFBTSxPQUFPLElBQUksSUFBSyxDQUFDLEtBRGhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQTtBQUFBO0FBQUEsWUFaSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFjQTtBQUFBLGFBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQ0E7QUFBQSxXQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdUNBO0FBQUEsTUFHQzVELFdBQ0MsdUJBQUMsd2NBQUksV0FBVSx3R0FDYjtBQUFBLCtCQUFDLHlWQUFLLE1BQUssZUFBYyxNQUFNLE1BQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0M7QUFBQSxRQUNsQyx1QkFBQywwVEFBTUEscUJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFlO0FBQUEsUUFDZjtBQUFBLFVBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNQyxXQUFXLEVBQUU7QUFBQSxZQUM1QixXQUFVO0FBQUEsWUFFVixpQ0FBQywrVUFBSyxNQUFLLEtBQUksTUFBTSxNQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3QjtBQUFBO0FBQUEsVUFKMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxXQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BRURILFNBQ0MsdUJBQUMsa2NBQUksV0FBVSxrR0FDYjtBQUFBLCtCQUFDLHlWQUFLLE1BQUssZUFBYyxNQUFNLE1BQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0M7QUFBQSxRQUNsQyx1QkFBQywwVEFBTUEsbUJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFhO0FBQUEsUUFDYjtBQUFBLFVBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNQyxTQUFTLEVBQUU7QUFBQSxZQUMxQixXQUFVO0FBQUEsWUFFVixpQ0FBQywrVUFBSyxNQUFLLEtBQUksTUFBTSxNQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3QjtBQUFBO0FBQUEsVUFKMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxXQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BSURmLHFCQUNDO0FBQUEsUUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFDQztBQUFBLFVBQ0E7QUFBQSxVQUNBLFNBQVMsTUFBTUMscUJBQXFCLEtBQUs7QUFBQTtBQUFBLFFBSDNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUc2QztBQUFBLE1BSy9DLHVCQUFDLHNWQUFJLFdBQVUsUUFDYjtBQUFBLCtCQUFDLGlXQUFJLFdBQVUsaUJBQ2I7QUFBQSxpQ0FBQyxrYUFBSSxXQUFVLHdFQUNiLGlDQUFDLGlZQUFLLE1BQUssVUFBUyxNQUFNLElBQUksV0FBVSx3QkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEQsS0FEOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLGFBQVk7QUFBQSxjQUNaLE9BQU9IO0FBQUFBLGNBQ1AsVUFBVSxDQUFDbUYsTUFBTWxGLGVBQWVrRixHQUFHQyxRQUFRQyxLQUFLO0FBQUEsY0FDaEQsV0FBVTtBQUFBO0FBQUEsWUFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLK0I7QUFBQSxhQVRqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0E7QUFBQSxRQUVBLHVCQUFDLGlYQUFJLFdBQVUsK0JBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNdEUsYUFBYSxLQUFLO0FBQUEsY0FDakMsV0FBVyxpQ0FDVEQsY0FBYyxRQUFPLDJDQUEwQyw2Q0FBNkM7QUFBQSxjQUMzRztBQUFBO0FBQUEsWUFKTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUNDLFNBQVMsTUFBTUMsYUFBYSxRQUFRO0FBQUEsY0FDcEMsV0FBVyxpQ0FDVEQsY0FBYyxXQUFVLDJDQUEwQyw2Q0FBNkM7QUFBQSxjQUM5RztBQUFBO0FBQUEsWUFKTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUNDLFNBQVMsTUFBTUMsYUFBYSxVQUFVO0FBQUEsY0FDdEMsV0FBVyxpQ0FDVEQsY0FBYyxhQUFZLDJDQUEwQyw2Q0FBNkM7QUFBQSxjQUNoSDtBQUFBO0FBQUEsWUFKTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPQTtBQUFBLGFBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5QkE7QUFBQSxXQXZDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0NBO0FBQUEsTUFHQ3BCLFVBQ0MsdUJBQUMsOFhBQUksV0FBVSwwQ0FDYixpQ0FBQyxpWEFBSSxXQUFVLCtCQUNiO0FBQUEsK0JBQUMsdVpBQUksV0FBVSxpRUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZFO0FBQUEsUUFDN0UsdUJBQUMsMFpBQUssV0FBVSx1QkFBc0IsbUNBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUQ7QUFBQSxXQUYzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQTtBQUFBLFFBR0EsdUJBQUMseVhBQUksV0FBVSxtQ0FFYjtBQUFBLGlDQUFDLHNYQUFJLFdBQVUsNEJBQ2IsaUNBQUMsOFlBQUksV0FBVSx3REFFYjtBQUFBLG1DQUFDLHdaQUFJLFdBQVUsZ0VBQ2I7QUFBQSxxQ0FBQyxxV0FBSSxXQUFVLHFCQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVNJLGtCQUFrQmdDLFdBQVdpQixrQkFBa0JqQixVQUFVaUIsa0JBQWtCakIsU0FBUztBQUFBLG9CQUM3RixVQUFVNEI7QUFBQUEsb0JBQ1YsV0FBVTtBQUFBO0FBQUEsa0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUkyRTtBQUFBLGdCQUUzRSx1QkFBQyx5WEFBSyxXQUFVLG9DQUNiNUQsNEJBQWtCZ0MsU0FBUyxJQUFJLEdBQUdoQyxrQkFBa0JnQyxNQUFNLGNBQWMsR0FBR2lCLGtCQUFrQmpCLE1BQU0sZUFEdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVUE7QUFBQSxjQUVDaEMsa0JBQWtCZ0MsU0FBUyxLQUMxQix1QkFBQyxrV0FBSSxXQUFVLGtCQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBQ0MsU0FBUyxNQUFNbkIscUJBQXFCLElBQUk7QUFBQSxvQkFDeEMsV0FBVTtBQUFBLG9CQUNWLE9BQU07QUFBQSxvQkFFTixpQ0FBQyxzVkFBSyxNQUFLLFlBQVcsTUFBTSxNQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUErQjtBQUFBO0FBQUEsa0JBTGpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUNDLFNBQVMwRDtBQUFBQSxvQkFDVCxXQUFVO0FBQUEsb0JBQ1YsT0FBTTtBQUFBLG9CQUVOLGlDQUFDLG9WQUFLLE1BQUssVUFBUyxNQUFNLE1BQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTZCO0FBQUE7QUFBQSxrQkFML0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1BO0FBQUEsZ0JBQ0N2RSxrQkFBa0JnQyxXQUFXLEtBQzVCO0FBQUEsa0JBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUNDLFNBQVMsTUFBTWpCLG9CQUFvQixJQUFJO0FBQUEsb0JBQ3ZDLFdBQVU7QUFBQSxvQkFDVixPQUFNO0FBQUEsb0JBRU4saUNBQUMsc1ZBQUssTUFBSyxZQUFXLE1BQU0sTUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBK0I7QUFBQTtBQUFBLGtCQUxqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQSxtQkF0Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF3QkE7QUFBQSxpQkF0Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF3Q0E7QUFBQSxZQUdBO0FBQUEsY0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ0MsVUFBVWtDO0FBQUFBLGdCQUNWO0FBQUEsZ0JBQ0E7QUFBQSxnQkFDQSxpQkFBaUJJO0FBQUFBLGdCQUNqQixzQkFBc0JFO0FBQUFBLGdCQUN0QixpQkFBaUJhO0FBQUFBO0FBQUFBLGNBTm5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU11QztBQUFBLGVBbkR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXFEQSxLQXRERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVEQTtBQUFBLFVBR0EsdUJBQUMsc1hBQUksV0FBVSw0QkFDWjlELDZCQUFtQkUsbUJBQ2xCO0FBQUEsWUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FDQyxTQUFTQSxtQkFBbUJWLGtCQUFrQjtBQUFBLGNBQzlDLFVBQVVrRTtBQUFBQSxjQUNWLFVBQVVHO0FBQUFBLGNBQ1YsV0FBVzNEO0FBQUFBO0FBQUFBLFlBSmI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSThCLElBRTVCVixrQkFDRjtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsU0FBU0E7QUFBQUEsY0FDVCxRQUFRaUU7QUFBQUEsY0FDUixVQUFVLE1BQU1LLG9CQUFvQnRFLGlCQUFpQjZELEVBQUU7QUFBQSxjQUN2RCxpQkFBaUJjO0FBQUFBO0FBQUFBLFlBSm5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUl1QyxJQUd2Qyx1QkFBQyxrYUFBSSxXQUFVLHdFQUNiO0FBQUEsbUNBQUMsb2JBQUksV0FBVSxzRkFDYixpQ0FBQywwWEFBSyxNQUFLLFNBQVEsTUFBTSxJQUFJLFdBQVUsa0JBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFELEtBRHZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLHFiQUFHLFdBQVUsZ0RBQStDLG1DQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRjtBQUFBLFlBQ2hGLHVCQUFDLDRkQUFFLFdBQVUsNEJBQTJCLCtFQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RztBQUFBLFlBQ3ZHO0FBQUEsY0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ0MsU0FBU1g7QUFBQUEsZ0JBQ1QsV0FBVTtBQUFBLGdCQUVWO0FBQUEseUNBQUMsc1ZBQUssTUFBSyxZQUFXLE1BQU0sTUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0I7QUFBQSxrQkFDL0IsdUJBQUMsMFdBQUssK0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBcUI7QUFBQTtBQUFBO0FBQUEsY0FMdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUE7QUFBQSxlQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUEsS0E3Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkErQkE7QUFBQSxhQTNGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNEZBO0FBQUE7QUFBQSxTQWhPSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa09BLEtBbk9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvT0EsS0FyT0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNPQTtBQUFBLElBRUNwRCxxQkFDQztBQUFBLE1BQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBQ0MsVUFBVWlFO0FBQUFBLFFBQ1YsU0FBUyxNQUFNaEUscUJBQXFCLEtBQUs7QUFBQTtBQUFBLE1BRjNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUU2QztBQUFBLElBRzlDQyxxQkFDQztBQUFBLE1BQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBQ0MsVUFBVWxCLFVBQVV3RCxPQUFPLENBQUFDLFlBQVduRCxrQkFBa0I2QyxTQUFTTSxTQUFTUSxFQUFFLENBQUM7QUFBQSxRQUM3RSxTQUFTLE1BQU05QyxxQkFBcUIsS0FBSztBQUFBO0FBQUEsTUFGM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRTZDO0FBQUEsSUFHOUNDLG9CQUFvQmQsa0JBQWtCZ0MsV0FBVyxLQUNoRDtBQUFBLE1BQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBQ0MsVUFBVXRDLFVBQVU4RixLQUFLLENBQUFDLE1BQUtBLEdBQUc5QixPQUFPM0QsbUJBQW1CLENBQUMsQ0FBQztBQUFBLFFBQzdELFVBQVVOLFVBQVU4RixLQUFLLENBQUFDLE1BQUtBLEdBQUc5QixPQUFPM0QsbUJBQW1CLENBQUMsQ0FBQztBQUFBLFFBQzdELFNBQVMsQ0FBQzBGLGtCQUFrQjtBQUMxQixnQkFBTXBCLGtCQUFrQjVFLFVBQVV3RCxPQUFPLENBQUF1QyxNQUFLLENBQUN6RixrQkFBa0I2QyxTQUFTNEMsR0FBRzlCLEVBQUUsQ0FBQztBQUNoRmhFLHNCQUFZLENBQUMsR0FBRzJFLGlCQUFpQm9CLGFBQWEsQ0FBQztBQUMvQzNGLDZCQUFtQjJGLGFBQWE7QUFDaEN6Riw4QkFBb0IsRUFBRTtBQUN0QmMsOEJBQW9CLEtBQUs7QUFBQSxRQUMzQjtBQUFBLFFBQ0EsU0FBUyxNQUFNQSxvQkFBb0IsS0FBSztBQUFBO0FBQUEsTUFWMUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBVTRDO0FBQUEsT0FqUWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvUUE7QUFFSjtBQUFFdkIsR0FyZ0JJRCxtQkFBaUI7QUFBQSxVQUNKRCxPQUFPO0FBQUE7QUFBQXFHLEtBRHBCcEc7QUF1Z0JOLGVBQWVBO0FBQWtCLElBQUFvRztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJJY29uIiwiSGVhZGVyIiwiQnJlYWRjcnVtYiIsIkNvbnRhY3RMaXN0IiwiQ29udGFjdERldGFpbCIsIkNvbnRhY3RGb3JtIiwiSW1wb3J0Q29udGFjdHNNb2RhbCIsIkV4cG9ydENvbnRhY3RzTW9kYWwiLCJNZXJnZUR1cGxpY2F0ZXNNb2RhbCIsIkZpbHRlclBhbmVsIiwiY29udGFjdHNTZXJ2aWNlIiwidXNlQXV0aCIsIkNvbnRhY3RNYW5hZ2VtZW50IiwiX3MiLCJ1c2VyIiwiY29udGFjdHMiLCJzZXRDb250YWN0cyIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwic2VsZWN0ZWRDb250YWN0Iiwic2V0U2VsZWN0ZWRDb250YWN0Iiwic2VsZWN0ZWRDb250YWN0cyIsInNldFNlbGVjdGVkQ29udGFjdHMiLCJzZWFyY2hRdWVyeSIsInNldFNlYXJjaFF1ZXJ5IiwiaXNGaWx0ZXJQYW5lbE9wZW4iLCJzZXRJc0ZpbHRlclBhbmVsT3BlbiIsImlzQWRkaW5nQ29udGFjdCIsInNldElzQWRkaW5nQ29udGFjdCIsImlzRWRpdGluZ0NvbnRhY3QiLCJzZXRJc0VkaXRpbmdDb250YWN0IiwiaXNJbXBvcnRNb2RhbE9wZW4iLCJzZXRJc0ltcG9ydE1vZGFsT3BlbiIsImlzRXhwb3J0TW9kYWxPcGVuIiwic2V0SXNFeHBvcnRNb2RhbE9wZW4iLCJpc01lcmdlTW9kYWxPcGVuIiwic2V0SXNNZXJnZU1vZGFsT3BlbiIsImFjdGl2ZVRhYiIsInNldEFjdGl2ZVRhYiIsImVycm9yIiwic2V0RXJyb3IiLCJzdWNjZXNzIiwic2V0U3VjY2VzcyIsImZpbHRlcnMiLCJzZXRGaWx0ZXJzIiwiY29tcGFueSIsImRlYWxTdGFnZSIsImxhc3RDb250YWN0RGF0ZSIsInRhZ3MiLCJsb2FkQ29udGFjdHMiLCJjb250YWN0c0RhdGEiLCJzZWFyY2hDb250YWN0cyIsImZpbHRlclBhcmFtcyIsImxlbmd0aCIsImNvbXBhbmllcyIsImRlYWxTdGFnZXMiLCJkYXRlUmFuZ2UiLCJPYmplY3QiLCJrZXlzIiwiZmlsdGVyQ29udGFjdHMiLCJnZXRVc2VyQ29udGFjdHMiLCJ3aW5kb3ciLCJpbm5lcldpZHRoIiwiZXJyIiwiY29uc29sZSIsIm1lc3NhZ2UiLCJpbmNsdWRlcyIsInRpbWVyIiwic2V0VGltZW91dCIsImNsZWFyVGltZW91dCIsImZpbHRlcmVkQ29udGFjdHMiLCJmaWx0ZXIiLCJjb250YWN0Iiwic3RhdHVzIiwiaGFuZGxlQ29udGFjdFNlbGVjdCIsImxvZyIsImhhbmRsZUNvbnRhY3RNdWx0aVNlbGVjdCIsImNvbnRhY3RJZCIsInByZXYiLCJuZXdTZWxlY3RlZCIsImlkIiwiaGFuZGxlU2VsZWN0QWxsIiwibWFwIiwiaGFuZGxlQWRkQ29udGFjdCIsImhhbmRsZUVkaXRDb250YWN0IiwiaGFuZGxlU2F2ZUNvbnRhY3QiLCJjb250YWN0RGF0YSIsInJlc3VsdCIsImhhbmRsZUNhbmNlbEZvcm0iLCJoYW5kbGVEZWxldGVDb250YWN0IiwiZGVsZXRlQ29udGFjdCIsInVwZGF0ZWRDb250YWN0cyIsImhhbmRsZUJ1bGtEZWxldGUiLCJkZWxldGVDb250YWN0cyIsImhhbmRsZUNvbnRhY3RVcGRhdGUiLCJ1cGRhdGVkQ29udGFjdCIsImhhbmRsZUltcG9ydENvbnRhY3RzIiwiaW1wb3J0ZWRDb250YWN0cyIsImltcG9ydENvbnRhY3RzIiwidmFsdWVzIiwic29tZSIsImYiLCJBcnJheSIsImlzQXJyYXkiLCJyZWR1Y2UiLCJjb3VudCIsImUiLCJ0YXJnZXQiLCJ2YWx1ZSIsImZpbmQiLCJjIiwibWVyZ2VkQ29udGFjdCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiaW5kZXguanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xyXG5cclxuaW1wb3J0IEljb24gZnJvbSAnY29tcG9uZW50cy9BcHBJY29uJztcclxuXHJcbmltcG9ydCBIZWFkZXIgZnJvbSAnY29tcG9uZW50cy91aS9IZWFkZXInO1xyXG5pbXBvcnQgQnJlYWRjcnVtYiBmcm9tICdjb21wb25lbnRzL3VpL0JyZWFkY3J1bWInO1xyXG5pbXBvcnQgQ29udGFjdExpc3QgZnJvbSAnLi9jb21wb25lbnRzL0NvbnRhY3RMaXN0JztcclxuaW1wb3J0IENvbnRhY3REZXRhaWwgZnJvbSAnLi9jb21wb25lbnRzL0NvbnRhY3REZXRhaWwnO1xyXG5pbXBvcnQgQ29udGFjdEZvcm0gZnJvbSAnLi9jb21wb25lbnRzL0NvbnRhY3RGb3JtJztcclxuaW1wb3J0IEltcG9ydENvbnRhY3RzTW9kYWwgZnJvbSAnLi9jb21wb25lbnRzL0ltcG9ydENvbnRhY3RzTW9kYWwnO1xyXG5pbXBvcnQgRXhwb3J0Q29udGFjdHNNb2RhbCBmcm9tICcuL2NvbXBvbmVudHMvRXhwb3J0Q29udGFjdHNNb2RhbCc7XHJcbmltcG9ydCBNZXJnZUR1cGxpY2F0ZXNNb2RhbCBmcm9tICcuL2NvbXBvbmVudHMvTWVyZ2VEdXBsaWNhdGVzTW9kYWwnO1xyXG5pbXBvcnQgRmlsdGVyUGFuZWwgZnJvbSAnLi9jb21wb25lbnRzL0ZpbHRlclBhbmVsJztcclxuaW1wb3J0IGNvbnRhY3RzU2VydmljZSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9jb250YWN0c1NlcnZpY2UnO1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vLi4vY29udGV4dHMvQXV0aENvbnRleHQnO1xyXG5cclxuY29uc3QgQ29udGFjdE1hbmFnZW1lbnQgPSAoKSA9PiB7XHJcbiAgY29uc3QgeyB1c2VyIH0gPSB1c2VBdXRoKCk7XHJcbiAgY29uc3QgW2NvbnRhY3RzLCBzZXRDb250YWN0c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkQ29udGFjdCwgc2V0U2VsZWN0ZWRDb250YWN0XSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZENvbnRhY3RzLCBzZXRTZWxlY3RlZENvbnRhY3RzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2VhcmNoUXVlcnksIHNldFNlYXJjaFF1ZXJ5XSA9IHVzZVN0YXRlKCcnKTtcclxuICBjb25zdCBbaXNGaWx0ZXJQYW5lbE9wZW4sIHNldElzRmlsdGVyUGFuZWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbaXNBZGRpbmdDb250YWN0LCBzZXRJc0FkZGluZ0NvbnRhY3RdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtpc0VkaXRpbmdDb250YWN0LCBzZXRJc0VkaXRpbmdDb250YWN0XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbaXNJbXBvcnRNb2RhbE9wZW4sIHNldElzSW1wb3J0TW9kYWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbaXNFeHBvcnRNb2RhbE9wZW4sIHNldElzRXhwb3J0TW9kYWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbaXNNZXJnZU1vZGFsT3Blbiwgc2V0SXNNZXJnZU1vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2FjdGl2ZVRhYiwgc2V0QWN0aXZlVGFiXSA9IHVzZVN0YXRlKCdhbGwnKTtcclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKTtcclxuICBjb25zdCBbc3VjY2Vzcywgc2V0U3VjY2Vzc10gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW2ZpbHRlcnMsIHNldEZpbHRlcnNdID0gdXNlU3RhdGUoe1xyXG4gICAgY29tcGFueTogW10sXHJcbiAgICBkZWFsU3RhZ2U6IFtdLFxyXG4gICAgbGFzdENvbnRhY3REYXRlOiBudWxsLFxyXG4gICAgdGFnczogW11cclxuICB9KTtcclxuXHJcbiAgLy8gTG9hZCBjb250YWN0cyBkYXRhIGZyb20gU3VwYWJhc2VcclxuICBjb25zdCBsb2FkQ29udGFjdHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4gICAgICBzZXRFcnJvcignJyk7XHJcbiAgICAgIFxyXG4gICAgICBsZXQgY29udGFjdHNEYXRhID0gW107XHJcbiAgICAgIGlmIChzZWFyY2hRdWVyeSkge1xyXG4gICAgICAgIGNvbnRhY3RzRGF0YSA9IGF3YWl0IGNvbnRhY3RzU2VydmljZT8uc2VhcmNoQ29udGFjdHMoc2VhcmNoUXVlcnkpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGNvbnN0IGZpbHRlclBhcmFtcyA9IHt9O1xyXG4gICAgICAgIFxyXG4gICAgICAgIGlmIChmaWx0ZXJzPy5jb21wYW55Py5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICBmaWx0ZXJQYXJhbXMuY29tcGFuaWVzID0gZmlsdGVycz8uY29tcGFueTtcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgICAgaWYgKGZpbHRlcnM/LmRlYWxTdGFnZT8ubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgZmlsdGVyUGFyYW1zLmRlYWxTdGFnZXMgPSBmaWx0ZXJzPy5kZWFsU3RhZ2U7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgICAgIGlmIChmaWx0ZXJzPy50YWdzPy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICBmaWx0ZXJQYXJhbXMudGFncyA9IGZpbHRlcnM/LnRhZ3M7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgICAgIGlmIChmaWx0ZXJzPy5sYXN0Q29udGFjdERhdGUpIHtcclxuICAgICAgICAgIGZpbHRlclBhcmFtcy5kYXRlUmFuZ2UgPSBmaWx0ZXJzPy5sYXN0Q29udGFjdERhdGU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgICAgIGlmIChPYmplY3Qua2V5cyhmaWx0ZXJQYXJhbXMpPy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICBjb250YWN0c0RhdGEgPSBhd2FpdCBjb250YWN0c1NlcnZpY2U/LmZpbHRlckNvbnRhY3RzKGZpbHRlclBhcmFtcyk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIGNvbnRhY3RzRGF0YSA9IGF3YWl0IGNvbnRhY3RzU2VydmljZT8uZ2V0VXNlckNvbnRhY3RzKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICBzZXRDb250YWN0cyhjb250YWN0c0RhdGEgfHwgW10pO1xyXG4gICAgICBcclxuICAgICAgLy8gU2V0IGZpcnN0IGNvbnRhY3QgYXMgc2VsZWN0ZWQgYnkgZGVmYXVsdCBmb3IgZGVza3RvcCB2aWV3XHJcbiAgICAgIGlmIChjb250YWN0c0RhdGE/Lmxlbmd0aCA+IDAgJiYgd2luZG93LmlubmVyV2lkdGggPj0gMTAyNCAmJiAhc2VsZWN0ZWRDb250YWN0KSB7XHJcbiAgICAgICAgc2V0U2VsZWN0ZWRDb250YWN0KGNvbnRhY3RzRGF0YT8uWzBdKTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGxvYWRpbmcgY29udGFjdHM6JywgZXJyKTtcclxuICAgICAgaWYgKGVycj8ubWVzc2FnZT8uaW5jbHVkZXMoJ0ZhaWxlZCB0byBmZXRjaCcpIHx8IFxyXG4gICAgICAgICAgZXJyPy5tZXNzYWdlPy5pbmNsdWRlcygnTmV0d29ya0Vycm9yJykpIHtcclxuICAgICAgICBzZXRFcnJvcignQ2Fubm90IGNvbm5lY3QgdG8gZGF0YWJhc2UuIFlvdXIgU3VwYWJhc2UgcHJvamVjdCBtYXkgYmUgcGF1c2VkIG9yIGluYWN0aXZlLiBQbGVhc2UgY2hlY2sgeW91ciBTdXBhYmFzZSBkYXNoYm9hcmQgYW5kIHJlc3VtZSB5b3VyIHByb2plY3QgaWYgbmVlZGVkLicpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldEVycm9yKCdGYWlsZWQgdG8gbG9hZCBjb250YWN0cy4gUGxlYXNlIHRyeSBhZ2Fpbi4nKTtcclxuICAgICAgfVxyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmICh1c2VyKSB7XHJcbiAgICAgIGxvYWRDb250YWN0cygpO1xyXG4gICAgfVxyXG4gIH0sIFt1c2VyLCBzZWFyY2hRdWVyeSwgZmlsdGVycywgYWN0aXZlVGFiXSk7XHJcblxyXG4gIC8vIEF1dG8tY2xlYXIgbWVzc2FnZXNcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKGVycm9yIHx8IHN1Y2Nlc3MpIHtcclxuICAgICAgY29uc3QgdGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICBzZXRFcnJvcignJyk7XHJcbiAgICAgICAgc2V0U3VjY2VzcygnJyk7XHJcbiAgICAgIH0sIDUwMDApO1xyXG4gICAgICByZXR1cm4gKCkgPT4gY2xlYXJUaW1lb3V0KHRpbWVyKTtcclxuICAgIH1cclxuICB9LCBbZXJyb3IsIHN1Y2Nlc3NdKTtcclxuXHJcbiAgLy8gRmlsdGVyIGNvbnRhY3RzIGJhc2VkIG9uIGFjdGl2ZSB0YWJcclxuICBjb25zdCBmaWx0ZXJlZENvbnRhY3RzID0gY29udGFjdHM/LmZpbHRlcihjb250YWN0ID0+IHtcclxuICAgIC8vIEZpbHRlciBieSBhY3RpdmUgdGFiXHJcbiAgICBpZiAoYWN0aXZlVGFiID09PSAnYWN0aXZlJykge1xyXG4gICAgICByZXR1cm4gY29udGFjdD8uc3RhdHVzID09PSAnYWN0aXZlJztcclxuICAgIH0gZWxzZSBpZiAoYWN0aXZlVGFiID09PSAnaW5hY3RpdmUnKSB7XHJcbiAgICAgIHJldHVybiBjb250YWN0Py5zdGF0dXMgPT09ICdpbmFjdGl2ZSc7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gdHJ1ZTsgLy8gJ2FsbCcgdGFiXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNvbnRhY3RTZWxlY3QgPSAoY29udGFjdCkgPT4ge1xyXG4gICAgXHJcbiAgICBjb25zb2xlLmxvZygnaGFuZGxlQ29udGFjdFNlbGVjdCBjYWxsZWQgd2l0aDonLCBjb250YWN0KTtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldFNlbGVjdGVkQ29udGFjdChjb250YWN0KTtcclxuICAgICAgc2V0SXNBZGRpbmdDb250YWN0KGZhbHNlKTtcclxuICAgICAgc2V0SXNFZGl0aW5nQ29udGFjdChmYWxzZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBpbiBoYW5kbGVDb250YWN0U2VsZWN0OicsIGVycm9yKTtcclxuICAgICAgc2V0RXJyb3IoJ1NvbWV0aGluZyB3ZW50IHdyb25nIHdoaWxlIHNlbGVjdGluZyB0aGUgY29udGFjdC4gUGxlYXNlIHRyeSBhZ2Fpbi4nKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDb250YWN0TXVsdGlTZWxlY3QgPSAoY29udGFjdElkKSA9PiB7XHJcbiAgICBjb25zb2xlLmxvZygnaGFuZGxlQ29udGFjdE11bHRpU2VsZWN0IGNhbGxlZCB3aXRoOicsIGNvbnRhY3RJZCk7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRTZWxlY3RlZENvbnRhY3RzKHByZXYgPT4ge1xyXG4gICAgICAgIGNvbnN0IG5ld1NlbGVjdGVkID0gcHJldj8uaW5jbHVkZXMoY29udGFjdElkKSBcclxuICAgICAgICAgID8gcHJldj8uZmlsdGVyKGlkID0+IGlkICE9PSBjb250YWN0SWQpXHJcbiAgICAgICAgICA6IFsuLi4ocHJldiB8fCBbXSksIGNvbnRhY3RJZF07XHJcbiAgICAgICAgY29uc29sZS5sb2coJ1VwZGF0ZWQgc2VsZWN0ZWRDb250YWN0czonLCBuZXdTZWxlY3RlZCk7XHJcbiAgICAgICAgcmV0dXJuIG5ld1NlbGVjdGVkO1xyXG4gICAgICB9KTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGluIGhhbmRsZUNvbnRhY3RNdWx0aVNlbGVjdDonLCBlcnJvcik7XHJcbiAgICAgIHNldEVycm9yKCdTb21ldGhpbmcgd2VudCB3cm9uZyB3aGlsZSBzZWxlY3RpbmcgY29udGFjdHMuIFBsZWFzZSB0cnkgYWdhaW4uJyk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU2VsZWN0QWxsID0gKCkgPT4ge1xyXG4gICAgaWYgKHNlbGVjdGVkQ29udGFjdHM/Lmxlbmd0aCA9PT0gZmlsdGVyZWRDb250YWN0cz8ubGVuZ3RoKSB7XHJcbiAgICAgIHNldFNlbGVjdGVkQ29udGFjdHMoW10pO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0U2VsZWN0ZWRDb250YWN0cyhmaWx0ZXJlZENvbnRhY3RzPy5tYXAoY29udGFjdCA9PiBjb250YWN0Py5pZCkpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUFkZENvbnRhY3QgPSAoKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZENvbnRhY3QobnVsbCk7XHJcbiAgICBzZXRJc0FkZGluZ0NvbnRhY3QodHJ1ZSk7XHJcbiAgICBzZXRJc0VkaXRpbmdDb250YWN0KGZhbHNlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVFZGl0Q29udGFjdCA9ICgpID0+IHtcclxuICAgIHNldElzQWRkaW5nQ29udGFjdChmYWxzZSk7XHJcbiAgICBzZXRJc0VkaXRpbmdDb250YWN0KHRydWUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVNhdmVDb250YWN0ID0gYXN5bmMgKGNvbnRhY3REYXRhKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRFcnJvcignJyk7XHJcbiAgICAgIGxldCByZXN1bHQ7XHJcbiAgICAgIFxyXG4gICAgICBpZiAoaXNBZGRpbmdDb250YWN0KSB7XHJcbiAgICAgICAgcmVzdWx0ID0gY29udGFjdERhdGE7XHJcbiAgICAgICAgc2V0U3VjY2VzcygnQ29udGFjdCBjcmVhdGVkIHN1Y2Nlc3NmdWxseSEnKTtcclxuICAgICAgfSBlbHNlIGlmIChpc0VkaXRpbmdDb250YWN0ICYmIHNlbGVjdGVkQ29udGFjdCkge1xyXG4gICAgICAgIHJlc3VsdCA9IGNvbnRhY3REYXRhO1xyXG4gICAgICAgIHNldFN1Y2Nlc3MoJ0NvbnRhY3QgdXBkYXRlZCBzdWNjZXNzZnVsbHkhJyk7XHJcbiAgICAgIH1cclxuICAgICAgXHJcbiAgICAgIHNldFNlbGVjdGVkQ29udGFjdChyZXN1bHQpO1xyXG4gICAgICBzZXRJc0FkZGluZ0NvbnRhY3QoZmFsc2UpO1xyXG4gICAgICBzZXRJc0VkaXRpbmdDb250YWN0KGZhbHNlKTtcclxuICAgICAgXHJcbiAgICAgIC8vIFJlZnJlc2ggY29udGFjdHMgbGlzdFxyXG4gICAgICBsb2FkQ29udGFjdHMoKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBzYXZpbmcgY29udGFjdDonLCBlcnIpO1xyXG4gICAgICBzZXRFcnJvcignRmFpbGVkIHRvIHNhdmUgY29udGFjdC4gUGxlYXNlIHRyeSBhZ2Fpbi4nKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDYW5jZWxGb3JtID0gKCkgPT4ge1xyXG4gICAgc2V0SXNBZGRpbmdDb250YWN0KGZhbHNlKTtcclxuICAgIHNldElzRWRpdGluZ0NvbnRhY3QoZmFsc2UpO1xyXG4gICAgaWYgKHNlbGVjdGVkQ29udGFjdCA9PT0gbnVsbCAmJiBjb250YWN0cz8ubGVuZ3RoID4gMCkge1xyXG4gICAgICBzZXRTZWxlY3RlZENvbnRhY3QoY29udGFjdHM/LlswXSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlQ29udGFjdCA9IGFzeW5jIChjb250YWN0SWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldEVycm9yKCcnKTtcclxuICAgICAgYXdhaXQgY29udGFjdHNTZXJ2aWNlPy5kZWxldGVDb250YWN0KGNvbnRhY3RJZCk7XHJcbiAgICAgIHNldFN1Y2Nlc3MoJ0NvbnRhY3QgZGVsZXRlZCBzdWNjZXNzZnVsbHkhJyk7XHJcbiAgICAgIFxyXG4gICAgICAvLyBVcGRhdGUgbG9jYWwgc3RhdGVcclxuICAgICAgY29uc3QgdXBkYXRlZENvbnRhY3RzID0gY29udGFjdHM/LmZpbHRlcihjb250YWN0ID0+IGNvbnRhY3Q/LmlkICE9PSBjb250YWN0SWQpO1xyXG4gICAgICBzZXRDb250YWN0cyh1cGRhdGVkQ29udGFjdHMpO1xyXG4gICAgICBcclxuICAgICAgaWYgKHNlbGVjdGVkQ29udGFjdCAmJiBzZWxlY3RlZENvbnRhY3Q/LmlkID09PSBjb250YWN0SWQpIHtcclxuICAgICAgICBzZXRTZWxlY3RlZENvbnRhY3QodXBkYXRlZENvbnRhY3RzPy5sZW5ndGggPiAwID8gdXBkYXRlZENvbnRhY3RzPy5bMF0gOiBudWxsKTtcclxuICAgICAgfVxyXG4gICAgICBcclxuICAgICAgc2V0U2VsZWN0ZWRDb250YWN0cyhwcmV2ID0+IHByZXY/LmZpbHRlcihpZCA9PiBpZCAhPT0gY29udGFjdElkKSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgZGVsZXRpbmcgY29udGFjdDonLCBlcnIpO1xyXG4gICAgICBzZXRFcnJvcignRmFpbGVkIHRvIGRlbGV0ZSBjb250YWN0LiBQbGVhc2UgdHJ5IGFnYWluLicpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUJ1bGtEZWxldGUgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRFcnJvcignJyk7XHJcbiAgICAgIGF3YWl0IGNvbnRhY3RzU2VydmljZT8uZGVsZXRlQ29udGFjdHMoc2VsZWN0ZWRDb250YWN0cyk7XHJcbiAgICAgIHNldFN1Y2Nlc3MoYCR7c2VsZWN0ZWRDb250YWN0cz8ubGVuZ3RofSBjb250YWN0KHMpIGRlbGV0ZWQgc3VjY2Vzc2Z1bGx5IWApO1xyXG4gICAgICBcclxuICAgICAgLy8gVXBkYXRlIGxvY2FsIHN0YXRlXHJcbiAgICAgIGNvbnN0IHVwZGF0ZWRDb250YWN0cyA9IGNvbnRhY3RzPy5maWx0ZXIoY29udGFjdCA9PiAhc2VsZWN0ZWRDb250YWN0cz8uaW5jbHVkZXMoY29udGFjdD8uaWQpKTtcclxuICAgICAgc2V0Q29udGFjdHModXBkYXRlZENvbnRhY3RzKTtcclxuICAgICAgXHJcbiAgICAgIGlmIChzZWxlY3RlZENvbnRhY3QgJiYgc2VsZWN0ZWRDb250YWN0cz8uaW5jbHVkZXMoc2VsZWN0ZWRDb250YWN0Py5pZCkpIHtcclxuICAgICAgICBzZXRTZWxlY3RlZENvbnRhY3QodXBkYXRlZENvbnRhY3RzPy5sZW5ndGggPiAwID8gdXBkYXRlZENvbnRhY3RzPy5bMF0gOiBudWxsKTtcclxuICAgICAgfVxyXG4gICAgICBcclxuICAgICAgc2V0U2VsZWN0ZWRDb250YWN0cyhbXSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgZGVsZXRpbmcgY29udGFjdHM6JywgZXJyKTtcclxuICAgICAgc2V0RXJyb3IoJ0ZhaWxlZCB0byBkZWxldGUgY29udGFjdHMuIFBsZWFzZSB0cnkgYWdhaW4uJyk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ29udGFjdFVwZGF0ZSA9ICh1cGRhdGVkQ29udGFjdCkgPT4ge1xyXG4gICAgLy8gVXBkYXRlIHRoZSBjb250YWN0IGluIHRoZSBtYWluIGNvbnRhY3RzIGxpc3RcclxuICAgIGNvbnN0IHVwZGF0ZWRDb250YWN0cyA9IGNvbnRhY3RzLm1hcChjb250YWN0ID0+IFxyXG4gICAgICBjb250YWN0LmlkID09PSB1cGRhdGVkQ29udGFjdC5pZCA/IHVwZGF0ZWRDb250YWN0IDogY29udGFjdFxyXG4gICAgKTtcclxuICAgIHNldENvbnRhY3RzKHVwZGF0ZWRDb250YWN0cyk7XHJcbiAgICBcclxuICAgIC8vIFVwZGF0ZSB0aGUgc2VsZWN0ZWQgY29udGFjdCBpZiBpdCdzIHRoZSBzYW1lIG9uZVxyXG4gICAgaWYgKHNlbGVjdGVkQ29udGFjdCAmJiBzZWxlY3RlZENvbnRhY3QuaWQgPT09IHVwZGF0ZWRDb250YWN0LmlkKSB7XHJcbiAgICAgIHNldFNlbGVjdGVkQ29udGFjdCh1cGRhdGVkQ29udGFjdCk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlSW1wb3J0Q29udGFjdHMgPSBhc3luYyAoaW1wb3J0ZWRDb250YWN0cykgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0RXJyb3IoJycpO1xyXG4gICAgICBhd2FpdCBjb250YWN0c1NlcnZpY2U/LmltcG9ydENvbnRhY3RzKGltcG9ydGVkQ29udGFjdHMpO1xyXG4gICAgICBzZXRTdWNjZXNzKGAke2ltcG9ydGVkQ29udGFjdHM/Lmxlbmd0aH0gY29udGFjdChzKSBpbXBvcnRlZCBzdWNjZXNzZnVsbHkhYCk7XHJcbiAgICAgIHNldElzSW1wb3J0TW9kYWxPcGVuKGZhbHNlKTtcclxuICAgICAgbG9hZENvbnRhY3RzKCk7IC8vIFJlZnJlc2ggdGhlIGxpc3RcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBpbXBvcnRpbmcgY29udGFjdHM6JywgZXJyKTtcclxuICAgICAgc2V0RXJyb3IoJ0ZhaWxlZCB0byBpbXBvcnQgY29udGFjdHMuIFBsZWFzZSB0cnkgYWdhaW4uJyk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGJnLWJhY2tncm91bmRcIj5cclxuICAgICAgPEhlYWRlciAvPlxyXG4gICAgICA8bWFpbiBjbGFzc05hbWU9XCJwdC0xNlwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS04XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LTd4bCBteC1hdXRvXCI+XHJcbiAgICAgICAgICAgIDxCcmVhZGNydW1iIC8+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbWQ6ZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLXN0YXJ0IG1kOml0ZW1zLWNlbnRlciBtYi02XCI+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBtZDp0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC10ZXh0LXByaW1hcnlcIj5Db250YWN0IE1hbmFnZW1lbnQ8L2gxPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC10ZXh0LXNlY29uZGFyeSBtdC0xXCI+TWFuYWdlIHlvdXIgY3VzdG9tZXIgcmVsYXRpb25zaGlwcyBhbmQgY29tbXVuaWNhdGlvbiBoaXN0b3J5PC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTMgbXQtNCBtZDptdC0wXCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIFxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVBZGRDb250YWN0fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidG4tcHJpbWFyeSBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIlVzZXJQbHVzXCIgc2l6ZT17MTh9IC8+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuPkFkZCBDb250YWN0PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIDxidXR0b24gXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzSW1wb3J0TW9kYWxPcGVuKHRydWUpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yIHB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLWxnIHRleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC10ZXh0LXByaW1hcnkgaG92ZXI6Ymctc3VyZmFjZS1ob3ZlciB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0xNTAgZWFzZS1vdXRcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiVXBsb2FkXCIgc2l6ZT17MTh9IC8+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuPkltcG9ydDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIFxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc0ZpbHRlclBhbmVsT3BlbighaXNGaWx0ZXJQYW5lbE9wZW4pfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yIHB4LTQgcHktMiBib3JkZXIgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0xNTAgZWFzZS1vdXQgJHtcclxuICAgICAgICAgICAgICAgICAgICBPYmplY3QudmFsdWVzKGZpbHRlcnMpPy5zb21lKGYgPT4gQXJyYXkuaXNBcnJheShmKSA/IGY/Lmxlbmd0aCA+IDAgOiBmICE9PSBudWxsKSB8fCBpc0ZpbHRlclBhbmVsT3BlblxyXG4gICAgICAgICAgICAgICAgICAgICAgPyAnYm9yZGVyLXByaW1hcnktNTAwIGJnLXByaW1hcnktNTAgdGV4dC1wcmltYXJ5JyA6J2JvcmRlci1ib3JkZXIgdGV4dC10ZXh0LXNlY29uZGFyeSBob3Zlcjp0ZXh0LXRleHQtcHJpbWFyeSBob3ZlcjpiZy1zdXJmYWNlLWhvdmVyJ1xyXG4gICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIkZpbHRlclwiIHNpemU9ezE4fSAvPlxyXG4gICAgICAgICAgICAgICAgICA8c3Bhbj5GaWx0ZXI8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIHtPYmplY3QudmFsdWVzKGZpbHRlcnMpPy5zb21lKGYgPT4gQXJyYXkuaXNBcnJheShmKSA/IGY/Lmxlbmd0aCA+IDAgOiBmICE9PSBudWxsKSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy01IGgtNSBiZy1wcmltYXJ5IHRleHQtd2hpdGUgdGV4dC14cyByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtPYmplY3QudmFsdWVzKGZpbHRlcnMpPy5yZWR1Y2UoKGNvdW50LCBmKSA9PiBjb3VudCArIChBcnJheS5pc0FycmF5KGYpID8gZj8ubGVuZ3RoIDogKGYgIT09IG51bGwgPyAxIDogMCkpLCAwKX1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB7LyogU3VjY2Vzcy9FcnJvciBNZXNzYWdlcyAqL31cclxuICAgICAgICAgICAge3N1Y2Nlc3MgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc3VjY2Vzcy01MCBib3JkZXIgYm9yZGVyLXN1Y2Nlc3MtMjAwIHRleHQtc3VjY2VzcyBwLTQgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTIgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIkNoZWNrQ2lyY2xlXCIgc2l6ZT17MjB9IC8+XHJcbiAgICAgICAgICAgICAgICA8c3Bhbj57c3VjY2Vzc308L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFN1Y2Nlc3MoJycpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtbC1hdXRvIHRleHQtc3VjY2VzcyBob3Zlcjp0ZXh0LXN1Y2Nlc3MtNjAwXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIlhcIiBzaXplPXsxNn0gLz5cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgICB7ZXJyb3IgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZXJyb3ItNTAgYm9yZGVyIGJvcmRlci1lcnJvci0yMDAgdGV4dC1lcnJvciBwLTQgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTIgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIkFsZXJ0Q2lyY2xlXCIgc2l6ZT17MjB9IC8+XHJcbiAgICAgICAgICAgICAgICA8c3Bhbj57ZXJyb3J9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRFcnJvcignJyl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1sLWF1dG8gdGV4dC1lcnJvciBob3Zlcjp0ZXh0LWVycm9yLTYwMFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJYXCIgc2l6ZT17MTZ9IC8+XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIHsvKiBGaWx0ZXIgUGFuZWwgKi99XHJcbiAgICAgICAgICAgIHtpc0ZpbHRlclBhbmVsT3BlbiAmJiAoXHJcbiAgICAgICAgICAgICAgPEZpbHRlclBhbmVsIFxyXG4gICAgICAgICAgICAgICAgZmlsdGVycz17ZmlsdGVyc30gXHJcbiAgICAgICAgICAgICAgICBzZXRGaWx0ZXJzPXtzZXRGaWx0ZXJzfSBcclxuICAgICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldElzRmlsdGVyUGFuZWxPcGVuKGZhbHNlKX0gXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIHsvKiBTZWFyY2ggYW5kIFRhYnMgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC15LTAgbGVmdC0wIHBsLTMgZmxleCBpdGVtcy1jZW50ZXIgcG9pbnRlci1ldmVudHMtbm9uZVwiPlxyXG4gICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiU2VhcmNoXCIgc2l6ZT17MTh9IGNsYXNzTmFtZT1cInRleHQtdGV4dC10ZXJ0aWFyeVwiIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIGNvbnRhY3RzIGJ5IG5hbWUsIGVtYWlsLCBvciBjb21wYW55Li4uXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlYXJjaFF1ZXJ5fVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlYXJjaFF1ZXJ5KGU/LnRhcmdldD8udmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbnB1dC1maWVsZCBwbC0xMFwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBib3JkZXItYiBib3JkZXItYm9yZGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYignYWxsJyl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTQgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtICR7XHJcbiAgICAgICAgICAgICAgICAgICAgYWN0aXZlVGFiID09PSAnYWxsJyA/J3RleHQtcHJpbWFyeSBib3JkZXItYi0yIGJvcmRlci1wcmltYXJ5JyA6J3RleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC10ZXh0LXByaW1hcnknXHJcbiAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBBbGwgQ29udGFjdHNcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoJ2FjdGl2ZScpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC00IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSAke1xyXG4gICAgICAgICAgICAgICAgICAgIGFjdGl2ZVRhYiA9PT0gJ2FjdGl2ZScgPyd0ZXh0LXByaW1hcnkgYm9yZGVyLWItMiBib3JkZXItcHJpbWFyeScgOid0ZXh0LXRleHQtc2Vjb25kYXJ5IGhvdmVyOnRleHQtdGV4dC1wcmltYXJ5J1xyXG4gICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQWN0aXZlXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKCdpbmFjdGl2ZScpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC00IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSAke1xyXG4gICAgICAgICAgICAgICAgICAgIGFjdGl2ZVRhYiA9PT0gJ2luYWN0aXZlJyA/J3RleHQtcHJpbWFyeSBib3JkZXItYi0yIGJvcmRlci1wcmltYXJ5JyA6J3RleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC10ZXh0LXByaW1hcnknXHJcbiAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBJbmFjdGl2ZVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgey8qIExvYWRpbmcgU3RhdGUgKi99XHJcbiAgICAgICAgICAgIHtsb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcHktMTJcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluIHJvdW5kZWQtZnVsbCBoLTggdy04IGJvcmRlci1iLTIgYm9yZGVyLXByaW1hcnlcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC10ZXh0LXNlY29uZGFyeVwiPkxvYWRpbmcgY29udGFjdHMuLi48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAvKiBNYWluIENvbnRlbnQgQXJlYSAqL1xyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBsZzpmbGV4LXJvdyBnYXAtNlwiPlxyXG4gICAgICAgICAgICAgICAgey8qIENvbnRhY3QgTGlzdCAoTGVmdCBQYW5lbCkgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBsZzp3LTEvMyB4bDp3LTEvNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXN1cmZhY2Ugcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWJvcmRlciBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgICAgICB7LyogTGlzdCBIZWFkZXIgd2l0aCBBY3Rpb25zICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJvcmRlci1iIGJvcmRlci1ib3JkZXIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17c2VsZWN0ZWRDb250YWN0cz8ubGVuZ3RoID09PSBmaWx0ZXJlZENvbnRhY3RzPy5sZW5ndGggJiYgZmlsdGVyZWRDb250YWN0cz8ubGVuZ3RoID4gMH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlU2VsZWN0QWxsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1wcmltYXJ5IGJvcmRlci1ib3JkZXIgcm91bmRlZCBmb2N1czpyaW5nLXByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC10ZXh0LXNlY29uZGFyeVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZENvbnRhY3RzPy5sZW5ndGggPiAwID8gYCR7c2VsZWN0ZWRDb250YWN0cz8ubGVuZ3RofSBzZWxlY3RlZGAgOiBgJHtmaWx0ZXJlZENvbnRhY3RzPy5sZW5ndGh9IGNvbnRhY3RzYH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZENvbnRhY3RzPy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHNwYWNlLXgtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzRXhwb3J0TW9kYWxPcGVuKHRydWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC10ZXh0LXNlY29uZGFyeSBob3Zlcjp0ZXh0LXRleHQtcHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkV4cG9ydCBTZWxlY3RlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIkRvd25sb2FkXCIgc2l6ZT17MTZ9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQnVsa0RlbGV0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZXJyb3IgaG92ZXI6dGV4dC1lcnJvci02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJEZWxldGUgU2VsZWN0ZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJUcmFzaDJcIiBzaXplPXsxNn0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRDb250YWN0cz8ubGVuZ3RoID09PSAyICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNNZXJnZU1vZGFsT3Blbih0cnVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC10ZXh0LXNlY29uZGFyeSBob3Zlcjp0ZXh0LXRleHQtcHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiTWVyZ2UgQ29udGFjdHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiR2l0TWVyZ2VcIiBzaXplPXsxNn0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICB7LyogQ29udGFjdCBMaXN0ICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxDb250YWN0TGlzdFxyXG4gICAgICAgICAgICAgICAgICAgICAgY29udGFjdHM9e2ZpbHRlcmVkQ29udGFjdHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZENvbnRhY3Q9e3NlbGVjdGVkQ29udGFjdH1cclxuICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkQ29udGFjdHM9e3NlbGVjdGVkQ29udGFjdHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNvbnRhY3RTZWxlY3Q9e2hhbmRsZUNvbnRhY3RTZWxlY3R9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNvbnRhY3RNdWx0aVNlbGVjdD17aGFuZGxlQ29udGFjdE11bHRpU2VsZWN0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25EZWxldGVDb250YWN0PXtoYW5kbGVEZWxldGVDb250YWN0fVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIHsvKiBDb250YWN0IERldGFpbCBvciBGb3JtIChSaWdodCBQYW5lbCkgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBsZzp3LTIvMyB4bDp3LTMvNFwiPlxyXG4gICAgICAgICAgICAgICAgICB7aXNBZGRpbmdDb250YWN0IHx8IGlzRWRpdGluZ0NvbnRhY3QgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPENvbnRhY3RGb3JtXHJcbiAgICAgICAgICAgICAgICAgICAgICBjb250YWN0PXtpc0VkaXRpbmdDb250YWN0ID8gc2VsZWN0ZWRDb250YWN0IDogbnVsbH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uU3VibWl0PXtoYW5kbGVTYXZlQ29udGFjdH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2FuY2VsPXtoYW5kbGVDYW5jZWxGb3JtfVxyXG4gICAgICAgICAgICAgICAgICAgICAgaXNFZGl0aW5nPXtpc0VkaXRpbmdDb250YWN0fVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICkgOiBzZWxlY3RlZENvbnRhY3QgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPENvbnRhY3REZXRhaWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnRhY3Q9e3NlbGVjdGVkQ29udGFjdH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uRWRpdD17aGFuZGxlRWRpdENvbnRhY3R9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkRlbGV0ZT17KCkgPT4gaGFuZGxlRGVsZXRlQ29udGFjdChzZWxlY3RlZENvbnRhY3Q/LmlkKX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ29udGFjdFVwZGF0ZT17aGFuZGxlQ29udGFjdFVwZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc3VyZmFjZSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItYm9yZGVyIHNoYWRvdy1zbSBwLTggdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xNiBoLTE2IGJnLXByaW1hcnktNTAgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG14LWF1dG8gbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiVXNlcnNcIiBzaXplPXsyNH0gY2xhc3NOYW1lPVwidGV4dC1wcmltYXJ5XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LXRleHQtcHJpbWFyeSBtYi0yXCI+Tm8gQ29udGFjdCBTZWxlY3RlZDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5IG1iLTZcIj5TZWxlY3QgYSBjb250YWN0IGZyb20gdGhlIGxpc3Qgb3IgYWRkIGEgbmV3IG9uZSB0byBnZXQgc3RhcnRlZC48L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUFkZENvbnRhY3R9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5IGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiVXNlclBsdXNcIiBzaXplPXsxOH0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+QWRkIE5ldyBDb250YWN0PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L21haW4+XHJcbiAgICAgIHsvKiBNb2RhbHMgKi99XHJcbiAgICAgIHtpc0ltcG9ydE1vZGFsT3BlbiAmJiAoXHJcbiAgICAgICAgPEltcG9ydENvbnRhY3RzTW9kYWxcclxuICAgICAgICAgIG9uSW1wb3J0PXtoYW5kbGVJbXBvcnRDb250YWN0c31cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldElzSW1wb3J0TW9kYWxPcGVuKGZhbHNlKX1cclxuICAgICAgICAvPlxyXG4gICAgICApfVxyXG4gICAgICB7aXNFeHBvcnRNb2RhbE9wZW4gJiYgKFxyXG4gICAgICAgIDxFeHBvcnRDb250YWN0c01vZGFsXHJcbiAgICAgICAgICBjb250YWN0cz17Y29udGFjdHM/LmZpbHRlcihjb250YWN0ID0+IHNlbGVjdGVkQ29udGFjdHM/LmluY2x1ZGVzKGNvbnRhY3Q/LmlkKSl9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRJc0V4cG9ydE1vZGFsT3BlbihmYWxzZSl9XHJcbiAgICAgICAgLz5cclxuICAgICAgKX1cclxuICAgICAge2lzTWVyZ2VNb2RhbE9wZW4gJiYgc2VsZWN0ZWRDb250YWN0cz8ubGVuZ3RoID09PSAyICYmIChcclxuICAgICAgICA8TWVyZ2VEdXBsaWNhdGVzTW9kYWxcclxuICAgICAgICAgIGNvbnRhY3QxPXtjb250YWN0cz8uZmluZChjID0+IGM/LmlkID09PSBzZWxlY3RlZENvbnRhY3RzPy5bMF0pfVxyXG4gICAgICAgICAgY29udGFjdDI9e2NvbnRhY3RzPy5maW5kKGMgPT4gYz8uaWQgPT09IHNlbGVjdGVkQ29udGFjdHM/LlsxXSl9XHJcbiAgICAgICAgICBvbk1lcmdlPXsobWVyZ2VkQ29udGFjdCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCB1cGRhdGVkQ29udGFjdHMgPSBjb250YWN0cz8uZmlsdGVyKGMgPT4gIXNlbGVjdGVkQ29udGFjdHM/LmluY2x1ZGVzKGM/LmlkKSk7XHJcbiAgICAgICAgICAgIHNldENvbnRhY3RzKFsuLi51cGRhdGVkQ29udGFjdHMsIG1lcmdlZENvbnRhY3RdKTtcclxuICAgICAgICAgICAgc2V0U2VsZWN0ZWRDb250YWN0KG1lcmdlZENvbnRhY3QpO1xyXG4gICAgICAgICAgICBzZXRTZWxlY3RlZENvbnRhY3RzKFtdKTtcclxuICAgICAgICAgICAgc2V0SXNNZXJnZU1vZGFsT3BlbihmYWxzZSk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0SXNNZXJnZU1vZGFsT3BlbihmYWxzZSl9XHJcbiAgICAgICAgLz5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDb250YWN0TWFuYWdlbWVudDsiXSwiZmlsZSI6IkQ6L2N1cnJlbnQgcHJvamVjdHMvY2xhdWRlLWNvZGUvc3JjL3BhZ2VzL2NvbnRhY3QtbWFuYWdlbWVudC9pbmRleC5qc3gifQ==