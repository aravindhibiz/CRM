import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/contact-management/components/FilterPanel.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/contact-management/components/FilterPanel.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import Icon from "/src/components/AppIcon.jsx";
const FilterPanel = ({ filters, setFilters, onClose }) => {
  _s();
  const [localFilters, setLocalFilters] = useState({ ...filters });
  const companies = [
    "Acme Corporation",
    "Globex Industries",
    "Soylent Corp",
    "Initech",
    "Umbrella Corporation",
    "Wayne Enterprises",
    "Stark Industries",
    "Cyberdyne Systems"
  ];
  const dealStages = [
    "discovery",
    "proposal",
    "negotiation",
    "closed-won",
    "closed-lost"
  ];
  const tags = [
    "enterprise",
    "mid-market",
    "small-business",
    "tech",
    "manufacturing",
    "healthcare",
    "finance",
    "marketing",
    "operations",
    "security",
    "decision-maker",
    "influencer",
    "procurement",
    "fast-growth",
    "innovation"
  ];
  const handleCompanyChange = (company) => {
    if (localFilters?.company?.includes(company)) {
      setLocalFilters({
        ...localFilters,
        company: localFilters?.company?.filter((c) => c !== company)
      });
    } else {
      setLocalFilters({
        ...localFilters,
        company: [...localFilters?.company, company]
      });
    }
  };
  const handleDealStageChange = (stage) => {
    if (localFilters?.dealStage?.includes(stage)) {
      setLocalFilters({
        ...localFilters,
        dealStage: localFilters?.dealStage?.filter((s) => s !== stage)
      });
    } else {
      setLocalFilters({
        ...localFilters,
        dealStage: [...localFilters?.dealStage, stage]
      });
    }
  };
  const handleTagChange = (tag) => {
    if (localFilters?.tags?.includes(tag)) {
      setLocalFilters({
        ...localFilters,
        tags: localFilters?.tags?.filter((t) => t !== tag)
      });
    } else {
      setLocalFilters({
        ...localFilters,
        tags: [...localFilters?.tags, tag]
      });
    }
  };
  const handleApplyFilters = () => {
    setFilters(localFilters);
    onClose();
  };
  const handleResetFilters = () => {
    const resetFilters = {
      company: [],
      dealStage: [],
      lastContactDate: null,
      tags: []
    };
    setLocalFilters(resetFilters);
    setFilters(resetFilters);
    onClose();
  };
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\FilterPanel.jsx:105:4", "data-component-path": "src\\pages\\contact-management\\components\\FilterPanel.jsx", "data-component-line": "105", "data-component-file": "FilterPanel.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20rounded-lg%20border%20border-border%20shadow-md%20mb-6%22%7D", className: "bg-surface rounded-lg border border-border shadow-md mb-6", children: [
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\FilterPanel.jsx:106:6", "data-component-path": "src\\pages\\contact-management\\components\\FilterPanel.jsx", "data-component-line": "106", "data-component-file": "FilterPanel.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22p-4%20border-b%20border-border%20flex%20justify-between%20items-center%22%7D", className: "p-4 border-b border-border flex justify-between items-center", children: [
      /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\contact-management\\components\\FilterPanel.jsx:107:8", "data-component-path": "src\\pages\\contact-management\\components\\FilterPanel.jsx", "data-component-line": "107", "data-component-file": "FilterPanel.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22font-medium%20text-text-primary%22%2C%22textContent%22%3A%22Filter%20Contacts%22%7D", className: "font-medium text-text-primary", children: "Filter Contacts" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/FilterPanel.jsx",
        lineNumber: 107,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          "data-component-id": "src\\pages\\contact-management\\components\\FilterPanel.jsx:108:8",
          "data-component-path": "src\\pages\\contact-management\\components\\FilterPanel.jsx",
          "data-component-line": "108",
          "data-component-file": "FilterPanel.jsx",
          "data-component-name": "button",
          "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22text-text-secondary%20hover%3Atext-text-primary%22%7D",
          onClick: onClose,
          className: "text-text-secondary hover:text-text-primary",
          children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\FilterPanel.jsx:112:10", "data-component-path": "src\\pages\\contact-management\\components\\FilterPanel.jsx", "data-component-line": "112", "data-component-file": "FilterPanel.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22X%22%7D", name: "X", size: 18 }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/FilterPanel.jsx",
            lineNumber: 112,
            columnNumber: 11
          }, this)
        },
        void 0,
        false,
        {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/FilterPanel.jsx",
          lineNumber: 108,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/FilterPanel.jsx",
      lineNumber: 106,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\FilterPanel.jsx:115:6", "data-component-path": "src\\pages\\contact-management\\components\\FilterPanel.jsx", "data-component-line": "115", "data-component-file": "FilterPanel.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22p-4%20grid%20grid-cols-1%20md%3Agrid-cols-3%20gap-6%22%7D", className: "p-4 grid grid-cols-1 md:grid-cols-3 gap-6", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\FilterPanel.jsx:117:8", "data-component-path": "src\\pages\\contact-management\\components\\FilterPanel.jsx", "data-component-line": "117", "data-component-file": "FilterPanel.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
        /* @__PURE__ */ jsxDEV("h4", { "data-component-id": "src\\pages\\contact-management\\components\\FilterPanel.jsx:118:10", "data-component-path": "src\\pages\\contact-management\\components\\FilterPanel.jsx", "data-component-line": "118", "data-component-file": "FilterPanel.jsx", "data-component-name": "h4", "data-component-content": "%7B%22elementName%22%3A%22h4%22%2C%22className%22%3A%22text-sm%20font-medium%20text-text-primary%20mb-2%22%2C%22textContent%22%3A%22Company%22%7D", className: "text-sm font-medium text-text-primary mb-2", children: "Company" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/FilterPanel.jsx",
          lineNumber: 118,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\FilterPanel.jsx:119:10", "data-component-path": "src\\pages\\contact-management\\components\\FilterPanel.jsx", "data-component-line": "119", "data-component-file": "FilterPanel.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-2%20max-h-48%20overflow-y-auto%22%7D", className: "space-y-2 max-h-48 overflow-y-auto", children: companies?.map(
          (company) => /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\FilterPanel.jsx:121:12", "data-component-path": "src\\pages\\contact-management\\components\\FilterPanel.jsx", "data-component-line": "121", "data-component-file": "FilterPanel.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22flex%20items-center%22%7D", className: "flex items-center", children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                "data-component-id": "src\\pages\\contact-management\\components\\FilterPanel.jsx:122:16",
                "data-component-path": "src\\pages\\contact-management\\components\\FilterPanel.jsx",
                "data-component-line": "122",
                "data-component-file": "FilterPanel.jsx",
                "data-component-name": "input",
                "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22checkbox%22%2C%22className%22%3A%22h-4%20w-4%20text-primary%20border-border%20rounded%20focus%3Aring-primary%22%7D",
                type: "checkbox",
                checked: localFilters?.company?.includes(company),
                onChange: () => handleCompanyChange(company),
                className: "h-4 w-4 text-primary border-border rounded focus:ring-primary"
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/FilterPanel.jsx",
                lineNumber: 122,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\FilterPanel.jsx:128:16", "data-component-path": "src\\pages\\contact-management\\components\\FilterPanel.jsx", "data-component-line": "128", "data-component-file": "FilterPanel.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22ml-2%20text-sm%20text-text-secondary%22%7D", className: "ml-2 text-sm text-text-secondary", children: company }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/FilterPanel.jsx",
              lineNumber: 128,
              columnNumber: 17
            }, this)
          ] }, company, true, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/FilterPanel.jsx",
            lineNumber: 121,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/FilterPanel.jsx",
          lineNumber: 119,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/FilterPanel.jsx",
        lineNumber: 117,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\FilterPanel.jsx:135:8", "data-component-path": "src\\pages\\contact-management\\components\\FilterPanel.jsx", "data-component-line": "135", "data-component-file": "FilterPanel.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
        /* @__PURE__ */ jsxDEV("h4", { "data-component-id": "src\\pages\\contact-management\\components\\FilterPanel.jsx:136:10", "data-component-path": "src\\pages\\contact-management\\components\\FilterPanel.jsx", "data-component-line": "136", "data-component-file": "FilterPanel.jsx", "data-component-name": "h4", "data-component-content": "%7B%22elementName%22%3A%22h4%22%2C%22className%22%3A%22text-sm%20font-medium%20text-text-primary%20mb-2%22%2C%22textContent%22%3A%22Deal%20Stage%22%7D", className: "text-sm font-medium text-text-primary mb-2", children: "Deal Stage" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/FilterPanel.jsx",
          lineNumber: 136,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\FilterPanel.jsx:137:10", "data-component-path": "src\\pages\\contact-management\\components\\FilterPanel.jsx", "data-component-line": "137", "data-component-file": "FilterPanel.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-2%22%7D", className: "space-y-2", children: dealStages?.map(
          (stage) => /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\FilterPanel.jsx:139:12", "data-component-path": "src\\pages\\contact-management\\components\\FilterPanel.jsx", "data-component-line": "139", "data-component-file": "FilterPanel.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22flex%20items-center%22%7D", className: "flex items-center", children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                "data-component-id": "src\\pages\\contact-management\\components\\FilterPanel.jsx:140:16",
                "data-component-path": "src\\pages\\contact-management\\components\\FilterPanel.jsx",
                "data-component-line": "140",
                "data-component-file": "FilterPanel.jsx",
                "data-component-name": "input",
                "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22checkbox%22%2C%22className%22%3A%22h-4%20w-4%20text-primary%20border-border%20rounded%20focus%3Aring-primary%22%7D",
                type: "checkbox",
                checked: localFilters?.dealStage?.includes(stage),
                onChange: () => handleDealStageChange(stage),
                className: "h-4 w-4 text-primary border-border rounded focus:ring-primary"
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/FilterPanel.jsx",
                lineNumber: 140,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\FilterPanel.jsx:146:16", "data-component-path": "src\\pages\\contact-management\\components\\FilterPanel.jsx", "data-component-line": "146", "data-component-file": "FilterPanel.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22ml-2%20text-sm%20text-text-secondary%20capitalize%22%7D", className: "ml-2 text-sm text-text-secondary capitalize", children: stage?.replace("-", " ") }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/FilterPanel.jsx",
              lineNumber: 146,
              columnNumber: 17
            }, this)
          ] }, stage, true, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/FilterPanel.jsx",
            lineNumber: 139,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/FilterPanel.jsx",
          lineNumber: 137,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/FilterPanel.jsx",
        lineNumber: 135,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\FilterPanel.jsx:155:8", "data-component-path": "src\\pages\\contact-management\\components\\FilterPanel.jsx", "data-component-line": "155", "data-component-file": "FilterPanel.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
        /* @__PURE__ */ jsxDEV("h4", { "data-component-id": "src\\pages\\contact-management\\components\\FilterPanel.jsx:156:10", "data-component-path": "src\\pages\\contact-management\\components\\FilterPanel.jsx", "data-component-line": "156", "data-component-file": "FilterPanel.jsx", "data-component-name": "h4", "data-component-content": "%7B%22elementName%22%3A%22h4%22%2C%22className%22%3A%22text-sm%20font-medium%20text-text-primary%20mb-2%22%2C%22textContent%22%3A%22Tags%22%7D", className: "text-sm font-medium text-text-primary mb-2", children: "Tags" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/FilterPanel.jsx",
          lineNumber: 156,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\FilterPanel.jsx:157:10", "data-component-path": "src\\pages\\contact-management\\components\\FilterPanel.jsx", "data-component-line": "157", "data-component-file": "FilterPanel.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-2%20max-h-48%20overflow-y-auto%22%7D", className: "space-y-2 max-h-48 overflow-y-auto", children: tags?.map(
          (tag) => /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\FilterPanel.jsx:159:12", "data-component-path": "src\\pages\\contact-management\\components\\FilterPanel.jsx", "data-component-line": "159", "data-component-file": "FilterPanel.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22flex%20items-center%22%7D", className: "flex items-center", children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                "data-component-id": "src\\pages\\contact-management\\components\\FilterPanel.jsx:160:16",
                "data-component-path": "src\\pages\\contact-management\\components\\FilterPanel.jsx",
                "data-component-line": "160",
                "data-component-file": "FilterPanel.jsx",
                "data-component-name": "input",
                "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22checkbox%22%2C%22className%22%3A%22h-4%20w-4%20text-primary%20border-border%20rounded%20focus%3Aring-primary%22%7D",
                type: "checkbox",
                checked: localFilters?.tags?.includes(tag),
                onChange: () => handleTagChange(tag),
                className: "h-4 w-4 text-primary border-border rounded focus:ring-primary"
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/FilterPanel.jsx",
                lineNumber: 160,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\FilterPanel.jsx:166:16", "data-component-path": "src\\pages\\contact-management\\components\\FilterPanel.jsx", "data-component-line": "166", "data-component-file": "FilterPanel.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22ml-2%20text-sm%20text-text-secondary%22%7D", className: "ml-2 text-sm text-text-secondary", children: tag }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/FilterPanel.jsx",
              lineNumber: 166,
              columnNumber: 17
            }, this)
          ] }, tag, true, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/FilterPanel.jsx",
            lineNumber: 159,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/FilterPanel.jsx",
          lineNumber: 157,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/FilterPanel.jsx",
        lineNumber: 155,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/FilterPanel.jsx",
      lineNumber: 115,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\FilterPanel.jsx:172:6", "data-component-path": "src\\pages\\contact-management\\components\\FilterPanel.jsx", "data-component-line": "172", "data-component-file": "FilterPanel.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22p-4%20border-t%20border-border%20flex%20justify-end%20space-x-3%22%7D", className: "p-4 border-t border-border flex justify-end space-x-3", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          "data-component-id": "src\\pages\\contact-management\\components\\FilterPanel.jsx:173:8",
          "data-component-path": "src\\pages\\contact-management\\components\\FilterPanel.jsx",
          "data-component-line": "173",
          "data-component-file": "FilterPanel.jsx",
          "data-component-name": "button",
          "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22px-4%20py-2%20border%20border-border%20rounded-lg%20text-text-secondary%20hover%3Atext-text-primary%20hover%3Abg-surface-hover%20transition-all%20duration-150%20ease-out%20text-sm%22%2C%22textContent%22%3A%22Reset%22%7D",
          onClick: handleResetFilters,
          className: "px-4 py-2 border border-border rounded-lg text-text-secondary hover:text-text-primary hover:bg-surface-hover transition-all duration-150 ease-out text-sm",
          children: "Reset"
        },
        void 0,
        false,
        {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/FilterPanel.jsx",
          lineNumber: 173,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          "data-component-id": "src\\pages\\contact-management\\components\\FilterPanel.jsx:179:8",
          "data-component-path": "src\\pages\\contact-management\\components\\FilterPanel.jsx",
          "data-component-line": "179",
          "data-component-file": "FilterPanel.jsx",
          "data-component-name": "button",
          "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22btn-primary%20text-sm%22%2C%22textContent%22%3A%22Apply%20Filters%22%7D",
          onClick: handleApplyFilters,
          className: "btn-primary text-sm",
          children: "Apply Filters"
        },
        void 0,
        false,
        {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/FilterPanel.jsx",
          lineNumber: 179,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/FilterPanel.jsx",
      lineNumber: 172,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/contact-management/components/FilterPanel.jsx",
    lineNumber: 105,
    columnNumber: 5
  }, this);
};
_s(FilterPanel, "yF+6EG7UjOGNbG0tPPmVb05TQZ8=");
_c = FilterPanel;
export default FilterPanel;
var _c;
$RefreshReg$(_c, "FilterPanel");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/contact-management/components/FilterPanel.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/contact-management/components/FilterPanel.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEdROzJCQTFHUjtBQUFnQkEsTUFBUSxjQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3ZDLE9BQU9DLFVBQVU7QUFFakIsTUFBTUMsY0FBY0EsQ0FBQyxFQUFFQyxTQUFTQyxZQUFZQyxRQUFRLE1BQU07QUFBQUMsS0FBQTtBQUN4RCxRQUFNLENBQUNDLGNBQWNDLGVBQWUsSUFBSVIsU0FBUyxFQUFFLEdBQUdHLFFBQVEsQ0FBQztBQUcvRCxRQUFNTSxZQUFZO0FBQUEsSUFDaEI7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFBbUI7QUFHckIsUUFBTUMsYUFBYTtBQUFBLElBQ2pCO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQWE7QUFHZixRQUFNQyxPQUFPO0FBQUEsSUFDWDtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFBWTtBQUdkLFFBQU1DLHNCQUFzQkEsQ0FBQ0MsWUFBWTtBQUN2QyxRQUFJTixjQUFjTSxTQUFTQyxTQUFTRCxPQUFPLEdBQUc7QUFDNUNMLHNCQUFnQjtBQUFBLFFBQ2QsR0FBR0Q7QUFBQUEsUUFDSE0sU0FBU04sY0FBY00sU0FBU0UsT0FBTyxDQUFBQyxNQUFLQSxNQUFNSCxPQUFPO0FBQUEsTUFDM0QsQ0FBQztBQUFBLElBQ0gsT0FBTztBQUNMTCxzQkFBZ0I7QUFBQSxRQUNkLEdBQUdEO0FBQUFBLFFBQ0hNLFNBQVMsQ0FBQyxHQUFHTixjQUFjTSxTQUFTQSxPQUFPO0FBQUEsTUFDN0MsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBRUEsUUFBTUksd0JBQXdCQSxDQUFDQyxVQUFVO0FBQ3ZDLFFBQUlYLGNBQWNZLFdBQVdMLFNBQVNJLEtBQUssR0FBRztBQUM1Q1Ysc0JBQWdCO0FBQUEsUUFDZCxHQUFHRDtBQUFBQSxRQUNIWSxXQUFXWixjQUFjWSxXQUFXSixPQUFPLENBQUFLLE1BQUtBLE1BQU1GLEtBQUs7QUFBQSxNQUM3RCxDQUFDO0FBQUEsSUFDSCxPQUFPO0FBQ0xWLHNCQUFnQjtBQUFBLFFBQ2QsR0FBR0Q7QUFBQUEsUUFDSFksV0FBVyxDQUFDLEdBQUdaLGNBQWNZLFdBQVdELEtBQUs7QUFBQSxNQUMvQyxDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFFQSxRQUFNRyxrQkFBa0JBLENBQUNDLFFBQVE7QUFDL0IsUUFBSWYsY0FBY0ksTUFBTUcsU0FBU1EsR0FBRyxHQUFHO0FBQ3JDZCxzQkFBZ0I7QUFBQSxRQUNkLEdBQUdEO0FBQUFBLFFBQ0hJLE1BQU1KLGNBQWNJLE1BQU1JLE9BQU8sQ0FBQVEsTUFBS0EsTUFBTUQsR0FBRztBQUFBLE1BQ2pELENBQUM7QUFBQSxJQUNILE9BQU87QUFDTGQsc0JBQWdCO0FBQUEsUUFDZCxHQUFHRDtBQUFBQSxRQUNISSxNQUFNLENBQUMsR0FBR0osY0FBY0ksTUFBTVcsR0FBRztBQUFBLE1BQ25DLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUVBLFFBQU1FLHFCQUFxQkEsTUFBTTtBQUMvQnBCLGVBQVdHLFlBQVk7QUFDdkJGLFlBQVE7QUFBQSxFQUNWO0FBRUEsUUFBTW9CLHFCQUFxQkEsTUFBTTtBQUMvQixVQUFNQyxlQUFlO0FBQUEsTUFDbkJiLFNBQVM7QUFBQSxNQUNUTSxXQUFXO0FBQUEsTUFDWFEsaUJBQWlCO0FBQUEsTUFDakJoQixNQUFNO0FBQUEsSUFDUjtBQUNBSCxvQkFBZ0JrQixZQUFZO0FBQzVCdEIsZUFBV3NCLFlBQVk7QUFDdkJyQixZQUFRO0FBQUEsRUFDVjtBQUVBLFNBQ0UsdUJBQUMsOGJBQUksV0FBVSw2REFDYjtBQUFBLDJCQUFDLGljQUFJLFdBQVUsZ0VBQ2I7QUFBQSw2QkFBQyxxY0FBRyxXQUFVLGlDQUFnQywrQkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RDtBQUFBLE1BQzdEO0FBQUEsUUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFDQyxTQUFTQTtBQUFBQSxVQUNULFdBQVU7QUFBQSxVQUVWLGlDQUFDLHlYQUFLLE1BQUssS0FBSSxNQUFNLE1BQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdCO0FBQUE7QUFBQSxRQUoxQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLQTtBQUFBLFNBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsSUFDQSx1QkFBQyw4YUFBSSxXQUFVLDZDQUViO0FBQUEsNkJBQUMsZ1dBQ0M7QUFBQSwrQkFBQyw2Y0FBRyxXQUFVLDhDQUE2Qyx1QkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRTtBQUFBLFFBQ2xFLHVCQUFDLGthQUFJLFdBQVUsc0NBQ1pJLHFCQUFXbUI7QUFBQUEsVUFBSSxDQUFBZixZQUNkLHVCQUFDLHFaQUFvQixXQUFVLHFCQUM3QjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVNOLGNBQWNNLFNBQVNDLFNBQVNELE9BQU87QUFBQSxnQkFDaEQsVUFBVSxNQUFNRCxvQkFBb0JDLE9BQU87QUFBQSxnQkFDM0MsV0FBVTtBQUFBO0FBQUEsY0FKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJMkU7QUFBQSxZQUUzRSx1QkFBQyxtYUFBSyxXQUFVLG9DQUFvQ0EscUJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTREO0FBQUEsZUFQbERBLFNBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFFBQ0QsS0FYSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxXQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFlQTtBQUFBLE1BR0EsdUJBQUMsZ1dBQ0M7QUFBQSwrQkFBQyxrZEFBRyxXQUFVLDhDQUE2QywwQkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRTtBQUFBLFFBQ3JFLHVCQUFDLHFZQUFJLFdBQVUsYUFDWkgsc0JBQVlrQjtBQUFBQSxVQUFJLENBQUFWLFVBQ2YsdUJBQUMscVpBQWtCLFdBQVUscUJBQzNCO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBU1gsY0FBY1ksV0FBV0wsU0FBU0ksS0FBSztBQUFBLGdCQUNoRCxVQUFVLE1BQU1ELHNCQUFzQkMsS0FBSztBQUFBLGdCQUMzQyxXQUFVO0FBQUE7QUFBQSxjQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUkyRTtBQUFBLFlBRTNFLHVCQUFDLGdiQUFLLFdBQVUsK0NBQ2JBLGlCQUFPVyxRQUFRLEtBQUssR0FBRyxLQUQxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFUVVgsT0FBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsUUFDRCxLQWJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFjQTtBQUFBLFdBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpQkE7QUFBQSxNQUdBLHVCQUFDLGdXQUNDO0FBQUEsK0JBQUMsMGNBQUcsV0FBVSw4Q0FBNkMsb0JBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0Q7QUFBQSxRQUMvRCx1QkFBQyxrYUFBSSxXQUFVLHNDQUNaUCxnQkFBTWlCO0FBQUFBLFVBQUksQ0FBQU4sUUFDVCx1QkFBQyxxWkFBZ0IsV0FBVSxxQkFDekI7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTZixjQUFjSSxNQUFNRyxTQUFTUSxHQUFHO0FBQUEsZ0JBQ3pDLFVBQVUsTUFBTUQsZ0JBQWdCQyxHQUFHO0FBQUEsZ0JBQ25DLFdBQVU7QUFBQTtBQUFBLGNBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSTJFO0FBQUEsWUFFM0UsdUJBQUMsbWFBQUssV0FBVSxvQ0FBb0NBLGlCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RDtBQUFBLGVBUDlDQSxLQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxRQUNELEtBWEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBO0FBQUEsV0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZUE7QUFBQSxTQXZERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBd0RBO0FBQUEsSUFDQSx1QkFBQywwYkFBSSxXQUFVLHlEQUNiO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUNDLFNBQVNHO0FBQUFBLFVBQ1QsV0FBVTtBQUFBLFVBQTJKO0FBQUE7QUFBQSxRQUZ2SztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUNDLFNBQVNEO0FBQUFBLFVBQ1QsV0FBVTtBQUFBLFVBQXFCO0FBQUE7QUFBQSxRQUZqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLQTtBQUFBLFNBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWFBO0FBQUEsT0FoRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlGQTtBQUVKO0FBQUVsQixHQXhMSUosYUFBVztBQUFBNEIsS0FBWDVCO0FBMExOLGVBQWVBO0FBQVksSUFBQTRCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkljb24iLCJGaWx0ZXJQYW5lbCIsImZpbHRlcnMiLCJzZXRGaWx0ZXJzIiwib25DbG9zZSIsIl9zIiwibG9jYWxGaWx0ZXJzIiwic2V0TG9jYWxGaWx0ZXJzIiwiY29tcGFuaWVzIiwiZGVhbFN0YWdlcyIsInRhZ3MiLCJoYW5kbGVDb21wYW55Q2hhbmdlIiwiY29tcGFueSIsImluY2x1ZGVzIiwiZmlsdGVyIiwiYyIsImhhbmRsZURlYWxTdGFnZUNoYW5nZSIsInN0YWdlIiwiZGVhbFN0YWdlIiwicyIsImhhbmRsZVRhZ0NoYW5nZSIsInRhZyIsInQiLCJoYW5kbGVBcHBseUZpbHRlcnMiLCJoYW5kbGVSZXNldEZpbHRlcnMiLCJyZXNldEZpbHRlcnMiLCJsYXN0Q29udGFjdERhdGUiLCJtYXAiLCJyZXBsYWNlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJGaWx0ZXJQYW5lbC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgSWNvbiBmcm9tICdjb21wb25lbnRzL0FwcEljb24nO1xyXG5cclxuY29uc3QgRmlsdGVyUGFuZWwgPSAoeyBmaWx0ZXJzLCBzZXRGaWx0ZXJzLCBvbkNsb3NlIH0pID0+IHtcclxuICBjb25zdCBbbG9jYWxGaWx0ZXJzLCBzZXRMb2NhbEZpbHRlcnNdID0gdXNlU3RhdGUoeyAuLi5maWx0ZXJzIH0pO1xyXG4gIFxyXG4gIC8vIE1vY2sgZGF0YSBmb3IgZmlsdGVyIG9wdGlvbnNcclxuICBjb25zdCBjb21wYW5pZXMgPSBbXHJcbiAgICBcIkFjbWUgQ29ycG9yYXRpb25cIiwgXHJcbiAgICBcIkdsb2JleCBJbmR1c3RyaWVzXCIsIFxyXG4gICAgXCJTb3lsZW50IENvcnBcIiwgXHJcbiAgICBcIkluaXRlY2hcIiwgXHJcbiAgICBcIlVtYnJlbGxhIENvcnBvcmF0aW9uXCIsIFxyXG4gICAgXCJXYXluZSBFbnRlcnByaXNlc1wiLCBcclxuICAgIFwiU3RhcmsgSW5kdXN0cmllc1wiLCBcclxuICAgIFwiQ3liZXJkeW5lIFN5c3RlbXNcIlxyXG4gIF07XHJcbiAgXHJcbiAgY29uc3QgZGVhbFN0YWdlcyA9IFtcclxuICAgIFwiZGlzY292ZXJ5XCIsIFxyXG4gICAgXCJwcm9wb3NhbFwiLCBcclxuICAgIFwibmVnb3RpYXRpb25cIiwgXHJcbiAgICBcImNsb3NlZC13b25cIiwgXHJcbiAgICBcImNsb3NlZC1sb3N0XCJcclxuICBdO1xyXG4gIFxyXG4gIGNvbnN0IHRhZ3MgPSBbXHJcbiAgICBcImVudGVycHJpc2VcIiwgXHJcbiAgICBcIm1pZC1tYXJrZXRcIiwgXHJcbiAgICBcInNtYWxsLWJ1c2luZXNzXCIsIFxyXG4gICAgXCJ0ZWNoXCIsIFxyXG4gICAgXCJtYW51ZmFjdHVyaW5nXCIsIFxyXG4gICAgXCJoZWFsdGhjYXJlXCIsIFxyXG4gICAgXCJmaW5hbmNlXCIsIFxyXG4gICAgXCJtYXJrZXRpbmdcIiwgXHJcbiAgICBcIm9wZXJhdGlvbnNcIiwgXHJcbiAgICBcInNlY3VyaXR5XCIsIFxyXG4gICAgXCJkZWNpc2lvbi1tYWtlclwiLCBcclxuICAgIFwiaW5mbHVlbmNlclwiLCBcclxuICAgIFwicHJvY3VyZW1lbnRcIiwgXHJcbiAgICBcImZhc3QtZ3Jvd3RoXCIsIFxyXG4gICAgXCJpbm5vdmF0aW9uXCJcclxuICBdO1xyXG5cclxuICBjb25zdCBoYW5kbGVDb21wYW55Q2hhbmdlID0gKGNvbXBhbnkpID0+IHtcclxuICAgIGlmIChsb2NhbEZpbHRlcnM/LmNvbXBhbnk/LmluY2x1ZGVzKGNvbXBhbnkpKSB7XHJcbiAgICAgIHNldExvY2FsRmlsdGVycyh7XHJcbiAgICAgICAgLi4ubG9jYWxGaWx0ZXJzLFxyXG4gICAgICAgIGNvbXBhbnk6IGxvY2FsRmlsdGVycz8uY29tcGFueT8uZmlsdGVyKGMgPT4gYyAhPT0gY29tcGFueSlcclxuICAgICAgfSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRMb2NhbEZpbHRlcnMoe1xyXG4gICAgICAgIC4uLmxvY2FsRmlsdGVycyxcclxuICAgICAgICBjb21wYW55OiBbLi4ubG9jYWxGaWx0ZXJzPy5jb21wYW55LCBjb21wYW55XVxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVEZWFsU3RhZ2VDaGFuZ2UgPSAoc3RhZ2UpID0+IHtcclxuICAgIGlmIChsb2NhbEZpbHRlcnM/LmRlYWxTdGFnZT8uaW5jbHVkZXMoc3RhZ2UpKSB7XHJcbiAgICAgIHNldExvY2FsRmlsdGVycyh7XHJcbiAgICAgICAgLi4ubG9jYWxGaWx0ZXJzLFxyXG4gICAgICAgIGRlYWxTdGFnZTogbG9jYWxGaWx0ZXJzPy5kZWFsU3RhZ2U/LmZpbHRlcihzID0+IHMgIT09IHN0YWdlKVxyXG4gICAgICB9KTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldExvY2FsRmlsdGVycyh7XHJcbiAgICAgICAgLi4ubG9jYWxGaWx0ZXJzLFxyXG4gICAgICAgIGRlYWxTdGFnZTogWy4uLmxvY2FsRmlsdGVycz8uZGVhbFN0YWdlLCBzdGFnZV1cclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVGFnQ2hhbmdlID0gKHRhZykgPT4ge1xyXG4gICAgaWYgKGxvY2FsRmlsdGVycz8udGFncz8uaW5jbHVkZXModGFnKSkge1xyXG4gICAgICBzZXRMb2NhbEZpbHRlcnMoe1xyXG4gICAgICAgIC4uLmxvY2FsRmlsdGVycyxcclxuICAgICAgICB0YWdzOiBsb2NhbEZpbHRlcnM/LnRhZ3M/LmZpbHRlcih0ID0+IHQgIT09IHRhZylcclxuICAgICAgfSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRMb2NhbEZpbHRlcnMoe1xyXG4gICAgICAgIC4uLmxvY2FsRmlsdGVycyxcclxuICAgICAgICB0YWdzOiBbLi4ubG9jYWxGaWx0ZXJzPy50YWdzLCB0YWddXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUFwcGx5RmlsdGVycyA9ICgpID0+IHtcclxuICAgIHNldEZpbHRlcnMobG9jYWxGaWx0ZXJzKTtcclxuICAgIG9uQ2xvc2UoKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVSZXNldEZpbHRlcnMgPSAoKSA9PiB7XHJcbiAgICBjb25zdCByZXNldEZpbHRlcnMgPSB7XHJcbiAgICAgIGNvbXBhbnk6IFtdLFxyXG4gICAgICBkZWFsU3RhZ2U6IFtdLFxyXG4gICAgICBsYXN0Q29udGFjdERhdGU6IG51bGwsXHJcbiAgICAgIHRhZ3M6IFtdXHJcbiAgICB9O1xyXG4gICAgc2V0TG9jYWxGaWx0ZXJzKHJlc2V0RmlsdGVycyk7XHJcbiAgICBzZXRGaWx0ZXJzKHJlc2V0RmlsdGVycyk7XHJcbiAgICBvbkNsb3NlKCk7XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc3VyZmFjZSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItYm9yZGVyIHNoYWRvdy1tZCBtYi02XCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJvcmRlci1iIGJvcmRlci1ib3JkZXIgZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5XCI+RmlsdGVyIENvbnRhY3RzPC9oMz5cclxuICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC10ZXh0LXNlY29uZGFyeSBob3Zlcjp0ZXh0LXRleHQtcHJpbWFyeVwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPEljb24gbmFtZT1cIlhcIiBzaXplPXsxOH0gLz5cclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTZcIj5cclxuICAgICAgICB7LyogQ29tcGFueSBGaWx0ZXIgKi99XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IG1iLTJcIj5Db21wYW55PC9oND5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yIG1heC1oLTQ4IG92ZXJmbG93LXktYXV0b1wiPlxyXG4gICAgICAgICAgICB7Y29tcGFuaWVzPy5tYXAoY29tcGFueSA9PiAoXHJcbiAgICAgICAgICAgICAgPGxhYmVsIGtleT17Y29tcGFueX0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICBjaGVja2VkPXtsb2NhbEZpbHRlcnM/LmNvbXBhbnk/LmluY2x1ZGVzKGNvbXBhbnkpfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT4gaGFuZGxlQ29tcGFueUNoYW5nZShjb21wYW55KX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LXByaW1hcnkgYm9yZGVyLWJvcmRlciByb3VuZGVkIGZvY3VzOnJpbmctcHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiB0ZXh0LXNtIHRleHQtdGV4dC1zZWNvbmRhcnlcIj57Y29tcGFueX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICBcclxuICAgICAgICB7LyogRGVhbCBTdGFnZSBGaWx0ZXIgKi99XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IG1iLTJcIj5EZWFsIFN0YWdlPC9oND5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgIHtkZWFsU3RhZ2VzPy5tYXAoc3RhZ2UgPT4gKFxyXG4gICAgICAgICAgICAgIDxsYWJlbCBrZXk9e3N0YWdlfSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2xvY2FsRmlsdGVycz8uZGVhbFN0YWdlPy5pbmNsdWRlcyhzdGFnZSl9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiBoYW5kbGVEZWFsU3RhZ2VDaGFuZ2Uoc3RhZ2UpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtcHJpbWFyeSBib3JkZXItYm9yZGVyIHJvdW5kZWQgZm9jdXM6cmluZy1wcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0yIHRleHQtc20gdGV4dC10ZXh0LXNlY29uZGFyeSBjYXBpdGFsaXplXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtzdGFnZT8ucmVwbGFjZSgnLScsICcgJyl9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICBcclxuICAgICAgICB7LyogVGFncyBGaWx0ZXIgKi99XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IG1iLTJcIj5UYWdzPC9oND5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yIG1heC1oLTQ4IG92ZXJmbG93LXktYXV0b1wiPlxyXG4gICAgICAgICAgICB7dGFncz8ubWFwKHRhZyA9PiAoXHJcbiAgICAgICAgICAgICAgPGxhYmVsIGtleT17dGFnfSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2xvY2FsRmlsdGVycz8udGFncz8uaW5jbHVkZXModGFnKX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IGhhbmRsZVRhZ0NoYW5nZSh0YWcpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtcHJpbWFyeSBib3JkZXItYm9yZGVyIHJvdW5kZWQgZm9jdXM6cmluZy1wcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0yIHRleHQtc20gdGV4dC10ZXh0LXNlY29uZGFyeVwiPnt0YWd9PC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBib3JkZXItdCBib3JkZXItYm9yZGVyIGZsZXgganVzdGlmeS1lbmQgc3BhY2UteC0zXCI+XHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgb25DbGljaz17aGFuZGxlUmVzZXRGaWx0ZXJzfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbGcgdGV4dC10ZXh0LXNlY29uZGFyeSBob3Zlcjp0ZXh0LXRleHQtcHJpbWFyeSBob3ZlcjpiZy1zdXJmYWNlLWhvdmVyIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTE1MCBlYXNlLW91dCB0ZXh0LXNtXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICBSZXNldFxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUFwcGx5RmlsdGVyc31cclxuICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5IHRleHQtc21cIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIEFwcGx5IEZpbHRlcnNcclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgRmlsdGVyUGFuZWw7Il0sImZpbGUiOiJEOi9jdXJyZW50IHByb2plY3RzL2NsYXVkZS1jb2RlL3NyYy9wYWdlcy9jb250YWN0LW1hbmFnZW1lbnQvY29tcG9uZW50cy9GaWx0ZXJQYW5lbC5qc3gifQ==