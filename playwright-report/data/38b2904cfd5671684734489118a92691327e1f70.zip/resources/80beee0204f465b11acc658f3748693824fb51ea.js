import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/login/index.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/login/index.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import { useAuth } from "/src/contexts/AuthContext.jsx";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=44ab9529";
import Icon from "/src/components/AppIcon.jsx";
const Login = () => {
  _s();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { signIn, authError, clearAuthError } = useAuth();
  const navigate = useNavigate();
  const handleSubmit = async (e) => {
    e?.preventDefault();
    setIsLoading(true);
    clearAuthError();
    const { user, error } = await signIn(email, password);
    if (user && !error) {
      navigate("/sales-dashboard");
    }
    setIsLoading(false);
  };
  const handleDemoLogin = async (role) => {
    setIsLoading(true);
    clearAuthError();
    const demoCredentials = {
      admin: { email: "admin@salesflow.com", password: "password123" },
      sales_rep: { email: "john.smith@salesflow.com", password: "password123" },
      manager: { email: "sarah.johnson@salesflow.com", password: "password123" }
    };
    const credentials = demoCredentials?.[role];
    if (credentials) {
      setEmail(credentials?.email);
      setPassword(credentials?.password);
      const { user, error } = await signIn(credentials?.email, credentials?.password);
      if (user && !error) {
        navigate("/sales-dashboard");
      }
    }
    setIsLoading(false);
  };
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\login\\index.jsx:53:4", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "53", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22min-h-screen%20flex%20items-center%20justify-center%20bg-gradient-to-br%20from-primary-50%20to-blue-50%20py-12%20px-4%20sm%3Apx-6%20lg%3Apx-8%22%7D", className: "min-h-screen flex items-center justify-center bg-gradient-to-br from-primary-50 to-blue-50 py-12 px-4 sm:px-6 lg:px-8", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\login\\index.jsx:54:6", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "54", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22max-w-md%20w-full%22%7D", className: "max-w-md w-full", children: [
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\login\\index.jsx:55:8", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "55", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-white%20rounded-2xl%20shadow-xl%20p-8%22%7D", className: "bg-white rounded-2xl shadow-xl p-8", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\login\\index.jsx:57:10", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "57", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-center%20mb-8%22%7D", className: "text-center mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\login\\index.jsx:58:12", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "58", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-16%20h-16%20bg-primary%20rounded-xl%20flex%20items-center%20justify-center%20mx-auto%20mb-4%22%7D", className: "w-16 h-16 bg-primary rounded-xl flex items-center justify-center mx-auto mb-4", children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\login\\index.jsx:59:14", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "59", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22BarChart3%22%2C%22className%22%3A%22text-white%22%7D", name: "BarChart3", size: 28, className: "text-white" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
          lineNumber: 59,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
          lineNumber: 58,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { "data-component-id": "src\\pages\\login\\index.jsx:61:12", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "61", "data-component-file": "index.jsx", "data-component-name": "h2", "data-component-content": "%7B%22elementName%22%3A%22h2%22%2C%22className%22%3A%22text-3xl%20font-bold%20text-text-primary%22%2C%22textContent%22%3A%22Welcome%20back%22%7D", className: "text-3xl font-bold text-text-primary", children: "Welcome back" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
          lineNumber: 61,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\login\\index.jsx:62:12", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "62", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20mt-2%22%2C%22textContent%22%3A%22Sign%20in%20to%20your%20SalesFlow%20account%22%7D", className: "text-text-secondary mt-2", children: "Sign in to your SalesFlow account" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
          lineNumber: 62,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
        lineNumber: 57,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\login\\index.jsx:66:10", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "66", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22mb-6%22%7D", className: "mb-6", children: [
        /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\login\\index.jsx:67:12", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "67", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%20text-text-secondary%20text-center%20mb-3%22%2C%22textContent%22%3A%22Quick%20Demo%20Access%3A%22%7D", className: "text-sm text-text-secondary text-center mb-3", children: "Quick Demo Access:" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
          lineNumber: 67,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\login\\index.jsx:68:12", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "68", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20gap-2%22%7D", className: "grid grid-cols-1 gap-2", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\login\\index.jsx:69:14",
              "data-component-path": "src\\pages\\login\\index.jsx",
              "data-component-line": "69",
              "data-component-file": "index.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22w-full%20py-2%20px-4%20text-sm%20border%20border-primary%20text-primary%20rounded-lg%20hover%3Abg-primary-50%20transition-colors%20duration-150%20disabled%3Aopacity-50%22%2C%22textContent%22%3A%22Demo%20as%20Admin%22%7D",
              onClick: () => handleDemoLogin("admin"),
              disabled: isLoading,
              className: "w-full py-2 px-4 text-sm border border-primary text-primary rounded-lg hover:bg-primary-50 transition-colors duration-150 disabled:opacity-50",
              children: "Demo as Admin"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
              lineNumber: 69,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\login\\index.jsx:76:14",
              "data-component-path": "src\\pages\\login\\index.jsx",
              "data-component-line": "76",
              "data-component-file": "index.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22w-full%20py-2%20px-4%20text-sm%20border%20border-primary%20text-primary%20rounded-lg%20hover%3Abg-primary-50%20transition-colors%20duration-150%20disabled%3Aopacity-50%22%2C%22textContent%22%3A%22Demo%20as%20Sales%20Rep%22%7D",
              onClick: () => handleDemoLogin("sales_rep"),
              disabled: isLoading,
              className: "w-full py-2 px-4 text-sm border border-primary text-primary rounded-lg hover:bg-primary-50 transition-colors duration-150 disabled:opacity-50",
              children: "Demo as Sales Rep"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
              lineNumber: 76,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
          lineNumber: 68,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
        lineNumber: 66,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\login\\index.jsx:86:10", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "86", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22relative%20mb-6%22%7D", className: "relative mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\login\\index.jsx:87:12", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "87", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22absolute%20inset-0%20flex%20items-center%22%7D", className: "absolute inset-0 flex items-center", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\login\\index.jsx:88:14", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "88", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-full%20border-t%20border-border%22%7D", className: "w-full border-t border-border" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
          lineNumber: 88,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
          lineNumber: 87,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\login\\index.jsx:90:12", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "90", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22relative%20flex%20justify-center%20text-sm%22%7D", className: "relative flex justify-center text-sm", children: /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\login\\index.jsx:91:14", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "91", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22bg-white%20px-2%20text-text-secondary%22%2C%22textContent%22%3A%22Or%20sign%20in%20manually%22%7D", className: "bg-white px-2 text-text-secondary", children: "Or sign in manually" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
          lineNumber: 91,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
          lineNumber: 90,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
        lineNumber: 86,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("form", { "data-component-id": "src\\pages\\login\\index.jsx:96:10", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "96", "data-component-file": "index.jsx", "data-component-name": "form", "data-component-content": "%7B%22elementName%22%3A%22form%22%2C%22className%22%3A%22space-y-6%22%7D", className: "space-y-6", onSubmit: handleSubmit, children: [
        authError && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\login\\index.jsx:98:12", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "98", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-error-50%20border%20border-error-200%20text-error%20rounded-lg%20p-4%20flex%20items-center%20space-x-2%22%7D", className: "bg-error-50 border border-error-200 text-error rounded-lg p-4 flex items-center space-x-2", children: [
          /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\login\\index.jsx:99:16", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "99", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22AlertCircle%22%2C%22className%22%3A%22text-error%20flex-shrink-0%22%7D", name: "AlertCircle", size: 16, className: "text-error flex-shrink-0" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
            lineNumber: 99,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\login\\index.jsx:100:16", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "100", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex-1%22%7D", className: "flex-1", children: [
            /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\login\\index.jsx:101:18", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "101", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%22%7D", className: "text-sm", children: authError }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
              lineNumber: 101,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                "data-component-id": "src\\pages\\login\\index.jsx:102:18",
                "data-component-path": "src\\pages\\login\\index.jsx",
                "data-component-line": "102",
                "data-component-file": "index.jsx",
                "data-component-name": "button",
                "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22button%22%2C%22className%22%3A%22text-xs%20text-error-600%20hover%3Atext-error-700%20underline%20mt-1%22%2C%22textContent%22%3A%22Copy%20error%20message%22%7D",
                type: "button",
                onClick: () => {
                  const errorText = authError;
                  navigator.clipboard?.writeText(errorText);
                },
                className: "text-xs text-error-600 hover:text-error-700 underline mt-1",
                children: "Copy error message"
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
                lineNumber: 102,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
            lineNumber: 100,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\login\\index.jsx:113:16",
              "data-component-path": "src\\pages\\login\\index.jsx",
              "data-component-line": "113",
              "data-component-file": "index.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22button%22%2C%22className%22%3A%22text-error%20hover%3Atext-error-600%22%7D",
              type: "button",
              onClick: clearAuthError,
              className: "text-error hover:text-error-600",
              children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\login\\index.jsx:118:18", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "118", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22X%22%7D", name: "X", size: 16 }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
                lineNumber: 118,
                columnNumber: 19
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
              lineNumber: 113,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
          lineNumber: 98,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\login\\index.jsx:123:12", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "123", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\login\\index.jsx:124:14", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "124", "data-component-file": "index.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-2%22%2C%22textContent%22%3A%22Email%20address%22%7D", htmlFor: "email", className: "block text-sm font-medium text-text-primary mb-2", children: "Email address" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
            lineNumber: 124,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\login\\index.jsx:127:14", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "127", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22relative%22%7D", className: "relative", children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                "data-component-id": "src\\pages\\login\\index.jsx:128:16",
                "data-component-path": "src\\pages\\login\\index.jsx",
                "data-component-line": "128",
                "data-component-file": "index.jsx",
                "data-component-name": "input",
                "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22id%22%3A%22email%22%2C%22name%22%3A%22email%22%2C%22type%22%3A%22email%22%2C%22className%22%3A%22input-field%20pl-10%22%2C%22value%22%3A%22%5Bvar%3Aemail%5D%22%7D",
                id: "email",
                name: "email",
                type: "email",
                autoComplete: "email",
                required: true,
                className: "input-field pl-10",
                placeholder: "Enter your email",
                value: email,
                onChange: (e) => setEmail(e?.target?.value)
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
                lineNumber: 128,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\login\\index.jsx:139:16", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "139", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22absolute%20inset-y-0%20left-0%20pl-3%20flex%20items-center%20pointer-events-none%22%7D", className: "absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none", children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\login\\index.jsx:140:18", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "140", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Mail%22%2C%22className%22%3A%22text-text-tertiary%22%7D", name: "Mail", size: 18, className: "text-text-tertiary" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
              lineNumber: 140,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
              lineNumber: 139,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
            lineNumber: 127,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
          lineNumber: 123,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\login\\index.jsx:145:12", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "145", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\login\\index.jsx:146:14", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "146", "data-component-file": "index.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-2%22%2C%22textContent%22%3A%22Password%22%7D", htmlFor: "password", className: "block text-sm font-medium text-text-primary mb-2", children: "Password" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
            lineNumber: 146,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\login\\index.jsx:149:14", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "149", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22relative%22%7D", className: "relative", children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                "data-component-id": "src\\pages\\login\\index.jsx:150:16",
                "data-component-path": "src\\pages\\login\\index.jsx",
                "data-component-line": "150",
                "data-component-file": "index.jsx",
                "data-component-name": "input",
                "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22id%22%3A%22password%22%2C%22name%22%3A%22password%22%2C%22type%22%3A%22password%22%2C%22className%22%3A%22input-field%20pl-10%22%2C%22value%22%3A%22%5Bvar%3Apassword%5D%22%7D",
                id: "password",
                name: "password",
                type: "password",
                autoComplete: "current-password",
                required: true,
                className: "input-field pl-10",
                placeholder: "Enter your password",
                value: password,
                onChange: (e) => setPassword(e?.target?.value)
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
                lineNumber: 150,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\login\\index.jsx:161:16", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "161", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22absolute%20inset-y-0%20left-0%20pl-3%20flex%20items-center%20pointer-events-none%22%7D", className: "absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none", children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\login\\index.jsx:162:18", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "162", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Lock%22%2C%22className%22%3A%22text-text-tertiary%22%7D", name: "Lock", size: 18, className: "text-text-tertiary" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
              lineNumber: 162,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
              lineNumber: 161,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
            lineNumber: 149,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
          lineNumber: 145,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\login\\index.jsx:167:12", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "167", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\login\\index.jsx:168:14", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "168", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%22%7D", className: "flex items-center", children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                "data-component-id": "src\\pages\\login\\index.jsx:169:16",
                "data-component-path": "src\\pages\\login\\index.jsx",
                "data-component-line": "169",
                "data-component-file": "index.jsx",
                "data-component-name": "input",
                "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22id%22%3A%22remember-me%22%2C%22name%22%3A%22remember-me%22%2C%22type%22%3A%22checkbox%22%2C%22className%22%3A%22h-4%20w-4%20text-primary%20focus%3Aring-primary%20border-border%20rounded%22%7D",
                id: "remember-me",
                name: "remember-me",
                type: "checkbox",
                className: "h-4 w-4 text-primary focus:ring-primary border-border rounded"
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
                lineNumber: 169,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\login\\index.jsx:175:16", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "175", "data-component-file": "index.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22ml-2%20block%20text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22Remember%20me%22%7D", htmlFor: "remember-me", className: "ml-2 block text-sm text-text-secondary", children: "Remember me" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
              lineNumber: 175,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
            lineNumber: 168,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\login\\index.jsx:180:14", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "180", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-sm%22%7D", className: "text-sm", children: /* @__PURE__ */ jsxDEV("a", { "data-component-id": "src\\pages\\login\\index.jsx:181:16", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "181", "data-component-file": "index.jsx", "data-component-name": "a", "data-component-content": "%7B%22elementName%22%3A%22a%22%2C%22href%22%3A%22%23%22%2C%22className%22%3A%22font-medium%20text-primary%20hover%3Atext-primary-600%22%2C%22textContent%22%3A%22Forgot%20your%20password%3F%22%7D", href: "#", className: "font-medium text-primary hover:text-primary-600", children: "Forgot your password?" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
            lineNumber: 181,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
            lineNumber: 180,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
          lineNumber: 167,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\login\\index.jsx:187:12", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "187", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\login\\index.jsx:188:14",
            "data-component-path": "src\\pages\\login\\index.jsx",
            "data-component-line": "188",
            "data-component-file": "index.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22submit%22%2C%22className%22%3A%22btn-primary%20w-full%20flex%20justify-center%20items-center%20space-x-2%20disabled%3Aopacity-50%20disabled%3Acursor-not-allowed%22%7D",
            type: "submit",
            disabled: isLoading,
            className: "btn-primary w-full flex justify-center items-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed",
            children: isLoading ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\login\\index.jsx:195:20", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "195", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22animate-spin%20rounded-full%20h-5%20w-5%20border-b-2%20border-white%22%7D", className: "animate-spin rounded-full h-5 w-5 border-b-2 border-white" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
                lineNumber: 195,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\login\\index.jsx:196:20", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "196", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Signing%20in...%22%7D", children: "Signing in..." }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
                lineNumber: 196,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
              lineNumber: 194,
              columnNumber: 17
            }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\login\\index.jsx:200:20", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "200", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22LogIn%22%7D", name: "LogIn", size: 18 }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
                lineNumber: 200,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\login\\index.jsx:201:20", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "201", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Sign%20in%22%7D", children: "Sign in" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
                lineNumber: 201,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
              lineNumber: 199,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
            lineNumber: 188,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
          lineNumber: 187,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
        lineNumber: 96,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\login\\index.jsx:208:10", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "208", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22mt-6%20text-center%22%7D", className: "mt-6 text-center", children: /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\login\\index.jsx:209:12", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "209", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22Don't%20have%20an%20account%3F%22%7D", className: "text-sm text-text-secondary", children: [
        "Don't have an account?",
        " ",
        /* @__PURE__ */ jsxDEV("a", { "data-component-id": "src\\pages\\login\\index.jsx:211:14", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "211", "data-component-file": "index.jsx", "data-component-name": "a", "data-component-content": "%7B%22elementName%22%3A%22a%22%2C%22href%22%3A%22%23%22%2C%22className%22%3A%22font-medium%20text-primary%20hover%3Atext-primary-600%22%2C%22textContent%22%3A%22Contact%20your%20administrator%22%7D", href: "#", className: "font-medium text-primary hover:text-primary-600", children: "Contact your administrator" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
          lineNumber: 211,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
        lineNumber: 209,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
        lineNumber: 208,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
      lineNumber: 55,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\login\\index.jsx:219:8", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "219", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22mt-8%20text-center%22%7D", className: "mt-8 text-center", children: /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\login\\index.jsx:220:10", "data-component-path": "src\\pages\\login\\index.jsx", "data-component-line": "220", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-xs%20text-text-tertiary%22%2C%22textContent%22%3A%22%C2%A9%202025%20SalesFlow%20Pro.%20Built%20with%20React%20%26%20Supabase.%22%7D", className: "text-xs text-text-tertiary", children: "© 2025 SalesFlow Pro. Built with React & Supabase." }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
      lineNumber: 220,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
      lineNumber: 219,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
    lineNumber: 54,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "D:/current projects/claude-code/src/pages/login/index.jsx",
    lineNumber: 53,
    columnNumber: 5
  }, this);
};
_s(Login, "JAakoYcnAFJTkep8WCz1TrIiyNo=", false, function() {
  return [useAuth, useNavigate];
});
_c = Login;
export default Login;
var _c;
$RefreshReg$(_c, "Login");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/login/index.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/login/index.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMERjLFNBdUlJLFVBdklKOzJCQTFEZDtBQUFnQkEsTUFBUSxjQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3ZDLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsbUJBQW1CO0FBQzVCLE9BQU9DLFVBQVU7QUFFakIsTUFBTUMsUUFBUUEsTUFBTTtBQUFBQyxLQUFBO0FBQ2xCLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJUCxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDUSxVQUFVQyxXQUFXLElBQUlULFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNVLFdBQVdDLFlBQVksSUFBSVgsU0FBUyxLQUFLO0FBQ2hELFFBQU0sRUFBRVksUUFBUUMsV0FBV0MsZUFBZSxJQUFJYixRQUFRO0FBQ3RELFFBQU1jLFdBQVdiLFlBQVk7QUFFN0IsUUFBTWMsZUFBZSxPQUFPQyxNQUFNO0FBQ2hDQSxPQUFHQyxlQUFlO0FBQ2xCUCxpQkFBYSxJQUFJO0FBQ2pCRyxtQkFBZTtBQUVmLFVBQU0sRUFBRUssTUFBTUMsTUFBTSxJQUFJLE1BQU1SLE9BQU9OLE9BQU9FLFFBQVE7QUFFcEQsUUFBSVcsUUFBUSxDQUFDQyxPQUFPO0FBQ2xCTCxlQUFTLGtCQUFrQjtBQUFBLElBQzdCO0FBRUFKLGlCQUFhLEtBQUs7QUFBQSxFQUNwQjtBQUVBLFFBQU1VLGtCQUFrQixPQUFPQyxTQUFTO0FBQ3RDWCxpQkFBYSxJQUFJO0FBQ2pCRyxtQkFBZTtBQUVmLFVBQU1TLGtCQUFrQjtBQUFBLE1BQ3RCQyxPQUFPLEVBQUVsQixPQUFPLHVCQUF1QkUsVUFBVSxjQUFjO0FBQUEsTUFDL0RpQixXQUFXLEVBQUVuQixPQUFPLDRCQUE0QkUsVUFBVSxjQUFjO0FBQUEsTUFDeEVrQixTQUFTLEVBQUVwQixPQUFPLCtCQUErQkUsVUFBVSxjQUFjO0FBQUEsSUFDM0U7QUFFQSxVQUFNbUIsY0FBY0osa0JBQWtCRCxJQUFJO0FBQzFDLFFBQUlLLGFBQWE7QUFDZnBCLGVBQVNvQixhQUFhckIsS0FBSztBQUMzQkcsa0JBQVlrQixhQUFhbkIsUUFBUTtBQUVqQyxZQUFNLEVBQUVXLE1BQU1DLE1BQU0sSUFBSSxNQUFNUixPQUFPZSxhQUFhckIsT0FBT3FCLGFBQWFuQixRQUFRO0FBRTlFLFVBQUlXLFFBQVEsQ0FBQ0MsT0FBTztBQUNsQkwsaUJBQVMsa0JBQWtCO0FBQUEsTUFDN0I7QUFBQSxJQUNGO0FBRUFKLGlCQUFhLEtBQUs7QUFBQSxFQUNwQjtBQUVBLFNBQ0UsdUJBQUMsa2NBQUksV0FBVSx5SEFDYixpQ0FBQyxzVUFBSSxXQUFVLG1CQUNiO0FBQUEsMkJBQUMsNlZBQUksV0FBVSxzQ0FFYjtBQUFBLDZCQUFDLHdVQUFJLFdBQVUsb0JBQ2I7QUFBQSwrQkFBQyxtWkFBSSxXQUFVLGlGQUNiLGlDQUFDLGdXQUFLLE1BQUssYUFBWSxNQUFNLElBQUksV0FBVSxnQkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RCxLQUR6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLHNZQUFHLFdBQVUsd0NBQXVDLDRCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlFO0FBQUEsUUFDakUsdUJBQUMsa1pBQUUsV0FBVSw0QkFBMkIsaURBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUU7QUFBQSxXQUwzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUE7QUFBQSxNQUdBLHVCQUFDLDBUQUFJLFdBQVUsUUFDYjtBQUFBLCtCQUFDLHVaQUFFLFdBQVUsZ0RBQStDLGtDQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThFO0FBQUEsUUFDOUUsdUJBQUMsZ1ZBQUksV0FBVSwwQkFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FDQyxTQUFTLE1BQU1VLGdCQUFnQixPQUFPO0FBQUEsY0FDdEMsVUFBVVg7QUFBQUEsY0FDVixXQUFVO0FBQUEsY0FBK0k7QUFBQTtBQUFBLFlBSDNKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNVyxnQkFBZ0IsV0FBVztBQUFBLGNBQzFDLFVBQVVYO0FBQUFBLGNBQ1YsV0FBVTtBQUFBLGNBQStJO0FBQUE7QUFBQSxZQUgzSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLGFBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWVBO0FBQUEsV0FqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtCQTtBQUFBLE1BRUEsdUJBQUMscVVBQUksV0FBVSxpQkFDYjtBQUFBLCtCQUFDLDhWQUFJLFdBQVUsc0NBQ2IsaUNBQUMsdVZBQUksV0FBVSxtQ0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStDLEtBRGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsZ1dBQUksV0FBVSx3Q0FDYixpQ0FBQyxvWkFBSyxXQUFVLHFDQUFvQyxtQ0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RSxLQUR6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLE1BR0EsdUJBQUMsa1VBQUssV0FBVSxhQUFZLFVBQVVNLGNBQ25DSDtBQUFBQSxxQkFDQyx1QkFBQywrWkFBSSxXQUFVLDZGQUNiO0FBQUEsaUNBQUMsa1hBQUssTUFBSyxlQUFjLE1BQU0sSUFBSSxXQUFVLDhCQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1RTtBQUFBLFVBQ3ZFLHVCQUFDLDhUQUFJLFdBQVUsVUFDYjtBQUFBLG1DQUFDLHlUQUFFLFdBQVUsV0FBV0EsdUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtDO0FBQUEsWUFDbEM7QUFBQSxjQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUyxNQUFNO0FBQ2Isd0JBQU1lLFlBQVlmO0FBQ2xCZ0IsNEJBQVVDLFdBQVdDLFVBQVVILFNBQVM7QUFBQSxnQkFDMUM7QUFBQSxnQkFDQSxXQUFVO0FBQUEsZ0JBQTREO0FBQUE7QUFBQSxjQU54RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFTQTtBQUFBLGVBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFZQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVNkO0FBQUFBLGNBQ1QsV0FBVTtBQUFBLGNBRVYsaUNBQUMscVRBQUssTUFBSyxLQUFJLE1BQU0sTUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0I7QUFBQTtBQUFBLFlBTDFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsYUFyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXNCQTtBQUFBLFFBR0YsdUJBQUMsNlJBQ0M7QUFBQSxpQ0FBQyxrYUFBTSxTQUFRLFNBQVEsV0FBVSxvREFBbUQsNkJBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLGdVQUFJLFdBQVUsWUFDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ0MsSUFBRztBQUFBLGdCQUNILE1BQUs7QUFBQSxnQkFDTCxNQUFLO0FBQUEsZ0JBQ0wsY0FBYTtBQUFBLGdCQUNiO0FBQUEsZ0JBQ0EsV0FBVTtBQUFBLGdCQUNWLGFBQVk7QUFBQSxnQkFDWixPQUFPUjtBQUFBQSxnQkFDUCxVQUFVLENBQUNXLE1BQU1WLFNBQVNVLEdBQUdlLFFBQVFDLEtBQUs7QUFBQTtBQUFBLGNBVDVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVM4QztBQUFBLFlBRTlDLHVCQUFDLHdZQUFJLFdBQVUsd0VBQ2IsaUNBQUMscVdBQUssTUFBSyxRQUFPLE1BQU0sSUFBSSxXQUFVLHdCQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRCxLQUQ1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWVBO0FBQUEsYUFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9CQTtBQUFBLFFBRUEsdUJBQUMsNlJBQ0M7QUFBQSxpQ0FBQywyWkFBTSxTQUFRLFlBQVcsV0FBVSxvREFBbUQsd0JBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLGdVQUFJLFdBQVUsWUFDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ0MsSUFBRztBQUFBLGdCQUNILE1BQUs7QUFBQSxnQkFDTCxNQUFLO0FBQUEsZ0JBQ0wsY0FBYTtBQUFBLGdCQUNiO0FBQUEsZ0JBQ0EsV0FBVTtBQUFBLGdCQUNWLGFBQVk7QUFBQSxnQkFDWixPQUFPekI7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDUyxNQUFNUixZQUFZUSxHQUFHZSxRQUFRQyxLQUFLO0FBQUE7QUFBQSxjQVQvQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFTaUQ7QUFBQSxZQUVqRCx1QkFBQyx3WUFBSSxXQUFVLHdFQUNiLGlDQUFDLHFXQUFLLE1BQUssUUFBTyxNQUFNLElBQUksV0FBVSx3QkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEQsS0FENUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFlQTtBQUFBLGFBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvQkE7QUFBQSxRQUVBLHVCQUFDLDZWQUFJLFdBQVUscUNBQ2I7QUFBQSxpQ0FBQywyVUFBSSxXQUFVLHFCQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFDQyxJQUFHO0FBQUEsZ0JBQ0gsTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUE7QUFBQSxjQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUkyRTtBQUFBLFlBRTNFLHVCQUFDLG9aQUFNLFNBQVEsZUFBYyxXQUFVLDBDQUF5QywyQkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBRUEsdUJBQUMsK1RBQUksV0FBVSxXQUNiLGlDQUFDLHdiQUFFLE1BQUssS0FBSSxXQUFVLG1EQUFrRCxxQ0FBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxhQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBa0JBO0FBQUEsUUFFQSx1QkFBQyw2UkFDQztBQUFBLFVBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsVUFBVXZCO0FBQUFBLFlBQ1YsV0FBVTtBQUFBLFlBRVRBLHNCQUNDLG1DQUNFO0FBQUEscUNBQUMsMlhBQUksV0FBVSwrREFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyRTtBQUFBLGNBQzNFLHVCQUFDLDRVQUFLLDZCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1CO0FBQUEsaUJBRnJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0EsSUFFQSxtQ0FDRTtBQUFBLHFDQUFDLHlUQUFLLE1BQUssU0FBUSxNQUFNLE1BQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRCO0FBQUEsY0FDNUIsdUJBQUMsc1VBQUssdUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBYTtBQUFBLGlCQUZmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQTtBQUFBLFVBZEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBZ0JBLEtBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQkE7QUFBQSxXQTdHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBOEdBO0FBQUEsTUFFQSx1QkFBQywwVUFBSSxXQUFVLG9CQUNiLGlDQUFDLDBZQUFFLFdBQVUsK0JBQThCO0FBQUE7QUFBQSxRQUNsQjtBQUFBLFFBQ3ZCLHVCQUFDLDJiQUFFLE1BQUssS0FBSSxXQUFVLG1EQUFrRCwwQ0FBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxTQWhLRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUtBO0FBQUEsSUFHQSx1QkFBQyx5VUFBSSxXQUFVLG9CQUNiLGlDQUFDLG9iQUFFLFdBQVUsOEJBQTZCLGtFQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxPQXpLRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMEtBLEtBM0tGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E0S0E7QUFFSjtBQUFFTCxHQTdOSUQsT0FBSztBQUFBLFVBSXFDSCxTQUM3QkMsV0FBVztBQUFBO0FBQUFnQyxLQUx4QjlCO0FBK05OLGVBQWVBO0FBQU0sSUFBQThCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUF1dGgiLCJ1c2VOYXZpZ2F0ZSIsIkljb24iLCJMb2dpbiIsIl9zIiwiZW1haWwiLCJzZXRFbWFpbCIsInBhc3N3b3JkIiwic2V0UGFzc3dvcmQiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJzaWduSW4iLCJhdXRoRXJyb3IiLCJjbGVhckF1dGhFcnJvciIsIm5hdmlnYXRlIiwiaGFuZGxlU3VibWl0IiwiZSIsInByZXZlbnREZWZhdWx0IiwidXNlciIsImVycm9yIiwiaGFuZGxlRGVtb0xvZ2luIiwicm9sZSIsImRlbW9DcmVkZW50aWFscyIsImFkbWluIiwic2FsZXNfcmVwIiwibWFuYWdlciIsImNyZWRlbnRpYWxzIiwiZXJyb3JUZXh0IiwibmF2aWdhdG9yIiwiY2xpcGJvYXJkIiwid3JpdGVUZXh0IiwidGFyZ2V0IiwidmFsdWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbImluZGV4LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tICcuLi8uLi9jb250ZXh0cy9BdXRoQ29udGV4dCc7XHJcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcbmltcG9ydCBJY29uIGZyb20gJ2NvbXBvbmVudHMvQXBwSWNvbic7XHJcblxyXG5jb25zdCBMb2dpbiA9ICgpID0+IHtcclxuICBjb25zdCBbZW1haWwsIHNldEVtYWlsXSA9IHVzZVN0YXRlKCcnKTtcclxuICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKCcnKTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IHsgc2lnbkluLCBhdXRoRXJyb3IsIGNsZWFyQXV0aEVycm9yIH0gPSB1c2VBdXRoKCk7XHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG5cclxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZT8ucHJldmVudERlZmF1bHQoKTtcclxuICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgIGNsZWFyQXV0aEVycm9yKCk7XHJcblxyXG4gICAgY29uc3QgeyB1c2VyLCBlcnJvciB9ID0gYXdhaXQgc2lnbkluKGVtYWlsLCBwYXNzd29yZCk7XHJcbiAgICBcclxuICAgIGlmICh1c2VyICYmICFlcnJvcikge1xyXG4gICAgICBuYXZpZ2F0ZSgnL3NhbGVzLWRhc2hib2FyZCcpO1xyXG4gICAgfVxyXG4gICAgXHJcbiAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbW9Mb2dpbiA9IGFzeW5jIChyb2xlKSA9PiB7XHJcbiAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICBjbGVhckF1dGhFcnJvcigpO1xyXG5cclxuICAgIGNvbnN0IGRlbW9DcmVkZW50aWFscyA9IHtcclxuICAgICAgYWRtaW46IHsgZW1haWw6ICdhZG1pbkBzYWxlc2Zsb3cuY29tJywgcGFzc3dvcmQ6ICdwYXNzd29yZDEyMycgfSxcclxuICAgICAgc2FsZXNfcmVwOiB7IGVtYWlsOiAnam9obi5zbWl0aEBzYWxlc2Zsb3cuY29tJywgcGFzc3dvcmQ6ICdwYXNzd29yZDEyMycgfSxcclxuICAgICAgbWFuYWdlcjogeyBlbWFpbDogJ3NhcmFoLmpvaG5zb25Ac2FsZXNmbG93LmNvbScsIHBhc3N3b3JkOiAncGFzc3dvcmQxMjMnIH1cclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgY3JlZGVudGlhbHMgPSBkZW1vQ3JlZGVudGlhbHM/Lltyb2xlXTtcclxuICAgIGlmIChjcmVkZW50aWFscykge1xyXG4gICAgICBzZXRFbWFpbChjcmVkZW50aWFscz8uZW1haWwpO1xyXG4gICAgICBzZXRQYXNzd29yZChjcmVkZW50aWFscz8ucGFzc3dvcmQpO1xyXG4gICAgICBcclxuICAgICAgY29uc3QgeyB1c2VyLCBlcnJvciB9ID0gYXdhaXQgc2lnbkluKGNyZWRlbnRpYWxzPy5lbWFpbCwgY3JlZGVudGlhbHM/LnBhc3N3b3JkKTtcclxuICAgICAgXHJcbiAgICAgIGlmICh1c2VyICYmICFlcnJvcikge1xyXG4gICAgICAgIG5hdmlnYXRlKCcvc2FsZXMtZGFzaGJvYXJkJyk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIFxyXG4gICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1wcmltYXJ5LTUwIHRvLWJsdWUtNTAgcHktMTIgcHgtNCBzbTpweC02IGxnOnB4LThcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy1tZCB3LWZ1bGxcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtMnhsIHNoYWRvdy14bCBwLThcIj5cclxuICAgICAgICAgIHsvKiBIZWFkZXIgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIG1iLThcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTE2IGgtMTYgYmctcHJpbWFyeSByb3VuZGVkLXhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG14LWF1dG8gbWItNFwiPlxyXG4gICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJCYXJDaGFydDNcIiBzaXplPXsyOH0gY2xhc3NOYW1lPVwidGV4dC13aGl0ZVwiIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtdGV4dC1wcmltYXJ5XCI+V2VsY29tZSBiYWNrPC9oMj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC10ZXh0LXNlY29uZGFyeSBtdC0yXCI+U2lnbiBpbiB0byB5b3VyIFNhbGVzRmxvdyBhY2NvdW50PC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIERlbW8gTG9naW4gQnV0dG9ucyAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtdGV4dC1zZWNvbmRhcnkgdGV4dC1jZW50ZXIgbWItM1wiPlF1aWNrIERlbW8gQWNjZXNzOjwvcD5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRGVtb0xvZ2luKCdhZG1pbicpfVxyXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzTG9hZGluZ31cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0yIHB4LTQgdGV4dC1zbSBib3JkZXIgYm9yZGVyLXByaW1hcnkgdGV4dC1wcmltYXJ5IHJvdW5kZWQtbGcgaG92ZXI6YmctcHJpbWFyeS01MCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTAgZGlzYWJsZWQ6b3BhY2l0eS01MFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgRGVtbyBhcyBBZG1pblxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbW9Mb2dpbignc2FsZXNfcmVwJyl9XHJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNMb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTIgcHgtNCB0ZXh0LXNtIGJvcmRlciBib3JkZXItcHJpbWFyeSB0ZXh0LXByaW1hcnkgcm91bmRlZC1sZyBob3ZlcjpiZy1wcmltYXJ5LTUwIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MCBkaXNhYmxlZDpvcGFjaXR5LTUwXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBEZW1vIGFzIFNhbGVzIFJlcFxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgbWItNlwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXItdCBib3JkZXItYm9yZGVyXCI+PC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXgganVzdGlmeS1jZW50ZXIgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJnLXdoaXRlIHB4LTIgdGV4dC10ZXh0LXNlY29uZGFyeVwiPk9yIHNpZ24gaW4gbWFudWFsbHk8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIExvZ2luIEZvcm0gKi99XHJcbiAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzcGFjZS15LTZcIiBvblN1Ym1pdD17aGFuZGxlU3VibWl0fT5cclxuICAgICAgICAgICAge2F1dGhFcnJvciAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1lcnJvci01MCBib3JkZXIgYm9yZGVyLWVycm9yLTIwMCB0ZXh0LWVycm9yIHJvdW5kZWQtbGcgcC00IGZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMlwiPlxyXG4gICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIkFsZXJ0Q2lyY2xlXCIgc2l6ZT17MTZ9IGNsYXNzTmFtZT1cInRleHQtZXJyb3IgZmxleC1zaHJpbmstMFwiIC8+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtXCI+e2F1dGhFcnJvcn08L3A+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCBlcnJvclRleHQgPSBhdXRoRXJyb3I7XHJcbiAgICAgICAgICAgICAgICAgICAgICBuYXZpZ2F0b3IuY2xpcGJvYXJkPy53cml0ZVRleHQoZXJyb3JUZXh0KTtcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1lcnJvci02MDAgaG92ZXI6dGV4dC1lcnJvci03MDAgdW5kZXJsaW5lIG10LTFcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgQ29weSBlcnJvciBtZXNzYWdlXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtjbGVhckF1dGhFcnJvcn1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1lcnJvciBob3Zlcjp0ZXh0LWVycm9yLTYwMFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJYXCIgc2l6ZT17MTZ9IC8+XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJlbWFpbFwiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgRW1haWwgYWRkcmVzc1xyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIGlkPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlucHV0LWZpZWxkIHBsLTEwXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB5b3VyIGVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2VtYWlsfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEVtYWlsKGU/LnRhcmdldD8udmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQteS0wIGxlZnQtMCBwbC0zIGZsZXggaXRlbXMtY2VudGVyIHBvaW50ZXItZXZlbnRzLW5vbmVcIj5cclxuICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIk1haWxcIiBzaXplPXsxOH0gY2xhc3NOYW1lPVwidGV4dC10ZXh0LXRlcnRpYXJ5XCIgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJwYXNzd29yZFwiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgUGFzc3dvcmRcclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICBpZD1cInBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cInBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICAgICAgYXV0b0NvbXBsZXRlPVwiY3VycmVudC1wYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlucHV0LWZpZWxkIHBsLTEwXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB5b3VyIHBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3Bhc3N3b3JkfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFBhc3N3b3JkKGU/LnRhcmdldD8udmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQteS0wIGxlZnQtMCBwbC0zIGZsZXggaXRlbXMtY2VudGVyIHBvaW50ZXItZXZlbnRzLW5vbmVcIj5cclxuICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIkxvY2tcIiBzaXplPXsxOH0gY2xhc3NOYW1lPVwidGV4dC10ZXh0LXRlcnRpYXJ5XCIgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIGlkPVwicmVtZW1iZXItbWVcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwicmVtZW1iZXItbWVcIlxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtcHJpbWFyeSBmb2N1czpyaW5nLXByaW1hcnkgYm9yZGVyLWJvcmRlciByb3VuZGVkXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInJlbWVtYmVyLW1lXCIgY2xhc3NOYW1lPVwibWwtMiBibG9jayB0ZXh0LXNtIHRleHQtdGV4dC1zZWNvbmRhcnlcIj5cclxuICAgICAgICAgICAgICAgICAgUmVtZW1iZXIgbWVcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgPGEgaHJlZj1cIiNcIiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LXByaW1hcnkgaG92ZXI6dGV4dC1wcmltYXJ5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBGb3Jnb3QgeW91ciBwYXNzd29yZD9cclxuICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzTG9hZGluZ31cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5IHctZnVsbCBmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBzcGFjZS14LTIgZGlzYWJsZWQ6b3BhY2l0eS01MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtpc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW4gcm91bmRlZC1mdWxsIGgtNSB3LTUgYm9yZGVyLWItMiBib3JkZXItd2hpdGVcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5TaWduaW5nIGluLi4uPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIkxvZ0luXCIgc2l6ZT17MTh9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+U2lnbiBpbjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZm9ybT5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+XHJcbiAgICAgICAgICAgICAgRG9uJ3QgaGF2ZSBhbiBhY2NvdW50P3snICd9XHJcbiAgICAgICAgICAgICAgPGEgaHJlZj1cIiNcIiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LXByaW1hcnkgaG92ZXI6dGV4dC1wcmltYXJ5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgQ29udGFjdCB5b3VyIGFkbWluaXN0cmF0b3JcclxuICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogRm9vdGVyICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtOCB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXRleHQtdGVydGlhcnlcIj5cclxuICAgICAgICAgICAgwqkgMjAyNSBTYWxlc0Zsb3cgUHJvLiBCdWlsdCB3aXRoIFJlYWN0ICYgU3VwYWJhc2UuXHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IExvZ2luOyJdLCJmaWxlIjoiRDovY3VycmVudCBwcm9qZWN0cy9jbGF1ZGUtY29kZS9zcmMvcGFnZXMvbG9naW4vaW5kZXguanN4In0=