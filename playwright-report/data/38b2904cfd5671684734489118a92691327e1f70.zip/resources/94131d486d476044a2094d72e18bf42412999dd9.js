import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/sales-dashboard/components/PerformanceMetrics.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip } from "/node_modules/.vite/deps/recharts.js?v=44ab9529";
import Icon from "/src/components/AppIcon.jsx";
const PerformanceMetrics = ({ data }) => {
  const quotaData = [
    { name: "Achieved", value: data?.achieved, color: "#10B981" },
    { name: "Remaining", value: data?.quota - data?.achieved, color: "#E5E7EB" }
  ];
  const dealOutcomeData = [
    { name: "Won", value: data?.dealsWon, color: "#10B981" },
    { name: "Lost", value: data?.dealsLost, color: "#EF4444" }
  ];
  const monthlyPerformance = [
    { month: "Jan", target: 4e5, actual: 42e4 },
    { month: "Feb", target: 45e4, actual: 485e3 },
    { month: "Mar", target: 5e5, actual: 562e3 },
    { month: "Apr", target: 52e4, actual: 598e3 },
    { month: "May", target: 55e4, actual: 645e3 },
    { month: "Jun", target: 6e5, actual: 58e4 }
  ];
  const RADIAN = Math.PI / 180;
  const renderCustomizedLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent }) => {
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);
    return /* @__PURE__ */ jsxDEV(
      "text",
      {
        "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:32:6",
        "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx",
        "data-component-line": "32",
        "data-component-file": "PerformanceMetrics.jsx",
        "data-component-name": "text",
        "data-component-content": "%7B%22elementName%22%3A%22text%22%7D",
        x,
        y,
        fill: "white",
        textAnchor: x > cx ? "start" : "end",
        dominantBaseline: "central",
        fontSize: "12",
        fontWeight: "600",
        children: `${(percent * 100)?.toFixed(0)}%`
      },
      void 0,
      false,
      {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
        lineNumber: 32,
        columnNumber: 7
      },
      this
    );
  };
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:47:4", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "47", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-6%22%7D", className: "card p-6", children: [
    /* @__PURE__ */ jsxDEV("h2", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:48:6", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "48", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "h2", "data-component-content": "%7B%22elementName%22%3A%22h2%22%2C%22className%22%3A%22text-xl%20font-semibold%20text-text-primary%20mb-6%22%2C%22textContent%22%3A%22Performance%20Metrics%22%7D", className: "text-xl font-semibold text-text-primary mb-6", children: "Performance Metrics" }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
      lineNumber: 48,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:49:6", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "49", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20lg%3Agrid-cols-2%20gap-8%22%7D", className: "grid grid-cols-1 lg:grid-cols-2 gap-8", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:51:8", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "51", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
        /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:52:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "52", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-medium%20text-text-primary%20mb-4%22%2C%22textContent%22%3A%22Quota%20Achievement%22%7D", className: "text-lg font-medium text-text-primary mb-4", children: "Quota Achievement" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
          lineNumber: 52,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:53:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "53", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-6%22%7D", className: "flex items-center space-x-6", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:54:12", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "54", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-32%20h-32%22%7D", className: "w-32 h-32", children: /* @__PURE__ */ jsxDEV(ResponsiveContainer, { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:55:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "55", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "ResponsiveContainer", "data-component-content": "%7B%22elementName%22%3A%22ResponsiveContainer%22%7D", width: "100%", height: "100%", children: /* @__PURE__ */ jsxDEV(PieChart, { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:56:16", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "56", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "PieChart", "data-component-content": "%7B%22elementName%22%3A%22PieChart%22%7D", children: /* @__PURE__ */ jsxDEV(
            Pie,
            {
              "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:57:18",
              "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx",
              "data-component-line": "57",
              "data-component-file": "PerformanceMetrics.jsx",
              "data-component-name": "Pie",
              "data-component-content": "%7B%22elementName%22%3A%22Pie%22%7D",
              data: quotaData,
              cx: "50%",
              cy: "50%",
              labelLine: false,
              label: renderCustomizedLabel,
              outerRadius: 60,
              fill: "#8884d8",
              dataKey: "value",
              strokeWidth: 0,
              children: quotaData?.map(
                (entry, index) => /* @__PURE__ */ jsxDEV(Cell, { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:69:20", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "69", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "Cell", "data-component-content": "%7B%22elementName%22%3A%22Cell%22%7D", fill: entry?.color }, `cell-${index}`, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
                  lineNumber: 69,
                  columnNumber: 21
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
              lineNumber: 57,
              columnNumber: 19
            },
            this
          ) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
            lineNumber: 56,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
            lineNumber: 55,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
            lineNumber: 54,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:76:12", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "76", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-3%22%7D", className: "space-y-3", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:77:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "77", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:78:16", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "78", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22Quota%22%7D", className: "text-sm text-text-secondary", children: "Quota" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
                lineNumber: 78,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:79:16", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "79", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%2C%22textContent%22%3A%22%24%20M%22%7D", className: "text-lg font-semibold text-text-primary", children: [
                "$",
                (data?.quota / 1e6)?.toFixed(1),
                "M"
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
                lineNumber: 79,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
              lineNumber: 77,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:83:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "83", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:84:16", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "84", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22Achieved%22%7D", className: "text-sm text-text-secondary", children: "Achieved" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
                lineNumber: 84,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:85:16", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "85", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-success%22%2C%22textContent%22%3A%22%24%20M%22%7D", className: "text-lg font-semibold text-success", children: [
                "$",
                (data?.achieved / 1e6)?.toFixed(1),
                "M"
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
                lineNumber: 85,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
              lineNumber: 83,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:89:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "89", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:90:16", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "90", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22Remaining%22%7D", className: "text-sm text-text-secondary", children: "Remaining" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
                lineNumber: 90,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:91:16", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "91", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%2C%22textContent%22%3A%22%24%20M%22%7D", className: "text-lg font-semibold text-text-primary", children: [
                "$",
                ((data?.quota - data?.achieved) / 1e6)?.toFixed(1),
                "M"
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
                lineNumber: 91,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
              lineNumber: 89,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
            lineNumber: 76,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
          lineNumber: 53,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
        lineNumber: 51,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:100:8", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "100", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
        /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:101:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "101", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-medium%20text-text-primary%20mb-4%22%2C%22textContent%22%3A%22Deal%20Outcomes%22%7D", className: "text-lg font-medium text-text-primary mb-4", children: "Deal Outcomes" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
          lineNumber: 101,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:102:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "102", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-6%22%7D", className: "flex items-center space-x-6", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:103:12", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "103", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-32%20h-32%22%7D", className: "w-32 h-32", children: /* @__PURE__ */ jsxDEV(ResponsiveContainer, { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:104:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "104", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "ResponsiveContainer", "data-component-content": "%7B%22elementName%22%3A%22ResponsiveContainer%22%7D", width: "100%", height: "100%", children: /* @__PURE__ */ jsxDEV(PieChart, { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:105:16", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "105", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "PieChart", "data-component-content": "%7B%22elementName%22%3A%22PieChart%22%7D", children: /* @__PURE__ */ jsxDEV(
            Pie,
            {
              "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:106:18",
              "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx",
              "data-component-line": "106",
              "data-component-file": "PerformanceMetrics.jsx",
              "data-component-name": "Pie",
              "data-component-content": "%7B%22elementName%22%3A%22Pie%22%7D",
              data: dealOutcomeData,
              cx: "50%",
              cy: "50%",
              labelLine: false,
              label: renderCustomizedLabel,
              outerRadius: 60,
              fill: "#8884d8",
              dataKey: "value",
              strokeWidth: 0,
              children: dealOutcomeData?.map(
                (entry, index) => /* @__PURE__ */ jsxDEV(Cell, { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:118:20", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "118", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "Cell", "data-component-content": "%7B%22elementName%22%3A%22Cell%22%7D", fill: entry?.color }, `cell-${index}`, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
                  lineNumber: 118,
                  columnNumber: 21
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
              lineNumber: 106,
              columnNumber: 19
            },
            this
          ) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
            lineNumber: 105,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
            lineNumber: 104,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
            lineNumber: 103,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:125:12", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "125", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-3%22%7D", className: "space-y-3", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:126:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "126", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:127:16", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "127", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22Deals%20Won%22%7D", className: "text-sm text-text-secondary", children: "Deals Won" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
                lineNumber: 127,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:128:16", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "128", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-success%22%7D", className: "text-lg font-semibold text-success", children: data?.dealsWon }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
                lineNumber: 128,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
              lineNumber: 126,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:130:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "130", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:131:16", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "131", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22Deals%20Lost%22%7D", className: "text-sm text-text-secondary", children: "Deals Lost" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
                lineNumber: 131,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:132:16", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "132", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-error%22%7D", className: "text-lg font-semibold text-error", children: data?.dealsLost }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
                lineNumber: 132,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
              lineNumber: 130,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:134:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "134", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:135:16", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "135", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22Win%20Rate%22%7D", className: "text-sm text-text-secondary", children: "Win Rate" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
                lineNumber: 135,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:136:16", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "136", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%2C%22textContent%22%3A%22%25%22%7D", className: "text-lg font-semibold text-text-primary", children: [
                (data?.dealsWon / (data?.dealsWon + data?.dealsLost) * 100)?.toFixed(1),
                "%"
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
                lineNumber: 136,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
              lineNumber: 134,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
            lineNumber: 125,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
          lineNumber: 102,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
        lineNumber: 100,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
      lineNumber: 49,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:145:6", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "145", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-2%20lg%3Agrid-cols-4%20gap-4%20mt-8%20pt-6%20border-t%20border-border%22%7D", className: "grid grid-cols-2 lg:grid-cols-4 gap-4 mt-8 pt-6 border-t border-border", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:146:8", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "146", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-center%22%7D", className: "text-center", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:147:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "147", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-12%20h-12%20bg-primary-50%20rounded-lg%20flex%20items-center%20justify-center%20mx-auto%20mb-2%22%7D", className: "w-12 h-12 bg-primary-50 rounded-lg flex items-center justify-center mx-auto mb-2", children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:148:12", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "148", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22DollarSign%22%2C%22className%22%3A%22text-primary%22%7D", name: "DollarSign", size: 20, className: "text-primary" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
          lineNumber: 148,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
          lineNumber: 147,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:150:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "150", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22Avg%20Deal%20Size%22%7D", className: "text-sm text-text-secondary", children: "Avg Deal Size" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
          lineNumber: 150,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:151:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "151", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%2C%22textContent%22%3A%22%24%20K%22%7D", className: "text-lg font-semibold text-text-primary", children: [
          "$",
          (data?.avgDealSize / 1e3)?.toFixed(0),
          "K"
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
          lineNumber: 151,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
        lineNumber: 146,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:156:8", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "156", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-center%22%7D", className: "text-center", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:157:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "157", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-12%20h-12%20bg-success-50%20rounded-lg%20flex%20items-center%20justify-center%20mx-auto%20mb-2%22%7D", className: "w-12 h-12 bg-success-50 rounded-lg flex items-center justify-center mx-auto mb-2", children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:158:12", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "158", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22TrendingUp%22%2C%22className%22%3A%22text-success%22%7D", name: "TrendingUp", size: 20, className: "text-success" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
          lineNumber: 158,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
          lineNumber: 157,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:160:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "160", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22Conversion%20Rate%22%7D", className: "text-sm text-text-secondary", children: "Conversion Rate" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
          lineNumber: 160,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:161:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "161", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%2C%22textContent%22%3A%22%25%22%7D", className: "text-lg font-semibold text-text-primary", children: [
          data?.conversionRate,
          "%"
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
          lineNumber: 161,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
        lineNumber: 156,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:164:8", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "164", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-center%22%7D", className: "text-center", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:165:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "165", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-12%20h-12%20bg-accent-50%20rounded-lg%20flex%20items-center%20justify-center%20mx-auto%20mb-2%22%7D", className: "w-12 h-12 bg-accent-50 rounded-lg flex items-center justify-center mx-auto mb-2", children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:166:12", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "166", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Clock%22%2C%22className%22%3A%22text-accent%22%7D", name: "Clock", size: 20, className: "text-accent" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
          lineNumber: 166,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
          lineNumber: 165,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:168:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "168", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22Avg%20Sales%20Cycle%22%7D", className: "text-sm text-text-secondary", children: "Avg Sales Cycle" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
          lineNumber: 168,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:169:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "169", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%2C%22textContent%22%3A%2245%20days%22%7D", className: "text-lg font-semibold text-text-primary", children: "45 days" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
          lineNumber: 169,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
        lineNumber: 164,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:172:8", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "172", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-center%22%7D", className: "text-center", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:173:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "173", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-12%20h-12%20bg-secondary-50%20rounded-lg%20flex%20items-center%20justify-center%20mx-auto%20mb-2%22%7D", className: "w-12 h-12 bg-secondary-50 rounded-lg flex items-center justify-center mx-auto mb-2", children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:174:12", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "174", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Target%22%2C%22className%22%3A%22text-secondary%22%7D", name: "Target", size: 20, className: "text-secondary" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
          lineNumber: 174,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
          lineNumber: 173,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:176:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "176", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22Activities%22%7D", className: "text-sm text-text-secondary", children: "Activities" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
          lineNumber: 176,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:177:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "177", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%2C%22textContent%22%3A%22127%22%7D", className: "text-lg font-semibold text-text-primary", children: "127" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
          lineNumber: 177,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
        lineNumber: 172,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
      lineNumber: 145,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:181:6", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "181", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22mt-8%20pt-6%20border-t%20border-border%22%7D", className: "mt-8 pt-6 border-t border-border", children: [
      /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:182:8", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "182", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-medium%20text-text-primary%20mb-4%22%2C%22textContent%22%3A%22Monthly%20Performance%20Trend%22%7D", className: "text-lg font-medium text-text-primary mb-4", children: "Monthly Performance Trend" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
        lineNumber: 182,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:183:8", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "183", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22h-64%22%7D", className: "h-64", children: /* @__PURE__ */ jsxDEV(ResponsiveContainer, { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:184:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "184", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "ResponsiveContainer", "data-component-content": "%7B%22elementName%22%3A%22ResponsiveContainer%22%7D", width: "100%", height: "100%", children: /* @__PURE__ */ jsxDEV(BarChart, { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:185:12", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "185", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "BarChart", "data-component-content": "%7B%22elementName%22%3A%22BarChart%22%7D", data: monthlyPerformance, children: [
        /* @__PURE__ */ jsxDEV(CartesianGrid, { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:186:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "186", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "CartesianGrid", "data-component-content": "%7B%22elementName%22%3A%22CartesianGrid%22%7D", strokeDasharray: "3 3", stroke: "#E5E7EB" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
          lineNumber: 186,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(XAxis, { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:187:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "187", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "XAxis", "data-component-content": "%7B%22elementName%22%3A%22XAxis%22%7D", dataKey: "month", stroke: "#6B7280" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
          lineNumber: 187,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(YAxis, { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:188:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "188", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "YAxis", "data-component-content": "%7B%22elementName%22%3A%22YAxis%22%7D", stroke: "#6B7280", tickFormatter: (value) => `$${value / 1e3}K` }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
          lineNumber: 188,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          Tooltip,
          {
            "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:189:14",
            "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx",
            "data-component-line": "189",
            "data-component-file": "PerformanceMetrics.jsx",
            "data-component-name": "Tooltip",
            "data-component-content": "%7B%22elementName%22%3A%22Tooltip%22%7D",
            formatter: (value) => [`$${value?.toLocaleString()}`, ""],
            labelStyle: { color: "#1F2937" }
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
            lineNumber: 189,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(Bar, { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:193:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "193", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "Bar", "data-component-content": "%7B%22elementName%22%3A%22Bar%22%2C%22name%22%3A%22Target%22%7D", dataKey: "target", fill: "#E5E7EB", name: "Target" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
          lineNumber: 193,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(Bar, { "data-component-id": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx:194:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\PerformanceMetrics.jsx", "data-component-line": "194", "data-component-file": "PerformanceMetrics.jsx", "data-component-name": "Bar", "data-component-content": "%7B%22elementName%22%3A%22Bar%22%2C%22name%22%3A%22Actual%22%7D", dataKey: "actual", fill: "var(--color-primary)", name: "Actual" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
          lineNumber: 194,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
        lineNumber: 185,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
        lineNumber: 184,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
        lineNumber: 183,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
      lineNumber: 181,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx",
    lineNumber: 47,
    columnNumber: 5
  }, this);
};
_c = PerformanceMetrics;
export default PerformanceMetrics;
var _c;
$RefreshReg$(_c, "PerformanceMetrics");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/sales-dashboard/components/PerformanceMetrics.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0JNO0FBL0JOLE9BQU9BLG9CQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN6QixTQUFTQyxVQUFVQyxLQUFLQyxNQUFNQyxxQkFBcUJDLFVBQVVDLEtBQUtDLE9BQU9DLE9BQU9DLGVBQWVDLGVBQWU7QUFDOUcsT0FBT0MsVUFBVTtBQUVqQixNQUFNQyxxQkFBcUJBLENBQUMsRUFBRUMsS0FBSyxNQUFNO0FBQ3ZDLFFBQU1DLFlBQVk7QUFBQSxJQUNoQixFQUFFQyxNQUFNLFlBQVlDLE9BQU9ILE1BQU1JLFVBQVVDLE9BQU8sVUFBVTtBQUFBLElBQzVELEVBQUVILE1BQU0sYUFBYUMsT0FBT0gsTUFBTU0sUUFBUU4sTUFBTUksVUFBVUMsT0FBTyxVQUFVO0FBQUEsRUFBQztBQUc5RSxRQUFNRSxrQkFBa0I7QUFBQSxJQUN0QixFQUFFTCxNQUFNLE9BQU9DLE9BQU9ILE1BQU1RLFVBQVVILE9BQU8sVUFBVTtBQUFBLElBQ3ZELEVBQUVILE1BQU0sUUFBUUMsT0FBT0gsTUFBTVMsV0FBV0osT0FBTyxVQUFVO0FBQUEsRUFBQztBQUc1RCxRQUFNSyxxQkFBcUI7QUFBQSxJQUN6QixFQUFFQyxPQUFPLE9BQU9DLFFBQVEsS0FBUUMsUUFBUSxLQUFPO0FBQUEsSUFDL0MsRUFBRUYsT0FBTyxPQUFPQyxRQUFRLE1BQVFDLFFBQVEsTUFBTztBQUFBLElBQy9DLEVBQUVGLE9BQU8sT0FBT0MsUUFBUSxLQUFRQyxRQUFRLE1BQU87QUFBQSxJQUMvQyxFQUFFRixPQUFPLE9BQU9DLFFBQVEsTUFBUUMsUUFBUSxNQUFPO0FBQUEsSUFDL0MsRUFBRUYsT0FBTyxPQUFPQyxRQUFRLE1BQVFDLFFBQVEsTUFBTztBQUFBLElBQy9DLEVBQUVGLE9BQU8sT0FBT0MsUUFBUSxLQUFRQyxRQUFRLEtBQU87QUFBQSxFQUFDO0FBR2xELFFBQU1DLFNBQVNDLEtBQUtDLEtBQUs7QUFDekIsUUFBTUMsd0JBQXdCQSxDQUFDLEVBQUVDLElBQUlDLElBQUlDLFVBQVVDLGFBQWFDLGFBQWFDLFFBQVEsTUFBTTtBQUN6RixVQUFNQyxTQUFTSCxlQUFlQyxjQUFjRCxlQUFlO0FBQzNELFVBQU1JLElBQUlQLEtBQUtNLFNBQVNULEtBQUtXLElBQUksQ0FBQ04sV0FBV04sTUFBTTtBQUNuRCxVQUFNYSxJQUFJUixLQUFLSyxTQUFTVCxLQUFLYSxJQUFJLENBQUNSLFdBQVdOLE1BQU07QUFFbkQsV0FDRTtBQUFBLE1BQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBO0FBQUEsUUFDQSxNQUFLO0FBQUEsUUFDTCxZQUFZVyxJQUFJUCxLQUFLLFVBQVU7QUFBQSxRQUMvQixrQkFBaUI7QUFBQSxRQUNqQixVQUFTO0FBQUEsUUFDVCxZQUFXO0FBQUEsUUFFVixjQUFJSyxVQUFVLE1BQU1NLFFBQVEsQ0FBQyxDQUFDO0FBQUE7QUFBQSxNQVRqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFVQTtBQUFBLEVBRUo7QUFFQSxTQUNFLHVCQUFDLGtaQUFJLFdBQVUsWUFDYjtBQUFBLDJCQUFDLHllQUFHLFdBQVUsZ0RBQStDLG1DQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdGO0FBQUEsSUFDaEYsdUJBQUMscWJBQUksV0FBVSx5Q0FFYjtBQUFBLDZCQUFDLDZXQUNDO0FBQUEsK0JBQUMsc2VBQUcsV0FBVSw4Q0FBNkMsaUNBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEU7QUFBQSxRQUM1RSx1QkFBQyx3YUFBSSxXQUFVLCtCQUNiO0FBQUEsaUNBQUMsb1pBQUksV0FBVSxhQUNiLGlDQUFDLDRaQUFvQixPQUFNLFFBQU8sUUFBTyxRQUN2QyxpQ0FBQywyWEFDQztBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsTUFBTTVCO0FBQUFBLGNBQ04sSUFBRztBQUFBLGNBQ0gsSUFBRztBQUFBLGNBQ0gsV0FBVztBQUFBLGNBQ1gsT0FBT2dCO0FBQUFBLGNBQ1AsYUFBYTtBQUFBLGNBQ2IsTUFBSztBQUFBLGNBQ0wsU0FBUTtBQUFBLGNBQ1IsYUFBYTtBQUFBLGNBRVpoQixxQkFBVzZCO0FBQUFBLGdCQUFJLENBQUNDLE9BQU9DLFVBQ3RCLHVCQUFDLCtXQUEyQixNQUFNRCxPQUFPMUIsU0FBOUIsUUFBUTJCLEtBQUssSUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0M7QUFBQSxjQUNoRDtBQUFBO0FBQUEsWUFiSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFjQSxLQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0JBLEtBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0JBLEtBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0JBO0FBQUEsVUFFQSx1QkFBQyxrWkFBSSxXQUFVLGFBQ2I7QUFBQSxtQ0FBQyw4V0FDQztBQUFBLHFDQUFDLGtjQUFFLFdBQVUsK0JBQThCLHFCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnRDtBQUFBLGNBQ2hELHVCQUFDLGtkQUFFLFdBQVUsMkNBQTBDO0FBQUE7QUFBQSxpQkFDbERoQyxNQUFNTSxRQUFRLE1BQVV1QixRQUFRLENBQUM7QUFBQSxnQkFBRTtBQUFBLG1CQUR4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBQ0EsdUJBQUMsOFdBQ0M7QUFBQSxxQ0FBQyxxY0FBRSxXQUFVLCtCQUE4Qix3QkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUQ7QUFBQSxjQUNuRCx1QkFBQyw2Y0FBRSxXQUFVLHNDQUFxQztBQUFBO0FBQUEsaUJBQzdDN0IsTUFBTUksV0FBVyxNQUFVeUIsUUFBUSxDQUFDO0FBQUEsZ0JBQUU7QUFBQSxtQkFEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxZQUNBLHVCQUFDLDhXQUNDO0FBQUEscUNBQUMsc2NBQUUsV0FBVSwrQkFBOEIseUJBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9EO0FBQUEsY0FDcEQsdUJBQUMsa2RBQUUsV0FBVSwyQ0FBMEM7QUFBQTtBQUFBLGtCQUNqRDdCLE1BQU1NLFFBQVFOLE1BQU1JLFlBQVksTUFBVXlCLFFBQVEsQ0FBQztBQUFBLGdCQUFFO0FBQUEsbUJBRDNEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsZUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQkE7QUFBQSxhQTFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMkNBO0FBQUEsV0E3Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQThDQTtBQUFBLE1BR0EsdUJBQUMsK1dBQ0M7QUFBQSwrQkFBQyxvZUFBRyxXQUFVLDhDQUE2Qyw2QkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RTtBQUFBLFFBQ3hFLHVCQUFDLDBhQUFJLFdBQVUsK0JBQ2I7QUFBQSxpQ0FBQyxzWkFBSSxXQUFVLGFBQ2IsaUNBQUMsOFpBQW9CLE9BQU0sUUFBTyxRQUFPLFFBQ3ZDLGlDQUFDLDZYQUNDO0FBQUEsWUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FDQyxNQUFNdEI7QUFBQUEsY0FDTixJQUFHO0FBQUEsY0FDSCxJQUFHO0FBQUEsY0FDSCxXQUFXO0FBQUEsY0FDWCxPQUFPVTtBQUFBQSxjQUNQLGFBQWE7QUFBQSxjQUNiLE1BQUs7QUFBQSxjQUNMLFNBQVE7QUFBQSxjQUNSLGFBQWE7QUFBQSxjQUVaViwyQkFBaUJ1QjtBQUFBQSxnQkFBSSxDQUFDQyxPQUFPQyxVQUM1Qix1QkFBQyxpWEFBMkIsTUFBTUQsT0FBTzFCLFNBQTlCLFFBQVEyQixLQUFLLElBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStDO0FBQUEsY0FDaEQ7QUFBQTtBQUFBLFlBYkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBY0EsS0FmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdCQSxLQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtCQSxLQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9CQTtBQUFBLFVBRUEsdUJBQUMsb1pBQUksV0FBVSxhQUNiO0FBQUEsbUNBQUMsZ1hBQ0M7QUFBQSxxQ0FBQywwY0FBRSxXQUFVLCtCQUE4Qix5QkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0Q7QUFBQSxjQUNwRCx1QkFBQywyYUFBRSxXQUFVLHNDQUFzQ2hDLGdCQUFNUSxZQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrRTtBQUFBLGlCQUZwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxnWEFDQztBQUFBLHFDQUFDLDJjQUFFLFdBQVUsK0JBQThCLDBCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxRDtBQUFBLGNBQ3JELHVCQUFDLHlhQUFFLFdBQVUsb0NBQW9DUixnQkFBTVMsYUFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUU7QUFBQSxpQkFGbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsZ1hBQ0M7QUFBQSxxQ0FBQyx5Y0FBRSxXQUFVLCtCQUE4Qix3QkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUQ7QUFBQSxjQUNuRCx1QkFBQyxnZEFBRSxXQUFVLDJDQUNSVDtBQUFBQSx1QkFBTVEsWUFBWVIsTUFBTVEsV0FBV1IsTUFBTVMsYUFBYyxNQUFNb0IsUUFBUSxDQUFDO0FBQUEsZ0JBQUU7QUFBQSxtQkFEN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxlQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZUE7QUFBQSxhQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdUNBO0FBQUEsV0F6Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTBDQTtBQUFBLFNBN0ZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4RkE7QUFBQSxJQUVBLHVCQUFDLGdlQUFJLFdBQVUsMEVBQ2I7QUFBQSw2QkFBQyxxWkFBSSxXQUFVLGVBQ2I7QUFBQSwrQkFBQywyZUFBSSxXQUFVLG9GQUNiLGlDQUFDLHdiQUFLLE1BQUssY0FBYSxNQUFNLElBQUksV0FBVSxrQkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRCxLQUQ1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLGdkQUFFLFdBQVUsK0JBQThCLDZCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdEO0FBQUEsUUFDeEQsdUJBQUMsb2RBQUUsV0FBVSwyQ0FBMEM7QUFBQTtBQUFBLFdBQ2xEN0IsTUFBTWlDLGNBQWMsTUFBT0osUUFBUSxDQUFDO0FBQUEsVUFBRTtBQUFBLGFBRDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFFQSx1QkFBQyxxWkFBSSxXQUFVLGVBQ2I7QUFBQSwrQkFBQywyZUFBSSxXQUFVLG9GQUNiLGlDQUFDLHdiQUFLLE1BQUssY0FBYSxNQUFNLElBQUksV0FBVSxrQkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRCxLQUQ1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLGdkQUFFLFdBQVUsK0JBQThCLCtCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBEO0FBQUEsUUFDMUQsdUJBQUMsZ2RBQUUsV0FBVSwyQ0FBMkM3QjtBQUFBQSxnQkFBTWtDO0FBQUFBLFVBQWU7QUFBQSxhQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThFO0FBQUEsV0FMaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsTUFFQSx1QkFBQyxxWkFBSSxXQUFVLGVBQ2I7QUFBQSwrQkFBQywwZUFBSSxXQUFVLG1GQUNiLGlDQUFDLGtiQUFLLE1BQUssU0FBUSxNQUFNLElBQUksV0FBVSxpQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRCxLQUR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLGtkQUFFLFdBQVUsK0JBQThCLCtCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBEO0FBQUEsUUFDMUQsdUJBQUMsc2RBQUUsV0FBVSwyQ0FBMEMsdUJBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEQ7QUFBQSxXQUxoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUE7QUFBQSxNQUVBLHVCQUFDLHFaQUFJLFdBQVUsZUFDYjtBQUFBLCtCQUFDLDZlQUFJLFdBQVUsc0ZBQ2IsaUNBQUMsc2JBQUssTUFBSyxVQUFTLE1BQU0sSUFBSSxXQUFVLG9CQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdELEtBRDFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMseWNBQUUsV0FBVSwrQkFBOEIsMEJBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUQ7QUFBQSxRQUNyRCx1QkFBQyxnZEFBRSxXQUFVLDJDQUEwQyxtQkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRDtBQUFBLFdBTDVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNQTtBQUFBLFNBakNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrQ0E7QUFBQSxJQUVBLHVCQUFDLGdiQUFJLFdBQVUsb0NBQ2I7QUFBQSw2QkFBQyxpZkFBRyxXQUFVLDhDQUE2Qyx5Q0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvRjtBQUFBLE1BQ3BGLHVCQUFDLDhZQUFJLFdBQVUsUUFDYixpQ0FBQyw4WkFBb0IsT0FBTSxRQUFPLFFBQU8sUUFDdkMsaUNBQUMsNlhBQVMsTUFBTXhCLG9CQUNkO0FBQUEsK0JBQUMsNFlBQWMsaUJBQWdCLE9BQU0sUUFBTyxhQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFEO0FBQUEsUUFDckQsdUJBQUMsb1hBQU0sU0FBUSxTQUFRLFFBQU8sYUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QztBQUFBLFFBQ3ZDLHVCQUFDLG9YQUFNLFFBQU8sV0FBVSxlQUFlLENBQUNQLFVBQVUsSUFBSUEsUUFBUSxHQUFJLE9BQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0U7QUFBQSxRQUN0RTtBQUFBLFVBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBQ0MsV0FBVyxDQUFDQSxVQUFVLENBQUMsSUFBSUEsT0FBT2dDLGVBQWUsQ0FBQyxJQUFJLEVBQUU7QUFBQSxZQUN4RCxZQUFZLEVBQUU5QixPQUFPLFVBQVU7QUFBQTtBQUFBLFVBRmpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUVtQztBQUFBLFFBRW5DLHVCQUFDLDBZQUFJLFNBQVEsVUFBUyxNQUFLLFdBQVUsTUFBSyxZQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtEO0FBQUEsUUFDbEQsdUJBQUMsMFlBQUksU0FBUSxVQUFTLE1BQUssd0JBQXVCLE1BQUssWUFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRDtBQUFBLFdBVGpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQSxLQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFZQSxLQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFjQTtBQUFBLFNBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpQkE7QUFBQSxPQXZKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBd0pBO0FBRUo7QUFBRStCLEtBcE1JckM7QUFzTU4sZUFBZUE7QUFBbUIsSUFBQXFDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsIlBpZUNoYXJ0IiwiUGllIiwiQ2VsbCIsIlJlc3BvbnNpdmVDb250YWluZXIiLCJCYXJDaGFydCIsIkJhciIsIlhBeGlzIiwiWUF4aXMiLCJDYXJ0ZXNpYW5HcmlkIiwiVG9vbHRpcCIsIkljb24iLCJQZXJmb3JtYW5jZU1ldHJpY3MiLCJkYXRhIiwicXVvdGFEYXRhIiwibmFtZSIsInZhbHVlIiwiYWNoaWV2ZWQiLCJjb2xvciIsInF1b3RhIiwiZGVhbE91dGNvbWVEYXRhIiwiZGVhbHNXb24iLCJkZWFsc0xvc3QiLCJtb250aGx5UGVyZm9ybWFuY2UiLCJtb250aCIsInRhcmdldCIsImFjdHVhbCIsIlJBRElBTiIsIk1hdGgiLCJQSSIsInJlbmRlckN1c3RvbWl6ZWRMYWJlbCIsImN4IiwiY3kiLCJtaWRBbmdsZSIsImlubmVyUmFkaXVzIiwib3V0ZXJSYWRpdXMiLCJwZXJjZW50IiwicmFkaXVzIiwieCIsImNvcyIsInkiLCJzaW4iLCJ0b0ZpeGVkIiwibWFwIiwiZW50cnkiLCJpbmRleCIsImF2Z0RlYWxTaXplIiwiY29udmVyc2lvblJhdGUiLCJ0b0xvY2FsZVN0cmluZyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUGVyZm9ybWFuY2VNZXRyaWNzLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBQaWVDaGFydCwgUGllLCBDZWxsLCBSZXNwb25zaXZlQ29udGFpbmVyLCBCYXJDaGFydCwgQmFyLCBYQXhpcywgWUF4aXMsIENhcnRlc2lhbkdyaWQsIFRvb2x0aXAgfSBmcm9tICdyZWNoYXJ0cyc7XHJcbmltcG9ydCBJY29uIGZyb20gJ2NvbXBvbmVudHMvQXBwSWNvbic7XHJcblxyXG5jb25zdCBQZXJmb3JtYW5jZU1ldHJpY3MgPSAoeyBkYXRhIH0pID0+IHtcclxuICBjb25zdCBxdW90YURhdGEgPSBbXHJcbiAgICB7IG5hbWU6ICdBY2hpZXZlZCcsIHZhbHVlOiBkYXRhPy5hY2hpZXZlZCwgY29sb3I6ICcjMTBCOTgxJyB9LFxyXG4gICAgeyBuYW1lOiAnUmVtYWluaW5nJywgdmFsdWU6IGRhdGE/LnF1b3RhIC0gZGF0YT8uYWNoaWV2ZWQsIGNvbG9yOiAnI0U1RTdFQicgfVxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGRlYWxPdXRjb21lRGF0YSA9IFtcclxuICAgIHsgbmFtZTogJ1dvbicsIHZhbHVlOiBkYXRhPy5kZWFsc1dvbiwgY29sb3I6ICcjMTBCOTgxJyB9LFxyXG4gICAgeyBuYW1lOiAnTG9zdCcsIHZhbHVlOiBkYXRhPy5kZWFsc0xvc3QsIGNvbG9yOiAnI0VGNDQ0NCcgfVxyXG4gIF07XHJcblxyXG4gIGNvbnN0IG1vbnRobHlQZXJmb3JtYW5jZSA9IFtcclxuICAgIHsgbW9udGg6ICdKYW4nLCB0YXJnZXQ6IDQwMDAwMCwgYWN0dWFsOiA0MjAwMDAgfSxcclxuICAgIHsgbW9udGg6ICdGZWInLCB0YXJnZXQ6IDQ1MDAwMCwgYWN0dWFsOiA0ODUwMDAgfSxcclxuICAgIHsgbW9udGg6ICdNYXInLCB0YXJnZXQ6IDUwMDAwMCwgYWN0dWFsOiA1NjIwMDAgfSxcclxuICAgIHsgbW9udGg6ICdBcHInLCB0YXJnZXQ6IDUyMDAwMCwgYWN0dWFsOiA1OTgwMDAgfSxcclxuICAgIHsgbW9udGg6ICdNYXknLCB0YXJnZXQ6IDU1MDAwMCwgYWN0dWFsOiA2NDUwMDAgfSxcclxuICAgIHsgbW9udGg6ICdKdW4nLCB0YXJnZXQ6IDYwMDAwMCwgYWN0dWFsOiA1ODAwMDAgfVxyXG4gIF07XHJcblxyXG4gIGNvbnN0IFJBRElBTiA9IE1hdGguUEkgLyAxODA7XHJcbiAgY29uc3QgcmVuZGVyQ3VzdG9taXplZExhYmVsID0gKHsgY3gsIGN5LCBtaWRBbmdsZSwgaW5uZXJSYWRpdXMsIG91dGVyUmFkaXVzLCBwZXJjZW50IH0pID0+IHtcclxuICAgIGNvbnN0IHJhZGl1cyA9IGlubmVyUmFkaXVzICsgKG91dGVyUmFkaXVzIC0gaW5uZXJSYWRpdXMpICogMC41O1xyXG4gICAgY29uc3QgeCA9IGN4ICsgcmFkaXVzICogTWF0aC5jb3MoLW1pZEFuZ2xlICogUkFESUFOKTtcclxuICAgIGNvbnN0IHkgPSBjeSArIHJhZGl1cyAqIE1hdGguc2luKC1taWRBbmdsZSAqIFJBRElBTik7XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgPHRleHQgXHJcbiAgICAgICAgeD17eH0gXHJcbiAgICAgICAgeT17eX0gXHJcbiAgICAgICAgZmlsbD1cIndoaXRlXCIgXHJcbiAgICAgICAgdGV4dEFuY2hvcj17eCA+IGN4ID8gJ3N0YXJ0JyA6ICdlbmQnfSBcclxuICAgICAgICBkb21pbmFudEJhc2VsaW5lPVwiY2VudHJhbFwiXHJcbiAgICAgICAgZm9udFNpemU9XCIxMlwiXHJcbiAgICAgICAgZm9udFdlaWdodD1cIjYwMFwiXHJcbiAgICAgID5cclxuICAgICAgICB7YCR7KHBlcmNlbnQgKiAxMDApPy50b0ZpeGVkKDApfSVgfVxyXG4gICAgICA8L3RleHQ+XHJcbiAgICApO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgcC02XCI+XHJcbiAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtc2VtaWJvbGQgdGV4dC10ZXh0LXByaW1hcnkgbWItNlwiPlBlcmZvcm1hbmNlIE1ldHJpY3M8L2gyPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbGc6Z3JpZC1jb2xzLTIgZ2FwLThcIj5cclxuICAgICAgICB7LyogUXVvdGEgQWNoaWV2ZW1lbnQgKi99XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IG1iLTRcIj5RdW90YSBBY2hpZXZlbWVudDwvaDM+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtNlwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMzIgaC0zMlwiPlxyXG4gICAgICAgICAgICAgIDxSZXNwb25zaXZlQ29udGFpbmVyIHdpZHRoPVwiMTAwJVwiIGhlaWdodD1cIjEwMCVcIj5cclxuICAgICAgICAgICAgICAgIDxQaWVDaGFydD5cclxuICAgICAgICAgICAgICAgICAgPFBpZVxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGE9e3F1b3RhRGF0YX1cclxuICAgICAgICAgICAgICAgICAgICBjeD1cIjUwJVwiXHJcbiAgICAgICAgICAgICAgICAgICAgY3k9XCI1MCVcIlxyXG4gICAgICAgICAgICAgICAgICAgIGxhYmVsTGluZT17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgbGFiZWw9e3JlbmRlckN1c3RvbWl6ZWRMYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICBvdXRlclJhZGl1cz17NjB9XHJcbiAgICAgICAgICAgICAgICAgICAgZmlsbD1cIiM4ODg0ZDhcIlxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGFLZXk9XCJ2YWx1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9ezB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7cXVvdGFEYXRhPy5tYXAoKGVudHJ5LCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPENlbGwga2V5PXtgY2VsbC0ke2luZGV4fWB9IGZpbGw9e2VudHJ5Py5jb2xvcn0gLz5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9QaWU+XHJcbiAgICAgICAgICAgICAgICA8L1BpZUNoYXJ0PlxyXG4gICAgICAgICAgICAgIDwvUmVzcG9uc2l2ZUNvbnRhaW5lcj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtdGV4dC1zZWNvbmRhcnlcIj5RdW90YTwvcD5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXRleHQtcHJpbWFyeVwiPlxyXG4gICAgICAgICAgICAgICAgICAkeyhkYXRhPy5xdW90YSAvIDEwMDAwMDApPy50b0ZpeGVkKDEpfU1cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+QWNoaWV2ZWQ8L3A+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1zdWNjZXNzXCI+XHJcbiAgICAgICAgICAgICAgICAgICR7KGRhdGE/LmFjaGlldmVkIC8gMTAwMDAwMCk/LnRvRml4ZWQoMSl9TVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtdGV4dC1zZWNvbmRhcnlcIj5SZW1haW5pbmc8L3A+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC10ZXh0LXByaW1hcnlcIj5cclxuICAgICAgICAgICAgICAgICAgJHsoKGRhdGE/LnF1b3RhIC0gZGF0YT8uYWNoaWV2ZWQpIC8gMTAwMDAwMCk/LnRvRml4ZWQoMSl9TVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogRGVhbCBPdXRjb21lcyAqL31cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItNFwiPkRlYWwgT3V0Y29tZXM8L2gzPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTZcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTMyIGgtMzJcIj5cclxuICAgICAgICAgICAgICA8UmVzcG9uc2l2ZUNvbnRhaW5lciB3aWR0aD1cIjEwMCVcIiBoZWlnaHQ9XCIxMDAlXCI+XHJcbiAgICAgICAgICAgICAgICA8UGllQ2hhcnQ+XHJcbiAgICAgICAgICAgICAgICAgIDxQaWVcclxuICAgICAgICAgICAgICAgICAgICBkYXRhPXtkZWFsT3V0Y29tZURhdGF9XHJcbiAgICAgICAgICAgICAgICAgICAgY3g9XCI1MCVcIlxyXG4gICAgICAgICAgICAgICAgICAgIGN5PVwiNTAlXCJcclxuICAgICAgICAgICAgICAgICAgICBsYWJlbExpbmU9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgIGxhYmVsPXtyZW5kZXJDdXN0b21pemVkTGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgICAgb3V0ZXJSYWRpdXM9ezYwfVxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGw9XCIjODg4NGQ4XCJcclxuICAgICAgICAgICAgICAgICAgICBkYXRhS2V5PVwidmFsdWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPXswfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge2RlYWxPdXRjb21lRGF0YT8ubWFwKChlbnRyeSwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxDZWxsIGtleT17YGNlbGwtJHtpbmRleH1gfSBmaWxsPXtlbnRyeT8uY29sb3J9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvUGllPlxyXG4gICAgICAgICAgICAgICAgPC9QaWVDaGFydD5cclxuICAgICAgICAgICAgICA8L1Jlc3BvbnNpdmVDb250YWluZXI+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+RGVhbHMgV29uPC9wPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtc3VjY2Vzc1wiPntkYXRhPy5kZWFsc1dvbn08L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC10ZXh0LXNlY29uZGFyeVwiPkRlYWxzIExvc3Q8L3A+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1lcnJvclwiPntkYXRhPy5kZWFsc0xvc3R9PC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtdGV4dC1zZWNvbmRhcnlcIj5XaW4gUmF0ZTwvcD5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXRleHQtcHJpbWFyeVwiPlxyXG4gICAgICAgICAgICAgICAgICB7KChkYXRhPy5kZWFsc1dvbiAvIChkYXRhPy5kZWFsc1dvbiArIGRhdGE/LmRlYWxzTG9zdCkpICogMTAwKT8udG9GaXhlZCgxKX0lXHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICB7LyogS2V5IE1ldHJpY3MgR3JpZCAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGxnOmdyaWQtY29scy00IGdhcC00IG10LTggcHQtNiBib3JkZXItdCBib3JkZXItYm9yZGVyXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgYmctcHJpbWFyeS01MCByb3VuZGVkLWxnIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG14LWF1dG8gbWItMlwiPlxyXG4gICAgICAgICAgICA8SWNvbiBuYW1lPVwiRG9sbGFyU2lnblwiIHNpemU9ezIwfSBjbGFzc05hbWU9XCJ0ZXh0LXByaW1hcnlcIiAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtdGV4dC1zZWNvbmRhcnlcIj5BdmcgRGVhbCBTaXplPC9wPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtdGV4dC1wcmltYXJ5XCI+XHJcbiAgICAgICAgICAgICR7KGRhdGE/LmF2Z0RlYWxTaXplIC8gMTAwMCk/LnRvRml4ZWQoMCl9S1xyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMiBoLTEyIGJnLXN1Y2Nlc3MtNTAgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBteC1hdXRvIG1iLTJcIj5cclxuICAgICAgICAgICAgPEljb24gbmFtZT1cIlRyZW5kaW5nVXBcIiBzaXplPXsyMH0gY2xhc3NOYW1lPVwidGV4dC1zdWNjZXNzXCIgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+Q29udmVyc2lvbiBSYXRlPC9wPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtdGV4dC1wcmltYXJ5XCI+e2RhdGE/LmNvbnZlcnNpb25SYXRlfSU8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgYmctYWNjZW50LTUwIHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbXgtYXV0byBtYi0yXCI+XHJcbiAgICAgICAgICAgIDxJY29uIG5hbWU9XCJDbG9ja1wiIHNpemU9ezIwfSBjbGFzc05hbWU9XCJ0ZXh0LWFjY2VudFwiIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC10ZXh0LXNlY29uZGFyeVwiPkF2ZyBTYWxlcyBDeWNsZTwvcD5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXRleHQtcHJpbWFyeVwiPjQ1IGRheXM8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgYmctc2Vjb25kYXJ5LTUwIHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbXgtYXV0byBtYi0yXCI+XHJcbiAgICAgICAgICAgIDxJY29uIG5hbWU9XCJUYXJnZXRcIiBzaXplPXsyMH0gY2xhc3NOYW1lPVwidGV4dC1zZWNvbmRhcnlcIiAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtdGV4dC1zZWNvbmRhcnlcIj5BY3Rpdml0aWVzPC9wPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtdGV4dC1wcmltYXJ5XCI+MTI3PC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgey8qIE1vbnRobHkgUGVyZm9ybWFuY2UgVHJlbmQgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtOCBwdC02IGJvcmRlci10IGJvcmRlci1ib3JkZXJcIj5cclxuICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSBtYi00XCI+TW9udGhseSBQZXJmb3JtYW5jZSBUcmVuZDwvaDM+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTY0XCI+XHJcbiAgICAgICAgICA8UmVzcG9uc2l2ZUNvbnRhaW5lciB3aWR0aD1cIjEwMCVcIiBoZWlnaHQ9XCIxMDAlXCI+XHJcbiAgICAgICAgICAgIDxCYXJDaGFydCBkYXRhPXttb250aGx5UGVyZm9ybWFuY2V9PlxyXG4gICAgICAgICAgICAgIDxDYXJ0ZXNpYW5HcmlkIHN0cm9rZURhc2hhcnJheT1cIjMgM1wiIHN0cm9rZT1cIiNFNUU3RUJcIiAvPlxyXG4gICAgICAgICAgICAgIDxYQXhpcyBkYXRhS2V5PVwibW9udGhcIiBzdHJva2U9XCIjNkI3MjgwXCIgLz5cclxuICAgICAgICAgICAgICA8WUF4aXMgc3Ryb2tlPVwiIzZCNzI4MFwiIHRpY2tGb3JtYXR0ZXI9eyh2YWx1ZSkgPT4gYCQke3ZhbHVlIC8gMTAwMH1LYH0gLz5cclxuICAgICAgICAgICAgICA8VG9vbHRpcCBcclxuICAgICAgICAgICAgICAgIGZvcm1hdHRlcj17KHZhbHVlKSA9PiBbYCQke3ZhbHVlPy50b0xvY2FsZVN0cmluZygpfWAsICcnXX1cclxuICAgICAgICAgICAgICAgIGxhYmVsU3R5bGU9e3sgY29sb3I6ICcjMUYyOTM3JyB9fVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPEJhciBkYXRhS2V5PVwidGFyZ2V0XCIgZmlsbD1cIiNFNUU3RUJcIiBuYW1lPVwiVGFyZ2V0XCIgLz5cclxuICAgICAgICAgICAgICA8QmFyIGRhdGFLZXk9XCJhY3R1YWxcIiBmaWxsPVwidmFyKC0tY29sb3ItcHJpbWFyeSlcIiBuYW1lPVwiQWN0dWFsXCIgLz5cclxuICAgICAgICAgICAgPC9CYXJDaGFydD5cclxuICAgICAgICAgIDwvUmVzcG9uc2l2ZUNvbnRhaW5lcj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgUGVyZm9ybWFuY2VNZXRyaWNzOyJdLCJmaWxlIjoiRDovY3VycmVudCBwcm9qZWN0cy9jbGF1ZGUtY29kZS9zcmMvcGFnZXMvc2FsZXMtZGFzaGJvYXJkL2NvbXBvbmVudHMvUGVyZm9ybWFuY2VNZXRyaWNzLmpzeCJ9