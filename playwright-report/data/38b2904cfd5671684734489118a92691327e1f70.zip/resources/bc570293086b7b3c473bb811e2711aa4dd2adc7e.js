import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/activity-timeline/index.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import Header from "/src/components/ui/Header.jsx";
import Breadcrumb from "/src/components/ui/Breadcrumb.jsx";
import Icon from "/src/components/AppIcon.jsx";
import { useAuth } from "/src/contexts/AuthContext.jsx";
import activitiesService from "/src/services/activitiesService.js";
import ActivityCard from "/src/pages/activity-timeline/components/ActivityCard.jsx";
import ActivityFilters from "/src/pages/activity-timeline/components/ActivityFilters.jsx";
import AddActivityModal from "/src/pages/activity-timeline/components/AddActivityModal.jsx";
const ActivityTimeline = () => {
  _s();
  const { user } = useAuth();
  const [activities, setActivities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [selectedFilters, setSelectedFilters] = useState({
    activityType: "all",
    dateRange: "all",
    teamMember: "all",
    channel: "all"
  });
  const [searchQuery, setSearchQuery] = useState("");
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const loadActivities = async () => {
    if (!user)
      return;
    console.log("Starting to load activities...");
    try {
      setLoading(true);
      setError("");
      const data = await activitiesService.getUserActivities();
      console.log("Data received from activitiesService:", data);
      setActivities(data);
    } catch (err) {
      console.error("Error loading activities:", err);
      setError("Failed to load activities. Please try again.");
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    loadActivities();
  }, [user]);
  const handleActivityAdded = (newActivity) => {
    setActivities((prevActivities) => [newActivity, ...prevActivities]);
  };
  const transformedActivities = useMemo(() => {
    return activities.map((activity) => ({
      id: activity.id,
      type: activity.type,
      channel: activity.channel || "system",
      title: activity.subject,
      description: activity.description,
      contact: activity.contact ? `${activity.contact.first_name} ${activity.contact.last_name}` : "N/A",
      company: activity.contact?.company?.name || "N/A",
      timestamp: new Date(activity.created_at),
      user: activity.user ? `${activity.user.first_name} ${activity.user.last_name}` : "System",
      avatar: activity.user?.avatar_url || null,
      contactAvatar: activity.contact?.avatar_url || null,
      status: activity.status,
      priority: activity.priority,
      dealValue: activity.deal ? `${activity.deal.value?.toLocaleString()}` : null,
      attachments: activity.attachments || [],
      duration: activity.duration_minutes ? `${activity.duration_minutes} min` : null,
      previousStage: activity.metadata?.previous_stage,
      currentStage: activity.metadata?.current_stage,
      probability: activity.metadata?.probability,
      meetingType: activity.metadata?.meeting_type,
      location: activity.metadata?.location,
      attendees: activity.metadata?.attendees,
      callType: activity.metadata?.call_type
    }));
  }, [activities]);
  const filteredActivities = useMemo(() => {
    return transformedActivities.filter((activity) => {
      const matchesType = selectedFilters.activityType === "all" || activity.type === selectedFilters.activityType;
      const matchesChannel = selectedFilters.channel === "all" || activity.channel === selectedFilters.channel;
      const lowerCaseQuery = searchQuery.toLowerCase();
      const matchesSearch = searchQuery === "" || activity.title?.toLowerCase().includes(lowerCaseQuery) || activity.description?.toLowerCase().includes(lowerCaseQuery) || activity.contact?.toLowerCase().includes(lowerCaseQuery) || activity.company?.toLowerCase().includes(lowerCaseQuery);
      let matchesDate = true;
      if (selectedFilters.dateRange !== "all") {
        const now = /* @__PURE__ */ new Date();
        const activityDate = new Date(activity.timestamp);
        switch (selectedFilters.dateRange) {
          case "today":
            matchesDate = activityDate.toDateString() === now.toDateString();
            break;
          case "week":
            const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1e3);
            matchesDate = activityDate >= weekAgo;
            break;
          case "month":
            const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1e3);
            matchesDate = activityDate >= monthAgo;
            break;
          default:
            break;
        }
      }
      return matchesType && matchesChannel && matchesSearch && matchesDate;
    });
  }, [transformedActivities, selectedFilters, searchQuery]);
  const handleExportTimeline = () => {
    const exportData = filteredActivities.map((activity) => ({
      timestamp: activity.timestamp.toISOString(),
      type: activity.type,
      title: activity.title,
      contact: activity.contact,
      company: activity.company,
      user: activity.user,
      description: activity.description
    }));
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `activity_timeline_${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:141:4", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "141", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22min-h-screen%20bg-background%22%7D", className: "min-h-screen bg-background", children: [
    /* @__PURE__ */ jsxDEV(Header, { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:142:6", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "142", "data-component-file": "index.jsx", "data-component-name": "Header", "data-component-content": "%7B%22elementName%22%3A%22Header%22%7D" }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
      lineNumber: 142,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("main", { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:143:6", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "143", "data-component-file": "index.jsx", "data-component-name": "main", "data-component-content": "%7B%22elementName%22%3A%22main%22%2C%22className%22%3A%22pt-16%22%7D", className: "pt-16", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:144:8", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "144", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22max-w-7xl%20mx-auto%20px-6%20py-8%22%7D", className: "max-w-7xl mx-auto px-6 py-8", children: [
      /* @__PURE__ */ jsxDEV(Breadcrumb, { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:145:10", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "145", "data-component-file": "index.jsx", "data-component-name": "Breadcrumb", "data-component-content": "%7B%22elementName%22%3A%22Breadcrumb%22%7D" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
        lineNumber: 145,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:147:10", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "147", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20flex-col%20lg%3Aflex-row%20lg%3Aitems-center%20lg%3Ajustify-between%20mb-8%22%7D", className: "flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:148:12", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "148", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("h1", { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:149:14", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "149", "data-component-file": "index.jsx", "data-component-name": "h1", "data-component-content": "%7B%22elementName%22%3A%22h1%22%2C%22className%22%3A%22text-3xl%20font-bold%20text-text-primary%20mb-2%22%2C%22textContent%22%3A%22Activity%20Timeline%22%7D", className: "text-3xl font-bold text-text-primary mb-2", children: "Activity Timeline" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
            lineNumber: 149,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:150:14", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "150", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%22%2C%22textContent%22%3A%22Unified%20view%20of%20all%20customer%20interactions%20across%20communication%20channels%22%7D", className: "text-text-secondary", children: "Unified view of all customer interactions across communication channels" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
            lineNumber: 150,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
          lineNumber: 148,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:155:12", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "155", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-4%20mt-4%20lg%3Amt-0%22%7D", className: "flex items-center space-x-4 mt-4 lg:mt-0", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\activity-timeline\\index.jsx:156:14",
              "data-component-path": "src\\pages\\activity-timeline\\index.jsx",
              "data-component-line": "156",
              "data-component-file": "index.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%20px-4%20py-2%20border%20border-border%20rounded-lg%20text-text-secondary%20hover%3Atext-text-primary%20hover%3Abg-surface-hover%20transition-all%20duration-150%20ease-out%22%7D",
              onClick: handleExportTimeline,
              className: "flex items-center space-x-2 px-4 py-2 border border-border rounded-lg text-text-secondary hover:text-text-primary hover:bg-surface-hover transition-all duration-150 ease-out",
              children: [
                /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:160:16", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "160", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Download%22%7D", name: "Download", size: 16 }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
                  lineNumber: 160,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:161:16", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "161", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Export%20Timeline%22%7D", children: "Export Timeline" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
                  lineNumber: 161,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
              lineNumber: 156,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\activity-timeline\\index.jsx:164:14",
              "data-component-path": "src\\pages\\activity-timeline\\index.jsx",
              "data-component-line": "164",
              "data-component-file": "index.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22btn-primary%20flex%20items-center%20space-x-2%22%7D",
              onClick: () => setIsAddModalOpen(true),
              className: "btn-primary flex items-center space-x-2",
              children: [
                /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:168:16", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "168", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Plus%22%7D", name: "Plus", size: 16 }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
                  lineNumber: 168,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:169:16", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "169", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Add%20Activity%22%7D", children: "Add Activity" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
                  lineNumber: 169,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
              lineNumber: 164,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
          lineNumber: 155,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
        lineNumber: 147,
        columnNumber: 11
      }, this),
      error && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:175:10", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "175", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-error-50%20border%20border-error-200%20text-error%20p-4%20rounded-lg%20mb-6%20flex%20items-center%20space-x-2%22%7D", className: "bg-error-50 border border-error-200 text-error p-4 rounded-lg mb-6 flex items-center space-x-2", children: [
        /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:176:14", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "176", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22AlertCircle%22%7D", name: "AlertCircle", size: 20 }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
          lineNumber: 176,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:177:14", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "177", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: error }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
          lineNumber: 177,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
        lineNumber: 175,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:181:10", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "181", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22mb-6%22%7D", className: "mb-6", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:182:12", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "182", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22relative%20max-w-md%22%7D", className: "relative max-w-md", children: [
        /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:183:14", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "183", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Search%22%2C%22className%22%3A%22absolute%20left-3%20top-1%2F2%20transform%20-translate-y-1%2F2%20text-text-tertiary%22%7D", name: "Search", size: 20, className: "absolute left-3 top-1/2 transform -translate-y-1/2 text-text-tertiary" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
          lineNumber: 183,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            "data-component-id": "src\\pages\\activity-timeline\\index.jsx:184:14",
            "data-component-path": "src\\pages\\activity-timeline\\index.jsx",
            "data-component-line": "184",
            "data-component-file": "index.jsx",
            "data-component-name": "input",
            "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22text%22%2C%22value%22%3A%22%5Bvar%3AsearchQuery%5D%22%2C%22className%22%3A%22input-field%20pl-10%22%7D",
            type: "text",
            placeholder: "Search activities, contacts, or companies...",
            value: searchQuery,
            onChange: (e) => setSearchQuery(e.target.value),
            className: "input-field pl-10"
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
            lineNumber: 184,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
        lineNumber: 182,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
        lineNumber: 181,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:194:10", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "194", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20flex-col%20lg%3Aflex-row%20gap-6%22%7D", className: "flex flex-col lg:flex-row gap-6", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:195:12", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "195", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", className: `lg:w-80 ${isSidebarOpen ? "block" : "hidden lg:block"}`, children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:196:14", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "196", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-6%20sticky%20top-24%22%7D", className: "card p-6 sticky top-24", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:197:16", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "197", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%20mb-4%22%7D", className: "flex items-center justify-between mb-4", children: [
            /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:198:18", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "198", "data-component-file": "index.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%2C%22textContent%22%3A%22Filters%22%7D", className: "text-lg font-semibold text-text-primary", children: "Filters" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
              lineNumber: 198,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                "data-component-id": "src\\pages\\activity-timeline\\index.jsx:199:18",
                "data-component-path": "src\\pages\\activity-timeline\\index.jsx",
                "data-component-line": "199",
                "data-component-file": "index.jsx",
                "data-component-name": "button",
                "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22lg%3Ahidden%20p-1%20text-text-secondary%20hover%3Atext-text-primary%22%7D",
                onClick: () => setIsSidebarOpen(!isSidebarOpen),
                className: "lg:hidden p-1 text-text-secondary hover:text-text-primary",
                children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:203:20", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "203", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22X%22%7D", name: "X", size: 20 }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
                  lineNumber: 203,
                  columnNumber: 21
                }, this)
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
                lineNumber: 199,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
            lineNumber: 197,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            ActivityFilters,
            {
              "data-component-id": "src\\pages\\activity-timeline\\index.jsx:207:16",
              "data-component-path": "src\\pages\\activity-timeline\\index.jsx",
              "data-component-line": "207",
              "data-component-file": "index.jsx",
              "data-component-name": "ActivityFilters",
              "data-component-content": "%7B%22elementName%22%3A%22ActivityFilters%22%7D",
              selectedFilters,
              onFiltersChange: setSelectedFilters
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
              lineNumber: 207,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
          lineNumber: 196,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
          lineNumber: 195,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\activity-timeline\\index.jsx:214:12",
            "data-component-path": "src\\pages\\activity-timeline\\index.jsx",
            "data-component-line": "214",
            "data-component-file": "index.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22lg%3Ahidden%20fixed%20bottom-6%20right-6%20w-14%20h-14%20bg-primary%20text-white%20rounded-full%20shadow-lg%20flex%20items-center%20justify-center%20z-50%22%7D",
            onClick: () => setIsSidebarOpen(!isSidebarOpen),
            className: "lg:hidden fixed bottom-6 right-6 w-14 h-14 bg-primary text-white rounded-full shadow-lg flex items-center justify-center z-50",
            children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:218:14", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "218", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Filter%22%7D", name: "Filter", size: 20 }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
              lineNumber: 218,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
            lineNumber: 214,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:221:12", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "221", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex-1%22%7D", className: "flex-1", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:222:14", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "222", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%20mb-6%22%7D", className: "flex items-center justify-between mb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:223:16", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "223", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22Showing%20of%20activities%22%7D", className: "text-sm text-text-secondary", children: [
              "Showing ",
              filteredActivities.length,
              " of ",
              activities.length,
              " activities"
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
              lineNumber: 223,
              columnNumber: 17
            }, this),
            (selectedFilters.activityType !== "all" || selectedFilters.dateRange !== "all" || selectedFilters.channel !== "all" || searchQuery) && /* @__PURE__ */ jsxDEV(
              "button",
              {
                "data-component-id": "src\\pages\\activity-timeline\\index.jsx:229:16",
                "data-component-path": "src\\pages\\activity-timeline\\index.jsx",
                "data-component-line": "229",
                "data-component-file": "index.jsx",
                "data-component-name": "button",
                "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22text-sm%20text-primary%20hover%3Atext-primary-700%20transition-colors%20duration-150%20ease-out%22%2C%22textContent%22%3A%22Clear%20all%20filters%22%7D",
                onClick: () => {
                  setSelectedFilters({
                    activityType: "all",
                    dateRange: "all",
                    teamMember: "all",
                    channel: "all"
                  });
                  setSearchQuery("");
                },
                className: "text-sm text-primary hover:text-primary-700 transition-colors duration-150 ease-out",
                children: "Clear all filters"
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
                lineNumber: 229,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
            lineNumber: 222,
            columnNumber: 15
          }, this),
          loading ? /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:247:14", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "247", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-center%20py-12%22%7D", className: "text-center py-12", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:248:18", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "248", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22animate-spin%20rounded-full%20h-12%20w-12%20border-b-2%20border-primary%20mx-auto%20mb-4%22%7D", className: "animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
              lineNumber: 248,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:249:18", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "249", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%22%2C%22textContent%22%3A%22Loading%20activities...%22%7D", className: "text-text-secondary", children: "Loading activities..." }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
              lineNumber: 249,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
            lineNumber: 247,
            columnNumber: 15
          }, this) : /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:252:14", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "252", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-6%22%7D", className: "space-y-6", children: filteredActivities.length > 0 ? filteredActivities.map(
            (activity, index) => /* @__PURE__ */ jsxDEV(
              ActivityCard,
              {
                "data-component-id": "src\\pages\\activity-timeline\\index.jsx:255:16",
                "data-component-path": "src\\pages\\activity-timeline\\index.jsx",
                "data-component-line": "255",
                "data-component-file": "index.jsx",
                "data-component-name": "ActivityCard",
                "data-component-content": "%7B%22elementName%22%3A%22ActivityCard%22%7D",
                activity,
                isLast: index === filteredActivities.length - 1
              },
              activity.id,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
                lineNumber: 255,
                columnNumber: 17
              },
              this
            )
          ) : /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:262:16", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "262", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-center%20py-12%22%7D", className: "text-center py-12", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:263:22", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "263", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-16%20h-16%20bg-primary-50%20rounded-full%20flex%20items-center%20justify-center%20mx-auto%20mb-4%22%7D", className: "w-16 h-16 bg-primary-50 rounded-full flex items-center justify-center mx-auto mb-4", children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:264:24", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "264", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Clock%22%2C%22className%22%3A%22text-primary%22%7D", name: "Clock", size: 32, className: "text-primary" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
              lineNumber: 264,
              columnNumber: 25
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
              lineNumber: 263,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:266:22", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "266", "data-component-file": "index.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%20mb-2%22%2C%22textContent%22%3A%22No%20activities%20found%22%7D", className: "text-lg font-semibold text-text-primary mb-2", children: "No activities found" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
              lineNumber: 266,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\activity-timeline\\index.jsx:267:22", "data-component-path": "src\\pages\\activity-timeline\\index.jsx", "data-component-line": "267", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20mb-4%22%2C%22textContent%22%3A%22Try%20adjusting%20your%20filters%20or%20search%20terms%20to%20find%20activities.%22%7D", className: "text-text-secondary mb-4", children: "Try adjusting your filters or search terms to find activities." }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
              lineNumber: 267,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                "data-component-id": "src\\pages\\activity-timeline\\index.jsx:270:22",
                "data-component-path": "src\\pages\\activity-timeline\\index.jsx",
                "data-component-line": "270",
                "data-component-file": "index.jsx",
                "data-component-name": "button",
                "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22btn-primary%22%2C%22textContent%22%3A%22Add%20First%20Activity%22%7D",
                onClick: () => setIsAddModalOpen(true),
                className: "btn-primary",
                children: "Add First Activity"
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
                lineNumber: 270,
                columnNumber: 23
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
            lineNumber: 262,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
            lineNumber: 252,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
          lineNumber: 221,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
        lineNumber: 194,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
      lineNumber: 144,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
      lineNumber: 143,
      columnNumber: 7
    }, this),
    isAddModalOpen && /* @__PURE__ */ jsxDEV(
      AddActivityModal,
      {
        "data-component-id": "src\\pages\\activity-timeline\\index.jsx:286:6",
        "data-component-path": "src\\pages\\activity-timeline\\index.jsx",
        "data-component-line": "286",
        "data-component-file": "index.jsx",
        "data-component-name": "AddActivityModal",
        "data-component-content": "%7B%22elementName%22%3A%22AddActivityModal%22%7D",
        isOpen: isAddModalOpen,
        onClose: () => setIsAddModalOpen(false),
        onActivityAdded: handleActivityAdded
      },
      void 0,
      false,
      {
        fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
        lineNumber: 286,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/activity-timeline/index.jsx",
    lineNumber: 141,
    columnNumber: 5
  }, this);
};
_s(ActivityTimeline, "rjDgNi+26Msil1j3EyCiNq5K8PY=", false, function() {
  return [useAuth];
});
_c = ActivityTimeline;
export default ActivityTimeline;
var _c;
$RefreshReg$(_c, "ActivityTimeline");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/activity-timeline/index.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/activity-timeline/index.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNklNOzJCQTdJTjtBQUFnQkEsTUFBVUMsY0FBU0MsT0FBUyxzQkFBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMzRCxPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGdCQUFnQjtBQUN2QixPQUFPQyxVQUFVO0FBQ2pCLFNBQVNDLGVBQWU7QUFDeEIsT0FBT0MsdUJBQXVCO0FBRTlCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxxQkFBcUI7QUFDNUIsT0FBT0Msc0JBQXNCO0FBRTdCLE1BQU1DLG1CQUFtQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzdCLFFBQU0sRUFBRUMsS0FBSyxJQUFJUCxRQUFRO0FBQ3pCLFFBQU0sQ0FBQ1EsWUFBWUMsYUFBYSxJQUFJZixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDZ0IsU0FBU0MsVUFBVSxJQUFJakIsU0FBUyxJQUFJO0FBQzNDLFFBQU0sQ0FBQ2tCLE9BQU9DLFFBQVEsSUFBSW5CLFNBQVMsRUFBRTtBQUVyQyxRQUFNLENBQUNvQixpQkFBaUJDLGtCQUFrQixJQUFJckIsU0FBUztBQUFBLElBQ3JEc0IsY0FBYztBQUFBLElBQ2RDLFdBQVc7QUFBQSxJQUNYQyxZQUFZO0FBQUEsSUFDWkMsU0FBUztBQUFBLEVBQ1gsQ0FBQztBQUNELFFBQU0sQ0FBQ0MsYUFBYUMsY0FBYyxJQUFJM0IsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQzRCLGdCQUFnQkMsaUJBQWlCLElBQUk3QixTQUFTLEtBQUs7QUFDMUQsUUFBTSxDQUFDOEIsZUFBZUMsZ0JBQWdCLElBQUkvQixTQUFTLElBQUk7QUFFdkQsUUFBTWdDLGlCQUFpQixZQUFZO0FBQ2pDLFFBQUksQ0FBQ25CO0FBQU07QUFDWG9CLFlBQVFDLElBQUksZ0NBQWdDO0FBQzVDLFFBQUk7QUFDRmpCLGlCQUFXLElBQUk7QUFDZkUsZUFBUyxFQUFFO0FBQ1gsWUFBTWdCLE9BQU8sTUFBTTVCLGtCQUFrQjZCLGtCQUFrQjtBQUN2REgsY0FBUUMsSUFBSSx5Q0FBeUNDLElBQUk7QUFDekRwQixvQkFBY29CLElBQUk7QUFBQSxJQUNwQixTQUFTRSxLQUFLO0FBQ1pKLGNBQVFmLE1BQU0sNkJBQTZCbUIsR0FBRztBQUM5Q2xCLGVBQVMsOENBQThDO0FBQUEsSUFDekQsVUFBQztBQUNDRixpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBRUFmLFlBQVUsTUFBTTtBQUNkOEIsbUJBQWU7QUFBQSxFQUNqQixHQUFHLENBQUNuQixJQUFJLENBQUM7QUFFVCxRQUFNeUIsc0JBQXNCQSxDQUFDQyxnQkFBZ0I7QUFDM0N4QixrQkFBYyxDQUFBeUIsbUJBQWtCLENBQUNELGFBQWEsR0FBR0MsY0FBYyxDQUFDO0FBQUEsRUFDbEU7QUFFQSxRQUFNQyx3QkFBd0J4QyxRQUFRLE1BQU07QUFDMUMsV0FBT2EsV0FBVzRCLElBQUksQ0FBQUMsY0FBYTtBQUFBLE1BQ2pDQyxJQUFJRCxTQUFTQztBQUFBQSxNQUNiQyxNQUFNRixTQUFTRTtBQUFBQSxNQUNmcEIsU0FBU2tCLFNBQVNsQixXQUFXO0FBQUEsTUFDN0JxQixPQUFPSCxTQUFTSTtBQUFBQSxNQUNoQkMsYUFBYUwsU0FBU0s7QUFBQUEsTUFDdEJDLFNBQVNOLFNBQVNNLFVBQVUsR0FBR04sU0FBU00sUUFBUUMsVUFBVSxJQUFJUCxTQUFTTSxRQUFRRSxTQUFTLEtBQUs7QUFBQSxNQUM3RkMsU0FBU1QsU0FBU00sU0FBU0csU0FBU0MsUUFBUTtBQUFBLE1BQzVDQyxXQUFXLElBQUlDLEtBQUtaLFNBQVNhLFVBQVU7QUFBQSxNQUN2QzNDLE1BQU04QixTQUFTOUIsT0FBTyxHQUFHOEIsU0FBUzlCLEtBQUtxQyxVQUFVLElBQUlQLFNBQVM5QixLQUFLc0MsU0FBUyxLQUFLO0FBQUEsTUFDakZNLFFBQVFkLFNBQVM5QixNQUFNNkMsY0FBYztBQUFBLE1BQ3JDQyxlQUFlaEIsU0FBU00sU0FBU1MsY0FBYztBQUFBLE1BQy9DRSxRQUFRakIsU0FBU2lCO0FBQUFBLE1BQ2pCQyxVQUFVbEIsU0FBU2tCO0FBQUFBLE1BQ25CQyxXQUFXbkIsU0FBU29CLE9BQU8sR0FBR3BCLFNBQVNvQixLQUFLQyxPQUFPQyxlQUFlLENBQUMsS0FBSztBQUFBLE1BQ3hFQyxhQUFhdkIsU0FBU3VCLGVBQWU7QUFBQSxNQUNyQ0MsVUFBVXhCLFNBQVN5QixtQkFBbUIsR0FBR3pCLFNBQVN5QixnQkFBZ0IsU0FBUztBQUFBLE1BQzNFQyxlQUFlMUIsU0FBUzJCLFVBQVVDO0FBQUFBLE1BQ2xDQyxjQUFjN0IsU0FBUzJCLFVBQVVHO0FBQUFBLE1BQ2pDQyxhQUFhL0IsU0FBUzJCLFVBQVVJO0FBQUFBLE1BQ2hDQyxhQUFhaEMsU0FBUzJCLFVBQVVNO0FBQUFBLE1BQ2hDQyxVQUFVbEMsU0FBUzJCLFVBQVVPO0FBQUFBLE1BQzdCQyxXQUFXbkMsU0FBUzJCLFVBQVVRO0FBQUFBLE1BQzlCQyxVQUFVcEMsU0FBUzJCLFVBQVVVO0FBQUFBLElBQy9CLEVBQUU7QUFBQSxFQUNKLEdBQUcsQ0FBQ2xFLFVBQVUsQ0FBQztBQUVmLFFBQU1tRSxxQkFBcUJoRixRQUFRLE1BQU07QUFDdkMsV0FBT3dDLHNCQUFzQnlDLE9BQU8sQ0FBQXZDLGFBQVk7QUFDOUMsWUFBTXdDLGNBQWMvRCxnQkFBZ0JFLGlCQUFpQixTQUFTcUIsU0FBU0UsU0FBU3pCLGdCQUFnQkU7QUFDaEcsWUFBTThELGlCQUFpQmhFLGdCQUFnQkssWUFBWSxTQUFTa0IsU0FBU2xCLFlBQVlMLGdCQUFnQks7QUFFakcsWUFBTTRELGlCQUFpQjNELFlBQVk0RCxZQUFZO0FBQy9DLFlBQU1DLGdCQUFnQjdELGdCQUFnQixNQUNwQ2lCLFNBQVNHLE9BQU93QyxZQUFZLEVBQUVFLFNBQVNILGNBQWMsS0FDckQxQyxTQUFTSyxhQUFhc0MsWUFBWSxFQUFFRSxTQUFTSCxjQUFjLEtBQzNEMUMsU0FBU00sU0FBU3FDLFlBQVksRUFBRUUsU0FBU0gsY0FBYyxLQUN2RDFDLFNBQVNTLFNBQVNrQyxZQUFZLEVBQUVFLFNBQVNILGNBQWM7QUFFekQsVUFBSUksY0FBYztBQUNsQixVQUFJckUsZ0JBQWdCRyxjQUFjLE9BQU87QUFDdkMsY0FBTW1FLE1BQU0sb0JBQUluQyxLQUFLO0FBQ3JCLGNBQU1vQyxlQUFlLElBQUlwQyxLQUFLWixTQUFTVyxTQUFTO0FBQ2hELGdCQUFRbEMsZ0JBQWdCRyxXQUFTO0FBQUEsVUFDL0IsS0FBSztBQUNIa0UsMEJBQWNFLGFBQWFDLGFBQWEsTUFBTUYsSUFBSUUsYUFBYTtBQUMvRDtBQUFBLFVBQ0YsS0FBSztBQUNILGtCQUFNQyxVQUFVLElBQUl0QyxLQUFLbUMsSUFBSUksUUFBUSxJQUFJLElBQUksS0FBSyxLQUFLLEtBQUssR0FBSTtBQUNoRUwsMEJBQWNFLGdCQUFnQkU7QUFDOUI7QUFBQSxVQUNGLEtBQUs7QUFDSCxrQkFBTUUsV0FBVyxJQUFJeEMsS0FBS21DLElBQUlJLFFBQVEsSUFBSSxLQUFLLEtBQUssS0FBSyxLQUFLLEdBQUk7QUFDbEVMLDBCQUFjRSxnQkFBZ0JJO0FBQzlCO0FBQUEsVUFDRjtBQUNFO0FBQUEsUUFDSjtBQUFBLE1BQ0Y7QUFFQSxhQUFPWixlQUFlQyxrQkFBa0JHLGlCQUFpQkU7QUFBQUEsSUFDM0QsQ0FBQztBQUFBLEVBQ0gsR0FBRyxDQUFDaEQsdUJBQXVCckIsaUJBQWlCTSxXQUFXLENBQUM7QUFFeEQsUUFBTXNFLHVCQUF1QkEsTUFBTTtBQUNqQyxVQUFNQyxhQUFhaEIsbUJBQW1CdkMsSUFBSSxDQUFBQyxjQUFhO0FBQUEsTUFDckRXLFdBQVdYLFNBQVNXLFVBQVU0QyxZQUFZO0FBQUEsTUFDMUNyRCxNQUFNRixTQUFTRTtBQUFBQSxNQUNmQyxPQUFPSCxTQUFTRztBQUFBQSxNQUNoQkcsU0FBU04sU0FBU007QUFBQUEsTUFDbEJHLFNBQVNULFNBQVNTO0FBQUFBLE1BQ2xCdkMsTUFBTThCLFNBQVM5QjtBQUFBQSxNQUNmbUMsYUFBYUwsU0FBU0s7QUFBQUEsSUFDeEIsRUFBRTtBQUVGLFVBQU1tRCxPQUFPLElBQUlDLEtBQUssQ0FBQ0MsS0FBS0MsVUFBVUwsWUFBWSxNQUFNLENBQUMsQ0FBQyxHQUFHLEVBQUVwRCxNQUFNLG1CQUFtQixDQUFDO0FBQ3pGLFVBQU0wRCxNQUFNQyxJQUFJQyxnQkFBZ0JOLElBQUk7QUFDcEMsVUFBTU8sSUFBSUMsU0FBU0MsY0FBYyxHQUFHO0FBQ3BDRixNQUFFRyxPQUFPTjtBQUNURyxNQUFFSSxXQUFXLHNCQUFxQixvQkFBSXZELEtBQUssR0FBRTJDLFlBQVksRUFBRWEsTUFBTSxHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQ3hFSixhQUFTSyxLQUFLQyxZQUFZUCxDQUFDO0FBQzNCQSxNQUFFUSxNQUFNO0FBQ1JQLGFBQVNLLEtBQUtHLFlBQVlULENBQUM7QUFDM0JGLFFBQUlZLGdCQUFnQmIsR0FBRztBQUFBLEVBQ3pCO0FBRUEsU0FDRSx1QkFBQywyV0FBSSxXQUFVLDhCQUNiO0FBQUEsMkJBQUMsNlRBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFPO0FBQUEsSUFDUCx1QkFBQyx1VkFBSyxXQUFVLFNBQ2QsaUNBQUMsZ1hBQUksV0FBVSwrQkFDYjtBQUFBLDZCQUFDLDBVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBVztBQUFBLE1BRVgsdUJBQUMsaWFBQUksV0FBVSxxRUFDYjtBQUFBLCtCQUFDLHFUQUNDO0FBQUEsaUNBQUMsNGFBQUcsV0FBVSw2Q0FBNEMsaUNBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJFO0FBQUEsVUFDM0UsdUJBQUMsaWRBQUUsV0FBVSx1QkFBc0IsdUZBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFFBRUEsdUJBQUMsa1lBQUksV0FBVSw0Q0FDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FDQyxTQUFTUDtBQUFBQSxjQUNULFdBQVU7QUFBQSxjQUVWO0FBQUEsdUNBQUMsb1ZBQUssTUFBSyxZQUFXLE1BQU0sTUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0I7QUFBQSxnQkFDL0IsdUJBQUMsc1dBQUssK0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUI7QUFBQTtBQUFBO0FBQUEsWUFMdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTUE7QUFBQSxVQUVBO0FBQUEsWUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FDQyxTQUFTLE1BQU1uRSxrQkFBa0IsSUFBSTtBQUFBLGNBQ3JDLFdBQVU7QUFBQSxjQUVWO0FBQUEsdUNBQUMsZ1ZBQUssTUFBSyxRQUFPLE1BQU0sTUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkI7QUFBQSxnQkFDM0IsdUJBQUMsbVdBQUssNEJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0I7QUFBQTtBQUFBO0FBQUEsWUFMcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTUE7QUFBQSxhQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkE7QUFBQSxXQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeUJBO0FBQUEsTUFFQ1gsU0FDQyx1QkFBQyxnY0FBSSxXQUFVLGtHQUNiO0FBQUEsK0JBQUMsdVZBQUssTUFBSyxlQUFjLE1BQU0sTUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrQztBQUFBLFFBQ2xDLHVCQUFDLHdUQUFNQSxtQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWE7QUFBQSxXQUZmO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BR0YsdUJBQUMsb1ZBQUksV0FBVSxRQUNiLGlDQUFDLG1XQUFJLFdBQVUscUJBQ2I7QUFBQSwrQkFBQyxnY0FBSyxNQUFLLFVBQVMsTUFBTSxJQUFJLFdBQVUsMkVBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0c7QUFBQSxRQUMvRztBQUFBLFVBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsYUFBWTtBQUFBLFlBQ1osT0FBT1E7QUFBQUEsWUFDUCxVQUFVLENBQUMyRixNQUFNMUYsZUFBZTBGLEVBQUVDLE9BQU90RCxLQUFLO0FBQUEsWUFDOUMsV0FBVTtBQUFBO0FBQUEsVUFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLK0I7QUFBQSxXQVBqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0EsS0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxNQUVBLHVCQUFDLHVYQUFJLFdBQVUsbUNBQ2I7QUFBQSwrQkFBQyxxVEFBSSxXQUFXLFdBQVdsQyxnQkFBZ0IsVUFBVSxpQkFBaUIsSUFDcEUsaUNBQUMsNFdBQUksV0FBVSwwQkFDYjtBQUFBLGlDQUFDLDRYQUFJLFdBQVUsMENBQ2I7QUFBQSxtQ0FBQyw0WkFBRyxXQUFVLDJDQUEwQyx1QkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0Q7QUFBQSxZQUMvRDtBQUFBLGNBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTUMsaUJBQWlCLENBQUNELGFBQWE7QUFBQSxnQkFDOUMsV0FBVTtBQUFBLGdCQUVWLGlDQUFDLDZVQUFLLE1BQUssS0FBSSxNQUFNLE1BQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdCO0FBQUE7QUFBQSxjQUoxQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLGVBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFVBRUE7QUFBQSxZQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUNDO0FBQUEsY0FDQSxpQkFBaUJUO0FBQUFBO0FBQUFBLFlBRm5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUVzQztBQUFBLGFBYnhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQSxLQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUJBO0FBQUEsUUFFQTtBQUFBLFVBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNVSxpQkFBaUIsQ0FBQ0QsYUFBYTtBQUFBLFlBQzlDLFdBQVU7QUFBQSxZQUVWLGlDQUFDLGtWQUFLLE1BQUssVUFBUyxNQUFNLE1BQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZCO0FBQUE7QUFBQSxVQUovQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLFFBRUEsdUJBQUMsc1ZBQUksV0FBVSxVQUNiO0FBQUEsaUNBQUMsNFhBQUksV0FBVSwwQ0FDYjtBQUFBLG1DQUFDLG1hQUFJLFdBQVUsK0JBQThCO0FBQUE7QUFBQSxjQUNsQ21ELG1CQUFtQnNDO0FBQUFBLGNBQU87QUFBQSxjQUFLekcsV0FBV3lHO0FBQUFBLGNBQU87QUFBQSxpQkFENUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGFBRUVuRyxnQkFBZ0JFLGlCQUFpQixTQUFTRixnQkFBZ0JHLGNBQWMsU0FDeEVILGdCQUFnQkssWUFBWSxTQUFTQyxnQkFDckM7QUFBQSxjQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFDQyxTQUFTLE1BQU07QUFDYkwscUNBQW1CO0FBQUEsb0JBQ2pCQyxjQUFjO0FBQUEsb0JBQ2RDLFdBQVc7QUFBQSxvQkFDWEMsWUFBWTtBQUFBLG9CQUNaQyxTQUFTO0FBQUEsa0JBQ1gsQ0FBQztBQUNERSxpQ0FBZSxFQUFFO0FBQUEsZ0JBQ25CO0FBQUEsZ0JBQ0EsV0FBVTtBQUFBLGdCQUFxRjtBQUFBO0FBQUEsY0FWakc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBYUE7QUFBQSxlQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXNCQTtBQUFBLFVBRUNYLFVBQ0MsdUJBQUMsbVdBQUksV0FBVSxxQkFDYjtBQUFBLG1DQUFDLHdhQUFJLFdBQVUsZ0ZBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEY7QUFBQSxZQUM1Rix1QkFBQyxpWkFBRSxXQUFVLHVCQUFzQixxQ0FBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0Q7QUFBQSxlQUYxRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBLElBRUEsdUJBQUMseVZBQUksV0FBVSxhQUNaaUUsNkJBQW1Cc0MsU0FBUyxJQUMzQnRDLG1CQUFtQnZDO0FBQUFBLFlBQUksQ0FBQ0MsVUFBVTZFLFVBQ2hDO0FBQUEsY0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRUM7QUFBQSxnQkFDQSxRQUFRQSxVQUFVdkMsbUJBQW1Cc0MsU0FBUztBQUFBO0FBQUEsY0FGekM1RSxTQUFTQztBQUFBQSxjQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBR2tEO0FBQUEsVUFFbkQsSUFFRCx1QkFBQyxtV0FBSSxXQUFVLHFCQUNiO0FBQUEsbUNBQUMsa2JBQUksV0FBVSxzRkFDYixpQ0FBQyx3WEFBSyxNQUFLLFNBQVEsTUFBTSxJQUFJLFdBQVUsa0JBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFELEtBRHZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLG1iQUFHLFdBQVUsZ0RBQStDLG1DQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRjtBQUFBLFlBQ2hGLHVCQUFDLGlkQUFFLFdBQVUsNEJBQTJCLDhFQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTWYsa0JBQWtCLElBQUk7QUFBQSxnQkFDckMsV0FBVTtBQUFBLGdCQUFhO0FBQUE7QUFBQSxjQUZ6QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLGVBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFjQSxLQXhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTBCQTtBQUFBLGFBekRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEyREE7QUFBQSxXQXRGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdUZBO0FBQUEsU0F6SUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBJQSxLQTNJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNElBO0FBQUEsSUFFQ0Qsa0JBQ0M7QUFBQSxNQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUNDLFFBQVFBO0FBQUFBLFFBQ1IsU0FBUyxNQUFNQyxrQkFBa0IsS0FBSztBQUFBLFFBQ3RDLGlCQUFpQlM7QUFBQUE7QUFBQUEsTUFIbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBR3VDO0FBQUEsT0FwSjNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1SkE7QUFFSjtBQUFFMUIsR0ExUklELGtCQUFnQjtBQUFBLFVBQ0hMLE9BQU87QUFBQTtBQUFBbUgsS0FEcEI5RztBQTRSTixlQUFlQTtBQXVSZixJQUFBOEc7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlTWVtbyIsInVzZUVmZmVjdCIsIkhlYWRlciIsIkJyZWFkY3J1bWIiLCJJY29uIiwidXNlQXV0aCIsImFjdGl2aXRpZXNTZXJ2aWNlIiwiQWN0aXZpdHlDYXJkIiwiQWN0aXZpdHlGaWx0ZXJzIiwiQWRkQWN0aXZpdHlNb2RhbCIsIkFjdGl2aXR5VGltZWxpbmUiLCJfcyIsInVzZXIiLCJhY3Rpdml0aWVzIiwic2V0QWN0aXZpdGllcyIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwiZXJyb3IiLCJzZXRFcnJvciIsInNlbGVjdGVkRmlsdGVycyIsInNldFNlbGVjdGVkRmlsdGVycyIsImFjdGl2aXR5VHlwZSIsImRhdGVSYW5nZSIsInRlYW1NZW1iZXIiLCJjaGFubmVsIiwic2VhcmNoUXVlcnkiLCJzZXRTZWFyY2hRdWVyeSIsImlzQWRkTW9kYWxPcGVuIiwic2V0SXNBZGRNb2RhbE9wZW4iLCJpc1NpZGViYXJPcGVuIiwic2V0SXNTaWRlYmFyT3BlbiIsImxvYWRBY3Rpdml0aWVzIiwiY29uc29sZSIsImxvZyIsImRhdGEiLCJnZXRVc2VyQWN0aXZpdGllcyIsImVyciIsImhhbmRsZUFjdGl2aXR5QWRkZWQiLCJuZXdBY3Rpdml0eSIsInByZXZBY3Rpdml0aWVzIiwidHJhbnNmb3JtZWRBY3Rpdml0aWVzIiwibWFwIiwiYWN0aXZpdHkiLCJpZCIsInR5cGUiLCJ0aXRsZSIsInN1YmplY3QiLCJkZXNjcmlwdGlvbiIsImNvbnRhY3QiLCJmaXJzdF9uYW1lIiwibGFzdF9uYW1lIiwiY29tcGFueSIsIm5hbWUiLCJ0aW1lc3RhbXAiLCJEYXRlIiwiY3JlYXRlZF9hdCIsImF2YXRhciIsImF2YXRhcl91cmwiLCJjb250YWN0QXZhdGFyIiwic3RhdHVzIiwicHJpb3JpdHkiLCJkZWFsVmFsdWUiLCJkZWFsIiwidmFsdWUiLCJ0b0xvY2FsZVN0cmluZyIsImF0dGFjaG1lbnRzIiwiZHVyYXRpb24iLCJkdXJhdGlvbl9taW51dGVzIiwicHJldmlvdXNTdGFnZSIsIm1ldGFkYXRhIiwicHJldmlvdXNfc3RhZ2UiLCJjdXJyZW50U3RhZ2UiLCJjdXJyZW50X3N0YWdlIiwicHJvYmFiaWxpdHkiLCJtZWV0aW5nVHlwZSIsIm1lZXRpbmdfdHlwZSIsImxvY2F0aW9uIiwiYXR0ZW5kZWVzIiwiY2FsbFR5cGUiLCJjYWxsX3R5cGUiLCJmaWx0ZXJlZEFjdGl2aXRpZXMiLCJmaWx0ZXIiLCJtYXRjaGVzVHlwZSIsIm1hdGNoZXNDaGFubmVsIiwibG93ZXJDYXNlUXVlcnkiLCJ0b0xvd2VyQ2FzZSIsIm1hdGNoZXNTZWFyY2giLCJpbmNsdWRlcyIsIm1hdGNoZXNEYXRlIiwibm93IiwiYWN0aXZpdHlEYXRlIiwidG9EYXRlU3RyaW5nIiwid2Vla0FnbyIsImdldFRpbWUiLCJtb250aEFnbyIsImhhbmRsZUV4cG9ydFRpbWVsaW5lIiwiZXhwb3J0RGF0YSIsInRvSVNPU3RyaW5nIiwiYmxvYiIsIkJsb2IiLCJKU09OIiwic3RyaW5naWZ5IiwidXJsIiwiVVJMIiwiY3JlYXRlT2JqZWN0VVJMIiwiYSIsImRvY3VtZW50IiwiY3JlYXRlRWxlbWVudCIsImhyZWYiLCJkb3dubG9hZCIsInNwbGl0IiwiYm9keSIsImFwcGVuZENoaWxkIiwiY2xpY2siLCJyZW1vdmVDaGlsZCIsInJldm9rZU9iamVjdFVSTCIsImUiLCJ0YXJnZXQiLCJsZW5ndGgiLCJpbmRleCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiaW5kZXguanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlTWVtbywgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgSGVhZGVyIGZyb20gJ2NvbXBvbmVudHMvdWkvSGVhZGVyJztcclxuaW1wb3J0IEJyZWFkY3J1bWIgZnJvbSAnY29tcG9uZW50cy91aS9CcmVhZGNydW1iJztcclxuaW1wb3J0IEljb24gZnJvbSAnY29tcG9uZW50cy9BcHBJY29uJztcclxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uLy4uL2NvbnRleHRzL0F1dGhDb250ZXh0JztcclxuaW1wb3J0IGFjdGl2aXRpZXNTZXJ2aWNlIGZyb20gJy4uLy4uL3NlcnZpY2VzL2FjdGl2aXRpZXNTZXJ2aWNlJztcclxuXHJcbmltcG9ydCBBY3Rpdml0eUNhcmQgZnJvbSAnLi9jb21wb25lbnRzL0FjdGl2aXR5Q2FyZCc7XHJcbmltcG9ydCBBY3Rpdml0eUZpbHRlcnMgZnJvbSAnLi9jb21wb25lbnRzL0FjdGl2aXR5RmlsdGVycyc7XHJcbmltcG9ydCBBZGRBY3Rpdml0eU1vZGFsIGZyb20gJy4vY29tcG9uZW50cy9BZGRBY3Rpdml0eU1vZGFsJztcclxuXHJcbmNvbnN0IEFjdGl2aXR5VGltZWxpbmUgPSAoKSA9PiB7XHJcbiAgY29uc3QgeyB1c2VyIH0gPSB1c2VBdXRoKCk7XHJcbiAgY29uc3QgW2FjdGl2aXRpZXMsIHNldEFjdGl2aXRpZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoJycpO1xyXG4gIFxyXG4gIGNvbnN0IFtzZWxlY3RlZEZpbHRlcnMsIHNldFNlbGVjdGVkRmlsdGVyc10gPSB1c2VTdGF0ZSh7XHJcbiAgICBhY3Rpdml0eVR5cGU6ICdhbGwnLFxyXG4gICAgZGF0ZVJhbmdlOiAnYWxsJyxcclxuICAgIHRlYW1NZW1iZXI6ICdhbGwnLFxyXG4gICAgY2hhbm5lbDogJ2FsbCdcclxuICB9KTtcclxuICBjb25zdCBbc2VhcmNoUXVlcnksIHNldFNlYXJjaFF1ZXJ5XSA9IHVzZVN0YXRlKCcnKTtcclxuICBjb25zdCBbaXNBZGRNb2RhbE9wZW4sIHNldElzQWRkTW9kYWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbaXNTaWRlYmFyT3Blbiwgc2V0SXNTaWRlYmFyT3Blbl0gPSB1c2VTdGF0ZSh0cnVlKTtcclxuXHJcbiAgY29uc3QgbG9hZEFjdGl2aXRpZXMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoIXVzZXIpIHJldHVybjtcclxuICAgIGNvbnNvbGUubG9nKFwiU3RhcnRpbmcgdG8gbG9hZCBhY3Rpdml0aWVzLi4uXCIpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0TG9hZGluZyh0cnVlKTtcclxuICAgICAgc2V0RXJyb3IoJycpO1xyXG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgYWN0aXZpdGllc1NlcnZpY2UuZ2V0VXNlckFjdGl2aXRpZXMoKTtcclxuICAgICAgY29uc29sZS5sb2coXCJEYXRhIHJlY2VpdmVkIGZyb20gYWN0aXZpdGllc1NlcnZpY2U6XCIsIGRhdGEpO1xyXG4gICAgICBzZXRBY3Rpdml0aWVzKGRhdGEpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBsb2FkaW5nIGFjdGl2aXRpZXM6XCIsIGVycik7XHJcbiAgICAgIHNldEVycm9yKFwiRmFpbGVkIHRvIGxvYWQgYWN0aXZpdGllcy4gUGxlYXNlIHRyeSBhZ2Fpbi5cIik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgbG9hZEFjdGl2aXRpZXMoKTtcclxuICB9LCBbdXNlcl0pO1xyXG5cclxuICBjb25zdCBoYW5kbGVBY3Rpdml0eUFkZGVkID0gKG5ld0FjdGl2aXR5KSA9PiB7XHJcbiAgICBzZXRBY3Rpdml0aWVzKHByZXZBY3Rpdml0aWVzID0+IFtuZXdBY3Rpdml0eSwgLi4ucHJldkFjdGl2aXRpZXNdKTtcclxuICB9O1xyXG5cclxuICBjb25zdCB0cmFuc2Zvcm1lZEFjdGl2aXRpZXMgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIHJldHVybiBhY3Rpdml0aWVzLm1hcChhY3Rpdml0eSA9PiAoe1xyXG4gICAgICBpZDogYWN0aXZpdHkuaWQsXHJcbiAgICAgIHR5cGU6IGFjdGl2aXR5LnR5cGUsXHJcbiAgICAgIGNoYW5uZWw6IGFjdGl2aXR5LmNoYW5uZWwgfHwgJ3N5c3RlbScsXHJcbiAgICAgIHRpdGxlOiBhY3Rpdml0eS5zdWJqZWN0LFxyXG4gICAgICBkZXNjcmlwdGlvbjogYWN0aXZpdHkuZGVzY3JpcHRpb24sXHJcbiAgICAgIGNvbnRhY3Q6IGFjdGl2aXR5LmNvbnRhY3QgPyBgJHthY3Rpdml0eS5jb250YWN0LmZpcnN0X25hbWV9ICR7YWN0aXZpdHkuY29udGFjdC5sYXN0X25hbWV9YCA6ICdOL0EnLFxyXG4gICAgICBjb21wYW55OiBhY3Rpdml0eS5jb250YWN0Py5jb21wYW55Py5uYW1lIHx8ICdOL0EnLFxyXG4gICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKGFjdGl2aXR5LmNyZWF0ZWRfYXQpLFxyXG4gICAgICB1c2VyOiBhY3Rpdml0eS51c2VyID8gYCR7YWN0aXZpdHkudXNlci5maXJzdF9uYW1lfSAke2FjdGl2aXR5LnVzZXIubGFzdF9uYW1lfWAgOiAnU3lzdGVtJyxcclxuICAgICAgYXZhdGFyOiBhY3Rpdml0eS51c2VyPy5hdmF0YXJfdXJsIHx8IG51bGwsXHJcbiAgICAgIGNvbnRhY3RBdmF0YXI6IGFjdGl2aXR5LmNvbnRhY3Q/LmF2YXRhcl91cmwgfHwgbnVsbCxcclxuICAgICAgc3RhdHVzOiBhY3Rpdml0eS5zdGF0dXMsXHJcbiAgICAgIHByaW9yaXR5OiBhY3Rpdml0eS5wcmlvcml0eSxcclxuICAgICAgZGVhbFZhbHVlOiBhY3Rpdml0eS5kZWFsID8gYCR7YWN0aXZpdHkuZGVhbC52YWx1ZT8udG9Mb2NhbGVTdHJpbmcoKX1gIDogbnVsbCxcclxuICAgICAgYXR0YWNobWVudHM6IGFjdGl2aXR5LmF0dGFjaG1lbnRzIHx8IFtdLFxyXG4gICAgICBkdXJhdGlvbjogYWN0aXZpdHkuZHVyYXRpb25fbWludXRlcyA/IGAke2FjdGl2aXR5LmR1cmF0aW9uX21pbnV0ZXN9IG1pbmAgOiBudWxsLFxyXG4gICAgICBwcmV2aW91c1N0YWdlOiBhY3Rpdml0eS5tZXRhZGF0YT8ucHJldmlvdXNfc3RhZ2UsXHJcbiAgICAgIGN1cnJlbnRTdGFnZTogYWN0aXZpdHkubWV0YWRhdGE/LmN1cnJlbnRfc3RhZ2UsXHJcbiAgICAgIHByb2JhYmlsaXR5OiBhY3Rpdml0eS5tZXRhZGF0YT8ucHJvYmFiaWxpdHksXHJcbiAgICAgIG1lZXRpbmdUeXBlOiBhY3Rpdml0eS5tZXRhZGF0YT8ubWVldGluZ190eXBlLFxyXG4gICAgICBsb2NhdGlvbjogYWN0aXZpdHkubWV0YWRhdGE/LmxvY2F0aW9uLFxyXG4gICAgICBhdHRlbmRlZXM6IGFjdGl2aXR5Lm1ldGFkYXRhPy5hdHRlbmRlZXMsXHJcbiAgICAgIGNhbGxUeXBlOiBhY3Rpdml0eS5tZXRhZGF0YT8uY2FsbF90eXBlLFxyXG4gICAgfSkpO1xyXG4gIH0sIFthY3Rpdml0aWVzXSk7XHJcblxyXG4gIGNvbnN0IGZpbHRlcmVkQWN0aXZpdGllcyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgcmV0dXJuIHRyYW5zZm9ybWVkQWN0aXZpdGllcy5maWx0ZXIoYWN0aXZpdHkgPT4ge1xyXG4gICAgICBjb25zdCBtYXRjaGVzVHlwZSA9IHNlbGVjdGVkRmlsdGVycy5hY3Rpdml0eVR5cGUgPT09ICdhbGwnIHx8IGFjdGl2aXR5LnR5cGUgPT09IHNlbGVjdGVkRmlsdGVycy5hY3Rpdml0eVR5cGU7XHJcbiAgICAgIGNvbnN0IG1hdGNoZXNDaGFubmVsID0gc2VsZWN0ZWRGaWx0ZXJzLmNoYW5uZWwgPT09ICdhbGwnIHx8IGFjdGl2aXR5LmNoYW5uZWwgPT09IHNlbGVjdGVkRmlsdGVycy5jaGFubmVsO1xyXG4gICAgICBcclxuICAgICAgY29uc3QgbG93ZXJDYXNlUXVlcnkgPSBzZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpO1xyXG4gICAgICBjb25zdCBtYXRjaGVzU2VhcmNoID0gc2VhcmNoUXVlcnkgPT09ICcnIHx8IFxyXG4gICAgICAgIGFjdGl2aXR5LnRpdGxlPy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGxvd2VyQ2FzZVF1ZXJ5KSB8fFxyXG4gICAgICAgIGFjdGl2aXR5LmRlc2NyaXB0aW9uPy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGxvd2VyQ2FzZVF1ZXJ5KSB8fFxyXG4gICAgICAgIGFjdGl2aXR5LmNvbnRhY3Q/LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMobG93ZXJDYXNlUXVlcnkpIHx8XHJcbiAgICAgICAgYWN0aXZpdHkuY29tcGFueT8udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhsb3dlckNhc2VRdWVyeSk7XHJcbiAgICAgIFxyXG4gICAgICBsZXQgbWF0Y2hlc0RhdGUgPSB0cnVlO1xyXG4gICAgICBpZiAoc2VsZWN0ZWRGaWx0ZXJzLmRhdGVSYW5nZSAhPT0gJ2FsbCcpIHtcclxuICAgICAgICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpO1xyXG4gICAgICAgIGNvbnN0IGFjdGl2aXR5RGF0ZSA9IG5ldyBEYXRlKGFjdGl2aXR5LnRpbWVzdGFtcCk7XHJcbiAgICAgICAgc3dpdGNoIChzZWxlY3RlZEZpbHRlcnMuZGF0ZVJhbmdlKSB7XHJcbiAgICAgICAgICBjYXNlICd0b2RheSc6XHJcbiAgICAgICAgICAgIG1hdGNoZXNEYXRlID0gYWN0aXZpdHlEYXRlLnRvRGF0ZVN0cmluZygpID09PSBub3cudG9EYXRlU3RyaW5nKCk7XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgY2FzZSAnd2Vlayc6XHJcbiAgICAgICAgICAgIGNvbnN0IHdlZWtBZ28gPSBuZXcgRGF0ZShub3cuZ2V0VGltZSgpIC0gNyAqIDI0ICogNjAgKiA2MCAqIDEwMDApO1xyXG4gICAgICAgICAgICBtYXRjaGVzRGF0ZSA9IGFjdGl2aXR5RGF0ZSA+PSB3ZWVrQWdvO1xyXG4gICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgIGNhc2UgJ21vbnRoJzpcclxuICAgICAgICAgICAgY29uc3QgbW9udGhBZ28gPSBuZXcgRGF0ZShub3cuZ2V0VGltZSgpIC0gMzAgKiAyNCAqIDYwICogNjAgKiAxMDAwKTtcclxuICAgICAgICAgICAgbWF0Y2hlc0RhdGUgPSBhY3Rpdml0eURhdGUgPj0gbW9udGhBZ287XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICByZXR1cm4gbWF0Y2hlc1R5cGUgJiYgbWF0Y2hlc0NoYW5uZWwgJiYgbWF0Y2hlc1NlYXJjaCAmJiBtYXRjaGVzRGF0ZTtcclxuICAgIH0pO1xyXG4gIH0sIFt0cmFuc2Zvcm1lZEFjdGl2aXRpZXMsIHNlbGVjdGVkRmlsdGVycywgc2VhcmNoUXVlcnldKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRXhwb3J0VGltZWxpbmUgPSAoKSA9PiB7XHJcbiAgICBjb25zdCBleHBvcnREYXRhID0gZmlsdGVyZWRBY3Rpdml0aWVzLm1hcChhY3Rpdml0eSA9PiAoe1xyXG4gICAgICB0aW1lc3RhbXA6IGFjdGl2aXR5LnRpbWVzdGFtcC50b0lTT1N0cmluZygpLFxyXG4gICAgICB0eXBlOiBhY3Rpdml0eS50eXBlLFxyXG4gICAgICB0aXRsZTogYWN0aXZpdHkudGl0bGUsXHJcbiAgICAgIGNvbnRhY3Q6IGFjdGl2aXR5LmNvbnRhY3QsXHJcbiAgICAgIGNvbXBhbnk6IGFjdGl2aXR5LmNvbXBhbnksXHJcbiAgICAgIHVzZXI6IGFjdGl2aXR5LnVzZXIsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiBhY3Rpdml0eS5kZXNjcmlwdGlvblxyXG4gICAgfSkpO1xyXG4gICAgXHJcbiAgICBjb25zdCBibG9iID0gbmV3IEJsb2IoW0pTT04uc3RyaW5naWZ5KGV4cG9ydERhdGEsIG51bGwsIDIpXSwgeyB0eXBlOiAnYXBwbGljYXRpb24vanNvbicgfSk7XHJcbiAgICBjb25zdCB1cmwgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpO1xyXG4gICAgY29uc3QgYSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKTtcclxuICAgIGEuaHJlZiA9IHVybDtcclxuICAgIGEuZG93bmxvYWQgPSBgYWN0aXZpdHlfdGltZWxpbmVfJHtuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXX0uanNvbmA7XHJcbiAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGEpO1xyXG4gICAgYS5jbGljaygpO1xyXG4gICAgZG9jdW1lbnQuYm9keS5yZW1vdmVDaGlsZChhKTtcclxuICAgIFVSTC5yZXZva2VPYmplY3RVUkwodXJsKTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctYmFja2dyb3VuZFwiPlxyXG4gICAgICA8SGVhZGVyIC8+XHJcbiAgICAgIDxtYWluIGNsYXNzTmFtZT1cInB0LTE2XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy03eGwgbXgtYXV0byBweC02IHB5LThcIj5cclxuICAgICAgICAgIDxCcmVhZGNydW1iIC8+XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBsZzpmbGV4LXJvdyBsZzppdGVtcy1jZW50ZXIgbGc6anVzdGlmeS1iZXR3ZWVuIG1iLThcIj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtdGV4dC1wcmltYXJ5IG1iLTJcIj5BY3Rpdml0eSBUaW1lbGluZTwvaDE+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC10ZXh0LXNlY29uZGFyeVwiPlxyXG4gICAgICAgICAgICAgICAgVW5pZmllZCB2aWV3IG9mIGFsbCBjdXN0b21lciBpbnRlcmFjdGlvbnMgYWNyb3NzIGNvbW11bmljYXRpb24gY2hhbm5lbHNcclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTQgbXQtNCBsZzptdC0wXCI+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRXhwb3J0VGltZWxpbmV9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTIgcHgtNCBweS0yIGJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbGcgdGV4dC10ZXh0LXNlY29uZGFyeSBob3Zlcjp0ZXh0LXRleHQtcHJpbWFyeSBob3ZlcjpiZy1zdXJmYWNlLWhvdmVyIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTE1MCBlYXNlLW91dFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIkRvd25sb2FkXCIgc2l6ZT17MTZ9IC8+XHJcbiAgICAgICAgICAgICAgICA8c3Bhbj5FeHBvcnQgVGltZWxpbmU8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNBZGRNb2RhbE9wZW4odHJ1ZSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidG4tcHJpbWFyeSBmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTJcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJQbHVzXCIgc2l6ZT17MTZ9IC8+XHJcbiAgICAgICAgICAgICAgICA8c3Bhbj5BZGQgQWN0aXZpdHk8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAge2Vycm9yICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1lcnJvci01MCBib3JkZXIgYm9yZGVyLWVycm9yLTIwMCB0ZXh0LWVycm9yIHAtNCByb3VuZGVkLWxnIG1iLTYgZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCI+XHJcbiAgICAgICAgICAgICAgPEljb24gbmFtZT1cIkFsZXJ0Q2lyY2xlXCIgc2l6ZT17MjB9IC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4+e2Vycm9yfTwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIG1heC13LW1kXCI+XHJcbiAgICAgICAgICAgICAgPEljb24gbmFtZT1cIlNlYXJjaFwiIHNpemU9ezIwfSBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTMgdG9wLTEvMiB0cmFuc2Zvcm0gLXRyYW5zbGF0ZS15LTEvMiB0ZXh0LXRleHQtdGVydGlhcnlcIiAvPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggYWN0aXZpdGllcywgY29udGFjdHMsIG9yIGNvbXBhbmllcy4uLlwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17c2VhcmNoUXVlcnl9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlYXJjaFF1ZXJ5KGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlucHV0LWZpZWxkIHBsLTEwXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBsZzpmbGV4LXJvdyBnYXAtNlwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGxnOnctODAgJHtpc1NpZGViYXJPcGVuID8gJ2Jsb2NrJyA6ICdoaWRkZW4gbGc6YmxvY2snfWB9PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZCBwLTYgc3RpY2t5IHRvcC0yNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtdGV4dC1wcmltYXJ5XCI+RmlsdGVyczwvaDM+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc1NpZGViYXJPcGVuKCFpc1NpZGViYXJPcGVuKX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJsZzpoaWRkZW4gcC0xIHRleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC10ZXh0LXByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIlhcIiBzaXplPXsyMH0gLz5cclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPEFjdGl2aXR5RmlsdGVyc1xyXG4gICAgICAgICAgICAgICAgICBzZWxlY3RlZEZpbHRlcnM9e3NlbGVjdGVkRmlsdGVyc31cclxuICAgICAgICAgICAgICAgICAgb25GaWx0ZXJzQ2hhbmdlPXtzZXRTZWxlY3RlZEZpbHRlcnN9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc1NpZGViYXJPcGVuKCFpc1NpZGViYXJPcGVuKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJsZzpoaWRkZW4gZml4ZWQgYm90dG9tLTYgcmlnaHQtNiB3LTE0IGgtMTQgYmctcHJpbWFyeSB0ZXh0LXdoaXRlIHJvdW5kZWQtZnVsbCBzaGFkb3ctbGcgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgei01MFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiRmlsdGVyXCIgc2l6ZT17MjB9IC8+XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi02XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC10ZXh0LXNlY29uZGFyeVwiPlxyXG4gICAgICAgICAgICAgICAgICBTaG93aW5nIHtmaWx0ZXJlZEFjdGl2aXRpZXMubGVuZ3RofSBvZiB7YWN0aXZpdGllcy5sZW5ndGh9IGFjdGl2aXRpZXNcclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICB7KHNlbGVjdGVkRmlsdGVycy5hY3Rpdml0eVR5cGUgIT09ICdhbGwnIHx8IHNlbGVjdGVkRmlsdGVycy5kYXRlUmFuZ2UgIT09ICdhbGwnIHx8IFxyXG4gICAgICAgICAgICAgICAgICBzZWxlY3RlZEZpbHRlcnMuY2hhbm5lbCAhPT0gJ2FsbCcgfHwgc2VhcmNoUXVlcnkpICYmIChcclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkRmlsdGVycyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjdGl2aXR5VHlwZTogJ2FsbCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGVSYW5nZTogJ2FsbCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRlYW1NZW1iZXI6ICdhbGwnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGFubmVsOiAnYWxsJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRTZWFyY2hRdWVyeSgnJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtcHJpbWFyeSBob3Zlcjp0ZXh0LXByaW1hcnktNzAwIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MCBlYXNlLW91dFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBDbGVhciBhbGwgZmlsdGVyc1xyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHtsb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS0xMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFuaW1hdGUtc3BpbiByb3VuZGVkLWZ1bGwgaC0xMiB3LTEyIGJvcmRlci1iLTIgYm9yZGVyLXByaW1hcnkgbXgtYXV0byBtYi00XCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtdGV4dC1zZWNvbmRhcnlcIj5Mb2FkaW5nIGFjdGl2aXRpZXMuLi48L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cclxuICAgICAgICAgICAgICAgICAge2ZpbHRlcmVkQWN0aXZpdGllcy5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgICAgICAgICAgICAgIGZpbHRlcmVkQWN0aXZpdGllcy5tYXAoKGFjdGl2aXR5LCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPEFjdGl2aXR5Q2FyZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2FjdGl2aXR5LmlkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY3Rpdml0eT17YWN0aXZpdHl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzTGFzdD17aW5kZXggPT09IGZpbHRlcmVkQWN0aXZpdGllcy5sZW5ndGggLSAxfVxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICApKVxyXG4gICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktMTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xNiBoLTE2IGJnLXByaW1hcnktNTAgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG14LWF1dG8gbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiQ2xvY2tcIiBzaXplPXszMn0gY2xhc3NOYW1lPVwidGV4dC1wcmltYXJ5XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXRleHQtcHJpbWFyeSBtYi0yXCI+Tm8gYWN0aXZpdGllcyBmb3VuZDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5IG1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgVHJ5IGFkanVzdGluZyB5b3VyIGZpbHRlcnMgb3Igc2VhcmNoIHRlcm1zIHRvIGZpbmQgYWN0aXZpdGllcy5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNBZGRNb2RhbE9wZW4odHJ1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQWRkIEZpcnN0IEFjdGl2aXR5XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvbWFpbj5cclxuICAgICAgXHJcbiAgICAgIHtpc0FkZE1vZGFsT3BlbiAmJiAoXHJcbiAgICAgICAgPEFkZEFjdGl2aXR5TW9kYWxcclxuICAgICAgICAgIGlzT3Blbj17aXNBZGRNb2RhbE9wZW59XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRJc0FkZE1vZGFsT3BlbihmYWxzZSl9XHJcbiAgICAgICAgICBvbkFjdGl2aXR5QWRkZWQ9e2hhbmRsZUFjdGl2aXR5QWRkZWR9XHJcbiAgICAgICAgLz5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBBY3Rpdml0eVRpbWVsaW5lOyAvLyBcIkVudGVycHJpc2UgQ1JNIEltcGxlbWVudGF0aW9uIC0gVGVjaENvcnBcIiBtb3ZlZCBmcm9tIFwiUHJvcG9zYWwgU2VudFwiIHRvIFwiTmVnb3RpYXRpb25cIiBzdGFnZS5cclxuXHJcbi8vIFN0YWdlIHByb2dyZXNzaW9uIGRldGFpbHM6XHJcbi8vIOKAoiBQcmV2aW91cyBzdGFnZTogUHJvcG9zYWwgU2VudCAoNyBkYXlzKVxyXG4vLyDigKIgQ3VycmVudCBzdGFnZTogTmVnb3RpYXRpb25cclxuLy8g4oCiIFByb2JhYmlsaXR5IHVwZGF0ZWQ6IDYwJSDihpIgNzUlXHJcbi8vIOKAoiBFeHBlY3RlZCBjbG9zZSBkYXRlOiBNYXJjaCAxNSwgMjAyNFxyXG4vLyDigKIgRGVhbCB2YWx1ZTogJDQ1LDAwMFxyXG5cclxuLy8gQXV0b21hdGVkIGZvbGxvdy11cCB0YXNrcyBjcmVhdGVkOlxyXG4vLyDigKIgU2NoZWR1bGUgY29udHJhY3QgcmV2aWV3IG1lZXRpbmdcclxuLy8g4oCiIFByZXBhcmUgaW1wbGVtZW50YXRpb24gdGltZWxpbmVcclxuLy8g4oCiIENvb3JkaW5hdGUgd2l0aCBsZWdhbCB0ZWFtIGZvciBjb250cmFjdCB0ZXJtc2AsXHJcbi8vICAgICAgIGNvbnRhY3Q6ICdTYXJhaCBKb2huc29uJyxcclxuLy8gICAgICAgY29tcGFueTogJ1RlY2hDb3JwIFNvbHV0aW9ucycsXHJcbi8vICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoRGF0ZS5ub3coKSAtIDggKiA2MCAqIDYwICogMTAwMCksXHJcbi8vICAgICAgIHVzZXI6ICdTeXN0ZW0nLFxyXG4vLyAgICAgICBhdmF0YXI6IG51bGwsXHJcbi8vICAgICAgIGNvbnRhY3RBdmF0YXI6ICdodHRwczovL2ltYWdlcy51bnNwbGFzaC5jb20vcGhvdG8tMTQ5NDc5MDEwODc1NS0yNjE2YjYxMmI3ODY/dz0xNTAmaD0xNTAmZml0PWNyb3AmY3JvcD1mYWNlJyxcclxuLy8gICAgICAgcHJldmlvdXNTdGFnZTogJ1Byb3Bvc2FsIFNlbnQnLFxyXG4vLyAgICAgICBjdXJyZW50U3RhZ2U6ICdOZWdvdGlhdGlvbicsXHJcbi8vICAgICAgIHByb2JhYmlsaXR5OiA3NSxcclxuLy8gICAgICAgc3RhdHVzOiAndXBkYXRlZCcsXHJcbi8vICAgICAgIHByaW9yaXR5OiAnbWVkaXVtJyxcclxuLy8gICAgICAgZGVhbFZhbHVlOiAnJDQ1LDAwMCdcclxuLy8gICAgIH0sXHJcbi8vICAgICB7XHJcbi8vICAgICAgIGlkOiA1LFxyXG4vLyAgICAgICB0eXBlOiAnZW1haWwnLFxyXG4vLyAgICAgICBjaGFubmVsOiAnZ21haWwnLFxyXG4vLyAgICAgICB0aXRsZTogJ0NvbnRyYWN0IFRlcm1zIFJlY2VpdmVkJyxcclxuLy8gICAgICAgZGVzY3JpcHRpb246IGBSZWNlaXZlZCBjb250cmFjdCB0ZXJtcyBhbmQgY29uZGl0aW9ucyBmcm9tIEdsb2JhbFRlY2gncyBsZWdhbCB0ZWFtLiBLZXkgcG9pbnRzIGZvciByZXZpZXc6XHJcblxyXG4vLyDigKIgUGF5bWVudCB0ZXJtczogTmV0IDMwIGRheXNcclxuLy8g4oCiIEltcGxlbWVudGF0aW9uIHRpbWVsaW5lOiA5MCBkYXlzIGZyb20gY29udHJhY3Qgc2lnbmluZ1xyXG4vLyDigKIgRGF0YSBtaWdyYXRpb24gcmVxdWlyZW1lbnRzOiBGdWxsIFNhbGVzZm9yY2UgZXhwb3J0XHJcbi8vIOKAoiBUcmFpbmluZyByZXF1aXJlbWVudHM6IDIwIGhvdXJzIG9mIHVzZXIgdHJhaW5pbmdcclxuLy8g4oCiIFN1cHBvcnQgbGV2ZWw6IFByZW1pdW0gc3VwcG9ydCB3aXRoIDQtaG91ciByZXNwb25zZSBTTEFcclxuLy8g4oCiIENvbnRyYWN0IGR1cmF0aW9uOiAzIHllYXJzIHdpdGggYW5udWFsIHJlbmV3YWwgb3B0aW9uXHJcblxyXG4vLyBMZWdhbCByZXZpZXcgc2NoZWR1bGVkIGZvciB0b21vcnJvdyBtb3JuaW5nLiBDb250cmFjdCBsb29rcyBmYXZvcmFibGUgd2l0aCBtaW5vciBhZGp1c3RtZW50cyBuZWVkZWQgZm9yIGltcGxlbWVudGF0aW9uIHRpbWVsaW5lLmAsXHJcbi8vICAgICAgIGNvbnRhY3Q6ICdMaXNhIFBhcmsnLGNvbXBhbnk6ICdHbG9iYWxUZWNoIEluZHVzdHJpZXMnLHRpbWVzdGFtcDogbmV3IERhdGUoRGF0ZS5ub3coKSAtIDEyICogNjAgKiA2MCAqIDEwMDApLHVzZXI6ICdBbGV4IFRob21wc29uJyxhdmF0YXI6ICdodHRwczovL2ltYWdlcy51bnNwbGFzaC5jb20vcGhvdG8tMTUwMDY0ODc2Nzc5MS0wMGRjYzk5NGE0M2U/dz0xNTAmaD0xNTAmZml0PWNyb3AmY3JvcD1mYWNlJyxjb250YWN0QXZhdGFyOiAnaHR0cHM6Ly9pbWFnZXMudW5zcGxhc2guY29tL3Bob3RvLTE1NzM0OTYzNTkxNDItYjhkODc3MzRhNWEyP3c9MTUwJmg9MTUwJmZpdD1jcm9wJmNyb3A9ZmFjZScsc3RhdHVzOiAncmVjZWl2ZWQnLHByaW9yaXR5OiAnaGlnaCcsZGVhbFZhbHVlOiAnJDEyNSwwMDAnLFxyXG4vLyAgICAgICBhdHRhY2htZW50czogWydjb250cmFjdF90ZXJtc19nbG9iYWx0ZWNoLnBkZicsICdzbGFfYWdyZWVtZW50LnBkZiddXHJcbi8vICAgICB9LFxyXG4vLyAgICAge1xyXG4vLyAgICAgICBpZDogNixcclxuLy8gICAgICAgdHlwZTogJ3Rhc2snLGNoYW5uZWw6ICdzeXN0ZW0nLHRpdGxlOiAnRm9sbG93LXVwIFRhc2sgQ29tcGxldGVkJyxcclxuLy8gICAgICAgZGVzY3JpcHRpb246IGBDb21wbGV0ZWQgZm9sbG93LXVwIHRhc2s6IFwiU2VuZCBwcmljaW5nIGNvbXBhcmlzb24gZG9jdW1lbnQgdG8gSW5ub3ZhdGVUZWNoXCJcclxuXHJcbi8vIFRhc2sgZGV0YWlsczpcclxuLy8g4oCiIENyZWF0ZWQ6IDMgZGF5cyBhZ29cclxuLy8g4oCiIEFzc2lnbmVkIHRvOiBKZW5uaWZlciBXYWxzaFxyXG4vLyDigKIgUHJpb3JpdHk6IEhpZ2hcclxuLy8g4oCiIER1ZSBkYXRlOiBUb2RheVxyXG4vLyDigKIgU3RhdHVzOiBDb21wbGV0ZWRcclxuXHJcbi8vIEFjdGlvbnMgdGFrZW46XHJcbi8vIOKAoiBQcmVwYXJlZCBjb21wcmVoZW5zaXZlIHByaWNpbmcgY29tcGFyaXNvbiB3aXRoIGNvbXBldGl0b3JzXHJcbi8vIOKAoiBIaWdobGlnaHRlZCBTYWxlc0Zsb3cgUHJvJ3MgdW5pcXVlIHZhbHVlIHByb3Bvc2l0aW9uc1xyXG4vLyDigKIgSW5jbHVkZWQgUk9JIGNhbGN1bGF0b3IgYW5kIGltcGxlbWVudGF0aW9uIHRpbWVsaW5lXHJcbi8vIOKAoiBTZW50IHZpYSBlbWFpbCB3aXRoIHJlYWQgcmVjZWlwdCBjb25maXJtYXRpb25cclxuXHJcbi8vIE5leHQgYWN0aW9uOiBTY2hlZHVsZSBmb2xsb3ctdXAgY2FsbCB3aXRoaW4gNDggaG91cnMgdG8gZGlzY3VzcyBwcmljaW5nIGZlZWRiYWNrLmAsXHJcbi8vICAgICAgIGNvbnRhY3Q6ICdEYXZpZCBDaGVuJyxcclxuLy8gICAgICAgY29tcGFueTogJ0lubm92YXRlVGVjaCcsXHJcbi8vICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoRGF0ZS5ub3coKSAtIDE2ICogNjAgKiA2MCAqIDEwMDApLFxyXG4vLyAgICAgICB1c2VyOiAnSmVubmlmZXIgV2Fsc2gnLFxyXG4vLyAgICAgICBhdmF0YXI6ICdodHRwczovL2ltYWdlcy51bnNwbGFzaC5jb20vcGhvdG8tMTQzODc2MTY4MTAzMy02NDYxZmZhZDhkODA/dz0xNTAmaD0xNTAmZml0PWNyb3AmY3JvcD1mYWNlJyxcclxuLy8gICAgICAgY29udGFjdEF2YXRhcjogJ2h0dHBzOi8vaW1hZ2VzLnVuc3BsYXNoLmNvbS9waG90by0xNDcyMDk5NjQ1Nzg1LTU2NThhYmY0ZmY0ZT93PTE1MCZoPTE1MCZmaXQ9Y3JvcCZjcm9wPWZhY2UnLFxyXG4vLyAgICAgICB0YXNrVHlwZTogJ2ZvbGxvd191cCcsXHJcbi8vICAgICAgIHN0YXR1czogJ2NvbXBsZXRlZCcsXHJcbi8vICAgICAgIHByaW9yaXR5OiAnaGlnaCcsXHJcbi8vICAgICAgIGRlYWxWYWx1ZTogJyQ0MiwwMDAnXHJcbi8vICAgICB9XHJcbi8vICAgXTtcclxuXHJcbi8vICAgY29uc3QgZmlsdGVyZWRBY3Rpdml0aWVzID0gdXNlTWVtbygoKSA9PiB7XHJcbi8vICAgICByZXR1cm4gYWN0aXZpdGllcz8uZmlsdGVyKGFjdGl2aXR5ID0+IHtcclxuLy8gICAgICAgY29uc3QgbWF0Y2hlc1R5cGUgPSBzZWxlY3RlZEZpbHRlcnM/LmFjdGl2aXR5VHlwZSA9PT0gJ2FsbCcgfHwgYWN0aXZpdHk/LnR5cGUgPT09IHNlbGVjdGVkRmlsdGVycz8uYWN0aXZpdHlUeXBlO1xyXG4vLyAgICAgICBjb25zdCBtYXRjaGVzQ2hhbm5lbCA9IHNlbGVjdGVkRmlsdGVycz8uY2hhbm5lbCA9PT0gJ2FsbCcgfHwgYWN0aXZpdHk/LmNoYW5uZWwgPT09IHNlbGVjdGVkRmlsdGVycz8uY2hhbm5lbDtcclxuLy8gICAgICAgY29uc3QgbWF0Y2hlc1NlYXJjaCA9IHNlYXJjaFF1ZXJ5ID09PSAnJyB8fCBcclxuLy8gICAgICAgICBhY3Rpdml0eT8udGl0bGU/LnRvTG93ZXJDYXNlKCk/LmluY2x1ZGVzKHNlYXJjaFF1ZXJ5Py50b0xvd2VyQ2FzZSgpKSB8fFxyXG4vLyAgICAgICAgIGFjdGl2aXR5Py5kZXNjcmlwdGlvbj8udG9Mb3dlckNhc2UoKT8uaW5jbHVkZXMoc2VhcmNoUXVlcnk/LnRvTG93ZXJDYXNlKCkpIHx8XHJcbi8vICAgICAgICAgYWN0aXZpdHk/LmNvbnRhY3Q/LnRvTG93ZXJDYXNlKCk/LmluY2x1ZGVzKHNlYXJjaFF1ZXJ5Py50b0xvd2VyQ2FzZSgpKSB8fFxyXG4vLyAgICAgICAgIGFjdGl2aXR5Py5jb21wYW55Py50b0xvd2VyQ2FzZSgpPy5pbmNsdWRlcyhzZWFyY2hRdWVyeT8udG9Mb3dlckNhc2UoKSk7XHJcbiAgICAgIFxyXG4vLyAgICAgICBsZXQgbWF0Y2hlc0RhdGUgPSB0cnVlO1xyXG4vLyAgICAgICBpZiAoc2VsZWN0ZWRGaWx0ZXJzPy5kYXRlUmFuZ2UgIT09ICdhbGwnKSB7XHJcbi8vICAgICAgICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKTtcclxuLy8gICAgICAgICBjb25zdCBhY3Rpdml0eURhdGUgPSBuZXcgRGF0ZShhY3Rpdml0eS50aW1lc3RhbXApO1xyXG4vLyAgICAgICAgIHN3aXRjaCAoc2VsZWN0ZWRGaWx0ZXJzPy5kYXRlUmFuZ2UpIHtcclxuLy8gICAgICAgICAgIGNhc2UgJ3RvZGF5JzpcclxuLy8gICAgICAgICAgICAgbWF0Y2hlc0RhdGUgPSBhY3Rpdml0eURhdGU/LnRvRGF0ZVN0cmluZygpID09PSBub3c/LnRvRGF0ZVN0cmluZygpO1xyXG4vLyAgICAgICAgICAgICBicmVhaztcclxuLy8gICAgICAgICAgIGNhc2UgJ3dlZWsnOlxyXG4vLyAgICAgICAgICAgICBjb25zdCB3ZWVrQWdvID0gbmV3IERhdGUobm93LmdldFRpbWUoKSAtIDcgKiAyNCAqIDYwICogNjAgKiAxMDAwKTtcclxuLy8gICAgICAgICAgICAgbWF0Y2hlc0RhdGUgPSBhY3Rpdml0eURhdGUgPj0gd2Vla0FnbztcclxuLy8gICAgICAgICAgICAgYnJlYWs7XHJcbi8vICAgICAgICAgICBjYXNlICdtb250aCc6XHJcbi8vICAgICAgICAgICAgIGNvbnN0IG1vbnRoQWdvID0gbmV3IERhdGUobm93LmdldFRpbWUoKSAtIDMwICogMjQgKiA2MCAqIDYwICogMTAwMCk7XHJcbi8vICAgICAgICAgICAgIG1hdGNoZXNEYXRlID0gYWN0aXZpdHlEYXRlID49IG1vbnRoQWdvO1xyXG4vLyAgICAgICAgICAgICBicmVhaztcclxuLy8gICAgICAgICB9XHJcbi8vICAgICAgIH1cclxuXHJcbi8vICAgICAgIHJldHVybiBtYXRjaGVzVHlwZSAmJiBtYXRjaGVzQ2hhbm5lbCAmJiBtYXRjaGVzU2VhcmNoICYmIG1hdGNoZXNEYXRlO1xyXG4vLyAgICAgfSk7XHJcbi8vICAgfSwgW2FjdGl2aXRpZXMsIHNlbGVjdGVkRmlsdGVycywgc2VhcmNoUXVlcnldKTtcclxuXHJcbi8vICAgY29uc3QgaGFuZGxlRXhwb3J0VGltZWxpbmUgPSAoKSA9PiB7XHJcbi8vICAgICBjb25zdCBleHBvcnREYXRhID0gZmlsdGVyZWRBY3Rpdml0aWVzPy5tYXAoYWN0aXZpdHkgPT4gKHtcclxuLy8gICAgICAgdGltZXN0YW1wOiBhY3Rpdml0eT8udGltZXN0YW1wPy50b0lTT1N0cmluZygpLFxyXG4vLyAgICAgICB0eXBlOiBhY3Rpdml0eT8udHlwZSxcclxuLy8gICAgICAgdGl0bGU6IGFjdGl2aXR5Py50aXRsZSxcclxuLy8gICAgICAgY29udGFjdDogYWN0aXZpdHk/LmNvbnRhY3QsXHJcbi8vICAgICAgIGNvbXBhbnk6IGFjdGl2aXR5Py5jb21wYW55LFxyXG4vLyAgICAgICB1c2VyOiBhY3Rpdml0eT8udXNlcixcclxuLy8gICAgICAgZGVzY3JpcHRpb246IGFjdGl2aXR5Py5kZXNjcmlwdGlvblxyXG4vLyAgICAgfSkpO1xyXG4gICAgXHJcbi8vICAgICBjb25zdCBibG9iID0gbmV3IEJsb2IoW0pTT04uc3RyaW5naWZ5KGV4cG9ydERhdGEsIG51bGwsIDIpXSwgeyB0eXBlOiAnYXBwbGljYXRpb24vanNvbicgfSk7XHJcbi8vICAgICBjb25zdCB1cmwgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpO1xyXG4vLyAgICAgY29uc3QgYSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKTtcclxuLy8gICAgIGEuaHJlZiA9IHVybDtcclxuLy8gICAgIGEuZG93bmxvYWQgPSBgYWN0aXZpdHlfdGltZWxpbmVfJHtuZXcgRGF0ZSgpPy50b0lTT1N0cmluZygpPy5zcGxpdCgnVCcpPy5bMF19Lmpzb25gO1xyXG4vLyAgICAgZG9jdW1lbnQuYm9keT8uYXBwZW5kQ2hpbGQoYSk7XHJcbi8vICAgICBhPy5jbGljaygpO1xyXG4vLyAgICAgZG9jdW1lbnQuYm9keT8ucmVtb3ZlQ2hpbGQoYSk7XHJcbi8vICAgICBVUkwucmV2b2tlT2JqZWN0VVJMKHVybCk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgcmV0dXJuIChcclxuLy8gICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGJnLWJhY2tncm91bmRcIj5cclxuLy8gICAgICAgPEhlYWRlciAvPlxyXG4vLyAgICAgICA8bWFpbiBjbGFzc05hbWU9XCJwdC0xNlwiPlxyXG4vLyAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctN3hsIG14LWF1dG8gcHgtNiBweS04XCI+XHJcbi8vICAgICAgICAgICA8QnJlYWRjcnVtYiAvPlxyXG4gICAgICAgICAgXHJcbi8vICAgICAgICAgICB7LyogUGFnZSBIZWFkZXIgKi99XHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbGc6ZmxleC1yb3cgbGc6aXRlbXMtY2VudGVyIGxnOmp1c3RpZnktYmV0d2VlbiBtYi04XCI+XHJcbi8vICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LXRleHQtcHJpbWFyeSBtYi0yXCI+QWN0aXZpdHkgVGltZWxpbmU8L2gxPlxyXG4vLyAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtdGV4dC1zZWNvbmRhcnlcIj5cclxuLy8gICAgICAgICAgICAgICAgIFVuaWZpZWQgdmlldyBvZiBhbGwgY3VzdG9tZXIgaW50ZXJhY3Rpb25zIGFjcm9zcyBjb21tdW5pY2F0aW9uIGNoYW5uZWxzXHJcbi8vICAgICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgXHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC00IG10LTQgbGc6bXQtMFwiPlxyXG4vLyAgICAgICAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUV4cG9ydFRpbWVsaW5lfVxyXG4vLyAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yIHB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLWxnIHRleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC10ZXh0LXByaW1hcnkgaG92ZXI6Ymctc3VyZmFjZS1ob3ZlciB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0xNTAgZWFzZS1vdXRcIlxyXG4vLyAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJEb3dubG9hZFwiIHNpemU9ezE2fSAvPlxyXG4vLyAgICAgICAgICAgICAgICAgPHNwYW4+RXhwb3J0IFRpbWVsaW5lPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIFxyXG4vLyAgICAgICAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzQWRkTW9kYWxPcGVuKHRydWUpfVxyXG4vLyAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLXByaW1hcnkgZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCJcclxuLy8gICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiUGx1c1wiIHNpemU9ezE2fSAvPlxyXG4vLyAgICAgICAgICAgICAgICAgPHNwYW4+QWRkIEFjdGl2aXR5PC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgIHsvKiBTZWFyY2ggQmFyICovfVxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02XCI+XHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgbWF4LXctbWRcIj5cclxuLy8gICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiU2VhcmNoXCIgc2l6ZT17MjB9IGNsYXNzTmFtZT1cImFic29sdXRlIGxlZnQtMyB0b3AtMS8yIHRyYW5zZm9ybSAtdHJhbnNsYXRlLXktMS8yIHRleHQtdGV4dC10ZXJ0aWFyeVwiIC8+XHJcbi8vICAgICAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbi8vICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBhY3Rpdml0aWVzLCBjb250YWN0cywgb3IgY29tcGFuaWVzLi4uXCJcclxuLy8gICAgICAgICAgICAgICAgIHZhbHVlPXtzZWFyY2hRdWVyeX1cclxuLy8gICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VhcmNoUXVlcnkoZT8udGFyZ2V0Py52YWx1ZSl9XHJcbi8vICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbnB1dC1maWVsZCBwbC0xMFwiXHJcbi8vICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbGc6ZmxleC1yb3cgZ2FwLTZcIj5cclxuLy8gICAgICAgICAgICAgey8qIFNpZGViYXIgRmlsdGVycyAqL31cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BsZzp3LTgwICR7aXNTaWRlYmFyT3BlbiA/ICdibG9jaycgOiAnaGlkZGVuIGxnOmJsb2NrJ31gfT5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgcC02IHN0aWNreSB0b3AtMjRcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTRcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXRleHQtcHJpbWFyeVwiPkZpbHRlcnM8L2gzPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbi8vICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNTaWRlYmFyT3BlbighaXNTaWRlYmFyT3Blbil9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibGc6aGlkZGVuIHAtMSB0ZXh0LXRleHQtc2Vjb25kYXJ5IGhvdmVyOnRleHQtdGV4dC1wcmltYXJ5XCJcclxuLy8gICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJYXCIgc2l6ZT17MjB9IC8+XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICBcclxuLy8gICAgICAgICAgICAgICAgIDxBY3Rpdml0eUZpbHRlcnNcclxuLy8gICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRGaWx0ZXJzPXtzZWxlY3RlZEZpbHRlcnN9XHJcbi8vICAgICAgICAgICAgICAgICAgIG9uRmlsdGVyc0NoYW5nZT17c2V0U2VsZWN0ZWRGaWx0ZXJzfVxyXG4vLyAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICB7LyogTW9iaWxlIEZpbHRlciBUb2dnbGUgKi99XHJcbi8vICAgICAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc1NpZGViYXJPcGVuKCFpc1NpZGViYXJPcGVuKX1cclxuLy8gICAgICAgICAgICAgICBjbGFzc05hbWU9XCJsZzpoaWRkZW4gZml4ZWQgYm90dG9tLTYgcmlnaHQtNiB3LTE0IGgtMTQgYmctcHJpbWFyeSB0ZXh0LXdoaXRlIHJvdW5kZWQtZnVsbCBzaGFkb3ctbGcgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgei01MFwiXHJcbi8vICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiRmlsdGVyXCIgc2l6ZT17MjB9IC8+XHJcbi8vICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuLy8gICAgICAgICAgICAgey8qIFRpbWVsaW5lIENvbnRlbnQgKi99XHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XHJcbi8vICAgICAgICAgICAgICAgey8qIFJlc3VsdHMgU3VtbWFyeSAqL31cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi02XCI+XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC10ZXh0LXNlY29uZGFyeVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICBTaG93aW5nIHtmaWx0ZXJlZEFjdGl2aXRpZXM/Lmxlbmd0aH0gb2Yge2FjdGl2aXRpZXM/Lmxlbmd0aH0gYWN0aXZpdGllc1xyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICBcclxuLy8gICAgICAgICAgICAgICAgIHsoc2VsZWN0ZWRGaWx0ZXJzPy5hY3Rpdml0eVR5cGUgIT09ICdhbGwnIHx8IHNlbGVjdGVkRmlsdGVycz8uZGF0ZVJhbmdlICE9PSAnYWxsJyB8fCBcclxuLy8gICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRGaWx0ZXJzPy5jaGFubmVsICE9PSAnYWxsJyB8fCBzZWFyY2hRdWVyeSkgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbi8vICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRGaWx0ZXJzKHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgYWN0aXZpdHlUeXBlOiAnYWxsJyxcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgZGF0ZVJhbmdlOiAnYWxsJyxcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgdGVhbU1lbWJlcjogJ2FsbCcsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIGNoYW5uZWw6ICdhbGwnXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHNldFNlYXJjaFF1ZXJ5KCcnKTtcclxuLy8gICAgICAgICAgICAgICAgICAgICB9fVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1wcmltYXJ5IGhvdmVyOnRleHQtcHJpbWFyeS03MDAgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwIGVhc2Utb3V0XCJcclxuLy8gICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIENsZWFyIGFsbCBmaWx0ZXJzXHJcbi8vICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgICAgey8qIFRpbWVsaW5lICovfVxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XHJcbi8vICAgICAgICAgICAgICAgICB7ZmlsdGVyZWRBY3Rpdml0aWVzPy5sZW5ndGggPiAwID8gKFxyXG4vLyAgICAgICAgICAgICAgICAgICBmaWx0ZXJlZEFjdGl2aXRpZXM/Lm1hcCgoYWN0aXZpdHksIGluZGV4KSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPEFjdGl2aXR5Q2FyZFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAga2V5PXthY3Rpdml0eT8uaWR9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBhY3Rpdml0eT17YWN0aXZpdHl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBpc0xhc3Q9e2luZGV4ID09PSBmaWx0ZXJlZEFjdGl2aXRpZXM/Lmxlbmd0aCAtIDF9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgKSlcclxuLy8gICAgICAgICAgICAgICAgICkgOiAoXHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktMTJcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTYgaC0xNiBiZy1wcmltYXJ5LTUwIHJvdW5kZWQtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBteC1hdXRvIG1iLTRcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJDbG9ja1wiIHNpemU9ezMyfSBjbGFzc05hbWU9XCJ0ZXh0LXByaW1hcnlcIiAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC10ZXh0LXByaW1hcnkgbWItMlwiPk5vIGFjdGl2aXRpZXMgZm91bmQ8L2gzPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtdGV4dC1zZWNvbmRhcnkgbWItNFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgVHJ5IGFkanVzdGluZyB5b3VyIGZpbHRlcnMgb3Igc2VhcmNoIHRlcm1zIHRvIGZpbmQgYWN0aXZpdGllcy5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNBZGRNb2RhbE9wZW4odHJ1ZSl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidG4tcHJpbWFyeVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgQWRkIEZpcnN0IEFjdGl2aXR5XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgPC9tYWluPlxyXG4vLyAgICAgICB7LyogQWRkIEFjdGl2aXR5IE1vZGFsICovfVxyXG4vLyAgICAgICB7aXNBZGRNb2RhbE9wZW4gJiYgKFxyXG4vLyAgICAgICAgIDxBZGRBY3Rpdml0eU1vZGFsXHJcbi8vICAgICAgICAgICBpc09wZW49e2lzQWRkTW9kYWxPcGVufVxyXG4vLyAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0SXNBZGRNb2RhbE9wZW4oZmFsc2UpfVxyXG4vLyAgICAgICAgIC8+XHJcbi8vICAgICAgICl9XHJcbi8vICAgICA8L2Rpdj5cclxuLy8gICApO1xyXG4vLyB9O1xyXG5cclxuLy8gZXhwb3J0IGRlZmF1bHQgQWN0aXZpdHlUaW1lbGluZTsiXSwiZmlsZSI6IkQ6L2N1cnJlbnQgcHJvamVjdHMvY2xhdWRlLWNvZGUvc3JjL3BhZ2VzL2FjdGl2aXR5LXRpbWVsaW5lL2luZGV4LmpzeCJ9