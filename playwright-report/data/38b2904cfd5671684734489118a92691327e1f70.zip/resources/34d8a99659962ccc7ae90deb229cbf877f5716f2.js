import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/settings-administration/components/SystemConfiguration.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import Icon from "/src/components/AppIcon.jsx";
const SystemConfiguration = () => {
  _s();
  const [config, setConfig] = useState({
    general: {
      companyName: "SalesFlow Pro Inc.",
      timezone: "America/New_York",
      dateFormat: "MM/DD/YYYY",
      currency: "USD",
      language: "en"
    },
    sales: {
      defaultPipelineStage: "Prospecting",
      dealCurrency: "USD",
      requireDealValue: true,
      autoProgressDeals: false,
      dealInactivityDays: 30
    },
    notifications: {
      emailNotifications: true,
      dealUpdateNotifications: true,
      taskReminders: true,
      weeklyReports: true,
      systemAlerts: true
    },
    security: {
      passwordComplexity: true,
      twoFactorAuth: false,
      sessionTimeout: 480,
      loginAttempts: 5,
      dataEncryption: true
    },
    backup: {
      autoBackup: true,
      backupFrequency: "daily",
      retentionDays: 30,
      backupLocation: "cloud"
    }
  });
  const [hasChanges, setHasChanges] = useState(false);
  const [exportFormat, setExportFormat] = useState("json");
  const [showExportModal, setShowExportModal] = useState(false);
  const timezones = [
    "America/New_York",
    "America/Chicago",
    "America/Denver",
    "America/Los_Angeles",
    "Europe/London",
    "Europe/Paris",
    "Asia/Tokyo",
    "Asia/Shanghai",
    "Australia/Sydney"
  ];
  const currencies = [
    { code: "USD", name: "US Dollar" },
    { code: "EUR", name: "Euro" },
    { code: "GBP", name: "British Pound" },
    { code: "CAD", name: "Canadian Dollar" },
    { code: "AUD", name: "Australian Dollar" },
    { code: "JPY", name: "Japanese Yen" }
  ];
  const dateFormats = [
    "MM/DD/YYYY",
    "DD/MM/YYYY",
    "YYYY-MM-DD",
    "DD-MM-YYYY"
  ];
  const languages = [
    { code: "en", name: "English" },
    { code: "es", name: "Spanish" },
    { code: "fr", name: "French" },
    { code: "de", name: "German" },
    { code: "it", name: "Italian" }
  ];
  const updateConfig = (section, field, value) => {
    setConfig((prev) => ({
      ...prev,
      [section]: {
        ...prev?.[section],
        [field]: value
      }
    }));
    setHasChanges(true);
  };
  const handleSaveChanges = () => {
    console.log("Saving configuration:", config);
    setHasChanges(false);
  };
  const handleExportConfig = () => {
    const configData = exportFormat === "json" ? JSON.stringify(config, null, 2) : config;
    const blob = new Blob([configData], { type: exportFormat === "json" ? "application/json" : "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `system-config.${exportFormat}`;
    document.body?.appendChild(a);
    a?.click();
    document.body?.removeChild(a);
    URL.revokeObjectURL(url);
    setShowExportModal(false);
  };
  const handleTestBackup = () => {
    console.log("Testing backup system...");
  };
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:120:4", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "120", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-6%22%7D", className: "space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:122:6", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "122", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:123:8", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "123", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
        /* @__PURE__ */ jsxDEV("h2", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:124:10", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "124", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "h2", "data-component-content": "%7B%22elementName%22%3A%22h2%22%2C%22className%22%3A%22text-2xl%20font-bold%20text-text-primary%22%2C%22textContent%22%3A%22System%20Configuration%22%7D", className: "text-2xl font-bold text-text-primary", children: "System Configuration" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
          lineNumber: 124,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:125:10", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "125", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20mt-1%22%2C%22textContent%22%3A%22Manage%20general%20system%20settings%20and%20preferences%22%7D", className: "text-text-secondary mt-1", children: "Manage general system settings and preferences" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
          lineNumber: 125,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
        lineNumber: 123,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:127:8", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "127", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20space-x-3%22%7D", className: "flex space-x-3", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:128:10",
            "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx",
            "data-component-line": "128",
            "data-component-file": "SystemConfiguration.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22bg-background%20text-text-primary%20px-4%20py-2%20rounded-lg%20hover%3Abg-surface-hover%20transition-colors%20duration-150%20ease-smooth%20flex%20items-center%20space-x-2%20border%20border-border%22%7D",
            onClick: () => setShowExportModal(true),
            className: "bg-background text-text-primary px-4 py-2 rounded-lg hover:bg-surface-hover transition-colors duration-150 ease-smooth flex items-center space-x-2 border border-border",
            children: [
              /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:132:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "132", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Download%22%7D", name: "Download", size: 16 }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                lineNumber: 132,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:133:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "133", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Export%20Configuration%22%7D", children: "Export Configuration" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                lineNumber: 133,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
            lineNumber: 128,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:135:10",
            "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx",
            "data-component-line": "135",
            "data-component-file": "SystemConfiguration.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%7D",
            onClick: handleSaveChanges,
            disabled: !hasChanges,
            className: `px-4 py-2 rounded-lg transition-colors duration-150 ease-smooth flex items-center space-x-2 ${hasChanges ? "bg-primary text-white hover:bg-primary-600" : "bg-gray-100 text-gray-400 cursor-not-allowed"}`,
            children: [
              /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:143:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "143", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Save%22%7D", name: "Save", size: 16 }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                lineNumber: 143,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:144:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "144", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Save%20Changes%22%7D", children: "Save Changes" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                lineNumber: 144,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
            lineNumber: 135,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
        lineNumber: 127,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
      lineNumber: 122,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:149:6", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "149", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20lg%3Agrid-cols-2%20gap-6%22%7D", className: "grid grid-cols-1 lg:grid-cols-2 gap-6", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:151:8", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "151", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20rounded-lg%20border%20border-border%20p-6%22%7D", className: "bg-surface rounded-lg border border-border p-6", children: [
        /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:152:10", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "152", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%20mb-4%20flex%20items-center%20space-x-2%22%7D", className: "text-lg font-semibold text-text-primary mb-4 flex items-center space-x-2", children: [
          /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:153:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "153", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Settings%22%2C%22className%22%3A%22text-primary%22%7D", name: "Settings", size: 20, className: "text-primary" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
            lineNumber: 153,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:154:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "154", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22General%20Settings%22%7D", children: "General Settings" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
            lineNumber: 154,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
          lineNumber: 152,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:157:10", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "157", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-4%22%7D", className: "space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:158:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "158", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:159:14", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "159", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Company%20Name%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Company Name" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
              lineNumber: 159,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:160:14",
                "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx",
                "data-component-line": "160",
                "data-component-file": "SystemConfiguration.jsx",
                "data-component-name": "input",
                "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22text%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
                type: "text",
                value: config?.general?.companyName,
                onChange: (e) => updateConfig("general", "companyName", e?.target?.value),
                className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary"
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                lineNumber: 160,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
            lineNumber: 158,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:168:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "168", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:169:14", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "169", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Timezone%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Timezone" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
              lineNumber: 169,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:170:14",
                "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx",
                "data-component-line": "170",
                "data-component-file": "SystemConfiguration.jsx",
                "data-component-name": "select",
                "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
                value: config?.general?.timezone,
                onChange: (e) => updateConfig("general", "timezone", e?.target?.value),
                className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
                children: timezones?.map(
                  (tz) => /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:176:16", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "176", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22%5Bvar%3Atz%5D%22%7D", value: tz, children: tz }, tz, false, {
                    fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                    lineNumber: 176,
                    columnNumber: 17
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                lineNumber: 170,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
            lineNumber: 168,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:181:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "181", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:182:14", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "182", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Date%20Format%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Date Format" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
              lineNumber: 182,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:183:14",
                "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx",
                "data-component-line": "183",
                "data-component-file": "SystemConfiguration.jsx",
                "data-component-name": "select",
                "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
                value: config?.general?.dateFormat,
                onChange: (e) => updateConfig("general", "dateFormat", e?.target?.value),
                className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
                children: dateFormats?.map(
                  (format) => /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:189:16", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "189", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22%5Bvar%3Aformat%5D%22%7D", value: format, children: format }, format, false, {
                    fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                    lineNumber: 189,
                    columnNumber: 17
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                lineNumber: 183,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
            lineNumber: 181,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:194:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "194", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:195:14", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "195", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Currency%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Currency" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
              lineNumber: 195,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:196:14",
                "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx",
                "data-component-line": "196",
                "data-component-file": "SystemConfiguration.jsx",
                "data-component-name": "select",
                "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
                value: config?.general?.currency,
                onChange: (e) => updateConfig("general", "currency", e?.target?.value),
                className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
                children: currencies?.map(
                  (currency) => /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:202:16", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "202", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22textContent%22%3A%22-%22%7D", value: currency?.code, children: [
                    currency?.code,
                    " - ",
                    currency?.name
                  ] }, currency?.code, true, {
                    fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                    lineNumber: 202,
                    columnNumber: 17
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                lineNumber: 196,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
            lineNumber: 194,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:209:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "209", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:210:14", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "210", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Language%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Language" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
              lineNumber: 210,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:211:14",
                "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx",
                "data-component-line": "211",
                "data-component-file": "SystemConfiguration.jsx",
                "data-component-name": "select",
                "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
                value: config?.general?.language,
                onChange: (e) => updateConfig("general", "language", e?.target?.value),
                className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
                children: languages?.map(
                  (lang) => /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:217:16", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "217", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%7D", value: lang?.code, children: lang?.name }, lang?.code, false, {
                    fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                    lineNumber: 217,
                    columnNumber: 17
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                lineNumber: 211,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
            lineNumber: 209,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
          lineNumber: 157,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
        lineNumber: 151,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:225:8", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "225", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20rounded-lg%20border%20border-border%20p-6%22%7D", className: "bg-surface rounded-lg border border-border p-6", children: [
        /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:226:10", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "226", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%20mb-4%20flex%20items-center%20space-x-2%22%7D", className: "text-lg font-semibold text-text-primary mb-4 flex items-center space-x-2", children: [
          /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:227:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "227", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Target%22%2C%22className%22%3A%22text-primary%22%7D", name: "Target", size: 20, className: "text-primary" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
            lineNumber: 227,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:228:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "228", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Sales%20Settings%22%7D", children: "Sales Settings" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
            lineNumber: 228,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
          lineNumber: 226,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:231:10", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "231", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-4%22%7D", className: "space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:232:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "232", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:233:14", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "233", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Default%20Pipeline%20Stage%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Default Pipeline Stage" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
              lineNumber: 233,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:234:14",
                "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx",
                "data-component-line": "234",
                "data-component-file": "SystemConfiguration.jsx",
                "data-component-name": "select",
                "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
                value: config?.sales?.defaultPipelineStage,
                onChange: (e) => updateConfig("sales", "defaultPipelineStage", e?.target?.value),
                className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
                children: [
                  /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:239:16", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "239", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22Prospecting%22%2C%22textContent%22%3A%22Prospecting%22%7D", value: "Prospecting", children: "Prospecting" }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                    lineNumber: 239,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:240:16", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "240", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22Qualification%22%2C%22textContent%22%3A%22Qualification%22%7D", value: "Qualification", children: "Qualification" }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                    lineNumber: 240,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:241:16", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "241", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22Proposal%22%2C%22textContent%22%3A%22Proposal%22%7D", value: "Proposal", children: "Proposal" }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                    lineNumber: 241,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:242:16", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "242", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22Negotiation%22%2C%22textContent%22%3A%22Negotiation%22%7D", value: "Negotiation", children: "Negotiation" }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                    lineNumber: 242,
                    columnNumber: 17
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                lineNumber: 234,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
            lineNumber: 232,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:246:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "246", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:247:14", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "247", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Deal%20Inactivity%20Warning%20(Days)%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Deal Inactivity Warning (Days)" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
              lineNumber: 247,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:248:14",
                "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx",
                "data-component-line": "248",
                "data-component-file": "SystemConfiguration.jsx",
                "data-component-name": "input",
                "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22number%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
                type: "number",
                value: config?.sales?.dealInactivityDays,
                onChange: (e) => updateConfig("sales", "dealInactivityDays", parseInt(e?.target?.value)),
                className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
                min: "1",
                max: "365"
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                lineNumber: 248,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
            lineNumber: 246,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:258:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "258", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-2%22%7D", className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:259:14", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "259", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%22%7D", className: "flex items-center space-x-2", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:260:16",
                  "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx",
                  "data-component-line": "260",
                  "data-component-file": "SystemConfiguration.jsx",
                  "data-component-name": "input",
                  "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22checkbox%22%2C%22className%22%3A%22rounded%20border-border%20text-primary%20focus%3Aring-primary%22%7D",
                  type: "checkbox",
                  checked: config?.sales?.requireDealValue,
                  onChange: (e) => updateConfig("sales", "requireDealValue", e?.target?.checked),
                  className: "rounded border-border text-primary focus:ring-primary"
                },
                void 0,
                false,
                {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                  lineNumber: 260,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:266:16", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "266", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-primary%22%2C%22textContent%22%3A%22Require%20deal%20value%22%7D", className: "text-sm text-text-primary", children: "Require deal value" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                lineNumber: 266,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
              lineNumber: 259,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:269:14", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "269", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%22%7D", className: "flex items-center space-x-2", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:270:16",
                  "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx",
                  "data-component-line": "270",
                  "data-component-file": "SystemConfiguration.jsx",
                  "data-component-name": "input",
                  "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22checkbox%22%2C%22className%22%3A%22rounded%20border-border%20text-primary%20focus%3Aring-primary%22%7D",
                  type: "checkbox",
                  checked: config?.sales?.autoProgressDeals,
                  onChange: (e) => updateConfig("sales", "autoProgressDeals", e?.target?.checked),
                  className: "rounded border-border text-primary focus:ring-primary"
                },
                void 0,
                false,
                {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                  lineNumber: 270,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:276:16", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "276", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-primary%22%2C%22textContent%22%3A%22Auto-progress%20deals%20based%20on%20activities%22%7D", className: "text-sm text-text-primary", children: "Auto-progress deals based on activities" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                lineNumber: 276,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
              lineNumber: 269,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
            lineNumber: 258,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
          lineNumber: 231,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
        lineNumber: 225,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:283:8", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "283", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20rounded-lg%20border%20border-border%20p-6%22%7D", className: "bg-surface rounded-lg border border-border p-6", children: [
        /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:284:10", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "284", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%20mb-4%20flex%20items-center%20space-x-2%22%7D", className: "text-lg font-semibold text-text-primary mb-4 flex items-center space-x-2", children: [
          /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:285:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "285", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Bell%22%2C%22className%22%3A%22text-primary%22%7D", name: "Bell", size: 20, className: "text-primary" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
            lineNumber: 285,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:286:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "286", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Notifications%22%7D", children: "Notifications" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
            lineNumber: 286,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
          lineNumber: 284,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:289:10", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "289", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-3%22%7D", className: "space-y-3", children: [
          /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:290:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "290", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%22%7D", className: "flex items-center space-x-2", children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:291:14",
                "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx",
                "data-component-line": "291",
                "data-component-file": "SystemConfiguration.jsx",
                "data-component-name": "input",
                "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22checkbox%22%2C%22className%22%3A%22rounded%20border-border%20text-primary%20focus%3Aring-primary%22%7D",
                type: "checkbox",
                checked: config?.notifications?.emailNotifications,
                onChange: (e) => updateConfig("notifications", "emailNotifications", e?.target?.checked),
                className: "rounded border-border text-primary focus:ring-primary"
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                lineNumber: 291,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:297:14", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "297", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-primary%22%2C%22textContent%22%3A%22Email%20notifications%22%7D", className: "text-sm text-text-primary", children: "Email notifications" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
              lineNumber: 297,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
            lineNumber: 290,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:300:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "300", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%22%7D", className: "flex items-center space-x-2", children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:301:14",
                "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx",
                "data-component-line": "301",
                "data-component-file": "SystemConfiguration.jsx",
                "data-component-name": "input",
                "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22checkbox%22%2C%22className%22%3A%22rounded%20border-border%20text-primary%20focus%3Aring-primary%22%7D",
                type: "checkbox",
                checked: config?.notifications?.dealUpdateNotifications,
                onChange: (e) => updateConfig("notifications", "dealUpdateNotifications", e?.target?.checked),
                className: "rounded border-border text-primary focus:ring-primary"
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                lineNumber: 301,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:307:14", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "307", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-primary%22%2C%22textContent%22%3A%22Deal%20update%20notifications%22%7D", className: "text-sm text-text-primary", children: "Deal update notifications" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
              lineNumber: 307,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
            lineNumber: 300,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:310:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "310", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%22%7D", className: "flex items-center space-x-2", children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:311:14",
                "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx",
                "data-component-line": "311",
                "data-component-file": "SystemConfiguration.jsx",
                "data-component-name": "input",
                "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22checkbox%22%2C%22className%22%3A%22rounded%20border-border%20text-primary%20focus%3Aring-primary%22%7D",
                type: "checkbox",
                checked: config?.notifications?.taskReminders,
                onChange: (e) => updateConfig("notifications", "taskReminders", e?.target?.checked),
                className: "rounded border-border text-primary focus:ring-primary"
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                lineNumber: 311,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:317:14", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "317", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-primary%22%2C%22textContent%22%3A%22Task%20reminders%22%7D", className: "text-sm text-text-primary", children: "Task reminders" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
              lineNumber: 317,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
            lineNumber: 310,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:320:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "320", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%22%7D", className: "flex items-center space-x-2", children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:321:14",
                "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx",
                "data-component-line": "321",
                "data-component-file": "SystemConfiguration.jsx",
                "data-component-name": "input",
                "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22checkbox%22%2C%22className%22%3A%22rounded%20border-border%20text-primary%20focus%3Aring-primary%22%7D",
                type: "checkbox",
                checked: config?.notifications?.weeklyReports,
                onChange: (e) => updateConfig("notifications", "weeklyReports", e?.target?.checked),
                className: "rounded border-border text-primary focus:ring-primary"
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                lineNumber: 321,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:327:14", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "327", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-primary%22%2C%22textContent%22%3A%22Weekly%20reports%22%7D", className: "text-sm text-text-primary", children: "Weekly reports" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
              lineNumber: 327,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
            lineNumber: 320,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:330:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "330", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%22%7D", className: "flex items-center space-x-2", children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:331:14",
                "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx",
                "data-component-line": "331",
                "data-component-file": "SystemConfiguration.jsx",
                "data-component-name": "input",
                "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22checkbox%22%2C%22className%22%3A%22rounded%20border-border%20text-primary%20focus%3Aring-primary%22%7D",
                type: "checkbox",
                checked: config?.notifications?.systemAlerts,
                onChange: (e) => updateConfig("notifications", "systemAlerts", e?.target?.checked),
                className: "rounded border-border text-primary focus:ring-primary"
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                lineNumber: 331,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:337:14", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "337", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-primary%22%2C%22textContent%22%3A%22System%20alerts%22%7D", className: "text-sm text-text-primary", children: "System alerts" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
              lineNumber: 337,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
            lineNumber: 330,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
          lineNumber: 289,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
        lineNumber: 283,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:343:8", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "343", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20rounded-lg%20border%20border-border%20p-6%22%7D", className: "bg-surface rounded-lg border border-border p-6", children: [
        /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:344:10", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "344", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%20mb-4%20flex%20items-center%20space-x-2%22%7D", className: "text-lg font-semibold text-text-primary mb-4 flex items-center space-x-2", children: [
          /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:345:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "345", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Shield%22%2C%22className%22%3A%22text-primary%22%7D", name: "Shield", size: 20, className: "text-primary" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
            lineNumber: 345,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:346:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "346", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Security%22%7D", children: "Security" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
            lineNumber: 346,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
          lineNumber: 344,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:349:10", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "349", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-4%22%7D", className: "space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:350:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "350", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:351:14", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "351", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Session%20Timeout%20(minutes)%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Session Timeout (minutes)" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
              lineNumber: 351,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:352:14",
                "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx",
                "data-component-line": "352",
                "data-component-file": "SystemConfiguration.jsx",
                "data-component-name": "input",
                "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22number%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
                type: "number",
                value: config?.security?.sessionTimeout,
                onChange: (e) => updateConfig("security", "sessionTimeout", parseInt(e?.target?.value)),
                className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
                min: "30",
                max: "1440"
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                lineNumber: 352,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
            lineNumber: 350,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:362:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "362", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:363:14", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "363", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Max%20Login%20Attempts%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Max Login Attempts" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
              lineNumber: 363,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:364:14",
                "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx",
                "data-component-line": "364",
                "data-component-file": "SystemConfiguration.jsx",
                "data-component-name": "input",
                "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22number%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
                type: "number",
                value: config?.security?.loginAttempts,
                onChange: (e) => updateConfig("security", "loginAttempts", parseInt(e?.target?.value)),
                className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
                min: "3",
                max: "10"
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                lineNumber: 364,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
            lineNumber: 362,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:374:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "374", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-2%22%7D", className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:375:14", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "375", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%22%7D", className: "flex items-center space-x-2", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:376:16",
                  "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx",
                  "data-component-line": "376",
                  "data-component-file": "SystemConfiguration.jsx",
                  "data-component-name": "input",
                  "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22checkbox%22%2C%22className%22%3A%22rounded%20border-border%20text-primary%20focus%3Aring-primary%22%7D",
                  type: "checkbox",
                  checked: config?.security?.passwordComplexity,
                  onChange: (e) => updateConfig("security", "passwordComplexity", e?.target?.checked),
                  className: "rounded border-border text-primary focus:ring-primary"
                },
                void 0,
                false,
                {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                  lineNumber: 376,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:382:16", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "382", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-primary%22%2C%22textContent%22%3A%22Require%20password%20complexity%22%7D", className: "text-sm text-text-primary", children: "Require password complexity" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                lineNumber: 382,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
              lineNumber: 375,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:385:14", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "385", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%22%7D", className: "flex items-center space-x-2", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:386:16",
                  "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx",
                  "data-component-line": "386",
                  "data-component-file": "SystemConfiguration.jsx",
                  "data-component-name": "input",
                  "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22checkbox%22%2C%22className%22%3A%22rounded%20border-border%20text-primary%20focus%3Aring-primary%22%7D",
                  type: "checkbox",
                  checked: config?.security?.twoFactorAuth,
                  onChange: (e) => updateConfig("security", "twoFactorAuth", e?.target?.checked),
                  className: "rounded border-border text-primary focus:ring-primary"
                },
                void 0,
                false,
                {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                  lineNumber: 386,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:392:16", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "392", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-primary%22%2C%22textContent%22%3A%22Enable%20two-factor%20authentication%22%7D", className: "text-sm text-text-primary", children: "Enable two-factor authentication" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                lineNumber: 392,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
              lineNumber: 385,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:395:14", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "395", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%22%7D", className: "flex items-center space-x-2", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:396:16",
                  "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx",
                  "data-component-line": "396",
                  "data-component-file": "SystemConfiguration.jsx",
                  "data-component-name": "input",
                  "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22checkbox%22%2C%22className%22%3A%22rounded%20border-border%20text-primary%20focus%3Aring-primary%22%7D",
                  type: "checkbox",
                  checked: config?.security?.dataEncryption,
                  onChange: (e) => updateConfig("security", "dataEncryption", e?.target?.checked),
                  className: "rounded border-border text-primary focus:ring-primary"
                },
                void 0,
                false,
                {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                  lineNumber: 396,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:402:16", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "402", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-primary%22%2C%22textContent%22%3A%22Data%20encryption%20at%20rest%22%7D", className: "text-sm text-text-primary", children: "Data encryption at rest" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                lineNumber: 402,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
              lineNumber: 395,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
            lineNumber: 374,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
          lineNumber: 349,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
        lineNumber: 343,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
      lineNumber: 149,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:409:6", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "409", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20rounded-lg%20border%20border-border%20p-6%22%7D", className: "bg-surface rounded-lg border border-border p-6", children: [
      /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:410:8", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "410", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%20mb-4%20flex%20items-center%20space-x-2%22%7D", className: "text-lg font-semibold text-text-primary mb-4 flex items-center space-x-2", children: [
        /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:411:10", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "411", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Database%22%2C%22className%22%3A%22text-primary%22%7D", name: "Database", size: 20, className: "text-primary" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
          lineNumber: 411,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:412:10", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "412", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Backup%20%26%20Recovery%22%7D", children: "Backup & Recovery" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
          lineNumber: 412,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
        lineNumber: 410,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:415:8", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "415", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20md%3Agrid-cols-3%20gap-4%22%7D", className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:416:10", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "416", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:417:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "417", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Backup%20Frequency%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Backup Frequency" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
            lineNumber: 417,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:418:12",
              "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx",
              "data-component-line": "418",
              "data-component-file": "SystemConfiguration.jsx",
              "data-component-name": "select",
              "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
              value: config?.backup?.backupFrequency,
              onChange: (e) => updateConfig("backup", "backupFrequency", e?.target?.value),
              className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
              children: [
                /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:423:14", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "423", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22hourly%22%2C%22textContent%22%3A%22Hourly%22%7D", value: "hourly", children: "Hourly" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                  lineNumber: 423,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:424:14", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "424", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22daily%22%2C%22textContent%22%3A%22Daily%22%7D", value: "daily", children: "Daily" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                  lineNumber: 424,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:425:14", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "425", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22weekly%22%2C%22textContent%22%3A%22Weekly%22%7D", value: "weekly", children: "Weekly" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                  lineNumber: 425,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:426:14", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "426", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22monthly%22%2C%22textContent%22%3A%22Monthly%22%7D", value: "monthly", children: "Monthly" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                  lineNumber: 426,
                  columnNumber: 15
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
              lineNumber: 418,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
          lineNumber: 416,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:430:10", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "430", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:431:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "431", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Retention%20Period%20(Days)%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Retention Period (Days)" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
            lineNumber: 431,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:432:12",
              "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx",
              "data-component-line": "432",
              "data-component-file": "SystemConfiguration.jsx",
              "data-component-name": "input",
              "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22number%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
              type: "number",
              value: config?.backup?.retentionDays,
              onChange: (e) => updateConfig("backup", "retentionDays", parseInt(e?.target?.value)),
              className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
              min: "7",
              max: "365"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
              lineNumber: 432,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
          lineNumber: 430,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:442:10", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "442", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-end%22%7D", className: "flex items-end", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:443:12",
            "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx",
            "data-component-line": "443",
            "data-component-file": "SystemConfiguration.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22w-full%20bg-background%20text-text-primary%20px-4%20py-2%20rounded-lg%20hover%3Abg-surface-hover%20transition-colors%20duration-150%20ease-smooth%20flex%20items-center%20justify-center%20space-x-2%20border%20border-border%22%7D",
            onClick: handleTestBackup,
            className: "w-full bg-background text-text-primary px-4 py-2 rounded-lg hover:bg-surface-hover transition-colors duration-150 ease-smooth flex items-center justify-center space-x-2 border border-border",
            children: [
              /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:447:14", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "447", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22TestTube%22%7D", name: "TestTube", size: 16 }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                lineNumber: 447,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:448:14", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "448", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Test%20Backup%22%7D", children: "Test Backup" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                lineNumber: 448,
                columnNumber: 15
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
            lineNumber: 443,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
          lineNumber: 442,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
        lineNumber: 415,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:453:8", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "453", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22mt-4%22%7D", className: "mt-4", children: /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:454:10", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "454", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%22%7D", className: "flex items-center space-x-2", children: [
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:455:12",
            "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx",
            "data-component-line": "455",
            "data-component-file": "SystemConfiguration.jsx",
            "data-component-name": "input",
            "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22checkbox%22%2C%22className%22%3A%22rounded%20border-border%20text-primary%20focus%3Aring-primary%22%7D",
            type: "checkbox",
            checked: config?.backup?.autoBackup,
            onChange: (e) => updateConfig("backup", "autoBackup", e?.target?.checked),
            className: "rounded border-border text-primary focus:ring-primary"
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
            lineNumber: 455,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:461:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "461", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-primary%22%2C%22textContent%22%3A%22Enable%20automatic%20backups%22%7D", className: "text-sm text-text-primary", children: "Enable automatic backups" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
          lineNumber: 461,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
        lineNumber: 454,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
        lineNumber: 453,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
      lineNumber: 409,
      columnNumber: 7
    }, this),
    showExportModal && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:467:6", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "467", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20z-1200%20overflow-y-auto%22%7D", className: "fixed inset-0 z-1200 overflow-y-auto", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:468:10", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "468", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-center%20min-h-screen%20px-4%22%7D", className: "flex items-center justify-center min-h-screen px-4", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:469:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "469", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20bg-black%20bg-opacity-50%22%7D", className: "fixed inset-0 bg-black bg-opacity-50", onClick: () => setShowExportModal(false) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
        lineNumber: 469,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:470:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "470", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20rounded-lg%20shadow-xl%20max-w-md%20w-full%20relative%20z-1300%22%7D", className: "bg-surface rounded-lg shadow-xl max-w-md w-full relative z-1300", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:471:14", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "471", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22p-6%22%7D", className: "p-6", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:472:16", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "472", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%20mb-4%22%7D", className: "flex items-center justify-between mb-4", children: [
          /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:473:18", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "473", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%2C%22textContent%22%3A%22Export%20Configuration%22%7D", className: "text-lg font-semibold text-text-primary", children: "Export Configuration" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
            lineNumber: 473,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:474:18",
              "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx",
              "data-component-line": "474",
              "data-component-file": "SystemConfiguration.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22text-text-secondary%20hover%3Atext-text-primary%20transition-colors%20duration-150%22%7D",
              onClick: () => setShowExportModal(false),
              className: "text-text-secondary hover:text-text-primary transition-colors duration-150",
              children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:478:20", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "478", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22X%22%7D", name: "X", size: 20 }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                lineNumber: 478,
                columnNumber: 21
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
              lineNumber: 474,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
          lineNumber: 472,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:482:16", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "482", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-4%22%7D", className: "space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:483:18", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "483", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:484:20", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "484", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Export%20Format%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Export Format" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
              lineNumber: 484,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:485:20",
                "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx",
                "data-component-line": "485",
                "data-component-file": "SystemConfiguration.jsx",
                "data-component-name": "select",
                "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22value%22%3A%22%5Bvar%3AexportFormat%5D%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
                value: exportFormat,
                onChange: (e) => setExportFormat(e?.target?.value),
                className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
                children: [
                  /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:490:22", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "490", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22json%22%2C%22textContent%22%3A%22JSON%22%7D", value: "json", children: "JSON" }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                    lineNumber: 490,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:491:22", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "491", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22txt%22%2C%22textContent%22%3A%22Text%22%7D", value: "txt", children: "Text" }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                    lineNumber: 491,
                    columnNumber: 23
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
                lineNumber: 485,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
            lineNumber: 483,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:495:18", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "495", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22This%20will%20download%20your%20current%20system%20configuration%20settings.%22%7D", className: "text-sm text-text-secondary", children: "This will download your current system configuration settings." }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
            lineNumber: 495,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
          lineNumber: 482,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:500:16", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "500", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20justify-end%20space-x-3%20mt-6%22%7D", className: "flex justify-end space-x-3 mt-6", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:501:18",
              "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx",
              "data-component-line": "501",
              "data-component-file": "SystemConfiguration.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22px-4%20py-2%20text-text-secondary%20hover%3Atext-text-primary%20transition-colors%20duration-150%22%2C%22textContent%22%3A%22Cancel%22%7D",
              onClick: () => setShowExportModal(false),
              className: "px-4 py-2 text-text-secondary hover:text-text-primary transition-colors duration-150",
              children: "Cancel"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
              lineNumber: 501,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:507:18",
              "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx",
              "data-component-line": "507",
              "data-component-file": "SystemConfiguration.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22bg-primary%20text-white%20px-4%20py-2%20rounded-lg%20hover%3Abg-primary-600%20transition-colors%20duration-150%20ease-smooth%22%2C%22textContent%22%3A%22Export%22%7D",
              onClick: handleExportConfig,
              className: "bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary-600 transition-colors duration-150 ease-smooth",
              children: "Export"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
              lineNumber: 507,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
          lineNumber: 500,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
        lineNumber: 471,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
        lineNumber: 470,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
      lineNumber: 468,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
      lineNumber: 467,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:520:6", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "520", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-background%20border%20border-border%20rounded-lg%20p-4%22%7D", className: "bg-background border border-border rounded-lg p-4", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:521:8", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "521", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-start%20space-x-3%22%7D", className: "flex items-start space-x-3", children: [
      /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:522:10", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "522", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22AlertCircle%22%2C%22className%22%3A%22text-primary%20mt-0.5%22%7D", name: "AlertCircle", size: 16, className: "text-primary mt-0.5" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
        lineNumber: 522,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:523:10", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "523", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex-1%22%7D", className: "flex-1", children: [
        /* @__PURE__ */ jsxDEV("h4", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:524:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "524", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "h4", "data-component-content": "%7B%22elementName%22%3A%22h4%22%2C%22className%22%3A%22font-medium%20text-text-primary%20text-sm%22%2C%22textContent%22%3A%22Configuration%20Changes%22%7D", className: "font-medium text-text-primary text-sm", children: "Configuration Changes" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
          lineNumber: 524,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx:525:12", "data-component-path": "src\\pages\\settings-administration\\components\\SystemConfiguration.jsx", "data-component-line": "525", "data-component-file": "SystemConfiguration.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20text-sm%20mt-1%22%7D", className: "text-text-secondary text-sm mt-1", children: hasChanges ? 'You have unsaved changes. Click "Save Changes" to apply your modifications.' : "All settings are saved and up to date. Changes will take effect immediately after saving." }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
          lineNumber: 525,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
        lineNumber: 523,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
      lineNumber: 521,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
      lineNumber: 520,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx",
    lineNumber: 120,
    columnNumber: 5
  }, this);
};
_s(SystemConfiguration, "VtsqtCvmUKVPhO/rJO/gHgQnnN4=");
_c = SystemConfiguration;
export default SystemConfiguration;
var _c;
$RefreshReg$(_c, "SystemConfiguration");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/settings-administration/components/SystemConfiguration.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkhVOzJCQTNIVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBLE9BQU9BLFNBQVNDLGdCQUFnQjtBQUNoQyxPQUFPQyxVQUFVO0FBRWpCLE1BQU1DLHNCQUFzQkEsTUFBTTtBQUFBQyxLQUFBO0FBQ2hDLFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJTCxTQUFTO0FBQUEsSUFDbkNNLFNBQVM7QUFBQSxNQUNQQyxhQUFhO0FBQUEsTUFDYkMsVUFBVTtBQUFBLE1BQ1ZDLFlBQVk7QUFBQSxNQUNaQyxVQUFVO0FBQUEsTUFDVkMsVUFBVTtBQUFBLElBQ1o7QUFBQSxJQUNBQyxPQUFPO0FBQUEsTUFDTEMsc0JBQXNCO0FBQUEsTUFDdEJDLGNBQWM7QUFBQSxNQUNkQyxrQkFBa0I7QUFBQSxNQUNsQkMsbUJBQW1CO0FBQUEsTUFDbkJDLG9CQUFvQjtBQUFBLElBQ3RCO0FBQUEsSUFDQUMsZUFBZTtBQUFBLE1BQ2JDLG9CQUFvQjtBQUFBLE1BQ3BCQyx5QkFBeUI7QUFBQSxNQUN6QkMsZUFBZTtBQUFBLE1BQ2ZDLGVBQWU7QUFBQSxNQUNmQyxjQUFjO0FBQUEsSUFDaEI7QUFBQSxJQUNBQyxVQUFVO0FBQUEsTUFDUkMsb0JBQW9CO0FBQUEsTUFDcEJDLGVBQWU7QUFBQSxNQUNmQyxnQkFBZ0I7QUFBQSxNQUNoQkMsZUFBZTtBQUFBLE1BQ2ZDLGdCQUFnQjtBQUFBLElBQ2xCO0FBQUEsSUFDQUMsUUFBUTtBQUFBLE1BQ05DLFlBQVk7QUFBQSxNQUNaQyxpQkFBaUI7QUFBQSxNQUNqQkMsZUFBZTtBQUFBLE1BQ2ZDLGdCQUFnQjtBQUFBLElBQ2xCO0FBQUEsRUFDRixDQUFDO0FBRUQsUUFBTSxDQUFDQyxZQUFZQyxhQUFhLElBQUlwQyxTQUFTLEtBQUs7QUFDbEQsUUFBTSxDQUFDcUMsY0FBY0MsZUFBZSxJQUFJdEMsU0FBUyxNQUFNO0FBQ3ZELFFBQU0sQ0FBQ3VDLGlCQUFpQkMsa0JBQWtCLElBQUl4QyxTQUFTLEtBQUs7QUFFNUQsUUFBTXlDLFlBQVk7QUFBQSxJQUNoQjtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFBa0I7QUFHcEIsUUFBTUMsYUFBYTtBQUFBLElBQ2pCLEVBQUVDLE1BQU0sT0FBT0MsTUFBTSxZQUFZO0FBQUEsSUFDakMsRUFBRUQsTUFBTSxPQUFPQyxNQUFNLE9BQU87QUFBQSxJQUM1QixFQUFFRCxNQUFNLE9BQU9DLE1BQU0sZ0JBQWdCO0FBQUEsSUFDckMsRUFBRUQsTUFBTSxPQUFPQyxNQUFNLGtCQUFrQjtBQUFBLElBQ3ZDLEVBQUVELE1BQU0sT0FBT0MsTUFBTSxvQkFBb0I7QUFBQSxJQUN6QyxFQUFFRCxNQUFNLE9BQU9DLE1BQU0sZUFBZTtBQUFBLEVBQUM7QUFHdkMsUUFBTUMsY0FBYztBQUFBLElBQ2xCO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFBWTtBQUdkLFFBQU1DLFlBQVk7QUFBQSxJQUNoQixFQUFFSCxNQUFNLE1BQU1DLE1BQU0sVUFBVTtBQUFBLElBQzlCLEVBQUVELE1BQU0sTUFBTUMsTUFBTSxVQUFVO0FBQUEsSUFDOUIsRUFBRUQsTUFBTSxNQUFNQyxNQUFNLFNBQVM7QUFBQSxJQUM3QixFQUFFRCxNQUFNLE1BQU1DLE1BQU0sU0FBUztBQUFBLElBQzdCLEVBQUVELE1BQU0sTUFBTUMsTUFBTSxVQUFVO0FBQUEsRUFBQztBQUdqQyxRQUFNRyxlQUFlQSxDQUFDQyxTQUFTQyxPQUFPQyxVQUFVO0FBQzlDN0MsY0FBVSxDQUFBOEMsVUFBUztBQUFBLE1BQ2pCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ0gsT0FBTyxHQUFHO0FBQUEsUUFDVCxHQUFHRyxPQUFPSCxPQUFPO0FBQUEsUUFDakIsQ0FBQ0MsS0FBSyxHQUFHQztBQUFBQSxNQUNYO0FBQUEsSUFDRixFQUFFO0FBQ0ZkLGtCQUFjLElBQUk7QUFBQSxFQUNwQjtBQUVBLFFBQU1nQixvQkFBb0JBLE1BQU07QUFDOUJDLFlBQVFDLElBQUkseUJBQXlCbEQsTUFBTTtBQUMzQ2dDLGtCQUFjLEtBQUs7QUFBQSxFQUVyQjtBQUVBLFFBQU1tQixxQkFBcUJBLE1BQU07QUFDL0IsVUFBTUMsYUFBYW5CLGlCQUFpQixTQUFTb0IsS0FBS0MsVUFBVXRELFFBQVEsTUFBTSxDQUFDLElBQUlBO0FBQy9FLFVBQU11RCxPQUFPLElBQUlDLEtBQUssQ0FBQ0osVUFBVSxHQUFHLEVBQUVLLE1BQU14QixpQkFBaUIsU0FBUyxxQkFBcUIsYUFBYSxDQUFDO0FBQ3pHLFVBQU15QixNQUFNQyxJQUFJQyxnQkFBZ0JMLElBQUk7QUFDcEMsVUFBTU0sSUFBSUMsU0FBU0MsY0FBYyxHQUFHO0FBQ3BDRixNQUFFRyxPQUFPTjtBQUNURyxNQUFFSSxXQUFXLGlCQUFpQmhDLFlBQVk7QUFDMUM2QixhQUFTSSxNQUFNQyxZQUFZTixDQUFDO0FBQzVCQSxPQUFHTyxNQUFNO0FBQ1ROLGFBQVNJLE1BQU1HLFlBQVlSLENBQUM7QUFDNUJGLFFBQUlXLGdCQUFnQlosR0FBRztBQUN2QnRCLHVCQUFtQixLQUFLO0FBQUEsRUFDMUI7QUFFQSxRQUFNbUMsbUJBQW1CQSxNQUFNO0FBQzdCdEIsWUFBUUMsSUFBSSwwQkFBMEI7QUFBQSxFQUV4QztBQUVBLFNBQ0UsdUJBQUMsc2FBQUksV0FBVSxhQUViO0FBQUEsMkJBQUMsa2NBQUksV0FBVSxxQ0FDYjtBQUFBLDZCQUFDLGtZQUNDO0FBQUEsK0JBQUMsc2ZBQUcsV0FBVSx3Q0FBdUMsb0NBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUU7QUFBQSxRQUN6RSx1QkFBQyx1Z0JBQUUsV0FBVSw0QkFBMkIsOERBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0Y7QUFBQSxXQUZ4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLDZhQUFJLFdBQVUsa0JBQ2I7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNZCxtQkFBbUIsSUFBSTtBQUFBLFlBQ3RDLFdBQVU7QUFBQSxZQUVWO0FBQUEscUNBQUMsa2FBQUssTUFBSyxZQUFXLE1BQU0sTUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0I7QUFBQSxjQUMvQix1QkFBQyx5YkFBSyxvQ0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwQjtBQUFBO0FBQUE7QUFBQSxVQUw1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUNDLFNBQVNZO0FBQUFBLFlBQ1QsVUFBVSxDQUFDakI7QUFBQUEsWUFDWCxXQUFXLCtGQUNUQSxhQUNJLCtDQUE4Qyw4Q0FBOEM7QUFBQSxZQUdsRztBQUFBLHFDQUFDLDhaQUFLLE1BQUssUUFBTyxNQUFNLE1BQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJCO0FBQUEsY0FDM0IsdUJBQUMsaWJBQUssNEJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0I7QUFBQTtBQUFBO0FBQUEsVUFUcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBVUE7QUFBQSxXQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBbUJBO0FBQUEsU0F4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlCQTtBQUFBLElBRUEsdUJBQUMsMGNBQUksV0FBVSx5Q0FFYjtBQUFBLDZCQUFDLG1kQUFJLFdBQVUsa0RBQ2I7QUFBQSwrQkFBQywrZUFBRyxXQUFVLDRFQUNaO0FBQUEsaUNBQUMseWNBQUssTUFBSyxZQUFXLE1BQU0sSUFBSSxXQUFVLGtCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RDtBQUFBLFVBQ3hELHVCQUFDLHFiQUFLLGdDQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNCO0FBQUEsYUFGeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFFQSx1QkFBQyx1YUFBSSxXQUFVLGFBQ2I7QUFBQSxpQ0FBQyxtWUFDQztBQUFBLG1DQUFDLHVnQkFBTSxXQUFVLG9EQUFtRCw0QkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0Y7QUFBQSxZQUNoRjtBQUFBLGNBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxPQUFPL0IsUUFBUUUsU0FBU0M7QUFBQUEsZ0JBQ3hCLFVBQVUsQ0FBQ3FFLE1BQU03QixhQUFhLFdBQVcsZUFBZTZCLEdBQUdDLFFBQVEzQixLQUFLO0FBQUEsZ0JBQ3hFLFdBQVU7QUFBQTtBQUFBLGNBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSXNHO0FBQUEsZUFOeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFVBRUEsdUJBQUMsbVlBQ0M7QUFBQSxtQ0FBQyxpZ0JBQU0sV0FBVSxvREFBbUQsd0JBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRFO0FBQUEsWUFDNUU7QUFBQSxjQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFDQyxPQUFPOUMsUUFBUUUsU0FBU0U7QUFBQUEsZ0JBQ3hCLFVBQVUsQ0FBQ29FLE1BQU03QixhQUFhLFdBQVcsWUFBWTZCLEdBQUdDLFFBQVEzQixLQUFLO0FBQUEsZ0JBQ3JFLFdBQVU7QUFBQSxnQkFFVFQscUJBQVdxQztBQUFBQSxrQkFBSSxDQUFBQyxPQUNkLHVCQUFDLGliQUFnQixPQUFPQSxJQUFLQSxnQkFBaEJBLElBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQSxnQkFDakM7QUFBQTtBQUFBLGNBUEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUUE7QUFBQSxlQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQSxVQUVBLHVCQUFDLG1ZQUNDO0FBQUEsbUNBQUMsc2dCQUFNLFdBQVUsb0RBQW1ELDJCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErRTtBQUFBLFlBQy9FO0FBQUEsY0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ0MsT0FBTzNFLFFBQVFFLFNBQVNHO0FBQUFBLGdCQUN4QixVQUFVLENBQUNtRSxNQUFNN0IsYUFBYSxXQUFXLGNBQWM2QixHQUFHQyxRQUFRM0IsS0FBSztBQUFBLGdCQUN2RSxXQUFVO0FBQUEsZ0JBRVRMLHVCQUFhaUM7QUFBQUEsa0JBQUksQ0FBQUUsV0FDaEIsdUJBQUMscWJBQW9CLE9BQU9BLFFBQVNBLG9CQUF4QkEsUUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE0QztBQUFBLGdCQUM3QztBQUFBO0FBQUEsY0FQSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFRQTtBQUFBLGVBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLFVBRUEsdUJBQUMsbVlBQ0M7QUFBQSxtQ0FBQyxpZ0JBQU0sV0FBVSxvREFBbUQsd0JBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRFO0FBQUEsWUFDNUU7QUFBQSxjQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFDQyxPQUFPNUUsUUFBUUUsU0FBU0k7QUFBQUEsZ0JBQ3hCLFVBQVUsQ0FBQ2tFLE1BQU03QixhQUFhLFdBQVcsWUFBWTZCLEdBQUdDLFFBQVEzQixLQUFLO0FBQUEsZ0JBQ3JFLFdBQVU7QUFBQSxnQkFFVFIsc0JBQVlvQztBQUFBQSxrQkFBSSxDQUFBcEUsYUFDZix1QkFBQywwYUFBNEIsT0FBT0EsVUFBVWlDLE1BQzNDakM7QUFBQUEsOEJBQVVpQztBQUFBQSxvQkFBSztBQUFBLG9CQUFJakMsVUFBVWtDO0FBQUFBLHVCQURuQmxDLFVBQVVpQyxNQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsZ0JBQ0Q7QUFBQTtBQUFBLGNBVEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBVUE7QUFBQSxlQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUE7QUFBQSxVQUVBLHVCQUFDLG1ZQUNDO0FBQUEsbUNBQUMsaWdCQUFNLFdBQVUsb0RBQW1ELHdCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0RTtBQUFBLFlBQzVFO0FBQUEsY0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ0MsT0FBT3ZDLFFBQVFFLFNBQVNLO0FBQUFBLGdCQUN4QixVQUFVLENBQUNpRSxNQUFNN0IsYUFBYSxXQUFXLFlBQVk2QixHQUFHQyxRQUFRM0IsS0FBSztBQUFBLGdCQUNyRSxXQUFVO0FBQUEsZ0JBRVRKLHFCQUFXZ0M7QUFBQUEsa0JBQUksQ0FBQUcsU0FDZCx1QkFBQyw0WUFBd0IsT0FBT0EsTUFBTXRDLE1BQU9zQyxnQkFBTXJDLFFBQXRDcUMsTUFBTXRDLE1BQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXdEO0FBQUEsZ0JBQ3pEO0FBQUE7QUFBQSxjQVBIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVFBO0FBQUEsZUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVdBO0FBQUEsYUEvREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdFQTtBQUFBLFdBdEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF1RUE7QUFBQSxNQUdBLHVCQUFDLG1kQUFJLFdBQVUsa0RBQ2I7QUFBQSwrQkFBQywrZUFBRyxXQUFVLDRFQUNaO0FBQUEsaUNBQUMsdWNBQUssTUFBSyxVQUFTLE1BQU0sSUFBSSxXQUFVLGtCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRDtBQUFBLFVBQ3RELHVCQUFDLG1iQUFLLDhCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9CO0FBQUEsYUFGdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFFQSx1QkFBQyx1YUFBSSxXQUFVLGFBQ2I7QUFBQSxpQ0FBQyxtWUFDQztBQUFBLG1DQUFDLG1oQkFBTSxXQUFVLG9EQUFtRCxzQ0FBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEY7QUFBQSxZQUMxRjtBQUFBLGNBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUNDLE9BQU92QyxRQUFRUSxPQUFPQztBQUFBQSxnQkFDdEIsVUFBVSxDQUFDK0QsTUFBTTdCLGFBQWEsU0FBUyx3QkFBd0I2QixHQUFHQyxRQUFRM0IsS0FBSztBQUFBLGdCQUMvRSxXQUFVO0FBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxzZEFBTyxPQUFNLGVBQWMsMkJBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVDO0FBQUEsa0JBQ3ZDLHVCQUFDLDBkQUFPLE9BQU0saUJBQWdCLDZCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyQztBQUFBLGtCQUMzQyx1QkFBQyxnZEFBTyxPQUFNLFlBQVcsd0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWlDO0FBQUEsa0JBQ2pDLHVCQUFDLHNkQUFPLE9BQU0sZUFBYywyQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBdUM7QUFBQTtBQUFBO0FBQUEsY0FSekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBU0E7QUFBQSxlQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxVQUVBLHVCQUFDLG1ZQUNDO0FBQUEsbUNBQUMsNmhCQUFNLFdBQVUsb0RBQW1ELDhDQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRztBQUFBLFlBQ2xHO0FBQUEsY0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE9BQU85QyxRQUFRUSxPQUFPSztBQUFBQSxnQkFDdEIsVUFBVSxDQUFDMkQsTUFBTTdCLGFBQWEsU0FBUyxzQkFBc0JtQyxTQUFTTixHQUFHQyxRQUFRM0IsS0FBSyxDQUFDO0FBQUEsZ0JBQ3ZGLFdBQVU7QUFBQSxnQkFDVixLQUFJO0FBQUEsZ0JBQ0osS0FBSTtBQUFBO0FBQUEsY0FOTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNVztBQUFBLGVBUmI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBRUEsdUJBQUMsdWFBQUksV0FBVSxhQUNiO0FBQUEsbUNBQUMsbWNBQU0sV0FBVSwrQkFDZjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxTQUFTOUMsUUFBUVEsT0FBT0c7QUFBQUEsa0JBQ3hCLFVBQVUsQ0FBQzZELE1BQU03QixhQUFhLFNBQVMsb0JBQW9CNkIsR0FBR0MsUUFBUU0sT0FBTztBQUFBLGtCQUM3RSxXQUFVO0FBQUE7QUFBQSxnQkFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJbUU7QUFBQSxjQUVuRSx1QkFBQywrZUFBSyxXQUFVLDZCQUE0QixrQ0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEQ7QUFBQSxpQkFQaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLFlBRUEsdUJBQUMsbWNBQU0sV0FBVSwrQkFDZjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxTQUFTL0UsUUFBUVEsT0FBT0k7QUFBQUEsa0JBQ3hCLFVBQVUsQ0FBQzRELE1BQU03QixhQUFhLFNBQVMscUJBQXFCNkIsR0FBR0MsUUFBUU0sT0FBTztBQUFBLGtCQUM5RSxXQUFVO0FBQUE7QUFBQSxnQkFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJbUU7QUFBQSxjQUVuRSx1QkFBQyx3Z0JBQUssV0FBVSw2QkFBNEIsdURBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1GO0FBQUEsaUJBUHJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxlQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9CQTtBQUFBLGFBL0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnREE7QUFBQSxXQXRERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdURBO0FBQUEsTUFHQSx1QkFBQyxtZEFBSSxXQUFVLGtEQUNiO0FBQUEsK0JBQUMsK2VBQUcsV0FBVSw0RUFDWjtBQUFBLGlDQUFDLHFjQUFLLE1BQUssUUFBTyxNQUFNLElBQUksV0FBVSxrQkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Q7QUFBQSxVQUNwRCx1QkFBQyxnYkFBSyw2QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtQjtBQUFBLGFBRnJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBRUEsdUJBQUMsdWFBQUksV0FBVSxhQUNiO0FBQUEsaUNBQUMsbWNBQU0sV0FBVSwrQkFDZjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVMvRSxRQUFRYyxlQUFlQztBQUFBQSxnQkFDaEMsVUFBVSxDQUFDeUQsTUFBTTdCLGFBQWEsaUJBQWlCLHNCQUFzQjZCLEdBQUdDLFFBQVFNLE9BQU87QUFBQSxnQkFDdkYsV0FBVTtBQUFBO0FBQUEsY0FKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJbUU7QUFBQSxZQUVuRSx1QkFBQyw4ZUFBSyxXQUFVLDZCQUE0QixtQ0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0Q7QUFBQSxlQVBqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsVUFFQSx1QkFBQyxtY0FBTSxXQUFVLCtCQUNmO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUy9FLFFBQVFjLGVBQWVFO0FBQUFBLGdCQUNoQyxVQUFVLENBQUN3RCxNQUFNN0IsYUFBYSxpQkFBaUIsMkJBQTJCNkIsR0FBR0MsUUFBUU0sT0FBTztBQUFBLGdCQUM1RixXQUFVO0FBQUE7QUFBQSxjQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUltRTtBQUFBLFlBRW5FLHVCQUFDLHNmQUFLLFdBQVUsNkJBQTRCLHlDQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRTtBQUFBLGVBUHZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxVQUVBLHVCQUFDLG1jQUFNLFdBQVUsK0JBQ2Y7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTL0UsUUFBUWMsZUFBZUc7QUFBQUEsZ0JBQ2hDLFVBQVUsQ0FBQ3VELE1BQU03QixhQUFhLGlCQUFpQixpQkFBaUI2QixHQUFHQyxRQUFRTSxPQUFPO0FBQUEsZ0JBQ2xGLFdBQVU7QUFBQTtBQUFBLGNBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSW1FO0FBQUEsWUFFbkUsdUJBQUMseWVBQUssV0FBVSw2QkFBNEIsOEJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBEO0FBQUEsZUFQNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFVBRUEsdUJBQUMsbWNBQU0sV0FBVSwrQkFDZjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVMvRSxRQUFRYyxlQUFlSTtBQUFBQSxnQkFDaEMsVUFBVSxDQUFDc0QsTUFBTTdCLGFBQWEsaUJBQWlCLGlCQUFpQjZCLEdBQUdDLFFBQVFNLE9BQU87QUFBQSxnQkFDbEYsV0FBVTtBQUFBO0FBQUEsY0FKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJbUU7QUFBQSxZQUVuRSx1QkFBQyx5ZUFBSyxXQUFVLDZCQUE0Qiw4QkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEQ7QUFBQSxlQVA1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsVUFFQSx1QkFBQyxtY0FBTSxXQUFVLCtCQUNmO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUy9FLFFBQVFjLGVBQWVLO0FBQUFBLGdCQUNoQyxVQUFVLENBQUNxRCxNQUFNN0IsYUFBYSxpQkFBaUIsZ0JBQWdCNkIsR0FBR0MsUUFBUU0sT0FBTztBQUFBLGdCQUNqRixXQUFVO0FBQUE7QUFBQSxjQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUltRTtBQUFBLFlBRW5FLHVCQUFDLHdlQUFLLFdBQVUsNkJBQTRCLDZCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5RDtBQUFBLGVBUDNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxhQWpERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBa0RBO0FBQUEsV0F4REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlEQTtBQUFBLE1BR0EsdUJBQUMsbWRBQUksV0FBVSxrREFDYjtBQUFBLCtCQUFDLCtlQUFHLFdBQVUsNEVBQ1o7QUFBQSxpQ0FBQyx1Y0FBSyxNQUFLLFVBQVMsTUFBTSxJQUFJLFdBQVUsa0JBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNEO0FBQUEsVUFDdEQsdUJBQUMsMmFBQUssd0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBYztBQUFBLGFBRmhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBRUEsdUJBQUMsdWFBQUksV0FBVSxhQUNiO0FBQUEsaUNBQUMsbVlBQ0M7QUFBQSxtQ0FBQyxzaEJBQU0sV0FBVSxvREFBbUQseUNBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZGO0FBQUEsWUFDN0Y7QUFBQSxjQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsT0FBTy9FLFFBQVFvQixVQUFVRztBQUFBQSxnQkFDekIsVUFBVSxDQUFDaUQsTUFBTTdCLGFBQWEsWUFBWSxrQkFBa0JtQyxTQUFTTixHQUFHQyxRQUFRM0IsS0FBSyxDQUFDO0FBQUEsZ0JBQ3RGLFdBQVU7QUFBQSxnQkFDVixLQUFJO0FBQUEsZ0JBQ0osS0FBSTtBQUFBO0FBQUEsY0FOTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNWTtBQUFBLGVBUmQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBRUEsdUJBQUMsbVlBQ0M7QUFBQSxtQ0FBQywrZ0JBQU0sV0FBVSxvREFBbUQsa0NBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNGO0FBQUEsWUFDdEY7QUFBQSxjQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsT0FBTzlDLFFBQVFvQixVQUFVSTtBQUFBQSxnQkFDekIsVUFBVSxDQUFDZ0QsTUFBTTdCLGFBQWEsWUFBWSxpQkFBaUJtQyxTQUFTTixHQUFHQyxRQUFRM0IsS0FBSyxDQUFDO0FBQUEsZ0JBQ3JGLFdBQVU7QUFBQSxnQkFDVixLQUFJO0FBQUEsZ0JBQ0osS0FBSTtBQUFBO0FBQUEsY0FOTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNVTtBQUFBLGVBUlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBRUEsdUJBQUMsdWFBQUksV0FBVSxhQUNiO0FBQUEsbUNBQUMsbWNBQU0sV0FBVSwrQkFDZjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxTQUFTOUMsUUFBUW9CLFVBQVVDO0FBQUFBLGtCQUMzQixVQUFVLENBQUNtRCxNQUFNN0IsYUFBYSxZQUFZLHNCQUFzQjZCLEdBQUdDLFFBQVFNLE9BQU87QUFBQSxrQkFDbEYsV0FBVTtBQUFBO0FBQUEsZ0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSW1FO0FBQUEsY0FFbkUsdUJBQUMsd2ZBQUssV0FBVSw2QkFBNEIsMkNBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVFO0FBQUEsaUJBUHpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxZQUVBLHVCQUFDLG1jQUFNLFdBQVUsK0JBQ2Y7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsU0FBUy9FLFFBQVFvQixVQUFVRTtBQUFBQSxrQkFDM0IsVUFBVSxDQUFDa0QsTUFBTTdCLGFBQWEsWUFBWSxpQkFBaUI2QixHQUFHQyxRQUFRTSxPQUFPO0FBQUEsa0JBQzdFLFdBQVU7QUFBQTtBQUFBLGdCQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUltRTtBQUFBLGNBRW5FLHVCQUFDLDZmQUFLLFdBQVUsNkJBQTRCLGdEQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0RTtBQUFBLGlCQVA5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsWUFFQSx1QkFBQyxtY0FBTSxXQUFVLCtCQUNmO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFNBQVMvRSxRQUFRb0IsVUFBVUs7QUFBQUEsa0JBQzNCLFVBQVUsQ0FBQytDLE1BQU03QixhQUFhLFlBQVksa0JBQWtCNkIsR0FBR0MsUUFBUU0sT0FBTztBQUFBLGtCQUM5RSxXQUFVO0FBQUE7QUFBQSxnQkFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJbUU7QUFBQSxjQUVuRSx1QkFBQyxzZkFBSyxXQUFVLDZCQUE0Qix1Q0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUU7QUFBQSxpQkFQckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLGVBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBOEJBO0FBQUEsYUF2REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdEQTtBQUFBLFdBOURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUErREE7QUFBQSxTQWpRRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa1FBO0FBQUEsSUFFQSx1QkFBQyxtZEFBSSxXQUFVLGtEQUNiO0FBQUEsNkJBQUMsOGVBQUcsV0FBVSw0RUFDWjtBQUFBLCtCQUFDLHljQUFLLE1BQUssWUFBVyxNQUFNLElBQUksV0FBVSxrQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RDtBQUFBLFFBQ3hELHVCQUFDLDBiQUFLLGlDQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUI7QUFBQSxXQUZ6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUVBLHVCQUFDLDBjQUFJLFdBQVUseUNBQ2I7QUFBQSwrQkFBQyxtWUFDQztBQUFBLGlDQUFDLDJnQkFBTSxXQUFVLG9EQUFtRCxnQ0FBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Y7QUFBQSxVQUNwRjtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsT0FBTy9FLFFBQVEwQixRQUFRRTtBQUFBQSxjQUN2QixVQUFVLENBQUM0QyxNQUFNN0IsYUFBYSxVQUFVLG1CQUFtQjZCLEdBQUdDLFFBQVEzQixLQUFLO0FBQUEsY0FDM0UsV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyw0Y0FBTyxPQUFNLFVBQVMsc0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZCO0FBQUEsZ0JBQzdCLHVCQUFDLDBjQUFPLE9BQU0sU0FBUSxxQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkI7QUFBQSxnQkFDM0IsdUJBQUMsNGNBQU8sT0FBTSxVQUFTLHNCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2QjtBQUFBLGdCQUM3Qix1QkFBQyw4Y0FBTyxPQUFNLFdBQVUsdUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStCO0FBQUE7QUFBQTtBQUFBLFlBUmpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVNBO0FBQUEsYUFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxRQUVBLHVCQUFDLG1ZQUNDO0FBQUEsaUNBQUMsb2hCQUFNLFdBQVUsb0RBQW1ELHVDQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRjtBQUFBLFVBQzNGO0FBQUEsWUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxPQUFPOUMsUUFBUTBCLFFBQVFHO0FBQUFBLGNBQ3ZCLFVBQVUsQ0FBQzJDLE1BQU03QixhQUFhLFVBQVUsaUJBQWlCbUMsU0FBU04sR0FBR0MsUUFBUTNCLEtBQUssQ0FBQztBQUFBLGNBQ25GLFdBQVU7QUFBQSxjQUNWLEtBQUk7QUFBQSxjQUNKLEtBQUk7QUFBQTtBQUFBLFlBTk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTVc7QUFBQSxhQVJiO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFFBRUEsdUJBQUMsOGFBQUksV0FBVSxrQkFDYjtBQUFBLFVBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBQ0MsU0FBU3lCO0FBQUFBLFlBQ1QsV0FBVTtBQUFBLFlBRVY7QUFBQSxxQ0FBQyxrYUFBSyxNQUFLLFlBQVcsTUFBTSxNQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQjtBQUFBLGNBQy9CLHVCQUFDLGdiQUFLLDJCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlCO0FBQUE7QUFBQTtBQUFBLFVBTG5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsV0FuQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW9DQTtBQUFBLE1BRUEsdUJBQUMsaWFBQUksV0FBVSxRQUNiLGlDQUFDLG1jQUFNLFdBQVUsK0JBQ2Y7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBU3ZFLFFBQVEwQixRQUFRQztBQUFBQSxZQUN6QixVQUFVLENBQUM2QyxNQUFNN0IsYUFBYSxVQUFVLGNBQWM2QixHQUFHQyxRQUFRTSxPQUFPO0FBQUEsWUFDeEUsV0FBVTtBQUFBO0FBQUEsVUFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJbUU7QUFBQSxRQUVuRSx1QkFBQyxxZkFBSyxXQUFVLDZCQUE0Qix3Q0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRTtBQUFBLFdBUHRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLFNBdERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1REE7QUFBQSxJQUVDNUMsbUJBQ0MsdUJBQUMsdWNBQUksV0FBVSx3Q0FDYixpQ0FBQyx3ZEFBSSxXQUFVLHNEQUNiO0FBQUEsNkJBQUMsd2NBQUksV0FBVSx3Q0FBdUMsU0FBUyxNQUFNQyxtQkFBbUIsS0FBSyxLQUE3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdHO0FBQUEsTUFDaEcsdUJBQUMseWVBQUksV0FBVSxtRUFDYixpQ0FBQyxpYUFBSSxXQUFVLE9BQ2I7QUFBQSwrQkFBQywwY0FBSSxXQUFVLDBDQUNiO0FBQUEsaUNBQUMseWZBQUcsV0FBVSwyQ0FBMEMsb0NBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRFO0FBQUEsVUFDNUU7QUFBQSxZQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUNDLFNBQVMsTUFBTUEsbUJBQW1CLEtBQUs7QUFBQSxjQUN2QyxXQUFVO0FBQUEsY0FFVixpQ0FBQywyWkFBSyxNQUFLLEtBQUksTUFBTSxNQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3QjtBQUFBO0FBQUEsWUFKMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBRUEsdUJBQUMsdWFBQUksV0FBVSxhQUNiO0FBQUEsaUNBQUMsbVlBQ0M7QUFBQSxtQ0FBQyx3Z0JBQU0sV0FBVSxvREFBbUQsNkJBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlGO0FBQUEsWUFDakY7QUFBQSxjQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFDQyxPQUFPSDtBQUFBQSxnQkFDUCxVQUFVLENBQUN1QyxNQUFNdEMsZ0JBQWdCc0MsR0FBR0MsUUFBUTNCLEtBQUs7QUFBQSxnQkFDakQsV0FBVTtBQUFBLGdCQUVWO0FBQUEseUNBQUMsd2NBQU8sT0FBTSxRQUFPLG9CQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5QjtBQUFBLGtCQUN6Qix1QkFBQyx1Y0FBTyxPQUFNLE9BQU0sb0JBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXdCO0FBQUE7QUFBQTtBQUFBLGNBTjFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9BO0FBQUEsZUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsVUFFQSx1QkFBQyw4aEJBQUUsV0FBVSwrQkFBOEIsOEVBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkE7QUFBQSxRQUVBLHVCQUFDLG1jQUFJLFdBQVUsbUNBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNVixtQkFBbUIsS0FBSztBQUFBLGNBQ3ZDLFdBQVU7QUFBQSxjQUFzRjtBQUFBO0FBQUEsWUFGbEc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FDQyxTQUFTZTtBQUFBQSxjQUNULFdBQVU7QUFBQSxjQUE0RztBQUFBO0FBQUEsWUFGeEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxhQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLFdBMUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyQ0EsS0E1Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTZDQTtBQUFBLFNBL0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnREEsS0FqREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtEQTtBQUFBLElBR0YsdUJBQUMsc2RBQUksV0FBVSxxREFDYixpQ0FBQywyYkFBSSxXQUFVLDhCQUNiO0FBQUEsNkJBQUMscWRBQUssTUFBSyxlQUFjLE1BQU0sSUFBSSxXQUFVLHlCQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtFO0FBQUEsTUFDbEUsdUJBQUMsb2FBQUksV0FBVSxVQUNiO0FBQUEsK0JBQUMsd2ZBQUcsV0FBVSx5Q0FBd0MscUNBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkU7QUFBQSxRQUMzRSx1QkFBQyw0YkFBRSxXQUFVLG9DQUNWcEIsdUJBQ0MsZ0ZBRUEsK0ZBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsV0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxTQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQSxLQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FjQTtBQUFBLE9BOVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErWkE7QUFFSjtBQUFFaEMsR0FwaEJJRCxxQkFBbUI7QUFBQWtGLEtBQW5CbEY7QUFzaEJOLGVBQWVBO0FBQW9CLElBQUFrRjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJ1c2VTdGF0ZSIsIkljb24iLCJTeXN0ZW1Db25maWd1cmF0aW9uIiwiX3MiLCJjb25maWciLCJzZXRDb25maWciLCJnZW5lcmFsIiwiY29tcGFueU5hbWUiLCJ0aW1lem9uZSIsImRhdGVGb3JtYXQiLCJjdXJyZW5jeSIsImxhbmd1YWdlIiwic2FsZXMiLCJkZWZhdWx0UGlwZWxpbmVTdGFnZSIsImRlYWxDdXJyZW5jeSIsInJlcXVpcmVEZWFsVmFsdWUiLCJhdXRvUHJvZ3Jlc3NEZWFscyIsImRlYWxJbmFjdGl2aXR5RGF5cyIsIm5vdGlmaWNhdGlvbnMiLCJlbWFpbE5vdGlmaWNhdGlvbnMiLCJkZWFsVXBkYXRlTm90aWZpY2F0aW9ucyIsInRhc2tSZW1pbmRlcnMiLCJ3ZWVrbHlSZXBvcnRzIiwic3lzdGVtQWxlcnRzIiwic2VjdXJpdHkiLCJwYXNzd29yZENvbXBsZXhpdHkiLCJ0d29GYWN0b3JBdXRoIiwic2Vzc2lvblRpbWVvdXQiLCJsb2dpbkF0dGVtcHRzIiwiZGF0YUVuY3J5cHRpb24iLCJiYWNrdXAiLCJhdXRvQmFja3VwIiwiYmFja3VwRnJlcXVlbmN5IiwicmV0ZW50aW9uRGF5cyIsImJhY2t1cExvY2F0aW9uIiwiaGFzQ2hhbmdlcyIsInNldEhhc0NoYW5nZXMiLCJleHBvcnRGb3JtYXQiLCJzZXRFeHBvcnRGb3JtYXQiLCJzaG93RXhwb3J0TW9kYWwiLCJzZXRTaG93RXhwb3J0TW9kYWwiLCJ0aW1lem9uZXMiLCJjdXJyZW5jaWVzIiwiY29kZSIsIm5hbWUiLCJkYXRlRm9ybWF0cyIsImxhbmd1YWdlcyIsInVwZGF0ZUNvbmZpZyIsInNlY3Rpb24iLCJmaWVsZCIsInZhbHVlIiwicHJldiIsImhhbmRsZVNhdmVDaGFuZ2VzIiwiY29uc29sZSIsImxvZyIsImhhbmRsZUV4cG9ydENvbmZpZyIsImNvbmZpZ0RhdGEiLCJKU09OIiwic3RyaW5naWZ5IiwiYmxvYiIsIkJsb2IiLCJ0eXBlIiwidXJsIiwiVVJMIiwiY3JlYXRlT2JqZWN0VVJMIiwiYSIsImRvY3VtZW50IiwiY3JlYXRlRWxlbWVudCIsImhyZWYiLCJkb3dubG9hZCIsImJvZHkiLCJhcHBlbmRDaGlsZCIsImNsaWNrIiwicmVtb3ZlQ2hpbGQiLCJyZXZva2VPYmplY3RVUkwiLCJoYW5kbGVUZXN0QmFja3VwIiwiZSIsInRhcmdldCIsIm1hcCIsInR6IiwiZm9ybWF0IiwibGFuZyIsInBhcnNlSW50IiwiY2hlY2tlZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiU3lzdGVtQ29uZmlndXJhdGlvbi5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gc3JjL3BhZ2VzL3NldHRpbmdzLWFkbWluaXN0cmF0aW9uL2NvbXBvbmVudHMvU3lzdGVtQ29uZmlndXJhdGlvbi5qc3hcclxuaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgSWNvbiBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL0FwcEljb24nO1xyXG5cclxuY29uc3QgU3lzdGVtQ29uZmlndXJhdGlvbiA9ICgpID0+IHtcclxuICBjb25zdCBbY29uZmlnLCBzZXRDb25maWddID0gdXNlU3RhdGUoe1xyXG4gICAgZ2VuZXJhbDoge1xyXG4gICAgICBjb21wYW55TmFtZTogJ1NhbGVzRmxvdyBQcm8gSW5jLicsXHJcbiAgICAgIHRpbWV6b25lOiAnQW1lcmljYS9OZXdfWW9yaycsXHJcbiAgICAgIGRhdGVGb3JtYXQ6ICdNTS9ERC9ZWVlZJyxcclxuICAgICAgY3VycmVuY3k6ICdVU0QnLFxyXG4gICAgICBsYW5ndWFnZTogJ2VuJ1xyXG4gICAgfSxcclxuICAgIHNhbGVzOiB7XHJcbiAgICAgIGRlZmF1bHRQaXBlbGluZVN0YWdlOiAnUHJvc3BlY3RpbmcnLFxyXG4gICAgICBkZWFsQ3VycmVuY3k6ICdVU0QnLFxyXG4gICAgICByZXF1aXJlRGVhbFZhbHVlOiB0cnVlLFxyXG4gICAgICBhdXRvUHJvZ3Jlc3NEZWFsczogZmFsc2UsXHJcbiAgICAgIGRlYWxJbmFjdGl2aXR5RGF5czogMzBcclxuICAgIH0sXHJcbiAgICBub3RpZmljYXRpb25zOiB7XHJcbiAgICAgIGVtYWlsTm90aWZpY2F0aW9uczogdHJ1ZSxcclxuICAgICAgZGVhbFVwZGF0ZU5vdGlmaWNhdGlvbnM6IHRydWUsXHJcbiAgICAgIHRhc2tSZW1pbmRlcnM6IHRydWUsXHJcbiAgICAgIHdlZWtseVJlcG9ydHM6IHRydWUsXHJcbiAgICAgIHN5c3RlbUFsZXJ0czogdHJ1ZVxyXG4gICAgfSxcclxuICAgIHNlY3VyaXR5OiB7XHJcbiAgICAgIHBhc3N3b3JkQ29tcGxleGl0eTogdHJ1ZSxcclxuICAgICAgdHdvRmFjdG9yQXV0aDogZmFsc2UsXHJcbiAgICAgIHNlc3Npb25UaW1lb3V0OiA0ODAsXHJcbiAgICAgIGxvZ2luQXR0ZW1wdHM6IDUsXHJcbiAgICAgIGRhdGFFbmNyeXB0aW9uOiB0cnVlXHJcbiAgICB9LFxyXG4gICAgYmFja3VwOiB7XHJcbiAgICAgIGF1dG9CYWNrdXA6IHRydWUsXHJcbiAgICAgIGJhY2t1cEZyZXF1ZW5jeTogJ2RhaWx5JyxcclxuICAgICAgcmV0ZW50aW9uRGF5czogMzAsXHJcbiAgICAgIGJhY2t1cExvY2F0aW9uOiAnY2xvdWQnXHJcbiAgICB9XHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IFtoYXNDaGFuZ2VzLCBzZXRIYXNDaGFuZ2VzXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZXhwb3J0Rm9ybWF0LCBzZXRFeHBvcnRGb3JtYXRdID0gdXNlU3RhdGUoJ2pzb24nKTtcclxuICBjb25zdCBbc2hvd0V4cG9ydE1vZGFsLCBzZXRTaG93RXhwb3J0TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCB0aW1lem9uZXMgPSBbXHJcbiAgICAnQW1lcmljYS9OZXdfWW9yaycsXHJcbiAgICAnQW1lcmljYS9DaGljYWdvJyxcclxuICAgICdBbWVyaWNhL0RlbnZlcicsXHJcbiAgICAnQW1lcmljYS9Mb3NfQW5nZWxlcycsXHJcbiAgICAnRXVyb3BlL0xvbmRvbicsXHJcbiAgICAnRXVyb3BlL1BhcmlzJyxcclxuICAgICdBc2lhL1Rva3lvJyxcclxuICAgICdBc2lhL1NoYW5naGFpJyxcclxuICAgICdBdXN0cmFsaWEvU3lkbmV5J1xyXG4gIF07XHJcblxyXG4gIGNvbnN0IGN1cnJlbmNpZXMgPSBbXHJcbiAgICB7IGNvZGU6ICdVU0QnLCBuYW1lOiAnVVMgRG9sbGFyJyB9LFxyXG4gICAgeyBjb2RlOiAnRVVSJywgbmFtZTogJ0V1cm8nIH0sXHJcbiAgICB7IGNvZGU6ICdHQlAnLCBuYW1lOiAnQnJpdGlzaCBQb3VuZCcgfSxcclxuICAgIHsgY29kZTogJ0NBRCcsIG5hbWU6ICdDYW5hZGlhbiBEb2xsYXInIH0sXHJcbiAgICB7IGNvZGU6ICdBVUQnLCBuYW1lOiAnQXVzdHJhbGlhbiBEb2xsYXInIH0sXHJcbiAgICB7IGNvZGU6ICdKUFknLCBuYW1lOiAnSmFwYW5lc2UgWWVuJyB9XHJcbiAgXTtcclxuXHJcbiAgY29uc3QgZGF0ZUZvcm1hdHMgPSBbXHJcbiAgICAnTU0vREQvWVlZWScsXHJcbiAgICAnREQvTU0vWVlZWScsXHJcbiAgICAnWVlZWS1NTS1ERCcsXHJcbiAgICAnREQtTU0tWVlZWSdcclxuICBdO1xyXG5cclxuICBjb25zdCBsYW5ndWFnZXMgPSBbXHJcbiAgICB7IGNvZGU6ICdlbicsIG5hbWU6ICdFbmdsaXNoJyB9LFxyXG4gICAgeyBjb2RlOiAnZXMnLCBuYW1lOiAnU3BhbmlzaCcgfSxcclxuICAgIHsgY29kZTogJ2ZyJywgbmFtZTogJ0ZyZW5jaCcgfSxcclxuICAgIHsgY29kZTogJ2RlJywgbmFtZTogJ0dlcm1hbicgfSxcclxuICAgIHsgY29kZTogJ2l0JywgbmFtZTogJ0l0YWxpYW4nIH1cclxuICBdO1xyXG5cclxuICBjb25zdCB1cGRhdGVDb25maWcgPSAoc2VjdGlvbiwgZmllbGQsIHZhbHVlKSA9PiB7XHJcbiAgICBzZXRDb25maWcocHJldiA9PiAoe1xyXG4gICAgICAuLi5wcmV2LFxyXG4gICAgICBbc2VjdGlvbl06IHtcclxuICAgICAgICAuLi5wcmV2Py5bc2VjdGlvbl0sXHJcbiAgICAgICAgW2ZpZWxkXTogdmFsdWVcclxuICAgICAgfVxyXG4gICAgfSkpO1xyXG4gICAgc2V0SGFzQ2hhbmdlcyh0cnVlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTYXZlQ2hhbmdlcyA9ICgpID0+IHtcclxuICAgIGNvbnNvbGUubG9nKCdTYXZpbmcgY29uZmlndXJhdGlvbjonLCBjb25maWcpO1xyXG4gICAgc2V0SGFzQ2hhbmdlcyhmYWxzZSk7XHJcbiAgICAvLyBIZXJlIHlvdSB3b3VsZCB0eXBpY2FsbHkgbWFrZSBhbiBBUEkgY2FsbCB0byBzYXZlIHRoZSBjb25maWd1cmF0aW9uXHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRXhwb3J0Q29uZmlnID0gKCkgPT4ge1xyXG4gICAgY29uc3QgY29uZmlnRGF0YSA9IGV4cG9ydEZvcm1hdCA9PT0gJ2pzb24nID8gSlNPTi5zdHJpbmdpZnkoY29uZmlnLCBudWxsLCAyKSA6IGNvbmZpZztcclxuICAgIGNvbnN0IGJsb2IgPSBuZXcgQmxvYihbY29uZmlnRGF0YV0sIHsgdHlwZTogZXhwb3J0Rm9ybWF0ID09PSAnanNvbicgPyAnYXBwbGljYXRpb24vanNvbicgOiAndGV4dC9wbGFpbicgfSk7XHJcbiAgICBjb25zdCB1cmwgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpO1xyXG4gICAgY29uc3QgYSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKTtcclxuICAgIGEuaHJlZiA9IHVybDtcclxuICAgIGEuZG93bmxvYWQgPSBgc3lzdGVtLWNvbmZpZy4ke2V4cG9ydEZvcm1hdH1gO1xyXG4gICAgZG9jdW1lbnQuYm9keT8uYXBwZW5kQ2hpbGQoYSk7XHJcbiAgICBhPy5jbGljaygpO1xyXG4gICAgZG9jdW1lbnQuYm9keT8ucmVtb3ZlQ2hpbGQoYSk7XHJcbiAgICBVUkwucmV2b2tlT2JqZWN0VVJMKHVybCk7XHJcbiAgICBzZXRTaG93RXhwb3J0TW9kYWwoZmFsc2UpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVRlc3RCYWNrdXAgPSAoKSA9PiB7XHJcbiAgICBjb25zb2xlLmxvZygnVGVzdGluZyBiYWNrdXAgc3lzdGVtLi4uJyk7XHJcbiAgICAvLyBTaW11bGF0ZSBiYWNrdXAgdGVzdFxyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxyXG4gICAgICB7LyogSGVhZGVyICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtdGV4dC1wcmltYXJ5XCI+U3lzdGVtIENvbmZpZ3VyYXRpb248L2gyPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC10ZXh0LXNlY29uZGFyeSBtdC0xXCI+TWFuYWdlIGdlbmVyYWwgc3lzdGVtIHNldHRpbmdzIGFuZCBwcmVmZXJlbmNlczwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggc3BhY2UteC0zXCI+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dFeHBvcnRNb2RhbCh0cnVlKX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctYmFja2dyb3VuZCB0ZXh0LXRleHQtcHJpbWFyeSBweC00IHB5LTIgcm91bmRlZC1sZyBob3ZlcjpiZy1zdXJmYWNlLWhvdmVyIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MCBlYXNlLXNtb290aCBmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTIgYm9yZGVyIGJvcmRlci1ib3JkZXJcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8SWNvbiBuYW1lPVwiRG93bmxvYWRcIiBzaXplPXsxNn0gLz5cclxuICAgICAgICAgICAgPHNwYW4+RXhwb3J0IENvbmZpZ3VyYXRpb248L3NwYW4+XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU2F2ZUNoYW5nZXN9XHJcbiAgICAgICAgICAgIGRpc2FibGVkPXshaGFzQ2hhbmdlc31cclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0yIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwIGVhc2Utc21vb3RoIGZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMiAke1xyXG4gICAgICAgICAgICAgIGhhc0NoYW5nZXNcclxuICAgICAgICAgICAgICAgID8gJ2JnLXByaW1hcnkgdGV4dC13aGl0ZSBob3ZlcjpiZy1wcmltYXJ5LTYwMCcgOidiZy1ncmF5LTEwMCB0ZXh0LWdyYXktNDAwIGN1cnNvci1ub3QtYWxsb3dlZCdcclxuICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxJY29uIG5hbWU9XCJTYXZlXCIgc2l6ZT17MTZ9IC8+XHJcbiAgICAgICAgICAgIDxzcGFuPlNhdmUgQ2hhbmdlczwvc3Bhbj5cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgey8qIENvbmZpZ3VyYXRpb24gU2VjdGlvbnMgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBsZzpncmlkLWNvbHMtMiBnYXAtNlwiPlxyXG4gICAgICAgIHsvKiBHZW5lcmFsIFNldHRpbmdzICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc3VyZmFjZSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItYm9yZGVyIHAtNlwiPlxyXG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXRleHQtcHJpbWFyeSBtYi00IGZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMlwiPlxyXG4gICAgICAgICAgICA8SWNvbiBuYW1lPVwiU2V0dGluZ3NcIiBzaXplPXsyMH0gY2xhc3NOYW1lPVwidGV4dC1wcmltYXJ5XCIgLz5cclxuICAgICAgICAgICAgPHNwYW4+R2VuZXJhbCBTZXR0aW5nczwvc3Bhbj5cclxuICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItMVwiPkNvbXBhbnkgTmFtZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Y29uZmlnPy5nZW5lcmFsPy5jb21wYW55TmFtZX1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlQ29uZmlnKCdnZW5lcmFsJywgJ2NvbXBhbnlOYW1lJywgZT8udGFyZ2V0Py52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1wcmltYXJ5IGZvY3VzOmJvcmRlci1wcmltYXJ5XCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItMVwiPlRpbWV6b25lPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Y29uZmlnPy5nZW5lcmFsPy50aW1lem9uZX1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlQ29uZmlnKCdnZW5lcmFsJywgJ3RpbWV6b25lJywgZT8udGFyZ2V0Py52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1wcmltYXJ5IGZvY3VzOmJvcmRlci1wcmltYXJ5XCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7dGltZXpvbmVzPy5tYXAodHogPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17dHp9IHZhbHVlPXt0en0+e3R6fTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSBtYi0xXCI+RGF0ZSBGb3JtYXQ8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtjb25maWc/LmdlbmVyYWw/LmRhdGVGb3JtYXR9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZUNvbmZpZygnZ2VuZXJhbCcsICdkYXRlRm9ybWF0JywgZT8udGFyZ2V0Py52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1wcmltYXJ5IGZvY3VzOmJvcmRlci1wcmltYXJ5XCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7ZGF0ZUZvcm1hdHM/Lm1hcChmb3JtYXQgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17Zm9ybWF0fSB2YWx1ZT17Zm9ybWF0fT57Zm9ybWF0fTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSBtYi0xXCI+Q3VycmVuY3k8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtjb25maWc/LmdlbmVyYWw/LmN1cnJlbmN5fVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVDb25maWcoJ2dlbmVyYWwnLCAnY3VycmVuY3knLCBlPy50YXJnZXQ/LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ib3JkZXIgcm91bmRlZC1sZyBmb2N1czpyaW5nLXByaW1hcnkgZm9jdXM6Ym9yZGVyLXByaW1hcnlcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtjdXJyZW5jaWVzPy5tYXAoY3VycmVuY3kgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17Y3VycmVuY3k/LmNvZGV9IHZhbHVlPXtjdXJyZW5jeT8uY29kZX0+XHJcbiAgICAgICAgICAgICAgICAgICAge2N1cnJlbmN5Py5jb2RlfSAtIHtjdXJyZW5jeT8ubmFtZX1cclxuICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IG1iLTFcIj5MYW5ndWFnZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2NvbmZpZz8uZ2VuZXJhbD8ubGFuZ3VhZ2V9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZUNvbmZpZygnZ2VuZXJhbCcsICdsYW5ndWFnZScsIGU/LnRhcmdldD8udmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLWxnIGZvY3VzOnJpbmctcHJpbWFyeSBmb2N1czpib3JkZXItcHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge2xhbmd1YWdlcz8ubWFwKGxhbmcgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17bGFuZz8uY29kZX0gdmFsdWU9e2xhbmc/LmNvZGV9PntsYW5nPy5uYW1lfTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBTYWxlcyBTZXR0aW5ncyAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXN1cmZhY2Ugcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWJvcmRlciBwLTZcIj5cclxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC10ZXh0LXByaW1hcnkgbWItNCBmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTJcIj5cclxuICAgICAgICAgICAgPEljb24gbmFtZT1cIlRhcmdldFwiIHNpemU9ezIwfSBjbGFzc05hbWU9XCJ0ZXh0LXByaW1hcnlcIiAvPlxyXG4gICAgICAgICAgICA8c3Bhbj5TYWxlcyBTZXR0aW5nczwvc3Bhbj5cclxuICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItMVwiPkRlZmF1bHQgUGlwZWxpbmUgU3RhZ2U8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtjb25maWc/LnNhbGVzPy5kZWZhdWx0UGlwZWxpbmVTdGFnZX1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlQ29uZmlnKCdzYWxlcycsICdkZWZhdWx0UGlwZWxpbmVTdGFnZScsIGU/LnRhcmdldD8udmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLWxnIGZvY3VzOnJpbmctcHJpbWFyeSBmb2N1czpib3JkZXItcHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlByb3NwZWN0aW5nXCI+UHJvc3BlY3Rpbmc8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJRdWFsaWZpY2F0aW9uXCI+UXVhbGlmaWNhdGlvbjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlByb3Bvc2FsXCI+UHJvcG9zYWw8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJOZWdvdGlhdGlvblwiPk5lZ290aWF0aW9uPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSBtYi0xXCI+RGVhbCBJbmFjdGl2aXR5IFdhcm5pbmcgKERheXMpPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2NvbmZpZz8uc2FsZXM/LmRlYWxJbmFjdGl2aXR5RGF5c31cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlQ29uZmlnKCdzYWxlcycsICdkZWFsSW5hY3Rpdml0eURheXMnLCBwYXJzZUludChlPy50YXJnZXQ/LnZhbHVlKSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1wcmltYXJ5IGZvY3VzOmJvcmRlci1wcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgIG1pbj1cIjFcIlxyXG4gICAgICAgICAgICAgICAgbWF4PVwiMzY1XCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMlwiPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2NvbmZpZz8uc2FsZXM/LnJlcXVpcmVEZWFsVmFsdWV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlQ29uZmlnKCdzYWxlcycsICdyZXF1aXJlRGVhbFZhbHVlJywgZT8udGFyZ2V0Py5jaGVja2VkKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZCBib3JkZXItYm9yZGVyIHRleHQtcHJpbWFyeSBmb2N1czpyaW5nLXByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC10ZXh0LXByaW1hcnlcIj5SZXF1aXJlIGRlYWwgdmFsdWU8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCI+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Y29uZmlnPy5zYWxlcz8uYXV0b1Byb2dyZXNzRGVhbHN9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlQ29uZmlnKCdzYWxlcycsICdhdXRvUHJvZ3Jlc3NEZWFscycsIGU/LnRhcmdldD8uY2hlY2tlZCl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQgYm9yZGVyLWJvcmRlciB0ZXh0LXByaW1hcnkgZm9jdXM6cmluZy1wcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtdGV4dC1wcmltYXJ5XCI+QXV0by1wcm9ncmVzcyBkZWFscyBiYXNlZCBvbiBhY3Rpdml0aWVzPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBOb3RpZmljYXRpb24gU2V0dGluZ3MgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zdXJmYWNlIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ib3JkZXIgcC02XCI+XHJcbiAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtdGV4dC1wcmltYXJ5IG1iLTQgZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCI+XHJcbiAgICAgICAgICAgIDxJY29uIG5hbWU9XCJCZWxsXCIgc2l6ZT17MjB9IGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeVwiIC8+XHJcbiAgICAgICAgICAgIDxzcGFuPk5vdGlmaWNhdGlvbnM8L3NwYW4+XHJcbiAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxyXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCI+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgY2hlY2tlZD17Y29uZmlnPy5ub3RpZmljYXRpb25zPy5lbWFpbE5vdGlmaWNhdGlvbnN9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZUNvbmZpZygnbm90aWZpY2F0aW9ucycsICdlbWFpbE5vdGlmaWNhdGlvbnMnLCBlPy50YXJnZXQ/LmNoZWNrZWQpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZCBib3JkZXItYm9yZGVyIHRleHQtcHJpbWFyeSBmb2N1czpyaW5nLXByaW1hcnlcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXRleHQtcHJpbWFyeVwiPkVtYWlsIG5vdGlmaWNhdGlvbnM8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCI+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgY2hlY2tlZD17Y29uZmlnPy5ub3RpZmljYXRpb25zPy5kZWFsVXBkYXRlTm90aWZpY2F0aW9uc31cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlQ29uZmlnKCdub3RpZmljYXRpb25zJywgJ2RlYWxVcGRhdGVOb3RpZmljYXRpb25zJywgZT8udGFyZ2V0Py5jaGVja2VkKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQgYm9yZGVyLWJvcmRlciB0ZXh0LXByaW1hcnkgZm9jdXM6cmluZy1wcmltYXJ5XCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC10ZXh0LXByaW1hcnlcIj5EZWFsIHVwZGF0ZSBub3RpZmljYXRpb25zPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMlwiPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2NvbmZpZz8ubm90aWZpY2F0aW9ucz8udGFza1JlbWluZGVyc31cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlQ29uZmlnKCdub3RpZmljYXRpb25zJywgJ3Rhc2tSZW1pbmRlcnMnLCBlPy50YXJnZXQ/LmNoZWNrZWQpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZCBib3JkZXItYm9yZGVyIHRleHQtcHJpbWFyeSBmb2N1czpyaW5nLXByaW1hcnlcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXRleHQtcHJpbWFyeVwiPlRhc2sgcmVtaW5kZXJzPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMlwiPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2NvbmZpZz8ubm90aWZpY2F0aW9ucz8ud2Vla2x5UmVwb3J0c31cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlQ29uZmlnKCdub3RpZmljYXRpb25zJywgJ3dlZWtseVJlcG9ydHMnLCBlPy50YXJnZXQ/LmNoZWNrZWQpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZCBib3JkZXItYm9yZGVyIHRleHQtcHJpbWFyeSBmb2N1czpyaW5nLXByaW1hcnlcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXRleHQtcHJpbWFyeVwiPldlZWtseSByZXBvcnRzPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMlwiPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2NvbmZpZz8ubm90aWZpY2F0aW9ucz8uc3lzdGVtQWxlcnRzfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVDb25maWcoJ25vdGlmaWNhdGlvbnMnLCAnc3lzdGVtQWxlcnRzJywgZT8udGFyZ2V0Py5jaGVja2VkKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQgYm9yZGVyLWJvcmRlciB0ZXh0LXByaW1hcnkgZm9jdXM6cmluZy1wcmltYXJ5XCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC10ZXh0LXByaW1hcnlcIj5TeXN0ZW0gYWxlcnRzPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBTZWN1cml0eSBTZXR0aW5ncyAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXN1cmZhY2Ugcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWJvcmRlciBwLTZcIj5cclxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC10ZXh0LXByaW1hcnkgbWItNCBmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTJcIj5cclxuICAgICAgICAgICAgPEljb24gbmFtZT1cIlNoaWVsZFwiIHNpemU9ezIwfSBjbGFzc05hbWU9XCJ0ZXh0LXByaW1hcnlcIiAvPlxyXG4gICAgICAgICAgICA8c3Bhbj5TZWN1cml0eTwvc3Bhbj5cclxuICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItMVwiPlNlc3Npb24gVGltZW91dCAobWludXRlcyk8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Y29uZmlnPy5zZWN1cml0eT8uc2Vzc2lvblRpbWVvdXR9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZUNvbmZpZygnc2VjdXJpdHknLCAnc2Vzc2lvblRpbWVvdXQnLCBwYXJzZUludChlPy50YXJnZXQ/LnZhbHVlKSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1wcmltYXJ5IGZvY3VzOmJvcmRlci1wcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgIG1pbj1cIjMwXCJcclxuICAgICAgICAgICAgICAgIG1heD1cIjE0NDBcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSBtYi0xXCI+TWF4IExvZ2luIEF0dGVtcHRzPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2NvbmZpZz8uc2VjdXJpdHk/LmxvZ2luQXR0ZW1wdHN9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZUNvbmZpZygnc2VjdXJpdHknLCAnbG9naW5BdHRlbXB0cycsIHBhcnNlSW50KGU/LnRhcmdldD8udmFsdWUpKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ib3JkZXIgcm91bmRlZC1sZyBmb2N1czpyaW5nLXByaW1hcnkgZm9jdXM6Ym9yZGVyLXByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgbWluPVwiM1wiXHJcbiAgICAgICAgICAgICAgICBtYXg9XCIxMFwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTJcIj5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICBjaGVja2VkPXtjb25maWc/LnNlY3VyaXR5Py5wYXNzd29yZENvbXBsZXhpdHl9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlQ29uZmlnKCdzZWN1cml0eScsICdwYXNzd29yZENvbXBsZXhpdHknLCBlPy50YXJnZXQ/LmNoZWNrZWQpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkIGJvcmRlci1ib3JkZXIgdGV4dC1wcmltYXJ5IGZvY3VzOnJpbmctcHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXRleHQtcHJpbWFyeVwiPlJlcXVpcmUgcGFzc3dvcmQgY29tcGxleGl0eTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTJcIj5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICBjaGVja2VkPXtjb25maWc/LnNlY3VyaXR5Py50d29GYWN0b3JBdXRofVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZUNvbmZpZygnc2VjdXJpdHknLCAndHdvRmFjdG9yQXV0aCcsIGU/LnRhcmdldD8uY2hlY2tlZCl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQgYm9yZGVyLWJvcmRlciB0ZXh0LXByaW1hcnkgZm9jdXM6cmluZy1wcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtdGV4dC1wcmltYXJ5XCI+RW5hYmxlIHR3by1mYWN0b3IgYXV0aGVudGljYXRpb248L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCI+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Y29uZmlnPy5zZWN1cml0eT8uZGF0YUVuY3J5cHRpb259XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlQ29uZmlnKCdzZWN1cml0eScsICdkYXRhRW5jcnlwdGlvbicsIGU/LnRhcmdldD8uY2hlY2tlZCl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQgYm9yZGVyLWJvcmRlciB0ZXh0LXByaW1hcnkgZm9jdXM6cmluZy1wcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtdGV4dC1wcmltYXJ5XCI+RGF0YSBlbmNyeXB0aW9uIGF0IHJlc3Q8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIHsvKiBCYWNrdXAgQ29uZmlndXJhdGlvbiAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zdXJmYWNlIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ib3JkZXIgcC02XCI+XHJcbiAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXRleHQtcHJpbWFyeSBtYi00IGZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMlwiPlxyXG4gICAgICAgICAgPEljb24gbmFtZT1cIkRhdGFiYXNlXCIgc2l6ZT17MjB9IGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeVwiIC8+XHJcbiAgICAgICAgICA8c3Bhbj5CYWNrdXAgJiBSZWNvdmVyeTwvc3Bhbj5cclxuICAgICAgICA8L2gzPlxyXG4gICAgICAgIFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNFwiPlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItMVwiPkJhY2t1cCBGcmVxdWVuY3k8L2xhYmVsPlxyXG4gICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgdmFsdWU9e2NvbmZpZz8uYmFja3VwPy5iYWNrdXBGcmVxdWVuY3l9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVDb25maWcoJ2JhY2t1cCcsICdiYWNrdXBGcmVxdWVuY3knLCBlPy50YXJnZXQ/LnZhbHVlKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1wcmltYXJ5IGZvY3VzOmJvcmRlci1wcmltYXJ5XCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJob3VybHlcIj5Ib3VybHk8L29wdGlvbj5cclxuICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiZGFpbHlcIj5EYWlseTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJ3ZWVrbHlcIj5XZWVrbHk8L29wdGlvbj5cclxuICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwibW9udGhseVwiPk1vbnRobHk8L29wdGlvbj5cclxuICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItMVwiPlJldGVudGlvbiBQZXJpb2QgKERheXMpPC9sYWJlbD5cclxuICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e2NvbmZpZz8uYmFja3VwPy5yZXRlbnRpb25EYXlzfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlQ29uZmlnKCdiYWNrdXAnLCAncmV0ZW50aW9uRGF5cycsIHBhcnNlSW50KGU/LnRhcmdldD8udmFsdWUpKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1wcmltYXJ5IGZvY3VzOmJvcmRlci1wcmltYXJ5XCJcclxuICAgICAgICAgICAgICBtaW49XCI3XCJcclxuICAgICAgICAgICAgICBtYXg9XCIzNjVcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1lbmRcIj5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVRlc3RCYWNrdXB9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLWJhY2tncm91bmQgdGV4dC10ZXh0LXByaW1hcnkgcHgtNCBweS0yIHJvdW5kZWQtbGcgaG92ZXI6Ymctc3VyZmFjZS1ob3ZlciB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTAgZWFzZS1zbW9vdGggZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgc3BhY2UteC0yIGJvcmRlciBib3JkZXItYm9yZGVyXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJUZXN0VHViZVwiIHNpemU9ezE2fSAvPlxyXG4gICAgICAgICAgICAgIDxzcGFuPlRlc3QgQmFja3VwPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNFwiPlxyXG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMlwiPlxyXG4gICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgIGNoZWNrZWQ9e2NvbmZpZz8uYmFja3VwPy5hdXRvQmFja3VwfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlQ29uZmlnKCdiYWNrdXAnLCAnYXV0b0JhY2t1cCcsIGU/LnRhcmdldD8uY2hlY2tlZCl9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZCBib3JkZXItYm9yZGVyIHRleHQtcHJpbWFyeSBmb2N1czpyaW5nLXByaW1hcnlcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtdGV4dC1wcmltYXJ5XCI+RW5hYmxlIGF1dG9tYXRpYyBiYWNrdXBzPC9zcGFuPlxyXG4gICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIHsvKiBFeHBvcnQgQ29uZmlndXJhdGlvbiBNb2RhbCAqL31cclxuICAgICAge3Nob3dFeHBvcnRNb2RhbCAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotMTIwMCBvdmVyZmxvdy15LWF1dG9cIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbWluLWgtc2NyZWVuIHB4LTRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLWJsYWNrIGJnLW9wYWNpdHktNTBcIiBvbkNsaWNrPXsoKSA9PiBzZXRTaG93RXhwb3J0TW9kYWwoZmFsc2UpfT48L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zdXJmYWNlIHJvdW5kZWQtbGcgc2hhZG93LXhsIG1heC13LW1kIHctZnVsbCByZWxhdGl2ZSB6LTEzMDBcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNlwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtdGV4dC1wcmltYXJ5XCI+RXhwb3J0IENvbmZpZ3VyYXRpb248L2gzPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0V4cG9ydE1vZGFsKGZhbHNlKX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5IGhvdmVyOnRleHQtdGV4dC1wcmltYXJ5IHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiWFwiIHNpemU9ezIwfSAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IG1iLTFcIj5FeHBvcnQgRm9ybWF0PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZXhwb3J0Rm9ybWF0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRFeHBvcnRGb3JtYXQoZT8udGFyZ2V0Py52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1wcmltYXJ5IGZvY3VzOmJvcmRlci1wcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwianNvblwiPkpTT048L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJ0eHRcIj5UZXh0PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgVGhpcyB3aWxsIGRvd25sb2FkIHlvdXIgY3VycmVudCBzeXN0ZW0gY29uZmlndXJhdGlvbiBzZXR0aW5ncy5cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBzcGFjZS14LTMgbXQtNlwiPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0V4cG9ydE1vZGFsKGZhbHNlKX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC10ZXh0LXNlY29uZGFyeSBob3Zlcjp0ZXh0LXRleHQtcHJpbWFyeSB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTBcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRXhwb3J0Q29uZmlnfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXByaW1hcnkgdGV4dC13aGl0ZSBweC00IHB5LTIgcm91bmRlZC1sZyBob3ZlcjpiZy1wcmltYXJ5LTYwMCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTAgZWFzZS1zbW9vdGhcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgRXhwb3J0XHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcbiAgICAgIHsvKiBDb25maWd1cmF0aW9uIFN1bW1hcnkgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYmFja2dyb3VuZCBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLWxnIHAtNFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBzcGFjZS14LTNcIj5cclxuICAgICAgICAgIDxJY29uIG5hbWU9XCJBbGVydENpcmNsZVwiIHNpemU9ezE2fSBjbGFzc05hbWU9XCJ0ZXh0LXByaW1hcnkgbXQtMC41XCIgLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XHJcbiAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSB0ZXh0LXNtXCI+Q29uZmlndXJhdGlvbiBDaGFuZ2VzPC9oND5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC10ZXh0LXNlY29uZGFyeSB0ZXh0LXNtIG10LTFcIj5cclxuICAgICAgICAgICAgICB7aGFzQ2hhbmdlcyA/IChcclxuICAgICAgICAgICAgICAgICdZb3UgaGF2ZSB1bnNhdmVkIGNoYW5nZXMuIENsaWNrIFwiU2F2ZSBDaGFuZ2VzXCIgdG8gYXBwbHkgeW91ciBtb2RpZmljYXRpb25zLidcclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgJ0FsbCBzZXR0aW5ncyBhcmUgc2F2ZWQgYW5kIHVwIHRvIGRhdGUuIENoYW5nZXMgd2lsbCB0YWtlIGVmZmVjdCBpbW1lZGlhdGVseSBhZnRlciBzYXZpbmcuJ1xyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBTeXN0ZW1Db25maWd1cmF0aW9uOyJdLCJmaWxlIjoiRDovY3VycmVudCBwcm9qZWN0cy9jbGF1ZGUtY29kZS9zcmMvcGFnZXMvc2V0dGluZ3MtYWRtaW5pc3RyYXRpb24vY29tcG9uZW50cy9TeXN0ZW1Db25maWd1cmF0aW9uLmpzeCJ9