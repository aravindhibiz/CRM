import {
  require_react
} from "/node_modules/.vite/deps/chunk-XLKA4T3M.js?v=44ab9529";
import "/node_modules/.vite/deps/chunk-WXXH56N5.js?v=44ab9529";
export default require_react();
//# sourceMappingURL=react.js.map
