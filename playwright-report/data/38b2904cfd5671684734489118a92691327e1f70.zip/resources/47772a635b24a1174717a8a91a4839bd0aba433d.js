import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/styles/index.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "D:/current projects/claude-code/src/styles/index.css"
const __vite__css = "body {\r\n  margin: 0;\r\n  padding: 0;\r\n  font-family: Inter;\r\n}\r\n\r\n* {\r\n  box-sizing: border-box;\r\n  line-height: normal;\r\n  font-family: inherit;\r\n  margin: unset;\r\n}\r\n"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))