import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/deal-management/components/ActivityTimeline.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import Icon from "/src/components/AppIcon.jsx";
const ActivityTimeline = ({
  activities = [],
  loading = false,
  contact = null,
  onAddActivity,
  onDeleteActivity
}) => {
  _s();
  const [showAddModal, setShowAddModal] = useState(false);
  const [newActivity, setNewActivity] = useState({
    type: "note",
    title: "",
    description: ""
  });
  const activityTypes = [
    { value: "email", label: "Email", icon: "Mail", color: "text-blue-600" },
    { value: "call", label: "Call", icon: "Phone", color: "text-green-600" },
    { value: "meeting", label: "Meeting", icon: "Calendar", color: "text-purple-600" },
    { value: "note", label: "Note", icon: "FileText", color: "text-gray-600" },
    { value: "task", label: "Task", icon: "CheckSquare", color: "text-orange-600" },
    { value: "demo", label: "Demo", icon: "Play", color: "text-indigo-600" }
  ];
  const getActivityTypeInfo = (type) => {
    return activityTypes?.find((t) => t?.value === type) || activityTypes?.find((t) => t?.value === "note");
  };
  const handleAddActivity = async () => {
    if (!newActivity?.title?.trim())
      return;
    try {
      await onAddActivity?.(newActivity);
      setNewActivity({ type: "note", title: "", description: "" });
      setShowAddModal(false);
    } catch (err) {
      console.error("Error adding activity:", err);
    }
  };
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = /* @__PURE__ */ new Date();
    const diffInHours = (now - date) / (1e3 * 60 * 60);
    if (diffInHours < 24) {
      return `${Math.floor(diffInHours)}h ago`;
    } else if (diffInHours < 24 * 7) {
      return `${Math.floor(diffInHours / 24)}d ago`;
    } else {
      return date?.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        year: date?.getFullYear() !== now?.getFullYear() ? "numeric" : void 0
      });
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:62:4", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "62", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20rounded-lg%20border%20border-border%22%7D", className: "bg-surface rounded-lg border border-border", children: [
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:64:6", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "64", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22p-6%20border-b%20border-border%22%7D", className: "p-6 border-b border-border", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:65:8", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "65", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:66:10", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "66", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%2C%22textContent%22%3A%22Activity%20Timeline%22%7D", className: "text-lg font-semibold text-text-primary", children: "Activity Timeline" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
          lineNumber: 66,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:67:10",
            "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx",
            "data-component-line": "67",
            "data-component-file": "ActivityTimeline.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%20px-3%20py-1%20bg-primary%20text-white%20rounded-lg%20hover%3Abg-primary-600%20transition-colors%20duration-150%20text-sm%22%7D",
            onClick: () => setShowAddModal(true),
            className: "flex items-center space-x-2 px-3 py-1 bg-primary text-white rounded-lg hover:bg-primary-600 transition-colors duration-150 text-sm",
            children: [
              /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:71:12", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "71", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Plus%22%7D", name: "Plus", size: 16 }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
                lineNumber: 71,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:72:12", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "72", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Add%22%7D", children: "Add" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
                lineNumber: 72,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
            lineNumber: 67,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
        lineNumber: 65,
        columnNumber: 9
      }, this),
      contact && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:77:8", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "77", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22mt-2%20text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22Primary%20Contact%3A%22%7D", className: "mt-2 text-sm text-text-secondary", children: [
        "Primary Contact: ",
        contact?.first_name,
        " ",
        contact?.last_name,
        contact?.email && /* @__PURE__ */ jsxDEV(
          "a",
          {
            "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:80:10",
            "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx",
            "data-component-line": "80",
            "data-component-file": "ActivityTimeline.jsx",
            "data-component-name": "a",
            "data-component-content": "%7B%22elementName%22%3A%22a%22%2C%22className%22%3A%22ml-2%20text-primary%20hover%3Atext-primary-600%22%7D",
            href: `mailto:${contact?.email}`,
            className: "ml-2 text-primary hover:text-primary-600",
            children: contact?.email
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
            lineNumber: 80,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
        lineNumber: 77,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
      lineNumber: 64,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:91:6", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "91", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22p-6%22%7D", className: "p-6", children: loading ? /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:93:8", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "93", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-center%20py-8%22%7D", className: "flex items-center justify-center py-8", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:94:12", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "94", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22animate-spin%20rounded-full%20h-6%20w-6%20border-b-2%20border-primary%22%7D", className: "animate-spin rounded-full h-6 w-6 border-b-2 border-primary" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
        lineNumber: 94,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:95:12", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "95", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22ml-2%20text-text-secondary%22%2C%22textContent%22%3A%22Loading%20activities...%22%7D", className: "ml-2 text-text-secondary", children: "Loading activities..." }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
        lineNumber: 95,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
      lineNumber: 93,
      columnNumber: 9
    }, this) : activities?.length === 0 ? /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:98:8", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "98", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-center%20py-8%22%7D", className: "text-center py-8", children: [
      /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:99:12", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "99", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Activity%22%2C%22className%22%3A%22text-text-tertiary%20mx-auto%20mb-2%22%7D", name: "Activity", size: 32, className: "text-text-tertiary mx-auto mb-2" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
        lineNumber: 99,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:100:12", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "100", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%22%2C%22textContent%22%3A%22No%20activities%20yet%22%7D", className: "text-text-secondary", children: "No activities yet" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
        lineNumber: 100,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:101:12", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "101", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%20text-text-tertiary%20mt-1%22%2C%22textContent%22%3A%22Add%20your%20first%20activity%20to%20start%20tracking%22%7D", className: "text-sm text-text-tertiary mt-1", children: "Add your first activity to start tracking" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
        lineNumber: 101,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
      lineNumber: 98,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:104:8", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "104", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-4%22%7D", className: "space-y-4", children: activities?.map((activity, index) => {
      const typeInfo = getActivityTypeInfo(activity?.type);
      return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:109:14", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "109", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20space-x-3%22%7D", className: "flex space-x-3", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:111:18", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "111", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20flex-col%20items-center%22%7D", className: "flex flex-col items-center", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:112:20", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "112", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", className: `w-8 h-8 rounded-full bg-white border-2 flex items-center justify-center ${index === 0 ? "border-primary" : "border-border"}`, children: /* @__PURE__ */ jsxDEV(
            Icon,
            {
              "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:115:22",
              "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx",
              "data-component-line": "115",
              "data-component-file": "ActivityTimeline.jsx",
              "data-component-name": "Icon",
              "data-component-content": "%7B%22elementName%22%3A%22Icon%22%7D",
              name: typeInfo?.icon,
              size: 14,
              className: index === 0 ? "text-primary" : typeInfo?.color
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
              lineNumber: 115,
              columnNumber: 23
            },
            this
          ) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
            lineNumber: 112,
            columnNumber: 21
          }, this),
          index < activities?.length - 1 && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:122:18", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "122", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-0.5%20h-6%20bg-border%20mt-1%22%7D", className: "w-0.5 h-6 bg-border mt-1" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
            lineNumber: 122,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
          lineNumber: 111,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:126:18", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "126", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex-1%20min-w-0%22%7D", className: "flex-1 min-w-0", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:127:20", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "127", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-background%20rounded-lg%20p-4%20border%20border-border%20hover%3Aborder-border-hover%20transition-colors%20duration-150%22%7D", className: "bg-background rounded-lg p-4 border border-border hover:border-border-hover transition-colors duration-150", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:128:22", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "128", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-start%20justify-between%22%7D", className: "flex items-start justify-between", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:129:24", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "129", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex-1%20min-w-0%22%7D", className: "flex-1 min-w-0", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:130:26", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "130", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%20mb-1%22%7D", className: "flex items-center space-x-2 mb-1", children: [
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:131:28", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "131", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22font-medium%20text-text-primary%20text-sm%22%7D", className: "font-medium text-text-primary text-sm", children: activity?.title }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
                lineNumber: 131,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:134:28", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "134", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", className: `px-2 py-0.5 rounded-full text-xs font-medium bg-${typeInfo?.value === "email" ? "blue" : typeInfo?.value === "call" ? "green" : typeInfo?.value === "meeting" ? "purple" : "gray"}-100 text-${typeInfo?.value === "email" ? "blue" : typeInfo?.value === "call" ? "green" : typeInfo?.value === "meeting" ? "purple" : "gray"}-800`, children: typeInfo?.label }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
                lineNumber: 134,
                columnNumber: 29
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
              lineNumber: 130,
              columnNumber: 27
            }, this),
            activity?.description && /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:140:24", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "140", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%20text-text-secondary%20mb-2%20line-clamp-3%22%7D", className: "text-sm text-text-secondary mb-2 line-clamp-3", children: activity?.description }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
              lineNumber: 140,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:145:26", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "145", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20text-xs%20text-text-tertiary%20space-x-2%22%7D", className: "flex items-center text-xs text-text-tertiary space-x-2", children: [
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:146:28", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "146", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: activity?.user }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
                lineNumber: 146,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:147:28", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "147", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22%E2%80%A2%22%7D", children: "•" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
                lineNumber: 147,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:148:28", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "148", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: formatDate(activity?.timestamp) }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
                lineNumber: 148,
                columnNumber: 29
              }, this),
              activity?.duration && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:151:32", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "151", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22%E2%80%A2%22%7D", children: "•" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
                  lineNumber: 151,
                  columnNumber: 33
                }, this),
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:152:32", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "152", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22min%22%7D", children: [
                  activity?.duration,
                  " min"
                ] }, void 0, true, {
                  fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
                  lineNumber: 152,
                  columnNumber: 33
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
                lineNumber: 150,
                columnNumber: 27
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
              lineNumber: 145,
              columnNumber: 27
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
            lineNumber: 129,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:158:24",
              "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx",
              "data-component-line": "158",
              "data-component-file": "ActivityTimeline.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22ml-2%20text-text-tertiary%20hover%3Atext-error%20transition-colors%20duration-150%22%7D",
              onClick: () => onDeleteActivity?.(activity?.id),
              className: "ml-2 text-text-tertiary hover:text-error transition-colors duration-150",
              title: "Delete activity",
              children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:163:26", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "163", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Trash2%22%7D", name: "Trash2", size: 14 }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
                lineNumber: 163,
                columnNumber: 27
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
              lineNumber: 158,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
          lineNumber: 128,
          columnNumber: 23
        }, this) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
          lineNumber: 127,
          columnNumber: 21
        }, this) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
          lineNumber: 126,
          columnNumber: 19
        }, this)
      ] }, activity?.id, true, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
        lineNumber: 109,
        columnNumber: 15
      }, this);
    }) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
      lineNumber: 104,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
      lineNumber: 91,
      columnNumber: 7
    }, this),
    showAddModal && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:176:6", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "176", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20bg-black%20bg-opacity-50%20flex%20items-center%20justify-center%20z-50%22%7D", className: "fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:177:10", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "177", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20rounded-lg%20p-6%20max-w-md%20w-full%20mx-4%22%7D", className: "bg-surface rounded-lg p-6 max-w-md w-full mx-4", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:178:12", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "178", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%20mb-4%22%7D", className: "flex items-center justify-between mb-4", children: [
        /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:179:14", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "179", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%2C%22textContent%22%3A%22Add%20Activity%22%7D", className: "text-lg font-semibold text-text-primary", children: "Add Activity" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
          lineNumber: 179,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:180:14",
            "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx",
            "data-component-line": "180",
            "data-component-file": "ActivityTimeline.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22text-text-tertiary%20hover%3Atext-text-secondary%22%7D",
            onClick: () => setShowAddModal(false),
            className: "text-text-tertiary hover:text-text-secondary",
            children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:184:16", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "184", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22X%22%7D", name: "X", size: 20 }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
              lineNumber: 184,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
            lineNumber: 180,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
        lineNumber: 178,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:188:12", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "188", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-4%22%7D", className: "space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:190:14", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "190", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:191:16", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "191", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-2%22%2C%22textContent%22%3A%22Activity%20Type%22%7D", className: "block text-sm font-medium text-text-primary mb-2", children: "Activity Type" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
            lineNumber: 191,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:194:16",
              "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx",
              "data-component-line": "194",
              "data-component-file": "ActivityTimeline.jsx",
              "data-component-name": "select",
              "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
              value: newActivity?.type,
              onChange: (e) => setNewActivity((prev) => ({ ...prev, type: e?.target?.value })),
              className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
              children: activityTypes?.map(
                (type) => /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:200:16", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "200", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%7D", value: type?.value, children: type?.label }, type?.value, false, {
                  fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
                  lineNumber: 200,
                  columnNumber: 17
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
              lineNumber: 194,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
          lineNumber: 190,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:208:14", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "208", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:209:16", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "209", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-2%22%2C%22textContent%22%3A%22Subject%20*%22%7D", className: "block text-sm font-medium text-text-primary mb-2", children: "Subject *" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
            lineNumber: 209,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:212:16",
              "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx",
              "data-component-line": "212",
              "data-component-file": "ActivityTimeline.jsx",
              "data-component-name": "input",
              "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22text%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
              type: "text",
              value: newActivity?.title,
              onChange: (e) => setNewActivity((prev) => ({ ...prev, title: e?.target?.value })),
              className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
              placeholder: "What happened?",
              required: true
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
              lineNumber: 212,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
          lineNumber: 208,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:223:14", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "223", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:224:16", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "224", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-2%22%2C%22textContent%22%3A%22Description%22%7D", className: "block text-sm font-medium text-text-primary mb-2", children: "Description" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
            lineNumber: 224,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "textarea",
            {
              "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:227:16",
              "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx",
              "data-component-line": "227",
              "data-component-file": "ActivityTimeline.jsx",
              "data-component-name": "textarea",
              "data-component-content": "%7B%22elementName%22%3A%22textarea%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
              value: newActivity?.description,
              onChange: (e) => setNewActivity((prev) => ({ ...prev, description: e?.target?.value })),
              rows: 3,
              className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
              placeholder: "Add details..."
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
              lineNumber: 227,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
          lineNumber: 223,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
        lineNumber: 188,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:237:12", "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx", "data-component-line": "237", "data-component-file": "ActivityTimeline.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20justify-end%20space-x-3%20mt-6%22%7D", className: "flex justify-end space-x-3 mt-6", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:238:14",
            "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx",
            "data-component-line": "238",
            "data-component-file": "ActivityTimeline.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22px-4%20py-2%20text-text-secondary%20hover%3Atext-text-primary%20transition-colors%20duration-150%22%2C%22textContent%22%3A%22Cancel%22%7D",
            onClick: () => setShowAddModal(false),
            className: "px-4 py-2 text-text-secondary hover:text-text-primary transition-colors duration-150",
            children: "Cancel"
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
            lineNumber: 238,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx:244:14",
            "data-component-path": "src\\pages\\deal-management\\components\\ActivityTimeline.jsx",
            "data-component-line": "244",
            "data-component-file": "ActivityTimeline.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22px-4%20py-2%20bg-primary%20text-white%20rounded-lg%20hover%3Abg-primary-600%20disabled%3Aopacity-50%20disabled%3Acursor-not-allowed%20transition-colors%20duration-150%22%2C%22textContent%22%3A%22Add%20Activity%22%7D",
            onClick: handleAddActivity,
            disabled: !newActivity?.title?.trim(),
            className: "px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-150",
            children: "Add Activity"
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
            lineNumber: 244,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
        lineNumber: 237,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
      lineNumber: 177,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
      lineNumber: 176,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx",
    lineNumber: 62,
    columnNumber: 5
  }, this);
};
_s(ActivityTimeline, "XcxAo64zRWIsXcWxfWM0qZ86UzE=");
_c = ActivityTimeline;
export default ActivityTimeline;
var _c;
$RefreshReg$(_c, "ActivityTimeline");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/deal-management/components/ActivityTimeline.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUVVLFNBb0ZvQixVQXBGcEI7MkJBakVWO0FBQWdCQSxNQUFRLGNBQWU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDdkMsT0FBT0MsVUFBVTtBQUVqQixNQUFNQyxtQkFBbUJBLENBQUM7QUFBQSxFQUN4QkMsYUFBYTtBQUFBLEVBQ2JDLFVBQVU7QUFBQSxFQUNWQyxVQUFVO0FBQUEsRUFDVkM7QUFBQUEsRUFDQUM7QUFDRixNQUFNO0FBQUFDLEtBQUE7QUFDSixRQUFNLENBQUNDLGNBQWNDLGVBQWUsSUFBSVYsU0FBUyxLQUFLO0FBQ3RELFFBQU0sQ0FBQ1csYUFBYUMsY0FBYyxJQUFJWixTQUFTO0FBQUEsSUFDN0NhLE1BQU07QUFBQSxJQUNOQyxPQUFPO0FBQUEsSUFDUEMsYUFBYTtBQUFBLEVBQ2YsQ0FBQztBQUVELFFBQU1DLGdCQUFnQjtBQUFBLElBQ3BCLEVBQUVDLE9BQU8sU0FBU0MsT0FBTyxTQUFTQyxNQUFNLFFBQVFDLE9BQU8sZ0JBQWdCO0FBQUEsSUFDdkUsRUFBRUgsT0FBTyxRQUFRQyxPQUFPLFFBQVFDLE1BQU0sU0FBU0MsT0FBTyxpQkFBaUI7QUFBQSxJQUN2RSxFQUFFSCxPQUFPLFdBQVdDLE9BQU8sV0FBV0MsTUFBTSxZQUFZQyxPQUFPLGtCQUFrQjtBQUFBLElBQ2pGLEVBQUVILE9BQU8sUUFBUUMsT0FBTyxRQUFRQyxNQUFNLFlBQVlDLE9BQU8sZ0JBQWdCO0FBQUEsSUFDekUsRUFBRUgsT0FBTyxRQUFRQyxPQUFPLFFBQVFDLE1BQU0sZUFBZUMsT0FBTyxrQkFBa0I7QUFBQSxJQUM5RSxFQUFFSCxPQUFPLFFBQVFDLE9BQU8sUUFBUUMsTUFBTSxRQUFRQyxPQUFPLGtCQUFrQjtBQUFBLEVBQUM7QUFHMUUsUUFBTUMsc0JBQXNCQSxDQUFDUixTQUFTO0FBQ3BDLFdBQU9HLGVBQWVNLEtBQUssQ0FBQUMsTUFBS0EsR0FBR04sVUFBVUosSUFBSSxLQUFLRyxlQUFlTSxLQUFLLENBQUFDLE1BQUtBLEdBQUdOLFVBQVUsTUFBTTtBQUFBLEVBQ3BHO0FBRUEsUUFBTU8sb0JBQW9CLFlBQVk7QUFDcEMsUUFBSSxDQUFDYixhQUFhRyxPQUFPVyxLQUFLO0FBQUc7QUFFakMsUUFBSTtBQUNGLFlBQU1uQixnQkFBZ0JLLFdBQVc7QUFDakNDLHFCQUFlLEVBQUVDLE1BQU0sUUFBUUMsT0FBTyxJQUFJQyxhQUFhLEdBQUcsQ0FBQztBQUMzREwsc0JBQWdCLEtBQUs7QUFBQSxJQUN2QixTQUFTZ0IsS0FBSztBQUNaQyxjQUFRQyxNQUFNLDBCQUEwQkYsR0FBRztBQUFBLElBQzdDO0FBQUEsRUFDRjtBQUVBLFFBQU1HLGFBQWFBLENBQUNDLGVBQWU7QUFDakMsVUFBTUMsT0FBTyxJQUFJQyxLQUFLRixVQUFVO0FBQ2hDLFVBQU1HLE1BQU0sb0JBQUlELEtBQUs7QUFDckIsVUFBTUUsZUFBZUQsTUFBTUYsU0FBUyxNQUFPLEtBQUs7QUFFaEQsUUFBSUcsY0FBYyxJQUFJO0FBQ3BCLGFBQU8sR0FBR0MsS0FBS0MsTUFBTUYsV0FBVyxDQUFDO0FBQUEsSUFDbkMsV0FBV0EsY0FBYyxLQUFLLEdBQUc7QUFDL0IsYUFBTyxHQUFHQyxLQUFLQyxNQUFNRixjQUFjLEVBQUUsQ0FBQztBQUFBLElBQ3hDLE9BQU87QUFDTCxhQUFPSCxNQUFNTSxtQkFBbUIsU0FBUztBQUFBLFFBQ3ZDQyxPQUFPO0FBQUEsUUFDUEMsS0FBSztBQUFBLFFBQ0xDLE1BQU1ULE1BQU1VLFlBQVksTUFBTVIsS0FBS1EsWUFBWSxJQUFJLFlBQVlDO0FBQUFBLE1BQ2pFLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUVBLFNBQ0UsdUJBQUMsa2JBQUksV0FBVSw4Q0FFYjtBQUFBLDJCQUFDLGdhQUFJLFdBQVUsOEJBQ2I7QUFBQSw2QkFBQyx1YUFBSSxXQUFVLHFDQUNiO0FBQUEsK0JBQUMsMmRBQUcsV0FBVSwyQ0FBMEMsaUNBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUU7QUFBQSxRQUN6RTtBQUFBLFVBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNaEMsZ0JBQWdCLElBQUk7QUFBQSxZQUNuQyxXQUFVO0FBQUEsWUFFVjtBQUFBLHFDQUFDLG1ZQUFLLE1BQUssUUFBTyxNQUFNLE1BQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJCO0FBQUEsY0FDM0IsdUJBQUMsMllBQUssbUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBUztBQUFBO0FBQUE7QUFBQSxVQUxYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsV0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUVDTCxXQUNDLHVCQUFDLHVkQUFJLFdBQVUsb0NBQW1DO0FBQUE7QUFBQSxRQUM5QkEsU0FBU3NDO0FBQUFBLFFBQVc7QUFBQSxRQUFFdEMsU0FBU3VDO0FBQUFBLFFBQ2hEdkMsU0FBU3dDLFNBQ1I7QUFBQSxVQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUNDLE1BQU0sVUFBVXhDLFNBQVN3QyxLQUFLO0FBQUEsWUFDOUIsV0FBVTtBQUFBLFlBRVR4QyxtQkFBU3dDO0FBQUFBO0FBQUFBLFVBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxXQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLFNBdkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5QkE7QUFBQSxJQUVBLHVCQUFDLHFZQUFJLFdBQVUsT0FDWnpDLG9CQUNDLHVCQUFDLDZhQUFJLFdBQVUseUNBQ2I7QUFBQSw2QkFBQyx3Y0FBSSxXQUFVLGlFQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkU7QUFBQSxNQUM3RSx1QkFBQyxvZEFBSyxXQUFVLDRCQUEyQixxQ0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnRTtBQUFBLFNBRmxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQSxJQUNFRCxZQUFZMkMsV0FBVyxJQUN6Qix1QkFBQyxvWkFBSSxXQUFVLG9CQUNiO0FBQUEsNkJBQUMscWNBQUssTUFBSyxZQUFXLE1BQU0sSUFBSSxXQUFVLHFDQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJFO0FBQUEsTUFDM0UsdUJBQUMsb2NBQUUsV0FBVSx1QkFBc0IsaUNBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0Q7QUFBQSxNQUNwRCx1QkFBQyxvZkFBRSxXQUFVLG1DQUFrQyx5REFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3RjtBQUFBLFNBSDFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQSxJQUVBLHVCQUFDLDZZQUFJLFdBQVUsYUFDWjNDLHNCQUFZNEMsSUFBSSxDQUFDQyxVQUFVQyxVQUFVO0FBQ3BDLFlBQU1DLFdBQVc3QixvQkFBb0IyQixVQUFVbkMsSUFBSTtBQUVuRCxhQUNFLHVCQUFDLHFaQUF1QixXQUFVLGtCQUVoQztBQUFBLCtCQUFDLG1hQUFJLFdBQVUsOEJBQ2I7QUFBQSxpQ0FBQywwV0FBSSxXQUFXLDJFQUNkb0MsVUFBVSxJQUFJLG1CQUFtQixlQUFlLElBRWhEO0FBQUEsWUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FDQyxNQUFNQyxVQUFVL0I7QUFBQUEsY0FDaEIsTUFBTTtBQUFBLGNBQ04sV0FBVzhCLFVBQVUsSUFBSSxpQkFBaUJDLFVBQVU5QjtBQUFBQTtBQUFBQSxZQUh0RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFHNEQsS0FOOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFVBQ0M2QixRQUFROUMsWUFBWTJDLFNBQVMsS0FDNUIsdUJBQUMsbWFBQUksV0FBVSw4QkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwQztBQUFBLGFBWDlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLFFBRUEsdUJBQUMscVpBQUksV0FBVSxrQkFDYixpQ0FBQywrZkFBSSxXQUFVLDhHQUNiLGlDQUFDLHlhQUFJLFdBQVUsb0NBQ2I7QUFBQSxpQ0FBQyxxWkFBSSxXQUFVLGtCQUNiO0FBQUEsbUNBQUMsMmFBQUksV0FBVSxvQ0FDYjtBQUFBLHFDQUFDLGliQUFLLFdBQVUseUNBQ2JFLG9CQUFVbEMsU0FEYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyw2V0FBSyxXQUFXLG1EQUFtRG9DLFVBQVVqQyxVQUFVLFVBQVUsU0FBU2lDLFVBQVVqQyxVQUFVLFNBQVMsVUFBVWlDLFVBQVVqQyxVQUFVLFlBQVksV0FBVyxNQUFNLGFBQWFpQyxVQUFVakMsVUFBVSxVQUFVLFNBQVNpQyxVQUFVakMsVUFBVSxTQUFTLFVBQVVpQyxVQUFVakMsVUFBVSxZQUFZLFdBQVcsTUFBTSxRQUM1VWlDLG9CQUFVaEMsU0FEYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBRUM4QixVQUFVakMsZUFDVCx1QkFBQyxrYkFBRSxXQUFVLGlEQUNWaUMsb0JBQVVqQyxlQURiO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUdGLHVCQUFDLG1jQUFJLFdBQVUsMERBQ2I7QUFBQSxxQ0FBQyw2V0FBTWlDLG9CQUFVRyxRQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzQjtBQUFBLGNBQ3RCLHVCQUFDLG1aQUFLLGlCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQU87QUFBQSxjQUNQLHVCQUFDLDZXQUFNdEIscUJBQVdtQixVQUFVSSxTQUFTLEtBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVDO0FBQUEsY0FDdENKLFVBQVVLLFlBQ1QsbUNBQ0U7QUFBQSx1Q0FBQyxtWkFBSyxpQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFPO0FBQUEsZ0JBQ1AsdUJBQUMsNllBQU1MO0FBQUFBLDRCQUFVSztBQUFBQSxrQkFBUztBQUFBLHFCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE4QjtBQUFBLG1CQUZoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsaUJBUko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLGVBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMkJBO0FBQUEsVUFFQTtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNOUMsbUJBQW1CeUMsVUFBVU0sRUFBRTtBQUFBLGNBQzlDLFdBQVU7QUFBQSxjQUNWLE9BQU07QUFBQSxjQUVOLGlDQUFDLHVZQUFLLE1BQUssVUFBUyxNQUFNLE1BQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZCO0FBQUE7QUFBQSxZQUwvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLGFBcENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFxQ0EsS0F0Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXVDQSxLQXhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBeUNBO0FBQUEsV0ExRFFOLFVBQVVNLElBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyREE7QUFBQSxJQUVKLENBQUMsS0FsRUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1FQSxLQWhGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0ZBO0FBQUEsSUFFQzdDLGdCQUNDLHVCQUFDLDRkQUFJLFdBQVUsOEVBQ2IsaUNBQUMsNmJBQUksV0FBVSxrREFDYjtBQUFBLDZCQUFDLGliQUFJLFdBQVUsMENBQ2I7QUFBQSwrQkFBQyx3ZEFBRyxXQUFVLDJDQUEwQyw0QkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRTtBQUFBLFFBQ3BFO0FBQUEsVUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU1DLGdCQUFnQixLQUFLO0FBQUEsWUFDcEMsV0FBVTtBQUFBLFlBRVYsaUNBQUMsa1lBQUssTUFBSyxLQUFJLE1BQU0sTUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0I7QUFBQTtBQUFBLFVBSjFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsV0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxNQUVBLHVCQUFDLDhZQUFJLFdBQVUsYUFFYjtBQUFBLCtCQUFDLDBXQUNDO0FBQUEsaUNBQUMsK2VBQU0sV0FBVSxvREFBbUQsNkJBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FDQyxPQUFPQyxhQUFhRTtBQUFBQSxjQUNwQixVQUFVLENBQUMwQyxNQUFNM0MsZUFBZSxDQUFBNEMsVUFBUyxFQUFFLEdBQUdBLE1BQU0zQyxNQUFNMEMsR0FBR0UsUUFBUXhDLE1BQU0sRUFBRTtBQUFBLGNBQzdFLFdBQVU7QUFBQSxjQUVURCx5QkFBZStCO0FBQUFBLGdCQUFJLENBQUFsQyxTQUNsQix1QkFBQyxtWEFBeUIsT0FBT0EsTUFBTUksT0FDcENKLGdCQUFNSyxTQURJTCxNQUFNSSxPQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsY0FDRDtBQUFBO0FBQUEsWUFUSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFVQTtBQUFBLGFBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWVBO0FBQUEsUUFHQSx1QkFBQywwV0FDQztBQUFBLGlDQUFDLDJlQUFNLFdBQVUsb0RBQW1ELHlCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsT0FBT04sYUFBYUc7QUFBQUEsY0FDcEIsVUFBVSxDQUFDeUMsTUFBTTNDLGVBQWUsQ0FBQTRDLFVBQVMsRUFBRSxHQUFHQSxNQUFNMUMsT0FBT3lDLEdBQUdFLFFBQVF4QyxNQUFNLEVBQUU7QUFBQSxjQUM5RSxXQUFVO0FBQUEsY0FDVixhQUFZO0FBQUEsY0FDWixVQUFRO0FBQUE7QUFBQSxZQU5WO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1VO0FBQUEsYUFWWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxRQUdBLHVCQUFDLDBXQUNDO0FBQUEsaUNBQUMsMmVBQU0sV0FBVSxvREFBbUQsMkJBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FDQyxPQUFPTixhQUFhSTtBQUFBQSxjQUNwQixVQUFVLENBQUN3QyxNQUFNM0MsZUFBZSxDQUFBNEMsVUFBUyxFQUFFLEdBQUdBLE1BQU16QyxhQUFhd0MsR0FBR0UsUUFBUXhDLE1BQU0sRUFBRTtBQUFBLGNBQ3BGLE1BQU07QUFBQSxjQUNOLFdBQVU7QUFBQSxjQUNWLGFBQVk7QUFBQTtBQUFBLFlBTGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSzhCO0FBQUEsYUFUaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsV0E5Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQStDQTtBQUFBLE1BRUEsdUJBQUMsMGFBQUksV0FBVSxtQ0FDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU1QLGdCQUFnQixLQUFLO0FBQUEsWUFDcEMsV0FBVTtBQUFBLFlBQXNGO0FBQUE7QUFBQSxVQUZsRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUNDLFNBQVNjO0FBQUFBLFlBQ1QsVUFBVSxDQUFDYixhQUFhRyxPQUFPVyxLQUFLO0FBQUEsWUFDcEMsV0FBVTtBQUFBLFlBQWdKO0FBQUE7QUFBQSxVQUg1SjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFdBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWNBO0FBQUEsU0ExRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJFQSxLQTVFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNkVBO0FBQUEsT0EvTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlNQTtBQUVKO0FBQUVqQixHQTdQSU4sa0JBQWdCO0FBQUF3RCxLQUFoQnhEO0FBK1BOLGVBQWVBO0FBQWlCLElBQUF3RDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJJY29uIiwiQWN0aXZpdHlUaW1lbGluZSIsImFjdGl2aXRpZXMiLCJsb2FkaW5nIiwiY29udGFjdCIsIm9uQWRkQWN0aXZpdHkiLCJvbkRlbGV0ZUFjdGl2aXR5IiwiX3MiLCJzaG93QWRkTW9kYWwiLCJzZXRTaG93QWRkTW9kYWwiLCJuZXdBY3Rpdml0eSIsInNldE5ld0FjdGl2aXR5IiwidHlwZSIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJhY3Rpdml0eVR5cGVzIiwidmFsdWUiLCJsYWJlbCIsImljb24iLCJjb2xvciIsImdldEFjdGl2aXR5VHlwZUluZm8iLCJmaW5kIiwidCIsImhhbmRsZUFkZEFjdGl2aXR5IiwidHJpbSIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsImZvcm1hdERhdGUiLCJkYXRlU3RyaW5nIiwiZGF0ZSIsIkRhdGUiLCJub3ciLCJkaWZmSW5Ib3VycyIsIk1hdGgiLCJmbG9vciIsInRvTG9jYWxlRGF0ZVN0cmluZyIsIm1vbnRoIiwiZGF5IiwieWVhciIsImdldEZ1bGxZZWFyIiwidW5kZWZpbmVkIiwiZmlyc3RfbmFtZSIsImxhc3RfbmFtZSIsImVtYWlsIiwibGVuZ3RoIiwibWFwIiwiYWN0aXZpdHkiLCJpbmRleCIsInR5cGVJbmZvIiwidXNlciIsInRpbWVzdGFtcCIsImR1cmF0aW9uIiwiaWQiLCJlIiwicHJldiIsInRhcmdldCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQWN0aXZpdHlUaW1lbGluZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgSWNvbiBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL0FwcEljb24nO1xyXG5cclxuY29uc3QgQWN0aXZpdHlUaW1lbGluZSA9ICh7IFxyXG4gIGFjdGl2aXRpZXMgPSBbXSwgXHJcbiAgbG9hZGluZyA9IGZhbHNlLCBcclxuICBjb250YWN0ID0gbnVsbCwgXHJcbiAgb25BZGRBY3Rpdml0eSwgXHJcbiAgb25EZWxldGVBY3Rpdml0eSBcclxufSkgPT4ge1xyXG4gIGNvbnN0IFtzaG93QWRkTW9kYWwsIHNldFNob3dBZGRNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW25ld0FjdGl2aXR5LCBzZXROZXdBY3Rpdml0eV0gPSB1c2VTdGF0ZSh7XHJcbiAgICB0eXBlOiAnbm90ZScsXHJcbiAgICB0aXRsZTogJycsXHJcbiAgICBkZXNjcmlwdGlvbjogJydcclxuICB9KTtcclxuXHJcbiAgY29uc3QgYWN0aXZpdHlUeXBlcyA9IFtcclxuICAgIHsgdmFsdWU6ICdlbWFpbCcsIGxhYmVsOiAnRW1haWwnLCBpY29uOiAnTWFpbCcsIGNvbG9yOiAndGV4dC1ibHVlLTYwMCcgfSxcclxuICAgIHsgdmFsdWU6ICdjYWxsJywgbGFiZWw6ICdDYWxsJywgaWNvbjogJ1Bob25lJywgY29sb3I6ICd0ZXh0LWdyZWVuLTYwMCcgfSxcclxuICAgIHsgdmFsdWU6ICdtZWV0aW5nJywgbGFiZWw6ICdNZWV0aW5nJywgaWNvbjogJ0NhbGVuZGFyJywgY29sb3I6ICd0ZXh0LXB1cnBsZS02MDAnIH0sXHJcbiAgICB7IHZhbHVlOiAnbm90ZScsIGxhYmVsOiAnTm90ZScsIGljb246ICdGaWxlVGV4dCcsIGNvbG9yOiAndGV4dC1ncmF5LTYwMCcgfSxcclxuICAgIHsgdmFsdWU6ICd0YXNrJywgbGFiZWw6ICdUYXNrJywgaWNvbjogJ0NoZWNrU3F1YXJlJywgY29sb3I6ICd0ZXh0LW9yYW5nZS02MDAnIH0sXHJcbiAgICB7IHZhbHVlOiAnZGVtbycsIGxhYmVsOiAnRGVtbycsIGljb246ICdQbGF5JywgY29sb3I6ICd0ZXh0LWluZGlnby02MDAnIH1cclxuICBdO1xyXG5cclxuICBjb25zdCBnZXRBY3Rpdml0eVR5cGVJbmZvID0gKHR5cGUpID0+IHtcclxuICAgIHJldHVybiBhY3Rpdml0eVR5cGVzPy5maW5kKHQgPT4gdD8udmFsdWUgPT09IHR5cGUpIHx8IGFjdGl2aXR5VHlwZXM/LmZpbmQodCA9PiB0Py52YWx1ZSA9PT0gJ25vdGUnKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVBZGRBY3Rpdml0eSA9IGFzeW5jICgpID0+IHtcclxuICAgIGlmICghbmV3QWN0aXZpdHk/LnRpdGxlPy50cmltKCkpIHJldHVybjtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBvbkFkZEFjdGl2aXR5Py4obmV3QWN0aXZpdHkpO1xyXG4gICAgICBzZXROZXdBY3Rpdml0eSh7IHR5cGU6ICdub3RlJywgdGl0bGU6ICcnLCBkZXNjcmlwdGlvbjogJycgfSk7XHJcbiAgICAgIHNldFNob3dBZGRNb2RhbChmYWxzZSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgYWRkaW5nIGFjdGl2aXR5OicsIGVycik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZm9ybWF0RGF0ZSA9IChkYXRlU3RyaW5nKSA9PiB7XHJcbiAgICBjb25zdCBkYXRlID0gbmV3IERhdGUoZGF0ZVN0cmluZyk7XHJcbiAgICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpO1xyXG4gICAgY29uc3QgZGlmZkluSG91cnMgPSAobm93IC0gZGF0ZSkgLyAoMTAwMCAqIDYwICogNjApO1xyXG4gICAgXHJcbiAgICBpZiAoZGlmZkluSG91cnMgPCAyNCkge1xyXG4gICAgICByZXR1cm4gYCR7TWF0aC5mbG9vcihkaWZmSW5Ib3Vycyl9aCBhZ29gO1xyXG4gICAgfSBlbHNlIGlmIChkaWZmSW5Ib3VycyA8IDI0ICogNykge1xyXG4gICAgICByZXR1cm4gYCR7TWF0aC5mbG9vcihkaWZmSW5Ib3VycyAvIDI0KX1kIGFnb2A7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4gZGF0ZT8udG9Mb2NhbGVEYXRlU3RyaW5nKCdlbi1VUycsIHsgXHJcbiAgICAgICAgbW9udGg6ICdzaG9ydCcsIFxyXG4gICAgICAgIGRheTogJ251bWVyaWMnLFxyXG4gICAgICAgIHllYXI6IGRhdGU/LmdldEZ1bGxZZWFyKCkgIT09IG5vdz8uZ2V0RnVsbFllYXIoKSA/ICdudW1lcmljJyA6IHVuZGVmaW5lZFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zdXJmYWNlIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ib3JkZXJcIj5cclxuICAgICAgey8qIEhlYWRlciAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgYm9yZGVyLWIgYm9yZGVyLWJvcmRlclwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtdGV4dC1wcmltYXJ5XCI+QWN0aXZpdHkgVGltZWxpbmU8L2gzPlxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93QWRkTW9kYWwodHJ1ZSl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMiBweC0zIHB5LTEgYmctcHJpbWFyeSB0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgaG92ZXI6YmctcHJpbWFyeS02MDAgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwIHRleHQtc21cIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8SWNvbiBuYW1lPVwiUGx1c1wiIHNpemU9ezE2fSAvPlxyXG4gICAgICAgICAgICA8c3Bhbj5BZGQ8L3NwYW4+XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICBcclxuICAgICAgICB7Y29udGFjdCAmJiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+XHJcbiAgICAgICAgICAgIFByaW1hcnkgQ29udGFjdDoge2NvbnRhY3Q/LmZpcnN0X25hbWV9IHtjb250YWN0Py5sYXN0X25hbWV9XHJcbiAgICAgICAgICAgIHtjb250YWN0Py5lbWFpbCAmJiAoXHJcbiAgICAgICAgICAgICAgPGEgXHJcbiAgICAgICAgICAgICAgICBocmVmPXtgbWFpbHRvOiR7Y29udGFjdD8uZW1haWx9YH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1sLTIgdGV4dC1wcmltYXJ5IGhvdmVyOnRleHQtcHJpbWFyeS02MDBcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtjb250YWN0Py5lbWFpbH1cclxuICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgey8qIEFjdGl2aXRpZXMgTGlzdCAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTZcIj5cclxuICAgICAgICB7bG9hZGluZyA/IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcHktOFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFuaW1hdGUtc3BpbiByb3VuZGVkLWZ1bGwgaC02IHctNiBib3JkZXItYi0yIGJvcmRlci1wcmltYXJ5XCI+PC9kaXY+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTIgdGV4dC10ZXh0LXNlY29uZGFyeVwiPkxvYWRpbmcgYWN0aXZpdGllcy4uLjwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkgOiBhY3Rpdml0aWVzPy5sZW5ndGggPT09IDAgPyAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LThcIj5cclxuICAgICAgICAgICAgPEljb24gbmFtZT1cIkFjdGl2aXR5XCIgc2l6ZT17MzJ9IGNsYXNzTmFtZT1cInRleHQtdGV4dC10ZXJ0aWFyeSBteC1hdXRvIG1iLTJcIiAvPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+Tm8gYWN0aXZpdGllcyB5ZXQ8L3A+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC10ZXh0LXRlcnRpYXJ5IG10LTFcIj5BZGQgeW91ciBmaXJzdCBhY3Rpdml0eSB0byBzdGFydCB0cmFja2luZzwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkgOiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgICB7YWN0aXZpdGllcz8ubWFwKChhY3Rpdml0eSwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgICBjb25zdCB0eXBlSW5mbyA9IGdldEFjdGl2aXR5VHlwZUluZm8oYWN0aXZpdHk/LnR5cGUpO1xyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17YWN0aXZpdHk/LmlkfSBjbGFzc05hbWU9XCJmbGV4IHNwYWNlLXgtM1wiPlxyXG4gICAgICAgICAgICAgICAgICB7LyogVGltZWxpbmUgbGluZSAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgdy04IGgtOCByb3VuZGVkLWZ1bGwgYmctd2hpdGUgYm9yZGVyLTIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgJHtcclxuICAgICAgICAgICAgICAgICAgICAgIGluZGV4ID09PSAwID8gJ2JvcmRlci1wcmltYXJ5JyA6ICdib3JkZXItYm9yZGVyJ1xyXG4gICAgICAgICAgICAgICAgICAgIH1gfT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJY29uIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lPXt0eXBlSW5mbz8uaWNvbn0gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9ezE0fSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtpbmRleCA9PT0gMCA/ICd0ZXh0LXByaW1hcnknIDogdHlwZUluZm8/LmNvbG9yfVxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICB7aW5kZXggPCBhY3Rpdml0aWVzPy5sZW5ndGggLSAxICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0wLjUgaC02IGJnLWJvcmRlciBtdC0xXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIHsvKiBBY3Rpdml0eSBjb250ZW50ICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1iYWNrZ3JvdW5kIHJvdW5kZWQtbGcgcC00IGJvcmRlciBib3JkZXItYm9yZGVyIGhvdmVyOmJvcmRlci1ib3JkZXItaG92ZXIgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMiBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthY3Rpdml0eT8udGl0bGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC14cyBmb250LW1lZGl1bSBiZy0ke3R5cGVJbmZvPy52YWx1ZSA9PT0gJ2VtYWlsJyA/ICdibHVlJyA6IHR5cGVJbmZvPy52YWx1ZSA9PT0gJ2NhbGwnID8gJ2dyZWVuJyA6IHR5cGVJbmZvPy52YWx1ZSA9PT0gJ21lZXRpbmcnID8gJ3B1cnBsZScgOiAnZ3JheSd9LTEwMCB0ZXh0LSR7dHlwZUluZm8/LnZhbHVlID09PSAnZW1haWwnID8gJ2JsdWUnIDogdHlwZUluZm8/LnZhbHVlID09PSAnY2FsbCcgPyAnZ3JlZW4nIDogdHlwZUluZm8/LnZhbHVlID09PSAnbWVldGluZycgPyAncHVycGxlJyA6ICdncmF5J30tODAwYH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0eXBlSW5mbz8ubGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2FjdGl2aXR5Py5kZXNjcmlwdGlvbiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtdGV4dC1zZWNvbmRhcnkgbWItMiBsaW5lLWNsYW1wLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2FjdGl2aXR5Py5kZXNjcmlwdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgdGV4dC14cyB0ZXh0LXRleHQtdGVydGlhcnkgc3BhY2UteC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57YWN0aXZpdHk/LnVzZXJ9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+4oCiPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2Zvcm1hdERhdGUoYWN0aXZpdHk/LnRpbWVzdGFtcCl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2FjdGl2aXR5Py5kdXJhdGlvbiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+4oCiPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnthY3Rpdml0eT8uZHVyYXRpb259IG1pbjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbkRlbGV0ZUFjdGl2aXR5Py4oYWN0aXZpdHk/LmlkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtbC0yIHRleHQtdGV4dC10ZXJ0aWFyeSBob3Zlcjp0ZXh0LWVycm9yIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJEZWxldGUgYWN0aXZpdHlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIlRyYXNoMlwiIHNpemU9ezE0fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIHsvKiBBZGQgQWN0aXZpdHkgTW9kYWwgKi99XHJcbiAgICAgIHtzaG93QWRkTW9kYWwgJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBiZy1ibGFjayBiZy1vcGFjaXR5LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHotNTBcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc3VyZmFjZSByb3VuZGVkLWxnIHAtNiBtYXgtdy1tZCB3LWZ1bGwgbXgtNFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi00XCI+XHJcbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXRleHQtcHJpbWFyeVwiPkFkZCBBY3Rpdml0eTwvaDM+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0FkZE1vZGFsKGZhbHNlKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtdGV4dC10ZXJ0aWFyeSBob3Zlcjp0ZXh0LXRleHQtc2Vjb25kYXJ5XCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiWFwiIHNpemU9ezIwfSAvPlxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgICAgey8qIEFjdGl2aXR5IFR5cGUgKi99XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgQWN0aXZpdHkgVHlwZVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e25ld0FjdGl2aXR5Py50eXBlfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5ld0FjdGl2aXR5KHByZXYgPT4gKHsgLi4ucHJldiwgdHlwZTogZT8udGFyZ2V0Py52YWx1ZSB9KSl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ib3JkZXIgcm91bmRlZC1sZyBmb2N1czpyaW5nLXByaW1hcnkgZm9jdXM6Ym9yZGVyLXByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7YWN0aXZpdHlUeXBlcz8ubWFwKHR5cGUgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXt0eXBlPy52YWx1ZX0gdmFsdWU9e3R5cGU/LnZhbHVlfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHt0eXBlPy5sYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIFRpdGxlICovfVxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIFN1YmplY3QgKlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtuZXdBY3Rpdml0eT8udGl0bGV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TmV3QWN0aXZpdHkocHJldiA9PiAoeyAuLi5wcmV2LCB0aXRsZTogZT8udGFyZ2V0Py52YWx1ZSB9KSl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ib3JkZXIgcm91bmRlZC1sZyBmb2N1czpyaW5nLXByaW1hcnkgZm9jdXM6Ym9yZGVyLXByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIldoYXQgaGFwcGVuZWQ/XCJcclxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBEZXNjcmlwdGlvbiAqL31cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICBEZXNjcmlwdGlvblxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17bmV3QWN0aXZpdHk/LmRlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5ld0FjdGl2aXR5KHByZXYgPT4gKHsgLi4ucHJldiwgZGVzY3JpcHRpb246IGU/LnRhcmdldD8udmFsdWUgfSkpfVxyXG4gICAgICAgICAgICAgICAgICByb3dzPXszfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1wcmltYXJ5IGZvY3VzOmJvcmRlci1wcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJBZGQgZGV0YWlscy4uLlwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBzcGFjZS14LTMgbXQtNlwiPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dBZGRNb2RhbChmYWxzZSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC10ZXh0LXNlY29uZGFyeSBob3Zlcjp0ZXh0LXRleHQtcHJpbWFyeSB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTBcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUFkZEFjdGl2aXR5fVxyXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFuZXdBY3Rpdml0eT8udGl0bGU/LnRyaW0oKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBiZy1wcmltYXJ5IHRleHQtd2hpdGUgcm91bmRlZC1sZyBob3ZlcjpiZy1wcmltYXJ5LTYwMCBkaXNhYmxlZDpvcGFjaXR5LTUwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTBcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIEFkZCBBY3Rpdml0eVxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEFjdGl2aXR5VGltZWxpbmU7Il0sImZpbGUiOiJEOi9jdXJyZW50IHByb2plY3RzL2NsYXVkZS1jb2RlL3NyYy9wYWdlcy9kZWFsLW1hbmFnZW1lbnQvY29tcG9uZW50cy9BY3Rpdml0eVRpbWVsaW5lLmpzeCJ9