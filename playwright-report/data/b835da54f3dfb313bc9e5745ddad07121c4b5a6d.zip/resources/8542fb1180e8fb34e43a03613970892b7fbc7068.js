import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/contact-management/components/ContactList.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/contact-management/components/ContactList.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { formatDistanceToNow } from "/node_modules/.vite/deps/date-fns.js?v=44ab9529";
import Icon from "/src/components/AppIcon.jsx";
import Image from "/src/components/AppImage.jsx";
const ContactList = ({
  contacts,
  selectedContact,
  selectedContacts,
  onContactSelect,
  onContactMultiSelect,
  onDeleteContact
}) => {
  const formatDate = (dateString) => {
    if (!dateString)
      return "Never contacted";
    try {
      const date = new Date(dateString);
      return formatDistanceToNow(date, { addSuffix: true });
    } catch (error) {
      return "Invalid date";
    }
  };
  if (contacts?.length === 0) {
    return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactList.jsx:26:6", "data-component-path": "src\\pages\\contact-management\\components\\ContactList.jsx", "data-component-line": "26", "data-component-file": "ContactList.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22p-6%20text-center%22%7D", className: "p-6 text-center", children: /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\contact-management\\components\\ContactList.jsx:27:8", "data-component-path": "src\\pages\\contact-management\\components\\ContactList.jsx", "data-component-line": "27", "data-component-file": "ContactList.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%22%2C%22textContent%22%3A%22No%20contacts%20found%22%7D", className: "text-text-secondary", children: "No contacts found" }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactList.jsx",
      lineNumber: 27,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactList.jsx",
      lineNumber: 26,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactList.jsx:33:4", "data-component-path": "src\\pages\\contact-management\\components\\ContactList.jsx", "data-component-line": "33", "data-component-file": "ContactList.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22overflow-y-auto%20max-h-%5Bcalc(100vh-220px)%5D%22%7D", className: "overflow-y-auto max-h-[calc(100vh-220px)]", children: contacts?.map(
    (contact) => /* @__PURE__ */ jsxDEV(
      "div",
      {
        "data-component-id": "src\\pages\\contact-management\\components\\ContactList.jsx:35:6",
        "data-component-path": "src\\pages\\contact-management\\components\\ContactList.jsx",
        "data-component-line": "35",
        "data-component-file": "ContactList.jsx",
        "data-component-name": "div",
        "data-component-content": "%7B%22elementName%22%3A%22div%22%7D",
        className: `border-b border-border last:border-b-0 p-4 cursor-pointer transition-colors duration-150 ease-out ${selectedContact && selectedContact?.id === contact?.id ? "bg-primary-50" : "hover:bg-surface-hover"}`,
        onClick: () => {
          console.log("Contact clicked:", contact);
          onContactSelect?.(contact);
        },
        children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactList.jsx:46:10", "data-component-path": "src\\pages\\contact-management\\components\\ContactList.jsx", "data-component-line": "46", "data-component-file": "ContactList.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%22%7D", className: "flex items-center", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactList.jsx:47:12", "data-component-path": "src\\pages\\contact-management\\components\\ContactList.jsx", "data-component-line": "47", "data-component-file": "ContactList.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex-shrink-0%20mr-3%22%7D", className: "flex-shrink-0 mr-3", children: /* @__PURE__ */ jsxDEV(
            "input",
            {
              "data-component-id": "src\\pages\\contact-management\\components\\ContactList.jsx:48:14",
              "data-component-path": "src\\pages\\contact-management\\components\\ContactList.jsx",
              "data-component-line": "48",
              "data-component-file": "ContactList.jsx",
              "data-component-name": "input",
              "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22checkbox%22%2C%22className%22%3A%22h-4%20w-4%20text-primary%20border-border%20rounded%20focus%3Aring-primary%20cursor-pointer%22%7D",
              type: "checkbox",
              checked: selectedContacts?.includes(contact?.id) || false,
              onChange: (e) => {
                console.log("Checkbox clicked for contact:", contact?.id, "checked:", e?.target?.checked);
                e?.stopPropagation();
                onContactMultiSelect?.(contact?.id);
              },
              onClick: (e) => {
                e?.stopPropagation();
              },
              className: "h-4 w-4 text-primary border-border rounded focus:ring-primary cursor-pointer"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactList.jsx",
              lineNumber: 48,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactList.jsx",
            lineNumber: 47,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactList.jsx:63:12", "data-component-path": "src\\pages\\contact-management\\components\\ContactList.jsx", "data-component-line": "63", "data-component-file": "ContactList.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex-shrink-0%20mr-3%22%7D", className: "flex-shrink-0 mr-3", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactList.jsx:64:14", "data-component-path": "src\\pages\\contact-management\\components\\ContactList.jsx", "data-component-line": "64", "data-component-file": "ContactList.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22relative%22%7D", className: "relative", children: [
            /* @__PURE__ */ jsxDEV(
              Image,
              {
                "data-component-id": "src\\pages\\contact-management\\components\\ContactList.jsx:65:16",
                "data-component-path": "src\\pages\\contact-management\\components\\ContactList.jsx",
                "data-component-line": "65",
                "data-component-file": "ContactList.jsx",
                "data-component-name": "Image",
                "data-component-content": "%7B%22elementName%22%3A%22Image%22%2C%22className%22%3A%22w-10%20h-10%20rounded-full%20object-cover%22%7D",
                src: contact?.avatar_url || "/assets/images/no_image.png",
                alt: `${contact?.first_name || ""} ${contact?.last_name || ""}`,
                className: "w-10 h-10 rounded-full object-cover"
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactList.jsx",
                lineNumber: 65,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\ContactList.jsx:70:16", "data-component-path": "src\\pages\\contact-management\\components\\ContactList.jsx", "data-component-line": "70", "data-component-file": "ContactList.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", className: `absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-surface ${contact?.status === "active" ? "bg-success" : "bg-text-tertiary"}` }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactList.jsx",
              lineNumber: 70,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactList.jsx",
            lineNumber: 64,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactList.jsx",
            lineNumber: 63,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactList.jsx:76:12", "data-component-path": "src\\pages\\contact-management\\components\\ContactList.jsx", "data-component-line": "76", "data-component-file": "ContactList.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex-1%20min-w-0%22%7D", className: "flex-1 min-w-0", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactList.jsx:77:14", "data-component-path": "src\\pages\\contact-management\\components\\ContactList.jsx", "data-component-line": "77", "data-component-file": "ContactList.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20justify-between%20items-start%22%7D", className: "flex justify-between items-start", children: [
              /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\contact-management\\components\\ContactList.jsx:78:16", "data-component-path": "src\\pages\\contact-management\\components\\ContactList.jsx", "data-component-line": "78", "data-component-file": "ContactList.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-sm%20font-medium%20text-text-primary%20truncate%22%7D", className: "text-sm font-medium text-text-primary truncate", children: contact?.full_name || `${contact?.first_name || ""} ${contact?.last_name || ""}`?.trim() || "Unnamed Contact" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactList.jsx",
                lineNumber: 78,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactList.jsx:81:16", "data-component-path": "src\\pages\\contact-management\\components\\ContactList.jsx", "data-component-line": "81", "data-component-file": "ContactList.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20ml-2%22%7D", className: "flex items-center ml-2", children: [
                contact?.deals?.some((deal) => deal?.stage === "negotiation" || deal?.stage === "proposal") && /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\ContactList.jsx:83:16", "data-component-path": "src\\pages\\contact-management\\components\\ContactList.jsx", "data-component-line": "83", "data-component-file": "ContactList.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22w-2%20h-2%20bg-warning%20rounded-full%20mr-1%22%7D", className: "w-2 h-2 bg-warning rounded-full mr-1", title: "Has active deals" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactList.jsx",
                  lineNumber: 83,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    "data-component-id": "src\\pages\\contact-management\\components\\ContactList.jsx:85:18",
                    "data-component-path": "src\\pages\\contact-management\\components\\ContactList.jsx",
                    "data-component-line": "85",
                    "data-component-file": "ContactList.jsx",
                    "data-component-name": "button",
                    "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22text-text-tertiary%20hover%3Atext-error%20transition-colors%20duration-150%20ease-out%22%7D",
                    onClick: (e) => {
                      e?.stopPropagation();
                      if (window.confirm("Are you sure you want to delete this contact?")) {
                        onDeleteContact?.(contact?.id);
                      }
                    },
                    className: "text-text-tertiary hover:text-error transition-colors duration-150 ease-out",
                    title: "Delete contact",
                    children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ContactList.jsx:95:20", "data-component-path": "src\\pages\\contact-management\\components\\ContactList.jsx", "data-component-line": "95", "data-component-file": "ContactList.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Trash2%22%7D", name: "Trash2", size: 14 }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactList.jsx",
                      lineNumber: 95,
                      columnNumber: 21
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactList.jsx",
                    lineNumber: 85,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactList.jsx",
                lineNumber: 81,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactList.jsx",
              lineNumber: 77,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\contact-management\\components\\ContactList.jsx:99:14", "data-component-path": "src\\pages\\contact-management\\components\\ContactList.jsx", "data-component-line": "99", "data-component-file": "ContactList.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-xs%20text-text-secondary%20truncate%22%7D", className: "text-xs text-text-secondary truncate", children: contact?.company?.name || "No Company" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactList.jsx",
              lineNumber: 99,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactList.jsx:102:14", "data-component-path": "src\\pages\\contact-management\\components\\ContactList.jsx", "data-component-line": "102", "data-component-file": "ContactList.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20mt-1%22%7D", className: "flex items-center mt-1", children: [
              /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ContactList.jsx:103:16", "data-component-path": "src\\pages\\contact-management\\components\\ContactList.jsx", "data-component-line": "103", "data-component-file": "ContactList.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Clock%22%2C%22className%22%3A%22text-text-tertiary%20mr-1%22%7D", name: "Clock", size: 12, className: "text-text-tertiary mr-1" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactList.jsx",
                lineNumber: 103,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\ContactList.jsx:104:16", "data-component-path": "src\\pages\\contact-management\\components\\ContactList.jsx", "data-component-line": "104", "data-component-file": "ContactList.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-xs%20text-text-tertiary%22%7D", className: "text-xs text-text-tertiary", children: formatDate(contact?.last_contact_date) }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactList.jsx",
                lineNumber: 104,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactList.jsx",
              lineNumber: 102,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactList.jsx",
            lineNumber: 76,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactList.jsx",
          lineNumber: 46,
          columnNumber: 11
        }, this)
      },
      contact?.id,
      false,
      {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactList.jsx",
        lineNumber: 35,
        columnNumber: 7
      },
      this
    )
  ) }, void 0, false, {
    fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactList.jsx",
    lineNumber: 33,
    columnNumber: 5
  }, this);
};
_c = ContactList;
export default ContactList;
var _c;
$RefreshReg$(_c, "ContactList");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/contact-management/components/ContactList.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/contact-management/components/ContactList.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEJRO0FBMUJSLE9BQU9BLG9CQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN6QixTQUFTQywyQkFBMkI7QUFDcEMsT0FBT0MsVUFBVTtBQUNqQixPQUFPQyxXQUFXO0FBRWxCLE1BQU1DLGNBQWNBLENBQUM7QUFBQSxFQUNuQkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDRixNQUFNO0FBQ0osUUFBTUMsYUFBYUEsQ0FBQ0MsZUFBZTtBQUNqQyxRQUFJLENBQUNBO0FBQVksYUFBTztBQUN4QixRQUFJO0FBQ0YsWUFBTUMsT0FBTyxJQUFJQyxLQUFLRixVQUFVO0FBQ2hDLGFBQU9YLG9CQUFvQlksTUFBTSxFQUFFRSxXQUFXLEtBQUssQ0FBQztBQUFBLElBQ3RELFNBQVNDLE9BQU87QUFDZCxhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFFQSxNQUFJWCxVQUFVWSxXQUFXLEdBQUc7QUFDMUIsV0FDRSx1QkFBQywwWUFBSSxXQUFVLG1CQUNiLGlDQUFDLHdiQUFFLFdBQVUsdUJBQXNCLGlDQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9ELEtBRHREO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFFQSxTQUNFLHVCQUFDLHdhQUFJLFdBQVUsNkNBQ1paLG9CQUFVYTtBQUFBQSxJQUFJLENBQUFDLFlBQ2I7QUFBQSxNQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUVDLFdBQVcscUdBQ1RiLG1CQUFtQkEsaUJBQWlCYyxPQUFPRCxTQUFTQyxLQUNoRCxrQkFBaUIsd0JBQXdCO0FBQUEsUUFFL0MsU0FBUyxNQUFNO0FBQ2JDLGtCQUFRQyxJQUFJLG9CQUFvQkgsT0FBTztBQUN2Q1gsNEJBQWtCVyxPQUFPO0FBQUEsUUFDM0I7QUFBQSxRQUVBLGlDQUFDLDZZQUFJLFdBQVUscUJBQ2I7QUFBQSxpQ0FBQyw4WUFBSSxXQUFVLHNCQUNiO0FBQUEsWUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTWixrQkFBa0JnQixTQUFTSixTQUFTQyxFQUFFLEtBQUs7QUFBQSxjQUNwRCxVQUFVLENBQUNJLE1BQU07QUFDZkgsd0JBQVFDLElBQUksaUNBQWlDSCxTQUFTQyxJQUFJLFlBQVlJLEdBQUdDLFFBQVFDLE9BQU87QUFDeEZGLG1CQUFHRyxnQkFBZ0I7QUFDbkJsQix1Q0FBdUJVLFNBQVNDLEVBQUU7QUFBQSxjQUNwQztBQUFBLGNBQ0EsU0FBUyxDQUFDSSxNQUFNO0FBQ2RBLG1CQUFHRyxnQkFBZ0I7QUFBQSxjQUNyQjtBQUFBLGNBQ0EsV0FBVTtBQUFBO0FBQUEsWUFYWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFXMEYsS0FaNUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFjQTtBQUFBLFVBRUEsdUJBQUMsOFlBQUksV0FBVSxzQkFDYixpQ0FBQyxrWUFBSSxXQUFVLFlBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUNDLEtBQUtSLFNBQVNTLGNBQWM7QUFBQSxnQkFDNUIsS0FBSyxHQUFHVCxTQUFTVSxjQUFjLEVBQUUsSUFBSVYsU0FBU1csYUFBYSxFQUFFO0FBQUEsZ0JBQzdELFdBQVU7QUFBQTtBQUFBLGNBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBR2lEO0FBQUEsWUFFakQsdUJBQUMsa1dBQUssV0FBVywwRUFDZlgsU0FBU1ksV0FBVyxXQUFXLGVBQWUsa0JBQWtCLE1BRGxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUk7QUFBQSxlQVJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0EsS0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVdBO0FBQUEsVUFFQSx1QkFBQywwWUFBSSxXQUFVLGtCQUNiO0FBQUEsbUNBQUMsOFpBQUksV0FBVSxvQ0FDYjtBQUFBLHFDQUFDLDJhQUFHLFdBQVUsa0RBQ1haLG1CQUFTYSxhQUFhLEdBQUdiLFNBQVNVLGNBQWMsRUFBRSxJQUFJVixTQUFTVyxhQUFhLEVBQUUsSUFBSUcsS0FBSyxLQUFLLHFCQUQvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxvWkFBSSxXQUFVLDBCQUNaZDtBQUFBQSx5QkFBU2UsT0FBT0MsS0FBSyxDQUFBQyxTQUFRQSxNQUFNQyxVQUFVLGlCQUFpQkQsTUFBTUMsVUFBVSxVQUFVLEtBQ3ZGLHVCQUFDLHlhQUFLLFdBQVUsd0NBQXVDLE9BQU0sc0JBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdGO0FBQUEsZ0JBRWxGO0FBQUEsa0JBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUNDLFNBQVMsQ0FBQ2IsTUFBTTtBQUNkQSx5QkFBR0csZ0JBQWdCO0FBQ25CLDBCQUFJVyxPQUFPQyxRQUFRLCtDQUErQyxHQUFHO0FBQ25FN0IsMENBQWtCUyxTQUFTQyxFQUFFO0FBQUEsc0JBQy9CO0FBQUEsb0JBQ0Y7QUFBQSxvQkFDQSxXQUFVO0FBQUEsb0JBQ1YsT0FBTTtBQUFBLG9CQUVOLGlDQUFDLDRYQUFLLE1BQUssVUFBUyxNQUFNLE1BQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTZCO0FBQUE7QUFBQSxrQkFWL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVdBO0FBQUEsbUJBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFnQkE7QUFBQSxpQkFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFxQkE7QUFBQSxZQUNBLHVCQUFDLDRaQUFFLFdBQVUsd0NBQ1ZELG1CQUFTcUIsU0FBU0MsUUFBUSxnQkFEN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsc1pBQUksV0FBVSwwQkFDYjtBQUFBLHFDQUFDLGliQUFLLE1BQUssU0FBUSxNQUFNLElBQUksV0FBVSw2QkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0U7QUFBQSxjQUNoRSx1QkFBQywyWkFBSyxXQUFVLDhCQUNiOUIscUJBQVdRLFNBQVN1QixpQkFBaUIsS0FEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxlQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdDQTtBQUFBLGFBOURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUErREE7QUFBQTtBQUFBLE1BekVLdkIsU0FBU0M7QUFBQUEsTUFEaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQTJFQTtBQUFBLEVBQ0QsS0E5RUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQStFQTtBQUVKO0FBQUV1QixLQTVHSXZDO0FBOEdOLGVBQWVBO0FBQVksSUFBQXVDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsImZvcm1hdERpc3RhbmNlVG9Ob3ciLCJJY29uIiwiSW1hZ2UiLCJDb250YWN0TGlzdCIsImNvbnRhY3RzIiwic2VsZWN0ZWRDb250YWN0Iiwic2VsZWN0ZWRDb250YWN0cyIsIm9uQ29udGFjdFNlbGVjdCIsIm9uQ29udGFjdE11bHRpU2VsZWN0Iiwib25EZWxldGVDb250YWN0IiwiZm9ybWF0RGF0ZSIsImRhdGVTdHJpbmciLCJkYXRlIiwiRGF0ZSIsImFkZFN1ZmZpeCIsImVycm9yIiwibGVuZ3RoIiwibWFwIiwiY29udGFjdCIsImlkIiwiY29uc29sZSIsImxvZyIsImluY2x1ZGVzIiwiZSIsInRhcmdldCIsImNoZWNrZWQiLCJzdG9wUHJvcGFnYXRpb24iLCJhdmF0YXJfdXJsIiwiZmlyc3RfbmFtZSIsImxhc3RfbmFtZSIsInN0YXR1cyIsImZ1bGxfbmFtZSIsInRyaW0iLCJkZWFscyIsInNvbWUiLCJkZWFsIiwic3RhZ2UiLCJ3aW5kb3ciLCJjb25maXJtIiwiY29tcGFueSIsIm5hbWUiLCJsYXN0X2NvbnRhY3RfZGF0ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ29udGFjdExpc3QuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IGZvcm1hdERpc3RhbmNlVG9Ob3cgfSBmcm9tICdkYXRlLWZucyc7XHJcbmltcG9ydCBJY29uIGZyb20gJ2NvbXBvbmVudHMvQXBwSWNvbic7XHJcbmltcG9ydCBJbWFnZSBmcm9tICdjb21wb25lbnRzL0FwcEltYWdlJztcclxuXHJcbmNvbnN0IENvbnRhY3RMaXN0ID0gKHsgXHJcbiAgY29udGFjdHMsIFxyXG4gIHNlbGVjdGVkQ29udGFjdCwgXHJcbiAgc2VsZWN0ZWRDb250YWN0cywgXHJcbiAgb25Db250YWN0U2VsZWN0LCBcclxuICBvbkNvbnRhY3RNdWx0aVNlbGVjdCxcclxuICBvbkRlbGV0ZUNvbnRhY3QgXHJcbn0pID0+IHtcclxuICBjb25zdCBmb3JtYXREYXRlID0gKGRhdGVTdHJpbmcpID0+IHtcclxuICAgIGlmICghZGF0ZVN0cmluZykgcmV0dXJuICdOZXZlciBjb250YWN0ZWQnO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgZGF0ZSA9IG5ldyBEYXRlKGRhdGVTdHJpbmcpO1xyXG4gICAgICByZXR1cm4gZm9ybWF0RGlzdGFuY2VUb05vdyhkYXRlLCB7IGFkZFN1ZmZpeDogdHJ1ZSB9KTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHJldHVybiAnSW52YWxpZCBkYXRlJztcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBpZiAoY29udGFjdHM/Lmxlbmd0aCA9PT0gMCkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+Tm8gY29udGFjdHMgZm91bmQ8L3A+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXktYXV0byBtYXgtaC1bY2FsYygxMDB2aC0yMjBweCldXCI+XHJcbiAgICAgIHtjb250YWN0cz8ubWFwKGNvbnRhY3QgPT4gKFxyXG4gICAgICAgIDxkaXYgXHJcbiAgICAgICAgICBrZXk9e2NvbnRhY3Q/LmlkfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPXtgYm9yZGVyLWIgYm9yZGVyLWJvcmRlciBsYXN0OmJvcmRlci1iLTAgcC00IGN1cnNvci1wb2ludGVyIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MCBlYXNlLW91dCAke1xyXG4gICAgICAgICAgICBzZWxlY3RlZENvbnRhY3QgJiYgc2VsZWN0ZWRDb250YWN0Py5pZCA9PT0gY29udGFjdD8uaWQgXHJcbiAgICAgICAgICAgICAgPyAnYmctcHJpbWFyeS01MCcgOidob3ZlcjpiZy1zdXJmYWNlLWhvdmVyJ1xyXG4gICAgICAgICAgfWB9XHJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdDb250YWN0IGNsaWNrZWQ6JywgY29udGFjdCk7XHJcbiAgICAgICAgICAgIG9uQ29udGFjdFNlbGVjdD8uKGNvbnRhY3QpO1xyXG4gICAgICAgICAgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1zaHJpbmstMCBtci0zXCI+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgY2hlY2tlZD17c2VsZWN0ZWRDb250YWN0cz8uaW5jbHVkZXMoY29udGFjdD8uaWQpIHx8IGZhbHNlfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdDaGVja2JveCBjbGlja2VkIGZvciBjb250YWN0OicsIGNvbnRhY3Q/LmlkLCAnY2hlY2tlZDonLCBlPy50YXJnZXQ/LmNoZWNrZWQpO1xyXG4gICAgICAgICAgICAgICAgICBlPy5zdG9wUHJvcGFnYXRpb24oKTtcclxuICAgICAgICAgICAgICAgICAgb25Db250YWN0TXVsdGlTZWxlY3Q/Lihjb250YWN0Py5pZCk7XHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgZT8uc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LXByaW1hcnkgYm9yZGVyLWJvcmRlciByb3VuZGVkIGZvY3VzOnJpbmctcHJpbWFyeSBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtc2hyaW5rLTAgbXItM1wiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgIDxJbWFnZVxyXG4gICAgICAgICAgICAgICAgICBzcmM9e2NvbnRhY3Q/LmF2YXRhcl91cmwgfHwgJy9hc3NldHMvaW1hZ2VzL25vX2ltYWdlLnBuZyd9XHJcbiAgICAgICAgICAgICAgICAgIGFsdD17YCR7Y29udGFjdD8uZmlyc3RfbmFtZSB8fCAnJ30gJHtjb250YWN0Py5sYXN0X25hbWUgfHwgJyd9YH1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQtZnVsbCBvYmplY3QtY292ZXJcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YGFic29sdXRlIGJvdHRvbS0wIHJpZ2h0LTAgdy0zIGgtMyByb3VuZGVkLWZ1bGwgYm9yZGVyLTIgYm9yZGVyLXN1cmZhY2UgJHtcclxuICAgICAgICAgICAgICAgICAgY29udGFjdD8uc3RhdHVzID09PSAnYWN0aXZlJyA/ICdiZy1zdWNjZXNzJyA6ICdiZy10ZXh0LXRlcnRpYXJ5J1xyXG4gICAgICAgICAgICAgICAgfWB9Pjwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy0wXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1zdGFydFwiPlxyXG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgdHJ1bmNhdGVcIj5cclxuICAgICAgICAgICAgICAgICAge2NvbnRhY3Q/LmZ1bGxfbmFtZSB8fCBgJHtjb250YWN0Py5maXJzdF9uYW1lIHx8ICcnfSAke2NvbnRhY3Q/Lmxhc3RfbmFtZSB8fCAnJ31gPy50cmltKCkgfHwgJ1VubmFtZWQgQ29udGFjdCd9XHJcbiAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBtbC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtjb250YWN0Py5kZWFscz8uc29tZShkZWFsID0+IGRlYWw/LnN0YWdlID09PSAnbmVnb3RpYXRpb24nIHx8IGRlYWw/LnN0YWdlID09PSAncHJvcG9zYWwnKSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yIGgtMiBiZy13YXJuaW5nIHJvdW5kZWQtZnVsbCBtci0xXCIgdGl0bGU9XCJIYXMgYWN0aXZlIGRlYWxzXCI+PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIGU/LnN0b3BQcm9wYWdhdGlvbigpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgaWYgKHdpbmRvdy5jb25maXJtKCdBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gZGVsZXRlIHRoaXMgY29udGFjdD8nKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkRlbGV0ZUNvbnRhY3Q/Lihjb250YWN0Py5pZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtdGVydGlhcnkgaG92ZXI6dGV4dC1lcnJvciB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTAgZWFzZS1vdXRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiRGVsZXRlIGNvbnRhY3RcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIlRyYXNoMlwiIHNpemU9ezE0fSAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC10ZXh0LXNlY29uZGFyeSB0cnVuY2F0ZVwiPlxyXG4gICAgICAgICAgICAgICAge2NvbnRhY3Q/LmNvbXBhbnk/Lm5hbWUgfHwgJ05vIENvbXBhbnknfVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIG10LTFcIj5cclxuICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJDbG9ja1wiIHNpemU9ezEyfSBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtdGVydGlhcnkgbXItMVwiIC8+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtdGV4dC10ZXJ0aWFyeVwiPlxyXG4gICAgICAgICAgICAgICAgICB7Zm9ybWF0RGF0ZShjb250YWN0Py5sYXN0X2NvbnRhY3RfZGF0ZSl9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICkpfVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IENvbnRhY3RMaXN0OyJdLCJmaWxlIjoiRDovY3VycmVudCBwcm9qZWN0cy9jbGF1ZGUtY29kZS9zcmMvcGFnZXMvY29udGFjdC1tYW5hZ2VtZW50L2NvbXBvbmVudHMvQ29udGFjdExpc3QuanN4In0=