import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport1_react.__esModule ? __vite__cjsImport1_react.default : __vite__cjsImport1_react;
import __vite__cjsImport2_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=44ab9529"; const createRoot = __vite__cjsImport2_reactDom_client["createRoot"];
import App from "/src/App.jsx";
import "/src/styles/tailwind.css";
import "/src/styles/index.css";
const container = document.getElementById("root");
const root = createRoot(container);
root.render(/* @__PURE__ */ jsxDEV(App, { "data-component-id": "src\\index.jsx:10:12", "data-component-path": "src\\index.jsx", "data-component-line": "10", "data-component-file": "index.jsx", "data-component-name": "App", "data-component-content": "%7B%22elementName%22%3A%22App%22%7D" }, void 0, false, {
  fileName: "D:/current projects/claude-code/src/index.jsx",
  lineNumber: 10,
  columnNumber: 13
}, this));

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU1k7QUFUWixPQUFPQSxXQUFXO0FBQ2xCLFNBQVNDLGtCQUFrQjtBQUMzQixPQUFPQyxTQUFTO0FBQ2hCLE9BQU87QUFDUCxPQUFPO0FBRVAsTUFBTUMsWUFBWUMsU0FBU0MsZUFBZSxNQUFNO0FBQ2hELE1BQU1DLE9BQU9MLFdBQVdFLFNBQVM7QUFFakNHLEtBQUtDLE9BQU8sdUJBQUMsK1BBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUFJLENBQUciLCJuYW1lcyI6WyJSZWFjdCIsImNyZWF0ZVJvb3QiLCJBcHAiLCJjb250YWluZXIiLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwicm9vdCIsInJlbmRlciJdLCJzb3VyY2VzIjpbImluZGV4LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IGNyZWF0ZVJvb3QgfSBmcm9tIFwicmVhY3QtZG9tL2NsaWVudFwiO1xyXG5pbXBvcnQgQXBwIGZyb20gXCIuL0FwcFwiO1xyXG5pbXBvcnQgXCIuL3N0eWxlcy90YWlsd2luZC5jc3NcIjtcclxuaW1wb3J0IFwiLi9zdHlsZXMvaW5kZXguY3NzXCI7XHJcblxyXG5jb25zdCBjb250YWluZXIgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInJvb3RcIik7XHJcbmNvbnN0IHJvb3QgPSBjcmVhdGVSb290KGNvbnRhaW5lcik7XHJcblxyXG5yb290LnJlbmRlcig8QXBwIC8+KTtcclxuIl0sImZpbGUiOiJEOi9jdXJyZW50IHByb2plY3RzL2NsYXVkZS1jb2RlL3NyYy9pbmRleC5qc3gifQ==