import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/activity-timeline/components/ActivityCard.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import Icon from "/src/components/AppIcon.jsx";
import Image from "/src/components/AppImage.jsx";
const ActivityCard = ({ activity, isLast }) => {
  _s();
  const [isExpanded, setIsExpanded] = useState(false);
  const getActivityIcon = (type) => {
    switch (type) {
      case "email":
        return "Mail";
      case "call":
        return "Phone";
      case "meeting":
        return "Calendar";
      case "deal_update":
        return "TrendingUp";
      case "task":
        return "CheckSquare";
      default:
        return "Activity";
    }
  };
  const getActivityColor = (type) => {
    switch (type) {
      case "email":
        return "text-blue-600 bg-blue-50";
      case "call":
        return "text-green-600 bg-green-50";
      case "meeting":
        return "text-purple-600 bg-purple-50";
      case "deal_update":
        return "text-orange-600 bg-orange-50";
      case "task":
        return "text-indigo-600 bg-indigo-50";
      default:
        return "text-gray-600 bg-gray-50";
    }
  };
  const getPriorityColor = (priority) => {
    switch (priority) {
      case "high":
        return "text-error bg-error-50";
      case "medium":
        return "text-warning bg-warning-50";
      case "low":
        return "text-success bg-success-50";
      default:
        return "text-text-secondary bg-gray-50";
    }
  };
  const formatTimestamp = (timestamp) => {
    const now = /* @__PURE__ */ new Date();
    const diff = now - timestamp;
    const hours = Math.floor(diff / (1e3 * 60 * 60));
    const days = Math.floor(hours / 24);
    if (hours < 1) {
      return "Just now";
    } else if (hours < 24) {
      return `${hours}h ago`;
    } else if (days < 7) {
      return `${days}d ago`;
    } else {
      return timestamp?.toLocaleDateString();
    }
  };
  const getChannelIcon = (channel) => {
    switch (channel) {
      case "gmail":
        return "Mail";
      case "twilio":
        return "Phone";
      case "calendar":
        return "Calendar";
      case "system":
        return "Settings";
      default:
        return "Activity";
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:88:4", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "88", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22relative%22%7D", className: "relative", children: [
    !isLast && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:91:6", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "91", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22absolute%20left-6%20top-16%20w-0.5%20h-full%20bg-border%22%7D", className: "absolute left-6 top-16 w-0.5 h-full bg-border" }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
      lineNumber: 91,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:93:6", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "93", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20space-x-4%22%7D", className: "flex space-x-4", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:95:8", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "95", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", className: `w-12 h-12 rounded-full flex items-center justify-center ${getActivityColor(activity?.type)} flex-shrink-0`, children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:96:10", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "96", "data-component-file": "ActivityCard.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%7D", name: getActivityIcon(activity?.type), size: 20 }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
        lineNumber: 96,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
        lineNumber: 95,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:100:8", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "100", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex-1%20card%20p-6%22%7D", className: "flex-1 card p-6", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:102:10", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "102", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-start%20justify-between%20mb-4%22%7D", className: "flex items-start justify-between mb-4", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:103:12", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "103", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex-1%22%7D", className: "flex-1", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:104:14", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "104", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-3%20mb-2%22%7D", className: "flex items-center space-x-3 mb-2", children: [
              /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:105:16", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "105", "data-component-file": "ActivityCard.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%7D", className: "text-lg font-semibold text-text-primary", children: activity?.title }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                lineNumber: 105,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:106:16", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "106", "data-component-file": "ActivityCard.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", className: `px-2 py-1 rounded-full text-xs font-medium ${getPriorityColor(activity?.priority)}`, children: activity?.priority }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                lineNumber: 106,
                columnNumber: 17
              }, this),
              activity?.dealValue && /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:110:16", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "110", "data-component-file": "ActivityCard.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22px-2%20py-1%20bg-success-50%20text-success%20rounded-full%20text-xs%20font-medium%22%7D", className: "px-2 py-1 bg-success-50 text-success rounded-full text-xs font-medium", children: activity?.dealValue }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                lineNumber: 110,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
              lineNumber: 104,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:116:14", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "116", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-4%20text-sm%20text-text-secondary%22%7D", className: "flex items-center space-x-4 text-sm text-text-secondary", children: [
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:117:16", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "117", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%22%7D", className: "flex items-center space-x-2", children: [
                /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:118:18", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "118", "data-component-file": "ActivityCard.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%7D", name: getChannelIcon(activity?.channel), size: 14 }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                  lineNumber: 118,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:119:18", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "119", "data-component-file": "ActivityCard.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22capitalize%22%7D", className: "capitalize", children: activity?.channel }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                  lineNumber: 119,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                lineNumber: 117,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:121:16", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "121", "data-component-file": "ActivityCard.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: formatTimestamp(activity?.timestamp) }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                lineNumber: 121,
                columnNumber: 17
              }, this),
              activity?.duration && /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:123:16", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "123", "data-component-file": "ActivityCard.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Duration%3A%22%7D", children: [
                "Duration: ",
                activity?.duration
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                lineNumber: 123,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
              lineNumber: 116,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
            lineNumber: 103,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:128:12", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "128", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%22%7D", className: "flex items-center space-x-2", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:129:14",
              "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx",
              "data-component-line": "129",
              "data-component-file": "ActivityCard.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22p-2%20text-text-secondary%20hover%3Atext-text-primary%20hover%3Abg-surface-hover%20rounded-lg%20transition-all%20duration-150%20ease-out%22%7D",
              onClick: () => setIsExpanded(!isExpanded),
              className: "p-2 text-text-secondary hover:text-text-primary hover:bg-surface-hover rounded-lg transition-all duration-150 ease-out",
              children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:133:16", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "133", "data-component-file": "ActivityCard.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%7D", name: isExpanded ? "ChevronUp" : "ChevronDown", size: 16 }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                lineNumber: 133,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
              lineNumber: 129,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
            lineNumber: 128,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
          lineNumber: 102,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:139:10", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "139", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-4%20mb-4%22%7D", className: "flex items-center space-x-4 mb-4", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:140:12", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "140", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-3%22%7D", className: "flex items-center space-x-3", children: [
            activity?.contactAvatar && /* @__PURE__ */ jsxDEV(
              Image,
              {
                "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:142:14",
                "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx",
                "data-component-line": "142",
                "data-component-file": "ActivityCard.jsx",
                "data-component-name": "Image",
                "data-component-content": "%7B%22elementName%22%3A%22Image%22%2C%22className%22%3A%22w-8%20h-8%20rounded-full%20object-cover%22%7D",
                src: activity?.contactAvatar,
                alt: activity?.contact,
                className: "w-8 h-8 rounded-full object-cover"
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                lineNumber: 142,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:148:14", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "148", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:149:16", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "149", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22font-medium%20text-text-primary%22%7D", className: "font-medium text-text-primary", children: activity?.contact }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                lineNumber: 149,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:150:16", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "150", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%7D", className: "text-sm text-text-secondary", children: activity?.company }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                lineNumber: 150,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
              lineNumber: 148,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
            lineNumber: 140,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:154:12", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "154", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-3%20ml-auto%22%7D", className: "flex items-center space-x-3 ml-auto", children: activity?.user !== "System" && activity?.avatar && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:156:14", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "156", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%22%7D", className: "flex items-center space-x-2", children: [
            /* @__PURE__ */ jsxDEV(
              Image,
              {
                "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:157:18",
                "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx",
                "data-component-line": "157",
                "data-component-file": "ActivityCard.jsx",
                "data-component-name": "Image",
                "data-component-content": "%7B%22elementName%22%3A%22Image%22%2C%22className%22%3A%22w-6%20h-6%20rounded-full%20object-cover%22%7D",
                src: activity?.avatar,
                alt: activity?.user,
                className: "w-6 h-6 rounded-full object-cover"
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                lineNumber: 157,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:162:18", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "162", "data-component-file": "ActivityCard.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%7D", className: "text-sm text-text-secondary", children: activity?.user }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
              lineNumber: 162,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
            lineNumber: 156,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
            lineNumber: 154,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
          lineNumber: 139,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:169:10", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "169", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22mb-4%22%7D", className: "mb-4", children: /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:170:12", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "170", "data-component-file": "ActivityCard.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20text-sm%20leading-relaxed%22%7D", className: "text-text-secondary text-sm leading-relaxed", children: isExpanded ? activity?.description : `${activity?.description?.substring(0, 150)}${activity?.description?.length > 150 ? "..." : ""}` }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
          lineNumber: 170,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
          lineNumber: 169,
          columnNumber: 11
        }, this),
        isExpanded && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:180:10", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "180", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-4%20border-t%20border-border%20pt-4%22%7D", className: "space-y-4 border-t border-border pt-4", children: [
          activity?.attachments && activity?.attachments?.length > 0 && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:183:12", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "183", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
            /* @__PURE__ */ jsxDEV("h4", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:184:18", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "184", "data-component-file": "ActivityCard.jsx", "data-component-name": "h4", "data-component-content": "%7B%22elementName%22%3A%22h4%22%2C%22className%22%3A%22text-sm%20font-medium%20text-text-primary%20mb-2%22%2C%22textContent%22%3A%22Attachments%22%7D", className: "text-sm font-medium text-text-primary mb-2", children: "Attachments" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
              lineNumber: 184,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:185:18", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "185", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-2%22%7D", className: "space-y-2", children: activity?.attachments?.map(
              (attachment, index) => /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:187:16", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "187", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%20text-sm%22%7D", className: "flex items-center space-x-2 text-sm", children: [
                /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:188:24", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "188", "data-component-file": "ActivityCard.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Paperclip%22%2C%22className%22%3A%22text-text-tertiary%22%7D", name: "Paperclip", size: 14, className: "text-text-tertiary" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                  lineNumber: 188,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:189:24", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "189", "data-component-file": "ActivityCard.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-primary%20hover%3Atext-primary-700%20cursor-pointer%22%7D", className: "text-primary hover:text-primary-700 cursor-pointer", children: attachment }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                  lineNumber: 189,
                  columnNumber: 25
                }, this)
              ] }, index, true, {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                lineNumber: 187,
                columnNumber: 17
              }, this)
            ) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
              lineNumber: 185,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
            lineNumber: 183,
            columnNumber: 13
          }, this),
          activity?.type === "deal_update" && activity?.previousStage && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:198:12", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "198", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
            /* @__PURE__ */ jsxDEV("h4", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:199:18", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "199", "data-component-file": "ActivityCard.jsx", "data-component-name": "h4", "data-component-content": "%7B%22elementName%22%3A%22h4%22%2C%22className%22%3A%22text-sm%20font-medium%20text-text-primary%20mb-2%22%2C%22textContent%22%3A%22Stage%20Progression%22%7D", className: "text-sm font-medium text-text-primary mb-2", children: "Stage Progression" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
              lineNumber: 199,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:200:18", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "200", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%20text-sm%22%7D", className: "flex items-center space-x-2 text-sm", children: [
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:201:20", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "201", "data-component-file": "ActivityCard.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22px-2%20py-1%20bg-gray-100%20text-gray-700%20rounded%22%7D", className: "px-2 py-1 bg-gray-100 text-gray-700 rounded", children: activity?.previousStage }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                lineNumber: 201,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:202:20", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "202", "data-component-file": "ActivityCard.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22ArrowRight%22%2C%22className%22%3A%22text-text-tertiary%22%7D", name: "ArrowRight", size: 14, className: "text-text-tertiary" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                lineNumber: 202,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:203:20", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "203", "data-component-file": "ActivityCard.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22px-2%20py-1%20bg-primary-50%20text-primary%20rounded%22%7D", className: "px-2 py-1 bg-primary-50 text-primary rounded", children: activity?.currentStage }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                lineNumber: 203,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:204:20", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "204", "data-component-file": "ActivityCard.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-text-secondary%20ml-2%22%2C%22textContent%22%3A%22(%20%25%20probability)%22%7D", className: "text-text-secondary ml-2", children: [
                "(",
                activity?.probability,
                "% probability)"
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                lineNumber: 204,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
              lineNumber: 200,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
            lineNumber: 198,
            columnNumber: 13
          }, this),
          activity?.type === "meeting" && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:211:12", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "211", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20md%3Agrid-cols-2%20gap-4%20text-sm%22%7D", className: "grid grid-cols-1 md:grid-cols-2 gap-4 text-sm", children: [
            activity?.location && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:213:14", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "213", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:214:22", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "214", "data-component-file": "ActivityCard.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22font-medium%20text-text-primary%22%2C%22textContent%22%3A%22Location%3A%22%7D", className: "font-medium text-text-primary", children: "Location:" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                lineNumber: 214,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:215:22", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "215", "data-component-file": "ActivityCard.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-text-secondary%20ml-2%22%7D", className: "text-text-secondary ml-2", children: activity?.location }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                lineNumber: 215,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
              lineNumber: 213,
              columnNumber: 15
            }, this),
            activity?.attendees && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:219:14", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "219", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:220:22", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "220", "data-component-file": "ActivityCard.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22font-medium%20text-text-primary%22%2C%22textContent%22%3A%22Attendees%3A%22%7D", className: "font-medium text-text-primary", children: "Attendees:" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                lineNumber: 220,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:221:22", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "221", "data-component-file": "ActivityCard.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-text-secondary%20ml-2%22%2C%22textContent%22%3A%22people%22%7D", className: "text-text-secondary ml-2", children: [
                activity?.attendees,
                " people"
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                lineNumber: 221,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
              lineNumber: 219,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
            lineNumber: 211,
            columnNumber: 13
          }, this),
          activity?.type === "call" && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:229:12", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "229", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-4%20text-sm%22%7D", className: "flex items-center space-x-4 text-sm", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:230:18", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "230", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:231:20", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "231", "data-component-file": "ActivityCard.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22font-medium%20text-text-primary%22%2C%22textContent%22%3A%22Type%3A%22%7D", className: "font-medium text-text-primary", children: "Type:" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                lineNumber: 231,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:232:20", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "232", "data-component-file": "ActivityCard.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-text-secondary%20ml-2%20capitalize%22%7D", className: "text-text-secondary ml-2 capitalize", children: activity?.callType }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                lineNumber: 232,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
              lineNumber: 230,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:234:18", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "234", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:235:20", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "235", "data-component-file": "ActivityCard.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22font-medium%20text-text-primary%22%2C%22textContent%22%3A%22Status%3A%22%7D", className: "font-medium text-text-primary", children: "Status:" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                lineNumber: 235,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:236:20", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "236", "data-component-file": "ActivityCard.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-text-secondary%20ml-2%20capitalize%22%7D", className: "text-text-secondary ml-2 capitalize", children: activity?.status }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                lineNumber: 236,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
              lineNumber: 234,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
            lineNumber: 229,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
          lineNumber: 180,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:244:10", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "244", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%20pt-4%20border-t%20border-border%22%7D", className: "flex items-center justify-between pt-4 border-t border-border", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:245:12", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "245", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%22%7D", className: "flex items-center space-x-2", children: [
            /* @__PURE__ */ jsxDEV("button", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:246:14", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "246", "data-component-file": "ActivityCard.jsx", "data-component-name": "button", "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%20px-3%20py-1.5%20text-sm%20text-text-secondary%20hover%3Atext-primary%20hover%3Abg-primary-50%20rounded-lg%20transition-all%20duration-150%20ease-out%22%7D", className: "flex items-center space-x-2 px-3 py-1.5 text-sm text-text-secondary hover:text-primary hover:bg-primary-50 rounded-lg transition-all duration-150 ease-out", children: [
              /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:247:16", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "247", "data-component-file": "ActivityCard.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22MessageSquare%22%7D", name: "MessageSquare", size: 14 }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                lineNumber: 247,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:248:16", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "248", "data-component-file": "ActivityCard.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Reply%22%7D", children: "Reply" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                lineNumber: 248,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
              lineNumber: 246,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("button", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:251:14", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "251", "data-component-file": "ActivityCard.jsx", "data-component-name": "button", "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%20px-3%20py-1.5%20text-sm%20text-text-secondary%20hover%3Atext-primary%20hover%3Abg-primary-50%20rounded-lg%20transition-all%20duration-150%20ease-out%22%7D", className: "flex items-center space-x-2 px-3 py-1.5 text-sm text-text-secondary hover:text-primary hover:bg-primary-50 rounded-lg transition-all duration-150 ease-out", children: [
              /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:252:16", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "252", "data-component-file": "ActivityCard.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Plus%22%7D", name: "Plus", size: 14 }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                lineNumber: 252,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:253:16", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "253", "data-component-file": "ActivityCard.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Follow-up%22%7D", children: "Follow-up" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                lineNumber: 253,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
              lineNumber: 251,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("button", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:256:14", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "256", "data-component-file": "ActivityCard.jsx", "data-component-name": "button", "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%20px-3%20py-1.5%20text-sm%20text-text-secondary%20hover%3Atext-primary%20hover%3Abg-primary-50%20rounded-lg%20transition-all%20duration-150%20ease-out%22%7D", className: "flex items-center space-x-2 px-3 py-1.5 text-sm text-text-secondary hover:text-primary hover:bg-primary-50 rounded-lg transition-all duration-150 ease-out", children: [
              /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:257:16", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "257", "data-component-file": "ActivityCard.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Calendar%22%7D", name: "Calendar", size: 14 }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                lineNumber: 257,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:258:16", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "258", "data-component-file": "ActivityCard.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Schedule%22%7D", children: "Schedule" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
                lineNumber: 258,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
              lineNumber: 256,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
            lineNumber: 245,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:262:12", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "262", "data-component-file": "ActivityCard.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%22%7D", className: "flex items-center space-x-2", children: [
            /* @__PURE__ */ jsxDEV("button", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:263:14", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "263", "data-component-file": "ActivityCard.jsx", "data-component-name": "button", "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22p-1.5%20text-text-secondary%20hover%3Atext-text-primary%20hover%3Abg-surface-hover%20rounded%20transition-all%20duration-150%20ease-out%22%7D", className: "p-1.5 text-text-secondary hover:text-text-primary hover:bg-surface-hover rounded transition-all duration-150 ease-out", children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:264:16", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "264", "data-component-file": "ActivityCard.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Share%22%7D", name: "Share", size: 14 }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
              lineNumber: 264,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
              lineNumber: 263,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("button", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:267:14", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "267", "data-component-file": "ActivityCard.jsx", "data-component-name": "button", "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22p-1.5%20text-text-secondary%20hover%3Atext-text-primary%20hover%3Abg-surface-hover%20rounded%20transition-all%20duration-150%20ease-out%22%7D", className: "p-1.5 text-text-secondary hover:text-text-primary hover:bg-surface-hover rounded transition-all duration-150 ease-out", children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx:268:16", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityCard.jsx", "data-component-line": "268", "data-component-file": "ActivityCard.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22MoreHorizontal%22%7D", name: "MoreHorizontal", size: 14 }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
              lineNumber: 268,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
              lineNumber: 267,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
            lineNumber: 262,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
          lineNumber: 244,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
        lineNumber: 100,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
      lineNumber: 93,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx",
    lineNumber: 88,
    columnNumber: 5
  }, this);
};
_s(ActivityCard, "FPNvbbHVlWWR4LKxxNntSxiIS38=");
_c = ActivityCard;
export default ActivityCard;
var _c;
$RefreshReg$(_c, "ActivityCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityCard.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEZROzJCQTFGUjtBQUFnQkEsTUFBUSxjQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3ZDLE9BQU9DLFVBQVU7QUFDakIsT0FBT0MsV0FBVztBQUVsQixNQUFNQyxlQUFlQSxDQUFDLEVBQUVDLFVBQVVDLE9BQU8sTUFBTTtBQUFBQyxLQUFBO0FBQzdDLFFBQU0sQ0FBQ0MsWUFBWUMsYUFBYSxJQUFJUixTQUFTLEtBQUs7QUFFbEQsUUFBTVMsa0JBQWtCQSxDQUFDQyxTQUFTO0FBQ2hDLFlBQVFBLE1BQUk7QUFBQSxNQUNWLEtBQUs7QUFDSCxlQUFPO0FBQUEsTUFDVCxLQUFLO0FBQ0gsZUFBTztBQUFBLE1BQ1QsS0FBSztBQUNILGVBQU87QUFBQSxNQUNULEtBQUs7QUFDSCxlQUFPO0FBQUEsTUFDVCxLQUFLO0FBQ0gsZUFBTztBQUFBLE1BQ1Q7QUFDRSxlQUFPO0FBQUEsSUFDWDtBQUFBLEVBQ0Y7QUFFQSxRQUFNQyxtQkFBbUJBLENBQUNELFNBQVM7QUFDakMsWUFBUUEsTUFBSTtBQUFBLE1BQ1YsS0FBSztBQUNILGVBQU87QUFBQSxNQUNULEtBQUs7QUFDSCxlQUFPO0FBQUEsTUFDVCxLQUFLO0FBQ0gsZUFBTztBQUFBLE1BQ1QsS0FBSztBQUNILGVBQU87QUFBQSxNQUNULEtBQUs7QUFDSCxlQUFPO0FBQUEsTUFDVDtBQUNFLGVBQU87QUFBQSxJQUNYO0FBQUEsRUFDRjtBQUVBLFFBQU1FLG1CQUFtQkEsQ0FBQ0MsYUFBYTtBQUNyQyxZQUFRQSxVQUFRO0FBQUEsTUFDZCxLQUFLO0FBQ0gsZUFBTztBQUFBLE1BQ1QsS0FBSztBQUNILGVBQU87QUFBQSxNQUNULEtBQUs7QUFDSCxlQUFPO0FBQUEsTUFDVDtBQUNFLGVBQU87QUFBQSxJQUNYO0FBQUEsRUFDRjtBQUVBLFFBQU1DLGtCQUFrQkEsQ0FBQ0MsY0FBYztBQUNyQyxVQUFNQyxNQUFNLG9CQUFJQyxLQUFLO0FBQ3JCLFVBQU1DLE9BQU9GLE1BQU1EO0FBQ25CLFVBQU1JLFFBQVFDLEtBQUtDLE1BQU1ILFFBQVEsTUFBTyxLQUFLLEdBQUc7QUFDaEQsVUFBTUksT0FBT0YsS0FBS0MsTUFBTUYsUUFBUSxFQUFFO0FBRWxDLFFBQUlBLFFBQVEsR0FBRztBQUNiLGFBQU87QUFBQSxJQUNULFdBQVdBLFFBQVEsSUFBSTtBQUNyQixhQUFPLEdBQUdBLEtBQUs7QUFBQSxJQUNqQixXQUFXRyxPQUFPLEdBQUc7QUFDbkIsYUFBTyxHQUFHQSxJQUFJO0FBQUEsSUFDaEIsT0FBTztBQUNMLGFBQU9QLFdBQVdRLG1CQUFtQjtBQUFBLElBQ3ZDO0FBQUEsRUFDRjtBQUVBLFFBQU1DLGlCQUFpQkEsQ0FBQ0MsWUFBWTtBQUNsQyxZQUFRQSxTQUFPO0FBQUEsTUFDYixLQUFLO0FBQ0gsZUFBTztBQUFBLE1BQ1QsS0FBSztBQUNILGVBQU87QUFBQSxNQUNULEtBQUs7QUFDSCxlQUFPO0FBQUEsTUFDVCxLQUFLO0FBQ0gsZUFBTztBQUFBLE1BQ1Q7QUFDRSxlQUFPO0FBQUEsSUFDWDtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLGtZQUFJLFdBQVUsWUFFWjtBQUFBLEtBQUNwQixVQUNBLHVCQUFDLGliQUFJLFdBQVUsbURBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErRDtBQUFBLElBRWpFLHVCQUFDLDBZQUFJLFdBQVUsa0JBRWI7QUFBQSw2QkFBQywrVkFBSSxXQUFXLDJEQUEyRE0saUJBQWlCUCxVQUFVTSxJQUFJLENBQUMsa0JBQ3pHLGlDQUFDLGlXQUFLLE1BQU1ELGdCQUFnQkwsVUFBVU0sSUFBSSxHQUFHLE1BQU0sTUFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzRCxLQUR4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUdBLHVCQUFDLCtZQUFJLFdBQVUsbUJBRWI7QUFBQSwrQkFBQyx3YUFBSSxXQUFVLHlDQUNiO0FBQUEsaUNBQUMsbVlBQUksV0FBVSxVQUNiO0FBQUEsbUNBQUMsbWFBQUksV0FBVSxvQ0FDYjtBQUFBLHFDQUFDLHFhQUFHLFdBQVUsMkNBQTJDTixvQkFBVXNCLFNBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlFO0FBQUEsY0FDekUsdUJBQUMscVdBQUssV0FBVyw4Q0FBOENkLGlCQUFpQlIsVUFBVVMsUUFBUSxDQUFDLElBQ2hHVCxvQkFBVVMsWUFEYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQ1QsVUFBVXVCLGFBQ1QsdUJBQUMsaWRBQUssV0FBVSx5RUFDYnZCLG9CQUFVdUIsYUFEYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBUko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLFlBRUEsdUJBQUMsNGJBQUksV0FBVSwyREFDYjtBQUFBLHFDQUFDLDRaQUFJLFdBQVUsK0JBQ2I7QUFBQSx1Q0FBQyxtV0FBSyxNQUFNSCxlQUFlcEIsVUFBVXFCLE9BQU8sR0FBRyxNQUFNLE1BQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdEO0FBQUEsZ0JBQ3hELHVCQUFDLDBZQUFLLFdBQVUsY0FBY3JCLG9CQUFVcUIsV0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0Q7QUFBQSxtQkFGbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMscVdBQU1YLDBCQUFnQlYsVUFBVVcsU0FBUyxLQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0QztBQUFBLGNBQzNDWCxVQUFVd0IsWUFDVCx1QkFBQyw2WUFBSztBQUFBO0FBQUEsZ0JBQVd4QixVQUFVd0I7QUFBQUEsbUJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9DO0FBQUEsaUJBUHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBU0E7QUFBQSxlQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVCQTtBQUFBLFVBRUEsdUJBQUMsNFpBQUksV0FBVSwrQkFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNcEIsY0FBYyxDQUFDRCxVQUFVO0FBQUEsY0FDeEMsV0FBVTtBQUFBLGNBRVYsaUNBQUMsbVdBQUssTUFBTUEsYUFBYSxjQUFjLGVBQWUsTUFBTSxNQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErRDtBQUFBO0FBQUEsWUFKakU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsYUFqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWtDQTtBQUFBLFFBR0EsdUJBQUMsbWFBQUksV0FBVSxvQ0FDYjtBQUFBLGlDQUFDLDRaQUFJLFdBQVUsK0JBQ1pIO0FBQUFBLHNCQUFVeUIsaUJBQ1Q7QUFBQSxjQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFDQyxLQUFLekIsVUFBVXlCO0FBQUFBLGdCQUNmLEtBQUt6QixVQUFVMEI7QUFBQUEsZ0JBQ2YsV0FBVTtBQUFBO0FBQUEsY0FIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFHK0M7QUFBQSxZQUdqRCx1QkFBQyxrV0FDQztBQUFBLHFDQUFDLDRaQUFJLFdBQVUsaUNBQWlDMUIsb0JBQVUwQixXQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrRTtBQUFBLGNBQ2xFLHVCQUFDLDBaQUFJLFdBQVUsK0JBQStCMUIsb0JBQVUyQixXQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnRTtBQUFBLGlCQUZsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsZUFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVlBO0FBQUEsVUFFQSx1QkFBQyxzYUFBSSxXQUFVLHVDQUNaM0Isb0JBQVU0QixTQUFTLFlBQVk1QixVQUFVNkIsVUFDeEMsdUJBQUMsNFpBQUksV0FBVSwrQkFDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ0MsS0FBSzdCLFVBQVU2QjtBQUFBQSxnQkFDZixLQUFLN0IsVUFBVTRCO0FBQUFBLGdCQUNmLFdBQVU7QUFBQTtBQUFBLGNBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRytDO0FBQUEsWUFFL0MsdUJBQUMsNlpBQUssV0FBVSwrQkFBK0I1QixvQkFBVTRCLFFBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThEO0FBQUEsZUFOaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQSxLQVRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQSxhQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMkJBO0FBQUEsUUFHQSx1QkFBQyxpWUFBSSxXQUFVLFFBQ2IsaUNBQUMsc2FBQUUsV0FBVSwrQ0FDVnpCLHVCQUNHSCxVQUFVOEIsY0FDVixHQUFHOUIsVUFBVThCLGFBQWFDLFVBQVUsR0FBRyxHQUFHLENBQUMsR0FBRy9CLFVBQVU4QixhQUFhRSxTQUFTLE1BQU0sUUFBUSxFQUFFLE1BSHBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBR0M3QixjQUNDLHVCQUFDLHdhQUFJLFdBQVUseUNBRVpIO0FBQUFBLG9CQUFVaUMsZUFBZWpDLFVBQVVpQyxhQUFhRCxTQUFTLEtBQ3hELHVCQUFDLGtXQUNDO0FBQUEsbUNBQUMsa2RBQUcsV0FBVSw4Q0FBNkMsMkJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNFO0FBQUEsWUFDdEUsdUJBQUMsc1lBQUksV0FBVSxhQUNaaEMsb0JBQVVpQyxhQUFhQztBQUFBQSxjQUFJLENBQUNDLFlBQVlDLFVBQ3ZDLHVCQUFDLHNhQUFnQixXQUFVLHVDQUN6QjtBQUFBLHVDQUFDLCthQUFLLE1BQUssYUFBWSxNQUFNLElBQUksV0FBVSx3QkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0Q7QUFBQSxnQkFDL0QsdUJBQUMsd2JBQUssV0FBVSxzREFBc0RELHdCQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpRjtBQUFBLG1CQUZ6RUMsT0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsWUFDRCxLQU5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxlQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxVQUlEcEMsVUFBVU0sU0FBUyxpQkFBaUJOLFVBQVVxQyxpQkFDN0MsdUJBQUMsa1dBQ0M7QUFBQSxtQ0FBQywwZEFBRyxXQUFVLDhDQUE2QyxpQ0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEU7QUFBQSxZQUM1RSx1QkFBQyxzYUFBSSxXQUFVLHVDQUNiO0FBQUEscUNBQUMsbWJBQUssV0FBVSwrQ0FBK0NyQyxvQkFBVXFDLGlCQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1RjtBQUFBLGNBQ3ZGLHVCQUFDLGdiQUFLLE1BQUssY0FBYSxNQUFNLElBQUksV0FBVSx3QkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0U7QUFBQSxjQUNoRSx1QkFBQyxvYkFBSyxXQUFVLGdEQUFnRHJDLG9CQUFVc0MsZ0JBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVGO0FBQUEsY0FDdkYsdUJBQUMsNmNBQUssV0FBVSw0QkFBMkI7QUFBQTtBQUFBLGdCQUFFdEMsVUFBVXVDO0FBQUFBLGdCQUFZO0FBQUEsbUJBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlGO0FBQUEsaUJBSm5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxlQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxVQUlEdkMsVUFBVU0sU0FBUyxhQUNsQix1QkFBQyxvYkFBSSxXQUFVLGlEQUNaTjtBQUFBQSxzQkFBVXdDLFlBQ1QsdUJBQUMsa1dBQ0M7QUFBQSxxQ0FBQyx1Y0FBSyxXQUFVLGlDQUFnQyx5QkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUQ7QUFBQSxjQUN6RCx1QkFBQywwWkFBSyxXQUFVLDRCQUE0QnhDLG9CQUFVd0MsWUFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0Q7QUFBQSxpQkFGakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBRUR4QyxVQUFVeUMsYUFDVCx1QkFBQyxrV0FDQztBQUFBLHFDQUFDLHdjQUFLLFdBQVUsaUNBQWdDLDBCQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwRDtBQUFBLGNBQzFELHVCQUFDLDZiQUFLLFdBQVUsNEJBQTRCekM7QUFBQUEsMEJBQVV5QztBQUFBQSxnQkFBVTtBQUFBLG1CQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1RTtBQUFBLGlCQUZ6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsZUFYSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBO0FBQUEsVUFJRHpDLFVBQVVNLFNBQVMsVUFDbEIsdUJBQUMsc2FBQUksV0FBVSx1Q0FDYjtBQUFBLG1DQUFDLGtXQUNDO0FBQUEscUNBQUMsbWNBQUssV0FBVSxpQ0FBZ0MscUJBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFEO0FBQUEsY0FDckQsdUJBQUMsdWFBQUssV0FBVSx1Q0FBdUNOLG9CQUFVMEMsWUFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEU7QUFBQSxpQkFGNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsa1dBQ0M7QUFBQSxxQ0FBQyxxY0FBSyxXQUFVLGlDQUFnQyx1QkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUQ7QUFBQSxjQUN2RCx1QkFBQyx1YUFBSyxXQUFVLHVDQUF1QzFDLG9CQUFVMkMsVUFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0U7QUFBQSxpQkFGMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLGVBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQTtBQUFBLGFBMURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0REE7QUFBQSxRQUlGLHVCQUFDLG9jQUFJLFdBQVUsaUVBQ2I7QUFBQSxpQ0FBQyw0WkFBSSxXQUFVLCtCQUNiO0FBQUEsbUNBQUMsNGpCQUFPLFdBQVUsOEpBQ2hCO0FBQUEscUNBQUMsc1lBQUssTUFBSyxpQkFBZ0IsTUFBTSxNQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvQztBQUFBLGNBQ3BDLHVCQUFDLHVZQUFLLHFCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQVc7QUFBQSxpQkFGYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFFQSx1QkFBQyw0akJBQU8sV0FBVSw4SkFDaEI7QUFBQSxxQ0FBQyw2WEFBSyxNQUFLLFFBQU8sTUFBTSxNQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyQjtBQUFBLGNBQzNCLHVCQUFDLDJZQUFLLHlCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWU7QUFBQSxpQkFGakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBRUEsdUJBQUMsNGpCQUFPLFdBQVUsOEpBQ2hCO0FBQUEscUNBQUMsaVlBQUssTUFBSyxZQUFXLE1BQU0sTUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0I7QUFBQSxjQUMvQix1QkFBQywwWUFBSyx3QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFjO0FBQUEsaUJBRmhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxlQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZUE7QUFBQSxVQUVBLHVCQUFDLDRaQUFJLFdBQVUsK0JBQ2I7QUFBQSxtQ0FBQyw2Z0JBQU8sV0FBVSx5SEFDaEIsaUNBQUMsOFhBQUssTUFBSyxTQUFRLE1BQU0sTUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEIsS0FEOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBRUEsdUJBQUMsNmdCQUFPLFdBQVUseUhBQ2hCLGlDQUFDLHVZQUFLLE1BQUssa0JBQWlCLE1BQU0sTUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUMsS0FEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLGFBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEyQkE7QUFBQSxXQTNLRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNEtBO0FBQUEsU0FuTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9MQTtBQUFBLE9BekxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwTEE7QUFFSjtBQUFFekMsR0EvUUlILGNBQVk7QUFBQTZDLEtBQVo3QztBQWlSTixlQUFlQTtBQUFhLElBQUE2QztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJJY29uIiwiSW1hZ2UiLCJBY3Rpdml0eUNhcmQiLCJhY3Rpdml0eSIsImlzTGFzdCIsIl9zIiwiaXNFeHBhbmRlZCIsInNldElzRXhwYW5kZWQiLCJnZXRBY3Rpdml0eUljb24iLCJ0eXBlIiwiZ2V0QWN0aXZpdHlDb2xvciIsImdldFByaW9yaXR5Q29sb3IiLCJwcmlvcml0eSIsImZvcm1hdFRpbWVzdGFtcCIsInRpbWVzdGFtcCIsIm5vdyIsIkRhdGUiLCJkaWZmIiwiaG91cnMiLCJNYXRoIiwiZmxvb3IiLCJkYXlzIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwiZ2V0Q2hhbm5lbEljb24iLCJjaGFubmVsIiwidGl0bGUiLCJkZWFsVmFsdWUiLCJkdXJhdGlvbiIsImNvbnRhY3RBdmF0YXIiLCJjb250YWN0IiwiY29tcGFueSIsInVzZXIiLCJhdmF0YXIiLCJkZXNjcmlwdGlvbiIsInN1YnN0cmluZyIsImxlbmd0aCIsImF0dGFjaG1lbnRzIiwibWFwIiwiYXR0YWNobWVudCIsImluZGV4IiwicHJldmlvdXNTdGFnZSIsImN1cnJlbnRTdGFnZSIsInByb2JhYmlsaXR5IiwibG9jYXRpb24iLCJhdHRlbmRlZXMiLCJjYWxsVHlwZSIsInN0YXR1cyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQWN0aXZpdHlDYXJkLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCBJY29uIGZyb20gJ2NvbXBvbmVudHMvQXBwSWNvbic7XHJcbmltcG9ydCBJbWFnZSBmcm9tICdjb21wb25lbnRzL0FwcEltYWdlJztcclxuXHJcbmNvbnN0IEFjdGl2aXR5Q2FyZCA9ICh7IGFjdGl2aXR5LCBpc0xhc3QgfSkgPT4ge1xyXG4gIGNvbnN0IFtpc0V4cGFuZGVkLCBzZXRJc0V4cGFuZGVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgY29uc3QgZ2V0QWN0aXZpdHlJY29uID0gKHR5cGUpID0+IHtcclxuICAgIHN3aXRjaCAodHlwZSkge1xyXG4gICAgICBjYXNlICdlbWFpbCc6XHJcbiAgICAgICAgcmV0dXJuICdNYWlsJztcclxuICAgICAgY2FzZSAnY2FsbCc6XHJcbiAgICAgICAgcmV0dXJuICdQaG9uZSc7XHJcbiAgICAgIGNhc2UgJ21lZXRpbmcnOlxyXG4gICAgICAgIHJldHVybiAnQ2FsZW5kYXInO1xyXG4gICAgICBjYXNlICdkZWFsX3VwZGF0ZSc6XHJcbiAgICAgICAgcmV0dXJuICdUcmVuZGluZ1VwJztcclxuICAgICAgY2FzZSAndGFzayc6XHJcbiAgICAgICAgcmV0dXJuICdDaGVja1NxdWFyZSc7XHJcbiAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgcmV0dXJuICdBY3Rpdml0eSc7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZ2V0QWN0aXZpdHlDb2xvciA9ICh0eXBlKSA9PiB7XHJcbiAgICBzd2l0Y2ggKHR5cGUpIHtcclxuICAgICAgY2FzZSAnZW1haWwnOlxyXG4gICAgICAgIHJldHVybiAndGV4dC1ibHVlLTYwMCBiZy1ibHVlLTUwJztcclxuICAgICAgY2FzZSAnY2FsbCc6XHJcbiAgICAgICAgcmV0dXJuICd0ZXh0LWdyZWVuLTYwMCBiZy1ncmVlbi01MCc7XHJcbiAgICAgIGNhc2UgJ21lZXRpbmcnOlxyXG4gICAgICAgIHJldHVybiAndGV4dC1wdXJwbGUtNjAwIGJnLXB1cnBsZS01MCc7XHJcbiAgICAgIGNhc2UgJ2RlYWxfdXBkYXRlJzpcclxuICAgICAgICByZXR1cm4gJ3RleHQtb3JhbmdlLTYwMCBiZy1vcmFuZ2UtNTAnO1xyXG4gICAgICBjYXNlICd0YXNrJzpcclxuICAgICAgICByZXR1cm4gJ3RleHQtaW5kaWdvLTYwMCBiZy1pbmRpZ28tNTAnO1xyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHJldHVybiAndGV4dC1ncmF5LTYwMCBiZy1ncmF5LTUwJztcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBnZXRQcmlvcml0eUNvbG9yID0gKHByaW9yaXR5KSA9PiB7XHJcbiAgICBzd2l0Y2ggKHByaW9yaXR5KSB7XHJcbiAgICAgIGNhc2UgJ2hpZ2gnOlxyXG4gICAgICAgIHJldHVybiAndGV4dC1lcnJvciBiZy1lcnJvci01MCc7XHJcbiAgICAgIGNhc2UgJ21lZGl1bSc6XHJcbiAgICAgICAgcmV0dXJuICd0ZXh0LXdhcm5pbmcgYmctd2FybmluZy01MCc7XHJcbiAgICAgIGNhc2UgJ2xvdyc6XHJcbiAgICAgICAgcmV0dXJuICd0ZXh0LXN1Y2Nlc3MgYmctc3VjY2Vzcy01MCc7XHJcbiAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgcmV0dXJuICd0ZXh0LXRleHQtc2Vjb25kYXJ5IGJnLWdyYXktNTAnO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZvcm1hdFRpbWVzdGFtcCA9ICh0aW1lc3RhbXApID0+IHtcclxuICAgIGNvbnN0IG5vdyA9IG5ldyBEYXRlKCk7XHJcbiAgICBjb25zdCBkaWZmID0gbm93IC0gdGltZXN0YW1wO1xyXG4gICAgY29uc3QgaG91cnMgPSBNYXRoLmZsb29yKGRpZmYgLyAoMTAwMCAqIDYwICogNjApKTtcclxuICAgIGNvbnN0IGRheXMgPSBNYXRoLmZsb29yKGhvdXJzIC8gMjQpO1xyXG5cclxuICAgIGlmIChob3VycyA8IDEpIHtcclxuICAgICAgcmV0dXJuICdKdXN0IG5vdyc7XHJcbiAgICB9IGVsc2UgaWYgKGhvdXJzIDwgMjQpIHtcclxuICAgICAgcmV0dXJuIGAke2hvdXJzfWggYWdvYDtcclxuICAgIH0gZWxzZSBpZiAoZGF5cyA8IDcpIHtcclxuICAgICAgcmV0dXJuIGAke2RheXN9ZCBhZ29gO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHRpbWVzdGFtcD8udG9Mb2NhbGVEYXRlU3RyaW5nKCk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZ2V0Q2hhbm5lbEljb24gPSAoY2hhbm5lbCkgPT4ge1xyXG4gICAgc3dpdGNoIChjaGFubmVsKSB7XHJcbiAgICAgIGNhc2UgJ2dtYWlsJzpcclxuICAgICAgICByZXR1cm4gJ01haWwnO1xyXG4gICAgICBjYXNlICd0d2lsaW8nOlxyXG4gICAgICAgIHJldHVybiAnUGhvbmUnO1xyXG4gICAgICBjYXNlICdjYWxlbmRhcic6XHJcbiAgICAgICAgcmV0dXJuICdDYWxlbmRhcic7XHJcbiAgICAgIGNhc2UgJ3N5c3RlbSc6XHJcbiAgICAgICAgcmV0dXJuICdTZXR0aW5ncyc7XHJcbiAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgcmV0dXJuICdBY3Rpdml0eSc7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuICAgICAgey8qIFRpbWVsaW5lIExpbmUgKi99XHJcbiAgICAgIHshaXNMYXN0ICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGxlZnQtNiB0b3AtMTYgdy0wLjUgaC1mdWxsIGJnLWJvcmRlclwiPjwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggc3BhY2UteC00XCI+XHJcbiAgICAgICAgey8qIFRpbWVsaW5lIEljb24gKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9e2B3LTEyIGgtMTIgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyICR7Z2V0QWN0aXZpdHlDb2xvcihhY3Rpdml0eT8udHlwZSl9IGZsZXgtc2hyaW5rLTBgfT5cclxuICAgICAgICAgIDxJY29uIG5hbWU9e2dldEFjdGl2aXR5SWNvbihhY3Rpdml0eT8udHlwZSl9IHNpemU9ezIwfSAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogQWN0aXZpdHkgQ29udGVudCAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBjYXJkIHAtNlwiPlxyXG4gICAgICAgICAgey8qIEhlYWRlciAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gbWItNFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0zIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC10ZXh0LXByaW1hcnlcIj57YWN0aXZpdHk/LnRpdGxlfTwvaDM+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0yIHB5LTEgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1tZWRpdW0gJHtnZXRQcmlvcml0eUNvbG9yKGFjdGl2aXR5Py5wcmlvcml0eSl9YH0+XHJcbiAgICAgICAgICAgICAgICAgIHthY3Rpdml0eT8ucHJpb3JpdHl9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICB7YWN0aXZpdHk/LmRlYWxWYWx1ZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIgcHktMSBiZy1zdWNjZXNzLTUwIHRleHQtc3VjY2VzcyByb3VuZGVkLWZ1bGwgdGV4dC14cyBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHthY3Rpdml0eT8uZGVhbFZhbHVlfVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC00IHRleHQtc20gdGV4dC10ZXh0LXNlY29uZGFyeVwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT17Z2V0Q2hhbm5lbEljb24oYWN0aXZpdHk/LmNoYW5uZWwpfSBzaXplPXsxNH0gLz5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2FwaXRhbGl6ZVwiPnthY3Rpdml0eT8uY2hhbm5lbH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxzcGFuPntmb3JtYXRUaW1lc3RhbXAoYWN0aXZpdHk/LnRpbWVzdGFtcCl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAge2FjdGl2aXR5Py5kdXJhdGlvbiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuPkR1cmF0aW9uOiB7YWN0aXZpdHk/LmR1cmF0aW9ufTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTJcIj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc0V4cGFuZGVkKCFpc0V4cGFuZGVkKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiB0ZXh0LXRleHQtc2Vjb25kYXJ5IGhvdmVyOnRleHQtdGV4dC1wcmltYXJ5IGhvdmVyOmJnLXN1cmZhY2UtaG92ZXIgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0xNTAgZWFzZS1vdXRcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9e2lzRXhwYW5kZWQgPyBcIkNoZXZyb25VcFwiIDogXCJDaGV2cm9uRG93blwifSBzaXplPXsxNn0gLz5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogQ29udGFjdCAmIENvbXBhbnkgSW5mbyAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC00IG1iLTRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTNcIj5cclxuICAgICAgICAgICAgICB7YWN0aXZpdHk/LmNvbnRhY3RBdmF0YXIgJiYgKFxyXG4gICAgICAgICAgICAgICAgPEltYWdlXHJcbiAgICAgICAgICAgICAgICAgIHNyYz17YWN0aXZpdHk/LmNvbnRhY3RBdmF0YXJ9XHJcbiAgICAgICAgICAgICAgICAgIGFsdD17YWN0aXZpdHk/LmNvbnRhY3R9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctOCBoLTggcm91bmRlZC1mdWxsIG9iamVjdC1jb3ZlclwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnlcIj57YWN0aXZpdHk/LmNvbnRhY3R9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC10ZXh0LXNlY29uZGFyeVwiPnthY3Rpdml0eT8uY29tcGFueX08L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMyBtbC1hdXRvXCI+XHJcbiAgICAgICAgICAgICAge2FjdGl2aXR5Py51c2VyICE9PSAnU3lzdGVtJyAmJiBhY3Rpdml0eT8uYXZhdGFyICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbWFnZVxyXG4gICAgICAgICAgICAgICAgICAgIHNyYz17YWN0aXZpdHk/LmF2YXRhcn1cclxuICAgICAgICAgICAgICAgICAgICBhbHQ9e2FjdGl2aXR5Py51c2VyfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNiBoLTYgcm91bmRlZC1mdWxsIG9iamVjdC1jb3ZlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC10ZXh0LXNlY29uZGFyeVwiPnthY3Rpdml0eT8udXNlcn08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiBEZXNjcmlwdGlvbiBQcmV2aWV3ICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00XCI+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtdGV4dC1zZWNvbmRhcnkgdGV4dC1zbSBsZWFkaW5nLXJlbGF4ZWRcIj5cclxuICAgICAgICAgICAgICB7aXNFeHBhbmRlZCBcclxuICAgICAgICAgICAgICAgID8gYWN0aXZpdHk/LmRlc2NyaXB0aW9uXHJcbiAgICAgICAgICAgICAgICA6IGAke2FjdGl2aXR5Py5kZXNjcmlwdGlvbj8uc3Vic3RyaW5nKDAsIDE1MCl9JHthY3Rpdml0eT8uZGVzY3JpcHRpb24/Lmxlbmd0aCA+IDE1MCA/ICcuLi4nIDogJyd9YFxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIEFkZGl0aW9uYWwgSW5mbyAqL31cclxuICAgICAgICAgIHtpc0V4cGFuZGVkICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTQgYm9yZGVyLXQgYm9yZGVyLWJvcmRlciBwdC00XCI+XHJcbiAgICAgICAgICAgICAgey8qIEF0dGFjaG1lbnRzICovfVxyXG4gICAgICAgICAgICAgIHthY3Rpdml0eT8uYXR0YWNobWVudHMgJiYgYWN0aXZpdHk/LmF0dGFjaG1lbnRzPy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IG1iLTJcIj5BdHRhY2htZW50czwvaDQ+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2FjdGl2aXR5Py5hdHRhY2htZW50cz8ubWFwKChhdHRhY2htZW50LCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2luZGV4fSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTIgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiUGFwZXJjbGlwXCIgc2l6ZT17MTR9IGNsYXNzTmFtZT1cInRleHQtdGV4dC10ZXJ0aWFyeVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeSBob3Zlcjp0ZXh0LXByaW1hcnktNzAwIGN1cnNvci1wb2ludGVyXCI+e2F0dGFjaG1lbnR9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgey8qIERlYWwgU3RhZ2UgSW5mbyAqL31cclxuICAgICAgICAgICAgICB7YWN0aXZpdHk/LnR5cGUgPT09ICdkZWFsX3VwZGF0ZScgJiYgYWN0aXZpdHk/LnByZXZpb3VzU3RhZ2UgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItMlwiPlN0YWdlIFByb2dyZXNzaW9uPC9oND5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTIgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIgcHktMSBiZy1ncmF5LTEwMCB0ZXh0LWdyYXktNzAwIHJvdW5kZWRcIj57YWN0aXZpdHk/LnByZXZpb3VzU3RhZ2V9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJBcnJvd1JpZ2h0XCIgc2l6ZT17MTR9IGNsYXNzTmFtZT1cInRleHQtdGV4dC10ZXJ0aWFyeVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMiBweS0xIGJnLXByaW1hcnktNTAgdGV4dC1wcmltYXJ5IHJvdW5kZWRcIj57YWN0aXZpdHk/LmN1cnJlbnRTdGFnZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC10ZXh0LXNlY29uZGFyeSBtbC0yXCI+KHthY3Rpdml0eT8ucHJvYmFiaWxpdHl9JSBwcm9iYWJpbGl0eSk8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgey8qIE1lZXRpbmcgRGV0YWlscyAqL31cclxuICAgICAgICAgICAgICB7YWN0aXZpdHk/LnR5cGUgPT09ICdtZWV0aW5nJyAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTQgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICB7YWN0aXZpdHk/LmxvY2F0aW9uICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnlcIj5Mb2NhdGlvbjo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5IG1sLTJcIj57YWN0aXZpdHk/LmxvY2F0aW9ufTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAge2FjdGl2aXR5Py5hdHRlbmRlZXMgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeVwiPkF0dGVuZGVlczo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5IG1sLTJcIj57YWN0aXZpdHk/LmF0dGVuZGVlc30gcGVvcGxlPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgey8qIENhbGwgRGV0YWlscyAqL31cclxuICAgICAgICAgICAgICB7YWN0aXZpdHk/LnR5cGUgPT09ICdjYWxsJyAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtNCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnlcIj5UeXBlOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5IG1sLTIgY2FwaXRhbGl6ZVwiPnthY3Rpdml0eT8uY2FsbFR5cGV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeVwiPlN0YXR1czo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC10ZXh0LXNlY29uZGFyeSBtbC0yIGNhcGl0YWxpemVcIj57YWN0aXZpdHk/LnN0YXR1c308L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIHsvKiBBY3Rpb24gQnV0dG9ucyAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB0LTQgYm9yZGVyLXQgYm9yZGVyLWJvcmRlclwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMlwiPlxyXG4gICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yIHB4LTMgcHktMS41IHRleHQtc20gdGV4dC10ZXh0LXNlY29uZGFyeSBob3Zlcjp0ZXh0LXByaW1hcnkgaG92ZXI6YmctcHJpbWFyeS01MCByb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTE1MCBlYXNlLW91dFwiPlxyXG4gICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIk1lc3NhZ2VTcXVhcmVcIiBzaXplPXsxNH0gLz5cclxuICAgICAgICAgICAgICAgIDxzcGFuPlJlcGx5PC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yIHB4LTMgcHktMS41IHRleHQtc20gdGV4dC10ZXh0LXNlY29uZGFyeSBob3Zlcjp0ZXh0LXByaW1hcnkgaG92ZXI6YmctcHJpbWFyeS01MCByb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTE1MCBlYXNlLW91dFwiPlxyXG4gICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIlBsdXNcIiBzaXplPXsxNH0gLz5cclxuICAgICAgICAgICAgICAgIDxzcGFuPkZvbGxvdy11cDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMiBweC0zIHB5LTEuNSB0ZXh0LXNtIHRleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC1wcmltYXJ5IGhvdmVyOmJnLXByaW1hcnktNTAgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0xNTAgZWFzZS1vdXRcIj5cclxuICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJDYWxlbmRhclwiIHNpemU9ezE0fSAvPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4+U2NoZWR1bGU8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTJcIj5cclxuICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInAtMS41IHRleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC10ZXh0LXByaW1hcnkgaG92ZXI6Ymctc3VyZmFjZS1ob3ZlciByb3VuZGVkIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTE1MCBlYXNlLW91dFwiPlxyXG4gICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIlNoYXJlXCIgc2l6ZT17MTR9IC8+XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJwLTEuNSB0ZXh0LXRleHQtc2Vjb25kYXJ5IGhvdmVyOnRleHQtdGV4dC1wcmltYXJ5IGhvdmVyOmJnLXN1cmZhY2UtaG92ZXIgcm91bmRlZCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0xNTAgZWFzZS1vdXRcIj5cclxuICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJNb3JlSG9yaXpvbnRhbFwiIHNpemU9ezE0fSAvPlxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBBY3Rpdml0eUNhcmQ7Il0sImZpbGUiOiJEOi9jdXJyZW50IHByb2plY3RzL2NsYXVkZS1jb2RlL3NyYy9wYWdlcy9hY3Rpdml0eS10aW1lbGluZS9jb21wb25lbnRzL0FjdGl2aXR5Q2FyZC5qc3gifQ==