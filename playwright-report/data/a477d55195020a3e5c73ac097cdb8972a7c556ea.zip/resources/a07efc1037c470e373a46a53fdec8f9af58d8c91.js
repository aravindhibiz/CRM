import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AppImage.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/components/AppImage.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
function Image({
  src,
  alt = "Image Name",
  className = "",
  ...props
}) {
  return /* @__PURE__ */ jsxDEV(
    "img",
    {
      "data-component-id": "src\\components\\AppImage.jsx:11:4",
      "data-component-path": "src\\components\\AppImage.jsx",
      "data-component-line": "11",
      "data-component-file": "AppImage.jsx",
      "data-component-name": "img",
      "data-component-content": "%7B%22elementName%22%3A%22img%22%2C%22src%22%3A%22%5Bvar%3Asrc%5D%22%2C%22alt%22%3A%22%5Bvar%3Aalt%5D%22%2C%22className%22%3A%22%5Bvar%3AclassName%5D%22%2C%22%5Bspread%5D%22%3A%22true%22%7D",
      src,
      alt,
      className,
      onError: (e) => {
        e.target.src = "/assets/images/no_image.png";
      },
      ...props
    },
    void 0,
    false,
    {
      fileName: "D:/current projects/claude-code/src/components/AppImage.jsx",
      lineNumber: 11,
      columnNumber: 5
    },
    this
  );
}
_c = Image;
export default Image;
var _c;
$RefreshReg$(_c, "Image");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/components/AppImage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/components/AppImage.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVUk7QUFWSixPQUFPQSxvQkFBa0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFekIsU0FBU0MsTUFBTTtBQUFBLEVBQ2JDO0FBQUFBLEVBQ0FDLE1BQU07QUFBQSxFQUNOQyxZQUFZO0FBQUEsRUFDWixHQUFHQztBQUNMLEdBQUc7QUFFRCxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFDQztBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQSxTQUFTLENBQUNDLE1BQU07QUFDZEEsVUFBRUMsT0FBT0wsTUFBTTtBQUFBLE1BQ2pCO0FBQUEsTUFDQSxHQUFJRztBQUFBQTtBQUFBQSxJQVBOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU9ZO0FBR2hCO0FBQUNHLEtBbEJRUDtBQW9CVCxlQUFlQTtBQUFNLElBQUFPO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsIkltYWdlIiwic3JjIiwiYWx0IiwiY2xhc3NOYW1lIiwicHJvcHMiLCJlIiwidGFyZ2V0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBcHBJbWFnZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuXHJcbmZ1bmN0aW9uIEltYWdlKHtcclxuICBzcmMsXHJcbiAgYWx0ID0gXCJJbWFnZSBOYW1lXCIsXHJcbiAgY2xhc3NOYW1lID0gXCJcIixcclxuICAuLi5wcm9wc1xyXG59KSB7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8aW1nXHJcbiAgICAgIHNyYz17c3JjfVxyXG4gICAgICBhbHQ9e2FsdH1cclxuICAgICAgY2xhc3NOYW1lPXtjbGFzc05hbWV9XHJcbiAgICAgIG9uRXJyb3I9eyhlKSA9PiB7XHJcbiAgICAgICAgZS50YXJnZXQuc3JjID0gXCIvYXNzZXRzL2ltYWdlcy9ub19pbWFnZS5wbmdcIlxyXG4gICAgICB9fVxyXG4gICAgICB7Li4ucHJvcHN9XHJcbiAgICAvPlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEltYWdlO1xyXG4iXSwiZmlsZSI6IkQ6L2N1cnJlbnQgcHJvamVjdHMvY2xhdWRlLWNvZGUvc3JjL2NvbXBvbmVudHMvQXBwSW1hZ2UuanN4In0=