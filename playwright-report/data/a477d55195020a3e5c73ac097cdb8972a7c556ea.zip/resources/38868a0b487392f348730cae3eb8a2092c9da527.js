import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/contact-management/components/ComposeEmailModal.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import Icon from "/src/components/AppIcon.jsx";
import emailService from "/src/services/emailService.js";
import geminiService from "/src/services/geminiService.js";
const ComposeEmailModal = ({ contact, onClose, onSend }) => {
  _s();
  const [emailData, setEmailData] = useState({
    to: contact?.email,
    subject: "",
    body: "",
    cc: "",
    bcc: ""
  });
  const [showCcBcc, setShowCcBcc] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedContent, setGeneratedContent] = useState(null);
  const [showPreview, setShowPreview] = useState(false);
  const handleChange = (e) => {
    const { name, value } = e?.target;
    setEmailData({
      ...emailData,
      [name]: value
    });
  };
  const handleSubmit = async (e) => {
    e?.preventDefault();
    setIsSending(true);
    try {
      console.log("Submitting email with data:", {
        to: emailData?.to,
        subject: emailData?.subject,
        body: emailData?.body,
        cc: emailData?.cc,
        bcc: emailData?.bcc,
        contactId: contact?.id
      });
      const response = await emailService.sendEmail({
        to: emailData?.to,
        subject: emailData?.subject,
        body: emailData?.body,
        cc: emailData?.cc,
        bcc: emailData?.bcc,
        contactId: contact?.id
      });
      console.log("Email response:", response);
      onSend({
        ...emailData,
        timestamp: (/* @__PURE__ */ new Date())?.toISOString(),
        contactId: contact?.id,
        status: response?.status || "sent"
      });
      onClose();
    } catch (error) {
      console.error("Email sending failed:", error);
      let errorMessage = "Failed to send email. Please try again.";
      if (error.response?.data?.error) {
        errorMessage = `Failed to send email: ${error.response.data.error}`;
      } else if (error.message) {
        errorMessage = `Failed to send email: ${error.message}`;
      }
      alert(errorMessage);
    } finally {
      setIsSending(false);
    }
  };
  const handleGenerateEmail = async () => {
    try {
      setIsGenerating(true);
      const generated = await geminiService.generateEmailContent(
        contact,
        emailData.subject,
        emailData.body
      );
      setGeneratedContent(generated);
      setShowPreview(true);
    } catch (error) {
      console.error("Failed to generate email content:", error);
      alert("Failed to generate email content. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };
  const handleUseGenerated = () => {
    if (generatedContent) {
      setEmailData({
        ...emailData,
        subject: generatedContent.subject,
        body: generatedContent.body
      });
      setShowPreview(false);
      setGeneratedContent(null);
    }
  };
  const handleDiscardGenerated = () => {
    setShowPreview(false);
    setGeneratedContent(null);
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:115:6", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "115", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20z-1100%20overflow-y-auto%22%7D", className: "fixed inset-0 z-1100 overflow-y-auto", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:116:8", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "116", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-center%20min-h-screen%20px-4%20pt-4%20pb-20%20text-center%20sm%3Ablock%20sm%3Ap-0%22%7D", className: "flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:117:10", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "117", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20transition-opacity%22%7D", className: "fixed inset-0 transition-opacity", "aria-hidden": "true", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:118:12", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "118", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22absolute%20inset-0%20bg-black%20bg-opacity-50%22%7D", className: "absolute inset-0 bg-black bg-opacity-50" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
        lineNumber: 118,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
        lineNumber: 117,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:121:8", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "121", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22hidden%20sm%3Ainline-block%20sm%3Aalign-middle%20sm%3Ah-screen%22%2C%22textContent%22%3A%22%E2%80%8B%22%7D", className: "hidden sm:inline-block sm:align-middle sm:h-screen", "aria-hidden": "true", children: "​" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
        lineNumber: 121,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:123:8", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "123", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22inline-block%20align-bottom%20bg-surface%20rounded-lg%20text-left%20overflow-hidden%20shadow-xl%20transform%20transition-all%20sm%3Amy-8%20sm%3Aalign-middle%20sm%3Amax-w-lg%20sm%3Aw-full%20md%3Amax-w-2xl%22%7D", className: "inline-block align-bottom bg-surface rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full md:max-w-2xl", children: /* @__PURE__ */ jsxDEV("form", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:124:10", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "124", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "form", "data-component-content": "%7B%22elementName%22%3A%22form%22%7D", onSubmit: handleSubmit, children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:125:12", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "125", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22px-6%20py-4%20border-b%20border-border%20flex%20justify-between%20items-center%22%7D", className: "px-6 py-4 border-b border-border flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:126:14", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "126", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%2C%22textContent%22%3A%22Compose%20Email%22%7D", className: "text-lg font-semibold text-text-primary", children: "Compose Email" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
            lineNumber: 126,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:127:14",
              "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx",
              "data-component-line": "127",
              "data-component-file": "ComposeEmailModal.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22button%22%2C%22className%22%3A%22text-text-secondary%20hover%3Atext-text-primary%22%7D",
              type: "button",
              onClick: onClose,
              className: "text-text-secondary hover:text-text-primary",
              children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:132:16", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "132", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22X%22%7D", name: "X", size: 20 }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
                lineNumber: 132,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
              lineNumber: 127,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
          lineNumber: 125,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:136:12", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "136", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22px-6%20py-5%22%7D", className: "px-6 py-5", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:137:14", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "137", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-4%22%7D", className: "space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:138:16", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "138", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:139:18", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "139", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-secondary%20mb-1%22%2C%22textContent%22%3A%22To%22%7D", className: "block text-sm font-medium text-text-secondary mb-1", children: "To" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
              lineNumber: 139,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:142:18", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "142", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%22%7D", className: "flex items-center", children: /* @__PURE__ */ jsxDEV(
              "input",
              {
                "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:143:20",
                "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx",
                "data-component-line": "143",
                "data-component-file": "ComposeEmailModal.jsx",
                "data-component-name": "input",
                "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22email%22%2C%22name%22%3A%22to%22%2C%22className%22%3A%22input-field%22%7D",
                type: "email",
                name: "to",
                value: emailData?.to,
                onChange: handleChange,
                className: "input-field",
                readOnly: true
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
                lineNumber: 143,
                columnNumber: 21
              },
              this
            ) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
              lineNumber: 142,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
            lineNumber: 138,
            columnNumber: 17
          }, this),
          showCcBcc && /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:156:20", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "156", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:157:22", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "157", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-secondary%20mb-1%22%2C%22textContent%22%3A%22Cc%22%7D", className: "block text-sm font-medium text-text-secondary mb-1", children: "Cc" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
                lineNumber: 157,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:160:22",
                  "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx",
                  "data-component-line": "160",
                  "data-component-file": "ComposeEmailModal.jsx",
                  "data-component-name": "input",
                  "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22text%22%2C%22name%22%3A%22cc%22%2C%22className%22%3A%22input-field%22%7D",
                  type: "text",
                  name: "cc",
                  value: emailData?.cc,
                  onChange: handleChange,
                  placeholder: "email@example.com, another@example.com",
                  className: "input-field"
                },
                void 0,
                false,
                {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
                  lineNumber: 160,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
              lineNumber: 156,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:170:20", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "170", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:171:22", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "171", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-secondary%20mb-1%22%2C%22textContent%22%3A%22Bcc%22%7D", className: "block text-sm font-medium text-text-secondary mb-1", children: "Bcc" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
                lineNumber: 171,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:174:22",
                  "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx",
                  "data-component-line": "174",
                  "data-component-file": "ComposeEmailModal.jsx",
                  "data-component-name": "input",
                  "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22text%22%2C%22name%22%3A%22bcc%22%2C%22className%22%3A%22input-field%22%7D",
                  type: "text",
                  name: "bcc",
                  value: emailData?.bcc,
                  onChange: handleChange,
                  placeholder: "email@example.com, another@example.com",
                  className: "input-field"
                },
                void 0,
                false,
                {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
                  lineNumber: 174,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
              lineNumber: 170,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
            lineNumber: 155,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:186:16", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "186", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:187:18", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "187", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-secondary%20mb-1%22%2C%22textContent%22%3A%22Subject%22%7D", className: "block text-sm font-medium text-text-secondary mb-1", children: "Subject" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
              lineNumber: 187,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:190:18",
                "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx",
                "data-component-line": "190",
                "data-component-file": "ComposeEmailModal.jsx",
                "data-component-name": "input",
                "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22text%22%2C%22name%22%3A%22subject%22%2C%22className%22%3A%22input-field%22%7D",
                type: "text",
                name: "subject",
                value: emailData?.subject,
                onChange: handleChange,
                placeholder: "Enter email subject",
                className: "input-field",
                required: true
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
                lineNumber: 190,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
            lineNumber: 186,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:201:16", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "201", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:202:18", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "202", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-secondary%20mb-1%22%2C%22textContent%22%3A%22Message%22%7D", className: "block text-sm font-medium text-text-secondary mb-1", children: "Message" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
              lineNumber: 202,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "textarea",
              {
                "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:205:18",
                "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx",
                "data-component-line": "205",
                "data-component-file": "ComposeEmailModal.jsx",
                "data-component-name": "textarea",
                "data-component-content": "%7B%22elementName%22%3A%22textarea%22%2C%22name%22%3A%22body%22%2C%22className%22%3A%22input-field%22%7D",
                name: "body",
                value: emailData?.body,
                onChange: handleChange,
                rows: 8,
                placeholder: "Write your message here...",
                className: "input-field",
                required: true
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
                lineNumber: 205,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
            lineNumber: 201,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
          lineNumber: 137,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
          lineNumber: 136,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:218:12", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "218", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22px-6%20py-4%20border-t%20border-border%20flex%20justify-between%22%7D", className: "px-6 py-4 border-t border-border flex justify-between", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:219:14", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "219", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-4%22%7D", className: "flex items-center space-x-4", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:220:16",
                "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx",
                "data-component-line": "220",
                "data-component-file": "ComposeEmailModal.jsx",
                "data-component-name": "button",
                "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22button%22%2C%22className%22%3A%22text-text-secondary%20hover%3Atext-text-primary%20text-sm%22%2C%22textContent%22%3A%22Cc%2FBcc%22%7D",
                type: "button",
                onClick: () => setShowCcBcc(!showCcBcc),
                className: "text-text-secondary hover:text-text-primary text-sm",
                children: [
                  showCcBcc ? "Hide" : "Show",
                  " Cc/Bcc"
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
                lineNumber: 220,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:227:16",
                "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx",
                "data-component-line": "227",
                "data-component-file": "ComposeEmailModal.jsx",
                "data-component-name": "button",
                "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22button%22%2C%22className%22%3A%22inline-flex%20items-center%20px-3%20py-1.5%20bg-gradient-to-r%20from-purple-500%20to-indigo-500%20text-white%20rounded-md%20hover%3Afrom-purple-600%20hover%3Ato-indigo-600%20transition-all%20duration-150%20ease-out%20text-sm%20disabled%3Aopacity-50%20disabled%3Acursor-not-allowed%22%7D",
                type: "button",
                onClick: handleGenerateEmail,
                disabled: isGenerating,
                className: "inline-flex items-center px-3 py-1.5 bg-gradient-to-r from-purple-500 to-indigo-500 text-white rounded-md hover:from-purple-600 hover:to-indigo-600 transition-all duration-150 ease-out text-sm disabled:opacity-50 disabled:cursor-not-allowed",
                children: isGenerating ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
                  /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:235:22", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "235", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Loader%22%2C%22className%22%3A%22animate-spin%20mr-1.5%22%7D", name: "Loader", size: 14, className: "animate-spin mr-1.5" }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
                    lineNumber: 235,
                    columnNumber: 23
                  }, this),
                  "Generating..."
                ] }, void 0, true, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
                  lineNumber: 234,
                  columnNumber: 21
                }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
                  /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:240:22", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "240", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Sparkles%22%2C%22className%22%3A%22mr-1.5%22%7D", name: "Sparkles", size: 14, className: "mr-1.5" }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
                    lineNumber: 240,
                    columnNumber: 23
                  }, this),
                  "Generate Email"
                ] }, void 0, true, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
                  lineNumber: 239,
                  columnNumber: 21
                }, this)
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
                lineNumber: 227,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:245:16",
                "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx",
                "data-component-line": "245",
                "data-component-file": "ComposeEmailModal.jsx",
                "data-component-name": "button",
                "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22button%22%2C%22className%22%3A%22text-text-secondary%20hover%3Atext-text-primary%22%7D",
                type: "button",
                className: "text-text-secondary hover:text-text-primary",
                children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:249:18", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "249", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Paperclip%22%7D", name: "Paperclip", size: 16 }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
                  lineNumber: 249,
                  columnNumber: 19
                }, this)
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
                lineNumber: 245,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:251:16",
                "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx",
                "data-component-line": "251",
                "data-component-file": "ComposeEmailModal.jsx",
                "data-component-name": "button",
                "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22button%22%2C%22className%22%3A%22text-text-secondary%20hover%3Atext-text-primary%22%7D",
                type: "button",
                className: "text-text-secondary hover:text-text-primary",
                children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:255:18", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "255", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Image%22%7D", name: "Image", size: 16 }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
                  lineNumber: 255,
                  columnNumber: 19
                }, this)
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
                lineNumber: 251,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
            lineNumber: 219,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:259:14", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "259", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20space-x-3%22%7D", className: "flex space-x-3", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:260:16",
                "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx",
                "data-component-line": "260",
                "data-component-file": "ComposeEmailModal.jsx",
                "data-component-name": "button",
                "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22button%22%2C%22className%22%3A%22px-4%20py-2%20border%20border-border%20rounded-lg%20text-text-secondary%20hover%3Atext-text-primary%20hover%3Abg-surface-hover%20transition-all%20duration-150%20ease-out%22%2C%22textContent%22%3A%22Cancel%22%7D",
                type: "button",
                onClick: onClose,
                className: "px-4 py-2 border border-border rounded-lg text-text-secondary hover:text-text-primary hover:bg-surface-hover transition-all duration-150 ease-out",
                children: "Cancel"
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
                lineNumber: 260,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:267:16",
                "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx",
                "data-component-line": "267",
                "data-component-file": "ComposeEmailModal.jsx",
                "data-component-name": "button",
                "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22submit%22%7D",
                type: "submit",
                disabled: isSending || !emailData?.subject || !emailData?.body,
                className: `btn-primary inline-flex items-center ${isSending || !emailData?.subject || !emailData?.body ? "opacity-50 cursor-not-allowed" : ""}`,
                children: isSending ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
                  /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:277:22", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "277", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Loader%22%2C%22className%22%3A%22animate-spin%20mr-2%22%7D", name: "Loader", size: 16, className: "animate-spin mr-2" }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
                    lineNumber: 277,
                    columnNumber: 23
                  }, this),
                  "Sending..."
                ] }, void 0, true, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
                  lineNumber: 276,
                  columnNumber: 21
                }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
                  /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:283:22", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "283", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Send%22%2C%22className%22%3A%22mr-2%22%7D", name: "Send", size: 16, className: "mr-2" }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
                    lineNumber: 283,
                    columnNumber: 23
                  }, this),
                  "Send Email"
                ] }, void 0, true, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
                  lineNumber: 282,
                  columnNumber: 21
                }, this)
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
                lineNumber: 267,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
            lineNumber: 259,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
          lineNumber: 218,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
        lineNumber: 124,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
        lineNumber: 123,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
      lineNumber: 116,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
      lineNumber: 115,
      columnNumber: 7
    }, this),
    showPreview && generatedContent && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:297:6", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "297", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20z-1200%20overflow-y-auto%22%7D", className: "fixed inset-0 z-1200 overflow-y-auto", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:298:10", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "298", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-center%20min-h-screen%20px-4%20pt-4%20pb-20%20text-center%20sm%3Ablock%20sm%3Ap-0%22%7D", className: "flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:299:12", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "299", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20transition-opacity%22%7D", className: "fixed inset-0 transition-opacity", "aria-hidden": "true", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:300:14", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "300", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22absolute%20inset-0%20bg-black%20bg-opacity-50%22%7D", className: "absolute inset-0 bg-black bg-opacity-50" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
        lineNumber: 300,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
        lineNumber: 299,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:303:12", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "303", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22inline-block%20align-bottom%20bg-surface%20rounded-lg%20text-left%20overflow-hidden%20shadow-xl%20transform%20transition-all%20sm%3Amy-8%20sm%3Aalign-middle%20sm%3Amax-w-lg%20sm%3Aw-full%22%7D", className: "inline-block align-bottom bg-surface rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:304:14", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "304", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20px-6%20py-4%20border-b%20border-border%22%7D", className: "bg-surface px-6 py-4 border-b border-border", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:305:16", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "305", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:306:18", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "306", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%22%7D", className: "flex items-center", children: [
            /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:307:20", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "307", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Sparkles%22%2C%22className%22%3A%22text-purple-500%20mr-2%22%7D", name: "Sparkles", size: 20, className: "text-purple-500 mr-2" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
              lineNumber: 307,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:308:20", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "308", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-medium%20text-text-primary%22%2C%22textContent%22%3A%22Generated%20Email%20Content%22%7D", className: "text-lg font-medium text-text-primary", children: "Generated Email Content" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
              lineNumber: 308,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
            lineNumber: 306,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:312:18",
              "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx",
              "data-component-line": "312",
              "data-component-file": "ComposeEmailModal.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22text-text-secondary%20hover%3Atext-text-primary%22%7D",
              onClick: handleDiscardGenerated,
              className: "text-text-secondary hover:text-text-primary",
              children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:316:20", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "316", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22X%22%7D", name: "X", size: 20 }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
                lineNumber: 316,
                columnNumber: 21
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
              lineNumber: 312,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
          lineNumber: 305,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
          lineNumber: 304,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:321:14", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "321", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20px-6%20py-4%20max-h-96%20overflow-y-auto%22%7D", className: "bg-surface px-6 py-4 max-h-96 overflow-y-auto", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:322:16", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "322", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-4%22%7D", className: "space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:323:18", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "323", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:324:20", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "324", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-secondary%20mb-1%22%2C%22textContent%22%3A%22Generated%20Subject%3A%22%7D", className: "block text-sm font-medium text-text-secondary mb-1", children: "Generated Subject:" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
              lineNumber: 324,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:327:20", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "327", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22p-3%20bg-surface-secondary%20border%20border-border%20rounded-lg%22%7D", className: "p-3 bg-surface-secondary border border-border rounded-lg", children: /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:328:22", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "328", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-primary%22%7D", className: "text-text-primary", children: generatedContent.subject }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
              lineNumber: 328,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
              lineNumber: 327,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
            lineNumber: 323,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:332:18", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "332", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:333:20", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "333", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-secondary%20mb-1%22%2C%22textContent%22%3A%22Generated%20Body%3A%22%7D", className: "block text-sm font-medium text-text-secondary mb-1", children: "Generated Body:" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
              lineNumber: 333,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:336:20", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "336", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22p-3%20bg-surface-secondary%20border%20border-border%20rounded-lg%22%7D", className: "p-3 bg-surface-secondary border border-border rounded-lg", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:337:22", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "337", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-text-primary%20whitespace-pre-wrap%22%7D", className: "text-text-primary whitespace-pre-wrap", children: generatedContent.body }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
              lineNumber: 337,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
              lineNumber: 336,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
            lineNumber: 332,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
          lineNumber: 322,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
          lineNumber: 321,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:345:14", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "345", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20px-6%20py-4%20border-t%20border-border%22%7D", className: "bg-surface px-6 py-4 border-t border-border", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:346:16", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "346", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20space-x-3%20justify-end%22%7D", className: "flex space-x-3 justify-end", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:347:18",
              "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx",
              "data-component-line": "347",
              "data-component-file": "ComposeEmailModal.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22px-4%20py-2%20border%20border-border%20rounded-lg%20text-text-secondary%20hover%3Atext-text-primary%20hover%3Abg-surface-hover%20transition-all%20duration-150%20ease-out%22%2C%22textContent%22%3A%22Discard%22%7D",
              onClick: handleDiscardGenerated,
              className: "px-4 py-2 border border-border rounded-lg text-text-secondary hover:text-text-primary hover:bg-surface-hover transition-all duration-150 ease-out",
              children: "Discard"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
              lineNumber: 347,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:353:18",
              "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx",
              "data-component-line": "353",
              "data-component-file": "ComposeEmailModal.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22btn-primary%20inline-flex%20items-center%22%2C%22textContent%22%3A%22Use%20This%20Content%22%7D",
              onClick: handleUseGenerated,
              className: "btn-primary inline-flex items-center",
              children: [
                /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx:357:20", "data-component-path": "src\\pages\\contact-management\\components\\ComposeEmailModal.jsx", "data-component-line": "357", "data-component-file": "ComposeEmailModal.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Check%22%2C%22className%22%3A%22mr-2%22%7D", name: "Check", size: 16, className: "mr-2" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
                  lineNumber: 357,
                  columnNumber: 21
                }, this),
                "Use This Content"
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
              lineNumber: 353,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
          lineNumber: 346,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
          lineNumber: 345,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
        lineNumber: 303,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
      lineNumber: 298,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
      lineNumber: 297,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx",
    lineNumber: 114,
    columnNumber: 5
  }, this);
};
_s(ComposeEmailModal, "ARCEmSFR368Gmwhu0ux5Ex0vQIs=");
_c = ComposeEmailModal;
export default ComposeEmailModal;
var _c;
$RefreshReg$(_c, "ComposeEmailModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/contact-management/components/ComposeEmailModal.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUhZLFNBcUNNLFVBckNOOzJCQXJIWjtBQUFnQkEsTUFBUSxjQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3ZDLE9BQU9DLFVBQVU7QUFDakIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLG1CQUFtQjtBQUUxQixNQUFNQyxvQkFBb0JBLENBQUMsRUFBRUMsU0FBU0MsU0FBU0MsT0FBTyxNQUFNO0FBQUFDLEtBQUE7QUFDMUQsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUlWLFNBQVM7QUFBQSxJQUN6Q1csSUFBSU4sU0FBU087QUFBQUEsSUFDYkMsU0FBUztBQUFBLElBQ1RDLE1BQU07QUFBQSxJQUNOQyxJQUFJO0FBQUEsSUFDSkMsS0FBSztBQUFBLEVBQ1AsQ0FBQztBQUNELFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJbEIsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ21CLFdBQVdDLFlBQVksSUFBSXBCLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUNxQixjQUFjQyxlQUFlLElBQUl0QixTQUFTLEtBQUs7QUFDdEQsUUFBTSxDQUFDdUIsa0JBQWtCQyxtQkFBbUIsSUFBSXhCLFNBQVMsSUFBSTtBQUM3RCxRQUFNLENBQUN5QixhQUFhQyxjQUFjLElBQUkxQixTQUFTLEtBQUs7QUFFcEQsUUFBTTJCLGVBQWVBLENBQUNDLE1BQU07QUFDMUIsVUFBTSxFQUFFQyxNQUFNQyxNQUFNLElBQUlGLEdBQUdHO0FBQzNCckIsaUJBQWE7QUFBQSxNQUNYLEdBQUdEO0FBQUFBLE1BQ0gsQ0FBQ29CLElBQUksR0FBR0M7QUFBQUEsSUFDVixDQUFDO0FBQUEsRUFDSDtBQUVBLFFBQU1FLGVBQWUsT0FBT0osTUFBTTtBQUNoQ0EsT0FBR0ssZUFBZTtBQUNsQmIsaUJBQWEsSUFBSTtBQUNqQixRQUFJO0FBQ0ZjLGNBQVFDLElBQUksK0JBQStCO0FBQUEsUUFDekN4QixJQUFJRixXQUFXRTtBQUFBQSxRQUNmRSxTQUFTSixXQUFXSTtBQUFBQSxRQUNwQkMsTUFBTUwsV0FBV0s7QUFBQUEsUUFDakJDLElBQUlOLFdBQVdNO0FBQUFBLFFBQ2ZDLEtBQUtQLFdBQVdPO0FBQUFBLFFBQ2hCb0IsV0FBVy9CLFNBQVNnQztBQUFBQSxNQUN0QixDQUFDO0FBRUQsWUFBTUMsV0FBVyxNQUFNcEMsYUFBYXFDLFVBQVU7QUFBQSxRQUM1QzVCLElBQUlGLFdBQVdFO0FBQUFBLFFBQ2ZFLFNBQVNKLFdBQVdJO0FBQUFBLFFBQ3BCQyxNQUFNTCxXQUFXSztBQUFBQSxRQUNqQkMsSUFBSU4sV0FBV007QUFBQUEsUUFDZkMsS0FBS1AsV0FBV087QUFBQUEsUUFDaEJvQixXQUFXL0IsU0FBU2dDO0FBQUFBLE1BQ3RCLENBQUM7QUFFREgsY0FBUUMsSUFBSSxtQkFBbUJHLFFBQVE7QUFFdkMvQixhQUFPO0FBQUEsUUFDTCxHQUFHRTtBQUFBQSxRQUNIK0IsWUFBVyxvQkFBSUMsS0FBSyxJQUFHQyxZQUFZO0FBQUEsUUFDbkNOLFdBQVcvQixTQUFTZ0M7QUFBQUEsUUFDcEJNLFFBQVFMLFVBQVVLLFVBQVU7QUFBQSxNQUM5QixDQUFDO0FBQ0RyQyxjQUFRO0FBQUEsSUFDVixTQUFTc0MsT0FBTztBQUNkVixjQUFRVSxNQUFNLHlCQUF5QkEsS0FBSztBQUU1QyxVQUFJQyxlQUFlO0FBQ25CLFVBQUlELE1BQU1OLFVBQVVRLE1BQU1GLE9BQU87QUFDL0JDLHVCQUFlLHlCQUF5QkQsTUFBTU4sU0FBU1EsS0FBS0YsS0FBSztBQUFBLE1BQ25FLFdBQVdBLE1BQU1HLFNBQVM7QUFDeEJGLHVCQUFlLHlCQUF5QkQsTUFBTUcsT0FBTztBQUFBLE1BQ3ZEO0FBRUFDLFlBQU1ILFlBQVk7QUFBQSxJQUNwQixVQUFDO0FBQ0N6QixtQkFBYSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBRUEsUUFBTTZCLHNCQUFzQixZQUFZO0FBQ3RDLFFBQUk7QUFDRjNCLHNCQUFnQixJQUFJO0FBR3BCLFlBQU00QixZQUFZLE1BQU0vQyxjQUFjZ0Q7QUFBQUEsUUFDcEM5QztBQUFBQSxRQUNBSSxVQUFVSTtBQUFBQSxRQUNWSixVQUFVSztBQUFBQSxNQUNaO0FBRUFVLDBCQUFvQjBCLFNBQVM7QUFDN0J4QixxQkFBZSxJQUFJO0FBQUEsSUFDckIsU0FBU2tCLE9BQU87QUFDZFYsY0FBUVUsTUFBTSxxQ0FBcUNBLEtBQUs7QUFDeERJLFlBQU0scURBQXFEO0FBQUEsSUFDN0QsVUFBQztBQUNDMUIsc0JBQWdCLEtBQUs7QUFBQSxJQUN2QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNOEIscUJBQXFCQSxNQUFNO0FBQy9CLFFBQUk3QixrQkFBa0I7QUFDcEJiLG1CQUFhO0FBQUEsUUFDWCxHQUFHRDtBQUFBQSxRQUNISSxTQUFTVSxpQkFBaUJWO0FBQUFBLFFBQzFCQyxNQUFNUyxpQkFBaUJUO0FBQUFBLE1BQ3pCLENBQUM7QUFDRFkscUJBQWUsS0FBSztBQUNwQkYsMEJBQW9CLElBQUk7QUFBQSxJQUMxQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNNkIseUJBQXlCQSxNQUFNO0FBQ25DM0IsbUJBQWUsS0FBSztBQUNwQkYsd0JBQW9CLElBQUk7QUFBQSxFQUMxQjtBQUVBLFNBQ0UsbUNBQ0U7QUFBQSwyQkFBQyx1YkFBSSxXQUFVLHdDQUNiLGlDQUFDLDRmQUFJLFdBQVUsNkZBQ2I7QUFBQSw2QkFBQyxrYkFBSSxXQUFVLG9DQUFtQyxlQUFZLFFBQzVELGlDQUFDLDJiQUFJLFdBQVUsNkNBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5RCxLQUQzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUVGLHVCQUFDLG9mQUFLLFdBQVUsc0RBQXFELGVBQVksUUFBTyxpQkFBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErRjtBQUFBLE1BRS9GLHVCQUFDLHdsQkFBSSxXQUFVLDJLQUNiLGlDQUFDLHNYQUFLLFVBQVVRLGNBQ2Q7QUFBQSwrQkFBQyw0ZEFBSSxXQUFVLHNFQUNiO0FBQUEsaUNBQUMsa2VBQUcsV0FBVSwyQ0FBMEMsNkJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFFO0FBQUEsVUFDckU7QUFBQSxZQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMxQjtBQUFBQSxjQUNULFdBQVU7QUFBQSxjQUVWLGlDQUFDLDJZQUFLLE1BQUssS0FBSSxNQUFNLE1BQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdCO0FBQUE7QUFBQSxZQUwxQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLGFBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFFQSx1QkFBQyx5WkFBSSxXQUFVLGFBQ2IsaUNBQUMsdVpBQUksV0FBVSxhQUNiO0FBQUEsaUNBQUMsbVhBQ0M7QUFBQSxtQ0FBQyw2ZUFBTSxXQUFVLHNEQUFxRCxrQkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsaWFBQUksV0FBVSxxQkFDYjtBQUFBLGNBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxNQUFLO0FBQUEsZ0JBQ0wsT0FBT0csV0FBV0U7QUFBQUEsZ0JBQ2xCLFVBQVVnQjtBQUFBQSxnQkFDVixXQUFVO0FBQUEsZ0JBQ1YsVUFBUTtBQUFBO0FBQUEsY0FOVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNVSxLQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBU0E7QUFBQSxlQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBY0E7QUFBQSxVQUVDVixhQUNDLG1DQUNFO0FBQUEsbUNBQUMsbVhBQ0M7QUFBQSxxQ0FBQyw2ZUFBTSxXQUFVLHNEQUFxRCxrQkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxPQUFPUixXQUFXTTtBQUFBQSxrQkFDbEIsVUFBVVk7QUFBQUEsa0JBQ1YsYUFBWTtBQUFBLGtCQUNaLFdBQVU7QUFBQTtBQUFBLGdCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU15QjtBQUFBLGlCQVYzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVlBO0FBQUEsWUFFQSx1QkFBQyxtWEFDQztBQUFBLHFDQUFDLDhlQUFNLFdBQVUsc0RBQXFELG1CQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsTUFBSztBQUFBLGtCQUNMLE9BQU9sQixXQUFXTztBQUFBQSxrQkFDbEIsVUFBVVc7QUFBQUEsa0JBQ1YsYUFBWTtBQUFBLGtCQUNaLFdBQVU7QUFBQTtBQUFBLGdCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU15QjtBQUFBLGlCQVYzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVlBO0FBQUEsZUEzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE0QkE7QUFBQSxVQUdGLHVCQUFDLG1YQUNDO0FBQUEsbUNBQUMsa2ZBQU0sV0FBVSxzREFBcUQsdUJBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxPQUFPbEIsV0FBV0k7QUFBQUEsZ0JBQ2xCLFVBQVVjO0FBQUFBLGdCQUNWLGFBQVk7QUFBQSxnQkFDWixXQUFVO0FBQUEsZ0JBQ1YsVUFBUTtBQUFBO0FBQUEsY0FQVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPVTtBQUFBLGVBWFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFhQTtBQUFBLFVBRUEsdUJBQUMsbVhBQ0M7QUFBQSxtQ0FBQyxrZkFBTSxXQUFVLHNEQUFxRCx1QkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsT0FBT2xCLFdBQVdLO0FBQUFBLGdCQUNsQixVQUFVYTtBQUFBQSxnQkFDVixNQUFNO0FBQUEsZ0JBQ04sYUFBWTtBQUFBLGdCQUNaLFdBQVU7QUFBQSxnQkFDVixVQUFRO0FBQUE7QUFBQSxjQVBWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVFDO0FBQUEsZUFaSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBO0FBQUEsYUE3RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQThFQSxLQS9FRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0ZBO0FBQUEsUUFFQSx1QkFBQyw2Y0FBSSxXQUFVLHlEQUNiO0FBQUEsaUNBQUMsNmFBQUksV0FBVSwrQkFDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVMsTUFBTVQsYUFBYSxDQUFDRCxTQUFTO0FBQUEsZ0JBQ3RDLFdBQVU7QUFBQSxnQkFFVEE7QUFBQUEsOEJBQVksU0FBUztBQUFBLGtCQUFPO0FBQUE7QUFBQTtBQUFBLGNBTC9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTZ0M7QUFBQUEsZ0JBQ1QsVUFBVTVCO0FBQUFBLGdCQUNWLFdBQVU7QUFBQSxnQkFFVEEseUJBQ0MsbUNBQ0U7QUFBQSx5Q0FBQyxnY0FBSyxNQUFLLFVBQVMsTUFBTSxJQUFJLFdBQVUseUJBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTZEO0FBQUEsa0JBQUc7QUFBQSxxQkFEbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQSxJQUVBLG1DQUNFO0FBQUEseUNBQUMsbWJBQUssTUFBSyxZQUFXLE1BQU0sSUFBSSxXQUFVLFlBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWtEO0FBQUEsa0JBQUc7QUFBQSxxQkFEdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBO0FBQUEsY0FmSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFpQkE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFFVixpQ0FBQyxtWkFBSyxNQUFLLGFBQVksTUFBTSxNQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQztBQUFBO0FBQUEsY0FKbEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFFVixpQ0FBQywrWUFBSyxNQUFLLFNBQVEsTUFBTSxNQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE0QjtBQUFBO0FBQUEsY0FKOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxlQXJDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXNDQTtBQUFBLFVBRUEsdUJBQUMsOFpBQUksV0FBVSxrQkFDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVNmO0FBQUFBLGdCQUNULFdBQVU7QUFBQSxnQkFBbUo7QUFBQTtBQUFBLGNBSC9KO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxVQUFVYSxhQUFhLENBQUNWLFdBQVdJLFdBQVcsQ0FBQ0osV0FBV0s7QUFBQUEsZ0JBQzFELFdBQVcsd0NBQ1RLLGFBQWEsQ0FBQ1YsV0FBV0ksV0FBVyxDQUFDSixXQUFXSyxPQUM1QyxrQ0FBaUMsRUFBRTtBQUFBLGdCQUd4Q0ssc0JBQ0MsbUNBQ0U7QUFBQSx5Q0FBQyw4YkFBSyxNQUFLLFVBQVMsTUFBTSxJQUFJLFdBQVUsdUJBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTJEO0FBQUEsa0JBQUc7QUFBQSxxQkFEaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQSxJQUVBLG1DQUNFO0FBQUEseUNBQUMsNmFBQUssTUFBSyxRQUFPLE1BQU0sSUFBSSxXQUFVLFVBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTRDO0FBQUEsa0JBQUc7QUFBQSxxQkFEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBO0FBQUEsY0FsQko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBb0JBO0FBQUEsZUE1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE2QkE7QUFBQSxhQXRFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdUVBO0FBQUEsV0FyS0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNLQSxLQXZLRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0tBO0FBQUEsU0EvS0E7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdMRixLQWpMQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0xGO0FBQUEsSUFHR00sZUFBZUYsb0JBQ2QsdUJBQUMsdWJBQUksV0FBVSx3Q0FDYixpQ0FBQyw2ZkFBSSxXQUFVLDZGQUNiO0FBQUEsNkJBQUMsa2JBQUksV0FBVSxvQ0FBbUMsZUFBWSxRQUM1RCxpQ0FBQywyYkFBSSxXQUFVLDZDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUQsS0FEM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFQSx1QkFBQyx3a0JBQUksV0FBVSw4SkFDYjtBQUFBLCtCQUFDLGljQUFJLFdBQVUsK0NBQ2IsaUNBQUMsbWJBQUksV0FBVSxxQ0FDYjtBQUFBLGlDQUFDLGlhQUFJLFdBQVUscUJBQ2I7QUFBQSxtQ0FBQyxtY0FBSyxNQUFLLFlBQVcsTUFBTSxJQUFJLFdBQVUsMEJBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdFO0FBQUEsWUFDaEUsdUJBQUMsNGVBQUcsV0FBVSx5Q0FBd0MsdUNBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FDQyxTQUFTOEI7QUFBQUEsY0FDVCxXQUFVO0FBQUEsY0FFVixpQ0FBQywyWUFBSyxNQUFLLEtBQUksTUFBTSxNQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3QjtBQUFBO0FBQUEsWUFKMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxhQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQSxLQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQTtBQUFBLFFBRUEsdUJBQUMsbWNBQUksV0FBVSxpREFDYixpQ0FBQyx1WkFBSSxXQUFVLGFBQ2I7QUFBQSxpQ0FBQyxtWEFDQztBQUFBLG1DQUFDLGlnQkFBTSxXQUFVLHNEQUFxRCxrQ0FBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsOGNBQUksV0FBVSw0REFDYixpQ0FBQyx5WkFBRSxXQUFVLHFCQUFxQjlCLDJCQUFpQlYsV0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkQsS0FEN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBRUEsdUJBQUMsbVhBQ0M7QUFBQSxtQ0FBQyw4ZkFBTSxXQUFVLHNEQUFxRCwrQkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsOGNBQUksV0FBVSw0REFDYixpQ0FBQyxxYkFBSSxXQUFVLHlDQUNaVSwyQkFBaUJULFFBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBO0FBQUEsZUFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVNBO0FBQUEsYUFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9CQSxLQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBc0JBO0FBQUEsUUFFQSx1QkFBQyxpY0FBSSxXQUFVLCtDQUNiLGlDQUFDLDRhQUFJLFdBQVUsOEJBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsU0FBU3VDO0FBQUFBLGNBQ1QsV0FBVTtBQUFBLGNBQW1KO0FBQUE7QUFBQSxZQUYvSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUNDLFNBQVNEO0FBQUFBLGNBQ1QsV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyw4YUFBSyxNQUFLLFNBQVEsTUFBTSxJQUFJLFdBQVUsVUFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkM7QUFBQSxnQkFBRztBQUFBO0FBQUE7QUFBQSxZQUpsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLGFBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBLEtBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdCQTtBQUFBLFdBMURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyREE7QUFBQSxTQWhFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUVBLEtBbEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtRUE7QUFBQSxPQTFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNFBBO0FBRUo7QUFBRTVDLEdBMVdJSixtQkFBaUI7QUFBQWtELEtBQWpCbEQ7QUE0V04sZUFBZUE7QUFBa0IsSUFBQWtEO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkljb24iLCJlbWFpbFNlcnZpY2UiLCJnZW1pbmlTZXJ2aWNlIiwiQ29tcG9zZUVtYWlsTW9kYWwiLCJjb250YWN0Iiwib25DbG9zZSIsIm9uU2VuZCIsIl9zIiwiZW1haWxEYXRhIiwic2V0RW1haWxEYXRhIiwidG8iLCJlbWFpbCIsInN1YmplY3QiLCJib2R5IiwiY2MiLCJiY2MiLCJzaG93Q2NCY2MiLCJzZXRTaG93Q2NCY2MiLCJpc1NlbmRpbmciLCJzZXRJc1NlbmRpbmciLCJpc0dlbmVyYXRpbmciLCJzZXRJc0dlbmVyYXRpbmciLCJnZW5lcmF0ZWRDb250ZW50Iiwic2V0R2VuZXJhdGVkQ29udGVudCIsInNob3dQcmV2aWV3Iiwic2V0U2hvd1ByZXZpZXciLCJoYW5kbGVDaGFuZ2UiLCJlIiwibmFtZSIsInZhbHVlIiwidGFyZ2V0IiwiaGFuZGxlU3VibWl0IiwicHJldmVudERlZmF1bHQiLCJjb25zb2xlIiwibG9nIiwiY29udGFjdElkIiwiaWQiLCJyZXNwb25zZSIsInNlbmRFbWFpbCIsInRpbWVzdGFtcCIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsInN0YXR1cyIsImVycm9yIiwiZXJyb3JNZXNzYWdlIiwiZGF0YSIsIm1lc3NhZ2UiLCJhbGVydCIsImhhbmRsZUdlbmVyYXRlRW1haWwiLCJnZW5lcmF0ZWQiLCJnZW5lcmF0ZUVtYWlsQ29udGVudCIsImhhbmRsZVVzZUdlbmVyYXRlZCIsImhhbmRsZURpc2NhcmRHZW5lcmF0ZWQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNvbXBvc2VFbWFpbE1vZGFsLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCBJY29uIGZyb20gJ2NvbXBvbmVudHMvQXBwSWNvbic7XHJcbmltcG9ydCBlbWFpbFNlcnZpY2UgZnJvbSAnLi4vLi4vLi4vc2VydmljZXMvZW1haWxTZXJ2aWNlJztcclxuaW1wb3J0IGdlbWluaVNlcnZpY2UgZnJvbSAnLi4vLi4vLi4vc2VydmljZXMvZ2VtaW5pU2VydmljZSc7XHJcblxyXG5jb25zdCBDb21wb3NlRW1haWxNb2RhbCA9ICh7IGNvbnRhY3QsIG9uQ2xvc2UsIG9uU2VuZCB9KSA9PiB7XHJcbiAgY29uc3QgW2VtYWlsRGF0YSwgc2V0RW1haWxEYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIHRvOiBjb250YWN0Py5lbWFpbCxcclxuICAgIHN1YmplY3Q6ICcnLFxyXG4gICAgYm9keTogJycsXHJcbiAgICBjYzogJycsXHJcbiAgICBiY2M6ICcnXHJcbiAgfSk7XHJcbiAgY29uc3QgW3Nob3dDY0JjYywgc2V0U2hvd0NjQmNjXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbaXNTZW5kaW5nLCBzZXRJc1NlbmRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtpc0dlbmVyYXRpbmcsIHNldElzR2VuZXJhdGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2dlbmVyYXRlZENvbnRlbnQsIHNldEdlbmVyYXRlZENvbnRlbnRdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3Nob3dQcmV2aWV3LCBzZXRTaG93UHJldmlld10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IG5hbWUsIHZhbHVlIH0gPSBlPy50YXJnZXQ7XHJcbiAgICBzZXRFbWFpbERhdGEoe1xyXG4gICAgICAuLi5lbWFpbERhdGEsXHJcbiAgICAgIFtuYW1lXTogdmFsdWVcclxuICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlPy5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgc2V0SXNTZW5kaW5nKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc29sZS5sb2coJ1N1Ym1pdHRpbmcgZW1haWwgd2l0aCBkYXRhOicsIHtcclxuICAgICAgICB0bzogZW1haWxEYXRhPy50byxcclxuICAgICAgICBzdWJqZWN0OiBlbWFpbERhdGE/LnN1YmplY3QsXHJcbiAgICAgICAgYm9keTogZW1haWxEYXRhPy5ib2R5LFxyXG4gICAgICAgIGNjOiBlbWFpbERhdGE/LmNjLFxyXG4gICAgICAgIGJjYzogZW1haWxEYXRhPy5iY2MsXHJcbiAgICAgICAgY29udGFjdElkOiBjb250YWN0Py5pZFxyXG4gICAgICB9KTtcclxuICAgICAgXHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZW1haWxTZXJ2aWNlLnNlbmRFbWFpbCh7XHJcbiAgICAgICAgdG86IGVtYWlsRGF0YT8udG8sXHJcbiAgICAgICAgc3ViamVjdDogZW1haWxEYXRhPy5zdWJqZWN0LFxyXG4gICAgICAgIGJvZHk6IGVtYWlsRGF0YT8uYm9keSxcclxuICAgICAgICBjYzogZW1haWxEYXRhPy5jYyxcclxuICAgICAgICBiY2M6IGVtYWlsRGF0YT8uYmNjLFxyXG4gICAgICAgIGNvbnRhY3RJZDogY29udGFjdD8uaWRcclxuICAgICAgfSk7XHJcbiAgICAgIFxyXG4gICAgICBjb25zb2xlLmxvZygnRW1haWwgcmVzcG9uc2U6JywgcmVzcG9uc2UpO1xyXG4gICAgICBcclxuICAgICAgb25TZW5kKHtcclxuICAgICAgICAuLi5lbWFpbERhdGEsXHJcbiAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpPy50b0lTT1N0cmluZygpLFxyXG4gICAgICAgIGNvbnRhY3RJZDogY29udGFjdD8uaWQsXHJcbiAgICAgICAgc3RhdHVzOiByZXNwb25zZT8uc3RhdHVzIHx8ICdzZW50J1xyXG4gICAgICB9KTtcclxuICAgICAgb25DbG9zZSgpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignRW1haWwgc2VuZGluZyBmYWlsZWQ6JywgZXJyb3IpO1xyXG4gICAgICBcclxuICAgICAgbGV0IGVycm9yTWVzc2FnZSA9ICdGYWlsZWQgdG8gc2VuZCBlbWFpbC4gUGxlYXNlIHRyeSBhZ2Fpbi4nO1xyXG4gICAgICBpZiAoZXJyb3IucmVzcG9uc2U/LmRhdGE/LmVycm9yKSB7XHJcbiAgICAgICAgZXJyb3JNZXNzYWdlID0gYEZhaWxlZCB0byBzZW5kIGVtYWlsOiAke2Vycm9yLnJlc3BvbnNlLmRhdGEuZXJyb3J9YDtcclxuICAgICAgfSBlbHNlIGlmIChlcnJvci5tZXNzYWdlKSB7XHJcbiAgICAgICAgZXJyb3JNZXNzYWdlID0gYEZhaWxlZCB0byBzZW5kIGVtYWlsOiAke2Vycm9yLm1lc3NhZ2V9YDtcclxuICAgICAgfVxyXG4gICAgICBcclxuICAgICAgYWxlcnQoZXJyb3JNZXNzYWdlKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzU2VuZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlR2VuZXJhdGVFbWFpbCA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldElzR2VuZXJhdGluZyh0cnVlKTtcclxuICAgICAgXHJcbiAgICAgIC8vIFBhc3MgY3VycmVudCBmb3JtIHZhbHVlcyBhbmQgY29udGFjdCBpbmZvIHRvIHRoZSBzZXJ2aWNlXHJcbiAgICAgIGNvbnN0IGdlbmVyYXRlZCA9IGF3YWl0IGdlbWluaVNlcnZpY2UuZ2VuZXJhdGVFbWFpbENvbnRlbnQoXHJcbiAgICAgICAgY29udGFjdCwgXHJcbiAgICAgICAgZW1haWxEYXRhLnN1YmplY3QsIFxyXG4gICAgICAgIGVtYWlsRGF0YS5ib2R5XHJcbiAgICAgICk7XHJcbiAgICAgIFxyXG4gICAgICBzZXRHZW5lcmF0ZWRDb250ZW50KGdlbmVyYXRlZCk7XHJcbiAgICAgIHNldFNob3dQcmV2aWV3KHRydWUpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignRmFpbGVkIHRvIGdlbmVyYXRlIGVtYWlsIGNvbnRlbnQ6JywgZXJyb3IpO1xyXG4gICAgICBhbGVydCgnRmFpbGVkIHRvIGdlbmVyYXRlIGVtYWlsIGNvbnRlbnQuIFBsZWFzZSB0cnkgYWdhaW4uJyk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc0dlbmVyYXRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVVzZUdlbmVyYXRlZCA9ICgpID0+IHtcclxuICAgIGlmIChnZW5lcmF0ZWRDb250ZW50KSB7XHJcbiAgICAgIHNldEVtYWlsRGF0YSh7XHJcbiAgICAgICAgLi4uZW1haWxEYXRhLFxyXG4gICAgICAgIHN1YmplY3Q6IGdlbmVyYXRlZENvbnRlbnQuc3ViamVjdCxcclxuICAgICAgICBib2R5OiBnZW5lcmF0ZWRDb250ZW50LmJvZHlcclxuICAgICAgfSk7XHJcbiAgICAgIHNldFNob3dQcmV2aWV3KGZhbHNlKTtcclxuICAgICAgc2V0R2VuZXJhdGVkQ29udGVudChudWxsKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVEaXNjYXJkR2VuZXJhdGVkID0gKCkgPT4ge1xyXG4gICAgc2V0U2hvd1ByZXZpZXcoZmFsc2UpO1xyXG4gICAgc2V0R2VuZXJhdGVkQ29udGVudChudWxsKTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotMTEwMCBvdmVyZmxvdy15LWF1dG9cIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG1pbi1oLXNjcmVlbiBweC00IHB0LTQgcGItMjAgdGV4dC1jZW50ZXIgc206YmxvY2sgc206cC0wXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgdHJhbnNpdGlvbi1vcGFjaXR5XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1ibGFjayBiZy1vcGFjaXR5LTUwXCI+PC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICBcclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gc206aW5saW5lLWJsb2NrIHNtOmFsaWduLW1pZGRsZSBzbTpoLXNjcmVlblwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPiYjODIwMzs8L3NwYW4+XHJcbiAgICAgICAgXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbmxpbmUtYmxvY2sgYWxpZ24tYm90dG9tIGJnLXN1cmZhY2Ugcm91bmRlZC1sZyB0ZXh0LWxlZnQgb3ZlcmZsb3ctaGlkZGVuIHNoYWRvdy14bCB0cmFuc2Zvcm0gdHJhbnNpdGlvbi1hbGwgc206bXktOCBzbTphbGlnbi1taWRkbGUgc206bWF4LXctbGcgc206dy1mdWxsIG1kOm1heC13LTJ4bFwiPlxyXG4gICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS00IGJvcmRlci1iIGJvcmRlci1ib3JkZXIgZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXRleHQtcHJpbWFyeVwiPkNvbXBvc2UgRW1haWw8L2gzPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC10ZXh0LXByaW1hcnlcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJYXCIgc2l6ZT17MjB9IC8+XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC02IHB5LTVcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXNlY29uZGFyeSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgVG9cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJ0b1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZW1haWxEYXRhPy50b31cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbnB1dC1maWVsZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIHtzaG93Q2NCY2MgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtc2Vjb25kYXJ5IG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQ2NcclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY2NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZW1haWxEYXRhPy5jY31cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlbWFpbEBleGFtcGxlLmNvbSwgYW5vdGhlckBleGFtcGxlLmNvbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlucHV0LWZpZWxkXCJcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1zZWNvbmRhcnkgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBCY2NcclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYmNjXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2VtYWlsRGF0YT8uYmNjfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImVtYWlsQGV4YW1wbGUuY29tLCBhbm90aGVyQGV4YW1wbGUuY29tXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5wdXQtZmllbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtc2Vjb25kYXJ5IG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICBTdWJqZWN0XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwic3ViamVjdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2VtYWlsRGF0YT8uc3ViamVjdH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgZW1haWwgc3ViamVjdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5wdXQtZmllbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXNlY29uZGFyeSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgTWVzc2FnZVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8dGV4dGFyZWFcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYm9keVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2VtYWlsRGF0YT8uYm9keX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIHJvd3M9ezh9XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJXcml0ZSB5b3VyIG1lc3NhZ2UgaGVyZS4uLlwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5wdXQtZmllbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgID48L3RleHRhcmVhPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC02IHB5LTQgYm9yZGVyLXQgYm9yZGVyLWJvcmRlciBmbGV4IGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93Q2NCY2MoIXNob3dDY0JjYyl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC10ZXh0LXByaW1hcnkgdGV4dC1zbVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHtzaG93Q2NCY2MgPyAnSGlkZScgOiAnU2hvdyd9IENjL0JjY1xyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVHZW5lcmF0ZUVtYWlsfVxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNHZW5lcmF0aW5nfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMyBweS0xLjUgYmctZ3JhZGllbnQtdG8tciBmcm9tLXB1cnBsZS01MDAgdG8taW5kaWdvLTUwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtbWQgaG92ZXI6ZnJvbS1wdXJwbGUtNjAwIGhvdmVyOnRvLWluZGlnby02MDAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMTUwIGVhc2Utb3V0IHRleHQtc20gZGlzYWJsZWQ6b3BhY2l0eS01MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7aXNHZW5lcmF0aW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiTG9hZGVyXCIgc2l6ZT17MTR9IGNsYXNzTmFtZT1cImFuaW1hdGUtc3BpbiBtci0xLjVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgR2VuZXJhdGluZy4uLlxyXG4gICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiU3BhcmtsZXNcIiBzaXplPXsxNH0gY2xhc3NOYW1lPVwibXItMS41XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIEdlbmVyYXRlIEVtYWlsXHJcbiAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC10ZXh0LXByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiUGFwZXJjbGlwXCIgc2l6ZT17MTZ9IC8+XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC10ZXh0LXByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiSW1hZ2VcIiBzaXplPXsxNn0gLz5cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBzcGFjZS14LTNcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLWxnIHRleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC10ZXh0LXByaW1hcnkgaG92ZXI6Ymctc3VyZmFjZS1ob3ZlciB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0xNTAgZWFzZS1vdXRcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBDYW5jZWxcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzU2VuZGluZyB8fCAhZW1haWxEYXRhPy5zdWJqZWN0IHx8ICFlbWFpbERhdGE/LmJvZHl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJ0bi1wcmltYXJ5IGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciAke1xyXG4gICAgICAgICAgICAgICAgICAgIGlzU2VuZGluZyB8fCAhZW1haWxEYXRhPy5zdWJqZWN0IHx8ICFlbWFpbERhdGE/LmJvZHlcclxuICAgICAgICAgICAgICAgICAgICAgID8gJ29wYWNpdHktNTAgY3Vyc29yLW5vdC1hbGxvd2VkJyA6JydcclxuICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHtpc1NlbmRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJMb2FkZXJcIiBzaXplPXsxNn0gY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluIG1yLTJcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgU2VuZGluZy4uLlxyXG4gICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJTZW5kXCIgc2l6ZT17MTZ9IGNsYXNzTmFtZT1cIm1yLTJcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgU2VuZCBFbWFpbFxyXG4gICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIEdlbmVyYXRlZCBDb250ZW50IFByZXZpZXcgTW9kYWwgKi99XHJcbiAgICAgIHtzaG93UHJldmlldyAmJiBnZW5lcmF0ZWRDb250ZW50ICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei0xMjAwIG92ZXJmbG93LXktYXV0b1wiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBtaW4taC1zY3JlZW4gcHgtNCBwdC00IHBiLTIwIHRleHQtY2VudGVyIHNtOmJsb2NrIHNtOnAtMFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgdHJhbnNpdGlvbi1vcGFjaXR5XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLWJsYWNrIGJnLW9wYWNpdHktNTBcIj48L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlubGluZS1ibG9jayBhbGlnbi1ib3R0b20gYmctc3VyZmFjZSByb3VuZGVkLWxnIHRleHQtbGVmdCBvdmVyZmxvdy1oaWRkZW4gc2hhZG93LXhsIHRyYW5zZm9ybSB0cmFuc2l0aW9uLWFsbCBzbTpteS04IHNtOmFsaWduLW1pZGRsZSBzbTptYXgtdy1sZyBzbTp3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXN1cmZhY2UgcHgtNiBweS00IGJvcmRlci1iIGJvcmRlci1ib3JkZXJcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiU3BhcmtsZXNcIiBzaXplPXsyMH0gY2xhc3NOYW1lPVwidGV4dC1wdXJwbGUtNTAwIG1yLTJcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBHZW5lcmF0ZWQgRW1haWwgQ29udGVudFxyXG4gICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRGlzY2FyZEdlbmVyYXRlZH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5IGhvdmVyOnRleHQtdGV4dC1wcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJYXCIgc2l6ZT17MjB9IC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zdXJmYWNlIHB4LTYgcHktNCBtYXgtaC05NiBvdmVyZmxvdy15LWF1dG9cIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXNlY29uZGFyeSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBHZW5lcmF0ZWQgU3ViamVjdDpcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIGJnLXN1cmZhY2Utc2Vjb25kYXJ5IGJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbGdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtdGV4dC1wcmltYXJ5XCI+e2dlbmVyYXRlZENvbnRlbnQuc3ViamVjdH08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtc2Vjb25kYXJ5IG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEdlbmVyYXRlZCBCb2R5OlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctc3VyZmFjZS1zZWNvbmRhcnkgYm9yZGVyIGJvcmRlci1ib3JkZXIgcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtcHJpbWFyeSB3aGl0ZXNwYWNlLXByZS13cmFwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtnZW5lcmF0ZWRDb250ZW50LmJvZHl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXN1cmZhY2UgcHgtNiBweS00IGJvcmRlci10IGJvcmRlci1ib3JkZXJcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBzcGFjZS14LTMganVzdGlmeS1lbmRcIj5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZURpc2NhcmRHZW5lcmF0ZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbGcgdGV4dC10ZXh0LXNlY29uZGFyeSBob3Zlcjp0ZXh0LXRleHQtcHJpbWFyeSBob3ZlcjpiZy1zdXJmYWNlLWhvdmVyIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTE1MCBlYXNlLW91dFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBEaXNjYXJkXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlVXNlR2VuZXJhdGVkfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5IGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiQ2hlY2tcIiBzaXplPXsxNn0gY2xhc3NOYW1lPVwibXItMlwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgVXNlIFRoaXMgQ29udGVudFxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgPC8+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IENvbXBvc2VFbWFpbE1vZGFsOyJdLCJmaWxlIjoiRDovY3VycmVudCBwcm9qZWN0cy9jbGF1ZGUtY29kZS9zcmMvcGFnZXMvY29udGFjdC1tYW5hZ2VtZW50L2NvbXBvbmVudHMvQ29tcG9zZUVtYWlsTW9kYWwuanN4In0=