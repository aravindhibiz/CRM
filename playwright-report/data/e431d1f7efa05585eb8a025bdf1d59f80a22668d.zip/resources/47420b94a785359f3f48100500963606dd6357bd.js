import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/contexts/AuthContext.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/contexts/AuthContext.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const createContext = __vite__cjsImport3_react["createContext"]; const useContext = __vite__cjsImport3_react["useContext"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { supabase } from "/src/lib/supabase.js";
const AuthContext = createContext({});
export const useAuth = () => {
  _s();
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within AuthProvider");
  }
  return context;
};
_s(useAuth, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
export const AuthProvider = ({ children }) => {
  _s2();
  const [user, setUser] = useState(null);
  const [userProfile, setUserProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [authError, setAuthError] = useState("");
  useEffect(() => {
    supabase?.auth?.getSession()?.then(({ data: { session } }) => {
      if (session?.user) {
        setUser(session?.user);
        getUserProfile(session?.user?.id).then(setUserProfile);
      }
      setLoading(false);
    })?.catch((error) => {
      console.error("Session error:", error);
      setLoading(false);
    });
    const { data: { subscription } } = supabase?.auth?.onAuthStateChange(
      (event, session) => {
        if (session?.user) {
          setUser(session?.user);
          getUserProfile(session?.user?.id).then(setUserProfile);
        } else {
          setUser(null);
          setUserProfile(null);
        }
        setLoading(false);
      }
    );
    return () => subscription?.unsubscribe();
  }, []);
  const signIn = async (email, password) => {
    try {
      setAuthError("");
      const { data, error } = await supabase?.auth?.signInWithPassword({
        email,
        password
      });
      if (error) {
        setAuthError(error?.message);
        return { error };
      }
      if (data?.user) {
        setUser(data?.user);
        const userProfile2 = await getUserProfile(data?.user?.id);
        setUserProfile(userProfile2);
        return { user: data?.user, userProfile: userProfile2 };
      }
    } catch (error) {
      if (error?.message?.includes("Failed to fetch") || error?.message?.includes("AuthRetryableFetchError")) {
        setAuthError("Cannot connect to authentication service. Your Supabase project may be paused or inactive.");
        return { error: { message: "Connection error. Please try again." } };
      }
      setAuthError("Sign in failed. Please try again.");
      return { error: { message: "Sign in failed. Please try again." } };
    }
  };
  const signUp = async (email, password, userData = {}) => {
    try {
      setAuthError("");
      const { data, error } = await supabase?.auth?.signUp({
        email,
        password,
        options: {
          data: {
            first_name: userData?.firstName || "",
            last_name: userData?.lastName || "",
            role: userData?.role || "sales_rep"
          }
        }
      });
      if (error) {
        setAuthError(error?.message);
        return { error };
      }
      return { user: data?.user };
    } catch (error) {
      if (error?.message?.includes("Failed to fetch")) {
        setAuthError("Cannot connect to authentication service. Please check your network connection.");
        return { error: { message: "Connection error. Please try again." } };
      }
      setAuthError("Sign up failed. Please try again.");
      return { error: { message: "Sign up failed. Please try again." } };
    }
  };
  const signOut = async () => {
    try {
      const { error } = await supabase?.auth?.signOut();
      if (error) {
        console.error("Sign out error:", error);
      } else {
        setUser(null);
        setUserProfile(null);
        setAuthError("");
      }
    } catch (error) {
      console.error("Sign out error:", error);
    }
  };
  const getUserProfile = async (userId) => {
    if (!userId)
      return null;
    const { data, error } = await supabase?.from("user_profiles")?.select("*")?.eq("id", userId)?.single();
    if (error && error?.code !== "PGRST116") {
      console.error("Error fetching user profile:", error);
      return null;
    }
    return data;
  };
  const updateUserProfile = async (userId, updates) => {
    const { data, error } = await supabase?.from("user_profiles")?.update(updates)?.eq("id", userId)?.select()?.single();
    return { data, error };
  };
  const clearAuthError = () => setAuthError("");
  const value = {
    user,
    userProfile,
    loading,
    authError,
    signIn,
    signUp,
    signOut,
    getUserProfile,
    updateUserProfile,
    clearAuthError
  };
  return /* @__PURE__ */ jsxDEV(AuthContext.Provider, { "data-component-id": "src\\contexts\\AuthContext.jsx:163:4", "data-component-path": "src\\contexts\\AuthContext.jsx", "data-component-line": "163", "data-component-file": "AuthContext.jsx", "data-component-name": "AuthContext.Provider", "data-component-content": "%7B%22elementName%22%3A%22AuthContext.Provider%22%2C%22value%22%3A%22%5Bvar%3Avalue%5D%22%7D", value, children }, void 0, false, {
    fileName: "D:/current projects/claude-code/src/contexts/AuthContext.jsx",
    lineNumber: 163,
    columnNumber: 5
  }, this);
};
_s2(AuthProvider, "H0McJ6LrIk3j34Ql9znHIib8lmw=");
_c = AuthProvider;
var _c;
$RefreshReg$(_c, "AuthProvider");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/contexts/AuthContext.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/contexts/AuthContext.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0tJOztBQWxLSixvQkFBZ0JBLDZCQUEyQkMsZUFBbUIsZ0JBQWU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDN0UsU0FBU0MsZ0JBQWdCO0FBRXpCLE1BQU1DLGNBQWNILGNBQWMsQ0FBQyxDQUFDO0FBRTdCLGFBQU1JLFVBQVVBLE1BQU07QUFBQUMsS0FBQTtBQUMzQixRQUFNQyxVQUFVQyxXQUFXSixXQUFXO0FBQ3RDLE1BQUksQ0FBQ0csU0FBUztBQUNaLFVBQU0sSUFBSUUsTUFBTSwwQ0FBMEM7QUFBQSxFQUM1RDtBQUNBLFNBQU9GO0FBQ1Q7QUFBQ0QsR0FOWUQsU0FBTztBQVFiLGFBQU1LLGVBQWVBLENBQUMsRUFBRUMsU0FBUyxNQUFNO0FBQUFDLE1BQUE7QUFDNUMsUUFBTSxDQUFDQyxNQUFNQyxPQUFPLElBQUlDLFNBQVMsSUFBSTtBQUNyQyxRQUFNLENBQUNDLGFBQWFDLGNBQWMsSUFBSUYsU0FBUyxJQUFJO0FBQ25ELFFBQU0sQ0FBQ0csU0FBU0MsVUFBVSxJQUFJSixTQUFTLElBQUk7QUFDM0MsUUFBTSxDQUFDSyxXQUFXQyxZQUFZLElBQUlOLFNBQVMsRUFBRTtBQUU3Q2IsWUFBVSxNQUFNO0FBRWRDLGNBQVVtQixNQUFNQyxXQUFXLEdBQUdDLEtBQUssQ0FBQyxFQUFFQyxNQUFNLEVBQUVDLFFBQVEsRUFBRSxNQUFNO0FBQzFELFVBQUlBLFNBQVNiLE1BQU07QUFDakJDLGdCQUFRWSxTQUFTYixJQUFJO0FBQ3JCYyx1QkFBZUQsU0FBU2IsTUFBTWUsRUFBRSxFQUFFSixLQUFLUCxjQUFjO0FBQUEsTUFDdkQ7QUFDQUUsaUJBQVcsS0FBSztBQUFBLElBQ2xCLENBQUMsR0FBR1UsTUFBTSxDQUFDQyxVQUFVO0FBQ25CQyxjQUFRRCxNQUFNLGtCQUFrQkEsS0FBSztBQUNyQ1gsaUJBQVcsS0FBSztBQUFBLElBQ2xCLENBQUM7QUFHSCxVQUFNLEVBQUVNLE1BQU0sRUFBRU8sYUFBYSxFQUFFLElBQUk3QixVQUFVbUIsTUFBTVc7QUFBQUEsTUFDakQsQ0FBQ0MsT0FBT1IsWUFBWTtBQUNsQixZQUFJQSxTQUFTYixNQUFNO0FBQ2pCQyxrQkFBUVksU0FBU2IsSUFBSTtBQUNyQmMseUJBQWVELFNBQVNiLE1BQU1lLEVBQUUsRUFBRUosS0FBS1AsY0FBYztBQUFBLFFBQ3ZELE9BQU87QUFDTEgsa0JBQVEsSUFBSTtBQUNaRyx5QkFBZSxJQUFJO0FBQUEsUUFDckI7QUFDQUUsbUJBQVcsS0FBSztBQUFBLE1BQ2xCO0FBQUEsSUFDRjtBQUVBLFdBQU8sTUFBTWEsY0FBY0csWUFBWTtBQUFBLEVBQ3pDLEdBQUcsRUFBRTtBQUlMLFFBQU1DLFNBQVMsT0FBT0MsT0FBT0MsYUFBYTtBQUN4QyxRQUFJO0FBQ0ZqQixtQkFBYSxFQUFFO0FBQ2YsWUFBTSxFQUFFSSxNQUFNSyxNQUFNLElBQUksTUFBTTNCLFVBQVVtQixNQUFNaUIsbUJBQW1CO0FBQUEsUUFDL0RGO0FBQUFBLFFBQ0FDO0FBQUFBLE1BQ0YsQ0FBQztBQUVELFVBQUlSLE9BQU87QUFDVFQscUJBQWFTLE9BQU9VLE9BQU87QUFDM0IsZUFBTyxFQUFFVixNQUFNO0FBQUEsTUFDakI7QUFFQSxVQUFJTCxNQUFNWixNQUFNO0FBQ2RDLGdCQUFRVyxNQUFNWixJQUFJO0FBQ2xCLGNBQU1HLGVBQWMsTUFBTVcsZUFBZUYsTUFBTVosTUFBTWUsRUFBRTtBQUN2RFgsdUJBQWVELFlBQVc7QUFDMUIsZUFBTyxFQUFFSCxNQUFNWSxNQUFNWixNQUFNRywwQkFBWTtBQUFBLE1BQ3pDO0FBQUEsSUFDRixTQUFTYyxPQUFPO0FBQ2QsVUFBSUEsT0FBT1UsU0FBU0MsU0FBUyxpQkFBaUIsS0FDMUNYLE9BQU9VLFNBQVNDLFNBQVMseUJBQXlCLEdBQUc7QUFDdkRwQixxQkFBYSw0RkFBNEY7QUFDekcsZUFBTyxFQUFFUyxPQUFPLEVBQUVVLFNBQVMsc0NBQXNDLEVBQUU7QUFBQSxNQUNyRTtBQUNBbkIsbUJBQWEsbUNBQW1DO0FBQ2hELGFBQU8sRUFBRVMsT0FBTyxFQUFFVSxTQUFTLG9DQUFvQyxFQUFFO0FBQUEsSUFDbkU7QUFBQSxFQUNGO0FBRUEsUUFBTUUsU0FBUyxPQUFPTCxPQUFPQyxVQUFVSyxXQUFXLENBQUMsTUFBTTtBQUN2RCxRQUFJO0FBQ0Z0QixtQkFBYSxFQUFFO0FBQ2YsWUFBTSxFQUFFSSxNQUFNSyxNQUFNLElBQUksTUFBTTNCLFVBQVVtQixNQUFNb0IsT0FBTztBQUFBLFFBQ25ETDtBQUFBQSxRQUNBQztBQUFBQSxRQUNBTSxTQUFTO0FBQUEsVUFDUG5CLE1BQU07QUFBQSxZQUNKb0IsWUFBWUYsVUFBVUcsYUFBYTtBQUFBLFlBQ25DQyxXQUFXSixVQUFVSyxZQUFZO0FBQUEsWUFDakNDLE1BQU1OLFVBQVVNLFFBQVE7QUFBQSxVQUMxQjtBQUFBLFFBQ0Y7QUFBQSxNQUNGLENBQUM7QUFFRCxVQUFJbkIsT0FBTztBQUNUVCxxQkFBYVMsT0FBT1UsT0FBTztBQUMzQixlQUFPLEVBQUVWLE1BQU07QUFBQSxNQUNqQjtBQUVBLGFBQU8sRUFBRWpCLE1BQU1ZLE1BQU1aLEtBQUs7QUFBQSxJQUM1QixTQUFTaUIsT0FBTztBQUNkLFVBQUlBLE9BQU9VLFNBQVNDLFNBQVMsaUJBQWlCLEdBQUc7QUFDL0NwQixxQkFBYSxpRkFBaUY7QUFDOUYsZUFBTyxFQUFFUyxPQUFPLEVBQUVVLFNBQVMsc0NBQXNDLEVBQUU7QUFBQSxNQUNyRTtBQUNBbkIsbUJBQWEsbUNBQW1DO0FBQ2hELGFBQU8sRUFBRVMsT0FBTyxFQUFFVSxTQUFTLG9DQUFvQyxFQUFFO0FBQUEsSUFDbkU7QUFBQSxFQUNGO0FBRUEsUUFBTVUsVUFBVSxZQUFZO0FBQzFCLFFBQUk7QUFDRixZQUFNLEVBQUVwQixNQUFNLElBQUksTUFBTTNCLFVBQVVtQixNQUFNNEIsUUFBUTtBQUNoRCxVQUFJcEIsT0FBTztBQUNUQyxnQkFBUUQsTUFBTSxtQkFBbUJBLEtBQUs7QUFBQSxNQUN4QyxPQUFPO0FBQ0xoQixnQkFBUSxJQUFJO0FBQ1pHLHVCQUFlLElBQUk7QUFDbkJJLHFCQUFhLEVBQUU7QUFBQSxNQUNqQjtBQUFBLElBQ0YsU0FBU1MsT0FBTztBQUNkQyxjQUFRRCxNQUFNLG1CQUFtQkEsS0FBSztBQUFBLElBQ3hDO0FBQUEsRUFDRjtBQUVBLFFBQU1ILGlCQUFpQixPQUFPd0IsV0FBVztBQUN2QyxRQUFJLENBQUNBO0FBQVEsYUFBTztBQUVwQixVQUFNLEVBQUUxQixNQUFNSyxNQUFNLElBQUksTUFBTTNCLFVBQVVpRCxLQUFLLGVBQWUsR0FBR0MsT0FBTyxHQUFHLEdBQUdDLEdBQUcsTUFBTUgsTUFBTSxHQUFHSSxPQUFPO0FBRXJHLFFBQUl6QixTQUFTQSxPQUFPMEIsU0FBUyxZQUFZO0FBQ3ZDekIsY0FBUUQsTUFBTSxnQ0FBZ0NBLEtBQUs7QUFDbkQsYUFBTztBQUFBLElBQ1Q7QUFFQSxXQUFPTDtBQUFBQSxFQUNUO0FBRUEsUUFBTWdDLG9CQUFvQixPQUFPTixRQUFRTyxZQUFZO0FBQ25ELFVBQU0sRUFBRWpDLE1BQU1LLE1BQU0sSUFBSSxNQUFNM0IsVUFBVWlELEtBQUssZUFBZSxHQUFHTyxPQUFPRCxPQUFPLEdBQUdKLEdBQUcsTUFBTUgsTUFBTSxHQUFHRSxPQUFPLEdBQUdFLE9BQU87QUFFbkgsV0FBTyxFQUFFOUIsTUFBTUssTUFBTTtBQUFBLEVBQ3ZCO0FBRUEsUUFBTThCLGlCQUFpQkEsTUFBTXZDLGFBQWEsRUFBRTtBQUU1QyxRQUFNd0MsUUFBUTtBQUFBLElBQ1poRDtBQUFBQSxJQUNBRztBQUFBQSxJQUNBRTtBQUFBQSxJQUNBRTtBQUFBQSxJQUNBZ0I7QUFBQUEsSUFDQU07QUFBQUEsSUFDQVE7QUFBQUEsSUFDQXZCO0FBQUFBLElBQ0E4QjtBQUFBQSxJQUNBRztBQUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxZQUFZLFVBQVosRUFBWSx1V0FBUyxPQUNuQmpELFlBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBO0FBRUo7QUFBQ0MsSUF6SllGLGNBQVk7QUFBQW9ELEtBQVpwRDtBQUFZLElBQUFvRDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiY3JlYXRlQ29udGV4dCIsInVzZUVmZmVjdCIsInN1cGFiYXNlIiwiQXV0aENvbnRleHQiLCJ1c2VBdXRoIiwiX3MiLCJjb250ZXh0IiwidXNlQ29udGV4dCIsIkVycm9yIiwiQXV0aFByb3ZpZGVyIiwiY2hpbGRyZW4iLCJfczIiLCJ1c2VyIiwic2V0VXNlciIsInVzZVN0YXRlIiwidXNlclByb2ZpbGUiLCJzZXRVc2VyUHJvZmlsZSIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwiYXV0aEVycm9yIiwic2V0QXV0aEVycm9yIiwiYXV0aCIsImdldFNlc3Npb24iLCJ0aGVuIiwiZGF0YSIsInNlc3Npb24iLCJnZXRVc2VyUHJvZmlsZSIsImlkIiwiY2F0Y2giLCJlcnJvciIsImNvbnNvbGUiLCJzdWJzY3JpcHRpb24iLCJvbkF1dGhTdGF0ZUNoYW5nZSIsImV2ZW50IiwidW5zdWJzY3JpYmUiLCJzaWduSW4iLCJlbWFpbCIsInBhc3N3b3JkIiwic2lnbkluV2l0aFBhc3N3b3JkIiwibWVzc2FnZSIsImluY2x1ZGVzIiwic2lnblVwIiwidXNlckRhdGEiLCJvcHRpb25zIiwiZmlyc3RfbmFtZSIsImZpcnN0TmFtZSIsImxhc3RfbmFtZSIsImxhc3ROYW1lIiwicm9sZSIsInNpZ25PdXQiLCJ1c2VySWQiLCJmcm9tIiwic2VsZWN0IiwiZXEiLCJzaW5nbGUiLCJjb2RlIiwidXBkYXRlVXNlclByb2ZpbGUiLCJ1cGRhdGVzIiwidXBkYXRlIiwiY2xlYXJBdXRoRXJyb3IiLCJ2YWx1ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXV0aENvbnRleHQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyBjcmVhdGVDb250ZXh0LCB1c2VDb250ZXh0LCB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBzdXBhYmFzZSB9IGZyb20gJy4uL2xpYi9zdXBhYmFzZSc7XHJcblxyXG5jb25zdCBBdXRoQ29udGV4dCA9IGNyZWF0ZUNvbnRleHQoe30pXHJcblxyXG5leHBvcnQgY29uc3QgdXNlQXV0aCA9ICgpID0+IHtcclxuICBjb25zdCBjb250ZXh0ID0gdXNlQ29udGV4dChBdXRoQ29udGV4dClcclxuICBpZiAoIWNvbnRleHQpIHtcclxuICAgIHRocm93IG5ldyBFcnJvcigndXNlQXV0aCBtdXN0IGJlIHVzZWQgd2l0aGluIEF1dGhQcm92aWRlcicpXHJcbiAgfVxyXG4gIHJldHVybiBjb250ZXh0XHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCBBdXRoUHJvdmlkZXIgPSAoeyBjaGlsZHJlbiB9KSA9PiB7XHJcbiAgY29uc3QgW3VzZXIsIHNldFVzZXJdID0gdXNlU3RhdGUobnVsbClcclxuICBjb25zdCBbdXNlclByb2ZpbGUsIHNldFVzZXJQcm9maWxlXSA9IHVzZVN0YXRlKG51bGwpXHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSlcclxuICBjb25zdCBbYXV0aEVycm9yLCBzZXRBdXRoRXJyb3JdID0gdXNlU3RhdGUoJycpXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAvLyBHZXQgaW5pdGlhbCBzZXNzaW9uIC0gVXNlIFByb21pc2UgY2hhaW5cclxuICAgIHN1cGFiYXNlPy5hdXRoPy5nZXRTZXNzaW9uKCk/LnRoZW4oKHsgZGF0YTogeyBzZXNzaW9uIH0gfSkgPT4ge1xyXG4gICAgICAgIGlmIChzZXNzaW9uPy51c2VyKSB7XHJcbiAgICAgICAgICBzZXRVc2VyKHNlc3Npb24/LnVzZXIpXHJcbiAgICAgICAgICBnZXRVc2VyUHJvZmlsZShzZXNzaW9uPy51c2VyPy5pZCkudGhlbihzZXRVc2VyUHJvZmlsZSlcclxuICAgICAgICB9XHJcbiAgICAgICAgc2V0TG9hZGluZyhmYWxzZSlcclxuICAgICAgfSk/LmNhdGNoKChlcnJvcikgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ1Nlc3Npb24gZXJyb3I6JywgZXJyb3IpXHJcbiAgICAgICAgc2V0TG9hZGluZyhmYWxzZSlcclxuICAgICAgfSlcclxuXHJcbiAgICAvLyBMaXN0ZW4gZm9yIGF1dGggY2hhbmdlcyAtIE5FVkVSIEFTWU5DIGNhbGxiYWNrXHJcbiAgICBjb25zdCB7IGRhdGE6IHsgc3Vic2NyaXB0aW9uIH0gfSA9IHN1cGFiYXNlPy5hdXRoPy5vbkF1dGhTdGF0ZUNoYW5nZShcclxuICAgICAgKGV2ZW50LCBzZXNzaW9uKSA9PiB7XHJcbiAgICAgICAgaWYgKHNlc3Npb24/LnVzZXIpIHtcclxuICAgICAgICAgIHNldFVzZXIoc2Vzc2lvbj8udXNlcilcclxuICAgICAgICAgIGdldFVzZXJQcm9maWxlKHNlc3Npb24/LnVzZXI/LmlkKS50aGVuKHNldFVzZXJQcm9maWxlKSAgLy8gRmlyZS1hbmQtZm9yZ2V0LCBOTyBBV0FJVFxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBzZXRVc2VyKG51bGwpXHJcbiAgICAgICAgICBzZXRVc2VyUHJvZmlsZShudWxsKVxyXG4gICAgICAgIH1cclxuICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKVxyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgcmV0dXJuICgpID0+IHN1YnNjcmlwdGlvbj8udW5zdWJzY3JpYmUoKVxyXG4gIH0sIFtdKVxyXG5cclxuICBcclxuXHJcbiAgY29uc3Qgc2lnbkluID0gYXN5bmMgKGVtYWlsLCBwYXNzd29yZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0QXV0aEVycm9yKCcnKVxyXG4gICAgICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZT8uYXV0aD8uc2lnbkluV2l0aFBhc3N3b3JkKHtcclxuICAgICAgICBlbWFpbCxcclxuICAgICAgICBwYXNzd29yZFxyXG4gICAgICB9KVxyXG5cclxuICAgICAgaWYgKGVycm9yKSB7XHJcbiAgICAgICAgc2V0QXV0aEVycm9yKGVycm9yPy5tZXNzYWdlKVxyXG4gICAgICAgIHJldHVybiB7IGVycm9yIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgaWYgKGRhdGE/LnVzZXIpIHtcclxuICAgICAgICBzZXRVc2VyKGRhdGE/LnVzZXIpXHJcbiAgICAgICAgY29uc3QgdXNlclByb2ZpbGUgPSBhd2FpdCBnZXRVc2VyUHJvZmlsZShkYXRhPy51c2VyPy5pZClcclxuICAgICAgICBzZXRVc2VyUHJvZmlsZSh1c2VyUHJvZmlsZSlcclxuICAgICAgICByZXR1cm4geyB1c2VyOiBkYXRhPy51c2VyLCB1c2VyUHJvZmlsZSB9O1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBpZiAoZXJyb3I/Lm1lc3NhZ2U/LmluY2x1ZGVzKCdGYWlsZWQgdG8gZmV0Y2gnKSB8fCBcclxuICAgICAgICAgIGVycm9yPy5tZXNzYWdlPy5pbmNsdWRlcygnQXV0aFJldHJ5YWJsZUZldGNoRXJyb3InKSkge1xyXG4gICAgICAgIHNldEF1dGhFcnJvcignQ2Fubm90IGNvbm5lY3QgdG8gYXV0aGVudGljYXRpb24gc2VydmljZS4gWW91ciBTdXBhYmFzZSBwcm9qZWN0IG1heSBiZSBwYXVzZWQgb3IgaW5hY3RpdmUuJylcclxuICAgICAgICByZXR1cm4geyBlcnJvcjogeyBtZXNzYWdlOiAnQ29ubmVjdGlvbiBlcnJvci4gUGxlYXNlIHRyeSBhZ2Fpbi4nIH0gfVxyXG4gICAgICB9XHJcbiAgICAgIHNldEF1dGhFcnJvcignU2lnbiBpbiBmYWlsZWQuIFBsZWFzZSB0cnkgYWdhaW4uJylcclxuICAgICAgcmV0dXJuIHsgZXJyb3I6IHsgbWVzc2FnZTogJ1NpZ24gaW4gZmFpbGVkLiBQbGVhc2UgdHJ5IGFnYWluLicgfSB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBjb25zdCBzaWduVXAgPSBhc3luYyAoZW1haWwsIHBhc3N3b3JkLCB1c2VyRGF0YSA9IHt9KSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRBdXRoRXJyb3IoJycpXHJcbiAgICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlPy5hdXRoPy5zaWduVXAoe1xyXG4gICAgICAgIGVtYWlsLFxyXG4gICAgICAgIHBhc3N3b3JkLFxyXG4gICAgICAgIG9wdGlvbnM6IHtcclxuICAgICAgICAgIGRhdGE6IHtcclxuICAgICAgICAgICAgZmlyc3RfbmFtZTogdXNlckRhdGE/LmZpcnN0TmFtZSB8fCAnJyxcclxuICAgICAgICAgICAgbGFzdF9uYW1lOiB1c2VyRGF0YT8ubGFzdE5hbWUgfHwgJycsXHJcbiAgICAgICAgICAgIHJvbGU6IHVzZXJEYXRhPy5yb2xlIHx8ICdzYWxlc19yZXAnXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG5cclxuICAgICAgaWYgKGVycm9yKSB7XHJcbiAgICAgICAgc2V0QXV0aEVycm9yKGVycm9yPy5tZXNzYWdlKVxyXG4gICAgICAgIHJldHVybiB7IGVycm9yIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgcmV0dXJuIHsgdXNlcjogZGF0YT8udXNlciB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBpZiAoZXJyb3I/Lm1lc3NhZ2U/LmluY2x1ZGVzKCdGYWlsZWQgdG8gZmV0Y2gnKSkge1xyXG4gICAgICAgIHNldEF1dGhFcnJvcignQ2Fubm90IGNvbm5lY3QgdG8gYXV0aGVudGljYXRpb24gc2VydmljZS4gUGxlYXNlIGNoZWNrIHlvdXIgbmV0d29yayBjb25uZWN0aW9uLicpXHJcbiAgICAgICAgcmV0dXJuIHsgZXJyb3I6IHsgbWVzc2FnZTogJ0Nvbm5lY3Rpb24gZXJyb3IuIFBsZWFzZSB0cnkgYWdhaW4uJyB9IH1cclxuICAgICAgfVxyXG4gICAgICBzZXRBdXRoRXJyb3IoJ1NpZ24gdXAgZmFpbGVkLiBQbGVhc2UgdHJ5IGFnYWluLicpXHJcbiAgICAgIHJldHVybiB7IGVycm9yOiB7IG1lc3NhZ2U6ICdTaWduIHVwIGZhaWxlZC4gUGxlYXNlIHRyeSBhZ2Fpbi4nIH0gfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgY29uc3Qgc2lnbk91dCA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHsgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlPy5hdXRoPy5zaWduT3V0KClcclxuICAgICAgaWYgKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcignU2lnbiBvdXQgZXJyb3I6JywgZXJyb3IpXHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0VXNlcihudWxsKVxyXG4gICAgICAgIHNldFVzZXJQcm9maWxlKG51bGwpXHJcbiAgICAgICAgc2V0QXV0aEVycm9yKCcnKVxyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdTaWduIG91dCBlcnJvcjonLCBlcnJvcilcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGNvbnN0IGdldFVzZXJQcm9maWxlID0gYXN5bmMgKHVzZXJJZCkgPT4ge1xyXG4gICAgaWYgKCF1c2VySWQpIHJldHVybiBudWxsXHJcbiAgICBcclxuICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlPy5mcm9tKCd1c2VyX3Byb2ZpbGVzJyk/LnNlbGVjdCgnKicpPy5lcSgnaWQnLCB1c2VySWQpPy5zaW5nbGUoKVxyXG5cclxuICAgIGlmIChlcnJvciAmJiBlcnJvcj8uY29kZSAhPT0gJ1BHUlNUMTE2Jykge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBmZXRjaGluZyB1c2VyIHByb2ZpbGU6JywgZXJyb3IpXHJcbiAgICAgIHJldHVybiBudWxsXHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIGRhdGFcclxuICB9XHJcblxyXG4gIGNvbnN0IHVwZGF0ZVVzZXJQcm9maWxlID0gYXN5bmMgKHVzZXJJZCwgdXBkYXRlcykgPT4ge1xyXG4gICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2U/LmZyb20oJ3VzZXJfcHJvZmlsZXMnKT8udXBkYXRlKHVwZGF0ZXMpPy5lcSgnaWQnLCB1c2VySWQpPy5zZWxlY3QoKT8uc2luZ2xlKClcclxuXHJcbiAgICByZXR1cm4geyBkYXRhLCBlcnJvciB9XHJcbiAgfVxyXG5cclxuICBjb25zdCBjbGVhckF1dGhFcnJvciA9ICgpID0+IHNldEF1dGhFcnJvcignJylcclxuXHJcbiAgY29uc3QgdmFsdWUgPSB7XHJcbiAgICB1c2VyLFxyXG4gICAgdXNlclByb2ZpbGUsXHJcbiAgICBsb2FkaW5nLFxyXG4gICAgYXV0aEVycm9yLFxyXG4gICAgc2lnbkluLFxyXG4gICAgc2lnblVwLFxyXG4gICAgc2lnbk91dCxcclxuICAgIGdldFVzZXJQcm9maWxlLFxyXG4gICAgdXBkYXRlVXNlclByb2ZpbGUsXHJcbiAgICBjbGVhckF1dGhFcnJvclxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxBdXRoQ29udGV4dC5Qcm92aWRlciB2YWx1ZT17dmFsdWV9PlxyXG4gICAgICB7Y2hpbGRyZW59XHJcbiAgICA8L0F1dGhDb250ZXh0LlByb3ZpZGVyPlxyXG4gICk7XHJcbn0iXSwiZmlsZSI6IkQ6L2N1cnJlbnQgcHJvamVjdHMvY2xhdWRlLWNvZGUvc3JjL2NvbnRleHRzL0F1dGhDb250ZXh0LmpzeCJ9