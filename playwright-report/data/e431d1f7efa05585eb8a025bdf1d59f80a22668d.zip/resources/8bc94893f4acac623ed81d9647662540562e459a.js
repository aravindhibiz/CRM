import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/activity-timeline/components/AddActivityModal.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useCallback = __vite__cjsImport3_react["useCallback"];
import Icon from "/src/components/AppIcon.jsx";
import { useAuth } from "/src/contexts/AuthContext.jsx";
import activitiesService from "/src/services/activitiesService.js";
import contactsService from "/src/services/contactsService.js";
import dealsService from "/src/services/dealsService.js";
const AddActivityModal = ({ isOpen, onClose, onActivityAdded, prefilledData = {} }) => {
  _s();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [contacts, setContacts] = useState([]);
  const [deals, setDeals] = useState([]);
  const [formData, setFormData] = useState({});
  const [errors, setErrors] = useState({});
  const initialFormState = useCallback(() => ({
    type: "note",
    subject: "",
    description: "",
    contact_id: "",
    deal_id: "",
    duration_minutes: "",
    scheduled_at: "",
    user_id: user?.id || ""
  }), [user]);
  useEffect(() => {
    if (isOpen) {
      const loadData = async () => {
        try {
          const [contactsData, dealsData] = await Promise.all(
            [
              contactsService.getUserContacts(),
              dealsService.getUserDeals()
            ]
          );
          setContacts(contactsData || []);
          setDeals(dealsData || []);
        } catch (err) {
          console.error("Error loading modal data:", err);
          setErrors({ submit: "Failed to load contacts and deals." });
        }
      };
      loadData();
      setFormData({ ...initialFormState(), ...prefilledData });
    } else {
      setFormData({});
      setErrors({});
    }
  }, [isOpen]);
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrors({});
    try {
      const requiredFields = ["type", "subject"];
      const validationErrors = {};
      requiredFields.forEach((field) => {
        if (!formData[field]?.trim()) {
          validationErrors[field] = `${field.replace("_", " ")} is required`;
        }
      });
      if (["call", "meeting"].includes(formData.type) && formData.duration_minutes && (isNaN(formData.duration_minutes) || parseInt(formData.duration_minutes) <= 0)) {
        validationErrors.duration_minutes = "Please enter a valid duration";
      }
      if (Object.keys(validationErrors).length > 0) {
        setErrors(validationErrors);
        setLoading(false);
        return;
      }
      const submitData = {
        ...formData,
        duration_minutes: formData.duration_minutes ? parseInt(formData.duration_minutes) : null,
        scheduled_at: formData.scheduled_at || null,
        user_id: user?.id,
        contact_id: formData.contact_id || null,
        deal_id: formData.deal_id || null
      };
      const newActivity = await activitiesService.createActivity(submitData);
      onActivityAdded(newActivity);
      onClose();
    } catch (err) {
      console.error("Error creating activity:", err);
      setErrors({
        submit: err.message || "Failed to create activity. Please try again."
      });
    } finally {
      setLoading(false);
    }
  };
  const handleInputChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => {
        const newErrors = { ...prev };
        delete newErrors[field];
        return newErrors;
      });
    }
  };
  const activityTypes = [
    { value: "note", label: "Note", icon: "FileText" },
    { value: "call", label: "Call", icon: "Phone" },
    { value: "email", label: "Email", icon: "Mail" },
    { value: "meeting", label: "Meeting", icon: "Calendar" },
    { value: "task", label: "Task", icon: "CheckSquare" }
  ];
  if (!isOpen)
    return null;
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:121:4", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "121", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20z-50%20overflow-y-auto%22%7D", className: "fixed inset-0 z-50 overflow-y-auto", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:122:6", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "122", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-center%20min-h-screen%20px-4%22%7D", className: "flex items-center justify-center min-h-screen px-4", children: [
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:123:8", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "123", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20bg-black%20bg-opacity-50%22%7D", className: "fixed inset-0 bg-black bg-opacity-50", onClick: onClose }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
      lineNumber: 123,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:124:8", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "124", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20rounded-lg%20shadow-xl%20max-w-2xl%20w-full%20relative%20z-10%22%7D", className: "bg-surface rounded-lg shadow-xl max-w-2xl w-full relative z-10", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:125:10", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "125", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22p-6%22%7D", className: "p-6", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:126:12", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "126", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%20mb-6%22%7D", className: "flex items-center justify-between mb-6", children: [
        /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:127:14", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "127", "data-component-file": "AddActivityModal.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-xl%20font-semibold%20text-text-primary%22%2C%22textContent%22%3A%22Add%20New%20Activity%22%7D", className: "text-xl font-semibold text-text-primary", children: "Add New Activity" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
          lineNumber: 127,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("button", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:128:14", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "128", "data-component-file": "AddActivityModal.jsx", "data-component-name": "button", "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22text-text-secondary%20hover%3Atext-text-primary%22%7D", onClick: onClose, className: "text-text-secondary hover:text-text-primary", children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:129:16", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "129", "data-component-file": "AddActivityModal.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22X%22%7D", name: "X", size: 24 }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
          lineNumber: 129,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
          lineNumber: 128,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
        lineNumber: 126,
        columnNumber: 13
      }, this),
      errors.submit && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:134:12", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "134", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-error-50%20border%20border-error-200%20text-error%20p-4%20rounded-lg%20mb-6%22%7D", className: "bg-error-50 border border-error-200 text-error p-4 rounded-lg mb-6", children: errors.submit }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
        lineNumber: 134,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:139:12", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "139", "data-component-file": "AddActivityModal.jsx", "data-component-name": "form", "data-component-content": "%7B%22elementName%22%3A%22form%22%2C%22className%22%3A%22space-y-6%22%7D", onSubmit: handleSubmit, className: "space-y-6", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:140:14", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "140", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:141:16", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "141", "data-component-file": "AddActivityModal.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-3%22%2C%22textContent%22%3A%22Activity%20Type%20*%22%7D", className: "block text-sm font-medium text-text-primary mb-3", children: "Activity Type *" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
            lineNumber: 141,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:142:16", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "142", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-2%20md%3Agrid-cols-5%20gap-3%22%7D", className: "grid grid-cols-2 md:grid-cols-5 gap-3", children: activityTypes.map(
            (type) => /* @__PURE__ */ jsxDEV(
              "button",
              {
                "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:144:18",
                "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx",
                "data-component-line": "144",
                "data-component-file": "AddActivityModal.jsx",
                "data-component-name": "button",
                "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22button%22%7D",
                type: "button",
                onClick: () => handleInputChange("type", type.value),
                className: `p-3 border rounded-lg flex flex-col items-center space-y-2 ${formData.type === type.value ? "border-primary bg-primary-50 text-primary" : "border-border hover:border-primary-50"}`,
                children: [
                  /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:153:22", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "153", "data-component-file": "AddActivityModal.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%7D", name: type.icon, size: 20 }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
                    lineNumber: 153,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:154:22", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "154", "data-component-file": "AddActivityModal.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20font-medium%22%7D", className: "text-sm font-medium", children: type.label }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
                    lineNumber: 154,
                    columnNumber: 23
                  }, this)
                ]
              },
              type.value,
              true,
              {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
                lineNumber: 144,
                columnNumber: 19
              },
              this
            )
          ) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
            lineNumber: 142,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
          lineNumber: 140,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:160:14", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "160", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:161:16", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "161", "data-component-file": "AddActivityModal.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Subject%20*%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Subject *" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
            lineNumber: 161,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:162:16",
              "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx",
              "data-component-line": "162",
              "data-component-file": "AddActivityModal.jsx",
              "data-component-name": "input",
              "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22text%22%7D",
              type: "text",
              value: formData.subject || "",
              onChange: (e) => handleInputChange("subject", e.target.value),
              className: `w-full input-field ${errors.subject ? "border-error" : ""}`,
              required: true
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
              lineNumber: 162,
              columnNumber: 17
            },
            this
          ),
          errors.subject && /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:169:35", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "169", "data-component-file": "AddActivityModal.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%20text-error%20mt-1%22%7D", className: "text-sm text-error mt-1", children: errors.subject }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
            lineNumber: 169,
            columnNumber: 36
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
          lineNumber: 160,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:172:14", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "172", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:173:16", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "173", "data-component-file": "AddActivityModal.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Description%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Description" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
            lineNumber: 173,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "textarea",
            {
              "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:174:16",
              "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx",
              "data-component-line": "174",
              "data-component-file": "AddActivityModal.jsx",
              "data-component-name": "textarea",
              "data-component-content": "%7B%22elementName%22%3A%22textarea%22%2C%22className%22%3A%22w-full%20input-field%22%7D",
              value: formData.description || "",
              onChange: (e) => handleInputChange("description", e.target.value),
              rows: 4,
              className: "w-full input-field"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
              lineNumber: 174,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
          lineNumber: 172,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:182:14", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "182", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20md%3Agrid-cols-2%20gap-4%22%7D", className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:183:16", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "183", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:184:18", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "184", "data-component-file": "AddActivityModal.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Related%20Contact%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Related Contact" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
              lineNumber: 184,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:185:18",
                "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx",
                "data-component-line": "185",
                "data-component-file": "AddActivityModal.jsx",
                "data-component-name": "select",
                "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22className%22%3A%22w-full%20input-field%22%7D",
                value: formData.contact_id || "",
                onChange: (e) => handleInputChange("contact_id", e.target.value),
                className: "w-full input-field",
                children: [
                  /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:190:20", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "190", "data-component-file": "AddActivityModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22%22%2C%22textContent%22%3A%22Select%20Contact%22%7D", value: "", children: "Select Contact" }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
                    lineNumber: 190,
                    columnNumber: 21
                  }, this),
                  contacts.map(
                    (contact) => /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:192:20", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "192", "data-component-file": "AddActivityModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%7D", value: contact.id, children: [
                      contact.first_name,
                      " ",
                      contact.last_name
                    ] }, contact.id, true, {
                      fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
                      lineNumber: 192,
                      columnNumber: 21
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
                lineNumber: 185,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
            lineNumber: 183,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:198:16", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "198", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:199:18", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "199", "data-component-file": "AddActivityModal.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Related%20Deal%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Related Deal" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
              lineNumber: 199,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:200:18",
                "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx",
                "data-component-line": "200",
                "data-component-file": "AddActivityModal.jsx",
                "data-component-name": "select",
                "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22className%22%3A%22w-full%20input-field%22%7D",
                value: formData.deal_id || "",
                onChange: (e) => handleInputChange("deal_id", e.target.value),
                className: "w-full input-field",
                children: [
                  /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:205:20", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "205", "data-component-file": "AddActivityModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22%22%2C%22textContent%22%3A%22Select%20Deal%22%7D", value: "", children: "Select Deal" }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
                    lineNumber: 205,
                    columnNumber: 21
                  }, this),
                  deals.map(
                    (deal) => /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:207:20", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "207", "data-component-file": "AddActivityModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%7D", value: deal.id, children: deal.name }, deal.id, false, {
                      fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
                      lineNumber: 207,
                      columnNumber: 21
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
                lineNumber: 200,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
            lineNumber: 198,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
          lineNumber: 182,
          columnNumber: 15
        }, this),
        ["call", "meeting"].includes(formData.type) && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:214:14", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "214", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20md%3Agrid-cols-2%20gap-4%22%7D", className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:215:18", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "215", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:216:20", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "216", "data-component-file": "AddActivityModal.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Duration%20(minutes)%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Duration (minutes)" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
              lineNumber: 216,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:217:20",
                "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx",
                "data-component-line": "217",
                "data-component-file": "AddActivityModal.jsx",
                "data-component-name": "input",
                "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22number%22%7D",
                type: "number",
                min: "1",
                value: formData.duration_minutes || "",
                onChange: (e) => handleInputChange("duration_minutes", e.target.value),
                className: `w-full input-field ${errors.duration_minutes ? "border-error" : ""}`
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
                lineNumber: 217,
                columnNumber: 21
              },
              this
            ),
            errors.duration_minutes && /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:224:48", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "224", "data-component-file": "AddActivityModal.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%20text-error%20mt-1%22%7D", className: "text-sm text-error mt-1", children: errors.duration_minutes }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
              lineNumber: 224,
              columnNumber: 49
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
            lineNumber: 215,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:226:18", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "226", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:227:20", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "227", "data-component-file": "AddActivityModal.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Date%2FTime%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Date/Time" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
              lineNumber: 227,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:228:20",
                "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx",
                "data-component-line": "228",
                "data-component-file": "AddActivityModal.jsx",
                "data-component-name": "input",
                "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22datetime-local%22%2C%22className%22%3A%22w-full%20input-field%22%7D",
                type: "datetime-local",
                value: formData.scheduled_at || "",
                onChange: (e) => handleInputChange("scheduled_at", e.target.value),
                className: "w-full input-field"
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
                lineNumber: 228,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
            lineNumber: 226,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
          lineNumber: 214,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:238:14", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "238", "data-component-file": "AddActivityModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20justify-end%20space-x-3%20pt-4%20border-t%20border-border%22%7D", className: "flex justify-end space-x-3 pt-4 border-t border-border", children: [
          /* @__PURE__ */ jsxDEV("button", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:239:16", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "239", "data-component-file": "AddActivityModal.jsx", "data-component-name": "button", "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22button%22%2C%22className%22%3A%22btn-secondary%22%2C%22textContent%22%3A%22Cancel%22%7D", type: "button", onClick: onClose, className: "btn-secondary", disabled: loading, children: "Cancel" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
            lineNumber: 239,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("button", { "data-component-id": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx:240:16", "data-component-path": "src\\pages\\activity-timeline\\components\\AddActivityModal.jsx", "data-component-line": "240", "data-component-file": "AddActivityModal.jsx", "data-component-name": "button", "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22submit%22%2C%22className%22%3A%22btn-primary%22%7D", type: "submit", className: "btn-primary", disabled: loading, children: loading ? "Creating..." : "Create Activity" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
            lineNumber: 240,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
          lineNumber: 238,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
        lineNumber: 139,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
      lineNumber: 125,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
      lineNumber: 124,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
    lineNumber: 122,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx",
    lineNumber: 121,
    columnNumber: 5
  }, this);
};
_s(AddActivityModal, "Q24rfnWk2fBYHH+XkXweowpy7Hw=", false, function() {
  return [useAuth];
});
_c = AddActivityModal;
export default AddActivityModal;
var _c;
$RefreshReg$(_c, "AddActivityModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/activity-timeline/components/AddActivityModal.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEhROzJCQTFIUjtBQUFnQkEsTUFBVUMsY0FBV0MsT0FBVyxzQkFBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMvRCxPQUFPQyxVQUFVO0FBQ2pCLFNBQVNDLGVBQWU7QUFDeEIsT0FBT0MsdUJBQXVCO0FBQzlCLE9BQU9DLHFCQUFxQjtBQUM1QixPQUFPQyxrQkFBa0I7QUFFekIsTUFBTUMsbUJBQW1CQSxDQUFDLEVBQUVDLFFBQVFDLFNBQVNDLGlCQUFpQkMsZ0JBQWdCLENBQUMsRUFBRSxNQUFNO0FBQUFDLEtBQUE7QUFDckYsUUFBTSxFQUFFQyxLQUFLLElBQUlWLFFBQVE7QUFDekIsUUFBTSxDQUFDVyxTQUFTQyxVQUFVLElBQUloQixTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDaUIsVUFBVUMsV0FBVyxJQUFJbEIsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ21CLE9BQU9DLFFBQVEsSUFBSXBCLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNxQixVQUFVQyxXQUFXLElBQUl0QixTQUFTLENBQUMsQ0FBQztBQUMzQyxRQUFNLENBQUN1QixRQUFRQyxTQUFTLElBQUl4QixTQUFTLENBQUMsQ0FBQztBQUV2QyxRQUFNeUIsbUJBQW1CdkIsWUFBWSxPQUFPO0FBQUEsSUFDMUN3QixNQUFNO0FBQUEsSUFDTkMsU0FBUztBQUFBLElBQ1RDLGFBQWE7QUFBQSxJQUNiQyxZQUFZO0FBQUEsSUFDWkMsU0FBUztBQUFBLElBQ1RDLGtCQUFrQjtBQUFBLElBQ2xCQyxjQUFjO0FBQUEsSUFDZEMsU0FBU25CLE1BQU1vQixNQUFNO0FBQUEsRUFDdkIsSUFBSSxDQUFDcEIsSUFBSSxDQUFDO0FBRVZiLFlBQVUsTUFBTTtBQUNkLFFBQUlRLFFBQVE7QUFDVixZQUFNMEIsV0FBVyxZQUFZO0FBQzNCLFlBQUk7QUFDRixnQkFBTSxDQUFDQyxjQUFjQyxTQUFTLElBQUksTUFBTUMsUUFBUUM7QUFBQUEsWUFBSTtBQUFBLGNBQ2xEakMsZ0JBQWdCa0MsZ0JBQWdCO0FBQUEsY0FDaENqQyxhQUFha0MsYUFBYTtBQUFBLFlBQUM7QUFBQSxVQUM1QjtBQUNEdkIsc0JBQVlrQixnQkFBZ0IsRUFBRTtBQUM5QmhCLG1CQUFTaUIsYUFBYSxFQUFFO0FBQUEsUUFDMUIsU0FBU0ssS0FBSztBQUNaQyxrQkFBUUMsTUFBTSw2QkFBNkJGLEdBQUc7QUFDOUNsQixvQkFBVSxFQUFFcUIsUUFBUSxxQ0FBcUMsQ0FBQztBQUFBLFFBQzVEO0FBQUEsTUFDRjtBQUNBVixlQUFTO0FBQ1RiLGtCQUFZLEVBQUUsR0FBR0csaUJBQWlCLEdBQUcsR0FBR2IsY0FBYyxDQUFDO0FBQUEsSUFDekQsT0FBTztBQUNMVSxrQkFBWSxDQUFDLENBQUM7QUFDZEUsZ0JBQVUsQ0FBQyxDQUFDO0FBQUEsSUFDZDtBQUFBLEVBQ0YsR0FBRyxDQUFDZixNQUFNLENBQUM7QUFFWCxRQUFNcUMsZUFBZSxPQUFPQyxNQUFNO0FBQ2hDQSxNQUFFQyxlQUFlO0FBQ2pCaEMsZUFBVyxJQUFJO0FBQ2ZRLGNBQVUsQ0FBQyxDQUFDO0FBRVosUUFBSTtBQUNGLFlBQU15QixpQkFBaUIsQ0FBQyxRQUFRLFNBQVM7QUFDekMsWUFBTUMsbUJBQW1CLENBQUM7QUFFMUJELHFCQUFlRSxRQUFRLENBQUFDLFVBQVM7QUFDOUIsWUFBSSxDQUFDL0IsU0FBUytCLEtBQUssR0FBR0MsS0FBSyxHQUFHO0FBQzVCSCwyQkFBaUJFLEtBQUssSUFBSSxHQUFHQSxNQUFNRSxRQUFRLEtBQUssR0FBRyxDQUFDO0FBQUEsUUFDdEQ7QUFBQSxNQUNGLENBQUM7QUFFRCxVQUFJLENBQUMsUUFBUSxTQUFTLEVBQUVDLFNBQVNsQyxTQUFTSyxJQUFJLEtBQUtMLFNBQVNVLHFCQUN2RHlCLE1BQU1uQyxTQUFTVSxnQkFBZ0IsS0FBSzBCLFNBQVNwQyxTQUFTVSxnQkFBZ0IsS0FBSyxJQUFJO0FBQ2xGbUIseUJBQWlCbkIsbUJBQW1CO0FBQUEsTUFDdEM7QUFFQSxVQUFJMkIsT0FBT0MsS0FBS1QsZ0JBQWdCLEVBQUVVLFNBQVMsR0FBRztBQUM1Q3BDLGtCQUFVMEIsZ0JBQWdCO0FBQzFCbEMsbUJBQVcsS0FBSztBQUNoQjtBQUFBLE1BQ0Y7QUFFQSxZQUFNNkMsYUFBYTtBQUFBLFFBQ2pCLEdBQUd4QztBQUFBQSxRQUNIVSxrQkFBa0JWLFNBQVNVLG1CQUFtQjBCLFNBQVNwQyxTQUFTVSxnQkFBZ0IsSUFBSTtBQUFBLFFBQ3BGQyxjQUFjWCxTQUFTVyxnQkFBZ0I7QUFBQSxRQUN2Q0MsU0FBU25CLE1BQU1vQjtBQUFBQSxRQUNmTCxZQUFZUixTQUFTUSxjQUFjO0FBQUEsUUFDbkNDLFNBQVNULFNBQVNTLFdBQVc7QUFBQSxNQUMvQjtBQUVBLFlBQU1nQyxjQUFjLE1BQU16RCxrQkFBa0IwRCxlQUFlRixVQUFVO0FBQ3JFbEQsc0JBQWdCbUQsV0FBVztBQUMzQnBELGNBQVE7QUFBQSxJQUVWLFNBQVNnQyxLQUFLO0FBQ1pDLGNBQVFDLE1BQU0sNEJBQTRCRixHQUFHO0FBQzdDbEIsZ0JBQVU7QUFBQSxRQUNScUIsUUFBUUgsSUFBSXNCLFdBQVc7QUFBQSxNQUN6QixDQUFDO0FBQUEsSUFDSCxVQUFDO0FBQ0NoRCxpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBRUEsUUFBTWlELG9CQUFvQkEsQ0FBQ2IsT0FBT2MsVUFBVTtBQUMxQzVDLGdCQUFZLENBQUE2QyxVQUFTLEVBQUUsR0FBR0EsTUFBTSxDQUFDZixLQUFLLEdBQUdjLE1BQU0sRUFBRTtBQUNqRCxRQUFJM0MsT0FBTzZCLEtBQUssR0FBRztBQUNqQjVCLGdCQUFVLENBQUEyQyxTQUFRO0FBQ2hCLGNBQU1DLFlBQVksRUFBRSxHQUFHRCxLQUFLO0FBQzVCLGVBQU9DLFVBQVVoQixLQUFLO0FBQ3RCLGVBQU9nQjtBQUFBQSxNQUNULENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUVBLFFBQU1DLGdCQUFnQjtBQUFBLElBQ3BCLEVBQUVILE9BQU8sUUFBUUksT0FBTyxRQUFRQyxNQUFNLFdBQVc7QUFBQSxJQUNqRCxFQUFFTCxPQUFPLFFBQVFJLE9BQU8sUUFBUUMsTUFBTSxRQUFRO0FBQUEsSUFDOUMsRUFBRUwsT0FBTyxTQUFTSSxPQUFPLFNBQVNDLE1BQU0sT0FBTztBQUFBLElBQy9DLEVBQUVMLE9BQU8sV0FBV0ksT0FBTyxXQUFXQyxNQUFNLFdBQVc7QUFBQSxJQUN2RCxFQUFFTCxPQUFPLFFBQVFJLE9BQU8sUUFBUUMsTUFBTSxjQUFjO0FBQUEsRUFBQztBQUd2RCxNQUFJLENBQUM5RDtBQUFRLFdBQU87QUFFcEIsU0FDRSx1QkFBQyxnYkFBSSxXQUFVLHNDQUNiLGlDQUFDLGtjQUFJLFdBQVUsc0RBQ2I7QUFBQSwyQkFBQyxrYkFBSSxXQUFVLHdDQUF1QyxTQUFTQyxXQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdFO0FBQUEsSUFDeEUsdUJBQUMsa2RBQUksV0FBVSxrRUFDYixpQ0FBQyw0WUFBSSxXQUFVLE9BQ2I7QUFBQSw2QkFBQyxxYkFBSSxXQUFVLDBDQUNiO0FBQUEsK0JBQUMsa2VBQUcsV0FBVSwyQ0FBMEMsZ0NBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0U7QUFBQSxRQUN4RSx1QkFBQyxpY0FBTyxTQUFTQSxTQUFTLFdBQVUsK0NBQ2xDLGlDQUFDLHNZQUFLLE1BQUssS0FBSSxNQUFNLE1BQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0IsS0FEMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUVDYSxPQUFPc0IsVUFDTix1QkFBQyx1ZEFBSSxXQUFVLHNFQUNadEIsaUJBQU9zQixVQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BR0YsdUJBQUMscVpBQUssVUFBVUMsY0FBYyxXQUFVLGFBQ3RDO0FBQUEsK0JBQUMsOFdBQ0M7QUFBQSxpQ0FBQyx1ZkFBTSxXQUFVLG9EQUFtRCwrQkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUY7QUFBQSxVQUNuRix1QkFBQyxzYkFBSSxXQUFVLHlDQUNadUIsd0JBQWNHO0FBQUFBLFlBQUksQ0FBQTlDLFNBQ2pCO0FBQUEsY0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRUMsTUFBSztBQUFBLGdCQUNMLFNBQVMsTUFBTXVDLGtCQUFrQixRQUFRdkMsS0FBS3dDLEtBQUs7QUFBQSxnQkFDbkQsV0FBVyw4REFDVDdDLFNBQVNLLFNBQVNBLEtBQUt3QyxRQUNuQiw4Q0FBNkMsdUNBQXVDO0FBQUEsZ0JBRzFGO0FBQUEseUNBQUMsK1dBQUssTUFBTXhDLEtBQUs2QyxNQUFNLE1BQU0sTUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQSxrQkFDaEMsdUJBQUMsaWFBQUssV0FBVSx1QkFBdUI3QyxlQUFLNEMsU0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa0Q7QUFBQTtBQUFBO0FBQUEsY0FUN0M1QyxLQUFLd0M7QUFBQUEsY0FEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBV0E7QUFBQSxVQUNELEtBZEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFlQTtBQUFBLGFBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQkE7QUFBQSxRQUVBLHVCQUFDLDhXQUNDO0FBQUEsaUNBQUMsK2VBQU0sV0FBVSxvREFBbUQseUJBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZFO0FBQUEsVUFDN0U7QUFBQSxZQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE9BQU83QyxTQUFTTSxXQUFXO0FBQUEsY0FDM0IsVUFBVSxDQUFDb0IsTUFBTWtCLGtCQUFrQixXQUFXbEIsRUFBRTBCLE9BQU9QLEtBQUs7QUFBQSxjQUM1RCxXQUFXLHNCQUFzQjNDLE9BQU9JLFVBQVUsaUJBQWlCLEVBQUU7QUFBQSxjQUNyRSxVQUFRO0FBQUE7QUFBQSxZQUxWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtVO0FBQUEsVUFFVEosT0FBT0ksV0FBVyx1QkFBQyw4WkFBRSxXQUFVLDJCQUEyQkosaUJBQU9JLFdBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVEO0FBQUEsYUFUNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsUUFFQSx1QkFBQyw4V0FDQztBQUFBLGlDQUFDLCtlQUFNLFdBQVUsb0RBQW1ELDJCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRTtBQUFBLFVBQy9FO0FBQUEsWUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FDQyxPQUFPTixTQUFTTyxlQUFlO0FBQUEsY0FDL0IsVUFBVSxDQUFDbUIsTUFBTWtCLGtCQUFrQixlQUFlbEIsRUFBRTBCLE9BQU9QLEtBQUs7QUFBQSxjQUNoRSxNQUFNO0FBQUEsY0FDTixXQUFVO0FBQUE7QUFBQSxZQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUlnQztBQUFBLGFBTmxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBRUEsdUJBQUMsc2JBQUksV0FBVSx5Q0FDYjtBQUFBLGlDQUFDLDhXQUNDO0FBQUEsbUNBQUMscWZBQU0sV0FBVSxvREFBbUQsK0JBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1GO0FBQUEsWUFDbkY7QUFBQSxjQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFDQyxPQUFPN0MsU0FBU1EsY0FBYztBQUFBLGdCQUM5QixVQUFVLENBQUNrQixNQUFNa0Isa0JBQWtCLGNBQWNsQixFQUFFMEIsT0FBT1AsS0FBSztBQUFBLGdCQUMvRCxXQUFVO0FBQUEsZ0JBRVY7QUFBQSx5Q0FBQywyYkFBTyxPQUFNLElBQUcsOEJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQStCO0FBQUEsa0JBQzlCakQsU0FBU3VEO0FBQUFBLG9CQUFJLENBQUFFLFlBQ1osdUJBQUMsdVhBQXdCLE9BQU9BLFFBQVF4QyxJQUNyQ3dDO0FBQUFBLDhCQUFRQztBQUFBQSxzQkFBVztBQUFBLHNCQUFFRCxRQUFRRTtBQUFBQSx5QkFEbkJGLFFBQVF4QyxJQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBO0FBQUEsY0FWSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFXQTtBQUFBLGVBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFjQTtBQUFBLFVBQ0EsdUJBQUMsOFdBQ0M7QUFBQSxtQ0FBQyxrZkFBTSxXQUFVLG9EQUFtRCw0QkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0Y7QUFBQSxZQUNoRjtBQUFBLGNBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUNDLE9BQU9iLFNBQVNTLFdBQVc7QUFBQSxnQkFDM0IsVUFBVSxDQUFDaUIsTUFBTWtCLGtCQUFrQixXQUFXbEIsRUFBRTBCLE9BQU9QLEtBQUs7QUFBQSxnQkFDNUQsV0FBVTtBQUFBLGdCQUVWO0FBQUEseUNBQUMsd2JBQU8sT0FBTSxJQUFHLDJCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE0QjtBQUFBLGtCQUMzQi9DLE1BQU1xRDtBQUFBQSxvQkFBSSxDQUFBSyxTQUNULHVCQUFDLHVYQUFxQixPQUFPQSxLQUFLM0MsSUFBSzJDLGVBQUtDLFFBQS9CRCxLQUFLM0MsSUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUQ7QUFBQSxrQkFDbEQ7QUFBQTtBQUFBO0FBQUEsY0FSSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFTQTtBQUFBLGVBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFZQTtBQUFBLGFBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE2QkE7QUFBQSxRQUVDLENBQUMsUUFBUSxTQUFTLEVBQUVxQixTQUFTbEMsU0FBU0ssSUFBSSxLQUN6Qyx1QkFBQyxzYkFBSSxXQUFVLHlDQUNiO0FBQUEsaUNBQUMsOFdBQ0M7QUFBQSxtQ0FBQyx3ZkFBTSxXQUFVLG9EQUFtRCxrQ0FBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0Y7QUFBQSxZQUN0RjtBQUFBLGNBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxLQUFJO0FBQUEsZ0JBQ0osT0FBT0wsU0FBU1Usb0JBQW9CO0FBQUEsZ0JBQ3BDLFVBQVUsQ0FBQ2dCLE1BQU1rQixrQkFBa0Isb0JBQW9CbEIsRUFBRTBCLE9BQU9QLEtBQUs7QUFBQSxnQkFDckUsV0FBVyxzQkFBc0IzQyxPQUFPUSxtQkFBbUIsaUJBQWlCLEVBQUU7QUFBQTtBQUFBLGNBTGhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUttRjtBQUFBLFlBRWxGUixPQUFPUSxvQkFBb0IsdUJBQUMsOFpBQUUsV0FBVSwyQkFBMkJSLGlCQUFPUSxvQkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0U7QUFBQSxlQVQ5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsVUFDQSx1QkFBQyw4V0FDQztBQUFBLG1DQUFDLCtlQUFNLFdBQVUsb0RBQW1ELHlCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RTtBQUFBLFlBQzdFO0FBQUEsY0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE9BQU9WLFNBQVNXLGdCQUFnQjtBQUFBLGdCQUNoQyxVQUFVLENBQUNlLE1BQU1rQixrQkFBa0IsZ0JBQWdCbEIsRUFBRTBCLE9BQU9QLEtBQUs7QUFBQSxnQkFDakUsV0FBVTtBQUFBO0FBQUEsY0FKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJZ0M7QUFBQSxlQU5sQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsYUFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXFCQTtBQUFBLFFBR0YsdUJBQUMseWNBQUksV0FBVSwwREFDYjtBQUFBLGlDQUFDLDhkQUFPLE1BQUssVUFBUyxTQUFTeEQsU0FBUyxXQUFVLGlCQUFnQixVQUFVSyxTQUFTLHNCQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRjtBQUFBLFVBQzNGLHVCQUFDLHliQUFPLE1BQUssVUFBUyxXQUFVLGVBQWMsVUFBVUEsU0FDckRBLG9CQUFVLGdCQUFnQixxQkFEN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsV0F4R0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlHQTtBQUFBLFNBdkhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3SEEsS0F6SEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBIQTtBQUFBLE9BNUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2SEEsS0E5SEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQStIQTtBQUVKO0FBQUVGLEdBbFBJTCxrQkFBZ0I7QUFBQSxVQUNISixPQUFPO0FBQUE7QUFBQTJFLEtBRHBCdkU7QUFvUE4sZUFBZUE7QUFBaUIsSUFBQXVFO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZUNhbGxiYWNrIiwiSWNvbiIsInVzZUF1dGgiLCJhY3Rpdml0aWVzU2VydmljZSIsImNvbnRhY3RzU2VydmljZSIsImRlYWxzU2VydmljZSIsIkFkZEFjdGl2aXR5TW9kYWwiLCJpc09wZW4iLCJvbkNsb3NlIiwib25BY3Rpdml0eUFkZGVkIiwicHJlZmlsbGVkRGF0YSIsIl9zIiwidXNlciIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwiY29udGFjdHMiLCJzZXRDb250YWN0cyIsImRlYWxzIiwic2V0RGVhbHMiLCJmb3JtRGF0YSIsInNldEZvcm1EYXRhIiwiZXJyb3JzIiwic2V0RXJyb3JzIiwiaW5pdGlhbEZvcm1TdGF0ZSIsInR5cGUiLCJzdWJqZWN0IiwiZGVzY3JpcHRpb24iLCJjb250YWN0X2lkIiwiZGVhbF9pZCIsImR1cmF0aW9uX21pbnV0ZXMiLCJzY2hlZHVsZWRfYXQiLCJ1c2VyX2lkIiwiaWQiLCJsb2FkRGF0YSIsImNvbnRhY3RzRGF0YSIsImRlYWxzRGF0YSIsIlByb21pc2UiLCJhbGwiLCJnZXRVc2VyQ29udGFjdHMiLCJnZXRVc2VyRGVhbHMiLCJlcnIiLCJjb25zb2xlIiwiZXJyb3IiLCJzdWJtaXQiLCJoYW5kbGVTdWJtaXQiLCJlIiwicHJldmVudERlZmF1bHQiLCJyZXF1aXJlZEZpZWxkcyIsInZhbGlkYXRpb25FcnJvcnMiLCJmb3JFYWNoIiwiZmllbGQiLCJ0cmltIiwicmVwbGFjZSIsImluY2x1ZGVzIiwiaXNOYU4iLCJwYXJzZUludCIsIk9iamVjdCIsImtleXMiLCJsZW5ndGgiLCJzdWJtaXREYXRhIiwibmV3QWN0aXZpdHkiLCJjcmVhdGVBY3Rpdml0eSIsIm1lc3NhZ2UiLCJoYW5kbGVJbnB1dENoYW5nZSIsInZhbHVlIiwicHJldiIsIm5ld0Vycm9ycyIsImFjdGl2aXR5VHlwZXMiLCJsYWJlbCIsImljb24iLCJtYXAiLCJ0YXJnZXQiLCJjb250YWN0IiwiZmlyc3RfbmFtZSIsImxhc3RfbmFtZSIsImRlYWwiLCJuYW1lIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBZGRBY3Rpdml0eU1vZGFsLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlQ2FsbGJhY2sgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCBJY29uIGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvQXBwSWNvbic7XHJcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tICcuLi8uLi8uLi9jb250ZXh0cy9BdXRoQ29udGV4dCc7XHJcbmltcG9ydCBhY3Rpdml0aWVzU2VydmljZSBmcm9tICcuLi8uLi8uLi9zZXJ2aWNlcy9hY3Rpdml0aWVzU2VydmljZSc7XHJcbmltcG9ydCBjb250YWN0c1NlcnZpY2UgZnJvbSAnLi4vLi4vLi4vc2VydmljZXMvY29udGFjdHNTZXJ2aWNlJztcclxuaW1wb3J0IGRlYWxzU2VydmljZSBmcm9tICcuLi8uLi8uLi9zZXJ2aWNlcy9kZWFsc1NlcnZpY2UnO1xyXG5cclxuY29uc3QgQWRkQWN0aXZpdHlNb2RhbCA9ICh7IGlzT3Blbiwgb25DbG9zZSwgb25BY3Rpdml0eUFkZGVkLCBwcmVmaWxsZWREYXRhID0ge30gfSkgPT4ge1xyXG4gIGNvbnN0IHsgdXNlciB9ID0gdXNlQXV0aCgpO1xyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY29udGFjdHMsIHNldENvbnRhY3RzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZGVhbHMsIHNldERlYWxzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG5cclxuICBjb25zdCBpbml0aWFsRm9ybVN0YXRlID0gdXNlQ2FsbGJhY2soKCkgPT4gKHtcclxuICAgIHR5cGU6ICdub3RlJyxcclxuICAgIHN1YmplY3Q6ICcnLFxyXG4gICAgZGVzY3JpcHRpb246ICcnLFxyXG4gICAgY29udGFjdF9pZDogJycsXHJcbiAgICBkZWFsX2lkOiAnJyxcclxuICAgIGR1cmF0aW9uX21pbnV0ZXM6ICcnLFxyXG4gICAgc2NoZWR1bGVkX2F0OiAnJyxcclxuICAgIHVzZXJfaWQ6IHVzZXI/LmlkIHx8ICcnXHJcbiAgfSksIFt1c2VyXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoaXNPcGVuKSB7XHJcbiAgICAgIGNvbnN0IGxvYWREYXRhID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBjb25zdCBbY29udGFjdHNEYXRhLCBkZWFsc0RhdGFdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xyXG4gICAgICAgICAgICBjb250YWN0c1NlcnZpY2UuZ2V0VXNlckNvbnRhY3RzKCksXHJcbiAgICAgICAgICAgIGRlYWxzU2VydmljZS5nZXRVc2VyRGVhbHMoKVxyXG4gICAgICAgICAgXSk7XHJcbiAgICAgICAgICBzZXRDb250YWN0cyhjb250YWN0c0RhdGEgfHwgW10pO1xyXG4gICAgICAgICAgc2V0RGVhbHMoZGVhbHNEYXRhIHx8IFtdKTtcclxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBsb2FkaW5nIG1vZGFsIGRhdGE6XCIsIGVycik7XHJcbiAgICAgICAgICBzZXRFcnJvcnMoeyBzdWJtaXQ6IFwiRmFpbGVkIHRvIGxvYWQgY29udGFjdHMgYW5kIGRlYWxzLlwiIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgfTtcclxuICAgICAgbG9hZERhdGEoKTtcclxuICAgICAgc2V0Rm9ybURhdGEoeyAuLi5pbml0aWFsRm9ybVN0YXRlKCksIC4uLnByZWZpbGxlZERhdGEgfSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRGb3JtRGF0YSh7fSk7XHJcbiAgICAgIHNldEVycm9ycyh7fSk7XHJcbiAgICB9XHJcbiAgfSwgW2lzT3Blbl0pO1xyXG5cclxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgc2V0TG9hZGluZyh0cnVlKTtcclxuICAgIHNldEVycm9ycyh7fSk7XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVxdWlyZWRGaWVsZHMgPSBbJ3R5cGUnLCAnc3ViamVjdCddO1xyXG4gICAgICBjb25zdCB2YWxpZGF0aW9uRXJyb3JzID0ge307XHJcbiAgICAgIFxyXG4gICAgICByZXF1aXJlZEZpZWxkcy5mb3JFYWNoKGZpZWxkID0+IHtcclxuICAgICAgICBpZiAoIWZvcm1EYXRhW2ZpZWxkXT8udHJpbSgpKSB7XHJcbiAgICAgICAgICB2YWxpZGF0aW9uRXJyb3JzW2ZpZWxkXSA9IGAke2ZpZWxkLnJlcGxhY2UoJ18nLCAnICcpfSBpcyByZXF1aXJlZGA7XHJcbiAgICAgICAgfVxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGlmIChbJ2NhbGwnLCAnbWVldGluZyddLmluY2x1ZGVzKGZvcm1EYXRhLnR5cGUpICYmIGZvcm1EYXRhLmR1cmF0aW9uX21pbnV0ZXMgJiYgXHJcbiAgICAgICAgICAoaXNOYU4oZm9ybURhdGEuZHVyYXRpb25fbWludXRlcykgfHwgcGFyc2VJbnQoZm9ybURhdGEuZHVyYXRpb25fbWludXRlcykgPD0gMCkpIHtcclxuICAgICAgICB2YWxpZGF0aW9uRXJyb3JzLmR1cmF0aW9uX21pbnV0ZXMgPSAnUGxlYXNlIGVudGVyIGEgdmFsaWQgZHVyYXRpb24nO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBpZiAoT2JqZWN0LmtleXModmFsaWRhdGlvbkVycm9ycykubGVuZ3RoID4gMCkge1xyXG4gICAgICAgIHNldEVycm9ycyh2YWxpZGF0aW9uRXJyb3JzKTtcclxuICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgICByZXR1cm47XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGNvbnN0IHN1Ym1pdERhdGEgPSB7XHJcbiAgICAgICAgLi4uZm9ybURhdGEsXHJcbiAgICAgICAgZHVyYXRpb25fbWludXRlczogZm9ybURhdGEuZHVyYXRpb25fbWludXRlcyA/IHBhcnNlSW50KGZvcm1EYXRhLmR1cmF0aW9uX21pbnV0ZXMpIDogbnVsbCxcclxuICAgICAgICBzY2hlZHVsZWRfYXQ6IGZvcm1EYXRhLnNjaGVkdWxlZF9hdCB8fCBudWxsLFxyXG4gICAgICAgIHVzZXJfaWQ6IHVzZXI/LmlkLFxyXG4gICAgICAgIGNvbnRhY3RfaWQ6IGZvcm1EYXRhLmNvbnRhY3RfaWQgfHwgbnVsbCxcclxuICAgICAgICBkZWFsX2lkOiBmb3JtRGF0YS5kZWFsX2lkIHx8IG51bGwsXHJcbiAgICAgIH07XHJcblxyXG4gICAgICBjb25zdCBuZXdBY3Rpdml0eSA9IGF3YWl0IGFjdGl2aXRpZXNTZXJ2aWNlLmNyZWF0ZUFjdGl2aXR5KHN1Ym1pdERhdGEpO1xyXG4gICAgICBvbkFjdGl2aXR5QWRkZWQobmV3QWN0aXZpdHkpO1xyXG4gICAgICBvbkNsb3NlKCk7XHJcblxyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGNyZWF0aW5nIGFjdGl2aXR5OicsIGVycik7XHJcbiAgICAgIHNldEVycm9ycyh7IFxyXG4gICAgICAgIHN1Ym1pdDogZXJyLm1lc3NhZ2UgfHwgJ0ZhaWxlZCB0byBjcmVhdGUgYWN0aXZpdHkuIFBsZWFzZSB0cnkgYWdhaW4uJyBcclxuICAgICAgfSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVJbnB1dENoYW5nZSA9IChmaWVsZCwgdmFsdWUpID0+IHtcclxuICAgIHNldEZvcm1EYXRhKHByZXYgPT4gKHsgLi4ucHJldiwgW2ZpZWxkXTogdmFsdWUgfSkpO1xyXG4gICAgaWYgKGVycm9yc1tmaWVsZF0pIHtcclxuICAgICAgc2V0RXJyb3JzKHByZXYgPT4ge1xyXG4gICAgICAgIGNvbnN0IG5ld0Vycm9ycyA9IHsgLi4ucHJldiB9O1xyXG4gICAgICAgIGRlbGV0ZSBuZXdFcnJvcnNbZmllbGRdO1xyXG4gICAgICAgIHJldHVybiBuZXdFcnJvcnM7XHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGFjdGl2aXR5VHlwZXMgPSBbXHJcbiAgICB7IHZhbHVlOiAnbm90ZScsIGxhYmVsOiAnTm90ZScsIGljb246ICdGaWxlVGV4dCcgfSxcclxuICAgIHsgdmFsdWU6ICdjYWxsJywgbGFiZWw6ICdDYWxsJywgaWNvbjogJ1Bob25lJyB9LFxyXG4gICAgeyB2YWx1ZTogJ2VtYWlsJywgbGFiZWw6ICdFbWFpbCcsIGljb246ICdNYWlsJyB9LFxyXG4gICAgeyB2YWx1ZTogJ21lZXRpbmcnLCBsYWJlbDogJ01lZXRpbmcnLCBpY29uOiAnQ2FsZW5kYXInIH0sXHJcbiAgICB7IHZhbHVlOiAndGFzaycsIGxhYmVsOiAnVGFzaycsIGljb246ICdDaGVja1NxdWFyZScgfSxcclxuICBdO1xyXG5cclxuICBpZiAoIWlzT3BlbikgcmV0dXJuIG51bGw7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBvdmVyZmxvdy15LWF1dG9cIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBtaW4taC1zY3JlZW4gcHgtNFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBiZy1ibGFjayBiZy1vcGFjaXR5LTUwXCIgb25DbGljaz17b25DbG9zZX0+PC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zdXJmYWNlIHJvdW5kZWQtbGcgc2hhZG93LXhsIG1heC13LTJ4bCB3LWZ1bGwgcmVsYXRpdmUgei0xMFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTZcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItNlwiPlxyXG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtc2VtaWJvbGQgdGV4dC10ZXh0LXByaW1hcnlcIj5BZGQgTmV3IEFjdGl2aXR5PC9oMz5cclxuICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e29uQ2xvc2V9IGNsYXNzTmFtZT1cInRleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC10ZXh0LXByaW1hcnlcIj5cclxuICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJYXCIgc2l6ZT17MjR9IC8+XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAge2Vycm9ycy5zdWJtaXQgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZXJyb3ItNTAgYm9yZGVyIGJvcmRlci1lcnJvci0yMDAgdGV4dC1lcnJvciBwLTQgcm91bmRlZC1sZyBtYi02XCI+XHJcbiAgICAgICAgICAgICAgICB7ZXJyb3JzLnN1Ym1pdH1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSBtYi0zXCI+QWN0aXZpdHkgVHlwZSAqPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBtZDpncmlkLWNvbHMtNSBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICB7YWN0aXZpdHlUeXBlcy5tYXAodHlwZSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXt0eXBlLnZhbHVlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVJbnB1dENoYW5nZSgndHlwZScsIHR5cGUudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0zIGJvcmRlciByb3VuZGVkLWxnIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIHNwYWNlLXktMiAke1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YS50eXBlID09PSB0eXBlLnZhbHVlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYm9yZGVyLXByaW1hcnkgYmctcHJpbWFyeS01MCB0ZXh0LXByaW1hcnknIDonYm9yZGVyLWJvcmRlciBob3Zlcjpib3JkZXItcHJpbWFyeS01MCdcclxuICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9e3R5cGUuaWNvbn0gc2l6ZT17MjB9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+e3R5cGUubGFiZWx9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItMVwiPlN1YmplY3QgKjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuc3ViamVjdCB8fCAnJ31cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVJbnB1dENoYW5nZSgnc3ViamVjdCcsIGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIGlucHV0LWZpZWxkICR7ZXJyb3JzLnN1YmplY3QgPyAnYm9yZGVyLWVycm9yJyA6ICcnfWB9XHJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAge2Vycm9ycy5zdWJqZWN0ICYmIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1lcnJvciBtdC0xXCI+e2Vycm9ycy5zdWJqZWN0fTwvcD59XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSBtYi0xXCI+RGVzY3JpcHRpb248L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPHRleHRhcmVhXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5kZXNjcmlwdGlvbiB8fCAnJ31cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVJbnB1dENoYW5nZSgnZGVzY3JpcHRpb24nLCBlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgIHJvd3M9ezR9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBpbnB1dC1maWVsZFwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IG1iLTFcIj5SZWxhdGVkIENvbnRhY3Q8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmNvbnRhY3RfaWQgfHwgJyd9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVJbnB1dENoYW5nZSgnY29udGFjdF9pZCcsIGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaW5wdXQtZmllbGRcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBDb250YWN0PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAge2NvbnRhY3RzLm1hcChjb250YWN0ID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtjb250YWN0LmlkfSB2YWx1ZT17Y29udGFjdC5pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtjb250YWN0LmZpcnN0X25hbWV9IHtjb250YWN0Lmxhc3RfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItMVwiPlJlbGF0ZWQgRGVhbDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZGVhbF9pZCB8fCAnJ31cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUlucHV0Q2hhbmdlKCdkZWFsX2lkJywgZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBpbnB1dC1maWVsZFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IERlYWw8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICB7ZGVhbHMubWFwKGRlYWwgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2RlYWwuaWR9IHZhbHVlPXtkZWFsLmlkfT57ZGVhbC5uYW1lfTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7WydjYWxsJywgJ21lZXRpbmcnXS5pbmNsdWRlcyhmb3JtRGF0YS50eXBlKSAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSBtYi0xXCI+RHVyYXRpb24gKG1pbnV0ZXMpPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbWluPVwiMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZHVyYXRpb25fbWludXRlcyB8fCAnJ31cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlSW5wdXRDaGFuZ2UoJ2R1cmF0aW9uX21pbnV0ZXMnLCBlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LWZ1bGwgaW5wdXQtZmllbGQgJHtlcnJvcnMuZHVyYXRpb25fbWludXRlcyA/ICdib3JkZXItZXJyb3InIDogJyd9YH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZHVyYXRpb25fbWludXRlcyAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZXJyb3IgbXQtMVwiPntlcnJvcnMuZHVyYXRpb25fbWludXRlc308L3A+fVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSBtYi0xXCI+RGF0ZS9UaW1lPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRldGltZS1sb2NhbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuc2NoZWR1bGVkX2F0IHx8ICcnfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVJbnB1dENoYW5nZSgnc2NoZWR1bGVkX2F0JywgZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGlucHV0LWZpZWxkXCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBzcGFjZS14LTMgcHQtNCBib3JkZXItdCBib3JkZXItYm9yZGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXtvbkNsb3NlfSBjbGFzc05hbWU9XCJidG4tc2Vjb25kYXJ5XCIgZGlzYWJsZWQ9e2xvYWRpbmd9PkNhbmNlbDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgY2xhc3NOYW1lPVwiYnRuLXByaW1hcnlcIiBkaXNhYmxlZD17bG9hZGluZ30+XHJcbiAgICAgICAgICAgICAgICAgIHtsb2FkaW5nID8gJ0NyZWF0aW5nLi4uJyA6ICdDcmVhdGUgQWN0aXZpdHknfVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBBZGRBY3Rpdml0eU1vZGFsO1xyXG4iXSwiZmlsZSI6IkQ6L2N1cnJlbnQgcHJvamVjdHMvY2xhdWRlLWNvZGUvc3JjL3BhZ2VzL2FjdGl2aXR5LXRpbWVsaW5lL2NvbXBvbmVudHMvQWRkQWN0aXZpdHlNb2RhbC5qc3gifQ==