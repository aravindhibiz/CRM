import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/settings-administration/components/UserManagement.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import Icon from "/src/components/AppIcon.jsx";
import { useAuth } from "/src/contexts/AuthContext.jsx";
import userService from "/src/services/userService.js";
const UserManagement = () => {
  _s();
  const { user: currentUser, userProfile } = useAuth();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [inviteForm, setInviteForm] = useState({
    email: "",
    firstName: "",
    lastName: "",
    role: "",
    message: ""
  });
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [roleFilter, setRoleFilter] = useState("all");
  const roles = userService?.getUserRoles();
  const loadUsers = async () => {
    try {
      setLoading(true);
      setError("");
      let userData = [];
      if (searchQuery) {
        userData = await userService?.searchUsers(searchQuery);
      } else {
        const filters = {};
        if (statusFilter !== "all") {
          filters.status = statusFilter;
        }
        if (roleFilter !== "all") {
          filters.roles = [roleFilter];
        }
        if (Object.keys(filters)?.length > 0) {
          userData = await userService?.filterUsers(filters);
        } else {
          userData = await userService?.getAllUsers();
        }
      }
      const transformedUsers = userData?.map((user) => ({
        id: user?.id,
        name: user?.full_name || `${user?.first_name} ${user?.last_name}`?.trim(),
        email: user?.email,
        role: roles?.find((r) => r?.value === user?.role)?.label || user?.role,
        status: user?.is_active ? "Active" : "Inactive",
        lastLogin: user?.updated_at ? new Date(user?.updated_at)?.toLocaleString() : "Never",
        avatar: user?.avatar_url,
        rawData: user
      }));
      setUsers(transformedUsers);
    } catch (err) {
      console.error("Error loading users:", err);
      setError("Failed to load users. Please try again.");
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    if (currentUser && userProfile?.role === "admin") {
      loadUsers();
    }
  }, [currentUser, userProfile, searchQuery, statusFilter, roleFilter]);
  useEffect(() => {
    if (error || success) {
      const timer = setTimeout(() => {
        setError("");
        setSuccess("");
      }, 5e3);
      return () => clearTimeout(timer);
    }
  }, [error, success]);
  const handleSelectUser = (userId) => {
    setSelectedUsers(
      (prev) => prev?.includes(userId) ? prev?.filter((id) => id !== userId) : [...prev, userId]
    );
  };
  const handleSelectAll = () => {
    setSelectedUsers(
      selectedUsers?.length === users?.length ? [] : users?.map((user) => user?.id)
    );
  };
  const handleBulkAction = async (action) => {
    try {
      setError("");
      let updates = {};
      switch (action) {
        case "activate":
          updates = { is_active: true };
          break;
        case "deactivate":
          updates = { is_active: false };
          break;
        case "delete":
          updates = { is_active: false };
          break;
      }
      await userService?.bulkUpdateUsers(selectedUsers, updates);
      setSuccess(`Successfully ${action}d ${selectedUsers?.length} user(s)`);
      setSelectedUsers([]);
      loadUsers();
    } catch (err) {
      console.error(`Error ${action}ing users:`, err);
      setError(`Failed to ${action} users. Please try again.`);
    }
  };
  const handleInviteUser = async (e) => {
    e?.preventDefault();
    try {
      setError("");
      await userService?.inviteUser(inviteForm);
      setSuccess("User invitation sent successfully!");
      setShowInviteModal(false);
      setInviteForm({ email: "", firstName: "", lastName: "", role: "", message: "" });
      loadUsers();
    } catch (err) {
      console.error("Error inviting user:", err);
      setError("Failed to send invitation. Please try again.");
    }
  };
  const handleUserAction = async (action, userId) => {
    try {
      setError("");
      switch (action) {
        case "activate":
          await userService?.activateUser(userId);
          setSuccess("User activated successfully");
          break;
        case "deactivate":
          await userService?.deactivateUser(userId);
          setSuccess("User deactivated successfully");
          break;
        case "delete":
          await userService?.deleteUser(userId);
          setSuccess("User deleted successfully");
          break;
      }
      loadUsers();
    } catch (err) {
      console.error(`Error ${action}ing user:`, err);
      setError(`Failed to ${action} user. Please try again.`);
    }
  };
  const getStatusBadge = (status) => {
    const statusStyles = {
      Active: "bg-success-50 text-success-600 border-success-100",
      Inactive: "bg-error-50 text-error-600 border-error-100",
      Pending: "bg-warning-50 text-warning-600 border-warning-100"
    };
    return /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:182:6", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "182", "data-component-file": "UserManagement.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", className: `px-2 py-1 text-xs font-medium rounded border ${statusStyles?.[status] || "bg-gray-50 text-gray-600 border-gray-100"}`, children: status }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
      lineNumber: 182,
      columnNumber: 7
    }, this);
  };
  if (!currentUser || !userProfile || userProfile?.role !== "admin") {
    return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:191:6", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "191", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-6%22%7D", className: "space-y-6", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:192:8", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "192", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-center%20py-12%22%7D", className: "text-center py-12", children: [
      /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:193:10", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "193", "data-component-file": "UserManagement.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Lock%22%2C%22className%22%3A%22text-text-tertiary%20mx-auto%20mb-4%22%7D", name: "Lock", size: 48, className: "text-text-tertiary mx-auto mb-4" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
        lineNumber: 193,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:194:10", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "194", "data-component-file": "UserManagement.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-medium%20text-text-primary%20mb-2%22%2C%22textContent%22%3A%22Access%20Restricted%22%7D", className: "text-lg font-medium text-text-primary mb-2", children: "Access Restricted" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
        lineNumber: 194,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:195:10", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "195", "data-component-file": "UserManagement.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%22%2C%22textContent%22%3A%22Only%20administrators%20can%20access%20user%20management.%22%7D", className: "text-text-secondary", children: "Only administrators can access user management." }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
        lineNumber: 195,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
      lineNumber: 192,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
      lineNumber: 191,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:202:4", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "202", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-6%22%7D", className: "space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:204:6", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "204", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:205:8", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "205", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
        /* @__PURE__ */ jsxDEV("h2", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:206:10", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "206", "data-component-file": "UserManagement.jsx", "data-component-name": "h2", "data-component-content": "%7B%22elementName%22%3A%22h2%22%2C%22className%22%3A%22text-2xl%20font-bold%20text-text-primary%22%2C%22textContent%22%3A%22User%20Management%22%7D", className: "text-2xl font-bold text-text-primary", children: "User Management" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
          lineNumber: 206,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:207:10", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "207", "data-component-file": "UserManagement.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20mt-1%22%2C%22textContent%22%3A%22Manage%20users%2C%20roles%2C%20and%20permissions%22%7D", className: "text-text-secondary mt-1", children: "Manage users, roles, and permissions" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
          lineNumber: 207,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
        lineNumber: 205,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:209:8",
          "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx",
          "data-component-line": "209",
          "data-component-file": "UserManagement.jsx",
          "data-component-name": "button",
          "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22bg-primary%20text-white%20px-4%20py-2%20rounded-lg%20hover%3Abg-primary-600%20transition-colors%20duration-150%20ease-smooth%20flex%20items-center%20space-x-2%22%7D",
          onClick: () => setShowInviteModal(true),
          className: "bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary-600 transition-colors duration-150 ease-smooth flex items-center space-x-2",
          children: [
            /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:213:10", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "213", "data-component-file": "UserManagement.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22UserPlus%22%7D", name: "UserPlus", size: 16 }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
              lineNumber: 213,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:214:10", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "214", "data-component-file": "UserManagement.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Invite%20User%22%7D", children: "Invite User" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
              lineNumber: 214,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
          lineNumber: 209,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
      lineNumber: 204,
      columnNumber: 7
    }, this),
    success && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:219:6", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "219", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-success-50%20border%20border-success-200%20text-success%20p-4%20rounded-lg%20flex%20items-center%20space-x-2%22%7D", className: "bg-success-50 border border-success-200 text-success p-4 rounded-lg flex items-center space-x-2", children: [
      /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:220:10", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "220", "data-component-file": "UserManagement.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22CheckCircle%22%7D", name: "CheckCircle", size: 20 }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
        lineNumber: 220,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:221:10", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "221", "data-component-file": "UserManagement.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: success }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
        lineNumber: 221,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:222:10",
          "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx",
          "data-component-line": "222",
          "data-component-file": "UserManagement.jsx",
          "data-component-name": "button",
          "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22ml-auto%20text-success%20hover%3Atext-success-600%22%7D",
          onClick: () => setSuccess(""),
          className: "ml-auto text-success hover:text-success-600",
          children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:226:12", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "226", "data-component-file": "UserManagement.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22X%22%7D", name: "X", size: 16 }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
            lineNumber: 226,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
          lineNumber: 222,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
      lineNumber: 219,
      columnNumber: 7
    }, this),
    error && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:231:6", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "231", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-error-50%20border%20border-error-200%20text-error%20p-4%20rounded-lg%20flex%20items-center%20space-x-2%22%7D", className: "bg-error-50 border border-error-200 text-error p-4 rounded-lg flex items-center space-x-2", children: [
      /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:232:10", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "232", "data-component-file": "UserManagement.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22AlertCircle%22%7D", name: "AlertCircle", size: 20 }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
        lineNumber: 232,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:233:10", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "233", "data-component-file": "UserManagement.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: error }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
        lineNumber: 233,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:234:10",
          "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx",
          "data-component-line": "234",
          "data-component-file": "UserManagement.jsx",
          "data-component-name": "button",
          "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22ml-auto%20text-error%20hover%3Atext-error-600%22%7D",
          onClick: () => setError(""),
          className: "ml-auto text-error hover:text-error-600",
          children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:238:12", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "238", "data-component-file": "UserManagement.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22X%22%7D", name: "X", size: 16 }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
            lineNumber: 238,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
          lineNumber: 234,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
      lineNumber: 231,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:243:6", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "243", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20flex-col%20sm%3Aflex-row%20gap-4%20items-start%20sm%3Aitems-center%20justify-between%22%7D", className: "flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:244:8", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "244", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20flex-col%20sm%3Aflex-row%20gap-3%22%7D", className: "flex flex-col sm:flex-row gap-3", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:245:10", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "245", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22relative%22%7D", className: "relative", children: [
          /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:246:12", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "246", "data-component-file": "UserManagement.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Search%22%2C%22className%22%3A%22absolute%20left-3%20top-1%2F2%20transform%20-translate-y-1%2F2%20text-text-tertiary%22%7D", name: "Search", size: 16, className: "absolute left-3 top-1/2 transform -translate-y-1/2 text-text-tertiary" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
            lineNumber: 246,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:247:12",
              "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx",
              "data-component-line": "247",
              "data-component-file": "UserManagement.jsx",
              "data-component-name": "input",
              "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22text%22%2C%22value%22%3A%22%5Bvar%3AsearchQuery%5D%22%2C%22className%22%3A%22pl-10%20pr-4%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%20w-64%22%7D",
              type: "text",
              placeholder: "Search users...",
              value: searchQuery,
              onChange: (e) => setSearchQuery(e?.target?.value),
              className: "pl-10 pr-4 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary w-64"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
              lineNumber: 247,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
          lineNumber: 245,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "select",
          {
            "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:256:10",
            "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx",
            "data-component-line": "256",
            "data-component-file": "UserManagement.jsx",
            "data-component-name": "select",
            "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22value%22%3A%22%5Bvar%3AstatusFilter%5D%22%2C%22className%22%3A%22px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
            value: statusFilter,
            onChange: (e) => setStatusFilter(e?.target?.value),
            className: "px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
            children: [
              /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:261:12", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "261", "data-component-file": "UserManagement.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22all%22%2C%22textContent%22%3A%22All%20Status%22%7D", value: "all", children: "All Status" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
                lineNumber: 261,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:262:12", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "262", "data-component-file": "UserManagement.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22active%22%2C%22textContent%22%3A%22Active%22%7D", value: "active", children: "Active" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
                lineNumber: 262,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:263:12", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "263", "data-component-file": "UserManagement.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22inactive%22%2C%22textContent%22%3A%22Inactive%22%7D", value: "inactive", children: "Inactive" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
                lineNumber: 263,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
            lineNumber: 256,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "select",
          {
            "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:266:10",
            "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx",
            "data-component-line": "266",
            "data-component-file": "UserManagement.jsx",
            "data-component-name": "select",
            "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22value%22%3A%22%5Bvar%3AroleFilter%5D%22%2C%22className%22%3A%22px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
            value: roleFilter,
            onChange: (e) => setRoleFilter(e?.target?.value),
            className: "px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
            children: [
              /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:271:12", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "271", "data-component-file": "UserManagement.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22all%22%2C%22textContent%22%3A%22All%20Roles%22%7D", value: "all", children: "All Roles" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
                lineNumber: 271,
                columnNumber: 13
              }, this),
              roles?.map(
                (role) => /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:273:12", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "273", "data-component-file": "UserManagement.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%7D", value: role?.value, children: role?.label }, role?.value, false, {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
                  lineNumber: 273,
                  columnNumber: 13
                }, this)
              )
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
            lineNumber: 266,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
        lineNumber: 244,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:278:8",
          "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx",
          "data-component-line": "278",
          "data-component-file": "UserManagement.jsx",
          "data-component-name": "button",
          "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%20px-3%20py-2%20text-text-secondary%20hover%3Atext-text-primary%20transition-colors%20duration-150%22%7D",
          onClick: loadUsers,
          disabled: loading,
          className: "flex items-center space-x-2 px-3 py-2 text-text-secondary hover:text-text-primary transition-colors duration-150",
          children: [
            /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:283:10", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "283", "data-component-file": "UserManagement.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22RefreshCw%22%7D", name: "RefreshCw", size: 16, className: loading ? "animate-spin" : "" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
              lineNumber: 283,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:284:10", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "284", "data-component-file": "UserManagement.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Refresh%22%7D", children: "Refresh" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
              lineNumber: 284,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
          lineNumber: 278,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
      lineNumber: 243,
      columnNumber: 7
    }, this),
    selectedUsers?.length > 0 && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:289:6", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "289", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-primary-50%20border%20border-primary-100%20rounded-lg%20p-4%22%7D", className: "bg-primary-50 border border-primary-100 rounded-lg p-4", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:290:10", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "290", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:291:12", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "291", "data-component-file": "UserManagement.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-primary%20font-medium%22%2C%22textContent%22%3A%22user%20selected%22%7D", className: "text-sm text-primary font-medium", children: [
        selectedUsers?.length,
        " user",
        selectedUsers?.length !== 1 ? "s" : "",
        " selected"
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
        lineNumber: 291,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:294:12", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "294", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20space-x-2%22%7D", className: "flex space-x-2", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:295:14",
            "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx",
            "data-component-line": "295",
            "data-component-file": "UserManagement.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22px-3%20py-1%20text-xs%20bg-success%20text-white%20rounded%20hover%3Abg-success-600%20transition-colors%20duration-150%22%2C%22textContent%22%3A%22Activate%22%7D",
            onClick: () => handleBulkAction("activate"),
            className: "px-3 py-1 text-xs bg-success text-white rounded hover:bg-success-600 transition-colors duration-150",
            children: "Activate"
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
            lineNumber: 295,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:301:14",
            "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx",
            "data-component-line": "301",
            "data-component-file": "UserManagement.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22px-3%20py-1%20text-xs%20bg-error%20text-white%20rounded%20hover%3Abg-error-600%20transition-colors%20duration-150%22%2C%22textContent%22%3A%22Deactivate%22%7D",
            onClick: () => handleBulkAction("deactivate"),
            className: "px-3 py-1 text-xs bg-error text-white rounded hover:bg-error-600 transition-colors duration-150",
            children: "Deactivate"
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
            lineNumber: 301,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:307:14",
            "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx",
            "data-component-line": "307",
            "data-component-file": "UserManagement.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22px-3%20py-1%20text-xs%20bg-text-secondary%20text-white%20rounded%20hover%3Abg-text-primary%20transition-colors%20duration-150%22%2C%22textContent%22%3A%22Delete%22%7D",
            onClick: () => handleBulkAction("delete"),
            className: "px-3 py-1 text-xs bg-text-secondary text-white rounded hover:bg-text-primary transition-colors duration-150",
            children: "Delete"
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
            lineNumber: 307,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
        lineNumber: 294,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
      lineNumber: 290,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
      lineNumber: 289,
      columnNumber: 7
    }, this),
    loading ? /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:319:6", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "319", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-center%20py-12%22%7D", className: "flex items-center justify-center py-12", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:320:10", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "320", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-3%22%7D", className: "flex items-center space-x-3", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:321:12", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "321", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22animate-spin%20rounded-full%20h-8%20w-8%20border-b-2%20border-primary%22%7D", className: "animate-spin rounded-full h-8 w-8 border-b-2 border-primary" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
        lineNumber: 321,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:322:12", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "322", "data-component-file": "UserManagement.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-text-secondary%22%2C%22textContent%22%3A%22Loading%20users...%22%7D", className: "text-text-secondary", children: "Loading users..." }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
        lineNumber: 322,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
      lineNumber: 320,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
      lineNumber: 319,
      columnNumber: 7
    }, this) : (
      /* Users Table */
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:327:6", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "327", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20rounded-lg%20border%20border-border%20overflow-hidden%22%7D", className: "bg-surface rounded-lg border border-border overflow-hidden", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:328:10", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "328", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22overflow-x-auto%22%7D", className: "overflow-x-auto", children: /* @__PURE__ */ jsxDEV("table", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:329:12", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "329", "data-component-file": "UserManagement.jsx", "data-component-name": "table", "data-component-content": "%7B%22elementName%22%3A%22table%22%2C%22className%22%3A%22w-full%22%7D", className: "w-full", children: [
        /* @__PURE__ */ jsxDEV("thead", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:330:14", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "330", "data-component-file": "UserManagement.jsx", "data-component-name": "thead", "data-component-content": "%7B%22elementName%22%3A%22thead%22%2C%22className%22%3A%22bg-background%20border-b%20border-border%22%7D", className: "bg-background border-b border-border", children: /* @__PURE__ */ jsxDEV("tr", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:331:16", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "331", "data-component-file": "UserManagement.jsx", "data-component-name": "tr", "data-component-content": "%7B%22elementName%22%3A%22tr%22%7D", children: [
          /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:332:18", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "332", "data-component-file": "UserManagement.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22text-left%20py-3%20px-4%22%7D", className: "text-left py-3 px-4", children: /* @__PURE__ */ jsxDEV(
            "input",
            {
              "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:333:20",
              "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx",
              "data-component-line": "333",
              "data-component-file": "UserManagement.jsx",
              "data-component-name": "input",
              "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22checkbox%22%2C%22className%22%3A%22rounded%20border-border%20text-primary%20focus%3Aring-primary%22%7D",
              type: "checkbox",
              checked: selectedUsers?.length === users?.length && users?.length > 0,
              onChange: handleSelectAll,
              className: "rounded border-border text-primary focus:ring-primary"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
              lineNumber: 333,
              columnNumber: 21
            },
            this
          ) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
            lineNumber: 332,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:340:18", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "340", "data-component-file": "UserManagement.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22text-left%20py-3%20px-4%20text-sm%20font-medium%20text-text-primary%22%2C%22textContent%22%3A%22User%22%7D", className: "text-left py-3 px-4 text-sm font-medium text-text-primary", children: "User" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
            lineNumber: 340,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:341:18", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "341", "data-component-file": "UserManagement.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22text-left%20py-3%20px-4%20text-sm%20font-medium%20text-text-primary%22%2C%22textContent%22%3A%22Role%22%7D", className: "text-left py-3 px-4 text-sm font-medium text-text-primary", children: "Role" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
            lineNumber: 341,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:342:18", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "342", "data-component-file": "UserManagement.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22text-left%20py-3%20px-4%20text-sm%20font-medium%20text-text-primary%22%2C%22textContent%22%3A%22Status%22%7D", className: "text-left py-3 px-4 text-sm font-medium text-text-primary", children: "Status" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
            lineNumber: 342,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:343:18", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "343", "data-component-file": "UserManagement.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22text-left%20py-3%20px-4%20text-sm%20font-medium%20text-text-primary%22%2C%22textContent%22%3A%22Last%20Login%22%7D", className: "text-left py-3 px-4 text-sm font-medium text-text-primary", children: "Last Login" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
            lineNumber: 343,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:344:18", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "344", "data-component-file": "UserManagement.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22text-left%20py-3%20px-4%20text-sm%20font-medium%20text-text-primary%22%2C%22textContent%22%3A%22Actions%22%7D", className: "text-left py-3 px-4 text-sm font-medium text-text-primary", children: "Actions" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
            lineNumber: 344,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
          lineNumber: 331,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
          lineNumber: 330,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:347:14", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "347", "data-component-file": "UserManagement.jsx", "data-component-name": "tbody", "data-component-content": "%7B%22elementName%22%3A%22tbody%22%7D", children: users?.length === 0 ? /* @__PURE__ */ jsxDEV("tr", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:349:14", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "349", "data-component-file": "UserManagement.jsx", "data-component-name": "tr", "data-component-content": "%7B%22elementName%22%3A%22tr%22%7D", children: /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:350:20", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "350", "data-component-file": "UserManagement.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22py-8%20text-center%22%7D", colSpan: "6", className: "py-8 text-center", children: [
          /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:351:22", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "351", "data-component-file": "UserManagement.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Users%22%2C%22className%22%3A%22text-text-tertiary%20mx-auto%20mb-4%22%7D", name: "Users", size: 48, className: "text-text-tertiary mx-auto mb-4" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
            lineNumber: 351,
            columnNumber: 23
          }, this),
          /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:352:22", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "352", "data-component-file": "UserManagement.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%22%2C%22textContent%22%3A%22No%20users%20found%22%7D", className: "text-text-secondary", children: "No users found" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
            lineNumber: 352,
            columnNumber: 23
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
          lineNumber: 350,
          columnNumber: 21
        }, this) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
          lineNumber: 349,
          columnNumber: 15
        }, this) : users?.map(
          (user) => /* @__PURE__ */ jsxDEV("tr", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:357:14", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "357", "data-component-file": "UserManagement.jsx", "data-component-name": "tr", "data-component-content": "%7B%22elementName%22%3A%22tr%22%2C%22className%22%3A%22border-b%20border-border%20hover%3Abg-surface-hover%22%7D", className: "border-b border-border hover:bg-surface-hover", children: [
            /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:358:22", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "358", "data-component-file": "UserManagement.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22py-3%20px-4%22%7D", className: "py-3 px-4", children: /* @__PURE__ */ jsxDEV(
              "input",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:359:24",
                "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx",
                "data-component-line": "359",
                "data-component-file": "UserManagement.jsx",
                "data-component-name": "input",
                "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22checkbox%22%2C%22className%22%3A%22rounded%20border-border%20text-primary%20focus%3Aring-primary%22%7D",
                type: "checkbox",
                checked: selectedUsers?.includes(user?.id),
                onChange: () => handleSelectUser(user?.id),
                className: "rounded border-border text-primary focus:ring-primary"
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
                lineNumber: 359,
                columnNumber: 25
              },
              this
            ) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
              lineNumber: 358,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:366:22", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "366", "data-component-file": "UserManagement.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22py-3%20px-4%22%7D", className: "py-3 px-4", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:367:24", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "367", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-3%22%7D", className: "flex items-center space-x-3", children: [
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:368:26", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "368", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-8%20h-8%20bg-primary-100%20rounded-full%20flex%20items-center%20justify-center%22%7D", className: "w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center", children: user?.avatar ? /* @__PURE__ */ jsxDEV("img", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:370:22", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "370", "data-component-file": "UserManagement.jsx", "data-component-name": "img", "data-component-content": "%7B%22elementName%22%3A%22img%22%2C%22className%22%3A%22w-8%20h-8%20rounded-full%22%7D", src: user?.avatar, alt: user?.name, className: "w-8 h-8 rounded-full" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
                lineNumber: 370,
                columnNumber: 23
              }, this) : /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:372:22", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "372", "data-component-file": "UserManagement.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22User%22%2C%22className%22%3A%22text-primary%22%7D", name: "User", size: 16, className: "text-primary" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
                lineNumber: 372,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
                lineNumber: 368,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:375:26", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "375", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
                /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:376:28", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "376", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22font-medium%20text-text-primary%22%7D", className: "font-medium text-text-primary", children: user?.name || "Unnamed User" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
                  lineNumber: 376,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:377:28", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "377", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%7D", className: "text-sm text-text-secondary", children: user?.email }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
                  lineNumber: 377,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
                lineNumber: 375,
                columnNumber: 27
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
              lineNumber: 367,
              columnNumber: 25
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
              lineNumber: 366,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:381:22", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "381", "data-component-file": "UserManagement.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22py-3%20px-4%20text-sm%20text-text-secondary%22%7D", className: "py-3 px-4 text-sm text-text-secondary", children: user?.role }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
              lineNumber: 381,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:382:22", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "382", "data-component-file": "UserManagement.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22py-3%20px-4%22%7D", className: "py-3 px-4", children: getStatusBadge(user?.status) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
              lineNumber: 382,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:383:22", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "383", "data-component-file": "UserManagement.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22py-3%20px-4%20text-sm%20text-text-secondary%22%7D", className: "py-3 px-4 text-sm text-text-secondary", children: user?.lastLogin }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
              lineNumber: 383,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:384:22", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "384", "data-component-file": "UserManagement.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22py-3%20px-4%22%7D", className: "py-3 px-4", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:385:24", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "385", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20space-x-2%22%7D", className: "flex space-x-2", children: [
              user?.status === "Active" ? /* @__PURE__ */ jsxDEV(
                "button",
                {
                  "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:387:20",
                  "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx",
                  "data-component-line": "387",
                  "data-component-file": "UserManagement.jsx",
                  "data-component-name": "button",
                  "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22p-1%20text-text-secondary%20hover%3Atext-error%20transition-colors%20duration-150%22%7D",
                  onClick: () => handleUserAction("deactivate", user?.id),
                  className: "p-1 text-text-secondary hover:text-error transition-colors duration-150",
                  title: "Deactivate User",
                  children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:392:30", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "392", "data-component-file": "UserManagement.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22UserX%22%7D", name: "UserX", size: 16 }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
                    lineNumber: 392,
                    columnNumber: 31
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
                  lineNumber: 387,
                  columnNumber: 21
                },
                this
              ) : /* @__PURE__ */ jsxDEV(
                "button",
                {
                  "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:395:20",
                  "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx",
                  "data-component-line": "395",
                  "data-component-file": "UserManagement.jsx",
                  "data-component-name": "button",
                  "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22p-1%20text-text-secondary%20hover%3Atext-success%20transition-colors%20duration-150%22%7D",
                  onClick: () => handleUserAction("activate", user?.id),
                  className: "p-1 text-text-secondary hover:text-success transition-colors duration-150",
                  title: "Activate User",
                  children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:400:30", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "400", "data-component-file": "UserManagement.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22UserCheck%22%7D", name: "UserCheck", size: 16 }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
                    lineNumber: 400,
                    columnNumber: 31
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
                  lineNumber: 395,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:403:26",
                  "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx",
                  "data-component-line": "403",
                  "data-component-file": "UserManagement.jsx",
                  "data-component-name": "button",
                  "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22p-1%20text-text-secondary%20hover%3Atext-error%20transition-colors%20duration-150%22%7D",
                  onClick: () => handleUserAction("delete", user?.id),
                  className: "p-1 text-text-secondary hover:text-error transition-colors duration-150",
                  title: "Delete User",
                  children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:408:28", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "408", "data-component-file": "UserManagement.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Trash2%22%7D", name: "Trash2", size: 16 }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
                    lineNumber: 408,
                    columnNumber: 29
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
                  lineNumber: 403,
                  columnNumber: 27
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
              lineNumber: 385,
              columnNumber: 25
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
              lineNumber: 384,
              columnNumber: 23
            }, this)
          ] }, user?.id, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
            lineNumber: 357,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
          lineNumber: 347,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
        lineNumber: 329,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
        lineNumber: 328,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
        lineNumber: 327,
        columnNumber: 7
      }, this)
    ),
    showInviteModal && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:422:6", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "422", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20z-1200%20overflow-y-auto%22%7D", className: "fixed inset-0 z-1200 overflow-y-auto", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:423:10", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "423", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-center%20min-h-screen%20px-4%22%7D", className: "flex items-center justify-center min-h-screen px-4", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:424:12", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "424", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20bg-black%20bg-opacity-50%22%7D", className: "fixed inset-0 bg-black bg-opacity-50", onClick: () => setShowInviteModal(false) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
        lineNumber: 424,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:425:12", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "425", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20rounded-lg%20shadow-xl%20max-w-md%20w-full%20relative%20z-1300%22%7D", className: "bg-surface rounded-lg shadow-xl max-w-md w-full relative z-1300", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:426:14", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "426", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22p-6%22%7D", className: "p-6", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:427:16", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "427", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%20mb-4%22%7D", className: "flex items-center justify-between mb-4", children: [
          /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:428:18", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "428", "data-component-file": "UserManagement.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%2C%22textContent%22%3A%22Invite%20New%20User%22%7D", className: "text-lg font-semibold text-text-primary", children: "Invite New User" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
            lineNumber: 428,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:429:18",
              "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx",
              "data-component-line": "429",
              "data-component-file": "UserManagement.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22text-text-secondary%20hover%3Atext-text-primary%20transition-colors%20duration-150%22%7D",
              onClick: () => setShowInviteModal(false),
              className: "text-text-secondary hover:text-text-primary transition-colors duration-150",
              children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:433:20", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "433", "data-component-file": "UserManagement.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22X%22%7D", name: "X", size: 20 }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
                lineNumber: 433,
                columnNumber: 21
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
              lineNumber: 429,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
          lineNumber: 427,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("form", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:436:16", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "436", "data-component-file": "UserManagement.jsx", "data-component-name": "form", "data-component-content": "%7B%22elementName%22%3A%22form%22%2C%22className%22%3A%22space-y-4%22%7D", onSubmit: handleInviteUser, className: "space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:437:18", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "437", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:438:20", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "438", "data-component-file": "UserManagement.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Email%20Address%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Email Address" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
              lineNumber: 438,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:439:20",
                "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx",
                "data-component-line": "439",
                "data-component-file": "UserManagement.jsx",
                "data-component-name": "input",
                "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22email%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
                type: "email",
                value: inviteForm?.email,
                onChange: (e) => setInviteForm((prev) => ({ ...prev, email: e?.target?.value })),
                className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
                placeholder: "user@company.com",
                required: true
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
                lineNumber: 439,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
            lineNumber: 437,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:449:18", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "449", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-2%20gap-3%22%7D", className: "grid grid-cols-2 gap-3", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:450:20", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "450", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:451:22", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "451", "data-component-file": "UserManagement.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22First%20Name%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "First Name" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
                lineNumber: 451,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:452:22",
                  "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx",
                  "data-component-line": "452",
                  "data-component-file": "UserManagement.jsx",
                  "data-component-name": "input",
                  "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22text%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
                  type: "text",
                  value: inviteForm?.firstName,
                  onChange: (e) => setInviteForm((prev) => ({ ...prev, firstName: e?.target?.value })),
                  className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
                  placeholder: "John"
                },
                void 0,
                false,
                {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
                  lineNumber: 452,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
              lineNumber: 450,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:460:20", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "460", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:461:22", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "461", "data-component-file": "UserManagement.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Last%20Name%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Last Name" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
                lineNumber: 461,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:462:22",
                  "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx",
                  "data-component-line": "462",
                  "data-component-file": "UserManagement.jsx",
                  "data-component-name": "input",
                  "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22text%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
                  type: "text",
                  value: inviteForm?.lastName,
                  onChange: (e) => setInviteForm((prev) => ({ ...prev, lastName: e?.target?.value })),
                  className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
                  placeholder: "Doe"
                },
                void 0,
                false,
                {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
                  lineNumber: 462,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
              lineNumber: 460,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
            lineNumber: 449,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:472:18", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "472", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:473:20", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "473", "data-component-file": "UserManagement.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Role%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Role" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
              lineNumber: 473,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:474:20",
                "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx",
                "data-component-line": "474",
                "data-component-file": "UserManagement.jsx",
                "data-component-name": "select",
                "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
                value: inviteForm?.role,
                onChange: (e) => setInviteForm((prev) => ({ ...prev, role: e?.target?.value })),
                className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
                required: true,
                children: [
                  /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:480:22", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "480", "data-component-file": "UserManagement.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22%22%2C%22textContent%22%3A%22Select%20Role%22%7D", value: "", children: "Select Role" }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
                    lineNumber: 480,
                    columnNumber: 23
                  }, this),
                  roles?.map(
                    (role) => /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:482:20", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "482", "data-component-file": "UserManagement.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%7D", value: role?.value, children: role?.label }, role?.value, false, {
                      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
                      lineNumber: 482,
                      columnNumber: 21
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
                lineNumber: 474,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
            lineNumber: 472,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:487:18", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "487", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:488:20", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "488", "data-component-file": "UserManagement.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Welcome%20Message%20(Optional)%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Welcome Message (Optional)" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
              lineNumber: 488,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              "textarea",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:489:20",
                "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx",
                "data-component-line": "489",
                "data-component-file": "UserManagement.jsx",
                "data-component-name": "textarea",
                "data-component-content": "%7B%22elementName%22%3A%22textarea%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
                value: inviteForm?.message,
                onChange: (e) => setInviteForm((prev) => ({ ...prev, message: e?.target?.value })),
                className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
                rows: 3,
                placeholder: "Welcome to our team..."
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
                lineNumber: 489,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
            lineNumber: 487,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:498:18", "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx", "data-component-line": "498", "data-component-file": "UserManagement.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20justify-end%20space-x-3%20mt-6%22%7D", className: "flex justify-end space-x-3 mt-6", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:499:20",
                "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx",
                "data-component-line": "499",
                "data-component-file": "UserManagement.jsx",
                "data-component-name": "button",
                "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22button%22%2C%22className%22%3A%22px-4%20py-2%20text-text-secondary%20hover%3Atext-text-primary%20transition-colors%20duration-150%22%2C%22textContent%22%3A%22Cancel%22%7D",
                type: "button",
                onClick: () => setShowInviteModal(false),
                className: "px-4 py-2 text-text-secondary hover:text-text-primary transition-colors duration-150",
                children: "Cancel"
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
                lineNumber: 499,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\UserManagement.jsx:506:20",
                "data-component-path": "src\\pages\\settings-administration\\components\\UserManagement.jsx",
                "data-component-line": "506",
                "data-component-file": "UserManagement.jsx",
                "data-component-name": "button",
                "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22submit%22%2C%22className%22%3A%22bg-primary%20text-white%20px-4%20py-2%20rounded-lg%20hover%3Abg-primary-600%20transition-colors%20duration-150%20ease-smooth%22%2C%22textContent%22%3A%22Send%20Invitation%22%7D",
                type: "submit",
                className: "bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary-600 transition-colors duration-150 ease-smooth",
                children: "Send Invitation"
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
                lineNumber: 506,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
            lineNumber: 498,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
          lineNumber: 436,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
        lineNumber: 426,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
        lineNumber: 425,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
      lineNumber: 423,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
      lineNumber: 422,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx",
    lineNumber: 202,
    columnNumber: 5
  }, this);
};
_s(UserManagement, "PMPdBQcC6yZsmx1a8D2QJjklbTc=", false, function() {
  return [useAuth];
});
_c = UserManagement;
export default UserManagement;
var _c;
$RefreshReg$(_c, "UserManagement");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/settings-administration/components/UserManagement.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUxNOzJCQXJMTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBLE9BQU9BLFNBQVNDLFVBQVVDLGlCQUFpQjtBQUMzQyxPQUFPQyxVQUFVO0FBQ2pCLFNBQVNDLGVBQWU7QUFDeEIsT0FBT0MsaUJBQWlCO0FBRXhCLE1BQU1DLGlCQUFpQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzNCLFFBQU0sRUFBRUMsTUFBTUMsYUFBYUMsWUFBWSxJQUFJTixRQUFRO0FBQ25ELFFBQU0sQ0FBQ08sT0FBT0MsUUFBUSxJQUFJWCxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDWSxTQUFTQyxVQUFVLElBQUliLFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUNjLGVBQWVDLGdCQUFnQixJQUFJZixTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDZ0IsaUJBQWlCQyxrQkFBa0IsSUFBSWpCLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUNrQixZQUFZQyxhQUFhLElBQUluQixTQUFTO0FBQUEsSUFDM0NvQixPQUFPO0FBQUEsSUFDUEMsV0FBVztBQUFBLElBQ1hDLFVBQVU7QUFBQSxJQUNWQyxNQUFNO0FBQUEsSUFDTkMsU0FBUztBQUFBLEVBQ1gsQ0FBQztBQUNELFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJMUIsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQzJCLFNBQVNDLFVBQVUsSUFBSTVCLFNBQVMsRUFBRTtBQUN6QyxRQUFNLENBQUM2QixhQUFhQyxjQUFjLElBQUk5QixTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDK0IsY0FBY0MsZUFBZSxJQUFJaEMsU0FBUyxLQUFLO0FBQ3RELFFBQU0sQ0FBQ2lDLFlBQVlDLGFBQWEsSUFBSWxDLFNBQVMsS0FBSztBQUVsRCxRQUFNbUMsUUFBUS9CLGFBQWFnQyxhQUFhO0FBR3hDLFFBQU1DLFlBQVksWUFBWTtBQUM1QixRQUFJO0FBQ0Z4QixpQkFBVyxJQUFJO0FBQ2ZhLGVBQVMsRUFBRTtBQUVYLFVBQUlZLFdBQVc7QUFDZixVQUFJVCxhQUFhO0FBQ2ZTLG1CQUFXLE1BQU1sQyxhQUFhbUMsWUFBWVYsV0FBVztBQUFBLE1BQ3ZELE9BQU87QUFDTCxjQUFNVyxVQUFVLENBQUM7QUFDakIsWUFBSVQsaUJBQWlCLE9BQU87QUFDMUJTLGtCQUFRQyxTQUFTVjtBQUFBQSxRQUNuQjtBQUNBLFlBQUlFLGVBQWUsT0FBTztBQUN4Qk8sa0JBQVFMLFFBQVEsQ0FBQ0YsVUFBVTtBQUFBLFFBQzdCO0FBRUEsWUFBSVMsT0FBT0MsS0FBS0gsT0FBTyxHQUFHSSxTQUFTLEdBQUc7QUFDcENOLHFCQUFXLE1BQU1sQyxhQUFheUMsWUFBWUwsT0FBTztBQUFBLFFBQ25ELE9BQU87QUFDTEYscUJBQVcsTUFBTWxDLGFBQWEwQyxZQUFZO0FBQUEsUUFDNUM7QUFBQSxNQUNGO0FBR0EsWUFBTUMsbUJBQW1CVCxVQUFVVSxJQUFJLENBQUF6QyxVQUFTO0FBQUEsUUFDOUMwQyxJQUFJMUMsTUFBTTBDO0FBQUFBLFFBQ1ZDLE1BQU0zQyxNQUFNNEMsYUFBYSxHQUFHNUMsTUFBTTZDLFVBQVUsSUFBSTdDLE1BQU04QyxTQUFTLElBQUlDLEtBQUs7QUFBQSxRQUN4RWxDLE9BQU9iLE1BQU1hO0FBQUFBLFFBQ2JHLE1BQU1ZLE9BQU9vQixLQUFLLENBQUFDLE1BQUtBLEdBQUdDLFVBQVVsRCxNQUFNZ0IsSUFBSSxHQUFHbUMsU0FBU25ELE1BQU1nQjtBQUFBQSxRQUNoRWtCLFFBQVFsQyxNQUFNb0QsWUFBWSxXQUFXO0FBQUEsUUFDckNDLFdBQVdyRCxNQUFNc0QsYUFBYSxJQUFJQyxLQUFLdkQsTUFBTXNELFVBQVUsR0FBR0UsZUFBZSxJQUFJO0FBQUEsUUFDN0VDLFFBQVF6RCxNQUFNMEQ7QUFBQUEsUUFDZEMsU0FBUzNEO0FBQUFBLE1BQ1gsRUFBRTtBQUVGSSxlQUFTb0MsZ0JBQWdCO0FBQUEsSUFDM0IsU0FBU29CLEtBQUs7QUFDWkMsY0FBUTNDLE1BQU0sd0JBQXdCMEMsR0FBRztBQUN6Q3pDLGVBQVMseUNBQXlDO0FBQUEsSUFDcEQsVUFBQztBQUNDYixpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBRUFaLFlBQVUsTUFBTTtBQUNkLFFBQUlPLGVBQWVDLGFBQWFjLFNBQVMsU0FBUztBQUNoRGMsZ0JBQVU7QUFBQSxJQUNaO0FBQUEsRUFDRixHQUFHLENBQUM3QixhQUFhQyxhQUFhb0IsYUFBYUUsY0FBY0UsVUFBVSxDQUFDO0FBR3BFaEMsWUFBVSxNQUFNO0FBQ2QsUUFBSXdCLFNBQVNFLFNBQVM7QUFDcEIsWUFBTTBDLFFBQVFDLFdBQVcsTUFBTTtBQUM3QjVDLGlCQUFTLEVBQUU7QUFDWEUsbUJBQVcsRUFBRTtBQUFBLE1BQ2YsR0FBRyxHQUFJO0FBQ1AsYUFBTyxNQUFNMkMsYUFBYUYsS0FBSztBQUFBLElBQ2pDO0FBQUEsRUFDRixHQUFHLENBQUM1QyxPQUFPRSxPQUFPLENBQUM7QUFFbkIsUUFBTTZDLG1CQUFtQkEsQ0FBQ0MsV0FBVztBQUNuQzFEO0FBQUFBLE1BQWlCLENBQUEyRCxTQUNmQSxNQUFNQyxTQUFTRixNQUFNLElBQ2pCQyxNQUFNRSxPQUFPLENBQUEzQixPQUFNQSxPQUFPd0IsTUFBTSxJQUNoQyxDQUFDLEdBQUdDLE1BQU1ELE1BQU07QUFBQSxJQUN0QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNSSxrQkFBa0JBLE1BQU07QUFDNUI5RDtBQUFBQSxNQUNFRCxlQUFlOEIsV0FBV2xDLE9BQU9rQyxTQUFTLEtBQUtsQyxPQUFPc0MsSUFBSSxDQUFBekMsU0FBUUEsTUFBTTBDLEVBQUU7QUFBQSxJQUM1RTtBQUFBLEVBQ0Y7QUFFQSxRQUFNNkIsbUJBQW1CLE9BQU9DLFdBQVc7QUFDekMsUUFBSTtBQUNGckQsZUFBUyxFQUFFO0FBQ1gsVUFBSXNELFVBQVUsQ0FBQztBQUVmLGNBQVFELFFBQU07QUFBQSxRQUNaLEtBQUs7QUFDSEMsb0JBQVUsRUFBRXJCLFdBQVcsS0FBSztBQUM1QjtBQUFBLFFBQ0YsS0FBSztBQUNIcUIsb0JBQVUsRUFBRXJCLFdBQVcsTUFBTTtBQUM3QjtBQUFBLFFBQ0YsS0FBSztBQUNIcUIsb0JBQVUsRUFBRXJCLFdBQVcsTUFBTTtBQUM3QjtBQUFBLE1BQ0o7QUFFQSxZQUFNdkQsYUFBYTZFLGdCQUFnQm5FLGVBQWVrRSxPQUFPO0FBQ3pEcEQsaUJBQVcsZ0JBQWdCbUQsTUFBTSxLQUFLakUsZUFBZThCLE1BQU0sVUFBVTtBQUNyRTdCLHVCQUFpQixFQUFFO0FBQ25Cc0IsZ0JBQVU7QUFBQSxJQUNaLFNBQVM4QixLQUFLO0FBQ1pDLGNBQVEzQyxNQUFNLFNBQVNzRCxNQUFNLGNBQWNaLEdBQUc7QUFDOUN6QyxlQUFTLGFBQWFxRCxNQUFNLDJCQUEyQjtBQUFBLElBQ3pEO0FBQUEsRUFDRjtBQUVBLFFBQU1HLG1CQUFtQixPQUFPQyxNQUFNO0FBQ3BDQSxPQUFHQyxlQUFlO0FBRWxCLFFBQUk7QUFDRjFELGVBQVMsRUFBRTtBQUNYLFlBQU10QixhQUFhaUYsV0FBV25FLFVBQVU7QUFDeENVLGlCQUFXLG9DQUFvQztBQUMvQ1gseUJBQW1CLEtBQUs7QUFDeEJFLG9CQUFjLEVBQUVDLE9BQU8sSUFBSUMsV0FBVyxJQUFJQyxVQUFVLElBQUlDLE1BQU0sSUFBSUMsU0FBUyxHQUFHLENBQUM7QUFDL0VhLGdCQUFVO0FBQUEsSUFDWixTQUFTOEIsS0FBSztBQUNaQyxjQUFRM0MsTUFBTSx3QkFBd0IwQyxHQUFHO0FBQ3pDekMsZUFBUyw4Q0FBOEM7QUFBQSxJQUN6RDtBQUFBLEVBQ0Y7QUFFQSxRQUFNNEQsbUJBQW1CLE9BQU9QLFFBQVFOLFdBQVc7QUFDakQsUUFBSTtBQUNGL0MsZUFBUyxFQUFFO0FBRVgsY0FBUXFELFFBQU07QUFBQSxRQUNaLEtBQUs7QUFDSCxnQkFBTTNFLGFBQWFtRixhQUFhZCxNQUFNO0FBQ3RDN0MscUJBQVcsNkJBQTZCO0FBQ3hDO0FBQUEsUUFDRixLQUFLO0FBQ0gsZ0JBQU14QixhQUFhb0YsZUFBZWYsTUFBTTtBQUN4QzdDLHFCQUFXLCtCQUErQjtBQUMxQztBQUFBLFFBQ0YsS0FBSztBQUNILGdCQUFNeEIsYUFBYXFGLFdBQVdoQixNQUFNO0FBQ3BDN0MscUJBQVcsMkJBQTJCO0FBQ3RDO0FBQUEsTUFDSjtBQUVBUyxnQkFBVTtBQUFBLElBQ1osU0FBUzhCLEtBQUs7QUFDWkMsY0FBUTNDLE1BQU0sU0FBU3NELE1BQU0sYUFBYVosR0FBRztBQUM3Q3pDLGVBQVMsYUFBYXFELE1BQU0sMEJBQTBCO0FBQUEsSUFDeEQ7QUFBQSxFQUNGO0FBRUEsUUFBTVcsaUJBQWlCQSxDQUFDakQsV0FBVztBQUNqQyxVQUFNa0QsZUFBZTtBQUFBLE1BQ25CQyxRQUFRO0FBQUEsTUFDUkMsVUFBVTtBQUFBLE1BQ1ZDLFNBQVM7QUFBQSxJQUNYO0FBRUEsV0FDRSx1QkFBQyxzWEFBSyxXQUFXLGdEQUFnREgsZUFBZWxELE1BQU0sS0FBSywwQ0FBMEMsSUFDbElBLG9CQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFHQSxNQUFJLENBQUNqQyxlQUFlLENBQUNDLGVBQWVBLGFBQWFjLFNBQVMsU0FBUztBQUNqRSxXQUNFLHVCQUFDLHVaQUFJLFdBQVUsYUFDYixpQ0FBQyxpYUFBSSxXQUFVLHFCQUNiO0FBQUEsNkJBQUMsNmNBQUssTUFBSyxRQUFPLE1BQU0sSUFBSSxXQUFVLHFDQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVFO0FBQUEsTUFDdkUsdUJBQUMsNGVBQUcsV0FBVSw4Q0FBNkMsaUNBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEU7QUFBQSxNQUM1RSx1QkFBQyxrZkFBRSxXQUFVLHVCQUFzQiwrREFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRjtBQUFBLFNBSHBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQSxLQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQTtBQUFBLEVBRUo7QUFFQSxTQUNFLHVCQUFDLHVaQUFJLFdBQVUsYUFFYjtBQUFBLDJCQUFDLG1iQUFJLFdBQVUscUNBQ2I7QUFBQSw2QkFBQyxtWEFDQztBQUFBLCtCQUFDLGtlQUFHLFdBQVUsd0NBQXVDLCtCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9FO0FBQUEsUUFDcEUsdUJBQUMsZ2ZBQUUsV0FBVSw0QkFBMkIsb0RBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEU7QUFBQSxXQUY5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFDQyxTQUFTLE1BQU1OLG1CQUFtQixJQUFJO0FBQUEsVUFDdEMsV0FBVTtBQUFBLFVBRVY7QUFBQSxtQ0FBQyxtWkFBSyxNQUFLLFlBQVcsTUFBTSxNQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErQjtBQUFBLFlBQy9CLHVCQUFDLGlhQUFLLDJCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlCO0FBQUE7QUFBQTtBQUFBLFFBTG5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1BO0FBQUEsU0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUE7QUFBQSxJQUVDVSxXQUNDLHVCQUFDLDZmQUFJLFdBQVUsbUdBQ2I7QUFBQSw2QkFBQyxzWkFBSyxNQUFLLGVBQWMsTUFBTSxNQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtDO0FBQUEsTUFDbEMsdUJBQUMsdVhBQU1BLHFCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZTtBQUFBLE1BQ2Y7QUFBQSxRQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUNDLFNBQVMsTUFBTUMsV0FBVyxFQUFFO0FBQUEsVUFDNUIsV0FBVTtBQUFBLFVBRVYsaUNBQUMsNFlBQUssTUFBSyxLQUFJLE1BQU0sTUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0I7QUFBQTtBQUFBLFFBSjFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtBO0FBQUEsU0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxJQUVESCxTQUNDLHVCQUFDLHVmQUFJLFdBQVUsNkZBQ2I7QUFBQSw2QkFBQyxzWkFBSyxNQUFLLGVBQWMsTUFBTSxNQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtDO0FBQUEsTUFDbEMsdUJBQUMsdVhBQU1BLG1CQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBYTtBQUFBLE1BQ2I7QUFBQSxRQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUNDLFNBQVMsTUFBTUMsU0FBUyxFQUFFO0FBQUEsVUFDMUIsV0FBVTtBQUFBLFVBRVYsaUNBQUMsNFlBQUssTUFBSyxLQUFJLE1BQU0sTUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0I7QUFBQTtBQUFBLFFBSjFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtBO0FBQUEsU0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxJQUdGLHVCQUFDLHllQUFJLFdBQVUsK0VBQ2I7QUFBQSw2QkFBQyxxYkFBSSxXQUFVLG1DQUNiO0FBQUEsK0JBQUMsdVpBQUksV0FBVSxZQUNiO0FBQUEsaUNBQUMsK2ZBQUssTUFBSyxVQUFTLE1BQU0sSUFBSSxXQUFVLDJFQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRztBQUFBLFVBQy9HO0FBQUEsWUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxhQUFZO0FBQUEsY0FDWixPQUFPRztBQUFBQSxjQUNQLFVBQVUsQ0FBQ3NELE1BQU1yRCxlQUFlcUQsR0FBR1ksUUFBUXRDLEtBQUs7QUFBQSxjQUNoRCxXQUFVO0FBQUE7QUFBQSxZQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUswRztBQUFBLGFBUDVHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFFBRUE7QUFBQSxVQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUNDLE9BQU8xQjtBQUFBQSxZQUNQLFVBQVUsQ0FBQ29ELE1BQU1uRCxnQkFBZ0JtRCxHQUFHWSxRQUFRdEMsS0FBSztBQUFBLFlBQ2pELFdBQVU7QUFBQSxZQUVWO0FBQUEscUNBQUMsZ2NBQU8sT0FBTSxPQUFNLDBCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4QjtBQUFBLGNBQzlCLHVCQUFDLDZiQUFPLE9BQU0sVUFBUyxzQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkI7QUFBQSxjQUM3Qix1QkFBQyxpY0FBTyxPQUFNLFlBQVcsd0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlDO0FBQUE7QUFBQTtBQUFBLFVBUG5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVFBO0FBQUEsUUFFQTtBQUFBLFVBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBQ0MsT0FBT3hCO0FBQUFBLFlBQ1AsVUFBVSxDQUFDa0QsTUFBTWpELGNBQWNpRCxHQUFHWSxRQUFRdEMsS0FBSztBQUFBLFlBQy9DLFdBQVU7QUFBQSxZQUVWO0FBQUEscUNBQUMsK2JBQU8sT0FBTSxPQUFNLHlCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2QjtBQUFBLGNBQzVCdEIsT0FBT2E7QUFBQUEsZ0JBQUksQ0FBQXpCLFNBQ1YsdUJBQUMsNlhBQXlCLE9BQU9BLE1BQU1rQyxPQUFRbEMsZ0JBQU1tQyxTQUF4Q25DLE1BQU1rQyxPQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyRDtBQUFBLGNBQzVEO0FBQUE7QUFBQTtBQUFBLFVBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBU0E7QUFBQSxXQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0NBO0FBQUEsTUFFQTtBQUFBLFFBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBQ0MsU0FBU3BCO0FBQUFBLFVBQ1QsVUFBVXpCO0FBQUFBLFVBQ1YsV0FBVTtBQUFBLFVBRVY7QUFBQSxtQ0FBQyxvWkFBSyxNQUFLLGFBQVksTUFBTSxJQUFJLFdBQVdBLFVBQVUsaUJBQWlCLE1BQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBFO0FBQUEsWUFDMUUsdUJBQUMsMlpBQUssdUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBYTtBQUFBO0FBQUE7QUFBQSxRQU5mO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9BO0FBQUEsU0ExQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJDQTtBQUFBLElBRUNFLGVBQWU4QixTQUFTLEtBQ3ZCLHVCQUFDLDRjQUFJLFdBQVUsMERBQ2IsaUNBQUMsb2JBQUksV0FBVSxxQ0FDYjtBQUFBLDZCQUFDLGtlQUFLLFdBQVUsb0NBQ2I5QjtBQUFBQSx1QkFBZThCO0FBQUFBLFFBQU87QUFBQSxRQUFNOUIsZUFBZThCLFdBQVcsSUFBSSxNQUFNO0FBQUEsUUFBRztBQUFBLFdBRHRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsK1pBQUksV0FBVSxrQkFDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU1rQyxpQkFBaUIsVUFBVTtBQUFBLFlBQzFDLFdBQVU7QUFBQSxZQUFxRztBQUFBO0FBQUEsVUFGakg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU1BLGlCQUFpQixZQUFZO0FBQUEsWUFDNUMsV0FBVTtBQUFBLFlBQWlHO0FBQUE7QUFBQSxVQUY3RztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTUEsaUJBQWlCLFFBQVE7QUFBQSxZQUN4QyxXQUFVO0FBQUEsWUFBNkc7QUFBQTtBQUFBLFVBRnpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsV0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1CQTtBQUFBLFNBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3QkEsS0F6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBCQTtBQUFBLElBR0RsRSxVQUNDLHVCQUFDLDBiQUFJLFdBQVUsMENBQ2IsaUNBQUMsOGFBQUksV0FBVSwrQkFDYjtBQUFBLDZCQUFDLG9kQUFJLFdBQVUsaUVBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RTtBQUFBLE1BQzdFLHVCQUFDLG9kQUFLLFdBQVUsdUJBQXNCLGdDQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNEO0FBQUEsU0FGeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBO0FBQUE7QUFBQSxNQUdDLHVCQUFDLGdkQUFJLFdBQVUsOERBQ2QsaUNBQUMsOFpBQUksV0FBVSxtQkFDYixpQ0FBQywyWkFBTSxXQUFVLFVBQ2Y7QUFBQSwrQkFBQyw2YkFBTSxXQUFVLHdDQUNmLGlDQUFDLGlYQUNDO0FBQUEsaUNBQUMsbWFBQUcsV0FBVSx1QkFDWjtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBU0UsZUFBZThCLFdBQVdsQyxPQUFPa0MsVUFBVWxDLE9BQU9rQyxTQUFTO0FBQUEsY0FDcEUsVUFBVWlDO0FBQUFBLGNBQ1YsV0FBVTtBQUFBO0FBQUEsWUFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJbUUsS0FMckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBQ0EsdUJBQUMsZ2ZBQUcsV0FBVSw2REFBNEQsb0JBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThFO0FBQUEsVUFDOUUsdUJBQUMsZ2ZBQUcsV0FBVSw2REFBNEQsb0JBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThFO0FBQUEsVUFDOUUsdUJBQUMsa2ZBQUcsV0FBVSw2REFBNEQsc0JBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdGO0FBQUEsVUFDaEYsdUJBQUMsd2ZBQUcsV0FBVSw2REFBNEQsMEJBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9GO0FBQUEsVUFDcEYsdUJBQUMsbWZBQUcsV0FBVSw2REFBNEQsdUJBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlGO0FBQUEsYUFibkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBLEtBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdCQTtBQUFBLFFBQ0EsdUJBQUMsMFhBQ0VuRSxpQkFBT2tDLFdBQVcsSUFDakIsdUJBQUMsaVhBQ0MsaUNBQUMsOFpBQUcsU0FBUSxLQUFJLFdBQVUsb0JBQ3hCO0FBQUEsaUNBQUMsOGNBQUssTUFBSyxTQUFRLE1BQU0sSUFBSSxXQUFVLHFDQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RTtBQUFBLFVBQ3hFLHVCQUFDLDJjQUFFLFdBQVUsdUJBQXNCLDhCQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpRDtBQUFBLGFBRm5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQSxJQUVBbEMsT0FBT3NDO0FBQUFBLFVBQUksQ0FBQ3pDLFNBQ1YsdUJBQUMsK2JBQWtCLFdBQVUsaURBQzNCO0FBQUEsbUNBQUMsdVpBQUcsV0FBVSxhQUNaO0FBQUEsY0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVNPLGVBQWU2RCxTQUFTcEUsTUFBTTBDLEVBQUU7QUFBQSxnQkFDekMsVUFBVSxNQUFNdUIsaUJBQWlCakUsTUFBTTBDLEVBQUU7QUFBQSxnQkFDekMsV0FBVTtBQUFBO0FBQUEsY0FKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJbUUsS0FMckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBQ0EsdUJBQUMsdVpBQUcsV0FBVSxhQUNaLGlDQUFDLDhhQUFJLFdBQVUsK0JBQ2I7QUFBQSxxQ0FBQywrZEFBSSxXQUFVLHdFQUNaMUMsZ0JBQU15RCxTQUNMLHVCQUFDLHVhQUFJLEtBQUt6RCxNQUFNeUQsUUFBUSxLQUFLekQsTUFBTTJDLE1BQU0sV0FBVSwwQkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUUsSUFFekUsdUJBQUMsc2JBQUssTUFBSyxRQUFPLE1BQU0sSUFBSSxXQUFVLGtCQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvRCxLQUp4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU1BO0FBQUEsY0FDQSx1QkFBQyxvWEFDQztBQUFBLHVDQUFDLDhhQUFJLFdBQVUsaUNBQWlDM0MsZ0JBQU0yQyxRQUFRLGtCQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2RTtBQUFBLGdCQUM3RSx1QkFBQyw0YUFBSSxXQUFVLCtCQUErQjNDLGdCQUFNYSxTQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwRDtBQUFBLG1CQUY1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsaUJBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFZQSxLQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBY0E7QUFBQSxZQUNBLHVCQUFDLHViQUFHLFdBQVUseUNBQXlDYixnQkFBTWdCLFFBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtFO0FBQUEsWUFDbEUsdUJBQUMsdVpBQUcsV0FBVSxhQUFhbUUseUJBQWVuRixNQUFNa0MsTUFBTSxLQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RDtBQUFBLFlBQ3hELHVCQUFDLHViQUFHLFdBQVUseUNBQXlDbEMsZ0JBQU1xRCxhQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RTtBQUFBLFlBQ3ZFLHVCQUFDLHVaQUFHLFdBQVUsYUFDWixpQ0FBQywrWkFBSSxXQUFVLGtCQUNackQ7QUFBQUEsb0JBQU1rQyxXQUFXLFdBQ2hCO0FBQUEsZ0JBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUNDLFNBQVMsTUFBTTZDLGlCQUFpQixjQUFjL0UsTUFBTTBDLEVBQUU7QUFBQSxrQkFDdEQsV0FBVTtBQUFBLGtCQUNWLE9BQU07QUFBQSxrQkFFTixpQ0FBQyxnWkFBSyxNQUFLLFNBQVEsTUFBTSxNQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE0QjtBQUFBO0FBQUEsZ0JBTDlCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1BLElBRUE7QUFBQSxnQkFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBQ0MsU0FBUyxNQUFNcUMsaUJBQWlCLFlBQVkvRSxNQUFNMEMsRUFBRTtBQUFBLGtCQUNwRCxXQUFVO0FBQUEsa0JBQ1YsT0FBTTtBQUFBLGtCQUVOLGlDQUFDLG9aQUFLLE1BQUssYUFBWSxNQUFNLE1BQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdDO0FBQUE7QUFBQSxnQkFMbEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTUE7QUFBQSxjQUVGO0FBQUEsZ0JBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUNDLFNBQVMsTUFBTXFDLGlCQUFpQixVQUFVL0UsTUFBTTBDLEVBQUU7QUFBQSxrQkFDbEQsV0FBVTtBQUFBLGtCQUNWLE9BQU07QUFBQSxrQkFFTixpQ0FBQyxpWkFBSyxNQUFLLFVBQVMsTUFBTSxNQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2QjtBQUFBO0FBQUEsZ0JBTC9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1BO0FBQUEsaUJBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBeUJBLEtBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMkJBO0FBQUEsZUF0RE8xQyxNQUFNMEMsSUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVEQTtBQUFBLFFBQ0QsS0FsRUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9FQTtBQUFBLFdBdEZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF1RkEsS0F4RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlGQSxLQTFGRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMkZEO0FBQUE7QUFBQSxJQUdEakMsbUJBQ0MsdUJBQUMsd2JBQUksV0FBVSx3Q0FDYixpQ0FBQyx5Y0FBSSxXQUFVLHNEQUNiO0FBQUEsNkJBQUMseWJBQUksV0FBVSx3Q0FBdUMsU0FBUyxNQUFNQyxtQkFBbUIsS0FBSyxLQUE3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdHO0FBQUEsTUFDaEcsdUJBQUMsMGRBQUksV0FBVSxtRUFDYixpQ0FBQyxrWkFBSSxXQUFVLE9BQ2I7QUFBQSwrQkFBQywyYkFBSSxXQUFVLDBDQUNiO0FBQUEsaUNBQUMsdWVBQUcsV0FBVSwyQ0FBMEMsK0JBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVFO0FBQUEsVUFDdkU7QUFBQSxZQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUNDLFNBQVMsTUFBTUEsbUJBQW1CLEtBQUs7QUFBQSxjQUN2QyxXQUFVO0FBQUEsY0FFVixpQ0FBQyw0WUFBSyxNQUFLLEtBQUksTUFBTSxNQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3QjtBQUFBO0FBQUEsWUFKMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBQ0EsdUJBQUMsMlpBQUssVUFBVWlFLGtCQUFrQixXQUFVLGFBQzFDO0FBQUEsaUNBQUMsb1hBQ0M7QUFBQSxtQ0FBQyx5ZkFBTSxXQUFVLG9EQUFtRCw2QkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUY7QUFBQSxZQUNqRjtBQUFBLGNBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxPQUFPaEUsWUFBWUU7QUFBQUEsZ0JBQ25CLFVBQVUsQ0FBQytELE1BQU1oRSxjQUFjLENBQUF1RCxVQUFTLEVBQUUsR0FBR0EsTUFBTXRELE9BQU8rRCxHQUFHWSxRQUFRdEMsTUFBTSxFQUFFO0FBQUEsZ0JBQzdFLFdBQVU7QUFBQSxnQkFDVixhQUFZO0FBQUEsZ0JBQ1osVUFBUTtBQUFBO0FBQUEsY0FOVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNVTtBQUFBLGVBUlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBRUEsdUJBQUMseWFBQUksV0FBVSwwQkFDYjtBQUFBLG1DQUFDLG9YQUNDO0FBQUEscUNBQUMsc2ZBQU0sV0FBVSxvREFBbUQsMEJBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQThFO0FBQUEsY0FDOUU7QUFBQSxnQkFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE9BQU92QyxZQUFZRztBQUFBQSxrQkFDbkIsVUFBVSxDQUFDOEQsTUFBTWhFLGNBQWMsQ0FBQXVELFVBQVMsRUFBRSxHQUFHQSxNQUFNckQsV0FBVzhELEdBQUdZLFFBQVF0QyxNQUFNLEVBQUU7QUFBQSxrQkFDakYsV0FBVTtBQUFBLGtCQUNWLGFBQVk7QUFBQTtBQUFBLGdCQUxkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtvQjtBQUFBLGlCQVB0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUEsWUFDQSx1QkFBQyxvWEFDQztBQUFBLHFDQUFDLHFmQUFNLFdBQVUsb0RBQW1ELHlCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2RTtBQUFBLGNBQzdFO0FBQUEsZ0JBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxPQUFPdkMsWUFBWUk7QUFBQUEsa0JBQ25CLFVBQVUsQ0FBQzZELE1BQU1oRSxjQUFjLENBQUF1RCxVQUFTLEVBQUUsR0FBR0EsTUFBTXBELFVBQVU2RCxHQUFHWSxRQUFRdEMsTUFBTSxFQUFFO0FBQUEsa0JBQ2hGLFdBQVU7QUFBQSxrQkFDVixhQUFZO0FBQUE7QUFBQSxnQkFMZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLbUI7QUFBQSxpQkFQckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFTQTtBQUFBLGVBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUJBO0FBQUEsVUFFQSx1QkFBQyxvWEFDQztBQUFBLG1DQUFDLDhlQUFNLFdBQVUsb0RBQW1ELG9CQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RTtBQUFBLFlBQ3hFO0FBQUEsY0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ0MsT0FBT3ZDLFlBQVlLO0FBQUFBLGdCQUNuQixVQUFVLENBQUM0RCxNQUFNaEUsY0FBYyxDQUFBdUQsVUFBUyxFQUFFLEdBQUdBLE1BQU1uRCxNQUFNNEQsR0FBR1ksUUFBUXRDLE1BQU0sRUFBRTtBQUFBLGdCQUM1RSxXQUFVO0FBQUEsZ0JBQ1YsVUFBUTtBQUFBLGdCQUVSO0FBQUEseUNBQUMsOGJBQU8sT0FBTSxJQUFHLDJCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE0QjtBQUFBLGtCQUMzQnRCLE9BQU9hO0FBQUFBLG9CQUFJLENBQUF6QixTQUNWLHVCQUFDLDZYQUF5QixPQUFPQSxNQUFNa0MsT0FBUWxDLGdCQUFNbUMsU0FBeENuQyxNQUFNa0MsT0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBMkQ7QUFBQSxrQkFDNUQ7QUFBQTtBQUFBO0FBQUEsY0FUSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFVQTtBQUFBLGVBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFhQTtBQUFBLFVBRUEsdUJBQUMsb1hBQ0M7QUFBQSxtQ0FBQyx3Z0JBQU0sV0FBVSxvREFBbUQsMENBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThGO0FBQUEsWUFDOUY7QUFBQSxjQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFDQyxPQUFPdkMsWUFBWU07QUFBQUEsZ0JBQ25CLFVBQVUsQ0FBQzJELE1BQU1oRSxjQUFjLENBQUF1RCxVQUFTLEVBQUUsR0FBR0EsTUFBTWxELFNBQVMyRCxHQUFHWSxRQUFRdEMsTUFBTSxFQUFFO0FBQUEsZ0JBQy9FLFdBQVU7QUFBQSxnQkFDVixNQUFNO0FBQUEsZ0JBQ04sYUFBWTtBQUFBO0FBQUEsY0FMZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLc0M7QUFBQSxlQVB4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVNBO0FBQUEsVUFFQSx1QkFBQyxvYkFBSSxXQUFVLG1DQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUyxNQUFNeEMsbUJBQW1CLEtBQUs7QUFBQSxnQkFDdkMsV0FBVTtBQUFBLGdCQUFzRjtBQUFBO0FBQUEsY0FIbEc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFBNEc7QUFBQTtBQUFBLGNBRnhIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBO0FBQUEsZUFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWNBO0FBQUEsYUE1RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTZFQTtBQUFBLFdBdkZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3RkEsS0F6RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTBGQTtBQUFBLFNBNUZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E2RkEsS0E5RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQStGQTtBQUFBLE9BM1RKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2VEE7QUFFSjtBQUFFWCxHQWxnQklELGdCQUFjO0FBQUEsVUFDeUJGLE9BQU87QUFBQTtBQUFBNkYsS0FEOUMzRjtBQW9nQk4sZUFBZUE7QUFBZSxJQUFBMkY7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJJY29uIiwidXNlQXV0aCIsInVzZXJTZXJ2aWNlIiwiVXNlck1hbmFnZW1lbnQiLCJfcyIsInVzZXIiLCJjdXJyZW50VXNlciIsInVzZXJQcm9maWxlIiwidXNlcnMiLCJzZXRVc2VycyIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwic2VsZWN0ZWRVc2VycyIsInNldFNlbGVjdGVkVXNlcnMiLCJzaG93SW52aXRlTW9kYWwiLCJzZXRTaG93SW52aXRlTW9kYWwiLCJpbnZpdGVGb3JtIiwic2V0SW52aXRlRm9ybSIsImVtYWlsIiwiZmlyc3ROYW1lIiwibGFzdE5hbWUiLCJyb2xlIiwibWVzc2FnZSIsImVycm9yIiwic2V0RXJyb3IiLCJzdWNjZXNzIiwic2V0U3VjY2VzcyIsInNlYXJjaFF1ZXJ5Iiwic2V0U2VhcmNoUXVlcnkiLCJzdGF0dXNGaWx0ZXIiLCJzZXRTdGF0dXNGaWx0ZXIiLCJyb2xlRmlsdGVyIiwic2V0Um9sZUZpbHRlciIsInJvbGVzIiwiZ2V0VXNlclJvbGVzIiwibG9hZFVzZXJzIiwidXNlckRhdGEiLCJzZWFyY2hVc2VycyIsImZpbHRlcnMiLCJzdGF0dXMiLCJPYmplY3QiLCJrZXlzIiwibGVuZ3RoIiwiZmlsdGVyVXNlcnMiLCJnZXRBbGxVc2VycyIsInRyYW5zZm9ybWVkVXNlcnMiLCJtYXAiLCJpZCIsIm5hbWUiLCJmdWxsX25hbWUiLCJmaXJzdF9uYW1lIiwibGFzdF9uYW1lIiwidHJpbSIsImZpbmQiLCJyIiwidmFsdWUiLCJsYWJlbCIsImlzX2FjdGl2ZSIsImxhc3RMb2dpbiIsInVwZGF0ZWRfYXQiLCJEYXRlIiwidG9Mb2NhbGVTdHJpbmciLCJhdmF0YXIiLCJhdmF0YXJfdXJsIiwicmF3RGF0YSIsImVyciIsImNvbnNvbGUiLCJ0aW1lciIsInNldFRpbWVvdXQiLCJjbGVhclRpbWVvdXQiLCJoYW5kbGVTZWxlY3RVc2VyIiwidXNlcklkIiwicHJldiIsImluY2x1ZGVzIiwiZmlsdGVyIiwiaGFuZGxlU2VsZWN0QWxsIiwiaGFuZGxlQnVsa0FjdGlvbiIsImFjdGlvbiIsInVwZGF0ZXMiLCJidWxrVXBkYXRlVXNlcnMiLCJoYW5kbGVJbnZpdGVVc2VyIiwiZSIsInByZXZlbnREZWZhdWx0IiwiaW52aXRlVXNlciIsImhhbmRsZVVzZXJBY3Rpb24iLCJhY3RpdmF0ZVVzZXIiLCJkZWFjdGl2YXRlVXNlciIsImRlbGV0ZVVzZXIiLCJnZXRTdGF0dXNCYWRnZSIsInN0YXR1c1N0eWxlcyIsIkFjdGl2ZSIsIkluYWN0aXZlIiwiUGVuZGluZyIsInRhcmdldCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiVXNlck1hbmFnZW1lbnQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIHNyYy9wYWdlcy9zZXR0aW5ncy1hZG1pbmlzdHJhdGlvbi9jb21wb25lbnRzL1VzZXJNYW5hZ2VtZW50LmpzeFxyXG5pbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IEljb24gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9BcHBJY29uJztcclxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uLy4uLy4uL2NvbnRleHRzL0F1dGhDb250ZXh0JztcclxuaW1wb3J0IHVzZXJTZXJ2aWNlIGZyb20gJy4uLy4uLy4uL3NlcnZpY2VzL3VzZXJTZXJ2aWNlJztcclxuXHJcbmNvbnN0IFVzZXJNYW5hZ2VtZW50ID0gKCkgPT4ge1xyXG4gIGNvbnN0IHsgdXNlcjogY3VycmVudFVzZXIsIHVzZXJQcm9maWxlIH0gPSB1c2VBdXRoKCk7XHJcbiAgY29uc3QgW3VzZXJzLCBzZXRVc2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkVXNlcnMsIHNldFNlbGVjdGVkVXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzaG93SW52aXRlTW9kYWwsIHNldFNob3dJbnZpdGVNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2ludml0ZUZvcm0sIHNldEludml0ZUZvcm1dID0gdXNlU3RhdGUoeyBcclxuICAgIGVtYWlsOiAnJywgXHJcbiAgICBmaXJzdE5hbWU6ICcnLCBcclxuICAgIGxhc3ROYW1lOiAnJywgXHJcbiAgICByb2xlOiAnJywgXHJcbiAgICBtZXNzYWdlOiAnJyBcclxuICB9KTtcclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKTtcclxuICBjb25zdCBbc3VjY2Vzcywgc2V0U3VjY2Vzc10gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW3NlYXJjaFF1ZXJ5LCBzZXRTZWFyY2hRdWVyeV0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW3N0YXR1c0ZpbHRlciwgc2V0U3RhdHVzRmlsdGVyXSA9IHVzZVN0YXRlKCdhbGwnKTtcclxuICBjb25zdCBbcm9sZUZpbHRlciwgc2V0Um9sZUZpbHRlcl0gPSB1c2VTdGF0ZSgnYWxsJyk7XHJcblxyXG4gIGNvbnN0IHJvbGVzID0gdXNlclNlcnZpY2U/LmdldFVzZXJSb2xlcygpO1xyXG5cclxuICAvLyBMb2FkIHVzZXJzIGRhdGFcclxuICBjb25zdCBsb2FkVXNlcnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4gICAgICBzZXRFcnJvcignJyk7XHJcbiAgICAgIFxyXG4gICAgICBsZXQgdXNlckRhdGEgPSBbXTtcclxuICAgICAgaWYgKHNlYXJjaFF1ZXJ5KSB7XHJcbiAgICAgICAgdXNlckRhdGEgPSBhd2FpdCB1c2VyU2VydmljZT8uc2VhcmNoVXNlcnMoc2VhcmNoUXVlcnkpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGNvbnN0IGZpbHRlcnMgPSB7fTtcclxuICAgICAgICBpZiAoc3RhdHVzRmlsdGVyICE9PSAnYWxsJykge1xyXG4gICAgICAgICAgZmlsdGVycy5zdGF0dXMgPSBzdGF0dXNGaWx0ZXI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChyb2xlRmlsdGVyICE9PSAnYWxsJykge1xyXG4gICAgICAgICAgZmlsdGVycy5yb2xlcyA9IFtyb2xlRmlsdGVyXTtcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgICAgaWYgKE9iamVjdC5rZXlzKGZpbHRlcnMpPy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICB1c2VyRGF0YSA9IGF3YWl0IHVzZXJTZXJ2aWNlPy5maWx0ZXJVc2VycyhmaWx0ZXJzKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgdXNlckRhdGEgPSBhd2FpdCB1c2VyU2VydmljZT8uZ2V0QWxsVXNlcnMoKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIFRyYW5zZm9ybSBkYXRhIGZvciBkaXNwbGF5XHJcbiAgICAgIGNvbnN0IHRyYW5zZm9ybWVkVXNlcnMgPSB1c2VyRGF0YT8ubWFwKHVzZXIgPT4gKHtcclxuICAgICAgICBpZDogdXNlcj8uaWQsXHJcbiAgICAgICAgbmFtZTogdXNlcj8uZnVsbF9uYW1lIHx8IGAke3VzZXI/LmZpcnN0X25hbWV9ICR7dXNlcj8ubGFzdF9uYW1lfWA/LnRyaW0oKSxcclxuICAgICAgICBlbWFpbDogdXNlcj8uZW1haWwsXHJcbiAgICAgICAgcm9sZTogcm9sZXM/LmZpbmQociA9PiByPy52YWx1ZSA9PT0gdXNlcj8ucm9sZSk/LmxhYmVsIHx8IHVzZXI/LnJvbGUsXHJcbiAgICAgICAgc3RhdHVzOiB1c2VyPy5pc19hY3RpdmUgPyAnQWN0aXZlJyA6ICdJbmFjdGl2ZScsXHJcbiAgICAgICAgbGFzdExvZ2luOiB1c2VyPy51cGRhdGVkX2F0ID8gbmV3IERhdGUodXNlcj8udXBkYXRlZF9hdCk/LnRvTG9jYWxlU3RyaW5nKCkgOiAnTmV2ZXInLFxyXG4gICAgICAgIGF2YXRhcjogdXNlcj8uYXZhdGFyX3VybCxcclxuICAgICAgICByYXdEYXRhOiB1c2VyXHJcbiAgICAgIH0pKTtcclxuXHJcbiAgICAgIHNldFVzZXJzKHRyYW5zZm9ybWVkVXNlcnMpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGxvYWRpbmcgdXNlcnM6JywgZXJyKTtcclxuICAgICAgc2V0RXJyb3IoJ0ZhaWxlZCB0byBsb2FkIHVzZXJzLiBQbGVhc2UgdHJ5IGFnYWluLicpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChjdXJyZW50VXNlciAmJiB1c2VyUHJvZmlsZT8ucm9sZSA9PT0gJ2FkbWluJykge1xyXG4gICAgICBsb2FkVXNlcnMoKTtcclxuICAgIH1cclxuICB9LCBbY3VycmVudFVzZXIsIHVzZXJQcm9maWxlLCBzZWFyY2hRdWVyeSwgc3RhdHVzRmlsdGVyLCByb2xlRmlsdGVyXSk7XHJcblxyXG4gIC8vIEF1dG8tY2xlYXIgbWVzc2FnZXNcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKGVycm9yIHx8IHN1Y2Nlc3MpIHtcclxuICAgICAgY29uc3QgdGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICBzZXRFcnJvcignJyk7XHJcbiAgICAgICAgc2V0U3VjY2VzcygnJyk7XHJcbiAgICAgIH0sIDUwMDApO1xyXG4gICAgICByZXR1cm4gKCkgPT4gY2xlYXJUaW1lb3V0KHRpbWVyKTtcclxuICAgIH1cclxuICB9LCBbZXJyb3IsIHN1Y2Nlc3NdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU2VsZWN0VXNlciA9ICh1c2VySWQpID0+IHtcclxuICAgIHNldFNlbGVjdGVkVXNlcnMocHJldiA9PlxyXG4gICAgICBwcmV2Py5pbmNsdWRlcyh1c2VySWQpXHJcbiAgICAgICAgPyBwcmV2Py5maWx0ZXIoaWQgPT4gaWQgIT09IHVzZXJJZClcclxuICAgICAgICA6IFsuLi5wcmV2LCB1c2VySWRdXHJcbiAgICApO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVNlbGVjdEFsbCA9ICgpID0+IHtcclxuICAgIHNldFNlbGVjdGVkVXNlcnMoXHJcbiAgICAgIHNlbGVjdGVkVXNlcnM/Lmxlbmd0aCA9PT0gdXNlcnM/Lmxlbmd0aCA/IFtdIDogdXNlcnM/Lm1hcCh1c2VyID0+IHVzZXI/LmlkKVxyXG4gICAgKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVCdWxrQWN0aW9uID0gYXN5bmMgKGFjdGlvbikgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0RXJyb3IoJycpO1xyXG4gICAgICBsZXQgdXBkYXRlcyA9IHt9O1xyXG4gICAgICBcclxuICAgICAgc3dpdGNoIChhY3Rpb24pIHtcclxuICAgICAgICBjYXNlICdhY3RpdmF0ZSc6XHJcbiAgICAgICAgICB1cGRhdGVzID0geyBpc19hY3RpdmU6IHRydWUgfTtcclxuICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIGNhc2UgJ2RlYWN0aXZhdGUnOlxyXG4gICAgICAgICAgdXBkYXRlcyA9IHsgaXNfYWN0aXZlOiBmYWxzZSB9O1xyXG4gICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgY2FzZSAnZGVsZXRlJzpcclxuICAgICAgICAgIHVwZGF0ZXMgPSB7IGlzX2FjdGl2ZTogZmFsc2UgfTtcclxuICAgICAgICAgIGJyZWFrO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBhd2FpdCB1c2VyU2VydmljZT8uYnVsa1VwZGF0ZVVzZXJzKHNlbGVjdGVkVXNlcnMsIHVwZGF0ZXMpO1xyXG4gICAgICBzZXRTdWNjZXNzKGBTdWNjZXNzZnVsbHkgJHthY3Rpb259ZCAke3NlbGVjdGVkVXNlcnM/Lmxlbmd0aH0gdXNlcihzKWApO1xyXG4gICAgICBzZXRTZWxlY3RlZFVzZXJzKFtdKTtcclxuICAgICAgbG9hZFVzZXJzKCk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgJHthY3Rpb259aW5nIHVzZXJzOmAsIGVycik7XHJcbiAgICAgIHNldEVycm9yKGBGYWlsZWQgdG8gJHthY3Rpb259IHVzZXJzLiBQbGVhc2UgdHJ5IGFnYWluLmApO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUludml0ZVVzZXIgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZT8ucHJldmVudERlZmF1bHQoKTtcclxuICAgIFxyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0RXJyb3IoJycpO1xyXG4gICAgICBhd2FpdCB1c2VyU2VydmljZT8uaW52aXRlVXNlcihpbnZpdGVGb3JtKTtcclxuICAgICAgc2V0U3VjY2VzcygnVXNlciBpbnZpdGF0aW9uIHNlbnQgc3VjY2Vzc2Z1bGx5IScpO1xyXG4gICAgICBzZXRTaG93SW52aXRlTW9kYWwoZmFsc2UpO1xyXG4gICAgICBzZXRJbnZpdGVGb3JtKHsgZW1haWw6ICcnLCBmaXJzdE5hbWU6ICcnLCBsYXN0TmFtZTogJycsIHJvbGU6ICcnLCBtZXNzYWdlOiAnJyB9KTtcclxuICAgICAgbG9hZFVzZXJzKCk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgaW52aXRpbmcgdXNlcjonLCBlcnIpO1xyXG4gICAgICBzZXRFcnJvcignRmFpbGVkIHRvIHNlbmQgaW52aXRhdGlvbi4gUGxlYXNlIHRyeSBhZ2Fpbi4nKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVVc2VyQWN0aW9uID0gYXN5bmMgKGFjdGlvbiwgdXNlcklkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRFcnJvcignJyk7XHJcbiAgICAgIFxyXG4gICAgICBzd2l0Y2ggKGFjdGlvbikge1xyXG4gICAgICAgIGNhc2UgJ2FjdGl2YXRlJzpcclxuICAgICAgICAgIGF3YWl0IHVzZXJTZXJ2aWNlPy5hY3RpdmF0ZVVzZXIodXNlcklkKTtcclxuICAgICAgICAgIHNldFN1Y2Nlc3MoJ1VzZXIgYWN0aXZhdGVkIHN1Y2Nlc3NmdWxseScpO1xyXG4gICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgY2FzZSAnZGVhY3RpdmF0ZSc6XHJcbiAgICAgICAgICBhd2FpdCB1c2VyU2VydmljZT8uZGVhY3RpdmF0ZVVzZXIodXNlcklkKTtcclxuICAgICAgICAgIHNldFN1Y2Nlc3MoJ1VzZXIgZGVhY3RpdmF0ZWQgc3VjY2Vzc2Z1bGx5Jyk7XHJcbiAgICAgICAgICBicmVhaztcclxuICAgICAgICBjYXNlICdkZWxldGUnOlxyXG4gICAgICAgICAgYXdhaXQgdXNlclNlcnZpY2U/LmRlbGV0ZVVzZXIodXNlcklkKTtcclxuICAgICAgICAgIHNldFN1Y2Nlc3MoJ1VzZXIgZGVsZXRlZCBzdWNjZXNzZnVsbHknKTtcclxuICAgICAgICAgIGJyZWFrO1xyXG4gICAgICB9XHJcbiAgICAgIFxyXG4gICAgICBsb2FkVXNlcnMoKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKGBFcnJvciAke2FjdGlvbn1pbmcgdXNlcjpgLCBlcnIpO1xyXG4gICAgICBzZXRFcnJvcihgRmFpbGVkIHRvICR7YWN0aW9ufSB1c2VyLiBQbGVhc2UgdHJ5IGFnYWluLmApO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGdldFN0YXR1c0JhZGdlID0gKHN0YXR1cykgPT4ge1xyXG4gICAgY29uc3Qgc3RhdHVzU3R5bGVzID0ge1xyXG4gICAgICBBY3RpdmU6ICdiZy1zdWNjZXNzLTUwIHRleHQtc3VjY2Vzcy02MDAgYm9yZGVyLXN1Y2Nlc3MtMTAwJyxcclxuICAgICAgSW5hY3RpdmU6ICdiZy1lcnJvci01MCB0ZXh0LWVycm9yLTYwMCBib3JkZXItZXJyb3ItMTAwJyxcclxuICAgICAgUGVuZGluZzogJ2JnLXdhcm5pbmctNTAgdGV4dC13YXJuaW5nLTYwMCBib3JkZXItd2FybmluZy0xMDAnXHJcbiAgICB9O1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHB4LTIgcHktMSB0ZXh0LXhzIGZvbnQtbWVkaXVtIHJvdW5kZWQgYm9yZGVyICR7c3RhdHVzU3R5bGVzPy5bc3RhdHVzXSB8fCAnYmctZ3JheS01MCB0ZXh0LWdyYXktNjAwIGJvcmRlci1ncmF5LTEwMCd9YH0+XHJcbiAgICAgICAge3N0YXR1c31cclxuICAgICAgPC9zcGFuPlxyXG4gICAgKTtcclxuICB9O1xyXG5cclxuICAvLyBTaG93IGFjY2VzcyBkZW5pZWQgZm9yIG5vbi1hZG1pbiB1c2Vyc1xyXG4gIGlmICghY3VycmVudFVzZXIgfHwgIXVzZXJQcm9maWxlIHx8IHVzZXJQcm9maWxlPy5yb2xlICE9PSAnYWRtaW4nKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktMTJcIj5cclxuICAgICAgICAgIDxJY29uIG5hbWU9XCJMb2NrXCIgc2l6ZT17NDh9IGNsYXNzTmFtZT1cInRleHQtdGV4dC10ZXJ0aWFyeSBteC1hdXRvIG1iLTRcIiAvPlxyXG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItMlwiPkFjY2VzcyBSZXN0cmljdGVkPC9oMz5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtdGV4dC1zZWNvbmRhcnlcIj5Pbmx5IGFkbWluaXN0cmF0b3JzIGNhbiBhY2Nlc3MgdXNlciBtYW5hZ2VtZW50LjwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XHJcbiAgICAgIHsvKiBIZWFkZXIgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC10ZXh0LXByaW1hcnlcIj5Vc2VyIE1hbmFnZW1lbnQ8L2gyPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC10ZXh0LXNlY29uZGFyeSBtdC0xXCI+TWFuYWdlIHVzZXJzLCByb2xlcywgYW5kIHBlcm1pc3Npb25zPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dJbnZpdGVNb2RhbCh0cnVlKX1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXByaW1hcnkgdGV4dC13aGl0ZSBweC00IHB5LTIgcm91bmRlZC1sZyBob3ZlcjpiZy1wcmltYXJ5LTYwMCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTAgZWFzZS1zbW9vdGggZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8SWNvbiBuYW1lPVwiVXNlclBsdXNcIiBzaXplPXsxNn0gLz5cclxuICAgICAgICAgIDxzcGFuPkludml0ZSBVc2VyPC9zcGFuPlxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgey8qIFN1Y2Nlc3MvRXJyb3IgTWVzc2FnZXMgKi99XHJcbiAgICAgIHtzdWNjZXNzICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXN1Y2Nlc3MtNTAgYm9yZGVyIGJvcmRlci1zdWNjZXNzLTIwMCB0ZXh0LXN1Y2Nlc3MgcC00IHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCI+XHJcbiAgICAgICAgICA8SWNvbiBuYW1lPVwiQ2hlY2tDaXJjbGVcIiBzaXplPXsyMH0gLz5cclxuICAgICAgICAgIDxzcGFuPntzdWNjZXNzfTwvc3Bhbj5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U3VjY2VzcygnJyl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1sLWF1dG8gdGV4dC1zdWNjZXNzIGhvdmVyOnRleHQtc3VjY2Vzcy02MDBcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8SWNvbiBuYW1lPVwiWFwiIHNpemU9ezE2fSAvPlxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcbiAgICAgIHtlcnJvciAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1lcnJvci01MCBib3JkZXIgYm9yZGVyLWVycm9yLTIwMCB0ZXh0LWVycm9yIHAtNCByb3VuZGVkLWxnIGZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMlwiPlxyXG4gICAgICAgICAgPEljb24gbmFtZT1cIkFsZXJ0Q2lyY2xlXCIgc2l6ZT17MjB9IC8+XHJcbiAgICAgICAgICA8c3Bhbj57ZXJyb3J9PC9zcGFuPlxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRFcnJvcignJyl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1sLWF1dG8gdGV4dC1lcnJvciBob3Zlcjp0ZXh0LWVycm9yLTYwMFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxJY29uIG5hbWU9XCJYXCIgc2l6ZT17MTZ9IC8+XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgICAgey8qIFNlYXJjaCBhbmQgRmlsdGVycyAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGdhcC00IGl0ZW1zLXN0YXJ0IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgZ2FwLTNcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgPEljb24gbmFtZT1cIlNlYXJjaFwiIHNpemU9ezE2fSBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTMgdG9wLTEvMiB0cmFuc2Zvcm0gLXRyYW5zbGF0ZS15LTEvMiB0ZXh0LXRleHQtdGVydGlhcnlcIiAvPlxyXG4gICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggdXNlcnMuLi5cIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtzZWFyY2hRdWVyeX1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlYXJjaFF1ZXJ5KGU/LnRhcmdldD8udmFsdWUpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInBsLTEwIHByLTQgcHktMiBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLWxnIGZvY3VzOnJpbmctcHJpbWFyeSBmb2N1czpib3JkZXItcHJpbWFyeSB3LTY0XCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgIHZhbHVlPXtzdGF0dXNGaWx0ZXJ9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U3RhdHVzRmlsdGVyKGU/LnRhcmdldD8udmFsdWUpfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ib3JkZXIgcm91bmRlZC1sZyBmb2N1czpyaW5nLXByaW1hcnkgZm9jdXM6Ym9yZGVyLXByaW1hcnlcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYWxsXCI+QWxsIFN0YXR1czwvb3B0aW9uPlxyXG4gICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYWN0aXZlXCI+QWN0aXZlPC9vcHRpb24+XHJcbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJpbmFjdGl2ZVwiPkluYWN0aXZlPC9vcHRpb24+XHJcbiAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICB2YWx1ZT17cm9sZUZpbHRlcn1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRSb2xlRmlsdGVyKGU/LnRhcmdldD8udmFsdWUpfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ib3JkZXIgcm91bmRlZC1sZyBmb2N1czpyaW5nLXByaW1hcnkgZm9jdXM6Ym9yZGVyLXByaW1hcnlcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYWxsXCI+QWxsIFJvbGVzPC9vcHRpb24+XHJcbiAgICAgICAgICAgIHtyb2xlcz8ubWFwKHJvbGUgPT4gKFxyXG4gICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtyb2xlPy52YWx1ZX0gdmFsdWU9e3JvbGU/LnZhbHVlfT57cm9sZT8ubGFiZWx9PC9vcHRpb24+XHJcbiAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgXHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgb25DbGljaz17bG9hZFVzZXJzfVxyXG4gICAgICAgICAgZGlzYWJsZWQ9e2xvYWRpbmd9XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTIgcHgtMyBweS0yIHRleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC10ZXh0LXByaW1hcnkgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8SWNvbiBuYW1lPVwiUmVmcmVzaEN3XCIgc2l6ZT17MTZ9IGNsYXNzTmFtZT17bG9hZGluZyA/ICdhbmltYXRlLXNwaW4nIDogJyd9IC8+XHJcbiAgICAgICAgICA8c3Bhbj5SZWZyZXNoPC9zcGFuPlxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgey8qIEJ1bGsgQWN0aW9ucyAqL31cclxuICAgICAge3NlbGVjdGVkVXNlcnM/Lmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctcHJpbWFyeS01MCBib3JkZXIgYm9yZGVyLXByaW1hcnktMTAwIHJvdW5kZWQtbGcgcC00XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtcHJpbWFyeSBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgIHtzZWxlY3RlZFVzZXJzPy5sZW5ndGh9IHVzZXJ7c2VsZWN0ZWRVc2Vycz8ubGVuZ3RoICE9PSAxID8gJ3MnIDogJyd9IHNlbGVjdGVkXHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHNwYWNlLXgtMlwiPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUJ1bGtBY3Rpb24oJ2FjdGl2YXRlJyl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTEgdGV4dC14cyBiZy1zdWNjZXNzIHRleHQtd2hpdGUgcm91bmRlZCBob3ZlcjpiZy1zdWNjZXNzLTYwMCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTBcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIEFjdGl2YXRlXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQnVsa0FjdGlvbignZGVhY3RpdmF0ZScpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xIHRleHQteHMgYmctZXJyb3IgdGV4dC13aGl0ZSByb3VuZGVkIGhvdmVyOmJnLWVycm9yLTYwMCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTBcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIERlYWN0aXZhdGVcclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVCdWxrQWN0aW9uKCdkZWxldGUnKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMSB0ZXh0LXhzIGJnLXRleHQtc2Vjb25kYXJ5IHRleHQtd2hpdGUgcm91bmRlZCBob3ZlcjpiZy10ZXh0LXByaW1hcnkgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBEZWxldGVcclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgICAgey8qIExvYWRpbmcgU3RhdGUgKi99XHJcbiAgICAgIHtsb2FkaW5nID8gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcHktMTJcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0zXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluIHJvdW5kZWQtZnVsbCBoLTggdy04IGJvcmRlci1iLTIgYm9yZGVyLXByaW1hcnlcIj48L2Rpdj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC10ZXh0LXNlY29uZGFyeVwiPkxvYWRpbmcgdXNlcnMuLi48L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKSA6IChcclxuICAgICAgICAvKiBVc2VycyBUYWJsZSAqL1xyXG4gICAgICAgICg8ZGl2IGNsYXNzTmFtZT1cImJnLXN1cmZhY2Ugcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWJvcmRlciBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvXCI+XHJcbiAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctYmFja2dyb3VuZCBib3JkZXItYiBib3JkZXItYm9yZGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgcHktMyBweC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17c2VsZWN0ZWRVc2Vycz8ubGVuZ3RoID09PSB1c2Vycz8ubGVuZ3RoICYmIHVzZXJzPy5sZW5ndGggPiAwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVNlbGVjdEFsbH1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQgYm9yZGVyLWJvcmRlciB0ZXh0LXByaW1hcnkgZm9jdXM6cmluZy1wcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHB5LTMgcHgtNCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5XCI+VXNlcjwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgcHktMyBweC00IHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnlcIj5Sb2xlPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInRleHQtbGVmdCBweS0zIHB4LTQgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeVwiPlN0YXR1czwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgcHktMyBweC00IHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnlcIj5MYXN0IExvZ2luPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInRleHQtbGVmdCBweS0zIHB4LTQgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeVwiPkFjdGlvbnM8L3RoPlxyXG4gICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgICAgIDx0Ym9keT5cclxuICAgICAgICAgICAgICAgIHt1c2Vycz8ubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRkIGNvbFNwYW49XCI2XCIgY2xhc3NOYW1lPVwicHktOCB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIlVzZXJzXCIgc2l6ZT17NDh9IGNsYXNzTmFtZT1cInRleHQtdGV4dC10ZXJ0aWFyeSBteC1hdXRvIG1iLTRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC10ZXh0LXNlY29uZGFyeVwiPk5vIHVzZXJzIGZvdW5kPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICB1c2Vycz8ubWFwKCh1c2VyKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17dXNlcj8uaWR9IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ib3JkZXIgaG92ZXI6Ymctc3VyZmFjZS1ob3ZlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3NlbGVjdGVkVXNlcnM/LmluY2x1ZGVzKHVzZXI/LmlkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT4gaGFuZGxlU2VsZWN0VXNlcih1c2VyPy5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZCBib3JkZXItYm9yZGVyIHRleHQtcHJpbWFyeSBmb2N1czpyaW5nLXByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOCBoLTggYmctcHJpbWFyeS0xMDAgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dXNlcj8uYXZhdGFyID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nIHNyYz17dXNlcj8uYXZhdGFyfSBhbHQ9e3VzZXI/Lm5hbWV9IGNsYXNzTmFtZT1cInctOCBoLTggcm91bmRlZC1mdWxsXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJVc2VyXCIgc2l6ZT17MTZ9IGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5XCI+e3VzZXI/Lm5hbWUgfHwgJ1VubmFtZWQgVXNlcid9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC10ZXh0LXNlY29uZGFyeVwiPnt1c2VyPy5lbWFpbH08L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtNCB0ZXh0LXNtIHRleHQtdGV4dC1zZWNvbmRhcnlcIj57dXNlcj8ucm9sZX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtNFwiPntnZXRTdGF0dXNCYWRnZSh1c2VyPy5zdGF0dXMpfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC00IHRleHQtc20gdGV4dC10ZXh0LXNlY29uZGFyeVwiPnt1c2VyPy5sYXN0TG9naW59PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHNwYWNlLXgtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHt1c2VyPy5zdGF0dXMgPT09ICdBY3RpdmUnID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVVc2VyQWN0aW9uKCdkZWFjdGl2YXRlJywgdXNlcj8uaWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEgdGV4dC10ZXh0LXNlY29uZGFyeSBob3Zlcjp0ZXh0LWVycm9yIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiRGVhY3RpdmF0ZSBVc2VyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIlVzZXJYXCIgc2l6ZT17MTZ9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVVc2VyQWN0aW9uKCdhY3RpdmF0ZScsIHVzZXI/LmlkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xIHRleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC1zdWNjZXNzIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiQWN0aXZhdGUgVXNlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJVc2VyQ2hlY2tcIiBzaXplPXsxNn0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVXNlckFjdGlvbignZGVsZXRlJywgdXNlcj8uaWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xIHRleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC1lcnJvciB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJEZWxldGUgVXNlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIlRyYXNoMlwiIHNpemU9ezE2fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgKSlcclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PilcclxuICAgICAgKX1cclxuICAgICAgey8qIEludml0ZSBVc2VyIE1vZGFsICovfVxyXG4gICAgICB7c2hvd0ludml0ZU1vZGFsICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei0xMjAwIG92ZXJmbG93LXktYXV0b1wiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBtaW4taC1zY3JlZW4gcHgtNFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctYmxhY2sgYmctb3BhY2l0eS01MFwiIG9uQ2xpY2s9eygpID0+IHNldFNob3dJbnZpdGVNb2RhbChmYWxzZSl9PjwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXN1cmZhY2Ugcm91bmRlZC1sZyBzaGFkb3cteGwgbWF4LXctbWQgdy1mdWxsIHJlbGF0aXZlIHotMTMwMFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC10ZXh0LXByaW1hcnlcIj5JbnZpdGUgTmV3IFVzZXI8L2gzPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0ludml0ZU1vZGFsKGZhbHNlKX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5IGhvdmVyOnRleHQtdGV4dC1wcmltYXJ5IHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiWFwiIHNpemU9ezIwfSAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZUludml0ZVVzZXJ9IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IG1iLTFcIj5FbWFpbCBBZGRyZXNzPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17aW52aXRlRm9ybT8uZW1haWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEludml0ZUZvcm0ocHJldiA9PiAoeyAuLi5wcmV2LCBlbWFpbDogZT8udGFyZ2V0Py52YWx1ZSB9KSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1wcmltYXJ5IGZvY3VzOmJvcmRlci1wcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwidXNlckBjb21wYW55LmNvbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IG1iLTFcIj5GaXJzdCBOYW1lPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtpbnZpdGVGb3JtPy5maXJzdE5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0SW52aXRlRm9ybShwcmV2ID0+ICh7IC4uLnByZXYsIGZpcnN0TmFtZTogZT8udGFyZ2V0Py52YWx1ZSB9KSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ib3JkZXIgcm91bmRlZC1sZyBmb2N1czpyaW5nLXByaW1hcnkgZm9jdXM6Ym9yZGVyLXByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkpvaG5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItMVwiPkxhc3QgTmFtZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17aW52aXRlRm9ybT8ubGFzdE5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0SW52aXRlRm9ybShwcmV2ID0+ICh7IC4uLnByZXYsIGxhc3ROYW1lOiBlPy50YXJnZXQ/LnZhbHVlIH0pKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLWxnIGZvY3VzOnJpbmctcHJpbWFyeSBmb2N1czpib3JkZXItcHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRG9lXCJcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSBtYi0xXCI+Um9sZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2ludml0ZUZvcm0/LnJvbGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEludml0ZUZvcm0ocHJldiA9PiAoeyAuLi5wcmV2LCByb2xlOiBlPy50YXJnZXQ/LnZhbHVlIH0pKX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ib3JkZXIgcm91bmRlZC1sZyBmb2N1czpyaW5nLXByaW1hcnkgZm9jdXM6Ym9yZGVyLXByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IFJvbGU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtyb2xlcz8ubWFwKHJvbGUgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17cm9sZT8udmFsdWV9IHZhbHVlPXtyb2xlPy52YWx1ZX0+e3JvbGU/LmxhYmVsfTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSBtYi0xXCI+V2VsY29tZSBNZXNzYWdlIChPcHRpb25hbCk8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2ludml0ZUZvcm0/Lm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEludml0ZUZvcm0ocHJldiA9PiAoeyAuLi5wcmV2LCBtZXNzYWdlOiBlPy50YXJnZXQ/LnZhbHVlIH0pKX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ib3JkZXIgcm91bmRlZC1sZyBmb2N1czpyaW5nLXByaW1hcnkgZm9jdXM6Ym9yZGVyLXByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcm93cz17M31cclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiV2VsY29tZSB0byBvdXIgdGVhbS4uLlwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgc3BhY2UteC0zIG10LTZcIj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dJbnZpdGVNb2RhbChmYWxzZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC10ZXh0LXNlY29uZGFyeSBob3Zlcjp0ZXh0LXRleHQtcHJpbWFyeSB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTBcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctcHJpbWFyeSB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkLWxnIGhvdmVyOmJnLXByaW1hcnktNjAwIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MCBlYXNlLXNtb290aFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgU2VuZCBJbnZpdGF0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFVzZXJNYW5hZ2VtZW50OyJdLCJmaWxlIjoiRDovY3VycmVudCBwcm9qZWN0cy9jbGF1ZGUtY29kZS9zcmMvcGFnZXMvc2V0dGluZ3MtYWRtaW5pc3RyYXRpb24vY29tcG9uZW50cy9Vc2VyTWFuYWdlbWVudC5qc3gifQ==