import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/sales-dashboard/components/PipelineStage.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { Droppable, Draggable } from "/node_modules/.vite/deps/react-beautiful-dnd.js?v=44ab9529";
import Icon from "/src/components/AppIcon.jsx";
import Image from "/src/components/AppImage.jsx";
const PipelineStage = ({ stage, totalValue, weightedValue }) => {
  const getStageColor = (stageId) => {
    const colors = {
      "lead": "bg-gray-100 border-gray-300",
      "qualified": "bg-blue-50 border-blue-300",
      "proposal": "bg-yellow-50 border-yellow-300",
      "negotiation": "bg-orange-50 border-orange-300",
      "closed": "bg-green-50 border-green-300"
    };
    return colors?.[stageId] || "bg-gray-100 border-gray-300";
  };
  const getStageIcon = (stageId) => {
    const icons = {
      "lead": "UserPlus",
      "qualified": "CheckCircle",
      "proposal": "FileText",
      "negotiation": "MessageSquare",
      "closed": "Trophy"
    };
    return icons?.[stageId] || "Circle";
  };
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:30:4", "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx", "data-component-line": "30", "data-component-file": "PipelineStage.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", className: `rounded-lg border-2 border-dashed p-4 ${getStageColor(stage?.id)}`, children: [
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:32:6", "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx", "data-component-line": "32", "data-component-file": "PipelineStage.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%20mb-4%22%7D", className: "flex items-center justify-between mb-4", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:33:8", "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx", "data-component-line": "33", "data-component-file": "PipelineStage.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%22%7D", className: "flex items-center space-x-2", children: [
        /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:34:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx", "data-component-line": "34", "data-component-file": "PipelineStage.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22className%22%3A%22text-text-secondary%22%7D", name: getStageIcon(stage?.id), size: 16, className: "text-text-secondary" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
          lineNumber: 34,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:35:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx", "data-component-line": "35", "data-component-file": "PipelineStage.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22font-medium%20text-text-primary%22%7D", className: "font-medium text-text-primary", children: stage?.title }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
          lineNumber: 35,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
        lineNumber: 33,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:37:8", "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx", "data-component-line": "37", "data-component-file": "PipelineStage.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20font-medium%20text-text-secondary%22%7D", className: "text-sm font-medium text-text-secondary", children: stage?.deals?.length }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
        lineNumber: 37,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
      lineNumber: 32,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:42:6", "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx", "data-component-line": "42", "data-component-file": "PipelineStage.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22mb-4%20space-y-1%22%7D", className: "mb-4 space-y-1", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:43:8", "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx", "data-component-line": "43", "data-component-file": "PipelineStage.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20justify-between%20text-xs%22%7D", className: "flex justify-between text-xs", children: [
        /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:44:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx", "data-component-line": "44", "data-component-file": "PipelineStage.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-text-secondary%22%2C%22textContent%22%3A%22Total%3A%22%7D", className: "text-text-secondary", children: "Total:" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
          lineNumber: 44,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:45:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx", "data-component-line": "45", "data-component-file": "PipelineStage.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22font-medium%20text-text-primary%22%2C%22textContent%22%3A%22%24%20K%22%7D", className: "font-medium text-text-primary", children: [
          "$",
          (totalValue / 1e3)?.toFixed(0),
          "K"
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
          lineNumber: 45,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
        lineNumber: 43,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:49:8", "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx", "data-component-line": "49", "data-component-file": "PipelineStage.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20justify-between%20text-xs%22%7D", className: "flex justify-between text-xs", children: [
        /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:50:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx", "data-component-line": "50", "data-component-file": "PipelineStage.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-text-secondary%22%2C%22textContent%22%3A%22Weighted%3A%22%7D", className: "text-text-secondary", children: "Weighted:" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
          lineNumber: 50,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:51:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx", "data-component-line": "51", "data-component-file": "PipelineStage.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22font-medium%20text-text-primary%22%2C%22textContent%22%3A%22%24%20K%22%7D", className: "font-medium text-text-primary", children: [
          "$",
          (weightedValue / 1e3)?.toFixed(0),
          "K"
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
          lineNumber: 51,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
        lineNumber: 49,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
      lineNumber: 42,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Droppable, { "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:57:6", "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx", "data-component-line": "57", "data-component-file": "PipelineStage.jsx", "data-component-name": "Droppable", "data-component-content": "%7B%22elementName%22%3A%22Droppable%22%7D", droppableId: stage?.id, children: (provided, snapshot) => /* @__PURE__ */ jsxDEV(
      "div",
      {
        "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:59:8",
        "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx",
        "data-component-line": "59",
        "data-component-file": "PipelineStage.jsx",
        "data-component-name": "div",
        "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22%5Bspread%5D%22%3A%22true%22%7D",
        ref: provided?.innerRef,
        ...provided?.droppableProps,
        className: `min-h-[200px] space-y-3 ${snapshot?.isDraggingOver ? "bg-primary-50 border-primary-300" : ""}`,
        children: [
          stage?.deals?.map(
            (deal, index) => /* @__PURE__ */ jsxDEV(Draggable, { "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:67:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx", "data-component-line": "67", "data-component-file": "PipelineStage.jsx", "data-component-name": "Draggable", "data-component-content": "%7B%22elementName%22%3A%22Draggable%22%7D", draggableId: deal?.id, index, children: (provided2, snapshot2) => /* @__PURE__ */ jsxDEV(
              "div",
              {
                "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:69:12",
                "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx",
                "data-component-line": "69",
                "data-component-file": "PipelineStage.jsx",
                "data-component-name": "div",
                "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22%5Bspread%5D%22%3A%22true%22%7D",
                ref: provided2?.innerRef,
                ...provided2?.draggableProps,
                ...provided2?.dragHandleProps,
                className: `bg-surface rounded-lg p-3 border border-border shadow-sm cursor-move transition-all duration-150 hover:shadow-md ${snapshot2?.isDragging ? "rotate-2 shadow-lg" : ""}`,
                children: [
                  /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:78:20", "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx", "data-component-line": "78", "data-component-file": "PipelineStage.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-start%20justify-between%20mb-2%22%7D", className: "flex items-start justify-between mb-2", children: [
                    /* @__PURE__ */ jsxDEV("h4", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:79:22", "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx", "data-component-line": "79", "data-component-file": "PipelineStage.jsx", "data-component-name": "h4", "data-component-content": "%7B%22elementName%22%3A%22h4%22%2C%22className%22%3A%22text-sm%20font-medium%20text-text-primary%20line-clamp-2%22%7D", className: "text-sm font-medium text-text-primary line-clamp-2", children: deal?.title }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
                      lineNumber: 79,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:82:22", "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx", "data-component-line": "82", "data-component-file": "PipelineStage.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22GripVertical%22%2C%22className%22%3A%22text-text-tertiary%20mt-1%22%7D", name: "GripVertical", size: 14, className: "text-text-tertiary mt-1" }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
                      lineNumber: 82,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
                    lineNumber: 78,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:86:20", "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx", "data-component-line": "86", "data-component-file": "PipelineStage.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%20mb-2%22%7D", className: "flex items-center justify-between mb-2", children: [
                    /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:87:22", "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx", "data-component-line": "87", "data-component-file": "PipelineStage.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%2C%22textContent%22%3A%22%24%20K%22%7D", className: "text-lg font-semibold text-text-primary", children: [
                      "$",
                      (deal?.value / 1e3)?.toFixed(0),
                      "K"
                    ] }, void 0, true, {
                      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
                      lineNumber: 87,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:90:22", "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx", "data-component-line": "90", "data-component-file": "PipelineStage.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-xs%20px-2%20py-1%20bg-primary-50%20text-primary%20rounded-full%22%2C%22textContent%22%3A%22%25%22%7D", className: "text-xs px-2 py-1 bg-primary-50 text-primary rounded-full", children: [
                      deal?.probability,
                      "%"
                    ] }, void 0, true, {
                      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
                      lineNumber: 90,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
                    lineNumber: 86,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:96:20", "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx", "data-component-line": "96", "data-component-file": "PipelineStage.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%20mb-2%22%7D", className: "flex items-center space-x-2 mb-2", children: [
                    /* @__PURE__ */ jsxDEV(
                      Image,
                      {
                        "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:97:22",
                        "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx",
                        "data-component-line": "97",
                        "data-component-file": "PipelineStage.jsx",
                        "data-component-name": "Image",
                        "data-component-content": "%7B%22elementName%22%3A%22Image%22%2C%22className%22%3A%22w-6%20h-6%20rounded-full%20object-cover%22%7D",
                        src: deal?.avatar,
                        alt: deal?.contact,
                        className: "w-6 h-6 rounded-full object-cover"
                      },
                      void 0,
                      false,
                      {
                        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
                        lineNumber: 97,
                        columnNumber: 23
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:102:22", "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx", "data-component-line": "102", "data-component-file": "PipelineStage.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex-1%20min-w-0%22%7D", className: "flex-1 min-w-0", children: [
                      /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:103:24", "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx", "data-component-line": "103", "data-component-file": "PipelineStage.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-xs%20font-medium%20text-text-primary%20truncate%22%7D", className: "text-xs font-medium text-text-primary truncate", children: deal?.contact }, void 0, false, {
                        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
                        lineNumber: 103,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:106:24", "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx", "data-component-line": "106", "data-component-file": "PipelineStage.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-xs%20text-text-secondary%20truncate%22%7D", className: "text-xs text-text-secondary truncate", children: deal?.company }, void 0, false, {
                        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
                        lineNumber: 106,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
                      lineNumber: 102,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
                    lineNumber: 96,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:113:20", "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx", "data-component-line": "113", "data-component-file": "PipelineStage.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%20text-xs%20text-text-secondary%22%7D", className: "flex items-center justify-between text-xs text-text-secondary", children: [
                    /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:114:22", "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx", "data-component-line": "114", "data-component-file": "PipelineStage.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22days%20in%20stage%22%7D", children: [
                      deal?.daysInStage,
                      " days in stage"
                    ] }, void 0, true, {
                      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
                      lineNumber: 114,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:115:22", "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx", "data-component-line": "115", "data-component-file": "PipelineStage.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: deal?.lastActivity }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
                      lineNumber: 115,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
                    lineNumber: 113,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
                lineNumber: 69,
                columnNumber: 13
              },
              this
            ) }, deal?.id, false, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
              lineNumber: 67,
              columnNumber: 11
            }, this)
          ),
          provided?.placeholder,
          stage?.deals?.length === 0 && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:125:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx", "data-component-line": "125", "data-component-file": "PipelineStage.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20flex-col%20items-center%20justify-center%20py-8%20text-text-tertiary%22%7D", className: "flex flex-col items-center justify-center py-8 text-text-tertiary", children: [
            /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:126:16", "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx", "data-component-line": "126", "data-component-file": "PipelineStage.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Plus%22%2C%22className%22%3A%22mb-2%22%7D", name: "Plus", size: 24, className: "mb-2" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
              lineNumber: 126,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx:127:16", "data-component-path": "src\\pages\\sales-dashboard\\components\\PipelineStage.jsx", "data-component-line": "127", "data-component-file": "PipelineStage.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-xs%22%2C%22textContent%22%3A%22Drop%20deals%20here%22%7D", className: "text-xs", children: "Drop deals here" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
              lineNumber: 127,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
            lineNumber: 125,
            columnNumber: 11
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
        lineNumber: 59,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
      lineNumber: 57,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx",
    lineNumber: 30,
    columnNumber: 5
  }, this);
};
_c = PipelineStage;
export default PipelineStage;
var _c;
$RefreshReg$(_c, "PipelineStage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/sales-dashboard/components/PipelineStage.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUNVO0FBakNWLE9BQU9BLG9CQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN6QixTQUFTQyxXQUFXQyxpQkFBaUI7QUFDckMsT0FBT0MsVUFBVTtBQUNqQixPQUFPQyxXQUFXO0FBRWxCLE1BQU1DLGdCQUFnQkEsQ0FBQyxFQUFFQyxPQUFPQyxZQUFZQyxjQUFjLE1BQU07QUFDOUQsUUFBTUMsZ0JBQWdCQSxDQUFDQyxZQUFZO0FBQ2pDLFVBQU1DLFNBQVM7QUFBQSxNQUNiLFFBQVE7QUFBQSxNQUNSLGFBQWE7QUFBQSxNQUNiLFlBQVk7QUFBQSxNQUNaLGVBQWU7QUFBQSxNQUNmLFVBQVU7QUFBQSxJQUNaO0FBQ0EsV0FBT0EsU0FBU0QsT0FBTyxLQUFLO0FBQUEsRUFDOUI7QUFFQSxRQUFNRSxlQUFlQSxDQUFDRixZQUFZO0FBQ2hDLFVBQU1HLFFBQVE7QUFBQSxNQUNaLFFBQVE7QUFBQSxNQUNSLGFBQWE7QUFBQSxNQUNiLFlBQVk7QUFBQSxNQUNaLGVBQWU7QUFBQSxNQUNmLFVBQVU7QUFBQSxJQUNaO0FBQ0EsV0FBT0EsUUFBUUgsT0FBTyxLQUFLO0FBQUEsRUFDN0I7QUFFQSxTQUNFLHVCQUFDLDhWQUFJLFdBQVcseUNBQXlDRCxjQUFjSCxPQUFPUSxFQUFFLENBQUMsSUFFL0U7QUFBQSwyQkFBQyxxYUFBSSxXQUFVLDBDQUNiO0FBQUEsNkJBQUMsd1pBQUksV0FBVSwrQkFDYjtBQUFBLCtCQUFDLDhZQUFLLE1BQU1GLGFBQWFOLE9BQU9RLEVBQUUsR0FBRyxNQUFNLElBQUksV0FBVSx5QkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4RTtBQUFBLFFBQzlFLHVCQUFDLHNaQUFHLFdBQVUsaUNBQWlDUixpQkFBT1MsU0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RDtBQUFBLFdBRjlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsdWFBQUssV0FBVSwyQ0FDYlQsaUJBQU9VLE9BQU9DLFVBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsSUFFQSx1QkFBQyx5WUFBSSxXQUFVLGtCQUNiO0FBQUEsNkJBQUMseVpBQUksV0FBVSxnQ0FDYjtBQUFBLCtCQUFDLHFiQUFLLFdBQVUsdUJBQXNCLHNCQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRDO0FBQUEsUUFDNUMsdUJBQUMsZ2NBQUssV0FBVSxpQ0FBZ0M7QUFBQTtBQUFBLFdBQzNDVixhQUFhLE1BQU9XLFFBQVEsQ0FBQztBQUFBLFVBQUU7QUFBQSxhQURwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0EsdUJBQUMseVpBQUksV0FBVSxnQ0FDYjtBQUFBLCtCQUFDLHdiQUFLLFdBQVUsdUJBQXNCLHlCQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStDO0FBQUEsUUFDL0MsdUJBQUMsZ2NBQUssV0FBVSxpQ0FBZ0M7QUFBQTtBQUFBLFdBQzNDVixnQkFBZ0IsTUFBT1UsUUFBUSxDQUFDO0FBQUEsVUFBRTtBQUFBLGFBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsU0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBYUE7QUFBQSxJQUVBLHVCQUFDLDhXQUFVLGFBQWFaLE9BQU9RLElBQzVCLFdBQUNLLFVBQVVDLGFBQ1Y7QUFBQSxNQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUNDLEtBQUtELFVBQVVFO0FBQUFBLFFBQ2YsR0FBSUYsVUFBVUc7QUFBQUEsUUFDZCxXQUFXLDJCQUNURixVQUFVRyxpQkFBaUIscUNBQXFDLEVBQUU7QUFBQSxRQUduRWpCO0FBQUFBLGlCQUFPVSxPQUFPUTtBQUFBQSxZQUFJLENBQUNDLE1BQU1DLFVBQ3hCLHVCQUFDLCtXQUF5QixhQUFhRCxNQUFNWCxJQUFJLE9BQzlDLFdBQUNLLFdBQVVDLGNBQ1Y7QUFBQSxjQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFDQyxLQUFLRCxXQUFVRTtBQUFBQSxnQkFDZixHQUFJRixXQUFVUTtBQUFBQSxnQkFDZCxHQUFJUixXQUFVUztBQUFBQSxnQkFDZCxXQUFXLG9IQUNUUixXQUFVUyxhQUFhLHVCQUF1QixFQUFFO0FBQUEsZ0JBSWxEO0FBQUEseUNBQUMscWFBQUksV0FBVSx5Q0FDYjtBQUFBLDJDQUFDLCthQUFHLFdBQVUsc0RBQ1hKLGdCQUFNVixTQURUO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxzYkFBSyxNQUFLLGdCQUFlLE1BQU0sSUFBSSxXQUFVLDZCQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF1RTtBQUFBLHVCQUp6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUtBO0FBQUEsa0JBR0EsdUJBQUMsc2FBQUksV0FBVSwwQ0FDYjtBQUFBLDJDQUFDLDRjQUFLLFdBQVUsMkNBQTBDO0FBQUE7QUFBQSx1QkFDckRVLE1BQU1LLFFBQVEsTUFBT1osUUFBUSxDQUFDO0FBQUEsc0JBQUU7QUFBQSx5QkFEckM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLGdlQUFLLFdBQVUsNkRBQ2JPO0FBQUFBLDRCQUFNTTtBQUFBQSxzQkFBWTtBQUFBLHlCQURyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFPQTtBQUFBLGtCQUdBLHVCQUFDLGdhQUFJLFdBQVUsb0NBQ2I7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFDQyxLQUFLTixNQUFNTztBQUFBQSx3QkFDWCxLQUFLUCxNQUFNUTtBQUFBQSx3QkFDWCxXQUFVO0FBQUE7QUFBQSxzQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBRytDO0FBQUEsb0JBRS9DLHVCQUFDLDRZQUFJLFdBQVUsa0JBQ2I7QUFBQSw2Q0FBQywwYUFBRSxXQUFVLGtEQUNWUixnQkFBTVEsV0FEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsOFpBQUUsV0FBVSx3Q0FDVlIsZ0JBQU1TLFdBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBT0E7QUFBQSx1QkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWNBO0FBQUEsa0JBR0EsdUJBQUMsaWNBQUksV0FBVSxpRUFDYjtBQUFBLDJDQUFDLGtaQUFNVDtBQUFBQSw0QkFBTVU7QUFBQUEsc0JBQVk7QUFBQSx5QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBdUM7QUFBQSxvQkFDdkMsdUJBQUMsb1dBQU1WLGdCQUFNVyxnQkFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUEwQjtBQUFBLHVCQUY1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUE7QUFBQTtBQUFBLGNBL0NGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWdEQSxLQWxEWVgsTUFBTVgsSUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFvREE7QUFBQSxVQUNEO0FBQUEsVUFDQUssVUFBVWtCO0FBQUFBLFVBR1YvQixPQUFPVSxPQUFPQyxXQUFXLEtBQ3hCLHVCQUFDLHVjQUFJLFdBQVUscUVBQ2I7QUFBQSxtQ0FBQywyWkFBSyxNQUFLLFFBQU8sTUFBTSxJQUFJLFdBQVUsVUFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEM7QUFBQSxZQUM1Qyx1QkFBQyxzYkFBSyxXQUFVLFdBQVUsK0JBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlDO0FBQUEsZUFGM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBO0FBQUE7QUFBQSxNQXJFSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUF1RUEsS0F6RUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJFQTtBQUFBLE9BdEdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1R0E7QUFFSjtBQUFFcUIsS0FqSUlqQztBQW1JTixlQUFlQTtBQUFjLElBQUFpQztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJEcm9wcGFibGUiLCJEcmFnZ2FibGUiLCJJY29uIiwiSW1hZ2UiLCJQaXBlbGluZVN0YWdlIiwic3RhZ2UiLCJ0b3RhbFZhbHVlIiwid2VpZ2h0ZWRWYWx1ZSIsImdldFN0YWdlQ29sb3IiLCJzdGFnZUlkIiwiY29sb3JzIiwiZ2V0U3RhZ2VJY29uIiwiaWNvbnMiLCJpZCIsInRpdGxlIiwiZGVhbHMiLCJsZW5ndGgiLCJ0b0ZpeGVkIiwicHJvdmlkZWQiLCJzbmFwc2hvdCIsImlubmVyUmVmIiwiZHJvcHBhYmxlUHJvcHMiLCJpc0RyYWdnaW5nT3ZlciIsIm1hcCIsImRlYWwiLCJpbmRleCIsImRyYWdnYWJsZVByb3BzIiwiZHJhZ0hhbmRsZVByb3BzIiwiaXNEcmFnZ2luZyIsInZhbHVlIiwicHJvYmFiaWxpdHkiLCJhdmF0YXIiLCJjb250YWN0IiwiY29tcGFueSIsImRheXNJblN0YWdlIiwibGFzdEFjdGl2aXR5IiwicGxhY2Vob2xkZXIiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlBpcGVsaW5lU3RhZ2UuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IERyb3BwYWJsZSwgRHJhZ2dhYmxlIH0gZnJvbSAncmVhY3QtYmVhdXRpZnVsLWRuZCc7XHJcbmltcG9ydCBJY29uIGZyb20gJ2NvbXBvbmVudHMvQXBwSWNvbic7XHJcbmltcG9ydCBJbWFnZSBmcm9tICdjb21wb25lbnRzL0FwcEltYWdlJztcclxuXHJcbmNvbnN0IFBpcGVsaW5lU3RhZ2UgPSAoeyBzdGFnZSwgdG90YWxWYWx1ZSwgd2VpZ2h0ZWRWYWx1ZSB9KSA9PiB7XHJcbiAgY29uc3QgZ2V0U3RhZ2VDb2xvciA9IChzdGFnZUlkKSA9PiB7XHJcbiAgICBjb25zdCBjb2xvcnMgPSB7XHJcbiAgICAgICdsZWFkJzogJ2JnLWdyYXktMTAwIGJvcmRlci1ncmF5LTMwMCcsXHJcbiAgICAgICdxdWFsaWZpZWQnOiAnYmctYmx1ZS01MCBib3JkZXItYmx1ZS0zMDAnLFxyXG4gICAgICAncHJvcG9zYWwnOiAnYmcteWVsbG93LTUwIGJvcmRlci15ZWxsb3ctMzAwJyxcclxuICAgICAgJ25lZ290aWF0aW9uJzogJ2JnLW9yYW5nZS01MCBib3JkZXItb3JhbmdlLTMwMCcsXHJcbiAgICAgICdjbG9zZWQnOiAnYmctZ3JlZW4tNTAgYm9yZGVyLWdyZWVuLTMwMCdcclxuICAgIH07XHJcbiAgICByZXR1cm4gY29sb3JzPy5bc3RhZ2VJZF0gfHwgJ2JnLWdyYXktMTAwIGJvcmRlci1ncmF5LTMwMCc7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZ2V0U3RhZ2VJY29uID0gKHN0YWdlSWQpID0+IHtcclxuICAgIGNvbnN0IGljb25zID0ge1xyXG4gICAgICAnbGVhZCc6ICdVc2VyUGx1cycsXHJcbiAgICAgICdxdWFsaWZpZWQnOiAnQ2hlY2tDaXJjbGUnLFxyXG4gICAgICAncHJvcG9zYWwnOiAnRmlsZVRleHQnLFxyXG4gICAgICAnbmVnb3RpYXRpb24nOiAnTWVzc2FnZVNxdWFyZScsXHJcbiAgICAgICdjbG9zZWQnOiAnVHJvcGh5J1xyXG4gICAgfTtcclxuICAgIHJldHVybiBpY29ucz8uW3N0YWdlSWRdIHx8ICdDaXJjbGUnO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT17YHJvdW5kZWQtbGcgYm9yZGVyLTIgYm9yZGVyLWRhc2hlZCBwLTQgJHtnZXRTdGFnZUNvbG9yKHN0YWdlPy5pZCl9YH0+XHJcbiAgICAgIHsvKiBTdGFnZSBIZWFkZXIgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTRcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMlwiPlxyXG4gICAgICAgICAgPEljb24gbmFtZT17Z2V0U3RhZ2VJY29uKHN0YWdlPy5pZCl9IHNpemU9ezE2fSBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5XCIgLz5cclxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeVwiPntzdGFnZT8udGl0bGV9PC9oMz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1zZWNvbmRhcnlcIj5cclxuICAgICAgICAgIHtzdGFnZT8uZGVhbHM/Lmxlbmd0aH1cclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICB7LyogU3RhZ2UgTWV0cmljcyAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00IHNwYWNlLXktMVwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC14c1wiPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC10ZXh0LXNlY29uZGFyeVwiPlRvdGFsOjwvc3Bhbj5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5XCI+XHJcbiAgICAgICAgICAgICR7KHRvdGFsVmFsdWUgLyAxMDAwKT8udG9GaXhlZCgwKX1LXHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+V2VpZ2h0ZWQ6PC9zcGFuPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnlcIj5cclxuICAgICAgICAgICAgJHsod2VpZ2h0ZWRWYWx1ZSAvIDEwMDApPy50b0ZpeGVkKDApfUtcclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIHsvKiBEcm9wcGFibGUgQXJlYSAqL31cclxuICAgICAgPERyb3BwYWJsZSBkcm9wcGFibGVJZD17c3RhZ2U/LmlkfT5cclxuICAgICAgICB7KHByb3ZpZGVkLCBzbmFwc2hvdCkgPT4gKFxyXG4gICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICByZWY9e3Byb3ZpZGVkPy5pbm5lclJlZn1cclxuICAgICAgICAgICAgey4uLnByb3ZpZGVkPy5kcm9wcGFibGVQcm9wc31cclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgbWluLWgtWzIwMHB4XSBzcGFjZS15LTMgJHtcclxuICAgICAgICAgICAgICBzbmFwc2hvdD8uaXNEcmFnZ2luZ092ZXIgPyAnYmctcHJpbWFyeS01MCBib3JkZXItcHJpbWFyeS0zMDAnIDogJydcclxuICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHtzdGFnZT8uZGVhbHM/Lm1hcCgoZGVhbCwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICA8RHJhZ2dhYmxlIGtleT17ZGVhbD8uaWR9IGRyYWdnYWJsZUlkPXtkZWFsPy5pZH0gaW5kZXg9e2luZGV4fT5cclxuICAgICAgICAgICAgICAgIHsocHJvdmlkZWQsIHNuYXBzaG90KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICByZWY9e3Byb3ZpZGVkPy5pbm5lclJlZn1cclxuICAgICAgICAgICAgICAgICAgICB7Li4ucHJvdmlkZWQ/LmRyYWdnYWJsZVByb3BzfVxyXG4gICAgICAgICAgICAgICAgICAgIHsuLi5wcm92aWRlZD8uZHJhZ0hhbmRsZVByb3BzfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLXN1cmZhY2Ugcm91bmRlZC1sZyBwLTMgYm9yZGVyIGJvcmRlci1ib3JkZXIgc2hhZG93LXNtIGN1cnNvci1tb3ZlIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTE1MCBob3ZlcjpzaGFkb3ctbWQgJHtcclxuICAgICAgICAgICAgICAgICAgICAgIHNuYXBzaG90Py5pc0RyYWdnaW5nID8gJ3JvdGF0ZS0yIHNoYWRvdy1sZycgOiAnJ1xyXG4gICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgey8qIERlYWwgSGVhZGVyICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbGluZS1jbGFtcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtkZWFsPy50aXRsZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvaDQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiR3JpcFZlcnRpY2FsXCIgc2l6ZT17MTR9IGNsYXNzTmFtZT1cInRleHQtdGV4dC10ZXJ0aWFyeSBtdC0xXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIERlYWwgVmFsdWUgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtdGV4dC1wcmltYXJ5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICR7KGRlYWw/LnZhbHVlIC8gMTAwMCk/LnRvRml4ZWQoMCl9S1xyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBweC0yIHB5LTEgYmctcHJpbWFyeS01MCB0ZXh0LXByaW1hcnkgcm91bmRlZC1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtkZWFsPy5wcm9iYWJpbGl0eX0lXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBDb250YWN0IEluZm8gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTIgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEltYWdlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17ZGVhbD8uYXZhdGFyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhbHQ9e2RlYWw/LmNvbnRhY3R9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNiBoLTYgcm91bmRlZC1mdWxsIG9iamVjdC1jb3ZlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbWluLXctMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IHRydW5jYXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2RlYWw/LmNvbnRhY3R9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXRleHQtc2Vjb25kYXJ5IHRydW5jYXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2RlYWw/LmNvbXBhbnl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogRGVhbCBNZXRhZGF0YSAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LXhzIHRleHQtdGV4dC1zZWNvbmRhcnlcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntkZWFsPy5kYXlzSW5TdGFnZX0gZGF5cyBpbiBzdGFnZTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntkZWFsPy5sYXN0QWN0aXZpdHl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9EcmFnZ2FibGU+XHJcbiAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICB7cHJvdmlkZWQ/LnBsYWNlaG9sZGVyfVxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgey8qIEVtcHR5IFN0YXRlICovfVxyXG4gICAgICAgICAgICB7c3RhZ2U/LmRlYWxzPy5sZW5ndGggPT09IDAgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcHktOCB0ZXh0LXRleHQtdGVydGlhcnlcIj5cclxuICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJQbHVzXCIgc2l6ZT17MjR9IGNsYXNzTmFtZT1cIm1iLTJcIiAvPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14c1wiPkRyb3AgZGVhbHMgaGVyZTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvRHJvcHBhYmxlPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFBpcGVsaW5lU3RhZ2U7Il0sImZpbGUiOiJEOi9jdXJyZW50IHByb2plY3RzL2NsYXVkZS1jb2RlL3NyYy9wYWdlcy9zYWxlcy1kYXNoYm9hcmQvY29tcG9uZW50cy9QaXBlbGluZVN0YWdlLmpzeCJ9