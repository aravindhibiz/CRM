import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/settings-administration/components/EmailTemplates.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import Icon from "/src/components/AppIcon.jsx";
const EmailTemplates = () => {
  _s();
  const [templates, setTemplates] = useState(
    [
      {
        id: 1,
        name: "Welcome Email",
        subject: "Welcome to {{company_name}}!",
        category: "onboarding",
        status: "active",
        lastModified: "2024-01-15",
        usage: 45,
        content: "Hello {{first_name}},\n\nWelcome to {{company_name}}! We're excited to have you on board.\n\nBest regards,\n{{sender_name}}"
      },
      {
        id: 2,
        name: "Follow-up After Meeting",
        subject: "Great meeting with you today!",
        category: "followup",
        status: "active",
        lastModified: "2024-01-12",
        usage: 78,
        content: "Hi {{first_name}},\n\nThank you for taking the time to meet with us today. As discussed, I'm attaching the proposal for your review.\n\nPlease let me know if you have any questions.\n\nBest regards,\n{{sender_name}}"
      },
      {
        id: 3,
        name: "Deal Closed Won",
        subject: "Congratulations! Welcome aboard!",
        category: "closing",
        status: "draft",
        lastModified: "2024-01-10",
        usage: 12,
        content: "Dear {{first_name}},\n\nCongratulations! We're thrilled to welcome you as our newest client.\n\nNext steps:\n- You'll receive your welcome packet within 24 hours\n- Our onboarding team will contact you shortly\n\nThank you for choosing {{company_name}}!\n\n{{sender_name}}"
      }
    ]
  );
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [showTemplateModal, setShowTemplateModal] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState(null);
  const [templateForm, setTemplateForm] = useState({
    name: "",
    subject: "",
    category: "general",
    content: ""
  });
  const categories = [
    { value: "general", label: "General" },
    { value: "onboarding", label: "Onboarding" },
    { value: "followup", label: "Follow-up" },
    { value: "closing", label: "Deal Closing" },
    { value: "nurturing", label: "Lead Nurturing" },
    { value: "reminder", label: "Reminders" }
  ];
  const mergeFields = [
    { field: "{{first_name}}", description: "Contact first name" },
    { field: "{{last_name}}", description: "Contact last name" },
    { field: "{{full_name}}", description: "Contact full name" },
    { field: "{{email}}", description: "Contact email address" },
    { field: "{{company_name}}", description: "Contact company name" },
    { field: "{{phone}}", description: "Contact phone number" },
    { field: "{{deal_name}}", description: "Deal title" },
    { field: "{{deal_value}}", description: "Deal value" },
    { field: "{{sender_name}}", description: "Your name" },
    { field: "{{sender_email}}", description: "Your email" },
    { field: "{{current_date}}", description: "Current date" }
  ];
  const handleCreateTemplate = () => {
    setEditingTemplate(null);
    setTemplateForm({
      name: "",
      subject: "",
      category: "general",
      content: ""
    });
    setShowTemplateModal(true);
  };
  const handleEditTemplate = (template) => {
    setEditingTemplate(template);
    setTemplateForm({
      name: template?.name,
      subject: template?.subject,
      category: template?.category,
      content: template?.content
    });
    setShowTemplateModal(true);
  };
  const handleDeleteTemplate = (templateId) => {
    setTemplates((prev) => prev?.filter((template) => template?.id !== templateId));
  };
  const handleSaveTemplate = (e) => {
    e?.preventDefault();
    if (editingTemplate) {
      setTemplates(
        (prev) => prev?.map(
          (template) => template?.id === editingTemplate?.id ? {
            ...template,
            ...templateForm,
            lastModified: (/* @__PURE__ */ new Date())?.toISOString()?.split("T")?.[0],
            status: template?.status === "draft" ? "draft" : "active"
          } : template
        )
      );
    } else {
      const newTemplate = {
        id: Date.now(),
        ...templateForm,
        status: "draft",
        lastModified: (/* @__PURE__ */ new Date())?.toISOString()?.split("T")?.[0],
        usage: 0
      };
      setTemplates((prev) => [...prev, newTemplate]);
    }
    setShowTemplateModal(false);
    setEditingTemplate(null);
  };
  const handlePreviewTemplate = (template) => {
    setSelectedTemplate(template);
    setShowPreview(true);
  };
  const insertMergeField = (field) => {
    const textarea = document.getElementById("template-content");
    const start = textarea?.selectionStart;
    const end = textarea?.selectionEnd;
    const text = templateForm?.content;
    const before = text?.substring(0, start);
    const after = text?.substring(end, text?.length);
    const newContent = before + field + after;
    setTemplateForm((prev) => ({ ...prev, content: newContent }));
    setTimeout(() => {
      textarea?.focus();
      textarea?.setSelectionRange(start + field?.length, start + field?.length);
    }, 0);
  };
  const getStatusBadge = (status) => {
    const statusStyles = {
      active: "bg-success-50 text-success-600 border-success-100",
      draft: "bg-warning-50 text-warning-600 border-warning-100",
      inactive: "bg-error-50 text-error-600 border-error-100"
    };
    return /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:161:6", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "161", "data-component-file": "EmailTemplates.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", className: `px-2 py-1 text-xs font-medium rounded border ${statusStyles?.[status] || "bg-gray-50 text-gray-600 border-gray-100"}`, children: status?.charAt(0)?.toUpperCase() + status?.slice(1) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
      lineNumber: 161,
      columnNumber: 7
    }, this);
  };
  const getCategoryBadge = (category) => {
    const categoryObj = categories?.find((c) => c?.value === category);
    return /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:170:6", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "170", "data-component-file": "EmailTemplates.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22px-2%20py-1%20text-xs%20bg-primary-50%20text-primary%20border%20border-primary-100%20rounded%22%7D", className: "px-2 py-1 text-xs bg-primary-50 text-primary border border-primary-100 rounded", children: categoryObj?.label || category }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
      lineNumber: 170,
      columnNumber: 7
    }, this);
  };
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:177:4", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "177", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-6%22%7D", className: "space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:179:6", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "179", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:180:8", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "180", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
        /* @__PURE__ */ jsxDEV("h2", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:181:10", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "181", "data-component-file": "EmailTemplates.jsx", "data-component-name": "h2", "data-component-content": "%7B%22elementName%22%3A%22h2%22%2C%22className%22%3A%22text-2xl%20font-bold%20text-text-primary%22%2C%22textContent%22%3A%22Email%20Templates%22%7D", className: "text-2xl font-bold text-text-primary", children: "Email Templates" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
          lineNumber: 181,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:182:10", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "182", "data-component-file": "EmailTemplates.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20mt-1%22%2C%22textContent%22%3A%22Create%20and%20manage%20email%20templates%20with%20merge%20fields%22%7D", className: "text-text-secondary mt-1", children: "Create and manage email templates with merge fields" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
          lineNumber: 182,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
        lineNumber: 180,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:184:8",
          "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx",
          "data-component-line": "184",
          "data-component-file": "EmailTemplates.jsx",
          "data-component-name": "button",
          "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22bg-primary%20text-white%20px-4%20py-2%20rounded-lg%20hover%3Abg-primary-600%20transition-colors%20duration-150%20ease-smooth%20flex%20items-center%20space-x-2%22%7D",
          onClick: handleCreateTemplate,
          className: "bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary-600 transition-colors duration-150 ease-smooth flex items-center space-x-2",
          children: [
            /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:188:10", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "188", "data-component-file": "EmailTemplates.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Plus%22%7D", name: "Plus", size: 16 }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
              lineNumber: 188,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:189:10", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "189", "data-component-file": "EmailTemplates.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Create%20Template%22%7D", children: "Create Template" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
              lineNumber: 189,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
          lineNumber: 184,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
      lineNumber: 179,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:193:6", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "193", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20rounded-lg%20border%20border-border%20overflow-hidden%22%7D", className: "bg-surface rounded-lg border border-border overflow-hidden", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:194:8", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "194", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22overflow-x-auto%22%7D", className: "overflow-x-auto", children: /* @__PURE__ */ jsxDEV("table", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:195:10", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "195", "data-component-file": "EmailTemplates.jsx", "data-component-name": "table", "data-component-content": "%7B%22elementName%22%3A%22table%22%2C%22className%22%3A%22w-full%22%7D", className: "w-full", children: [
      /* @__PURE__ */ jsxDEV("thead", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:196:12", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "196", "data-component-file": "EmailTemplates.jsx", "data-component-name": "thead", "data-component-content": "%7B%22elementName%22%3A%22thead%22%2C%22className%22%3A%22bg-background%20border-b%20border-border%22%7D", className: "bg-background border-b border-border", children: /* @__PURE__ */ jsxDEV("tr", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:197:14", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "197", "data-component-file": "EmailTemplates.jsx", "data-component-name": "tr", "data-component-content": "%7B%22elementName%22%3A%22tr%22%7D", children: [
        /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:198:16", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "198", "data-component-file": "EmailTemplates.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22text-left%20py-3%20px-4%20text-sm%20font-medium%20text-text-primary%22%2C%22textContent%22%3A%22Template%20Name%22%7D", className: "text-left py-3 px-4 text-sm font-medium text-text-primary", children: "Template Name" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
          lineNumber: 198,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:199:16", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "199", "data-component-file": "EmailTemplates.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22text-left%20py-3%20px-4%20text-sm%20font-medium%20text-text-primary%22%2C%22textContent%22%3A%22Subject%22%7D", className: "text-left py-3 px-4 text-sm font-medium text-text-primary", children: "Subject" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
          lineNumber: 199,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:200:16", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "200", "data-component-file": "EmailTemplates.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22text-left%20py-3%20px-4%20text-sm%20font-medium%20text-text-primary%22%2C%22textContent%22%3A%22Category%22%7D", className: "text-left py-3 px-4 text-sm font-medium text-text-primary", children: "Category" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
          lineNumber: 200,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:201:16", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "201", "data-component-file": "EmailTemplates.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22text-left%20py-3%20px-4%20text-sm%20font-medium%20text-text-primary%22%2C%22textContent%22%3A%22Status%22%7D", className: "text-left py-3 px-4 text-sm font-medium text-text-primary", children: "Status" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
          lineNumber: 201,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:202:16", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "202", "data-component-file": "EmailTemplates.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22text-left%20py-3%20px-4%20text-sm%20font-medium%20text-text-primary%22%2C%22textContent%22%3A%22Usage%22%7D", className: "text-left py-3 px-4 text-sm font-medium text-text-primary", children: "Usage" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
          lineNumber: 202,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:203:16", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "203", "data-component-file": "EmailTemplates.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22text-left%20py-3%20px-4%20text-sm%20font-medium%20text-text-primary%22%2C%22textContent%22%3A%22Modified%22%7D", className: "text-left py-3 px-4 text-sm font-medium text-text-primary", children: "Modified" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
          lineNumber: 203,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:204:16", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "204", "data-component-file": "EmailTemplates.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22text-left%20py-3%20px-4%20text-sm%20font-medium%20text-text-primary%22%2C%22textContent%22%3A%22Actions%22%7D", className: "text-left py-3 px-4 text-sm font-medium text-text-primary", children: "Actions" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
          lineNumber: 204,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
        lineNumber: 197,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
        lineNumber: 196,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("tbody", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:207:12", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "207", "data-component-file": "EmailTemplates.jsx", "data-component-name": "tbody", "data-component-content": "%7B%22elementName%22%3A%22tbody%22%7D", children: templates?.map(
        (template) => /* @__PURE__ */ jsxDEV("tr", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:209:14", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "209", "data-component-file": "EmailTemplates.jsx", "data-component-name": "tr", "data-component-content": "%7B%22elementName%22%3A%22tr%22%2C%22className%22%3A%22border-b%20border-border%20hover%3Abg-surface-hover%22%7D", className: "border-b border-border hover:bg-surface-hover", children: [
          /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:210:18", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "210", "data-component-file": "EmailTemplates.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22py-3%20px-4%22%7D", className: "py-3 px-4", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:211:20", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "211", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%22%7D", className: "flex items-center space-x-2", children: [
            /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:212:22", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "212", "data-component-file": "EmailTemplates.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Mail%22%2C%22className%22%3A%22text-text-tertiary%22%7D", name: "Mail", size: 16, className: "text-text-tertiary" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
              lineNumber: 212,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:213:22", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "213", "data-component-file": "EmailTemplates.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22font-medium%20text-text-primary%22%7D", className: "font-medium text-text-primary", children: template?.name }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
              lineNumber: 213,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
            lineNumber: 211,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
            lineNumber: 210,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:216:18", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "216", "data-component-file": "EmailTemplates.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22py-3%20px-4%20text-sm%20text-text-secondary%20max-w-xs%20truncate%22%7D", className: "py-3 px-4 text-sm text-text-secondary max-w-xs truncate", children: template?.subject }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
            lineNumber: 216,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:217:18", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "217", "data-component-file": "EmailTemplates.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22py-3%20px-4%22%7D", className: "py-3 px-4", children: getCategoryBadge(template?.category) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
            lineNumber: 217,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:218:18", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "218", "data-component-file": "EmailTemplates.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22py-3%20px-4%22%7D", className: "py-3 px-4", children: getStatusBadge(template?.status) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
            lineNumber: 218,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:219:18", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "219", "data-component-file": "EmailTemplates.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22py-3%20px-4%20text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22times%22%7D", className: "py-3 px-4 text-sm text-text-secondary", children: [
            template?.usage,
            " times"
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
            lineNumber: 219,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:220:18", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "220", "data-component-file": "EmailTemplates.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22py-3%20px-4%20text-sm%20text-text-secondary%22%7D", className: "py-3 px-4 text-sm text-text-secondary", children: template?.lastModified }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
            lineNumber: 220,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:221:18", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "221", "data-component-file": "EmailTemplates.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22py-3%20px-4%22%7D", className: "py-3 px-4", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:222:20", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "222", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20space-x-2%22%7D", className: "flex space-x-2", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:223:22",
                "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx",
                "data-component-line": "223",
                "data-component-file": "EmailTemplates.jsx",
                "data-component-name": "button",
                "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22p-1%20text-text-secondary%20hover%3Atext-primary%20transition-colors%20duration-150%22%7D",
                onClick: () => handlePreviewTemplate(template),
                className: "p-1 text-text-secondary hover:text-primary transition-colors duration-150",
                title: "Preview",
                children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:228:24", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "228", "data-component-file": "EmailTemplates.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Eye%22%7D", name: "Eye", size: 16 }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
                  lineNumber: 228,
                  columnNumber: 25
                }, this)
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
                lineNumber: 223,
                columnNumber: 23
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:230:22",
                "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx",
                "data-component-line": "230",
                "data-component-file": "EmailTemplates.jsx",
                "data-component-name": "button",
                "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22p-1%20text-text-secondary%20hover%3Atext-primary%20transition-colors%20duration-150%22%7D",
                onClick: () => handleEditTemplate(template),
                className: "p-1 text-text-secondary hover:text-primary transition-colors duration-150",
                title: "Edit",
                children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:235:24", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "235", "data-component-file": "EmailTemplates.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Edit3%22%7D", name: "Edit3", size: 16 }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
                  lineNumber: 235,
                  columnNumber: 25
                }, this)
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
                lineNumber: 230,
                columnNumber: 23
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:237:22",
                "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx",
                "data-component-line": "237",
                "data-component-file": "EmailTemplates.jsx",
                "data-component-name": "button",
                "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22p-1%20text-text-secondary%20hover%3Atext-error%20transition-colors%20duration-150%22%7D",
                onClick: () => handleDeleteTemplate(template?.id),
                className: "p-1 text-text-secondary hover:text-error transition-colors duration-150",
                title: "Delete",
                children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:242:24", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "242", "data-component-file": "EmailTemplates.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Trash2%22%7D", name: "Trash2", size: 16 }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
                  lineNumber: 242,
                  columnNumber: 25
                }, this)
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
                lineNumber: 237,
                columnNumber: 23
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
            lineNumber: 222,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
            lineNumber: 221,
            columnNumber: 19
          }, this)
        ] }, template?.id, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
          lineNumber: 209,
          columnNumber: 15
        }, this)
      ) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
        lineNumber: 207,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
      lineNumber: 195,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
      lineNumber: 194,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
      lineNumber: 193,
      columnNumber: 7
    }, this),
    showTemplateModal && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:254:6", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "254", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20z-1200%20overflow-y-auto%22%7D", className: "fixed inset-0 z-1200 overflow-y-auto", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:255:10", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "255", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-center%20min-h-screen%20px-4%22%7D", className: "flex items-center justify-center min-h-screen px-4", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:256:12", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "256", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20bg-black%20bg-opacity-50%22%7D", className: "fixed inset-0 bg-black bg-opacity-50", onClick: () => setShowTemplateModal(false) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
        lineNumber: 256,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:257:12", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "257", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20rounded-lg%20shadow-xl%20max-w-4xl%20w-full%20relative%20z-1300%20max-h-screen%20overflow-y-auto%22%7D", className: "bg-surface rounded-lg shadow-xl max-w-4xl w-full relative z-1300 max-h-screen overflow-y-auto", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:258:14", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "258", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22p-6%22%7D", className: "p-6", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:259:16", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "259", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%20mb-4%22%7D", className: "flex items-center justify-between mb-4", children: [
          /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:260:18", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "260", "data-component-file": "EmailTemplates.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%7D", className: "text-lg font-semibold text-text-primary", children: editingTemplate ? "Edit Template" : "Create New Template" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
            lineNumber: 260,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:263:18",
              "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx",
              "data-component-line": "263",
              "data-component-file": "EmailTemplates.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22text-text-secondary%20hover%3Atext-text-primary%20transition-colors%20duration-150%22%7D",
              onClick: () => setShowTemplateModal(false),
              className: "text-text-secondary hover:text-text-primary transition-colors duration-150",
              children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:267:20", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "267", "data-component-file": "EmailTemplates.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22X%22%7D", name: "X", size: 20 }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
                lineNumber: 267,
                columnNumber: 21
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
              lineNumber: 263,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
          lineNumber: 259,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("form", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:271:16", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "271", "data-component-file": "EmailTemplates.jsx", "data-component-name": "form", "data-component-content": "%7B%22elementName%22%3A%22form%22%2C%22className%22%3A%22space-y-4%22%7D", onSubmit: handleSaveTemplate, className: "space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:272:18", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "272", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20md%3Agrid-cols-2%20gap-4%22%7D", className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:273:20", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "273", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:274:22", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "274", "data-component-file": "EmailTemplates.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Template%20Name%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Template Name" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
                lineNumber: 274,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:275:22",
                  "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx",
                  "data-component-line": "275",
                  "data-component-file": "EmailTemplates.jsx",
                  "data-component-name": "input",
                  "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22text%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
                  type: "text",
                  value: templateForm?.name,
                  onChange: (e) => setTemplateForm((prev) => ({ ...prev, name: e?.target?.value })),
                  className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
                  placeholder: "Enter template name",
                  required: true
                },
                void 0,
                false,
                {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
                  lineNumber: 275,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
              lineNumber: 273,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:285:20", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "285", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:286:22", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "286", "data-component-file": "EmailTemplates.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Category%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Category" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
                lineNumber: 286,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:287:22",
                  "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx",
                  "data-component-line": "287",
                  "data-component-file": "EmailTemplates.jsx",
                  "data-component-name": "select",
                  "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
                  value: templateForm?.category,
                  onChange: (e) => setTemplateForm((prev) => ({ ...prev, category: e?.target?.value })),
                  className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
                  children: categories?.map(
                    (category) => /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:293:22", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "293", "data-component-file": "EmailTemplates.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%7D", value: category?.value, children: category?.label }, category?.value, false, {
                      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
                      lineNumber: 293,
                      columnNumber: 23
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
                  lineNumber: 287,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
              lineNumber: 285,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
            lineNumber: 272,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:299:18", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "299", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:300:20", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "300", "data-component-file": "EmailTemplates.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Subject%20Line%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Subject Line" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
              lineNumber: 300,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:301:20",
                "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx",
                "data-component-line": "301",
                "data-component-file": "EmailTemplates.jsx",
                "data-component-name": "input",
                "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22text%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
                type: "text",
                value: templateForm?.subject,
                onChange: (e) => setTemplateForm((prev) => ({ ...prev, subject: e?.target?.value })),
                className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
                placeholder: "Enter email subject",
                required: true
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
                lineNumber: 301,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
            lineNumber: 299,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:311:18", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "311", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20lg%3Agrid-cols-3%20gap-4%22%7D", className: "grid grid-cols-1 lg:grid-cols-3 gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:312:20", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "312", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22lg%3Acol-span-2%22%7D", className: "lg:col-span-2", children: [
              /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:313:22", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "313", "data-component-file": "EmailTemplates.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Email%20Content%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Email Content" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
                lineNumber: 313,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "textarea",
                {
                  "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:314:22",
                  "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx",
                  "data-component-line": "314",
                  "data-component-file": "EmailTemplates.jsx",
                  "data-component-name": "textarea",
                  "data-component-content": "%7B%22elementName%22%3A%22textarea%22%2C%22id%22%3A%22template-content%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
                  id: "template-content",
                  value: templateForm?.content,
                  onChange: (e) => setTemplateForm((prev) => ({ ...prev, content: e?.target?.value })),
                  className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
                  rows: 12,
                  placeholder: "Enter email content...",
                  required: true
                },
                void 0,
                false,
                {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
                  lineNumber: 314,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
              lineNumber: 312,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:325:20", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "325", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:326:22", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "326", "data-component-file": "EmailTemplates.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Merge%20Fields%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Merge Fields" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
                lineNumber: 326,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:327:22", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "327", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-background%20border%20border-border%20rounded-lg%20p-3%20max-h-80%20overflow-y-auto%22%7D", className: "bg-background border border-border rounded-lg p-3 max-h-80 overflow-y-auto", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:328:24", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "328", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-2%22%7D", className: "space-y-2", children: mergeFields?.map(
                (merge) => /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:330:24",
                    "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx",
                    "data-component-line": "330",
                    "data-component-file": "EmailTemplates.jsx",
                    "data-component-name": "button",
                    "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22button%22%2C%22className%22%3A%22w-full%20text-left%20p-2%20rounded%20hover%3Abg-surface-hover%20transition-colors%20duration-150%20group%22%7D",
                    type: "button",
                    onClick: () => insertMergeField(merge?.field),
                    className: "w-full text-left p-2 rounded hover:bg-surface-hover transition-colors duration-150 group",
                    children: [
                      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:336:30", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "336", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-xs%20font-mono%20text-primary%20group-hover%3Atext-primary-600%22%7D", className: "text-xs font-mono text-primary group-hover:text-primary-600", children: merge?.field }, void 0, false, {
                        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
                        lineNumber: 336,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:339:30", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "339", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-xs%20text-text-tertiary%20mt-1%22%7D", className: "text-xs text-text-tertiary mt-1", children: merge?.description }, void 0, false, {
                        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
                        lineNumber: 339,
                        columnNumber: 31
                      }, this)
                    ]
                  },
                  merge?.field,
                  true,
                  {
                    fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
                    lineNumber: 330,
                    columnNumber: 25
                  },
                  this
                )
              ) }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
                lineNumber: 328,
                columnNumber: 25
              }, this) }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
                lineNumber: 327,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
              lineNumber: 325,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
            lineNumber: 311,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:349:18", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "349", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20justify-end%20space-x-3%20mt-6%22%7D", className: "flex justify-end space-x-3 mt-6", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:350:20",
                "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx",
                "data-component-line": "350",
                "data-component-file": "EmailTemplates.jsx",
                "data-component-name": "button",
                "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22button%22%2C%22className%22%3A%22px-4%20py-2%20text-text-secondary%20hover%3Atext-text-primary%20transition-colors%20duration-150%22%2C%22textContent%22%3A%22Cancel%22%7D",
                type: "button",
                onClick: () => setShowTemplateModal(false),
                className: "px-4 py-2 text-text-secondary hover:text-text-primary transition-colors duration-150",
                children: "Cancel"
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
                lineNumber: 350,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:357:20",
                "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx",
                "data-component-line": "357",
                "data-component-file": "EmailTemplates.jsx",
                "data-component-name": "button",
                "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22submit%22%2C%22className%22%3A%22bg-primary%20text-white%20px-4%20py-2%20rounded-lg%20hover%3Abg-primary-600%20transition-colors%20duration-150%20ease-smooth%22%7D",
                type: "submit",
                className: "bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary-600 transition-colors duration-150 ease-smooth",
                children: editingTemplate ? "Update Template" : "Create Template"
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
                lineNumber: 357,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
            lineNumber: 349,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
          lineNumber: 271,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
        lineNumber: 258,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
        lineNumber: 257,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
      lineNumber: 255,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
      lineNumber: 254,
      columnNumber: 7
    }, this),
    showPreview && selectedTemplate && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:372:6", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "372", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20z-1200%20overflow-y-auto%22%7D", className: "fixed inset-0 z-1200 overflow-y-auto", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:373:10", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "373", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-center%20min-h-screen%20px-4%22%7D", className: "flex items-center justify-center min-h-screen px-4", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:374:12", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "374", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20bg-black%20bg-opacity-50%22%7D", className: "fixed inset-0 bg-black bg-opacity-50", onClick: () => setShowPreview(false) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
        lineNumber: 374,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:375:12", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "375", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20rounded-lg%20shadow-xl%20max-w-2xl%20w-full%20relative%20z-1300%22%7D", className: "bg-surface rounded-lg shadow-xl max-w-2xl w-full relative z-1300", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:376:14", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "376", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22p-6%22%7D", className: "p-6", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:377:16", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "377", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%20mb-4%22%7D", className: "flex items-center justify-between mb-4", children: [
          /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:378:18", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "378", "data-component-file": "EmailTemplates.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%2C%22textContent%22%3A%22Template%20Preview%22%7D", className: "text-lg font-semibold text-text-primary", children: "Template Preview" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
            lineNumber: 378,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:379:18",
              "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx",
              "data-component-line": "379",
              "data-component-file": "EmailTemplates.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22text-text-secondary%20hover%3Atext-text-primary%20transition-colors%20duration-150%22%7D",
              onClick: () => setShowPreview(false),
              className: "text-text-secondary hover:text-text-primary transition-colors duration-150",
              children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:383:20", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "383", "data-component-file": "EmailTemplates.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22X%22%7D", name: "X", size: 20 }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
                lineNumber: 383,
                columnNumber: 21
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
              lineNumber: 379,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
          lineNumber: 377,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:387:16", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "387", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-4%22%7D", className: "space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:388:18", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "388", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:389:20", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "389", "data-component-file": "EmailTemplates.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-secondary%20mb-1%22%2C%22textContent%22%3A%22Subject%3A%22%7D", className: "block text-sm font-medium text-text-secondary mb-1", children: "Subject:" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
              lineNumber: 389,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:390:20", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "390", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-background%20border%20border-border%20rounded-lg%20p-3%20text-text-primary%22%7D", className: "bg-background border border-border rounded-lg p-3 text-text-primary", children: selectedTemplate?.subject }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
              lineNumber: 390,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
            lineNumber: 388,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:395:18", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "395", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:396:20", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "396", "data-component-file": "EmailTemplates.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-secondary%20mb-1%22%2C%22textContent%22%3A%22Content%3A%22%7D", className: "block text-sm font-medium text-text-secondary mb-1", children: "Content:" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
              lineNumber: 396,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:397:20", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "397", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-background%20border%20border-border%20rounded-lg%20p-4%20text-text-primary%20whitespace-pre-wrap%20min-h-40%22%7D", className: "bg-background border border-border rounded-lg p-4 text-text-primary whitespace-pre-wrap min-h-40", children: selectedTemplate?.content }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
              lineNumber: 397,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
            lineNumber: 395,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
          lineNumber: 387,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:403:16", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "403", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20justify-end%20mt-6%22%7D", className: "flex justify-end mt-6", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:404:18",
            "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx",
            "data-component-line": "404",
            "data-component-file": "EmailTemplates.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22bg-primary%20text-white%20px-4%20py-2%20rounded-lg%20hover%3Abg-primary-600%20transition-colors%20duration-150%20ease-smooth%22%2C%22textContent%22%3A%22Close%20Preview%22%7D",
            onClick: () => setShowPreview(false),
            className: "bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary-600 transition-colors duration-150 ease-smooth",
            children: "Close Preview"
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
            lineNumber: 404,
            columnNumber: 19
          },
          this
        ) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
          lineNumber: 403,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
        lineNumber: 376,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
        lineNumber: 375,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
      lineNumber: 373,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
      lineNumber: 372,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:417:6", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "417", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-background%20border%20border-border%20rounded-lg%20p-4%22%7D", className: "bg-background border border-border rounded-lg p-4", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:418:8", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "418", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-start%20space-x-3%22%7D", className: "flex items-start space-x-3", children: [
      /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:419:10", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "419", "data-component-file": "EmailTemplates.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Lightbulb%22%2C%22className%22%3A%22text-primary%20mt-0.5%22%7D", name: "Lightbulb", size: 16, className: "text-primary mt-0.5" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
        lineNumber: 419,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:420:10", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "420", "data-component-file": "EmailTemplates.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex-1%22%7D", className: "flex-1", children: [
        /* @__PURE__ */ jsxDEV("h4", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:421:12", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "421", "data-component-file": "EmailTemplates.jsx", "data-component-name": "h4", "data-component-content": "%7B%22elementName%22%3A%22h4%22%2C%22className%22%3A%22font-medium%20text-text-primary%20text-sm%22%2C%22textContent%22%3A%22Template%20Usage%20Tips%22%7D", className: "font-medium text-text-primary text-sm", children: "Template Usage Tips" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
          lineNumber: 421,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx:422:12", "data-component-path": "src\\pages\\settings-administration\\components\\EmailTemplates.jsx", "data-component-line": "422", "data-component-file": "EmailTemplates.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20text-sm%20mt-1%22%2C%22textContent%22%3A%22Use%20merge%20fields%20like%20to%20personalize%20emails.%20Templates%20marked%20as%20'Active'%20are%20available%20%5Cn%20%20%20%20%20%20%20%20%20%20%20%20%20%20for%20use%20in%20email%20campaigns.%20Test%20your%20templates%20before%20sending%20to%20ensure%20proper%20formatting.%22%7D", className: "text-text-secondary text-sm mt-1", children: [
          "Use merge fields like ",
          `{{first_name}}`,
          " to personalize emails. Templates marked as 'Active' are available for use in email campaigns. Test your templates before sending to ensure proper formatting."
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
          lineNumber: 422,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
        lineNumber: 420,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
      lineNumber: 418,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
      lineNumber: 417,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx",
    lineNumber: 177,
    columnNumber: 5
  }, this);
};
_s(EmailTemplates, "aKKTHLHjd6JW0QEIrWtydtOe3js=");
_c = EmailTemplates;
export default EmailTemplates;
var _c;
$RefreshReg$(_c, "EmailTemplates");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/settings-administration/components/EmailTemplates.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0tNOzJCQWhLTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBLE9BQU9BLFNBQVNDLGdCQUFnQjtBQUNoQyxPQUFPQyxVQUFVO0FBRWpCLE1BQU1DLGlCQUFpQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzNCLFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJTDtBQUFBQSxJQUFTO0FBQUEsTUFDekM7QUFBQSxRQUNFTSxJQUFJO0FBQUEsUUFDSkMsTUFBTTtBQUFBLFFBQ05DLFNBQVM7QUFBQSxRQUNUQyxVQUFVO0FBQUEsUUFDVkMsUUFBUTtBQUFBLFFBQ1JDLGNBQWM7QUFBQSxRQUNkQyxPQUFPO0FBQUEsUUFDUEMsU0FBUztBQUFBLE1BQ1g7QUFBQSxNQUNBO0FBQUEsUUFDRVAsSUFBSTtBQUFBLFFBQ0pDLE1BQU07QUFBQSxRQUNOQyxTQUFTO0FBQUEsUUFDVEMsVUFBVTtBQUFBLFFBQ1ZDLFFBQVE7QUFBQSxRQUNSQyxjQUFjO0FBQUEsUUFDZEMsT0FBTztBQUFBLFFBQ1BDLFNBQVM7QUFBQSxNQUNYO0FBQUEsTUFDQTtBQUFBLFFBQ0VQLElBQUk7QUFBQSxRQUNKQyxNQUFNO0FBQUEsUUFDTkMsU0FBUztBQUFBLFFBQ1RDLFVBQVU7QUFBQSxRQUNWQyxRQUFRO0FBQUEsUUFDUkMsY0FBYztBQUFBLFFBQ2RDLE9BQU87QUFBQSxRQUNQQyxTQUFTO0FBQUEsTUFDWDtBQUFBLElBQUM7QUFBQSxFQUNGO0FBRUQsUUFBTSxDQUFDQyxrQkFBa0JDLG1CQUFtQixJQUFJZixTQUFTLElBQUk7QUFDN0QsUUFBTSxDQUFDZ0IsbUJBQW1CQyxvQkFBb0IsSUFBSWpCLFNBQVMsS0FBSztBQUNoRSxRQUFNLENBQUNrQixhQUFhQyxjQUFjLElBQUluQixTQUFTLEtBQUs7QUFDcEQsUUFBTSxDQUFDb0IsaUJBQWlCQyxrQkFBa0IsSUFBSXJCLFNBQVMsSUFBSTtBQUMzRCxRQUFNLENBQUNzQixjQUFjQyxlQUFlLElBQUl2QixTQUFTO0FBQUEsSUFDL0NPLE1BQU07QUFBQSxJQUNOQyxTQUFTO0FBQUEsSUFDVEMsVUFBVTtBQUFBLElBQ1ZJLFNBQVM7QUFBQSxFQUNYLENBQUM7QUFFRCxRQUFNVyxhQUFhO0FBQUEsSUFDakIsRUFBRUMsT0FBTyxXQUFXQyxPQUFPLFVBQVU7QUFBQSxJQUNyQyxFQUFFRCxPQUFPLGNBQWNDLE9BQU8sYUFBYTtBQUFBLElBQzNDLEVBQUVELE9BQU8sWUFBWUMsT0FBTyxZQUFZO0FBQUEsSUFDeEMsRUFBRUQsT0FBTyxXQUFXQyxPQUFPLGVBQWU7QUFBQSxJQUMxQyxFQUFFRCxPQUFPLGFBQWFDLE9BQU8saUJBQWlCO0FBQUEsSUFDOUMsRUFBRUQsT0FBTyxZQUFZQyxPQUFPLFlBQVk7QUFBQSxFQUFDO0FBRzNDLFFBQU1DLGNBQWM7QUFBQSxJQUNsQixFQUFFQyxPQUFPLGtCQUFrQkMsYUFBYSxxQkFBcUI7QUFBQSxJQUM3RCxFQUFFRCxPQUFPLGlCQUFpQkMsYUFBYSxvQkFBb0I7QUFBQSxJQUMzRCxFQUFFRCxPQUFPLGlCQUFpQkMsYUFBYSxvQkFBb0I7QUFBQSxJQUMzRCxFQUFFRCxPQUFPLGFBQWFDLGFBQWEsd0JBQXdCO0FBQUEsSUFDM0QsRUFBRUQsT0FBTyxvQkFBb0JDLGFBQWEsdUJBQXVCO0FBQUEsSUFDakUsRUFBRUQsT0FBTyxhQUFhQyxhQUFhLHVCQUF1QjtBQUFBLElBQzFELEVBQUVELE9BQU8saUJBQWlCQyxhQUFhLGFBQWE7QUFBQSxJQUNwRCxFQUFFRCxPQUFPLGtCQUFrQkMsYUFBYSxhQUFhO0FBQUEsSUFDckQsRUFBRUQsT0FBTyxtQkFBbUJDLGFBQWEsWUFBWTtBQUFBLElBQ3JELEVBQUVELE9BQU8sb0JBQW9CQyxhQUFhLGFBQWE7QUFBQSxJQUN2RCxFQUFFRCxPQUFPLG9CQUFvQkMsYUFBYSxlQUFlO0FBQUEsRUFBQztBQUc1RCxRQUFNQyx1QkFBdUJBLE1BQU07QUFDakNULHVCQUFtQixJQUFJO0FBQ3ZCRSxvQkFBZ0I7QUFBQSxNQUNkaEIsTUFBTTtBQUFBLE1BQ05DLFNBQVM7QUFBQSxNQUNUQyxVQUFVO0FBQUEsTUFDVkksU0FBUztBQUFBLElBQ1gsQ0FBQztBQUNESSx5QkFBcUIsSUFBSTtBQUFBLEVBQzNCO0FBRUEsUUFBTWMscUJBQXFCQSxDQUFDQyxhQUFhO0FBQ3ZDWCx1QkFBbUJXLFFBQVE7QUFDM0JULG9CQUFnQjtBQUFBLE1BQ2RoQixNQUFNeUIsVUFBVXpCO0FBQUFBLE1BQ2hCQyxTQUFTd0IsVUFBVXhCO0FBQUFBLE1BQ25CQyxVQUFVdUIsVUFBVXZCO0FBQUFBLE1BQ3BCSSxTQUFTbUIsVUFBVW5CO0FBQUFBLElBQ3JCLENBQUM7QUFDREkseUJBQXFCLElBQUk7QUFBQSxFQUMzQjtBQUVBLFFBQU1nQix1QkFBdUJBLENBQUNDLGVBQWU7QUFDM0M3QixpQkFBYSxDQUFBOEIsU0FBUUEsTUFBTUMsT0FBTyxDQUFBSixhQUFZQSxVQUFVMUIsT0FBTzRCLFVBQVUsQ0FBQztBQUFBLEVBQzVFO0FBRUEsUUFBTUcscUJBQXFCQSxDQUFDQyxNQUFNO0FBQ2hDQSxPQUFHQyxlQUFlO0FBRWxCLFFBQUluQixpQkFBaUI7QUFDbkJmO0FBQUFBLFFBQWEsQ0FBQThCLFNBQ1hBLE1BQU1LO0FBQUFBLFVBQUksQ0FBQVIsYUFDUkEsVUFBVTFCLE9BQU9jLGlCQUFpQmQsS0FDOUI7QUFBQSxZQUNFLEdBQUcwQjtBQUFBQSxZQUNILEdBQUdWO0FBQUFBLFlBQ0hYLGVBQWMsb0JBQUk4QixLQUFLLElBQUdDLFlBQVksR0FBR0MsTUFBTSxHQUFHLElBQUksQ0FBQztBQUFBLFlBQ3ZEakMsUUFBUXNCLFVBQVV0QixXQUFXLFVBQVUsVUFBVTtBQUFBLFVBQ25ELElBQ0FzQjtBQUFBQSxRQUNOO0FBQUEsTUFDRjtBQUFBLElBQ0YsT0FBTztBQUNMLFlBQU1ZLGNBQWM7QUFBQSxRQUNsQnRDLElBQUltQyxLQUFLSSxJQUFJO0FBQUEsUUFDYixHQUFHdkI7QUFBQUEsUUFDSFosUUFBUTtBQUFBLFFBQ1JDLGVBQWMsb0JBQUk4QixLQUFLLElBQUdDLFlBQVksR0FBR0MsTUFBTSxHQUFHLElBQUksQ0FBQztBQUFBLFFBQ3ZEL0IsT0FBTztBQUFBLE1BQ1Q7QUFDQVAsbUJBQWEsQ0FBQThCLFNBQVEsQ0FBQyxHQUFHQSxNQUFNUyxXQUFXLENBQUM7QUFBQSxJQUM3QztBQUVBM0IseUJBQXFCLEtBQUs7QUFDMUJJLHVCQUFtQixJQUFJO0FBQUEsRUFDekI7QUFFQSxRQUFNeUIsd0JBQXdCQSxDQUFDZCxhQUFhO0FBQzFDakIsd0JBQW9CaUIsUUFBUTtBQUM1QmIsbUJBQWUsSUFBSTtBQUFBLEVBQ3JCO0FBRUEsUUFBTTRCLG1CQUFtQkEsQ0FBQ25CLFVBQVU7QUFDbEMsVUFBTW9CLFdBQVdDLFNBQVNDLGVBQWUsa0JBQWtCO0FBQzNELFVBQU1DLFFBQVFILFVBQVVJO0FBQ3hCLFVBQU1DLE1BQU1MLFVBQVVNO0FBQ3RCLFVBQU1DLE9BQU9qQyxjQUFjVDtBQUMzQixVQUFNMkMsU0FBU0QsTUFBTUUsVUFBVSxHQUFHTixLQUFLO0FBQ3ZDLFVBQU1PLFFBQVFILE1BQU1FLFVBQVVKLEtBQUtFLE1BQU1JLE1BQU07QUFDL0MsVUFBTUMsYUFBYUosU0FBUzVCLFFBQVE4QjtBQUVwQ25DLG9CQUFnQixDQUFBWSxVQUFTLEVBQUUsR0FBR0EsTUFBTXRCLFNBQVMrQyxXQUFXLEVBQUU7QUFHMURDLGVBQVcsTUFBTTtBQUNmYixnQkFBVWMsTUFBTTtBQUNoQmQsZ0JBQVVlLGtCQUFrQlosUUFBUXZCLE9BQU8rQixRQUFRUixRQUFRdkIsT0FBTytCLE1BQU07QUFBQSxJQUMxRSxHQUFHLENBQUM7QUFBQSxFQUNOO0FBRUEsUUFBTUssaUJBQWlCQSxDQUFDdEQsV0FBVztBQUNqQyxVQUFNdUQsZUFBZTtBQUFBLE1BQ25CQyxRQUFRO0FBQUEsTUFDUkMsT0FBTztBQUFBLE1BQ1BDLFVBQVU7QUFBQSxJQUNaO0FBRUEsV0FDRSx1QkFBQyxzWEFBSyxXQUFXLGdEQUFnREgsZUFBZXZELE1BQU0sS0FBSywwQ0FBMEMsSUFDbElBLGtCQUFRMkQsT0FBTyxDQUFDLEdBQUdDLFlBQVksSUFBSTVELFFBQVE2RCxNQUFNLENBQUMsS0FEckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUVBLFFBQU1DLG1CQUFtQkEsQ0FBQy9ELGFBQWE7QUFDckMsVUFBTWdFLGNBQWNqRCxZQUFZa0QsS0FBSyxDQUFBQyxNQUFLQSxHQUFHbEQsVUFBVWhCLFFBQVE7QUFDL0QsV0FDRSx1QkFBQyw2ZUFBSyxXQUFVLGtGQUNiZ0UsdUJBQWEvQyxTQUFTakIsWUFEekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUVBLFNBQ0UsdUJBQUMsdVpBQUksV0FBVSxhQUViO0FBQUEsMkJBQUMsbWJBQUksV0FBVSxxQ0FDYjtBQUFBLDZCQUFDLG1YQUNDO0FBQUEsK0JBQUMsa2VBQUcsV0FBVSx3Q0FBdUMsK0JBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0U7QUFBQSxRQUNwRSx1QkFBQyxpZ0JBQUUsV0FBVSw0QkFBMkIsbUVBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkY7QUFBQSxXQUY3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFDQyxTQUFTcUI7QUFBQUEsVUFDVCxXQUFVO0FBQUEsVUFFVjtBQUFBLG1DQUFDLCtZQUFLLE1BQUssUUFBTyxNQUFNLE1BQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJCO0FBQUEsWUFDM0IsdUJBQUMscWFBQUssK0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUI7QUFBQTtBQUFBO0FBQUEsUUFMdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUE7QUFBQSxTQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQTtBQUFBLElBRUEsdUJBQUMsZ2RBQUksV0FBVSw4REFDYixpQ0FBQyw2WkFBSSxXQUFVLG1CQUNiLGlDQUFDLDJaQUFNLFdBQVUsVUFDZjtBQUFBLDZCQUFDLDZiQUFNLFdBQVUsd0NBQ2YsaUNBQUMsaVhBQ0M7QUFBQSwrQkFBQywyZkFBRyxXQUFVLDZEQUE0RCw2QkFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RjtBQUFBLFFBQ3ZGLHVCQUFDLG1mQUFHLFdBQVUsNkRBQTRELHVCQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlGO0FBQUEsUUFDakYsdUJBQUMsb2ZBQUcsV0FBVSw2REFBNEQsd0JBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0Y7QUFBQSxRQUNsRix1QkFBQyxrZkFBRyxXQUFVLDZEQUE0RCxzQkFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRjtBQUFBLFFBQ2hGLHVCQUFDLGlmQUFHLFdBQVUsNkRBQTRELHFCQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStFO0FBQUEsUUFDL0UsdUJBQUMsb2ZBQUcsV0FBVSw2REFBNEQsd0JBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0Y7QUFBQSxRQUNsRix1QkFBQyxtZkFBRyxXQUFVLDZEQUE0RCx1QkFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRjtBQUFBLFdBUG5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLE1BQ0EsdUJBQUMsMFhBQ0UxQixxQkFBV29DO0FBQUFBLFFBQUksQ0FBQ1IsYUFDZix1QkFBQywrYkFBc0IsV0FBVSxpREFDL0I7QUFBQSxpQ0FBQyx1WkFBRyxXQUFVLGFBQ1osaUNBQUMsOGFBQUksV0FBVSwrQkFDYjtBQUFBLG1DQUFDLDRiQUFLLE1BQUssUUFBTyxNQUFNLElBQUksV0FBVSx3QkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEQ7QUFBQSxZQUMxRCx1QkFBQyxpYkFBSyxXQUFVLGlDQUFpQ0Esb0JBQVV6QixRQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRTtBQUFBLGVBRmxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsVUFDQSx1QkFBQyw2Y0FBRyxXQUFVLDJEQUEyRHlCLG9CQUFVeEIsV0FBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkY7QUFBQSxVQUMzRix1QkFBQyx1WkFBRyxXQUFVLGFBQWFnRSwyQkFBaUJ4QyxVQUFVdkIsUUFBUSxLQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRTtBQUFBLFVBQ2hFLHVCQUFDLHVaQUFHLFdBQVUsYUFBYXVELHlCQUFlaEMsVUFBVXRCLE1BQU0sS0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEQ7QUFBQSxVQUM1RCx1QkFBQyx5ZEFBRyxXQUFVLHlDQUF5Q3NCO0FBQUFBLHNCQUFVcEI7QUFBQUEsWUFBTTtBQUFBLGVBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZFO0FBQUEsVUFDN0UsdUJBQUMsdWJBQUcsV0FBVSx5Q0FBeUNvQixvQkFBVXJCLGdCQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RTtBQUFBLFVBQzlFLHVCQUFDLHVaQUFHLFdBQVUsYUFDWixpQ0FBQywrWkFBSSxXQUFVLGtCQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFDQyxTQUFTLE1BQU1tQyxzQkFBc0JkLFFBQVE7QUFBQSxnQkFDN0MsV0FBVTtBQUFBLGdCQUNWLE9BQU07QUFBQSxnQkFFTixpQ0FBQyw4WUFBSyxNQUFLLE9BQU0sTUFBTSxNQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwQjtBQUFBO0FBQUEsY0FMNUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNRCxtQkFBbUJDLFFBQVE7QUFBQSxnQkFDMUMsV0FBVTtBQUFBLGdCQUNWLE9BQU07QUFBQSxnQkFFTixpQ0FBQyxnWkFBSyxNQUFLLFNBQVEsTUFBTSxNQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE0QjtBQUFBO0FBQUEsY0FMOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNQyxxQkFBcUJELFVBQVUxQixFQUFFO0FBQUEsZ0JBQ2hELFdBQVU7QUFBQSxnQkFDVixPQUFNO0FBQUEsZ0JBRU4saUNBQUMsaVpBQUssTUFBSyxVQUFTLE1BQU0sTUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkI7QUFBQTtBQUFBLGNBTC9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BO0FBQUEsZUFyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFzQkEsS0F2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3QkE7QUFBQSxhQXBDTzBCLFVBQVUxQixJQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBcUNBO0FBQUEsTUFDRCxLQXhDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeUNBO0FBQUEsU0FyREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNEQSxLQXZERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBd0RBLEtBekRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwREE7QUFBQSxJQUVDVSxxQkFDQyx1QkFBQyx3YkFBSSxXQUFVLHdDQUNiLGlDQUFDLHljQUFJLFdBQVUsc0RBQ2I7QUFBQSw2QkFBQyx5YkFBSSxXQUFVLHdDQUF1QyxTQUFTLE1BQU1DLHFCQUFxQixLQUFLLEtBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0c7QUFBQSxNQUNsRyx1QkFBQyw0ZkFBSSxXQUFVLGlHQUNiLGlDQUFDLGtaQUFJLFdBQVUsT0FDYjtBQUFBLCtCQUFDLDJiQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyx1YkFBRyxXQUFVLDJDQUNYRyw0QkFBa0Isa0JBQWtCLHlCQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNSCxxQkFBcUIsS0FBSztBQUFBLGNBQ3pDLFdBQVU7QUFBQSxjQUVWLGlDQUFDLDRZQUFLLE1BQUssS0FBSSxNQUFNLE1BQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdCO0FBQUE7QUFBQSxZQUoxQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLGFBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsUUFFQSx1QkFBQywyWkFBSyxVQUFVb0Isb0JBQW9CLFdBQVUsYUFDNUM7QUFBQSxpQ0FBQyw0YkFBSSxXQUFVLHlDQUNiO0FBQUEsbUNBQUMsb1hBQ0M7QUFBQSxxQ0FBQyx5ZkFBTSxXQUFVLG9EQUFtRCw2QkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUY7QUFBQSxjQUNqRjtBQUFBLGdCQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsT0FBT2YsY0FBY2Y7QUFBQUEsa0JBQ3JCLFVBQVUsQ0FBQytCLE1BQU1mLGdCQUFnQixDQUFBWSxVQUFTLEVBQUUsR0FBR0EsTUFBTTVCLE1BQU0rQixHQUFHc0MsUUFBUW5ELE1BQU0sRUFBRTtBQUFBLGtCQUM5RSxXQUFVO0FBQUEsa0JBQ1YsYUFBWTtBQUFBLGtCQUNaLFVBQVE7QUFBQTtBQUFBLGdCQU5WO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1VO0FBQUEsaUJBUlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLFlBRUEsdUJBQUMsb1hBQ0M7QUFBQSxxQ0FBQyxrZkFBTSxXQUFVLG9EQUFtRCx3QkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEU7QUFBQSxjQUM1RTtBQUFBLGdCQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFDQyxPQUFPSCxjQUFjYjtBQUFBQSxrQkFDckIsVUFBVSxDQUFDNkIsTUFBTWYsZ0JBQWdCLENBQUFZLFVBQVMsRUFBRSxHQUFHQSxNQUFNMUIsVUFBVTZCLEdBQUdzQyxRQUFRbkQsTUFBTSxFQUFFO0FBQUEsa0JBQ2xGLFdBQVU7QUFBQSxrQkFFVEQsc0JBQVlnQjtBQUFBQSxvQkFBSSxDQUFBL0IsYUFDZix1QkFBQyw2WEFBNkIsT0FBT0EsVUFBVWdCLE9BQVFoQixvQkFBVWlCLFNBQXBEakIsVUFBVWdCLE9BQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXVFO0FBQUEsa0JBQ3hFO0FBQUE7QUFBQSxnQkFQSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FRQTtBQUFBLGlCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBV0E7QUFBQSxlQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXlCQTtBQUFBLFVBRUEsdUJBQUMsb1hBQ0M7QUFBQSxtQ0FBQyx3ZkFBTSxXQUFVLG9EQUFtRCw0QkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0Y7QUFBQSxZQUNoRjtBQUFBLGNBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxPQUFPSCxjQUFjZDtBQUFBQSxnQkFDckIsVUFBVSxDQUFDOEIsTUFBTWYsZ0JBQWdCLENBQUFZLFVBQVMsRUFBRSxHQUFHQSxNQUFNM0IsU0FBUzhCLEdBQUdzQyxRQUFRbkQsTUFBTSxFQUFFO0FBQUEsZ0JBQ2pGLFdBQVU7QUFBQSxnQkFDVixhQUFZO0FBQUEsZ0JBQ1osVUFBUTtBQUFBO0FBQUEsY0FOVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNVTtBQUFBLGVBUlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBRUEsdUJBQUMsNGJBQUksV0FBVSx5Q0FDYjtBQUFBLG1DQUFDLDhaQUFJLFdBQVUsaUJBQ2I7QUFBQSxxQ0FBQyx5ZkFBTSxXQUFVLG9EQUFtRCw2QkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUY7QUFBQSxjQUNqRjtBQUFBLGdCQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFDQyxJQUFHO0FBQUEsa0JBQ0gsT0FBT0gsY0FBY1Q7QUFBQUEsa0JBQ3JCLFVBQVUsQ0FBQ3lCLE1BQU1mLGdCQUFnQixDQUFBWSxVQUFTLEVBQUUsR0FBR0EsTUFBTXRCLFNBQVN5QixHQUFHc0MsUUFBUW5ELE1BQU0sRUFBRTtBQUFBLGtCQUNqRixXQUFVO0FBQUEsa0JBQ1YsTUFBTTtBQUFBLGtCQUNOLGFBQVk7QUFBQSxrQkFDWixVQUFRO0FBQUE7QUFBQSxnQkFQVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPVTtBQUFBLGlCQVRaO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBV0E7QUFBQSxZQUVBLHVCQUFDLG9YQUNDO0FBQUEscUNBQUMsd2ZBQU0sV0FBVSxvREFBbUQsNEJBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdGO0FBQUEsY0FDaEYsdUJBQUMscWVBQUksV0FBVSw4RUFDYixpQ0FBQyx3WkFBSSxXQUFVLGFBQ1pFLHVCQUFhYTtBQUFBQSxnQkFBSSxDQUFDcUMsVUFDakI7QUFBQSxrQkFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBRUMsTUFBSztBQUFBLG9CQUNMLFNBQVMsTUFBTTlCLGlCQUFpQjhCLE9BQU9qRCxLQUFLO0FBQUEsb0JBQzVDLFdBQVU7QUFBQSxvQkFFVjtBQUFBLDZDQUFDLGtkQUFJLFdBQVUsK0RBQ1ppRCxpQkFBT2pELFNBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBLHVCQUFDLGtiQUFJLFdBQVUsbUNBQ1ppRCxpQkFBT2hELGVBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBO0FBQUE7QUFBQSxrQkFWS2dELE9BQU9qRDtBQUFBQSxrQkFEZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVlBO0FBQUEsY0FDRCxLQWZIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZ0JBLEtBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBa0JBO0FBQUEsaUJBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcUJBO0FBQUEsZUFuQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvQ0E7QUFBQSxVQUVBLHVCQUFDLG9iQUFJLFdBQVUsbUNBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTLE1BQU1YLHFCQUFxQixLQUFLO0FBQUEsZ0JBQ3pDLFdBQVU7QUFBQSxnQkFBc0Y7QUFBQTtBQUFBLGNBSGxHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUEsZ0JBRVRHLDRCQUFrQixvQkFBb0I7QUFBQTtBQUFBLGNBSnpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBO0FBQUEsZUFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWNBO0FBQUEsYUE1RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTZGQTtBQUFBLFdBMUdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyR0EsS0E1R0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTZHQTtBQUFBLFNBL0dGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnSEEsS0FqSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtIQTtBQUFBLElBR0RGLGVBQWVKLG9CQUNkLHVCQUFDLHdiQUFJLFdBQVUsd0NBQ2IsaUNBQUMseWNBQUksV0FBVSxzREFDYjtBQUFBLDZCQUFDLHliQUFJLFdBQVUsd0NBQXVDLFNBQVMsTUFBTUssZUFBZSxLQUFLLEtBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEY7QUFBQSxNQUM1Rix1QkFBQywyZEFBSSxXQUFVLG9FQUNiLGlDQUFDLGtaQUFJLFdBQVUsT0FDYjtBQUFBLCtCQUFDLDJiQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxzZUFBRyxXQUFVLDJDQUEwQyxnQ0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0U7QUFBQSxVQUN4RTtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNQSxlQUFlLEtBQUs7QUFBQSxjQUNuQyxXQUFVO0FBQUEsY0FFVixpQ0FBQyw0WUFBSyxNQUFLLEtBQUksTUFBTSxNQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3QjtBQUFBO0FBQUEsWUFKMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBRUEsdUJBQUMsd1pBQUksV0FBVSxhQUNiO0FBQUEsaUNBQUMsb1hBQ0M7QUFBQSxtQ0FBQyxzZkFBTSxXQUFVLHNEQUFxRCx3QkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEU7QUFBQSxZQUM5RSx1QkFBQyw0ZEFBSSxXQUFVLHVFQUNaTCw0QkFBa0JOLFdBRHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUVBLHVCQUFDLG9YQUNDO0FBQUEsbUNBQUMsc2ZBQU0sV0FBVSxzREFBcUQsd0JBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThFO0FBQUEsWUFDOUUsdUJBQUMsNmZBQUksV0FBVSxvR0FDWk0sNEJBQWtCRCxXQURyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsYUFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBY0E7QUFBQSxRQUVBLHVCQUFDLHdhQUFJLFdBQVUseUJBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTU0sZUFBZSxLQUFLO0FBQUEsWUFDbkMsV0FBVTtBQUFBLFlBQTRHO0FBQUE7QUFBQSxVQUZ4SDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFdBbENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFtQ0EsS0FwQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFDQTtBQUFBLFNBdkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3Q0EsS0F6Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBDQTtBQUFBLElBR0YsdUJBQUMsdWNBQUksV0FBVSxxREFDYixpQ0FBQyw0YUFBSSxXQUFVLDhCQUNiO0FBQUEsNkJBQUMsb2NBQUssTUFBSyxhQUFZLE1BQU0sSUFBSSxXQUFVLHlCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdFO0FBQUEsTUFDaEUsdUJBQUMscVpBQUksV0FBVSxVQUNiO0FBQUEsK0JBQUMseWVBQUcsV0FBVSx5Q0FBd0MsbUNBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUU7QUFBQSxRQUN6RSx1QkFBQywrdEJBQUUsV0FBVSxvQ0FBbUM7QUFBQTtBQUFBLFVBQ3ZCO0FBQUEsVUFBaUI7QUFBQSxhQUQxQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNQTtBQUFBLFNBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBLEtBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdBO0FBQUEsT0EzUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTRQQTtBQUVKO0FBQUVoQixHQTFhSUQsZ0JBQWM7QUFBQTRFLEtBQWQ1RTtBQTRhTixlQUFlQTtBQUFlLElBQUE0RTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJ1c2VTdGF0ZSIsIkljb24iLCJFbWFpbFRlbXBsYXRlcyIsIl9zIiwidGVtcGxhdGVzIiwic2V0VGVtcGxhdGVzIiwiaWQiLCJuYW1lIiwic3ViamVjdCIsImNhdGVnb3J5Iiwic3RhdHVzIiwibGFzdE1vZGlmaWVkIiwidXNhZ2UiLCJjb250ZW50Iiwic2VsZWN0ZWRUZW1wbGF0ZSIsInNldFNlbGVjdGVkVGVtcGxhdGUiLCJzaG93VGVtcGxhdGVNb2RhbCIsInNldFNob3dUZW1wbGF0ZU1vZGFsIiwic2hvd1ByZXZpZXciLCJzZXRTaG93UHJldmlldyIsImVkaXRpbmdUZW1wbGF0ZSIsInNldEVkaXRpbmdUZW1wbGF0ZSIsInRlbXBsYXRlRm9ybSIsInNldFRlbXBsYXRlRm9ybSIsImNhdGVnb3JpZXMiLCJ2YWx1ZSIsImxhYmVsIiwibWVyZ2VGaWVsZHMiLCJmaWVsZCIsImRlc2NyaXB0aW9uIiwiaGFuZGxlQ3JlYXRlVGVtcGxhdGUiLCJoYW5kbGVFZGl0VGVtcGxhdGUiLCJ0ZW1wbGF0ZSIsImhhbmRsZURlbGV0ZVRlbXBsYXRlIiwidGVtcGxhdGVJZCIsInByZXYiLCJmaWx0ZXIiLCJoYW5kbGVTYXZlVGVtcGxhdGUiLCJlIiwicHJldmVudERlZmF1bHQiLCJtYXAiLCJEYXRlIiwidG9JU09TdHJpbmciLCJzcGxpdCIsIm5ld1RlbXBsYXRlIiwibm93IiwiaGFuZGxlUHJldmlld1RlbXBsYXRlIiwiaW5zZXJ0TWVyZ2VGaWVsZCIsInRleHRhcmVhIiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInN0YXJ0Iiwic2VsZWN0aW9uU3RhcnQiLCJlbmQiLCJzZWxlY3Rpb25FbmQiLCJ0ZXh0IiwiYmVmb3JlIiwic3Vic3RyaW5nIiwiYWZ0ZXIiLCJsZW5ndGgiLCJuZXdDb250ZW50Iiwic2V0VGltZW91dCIsImZvY3VzIiwic2V0U2VsZWN0aW9uUmFuZ2UiLCJnZXRTdGF0dXNCYWRnZSIsInN0YXR1c1N0eWxlcyIsImFjdGl2ZSIsImRyYWZ0IiwiaW5hY3RpdmUiLCJjaGFyQXQiLCJ0b1VwcGVyQ2FzZSIsInNsaWNlIiwiZ2V0Q2F0ZWdvcnlCYWRnZSIsImNhdGVnb3J5T2JqIiwiZmluZCIsImMiLCJ0YXJnZXQiLCJtZXJnZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiRW1haWxUZW1wbGF0ZXMuanN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIHNyYy9wYWdlcy9zZXR0aW5ncy1hZG1pbmlzdHJhdGlvbi9jb21wb25lbnRzL0VtYWlsVGVtcGxhdGVzLmpzeFxyXG5pbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCBJY29uIGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvQXBwSWNvbic7XHJcblxyXG5jb25zdCBFbWFpbFRlbXBsYXRlcyA9ICgpID0+IHtcclxuICBjb25zdCBbdGVtcGxhdGVzLCBzZXRUZW1wbGF0ZXNdID0gdXNlU3RhdGUoW1xyXG4gICAge1xyXG4gICAgICBpZDogMSxcclxuICAgICAgbmFtZTogJ1dlbGNvbWUgRW1haWwnLFxyXG4gICAgICBzdWJqZWN0OiAnV2VsY29tZSB0byB7e2NvbXBhbnlfbmFtZX19IScsXHJcbiAgICAgIGNhdGVnb3J5OiAnb25ib2FyZGluZycsXHJcbiAgICAgIHN0YXR1czogJ2FjdGl2ZScsXHJcbiAgICAgIGxhc3RNb2RpZmllZDogJzIwMjQtMDEtMTUnLFxyXG4gICAgICB1c2FnZTogNDUsXHJcbiAgICAgIGNvbnRlbnQ6ICdIZWxsbyB7e2ZpcnN0X25hbWV9fSxcXG5cXG5XZWxjb21lIHRvIHt7Y29tcGFueV9uYW1lfX0hIFdlXFwncmUgZXhjaXRlZCB0byBoYXZlIHlvdSBvbiBib2FyZC5cXG5cXG5CZXN0IHJlZ2FyZHMsXFxue3tzZW5kZXJfbmFtZX19J1xyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgaWQ6IDIsXHJcbiAgICAgIG5hbWU6ICdGb2xsb3ctdXAgQWZ0ZXIgTWVldGluZycsXHJcbiAgICAgIHN1YmplY3Q6ICdHcmVhdCBtZWV0aW5nIHdpdGggeW91IHRvZGF5IScsXHJcbiAgICAgIGNhdGVnb3J5OiAnZm9sbG93dXAnLFxyXG4gICAgICBzdGF0dXM6ICdhY3RpdmUnLFxyXG4gICAgICBsYXN0TW9kaWZpZWQ6ICcyMDI0LTAxLTEyJyxcclxuICAgICAgdXNhZ2U6IDc4LFxyXG4gICAgICBjb250ZW50OiAnSGkge3tmaXJzdF9uYW1lfX0sXFxuXFxuVGhhbmsgeW91IGZvciB0YWtpbmcgdGhlIHRpbWUgdG8gbWVldCB3aXRoIHVzIHRvZGF5LiBBcyBkaXNjdXNzZWQsIElcXCdtIGF0dGFjaGluZyB0aGUgcHJvcG9zYWwgZm9yIHlvdXIgcmV2aWV3LlxcblxcblBsZWFzZSBsZXQgbWUga25vdyBpZiB5b3UgaGF2ZSBhbnkgcXVlc3Rpb25zLlxcblxcbkJlc3QgcmVnYXJkcyxcXG57e3NlbmRlcl9uYW1lfX0nXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBpZDogMyxcclxuICAgICAgbmFtZTogJ0RlYWwgQ2xvc2VkIFdvbicsXHJcbiAgICAgIHN1YmplY3Q6ICdDb25ncmF0dWxhdGlvbnMhIFdlbGNvbWUgYWJvYXJkIScsXHJcbiAgICAgIGNhdGVnb3J5OiAnY2xvc2luZycsXHJcbiAgICAgIHN0YXR1czogJ2RyYWZ0JyxcclxuICAgICAgbGFzdE1vZGlmaWVkOiAnMjAyNC0wMS0xMCcsXHJcbiAgICAgIHVzYWdlOiAxMixcclxuICAgICAgY29udGVudDogJ0RlYXIge3tmaXJzdF9uYW1lfX0sXFxuXFxuQ29uZ3JhdHVsYXRpb25zISBXZVxcJ3JlIHRocmlsbGVkIHRvIHdlbGNvbWUgeW91IGFzIG91ciBuZXdlc3QgY2xpZW50Llxcblxcbk5leHQgc3RlcHM6XFxuLSBZb3VcXCdsbCByZWNlaXZlIHlvdXIgd2VsY29tZSBwYWNrZXQgd2l0aGluIDI0IGhvdXJzXFxuLSBPdXIgb25ib2FyZGluZyB0ZWFtIHdpbGwgY29udGFjdCB5b3Ugc2hvcnRseVxcblxcblRoYW5rIHlvdSBmb3IgY2hvb3Npbmcge3tjb21wYW55X25hbWV9fSFcXG5cXG57e3NlbmRlcl9uYW1lfX0nXHJcbiAgICB9XHJcbiAgXSk7XHJcblxyXG4gIGNvbnN0IFtzZWxlY3RlZFRlbXBsYXRlLCBzZXRTZWxlY3RlZFRlbXBsYXRlXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtzaG93VGVtcGxhdGVNb2RhbCwgc2V0U2hvd1RlbXBsYXRlTW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzaG93UHJldmlldywgc2V0U2hvd1ByZXZpZXddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtlZGl0aW5nVGVtcGxhdGUsIHNldEVkaXRpbmdUZW1wbGF0ZV0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbdGVtcGxhdGVGb3JtLCBzZXRUZW1wbGF0ZUZvcm1dID0gdXNlU3RhdGUoe1xyXG4gICAgbmFtZTogJycsXHJcbiAgICBzdWJqZWN0OiAnJyxcclxuICAgIGNhdGVnb3J5OiAnZ2VuZXJhbCcsXHJcbiAgICBjb250ZW50OiAnJ1xyXG4gIH0pO1xyXG5cclxuICBjb25zdCBjYXRlZ29yaWVzID0gW1xyXG4gICAgeyB2YWx1ZTogJ2dlbmVyYWwnLCBsYWJlbDogJ0dlbmVyYWwnIH0sXHJcbiAgICB7IHZhbHVlOiAnb25ib2FyZGluZycsIGxhYmVsOiAnT25ib2FyZGluZycgfSxcclxuICAgIHsgdmFsdWU6ICdmb2xsb3d1cCcsIGxhYmVsOiAnRm9sbG93LXVwJyB9LFxyXG4gICAgeyB2YWx1ZTogJ2Nsb3NpbmcnLCBsYWJlbDogJ0RlYWwgQ2xvc2luZycgfSxcclxuICAgIHsgdmFsdWU6ICdudXJ0dXJpbmcnLCBsYWJlbDogJ0xlYWQgTnVydHVyaW5nJyB9LFxyXG4gICAgeyB2YWx1ZTogJ3JlbWluZGVyJywgbGFiZWw6ICdSZW1pbmRlcnMnIH1cclxuICBdO1xyXG5cclxuICBjb25zdCBtZXJnZUZpZWxkcyA9IFtcclxuICAgIHsgZmllbGQ6ICd7e2ZpcnN0X25hbWV9fScsIGRlc2NyaXB0aW9uOiAnQ29udGFjdCBmaXJzdCBuYW1lJyB9LFxyXG4gICAgeyBmaWVsZDogJ3t7bGFzdF9uYW1lfX0nLCBkZXNjcmlwdGlvbjogJ0NvbnRhY3QgbGFzdCBuYW1lJyB9LFxyXG4gICAgeyBmaWVsZDogJ3t7ZnVsbF9uYW1lfX0nLCBkZXNjcmlwdGlvbjogJ0NvbnRhY3QgZnVsbCBuYW1lJyB9LFxyXG4gICAgeyBmaWVsZDogJ3t7ZW1haWx9fScsIGRlc2NyaXB0aW9uOiAnQ29udGFjdCBlbWFpbCBhZGRyZXNzJyB9LFxyXG4gICAgeyBmaWVsZDogJ3t7Y29tcGFueV9uYW1lfX0nLCBkZXNjcmlwdGlvbjogJ0NvbnRhY3QgY29tcGFueSBuYW1lJyB9LFxyXG4gICAgeyBmaWVsZDogJ3t7cGhvbmV9fScsIGRlc2NyaXB0aW9uOiAnQ29udGFjdCBwaG9uZSBudW1iZXInIH0sXHJcbiAgICB7IGZpZWxkOiAne3tkZWFsX25hbWV9fScsIGRlc2NyaXB0aW9uOiAnRGVhbCB0aXRsZScgfSxcclxuICAgIHsgZmllbGQ6ICd7e2RlYWxfdmFsdWV9fScsIGRlc2NyaXB0aW9uOiAnRGVhbCB2YWx1ZScgfSxcclxuICAgIHsgZmllbGQ6ICd7e3NlbmRlcl9uYW1lfX0nLCBkZXNjcmlwdGlvbjogJ1lvdXIgbmFtZScgfSxcclxuICAgIHsgZmllbGQ6ICd7e3NlbmRlcl9lbWFpbH19JywgZGVzY3JpcHRpb246ICdZb3VyIGVtYWlsJyB9LFxyXG4gICAgeyBmaWVsZDogJ3t7Y3VycmVudF9kYXRlfX0nLCBkZXNjcmlwdGlvbjogJ0N1cnJlbnQgZGF0ZScgfVxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNyZWF0ZVRlbXBsYXRlID0gKCkgPT4ge1xyXG4gICAgc2V0RWRpdGluZ1RlbXBsYXRlKG51bGwpO1xyXG4gICAgc2V0VGVtcGxhdGVGb3JtKHtcclxuICAgICAgbmFtZTogJycsXHJcbiAgICAgIHN1YmplY3Q6ICcnLFxyXG4gICAgICBjYXRlZ29yeTogJ2dlbmVyYWwnLFxyXG4gICAgICBjb250ZW50OiAnJ1xyXG4gICAgfSk7XHJcbiAgICBzZXRTaG93VGVtcGxhdGVNb2RhbCh0cnVlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVFZGl0VGVtcGxhdGUgPSAodGVtcGxhdGUpID0+IHtcclxuICAgIHNldEVkaXRpbmdUZW1wbGF0ZSh0ZW1wbGF0ZSk7XHJcbiAgICBzZXRUZW1wbGF0ZUZvcm0oe1xyXG4gICAgICBuYW1lOiB0ZW1wbGF0ZT8ubmFtZSxcclxuICAgICAgc3ViamVjdDogdGVtcGxhdGU/LnN1YmplY3QsXHJcbiAgICAgIGNhdGVnb3J5OiB0ZW1wbGF0ZT8uY2F0ZWdvcnksXHJcbiAgICAgIGNvbnRlbnQ6IHRlbXBsYXRlPy5jb250ZW50XHJcbiAgICB9KTtcclxuICAgIHNldFNob3dUZW1wbGF0ZU1vZGFsKHRydWUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZVRlbXBsYXRlID0gKHRlbXBsYXRlSWQpID0+IHtcclxuICAgIHNldFRlbXBsYXRlcyhwcmV2ID0+IHByZXY/LmZpbHRlcih0ZW1wbGF0ZSA9PiB0ZW1wbGF0ZT8uaWQgIT09IHRlbXBsYXRlSWQpKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTYXZlVGVtcGxhdGUgPSAoZSkgPT4ge1xyXG4gICAgZT8ucHJldmVudERlZmF1bHQoKTtcclxuICAgIFxyXG4gICAgaWYgKGVkaXRpbmdUZW1wbGF0ZSkge1xyXG4gICAgICBzZXRUZW1wbGF0ZXMocHJldiA9PlxyXG4gICAgICAgIHByZXY/Lm1hcCh0ZW1wbGF0ZSA9PlxyXG4gICAgICAgICAgdGVtcGxhdGU/LmlkID09PSBlZGl0aW5nVGVtcGxhdGU/LmlkXHJcbiAgICAgICAgICAgID8geyBcclxuICAgICAgICAgICAgICAgIC4uLnRlbXBsYXRlLCBcclxuICAgICAgICAgICAgICAgIC4uLnRlbXBsYXRlRm9ybSwgXHJcbiAgICAgICAgICAgICAgICBsYXN0TW9kaWZpZWQ6IG5ldyBEYXRlKCk/LnRvSVNPU3RyaW5nKCk/LnNwbGl0KCdUJyk/LlswXSxcclxuICAgICAgICAgICAgICAgIHN0YXR1czogdGVtcGxhdGU/LnN0YXR1cyA9PT0gJ2RyYWZ0JyA/ICdkcmFmdCcgOiAnYWN0aXZlJ1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgOiB0ZW1wbGF0ZVxyXG4gICAgICAgIClcclxuICAgICAgKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGNvbnN0IG5ld1RlbXBsYXRlID0ge1xyXG4gICAgICAgIGlkOiBEYXRlLm5vdygpLFxyXG4gICAgICAgIC4uLnRlbXBsYXRlRm9ybSxcclxuICAgICAgICBzdGF0dXM6ICdkcmFmdCcsXHJcbiAgICAgICAgbGFzdE1vZGlmaWVkOiBuZXcgRGF0ZSgpPy50b0lTT1N0cmluZygpPy5zcGxpdCgnVCcpPy5bMF0sXHJcbiAgICAgICAgdXNhZ2U6IDBcclxuICAgICAgfTtcclxuICAgICAgc2V0VGVtcGxhdGVzKHByZXYgPT4gWy4uLnByZXYsIG5ld1RlbXBsYXRlXSk7XHJcbiAgICB9XHJcbiAgICBcclxuICAgIHNldFNob3dUZW1wbGF0ZU1vZGFsKGZhbHNlKTtcclxuICAgIHNldEVkaXRpbmdUZW1wbGF0ZShudWxsKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVQcmV2aWV3VGVtcGxhdGUgPSAodGVtcGxhdGUpID0+IHtcclxuICAgIHNldFNlbGVjdGVkVGVtcGxhdGUodGVtcGxhdGUpO1xyXG4gICAgc2V0U2hvd1ByZXZpZXcodHJ1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaW5zZXJ0TWVyZ2VGaWVsZCA9IChmaWVsZCkgPT4ge1xyXG4gICAgY29uc3QgdGV4dGFyZWEgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgndGVtcGxhdGUtY29udGVudCcpO1xyXG4gICAgY29uc3Qgc3RhcnQgPSB0ZXh0YXJlYT8uc2VsZWN0aW9uU3RhcnQ7XHJcbiAgICBjb25zdCBlbmQgPSB0ZXh0YXJlYT8uc2VsZWN0aW9uRW5kO1xyXG4gICAgY29uc3QgdGV4dCA9IHRlbXBsYXRlRm9ybT8uY29udGVudDtcclxuICAgIGNvbnN0IGJlZm9yZSA9IHRleHQ/LnN1YnN0cmluZygwLCBzdGFydCk7XHJcbiAgICBjb25zdCBhZnRlciA9IHRleHQ/LnN1YnN0cmluZyhlbmQsIHRleHQ/Lmxlbmd0aCk7XHJcbiAgICBjb25zdCBuZXdDb250ZW50ID0gYmVmb3JlICsgZmllbGQgKyBhZnRlcjtcclxuICAgIFxyXG4gICAgc2V0VGVtcGxhdGVGb3JtKHByZXYgPT4gKHsgLi4ucHJldiwgY29udGVudDogbmV3Q29udGVudCB9KSk7XHJcbiAgICBcclxuICAgIC8vIEZvY3VzIGJhY2sgdG8gdGV4dGFyZWEgYW5kIHNldCBjdXJzb3IgcG9zaXRpb25cclxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICB0ZXh0YXJlYT8uZm9jdXMoKTtcclxuICAgICAgdGV4dGFyZWE/LnNldFNlbGVjdGlvblJhbmdlKHN0YXJ0ICsgZmllbGQ/Lmxlbmd0aCwgc3RhcnQgKyBmaWVsZD8ubGVuZ3RoKTtcclxuICAgIH0sIDApO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGdldFN0YXR1c0JhZGdlID0gKHN0YXR1cykgPT4ge1xyXG4gICAgY29uc3Qgc3RhdHVzU3R5bGVzID0ge1xyXG4gICAgICBhY3RpdmU6ICdiZy1zdWNjZXNzLTUwIHRleHQtc3VjY2Vzcy02MDAgYm9yZGVyLXN1Y2Nlc3MtMTAwJyxcclxuICAgICAgZHJhZnQ6ICdiZy13YXJuaW5nLTUwIHRleHQtd2FybmluZy02MDAgYm9yZGVyLXdhcm5pbmctMTAwJyxcclxuICAgICAgaW5hY3RpdmU6ICdiZy1lcnJvci01MCB0ZXh0LWVycm9yLTYwMCBib3JkZXItZXJyb3ItMTAwJ1xyXG4gICAgfTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0yIHB5LTEgdGV4dC14cyBmb250LW1lZGl1bSByb3VuZGVkIGJvcmRlciAke3N0YXR1c1N0eWxlcz8uW3N0YXR1c10gfHwgJ2JnLWdyYXktNTAgdGV4dC1ncmF5LTYwMCBib3JkZXItZ3JheS0xMDAnfWB9PlxyXG4gICAgICAgIHtzdGF0dXM/LmNoYXJBdCgwKT8udG9VcHBlckNhc2UoKSArIHN0YXR1cz8uc2xpY2UoMSl9XHJcbiAgICAgIDwvc3Bhbj5cclxuICAgICk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZ2V0Q2F0ZWdvcnlCYWRnZSA9IChjYXRlZ29yeSkgPT4ge1xyXG4gICAgY29uc3QgY2F0ZWdvcnlPYmogPSBjYXRlZ29yaWVzPy5maW5kKGMgPT4gYz8udmFsdWUgPT09IGNhdGVnb3J5KTtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIgcHktMSB0ZXh0LXhzIGJnLXByaW1hcnktNTAgdGV4dC1wcmltYXJ5IGJvcmRlciBib3JkZXItcHJpbWFyeS0xMDAgcm91bmRlZFwiPlxyXG4gICAgICAgIHtjYXRlZ29yeU9iaj8ubGFiZWwgfHwgY2F0ZWdvcnl9XHJcbiAgICAgIDwvc3Bhbj5cclxuICAgICk7XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XHJcbiAgICAgIHsvKiBIZWFkZXIgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC10ZXh0LXByaW1hcnlcIj5FbWFpbCBUZW1wbGF0ZXM8L2gyPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC10ZXh0LXNlY29uZGFyeSBtdC0xXCI+Q3JlYXRlIGFuZCBtYW5hZ2UgZW1haWwgdGVtcGxhdGVzIHdpdGggbWVyZ2UgZmllbGRzPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUNyZWF0ZVRlbXBsYXRlfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiYmctcHJpbWFyeSB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkLWxnIGhvdmVyOmJnLXByaW1hcnktNjAwIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MCBlYXNlLXNtb290aCBmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTJcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxJY29uIG5hbWU9XCJQbHVzXCIgc2l6ZT17MTZ9IC8+XHJcbiAgICAgICAgICA8c3Bhbj5DcmVhdGUgVGVtcGxhdGU8L3NwYW4+XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICB7LyogVGVtcGxhdGVzIExpc3QgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc3VyZmFjZSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItYm9yZGVyIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvXCI+XHJcbiAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1iYWNrZ3JvdW5kIGJvcmRlci1iIGJvcmRlci1ib3JkZXJcIj5cclxuICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHB5LTMgcHgtNCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5XCI+VGVtcGxhdGUgTmFtZTwvdGg+XHJcbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHB5LTMgcHgtNCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5XCI+U3ViamVjdDwvdGg+XHJcbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHB5LTMgcHgtNCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5XCI+Q2F0ZWdvcnk8L3RoPlxyXG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInRleHQtbGVmdCBweS0zIHB4LTQgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeVwiPlN0YXR1czwvdGg+XHJcbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHB5LTMgcHgtNCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5XCI+VXNhZ2U8L3RoPlxyXG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInRleHQtbGVmdCBweS0zIHB4LTQgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeVwiPk1vZGlmaWVkPC90aD5cclxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgcHktMyBweC00IHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnlcIj5BY3Rpb25zPC90aD5cclxuICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgICA8dGJvZHk+XHJcbiAgICAgICAgICAgICAge3RlbXBsYXRlcz8ubWFwKCh0ZW1wbGF0ZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgPHRyIGtleT17dGVtcGxhdGU/LmlkfSBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItYm9yZGVyIGhvdmVyOmJnLXN1cmZhY2UtaG92ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiTWFpbFwiIHNpemU9ezE2fSBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtdGVydGlhcnlcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnlcIj57dGVtcGxhdGU/Lm5hbWV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC00IHRleHQtc20gdGV4dC10ZXh0LXNlY29uZGFyeSBtYXgtdy14cyB0cnVuY2F0ZVwiPnt0ZW1wbGF0ZT8uc3ViamVjdH08L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC00XCI+e2dldENhdGVnb3J5QmFkZ2UodGVtcGxhdGU/LmNhdGVnb3J5KX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC00XCI+e2dldFN0YXR1c0JhZGdlKHRlbXBsYXRlPy5zdGF0dXMpfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTQgdGV4dC1zbSB0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+e3RlbXBsYXRlPy51c2FnZX0gdGltZXM8L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC00IHRleHQtc20gdGV4dC10ZXh0LXNlY29uZGFyeVwiPnt0ZW1wbGF0ZT8ubGFzdE1vZGlmaWVkfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggc3BhY2UteC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVByZXZpZXdUZW1wbGF0ZSh0ZW1wbGF0ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMSB0ZXh0LXRleHQtc2Vjb25kYXJ5IGhvdmVyOnRleHQtcHJpbWFyeSB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlByZXZpZXdcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiRXllXCIgc2l6ZT17MTZ9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRWRpdFRlbXBsYXRlKHRlbXBsYXRlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xIHRleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC1wcmltYXJ5IHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiRWRpdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJFZGl0M1wiIHNpemU9ezE2fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZVRlbXBsYXRlKHRlbXBsYXRlPy5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMSB0ZXh0LXRleHQtc2Vjb25kYXJ5IGhvdmVyOnRleHQtZXJyb3IgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJEZWxldGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiVHJhc2gyXCIgc2l6ZT17MTZ9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgey8qIENyZWF0ZS9FZGl0IFRlbXBsYXRlIE1vZGFsICovfVxyXG4gICAgICB7c2hvd1RlbXBsYXRlTW9kYWwgJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTEyMDAgb3ZlcmZsb3cteS1hdXRvXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG1pbi1oLXNjcmVlbiBweC00XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBiZy1ibGFjayBiZy1vcGFjaXR5LTUwXCIgb25DbGljaz17KCkgPT4gc2V0U2hvd1RlbXBsYXRlTW9kYWwoZmFsc2UpfT48L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zdXJmYWNlIHJvdW5kZWQtbGcgc2hhZG93LXhsIG1heC13LTR4bCB3LWZ1bGwgcmVsYXRpdmUgei0xMzAwIG1heC1oLXNjcmVlbiBvdmVyZmxvdy15LWF1dG9cIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNlwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtdGV4dC1wcmltYXJ5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2VkaXRpbmdUZW1wbGF0ZSA/ICdFZGl0IFRlbXBsYXRlJyA6ICdDcmVhdGUgTmV3IFRlbXBsYXRlJ31cclxuICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dUZW1wbGF0ZU1vZGFsKGZhbHNlKX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5IGhvdmVyOnRleHQtdGV4dC1wcmltYXJ5IHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiWFwiIHNpemU9ezIwfSAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU2F2ZVRlbXBsYXRlfSBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IG1iLTFcIj5UZW1wbGF0ZSBOYW1lPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0ZW1wbGF0ZUZvcm0/Lm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VGVtcGxhdGVGb3JtKHByZXYgPT4gKHsgLi4ucHJldiwgbmFtZTogZT8udGFyZ2V0Py52YWx1ZSB9KSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ib3JkZXIgcm91bmRlZC1sZyBmb2N1czpyaW5nLXByaW1hcnkgZm9jdXM6Ym9yZGVyLXByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRlbXBsYXRlIG5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItMVwiPkNhdGVnb3J5PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3RlbXBsYXRlRm9ybT8uY2F0ZWdvcnl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VGVtcGxhdGVGb3JtKHByZXYgPT4gKHsgLi4ucHJldiwgY2F0ZWdvcnk6IGU/LnRhcmdldD8udmFsdWUgfSkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1wcmltYXJ5IGZvY3VzOmJvcmRlci1wcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2NhdGVnb3JpZXM/Lm1hcChjYXRlZ29yeSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2NhdGVnb3J5Py52YWx1ZX0gdmFsdWU9e2NhdGVnb3J5Py52YWx1ZX0+e2NhdGVnb3J5Py5sYWJlbH08L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IG1iLTFcIj5TdWJqZWN0IExpbmU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3RlbXBsYXRlRm9ybT8uc3ViamVjdH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VGVtcGxhdGVGb3JtKHByZXYgPT4gKHsgLi4ucHJldiwgc3ViamVjdDogZT8udGFyZ2V0Py52YWx1ZSB9KSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1wcmltYXJ5IGZvY3VzOmJvcmRlci1wcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgZW1haWwgc3ViamVjdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy0zIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzpjb2wtc3Bhbi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSBtYi0xXCI+RW1haWwgQ29udGVudDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGV4dGFyZWFcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0ZW1wbGF0ZS1jb250ZW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3RlbXBsYXRlRm9ybT8uY29udGVudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRUZW1wbGF0ZUZvcm0ocHJldiA9PiAoeyAuLi5wcmV2LCBjb250ZW50OiBlPy50YXJnZXQ/LnZhbHVlIH0pKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLWxnIGZvY3VzOnJpbmctcHJpbWFyeSBmb2N1czpib3JkZXItcHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJvd3M9ezEyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIGVtYWlsIGNvbnRlbnQuLi5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItMVwiPk1lcmdlIEZpZWxkczwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWJhY2tncm91bmQgYm9yZGVyIGJvcmRlci1ib3JkZXIgcm91bmRlZC1sZyBwLTMgbWF4LWgtODAgb3ZlcmZsb3cteS1hdXRvXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge21lcmdlRmllbGRzPy5tYXAoKG1lcmdlKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17bWVyZ2U/LmZpZWxkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaW5zZXJ0TWVyZ2VGaWVsZChtZXJnZT8uZmllbGQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1sZWZ0IHAtMiByb3VuZGVkIGhvdmVyOmJnLXN1cmZhY2UtaG92ZXIgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwIGdyb3VwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbW9ubyB0ZXh0LXByaW1hcnkgZ3JvdXAtaG92ZXI6dGV4dC1wcmltYXJ5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHttZXJnZT8uZmllbGR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC10ZXh0LXRlcnRpYXJ5IG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bWVyZ2U/LmRlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBzcGFjZS14LTMgbXQtNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1RlbXBsYXRlTW9kYWwoZmFsc2UpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC10ZXh0LXByaW1hcnkgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBDYW5jZWxcclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXByaW1hcnkgdGV4dC13aGl0ZSBweC00IHB5LTIgcm91bmRlZC1sZyBob3ZlcjpiZy1wcmltYXJ5LTYwMCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTAgZWFzZS1zbW9vdGhcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlZGl0aW5nVGVtcGxhdGUgPyAnVXBkYXRlIFRlbXBsYXRlJyA6ICdDcmVhdGUgVGVtcGxhdGUnfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgICAgey8qIFByZXZpZXcgTW9kYWwgKi99XHJcbiAgICAgIHtzaG93UHJldmlldyAmJiBzZWxlY3RlZFRlbXBsYXRlICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei0xMjAwIG92ZXJmbG93LXktYXV0b1wiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBtaW4taC1zY3JlZW4gcHgtNFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctYmxhY2sgYmctb3BhY2l0eS01MFwiIG9uQ2xpY2s9eygpID0+IHNldFNob3dQcmV2aWV3KGZhbHNlKX0+PC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc3VyZmFjZSByb3VuZGVkLWxnIHNoYWRvdy14bCBtYXgtdy0yeGwgdy1mdWxsIHJlbGF0aXZlIHotMTMwMFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC10ZXh0LXByaW1hcnlcIj5UZW1wbGF0ZSBQcmV2aWV3PC9oMz5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dQcmV2aWV3KGZhbHNlKX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5IGhvdmVyOnRleHQtdGV4dC1wcmltYXJ5IHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiWFwiIHNpemU9ezIwfSAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1zZWNvbmRhcnkgbWItMVwiPlN1YmplY3Q6PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWJhY2tncm91bmQgYm9yZGVyIGJvcmRlci1ib3JkZXIgcm91bmRlZC1sZyBwLTMgdGV4dC10ZXh0LXByaW1hcnlcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZFRlbXBsYXRlPy5zdWJqZWN0fVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXNlY29uZGFyeSBtYi0xXCI+Q29udGVudDo8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYmFja2dyb3VuZCBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLWxnIHAtNCB0ZXh0LXRleHQtcHJpbWFyeSB3aGl0ZXNwYWNlLXByZS13cmFwIG1pbi1oLTQwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRUZW1wbGF0ZT8uY29udGVudH1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIG10LTZcIj5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dQcmV2aWV3KGZhbHNlKX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1wcmltYXJ5IHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQtbGcgaG92ZXI6YmctcHJpbWFyeS02MDAgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwIGVhc2Utc21vb3RoXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIENsb3NlIFByZXZpZXdcclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgICAgey8qIFVzYWdlIEd1aWRlbGluZXMgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYmFja2dyb3VuZCBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLWxnIHAtNFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBzcGFjZS14LTNcIj5cclxuICAgICAgICAgIDxJY29uIG5hbWU9XCJMaWdodGJ1bGJcIiBzaXplPXsxNn0gY2xhc3NOYW1lPVwidGV4dC1wcmltYXJ5IG10LTAuNVwiIC8+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgdGV4dC1zbVwiPlRlbXBsYXRlIFVzYWdlIFRpcHM8L2g0PlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5IHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgIFVzZSBtZXJnZSBmaWVsZHMgbGlrZSB7YHt7Zmlyc3RfbmFtZX19YH0gdG8gcGVyc29uYWxpemUgZW1haWxzLiBUZW1wbGF0ZXMgbWFya2VkIGFzICdBY3RpdmUnIGFyZSBhdmFpbGFibGUgXHJcbiAgICAgICAgICAgICAgZm9yIHVzZSBpbiBlbWFpbCBjYW1wYWlnbnMuIFRlc3QgeW91ciB0ZW1wbGF0ZXMgYmVmb3JlIHNlbmRpbmcgdG8gZW5zdXJlIHByb3BlciBmb3JtYXR0aW5nLlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgRW1haWxUZW1wbGF0ZXM7Il0sImZpbGUiOiJEOi9jdXJyZW50IHByb2plY3RzL2NsYXVkZS1jb2RlL3NyYy9wYWdlcy9zZXR0aW5ncy1hZG1pbmlzdHJhdGlvbi9jb21wb25lbnRzL0VtYWlsVGVtcGxhdGVzLmpzeCJ9