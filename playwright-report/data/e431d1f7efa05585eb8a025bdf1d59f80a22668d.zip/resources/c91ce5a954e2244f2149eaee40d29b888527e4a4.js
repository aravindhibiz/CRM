import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/sales-dashboard/index.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { DragDropContext } from "/node_modules/.vite/deps/react-beautiful-dnd.js?v=44ab9529";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "/node_modules/.vite/deps/recharts.js?v=44ab9529";
import Header from "/src/components/ui/Header.jsx";
import Breadcrumb from "/src/components/ui/Breadcrumb.jsx";
import Icon from "/src/components/AppIcon.jsx";
import { useAuth } from "/src/contexts/AuthContext.jsx";
import RecentActivity from "/src/pages/sales-dashboard/components/RecentActivity.jsx";
import QuickActions from "/src/pages/sales-dashboard/components/QuickActions.jsx";
import UpcomingTasks from "/src/pages/sales-dashboard/components/UpcomingTasks.jsx";
import PipelineStage from "/src/pages/sales-dashboard/components/PipelineStage.jsx";
import PerformanceMetrics from "/src/pages/sales-dashboard/components/PerformanceMetrics.jsx";
import dealsService from "/src/services/dealsService.js";
const SalesDashboard = () => {
  _s();
  const { user, loading: authLoading } = useAuth();
  const [selectedDateRange, setSelectedDateRange] = useState("thisMonth");
  const [selectedProbability, setSelectedProbability] = useState("all");
  const [selectedTerritory, setSelectedTerritory] = useState("all");
  const [lastUpdated, setLastUpdated] = useState(/* @__PURE__ */ new Date());
  const [pipelineData, setPipelineData] = useState({});
  const [revenueData, setRevenueData] = useState([]);
  const [performanceData, setPerformanceData] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const loadDashboardData = async () => {
    if (!user)
      return;
    try {
      setLoading(true);
      setError("");
      const [
        pipelineDeals,
        revenueStats,
        performanceStats
      ] = await Promise.all(
        [
          dealsService?.getPipelineDeals(),
          dealsService?.getRevenueData(),
          dealsService?.getPerformanceMetrics()
        ]
      );
      setPipelineData(pipelineDeals);
      setRevenueData(revenueStats);
      setPerformanceData(performanceStats);
      setLastUpdated(/* @__PURE__ */ new Date());
    } catch (err) {
      console.error("Error loading dashboard data:", err);
      setError("Failed to load dashboard data. Please try again.");
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    if (user) {
      loadDashboardData();
    }
  }, [user]);
  useEffect(() => {
    const interval = setInterval(() => {
      if (user) {
        loadDashboardData();
      }
    }, 3e5);
    return () => clearInterval(interval);
  }, [user]);
  const onDragEnd = async (result) => {
    const { destination, source, draggableId } = result;
    if (!destination)
      return;
    if (destination?.droppableId === source?.droppableId && destination?.index === source?.index) {
      return;
    }
    try {
      await dealsService?.updateDealStage(draggableId, destination?.droppableId);
      const sourceStage = pipelineData?.[source?.droppableId];
      const destStage = pipelineData?.[destination?.droppableId];
      const draggedDeal = sourceStage?.deals?.find((deal) => deal?.id === draggableId);
      if (draggedDeal) {
        const stageProbs = {
          "lead": 10,
          "qualified": 25,
          "proposal": 50,
          "negotiation": 75,
          "closed_won": 100,
          "closed_lost": 0
        };
        const updatedDeal = {
          ...draggedDeal,
          probability: stageProbs?.[destination?.droppableId] || draggedDeal?.probability,
          daysInStage: 0
        };
        const newSourceDeals = sourceStage?.deals?.filter((deal) => deal?.id !== draggableId);
        const newDestDeals = [...destStage?.deals || []];
        newDestDeals?.splice(destination?.index, 0, updatedDeal);
        setPipelineData({
          ...pipelineData,
          [source?.droppableId]: {
            ...sourceStage,
            deals: newSourceDeals
          },
          [destination?.droppableId]: {
            ...destStage,
            deals: newDestDeals
          }
        });
      }
    } catch (err) {
      console.error("Error updating deal stage:", err);
      setError("Failed to update deal stage. Please try again.");
    }
  };
  const calculateStageTotal = (stage) => {
    return stage?.deals?.reduce((total, deal) => total + (deal?.value || 0), 0) || 0;
  };
  const calculateWeightedTotal = (stage) => {
    return stage?.deals?.reduce(
      (total, deal) => total + (deal?.value || 0) * (deal?.probability || 0) / 100,
      0
    ) || 0;
  };
  const totalPipelineValue = Object.values(pipelineData)?.reduce(
    (total, stage) => total + calculateStageTotal(stage),
    0
  );
  const weightedPipelineValue = Object.values(pipelineData)?.reduce(
    (total, stage) => total + calculateWeightedTotal(stage),
    0
  );
  const totalActiveDeals = Object.values(pipelineData)?.reduce(
    (total, stage) => total + (stage?.deals?.length || 0),
    0
  );
  if (authLoading) {
    return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:165:6", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "165", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22min-h-screen%20bg-background%20flex%20items-center%20justify-center%22%7D", className: "min-h-screen bg-background flex items-center justify-center", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:166:8", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "166", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-3%22%7D", className: "flex items-center space-x-3", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:167:10", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "167", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22animate-spin%20rounded-full%20h-8%20w-8%20border-b-2%20border-primary%22%7D", className: "animate-spin rounded-full h-8 w-8 border-b-2 border-primary" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
        lineNumber: 167,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:168:10", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "168", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-text-secondary%22%2C%22textContent%22%3A%22Loading%20dashboard...%22%7D", className: "text-text-secondary", children: "Loading dashboard..." }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
        lineNumber: 168,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
      lineNumber: 166,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
      lineNumber: 165,
      columnNumber: 7
    }, this);
  }
  if (!user) {
    return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:176:6", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "176", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22min-h-screen%20bg-background%22%7D", className: "min-h-screen bg-background", children: [
      /* @__PURE__ */ jsxDEV(Header, { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:177:8", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "177", "data-component-file": "index.jsx", "data-component-name": "Header", "data-component-content": "%7B%22elementName%22%3A%22Header%22%7D" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
        lineNumber: 177,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("main", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:179:8", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "179", "data-component-file": "index.jsx", "data-component-name": "main", "data-component-content": "%7B%22elementName%22%3A%22main%22%2C%22className%22%3A%22pt-20%20px-6%20pb-8%22%7D", className: "pt-20 px-6 pb-8", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:180:10", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "180", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22max-w-7xl%20mx-auto%22%7D", className: "max-w-7xl mx-auto", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:181:12", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "181", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-blue-50%20border%20border-blue-200%20p-4%20rounded-lg%20mb-6%22%7D", className: "bg-blue-50 border border-blue-200 p-4 rounded-lg mb-6", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:182:14", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "182", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%22%7D", className: "flex items-center space-x-2", children: [
          /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:183:16", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "183", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Info%22%2C%22className%22%3A%22text-blue-600%22%7D", name: "Info", size: 20, className: "text-blue-600" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
            lineNumber: 183,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:184:16", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "184", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
            /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:185:18", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "185", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-blue-800%20font-medium%22%2C%22textContent%22%3A%22Preview%20Mode%22%7D", className: "text-blue-800 font-medium", children: "Preview Mode" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 185,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:186:18", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "186", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-blue-700%20text-sm%22%2C%22textContent%22%3A%22This%20is%20how%20the%20sales%20dashboard%20looks%20when%20authenticated.%22%7D", className: "text-blue-700 text-sm", children: [
              "This is how the sales dashboard looks when authenticated.",
              " ",
              /* @__PURE__ */ jsxDEV("a", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:188:20", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "188", "data-component-file": "index.jsx", "data-component-name": "a", "data-component-content": "%7B%22elementName%22%3A%22a%22%2C%22href%22%3A%22%2Flogin%22%2C%22className%22%3A%22font-medium%20underline%20hover%3Atext-blue-800%22%2C%22textContent%22%3A%22Sign%20in%20to%20access%20real%20data%22%7D", href: "/login", className: "font-medium underline hover:text-blue-800", children: "Sign in to access real data" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                lineNumber: 188,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 186,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
            lineNumber: 184,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
          lineNumber: 182,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
          lineNumber: 181,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:196:12", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "196", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22opacity-75%22%7D", className: "opacity-75", children: [
          /* @__PURE__ */ jsxDEV("h1", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:197:14", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "197", "data-component-file": "index.jsx", "data-component-name": "h1", "data-component-content": "%7B%22elementName%22%3A%22h1%22%2C%22className%22%3A%22text-3xl%20font-bold%20text-text-primary%20mb-2%22%2C%22textContent%22%3A%22Sales%20Dashboard%22%7D", className: "text-3xl font-bold text-text-primary mb-2", children: "Sales Dashboard" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
            lineNumber: 197,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:198:14", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "198", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20mb-8%22%2C%22textContent%22%3A%22Preview%20of%20your%20sales%20pipeline%20and%20performance%20metrics%22%7D", className: "text-text-secondary mb-8", children: "Preview of your sales pipeline and performance metrics" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
            lineNumber: 198,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:203:14", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "203", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20md%3Agrid-cols-2%20lg%3Agrid-cols-4%20gap-6%20mb-8%22%7D", className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:204:16", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "204", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-6%22%7D", className: "card p-6", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:205:18", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "205", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:206:20", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "206", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
                /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:207:22", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "207", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20text-sm%22%2C%22textContent%22%3A%22Total%20Pipeline%22%7D", className: "text-text-secondary text-sm", children: "Total Pipeline" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                  lineNumber: 207,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:208:22", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "208", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-2xl%20font-normal%20text-text-primary%22%2C%22textContent%22%3A%22%242.1M%22%7D", className: "text-2xl font-normal text-text-primary", children: "$2.1M" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                  lineNumber: 208,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                lineNumber: 206,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:210:20", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "210", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-12%20h-12%20bg-primary-50%20rounded-lg%20flex%20items-center%20justify-center%22%7D", className: "w-12 h-12 bg-primary-50 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:211:22", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "211", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22TrendingUp%22%2C%22className%22%3A%22text-primary%22%7D", name: "TrendingUp", size: 24, className: "text-primary" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                lineNumber: 211,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                lineNumber: 210,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 205,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 204,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:216:16", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "216", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-6%22%7D", className: "card p-6", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:217:18", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "217", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:218:20", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "218", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
                /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:219:22", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "219", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20text-sm%22%2C%22textContent%22%3A%22Weighted%20Pipeline%22%7D", className: "text-text-secondary text-sm", children: "Weighted Pipeline" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                  lineNumber: 219,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:220:22", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "220", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-2xl%20font-normal%20text-text-primary%22%2C%22textContent%22%3A%22%241.2M%22%7D", className: "text-2xl font-normal text-text-primary", children: "$1.2M" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                  lineNumber: 220,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                lineNumber: 218,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:222:20", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "222", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-12%20h-12%20bg-success-50%20rounded-lg%20flex%20items-center%20justify-center%22%7D", className: "w-12 h-12 bg-success-50 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:223:22", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "223", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Target%22%2C%22className%22%3A%22text-success%22%7D", name: "Target", size: 24, className: "text-success" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                lineNumber: 223,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                lineNumber: 222,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 217,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 216,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:228:16", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "228", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-6%22%7D", className: "card p-6", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:229:18", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "229", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:230:20", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "230", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
                /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:231:22", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "231", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20text-sm%22%2C%22textContent%22%3A%22Active%20Deals%22%7D", className: "text-text-secondary text-sm", children: "Active Deals" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                  lineNumber: 231,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:232:22", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "232", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-2xl%20font-normal%20text-text-primary%22%2C%22textContent%22%3A%2224%22%7D", className: "text-2xl font-normal text-text-primary", children: "24" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                  lineNumber: 232,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                lineNumber: 230,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:234:20", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "234", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-12%20h-12%20bg-secondary-50%20rounded-lg%20flex%20items-center%20justify-center%22%7D", className: "w-12 h-12 bg-secondary-50 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:235:22", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "235", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Briefcase%22%2C%22className%22%3A%22text-secondary%22%7D", name: "Briefcase", size: 24, className: "text-secondary" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                lineNumber: 235,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                lineNumber: 234,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 229,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 228,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:240:16", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "240", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-6%22%7D", className: "card p-6", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:241:18", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "241", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:242:20", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "242", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
                /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:243:22", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "243", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20text-sm%22%2C%22textContent%22%3A%22Quota%20Achievement%22%7D", className: "text-text-secondary text-sm", children: "Quota Achievement" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                  lineNumber: 243,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:244:22", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "244", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-2xl%20font-normal%20text-text-primary%22%2C%22textContent%22%3A%2274%25%22%7D", className: "text-2xl font-normal text-text-primary", children: "74%" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                  lineNumber: 244,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                lineNumber: 242,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:246:20", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "246", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-12%20h-12%20bg-accent-50%20rounded-lg%20flex%20items-center%20justify-center%22%7D", className: "w-12 h-12 bg-accent-50 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:247:22", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "247", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Award%22%2C%22className%22%3A%22text-accent%22%7D", name: "Award", size: 24, className: "text-accent" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                lineNumber: 247,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                lineNumber: 246,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 241,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 240,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
            lineNumber: 203,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:253:14", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "253", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-6%22%7D", className: "card p-6", children: [
            /* @__PURE__ */ jsxDEV("h2", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:254:16", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "254", "data-component-file": "index.jsx", "data-component-name": "h2", "data-component-content": "%7B%22elementName%22%3A%22h2%22%2C%22className%22%3A%22text-xl%20font-normal%20text-text-primary%20mb-6%22%2C%22textContent%22%3A%22Pipeline%20Preview%22%7D", className: "text-xl font-normal text-text-primary mb-6", children: "Pipeline Preview" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 254,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:255:16", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "255", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-center%20py-12%22%7D", className: "text-center py-12", children: [
              /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:256:18", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "256", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22BarChart3%22%2C%22className%22%3A%22text-text-tertiary%20mx-auto%20mb-4%22%7D", name: "BarChart3", size: 48, className: "text-text-tertiary mx-auto mb-4" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                lineNumber: 256,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:257:18", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "257", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%22%2C%22textContent%22%3A%22Sign%20in%20to%20view%20your%20interactive%20sales%20pipeline%22%7D", className: "text-text-secondary", children: "Sign in to view your interactive sales pipeline" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                lineNumber: 257,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 255,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
            lineNumber: 253,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
          lineNumber: 196,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
        lineNumber: 180,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
        lineNumber: 179,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
      lineNumber: 176,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:268:4", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "268", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22min-h-screen%20bg-background%22%7D", className: "min-h-screen bg-background", children: [
    /* @__PURE__ */ jsxDEV(Header, { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:269:6", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "269", "data-component-file": "index.jsx", "data-component-name": "Header", "data-component-content": "%7B%22elementName%22%3A%22Header%22%7D" }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
      lineNumber: 269,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("main", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:270:6", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "270", "data-component-file": "index.jsx", "data-component-name": "main", "data-component-content": "%7B%22elementName%22%3A%22main%22%2C%22className%22%3A%22pt-20%20px-6%20pb-8%22%7D", className: "pt-20 px-6 pb-8", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:271:8", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "271", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22max-w-7xl%20mx-auto%22%7D", className: "max-w-7xl mx-auto", children: [
      /* @__PURE__ */ jsxDEV(Breadcrumb, { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:272:10", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "272", "data-component-file": "index.jsx", "data-component-name": "Breadcrumb", "data-component-content": "%7B%22elementName%22%3A%22Breadcrumb%22%7D" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
        lineNumber: 272,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:275:10", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "275", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20flex-col%20lg%3Aflex-row%20lg%3Aitems-center%20lg%3Ajustify-between%20mb-8%22%7D", className: "flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:276:12", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "276", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("h1", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:277:14", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "277", "data-component-file": "index.jsx", "data-component-name": "h1", "data-component-content": "%7B%22elementName%22%3A%22h1%22%2C%22className%22%3A%22text-3xl%20font-bold%20text-text-primary%20mb-2%22%2C%22textContent%22%3A%22Sales%20Dashboard%22%7D", className: "text-3xl font-bold text-text-primary mb-2", children: "Sales Dashboard" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
            lineNumber: 277,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:278:14", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "278", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%22%2C%22textContent%22%3A%22Last%20updated%3A%20%E2%80%A2%20Auto-refresh%20every%205%20minutes%22%7D", className: "text-text-secondary", children: [
            "Last updated: ",
            lastUpdated?.toLocaleTimeString(),
            " • Auto-refresh every 5 minutes"
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
            lineNumber: 278,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
          lineNumber: 276,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:284:12", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "284", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20flex-col%20sm%3Aflex-row%20gap-4%20mt-4%20lg%3Amt-0%22%7D", className: "flex flex-col sm:flex-row gap-4 mt-4 lg:mt-0", children: [
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:285:14",
              "data-component-path": "src\\pages\\sales-dashboard\\index.jsx",
              "data-component-line": "285",
              "data-component-file": "index.jsx",
              "data-component-name": "select",
              "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22value%22%3A%22%5Bvar%3AselectedDateRange%5D%22%2C%22className%22%3A%22input-field%20text-sm%22%7D",
              value: selectedDateRange,
              onChange: (e) => setSelectedDateRange(e?.target?.value),
              className: "input-field text-sm",
              children: [
                /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:290:16", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "290", "data-component-file": "index.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22thisWeek%22%2C%22textContent%22%3A%22This%20Week%22%7D", value: "thisWeek", children: "This Week" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                  lineNumber: 290,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:291:16", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "291", "data-component-file": "index.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22thisMonth%22%2C%22textContent%22%3A%22This%20Month%22%7D", value: "thisMonth", children: "This Month" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                  lineNumber: 291,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:292:16", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "292", "data-component-file": "index.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22thisQuarter%22%2C%22textContent%22%3A%22This%20Quarter%22%7D", value: "thisQuarter", children: "This Quarter" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                  lineNumber: 292,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:293:16", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "293", "data-component-file": "index.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22thisYear%22%2C%22textContent%22%3A%22This%20Year%22%7D", value: "thisYear", children: "This Year" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                  lineNumber: 293,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 285,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:296:14",
              "data-component-path": "src\\pages\\sales-dashboard\\index.jsx",
              "data-component-line": "296",
              "data-component-file": "index.jsx",
              "data-component-name": "select",
              "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22value%22%3A%22%5Bvar%3AselectedProbability%5D%22%2C%22className%22%3A%22input-field%20text-sm%22%7D",
              value: selectedProbability,
              onChange: (e) => setSelectedProbability(e?.target?.value),
              className: "input-field text-sm",
              children: [
                /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:301:16", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "301", "data-component-file": "index.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22all%22%2C%22textContent%22%3A%22All%20Probabilities%22%7D", value: "all", children: "All Probabilities" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                  lineNumber: 301,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:302:16", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "302", "data-component-file": "index.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22high%22%2C%22textContent%22%3A%22High%20(%3E70%25)%22%7D", value: "high", children: "High (>70%)" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                  lineNumber: 302,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:303:16", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "303", "data-component-file": "index.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22medium%22%2C%22textContent%22%3A%22Medium%20(30-70%25)%22%7D", value: "medium", children: "Medium (30-70%)" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                  lineNumber: 303,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:304:16", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "304", "data-component-file": "index.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22low%22%2C%22textContent%22%3A%22Low%20(%3C30%25)%22%7D", value: "low", children: "Low (<30%)" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                  lineNumber: 304,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 296,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:307:14",
              "data-component-path": "src\\pages\\sales-dashboard\\index.jsx",
              "data-component-line": "307",
              "data-component-file": "index.jsx",
              "data-component-name": "select",
              "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22value%22%3A%22%5Bvar%3AselectedTerritory%5D%22%2C%22className%22%3A%22input-field%20text-sm%22%7D",
              value: selectedTerritory,
              onChange: (e) => setSelectedTerritory(e?.target?.value),
              className: "input-field text-sm",
              children: [
                /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:312:16", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "312", "data-component-file": "index.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22all%22%2C%22textContent%22%3A%22All%20Territories%22%7D", value: "all", children: "All Territories" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                  lineNumber: 312,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:313:16", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "313", "data-component-file": "index.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22north%22%2C%22textContent%22%3A%22North%20America%22%7D", value: "north", children: "North America" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                  lineNumber: 313,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:314:16", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "314", "data-component-file": "index.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22europe%22%2C%22textContent%22%3A%22Europe%22%7D", value: "europe", children: "Europe" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                  lineNumber: 314,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:315:16", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "315", "data-component-file": "index.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22asia%22%2C%22textContent%22%3A%22Asia%20Pacific%22%7D", value: "asia", children: "Asia Pacific" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                  lineNumber: 315,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 307,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
          lineNumber: 284,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
        lineNumber: 275,
        columnNumber: 11
      }, this),
      error && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:322:10", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "322", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-error-50%20border%20border-error-200%20text-error%20p-4%20rounded-lg%20mb-6%20flex%20items-center%20space-x-2%22%7D", className: "bg-error-50 border border-error-200 text-error p-4 rounded-lg mb-6 flex items-center space-x-2", children: [
        /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:323:14", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "323", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22AlertCircle%22%7D", name: "AlertCircle", size: 20 }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
          lineNumber: 323,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:324:14", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "324", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: error }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
          lineNumber: 324,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:325:14",
            "data-component-path": "src\\pages\\sales-dashboard\\index.jsx",
            "data-component-line": "325",
            "data-component-file": "index.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22ml-auto%20text-error%20hover%3Atext-error-600%22%7D",
            onClick: () => setError(""),
            className: "ml-auto text-error hover:text-error-600",
            children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:329:16", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "329", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22X%22%7D", name: "X", size: 16 }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 329,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
            lineNumber: 325,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
        lineNumber: 322,
        columnNumber: 11
      }, this),
      loading ? /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:336:10", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "336", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-center%20py-12%22%7D", className: "flex items-center justify-center py-12", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:337:14", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "337", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-3%22%7D", className: "flex items-center space-x-3", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:338:16", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "338", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22animate-spin%20rounded-full%20h-8%20w-8%20border-b-2%20border-primary%22%7D", className: "animate-spin rounded-full h-8 w-8 border-b-2 border-primary" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
          lineNumber: 338,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:339:16", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "339", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-text-secondary%22%2C%22textContent%22%3A%22Loading%20dashboard%20data...%22%7D", className: "text-text-secondary", children: "Loading dashboard data..." }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
          lineNumber: 339,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
        lineNumber: 337,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
        lineNumber: 336,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:345:14", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "345", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20md%3Agrid-cols-2%20lg%3Agrid-cols-4%20gap-6%20mb-8%22%7D", className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:346:16", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "346", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-6%22%7D", className: "card p-6", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:347:18", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "347", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:348:20", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "348", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:349:22", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "349", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20text-sm%20font-normal%22%2C%22textContent%22%3A%22Total%20Pipeline%22%7D", className: "text-text-secondary text-sm font-normal", children: "Total Pipeline" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                lineNumber: 349,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:350:22", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "350", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-2xl%20font-normal%20text-text-primary%22%2C%22textContent%22%3A%22%24%20M%22%7D", className: "text-2xl font-normal text-text-primary", children: [
                "$",
                (totalPipelineValue / 1e6)?.toFixed(1),
                "M"
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                lineNumber: 350,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 348,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:354:20", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "354", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-12%20h-12%20bg-primary-50%20rounded-lg%20flex%20items-center%20justify-center%22%7D", className: "w-12 h-12 bg-primary-50 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:355:22", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "355", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22TrendingUp%22%2C%22className%22%3A%22text-primary%22%7D", name: "TrendingUp", size: 24, className: "text-primary" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 355,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 354,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
            lineNumber: 347,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
            lineNumber: 346,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:360:16", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "360", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-6%22%7D", className: "card p-6", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:361:18", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "361", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:362:20", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "362", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:363:22", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "363", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20text-sm%20font-normal%22%2C%22textContent%22%3A%22Weighted%20Pipeline%22%7D", className: "text-text-secondary text-sm font-normal", children: "Weighted Pipeline" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                lineNumber: 363,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:364:22", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "364", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-2xl%20font-normal%20text-text-primary%22%2C%22textContent%22%3A%22%24%20M%22%7D", className: "text-2xl font-normal text-text-primary", children: [
                "$",
                (weightedPipelineValue / 1e6)?.toFixed(1),
                "M"
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                lineNumber: 364,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 362,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:368:20", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "368", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-12%20h-12%20bg-success-50%20rounded-lg%20flex%20items-center%20justify-center%22%7D", className: "w-12 h-12 bg-success-50 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:369:22", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "369", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Target%22%2C%22className%22%3A%22text-success%22%7D", name: "Target", size: 24, className: "text-success" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 369,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 368,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
            lineNumber: 361,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
            lineNumber: 360,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:374:16", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "374", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-6%22%7D", className: "card p-6", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:375:18", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "375", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:376:20", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "376", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:377:22", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "377", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20text-sm%20font-normal%22%2C%22textContent%22%3A%22Active%20Deals%22%7D", className: "text-text-secondary text-sm font-normal", children: "Active Deals" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                lineNumber: 377,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:378:22", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "378", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-2xl%20font-normal%20text-text-primary%22%7D", className: "text-2xl font-normal text-text-primary", children: totalActiveDeals }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                lineNumber: 378,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 376,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:380:20", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "380", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-12%20h-12%20bg-secondary-50%20rounded-lg%20flex%20items-center%20justify-center%22%7D", className: "w-12 h-12 bg-secondary-50 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:381:22", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "381", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Briefcase%22%2C%22className%22%3A%22text-secondary%22%7D", name: "Briefcase", size: 24, className: "text-secondary" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 381,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 380,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
            lineNumber: 375,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
            lineNumber: 374,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:386:16", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "386", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-6%22%7D", className: "card p-6", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:387:18", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "387", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:388:20", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "388", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:389:22", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "389", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20text-sm%20font-normal%22%2C%22textContent%22%3A%22Quota%20Achievement%22%7D", className: "text-text-secondary text-sm font-normal", children: "Quota Achievement" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                lineNumber: 389,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:390:22", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "390", "data-component-file": "index.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-2xl%20font-normal%20text-text-primary%22%2C%22textContent%22%3A%22%25%22%7D", className: "text-2xl font-normal text-text-primary", children: [
                performanceData?.percentage || 0,
                "%"
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                lineNumber: 390,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 388,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:392:20", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "392", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-12%20h-12%20bg-accent-50%20rounded-lg%20flex%20items-center%20justify-center%22%7D", className: "w-12 h-12 bg-accent-50 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:393:22", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "393", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Award%22%2C%22className%22%3A%22text-accent%22%7D", name: "Award", size: 24, className: "text-accent" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 393,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 392,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
            lineNumber: 387,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
            lineNumber: 386,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
          lineNumber: 345,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:399:14", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "399", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20xl%3Agrid-cols-4%20gap-8%22%7D", className: "grid grid-cols-1 xl:grid-cols-4 gap-8", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:401:16", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "401", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22xl%3Acol-span-3%20space-y-8%22%7D", className: "xl:col-span-3 space-y-8", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:403:18", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "403", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-6%22%7D", className: "card p-6", children: [
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:404:20", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "404", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%20mb-6%22%7D", className: "flex items-center justify-between mb-6", children: [
                /* @__PURE__ */ jsxDEV("h2", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:405:22", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "405", "data-component-file": "index.jsx", "data-component-name": "h2", "data-component-content": "%7B%22elementName%22%3A%22h2%22%2C%22className%22%3A%22text-xl%20font-normal%20text-text-primary%22%2C%22textContent%22%3A%22Sales%20Pipeline%22%7D", className: "text-xl font-normal text-text-primary", children: "Sales Pipeline" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                  lineNumber: 405,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:406:22", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "406", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%20text-sm%20text-text-secondary%22%7D", className: "flex items-center space-x-2 text-sm text-text-secondary", children: [
                  /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:407:24", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "407", "data-component-file": "index.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22RefreshCw%22%7D", name: "RefreshCw", size: 16 }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                    lineNumber: 407,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:408:24", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "408", "data-component-file": "index.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Drag%20deals%20to%20update%20stages%22%7D", children: "Drag deals to update stages" }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                    lineNumber: 408,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                  lineNumber: 406,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                lineNumber: 404,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(DragDropContext, { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:412:20", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "412", "data-component-file": "index.jsx", "data-component-name": "DragDropContext", "data-component-content": "%7B%22elementName%22%3A%22DragDropContext%22%7D", onDragEnd, children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:413:22", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "413", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20md%3Agrid-cols-2%20lg%3Agrid-cols-5%20gap-4%22%7D", className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4", children: Object.values(pipelineData)?.map(
                (stage) => /* @__PURE__ */ jsxDEV(
                  PipelineStage,
                  {
                    "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:415:22",
                    "data-component-path": "src\\pages\\sales-dashboard\\index.jsx",
                    "data-component-line": "415",
                    "data-component-file": "index.jsx",
                    "data-component-name": "PipelineStage",
                    "data-component-content": "%7B%22elementName%22%3A%22PipelineStage%22%7D",
                    stage,
                    totalValue: calculateStageTotal(stage),
                    weightedValue: calculateWeightedTotal(stage)
                  },
                  stage?.id,
                  false,
                  {
                    fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                    lineNumber: 415,
                    columnNumber: 23
                  },
                  this
                )
              ) }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                lineNumber: 413,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                lineNumber: 412,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 403,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:427:18", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "427", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-6%22%7D", className: "card p-6", children: [
              /* @__PURE__ */ jsxDEV("h2", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:428:20", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "428", "data-component-file": "index.jsx", "data-component-name": "h2", "data-component-content": "%7B%22elementName%22%3A%22h2%22%2C%22className%22%3A%22text-xl%20font-normal%20text-text-primary%20mb-6%22%2C%22textContent%22%3A%22Monthly%20Revenue%20Forecast%22%7D", className: "text-xl font-normal text-text-primary mb-6", children: "Monthly Revenue Forecast" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                lineNumber: 428,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:429:20", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "429", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22h-80%22%7D", className: "h-80", children: /* @__PURE__ */ jsxDEV(ResponsiveContainer, { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:430:22", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "430", "data-component-file": "index.jsx", "data-component-name": "ResponsiveContainer", "data-component-content": "%7B%22elementName%22%3A%22ResponsiveContainer%22%7D", width: "100%", height: "100%", children: /* @__PURE__ */ jsxDEV(BarChart, { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:431:24", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "431", "data-component-file": "index.jsx", "data-component-name": "BarChart", "data-component-content": "%7B%22elementName%22%3A%22BarChart%22%7D", data: revenueData, children: [
                /* @__PURE__ */ jsxDEV(CartesianGrid, { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:432:26", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "432", "data-component-file": "index.jsx", "data-component-name": "CartesianGrid", "data-component-content": "%7B%22elementName%22%3A%22CartesianGrid%22%7D", strokeDasharray: "3 3", stroke: "#E5E7EB" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                  lineNumber: 432,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV(XAxis, { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:433:26", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "433", "data-component-file": "index.jsx", "data-component-name": "XAxis", "data-component-content": "%7B%22elementName%22%3A%22XAxis%22%7D", dataKey: "month", stroke: "#6B7280" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                  lineNumber: 433,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV(YAxis, { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:434:26", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "434", "data-component-file": "index.jsx", "data-component-name": "YAxis", "data-component-content": "%7B%22elementName%22%3A%22YAxis%22%7D", stroke: "#6B7280", tickFormatter: (value) => `$${value / 1e3}K` }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                  lineNumber: 434,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Tooltip,
                  {
                    "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:435:26",
                    "data-component-path": "src\\pages\\sales-dashboard\\index.jsx",
                    "data-component-line": "435",
                    "data-component-file": "index.jsx",
                    "data-component-name": "Tooltip",
                    "data-component-content": "%7B%22elementName%22%3A%22Tooltip%22%7D",
                    formatter: (value) => [`$${value?.toLocaleString()}`, ""],
                    labelStyle: { color: "#1F2937" }
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                    lineNumber: 435,
                    columnNumber: 27
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(Bar, { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:439:26", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "439", "data-component-file": "index.jsx", "data-component-name": "Bar", "data-component-content": "%7B%22elementName%22%3A%22Bar%22%2C%22name%22%3A%22Forecast%22%7D", dataKey: "forecast", fill: "var(--color-primary)", name: "Forecast" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                  lineNumber: 439,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV(Bar, { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:440:26", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "440", "data-component-file": "index.jsx", "data-component-name": "Bar", "data-component-content": "%7B%22elementName%22%3A%22Bar%22%2C%22name%22%3A%22Actual%22%7D", dataKey: "actual", fill: "var(--color-success)", name: "Actual" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                  lineNumber: 440,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                lineNumber: 431,
                columnNumber: 25
              }, this) }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                lineNumber: 430,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
                lineNumber: 429,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 427,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(PerformanceMetrics, { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:447:18", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "447", "data-component-file": "index.jsx", "data-component-name": "PerformanceMetrics", "data-component-content": "%7B%22elementName%22%3A%22PerformanceMetrics%22%7D", data: performanceData }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 447,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
            lineNumber: 401,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:451:16", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "451", "data-component-file": "index.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-6%22%7D", className: "space-y-6", children: [
            /* @__PURE__ */ jsxDEV(QuickActions, { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:453:18", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "453", "data-component-file": "index.jsx", "data-component-name": "QuickActions", "data-component-content": "%7B%22elementName%22%3A%22QuickActions%22%7D" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 453,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(UpcomingTasks, { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:456:18", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "456", "data-component-file": "index.jsx", "data-component-name": "UpcomingTasks", "data-component-content": "%7B%22elementName%22%3A%22UpcomingTasks%22%7D" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 456,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(RecentActivity, { "data-component-id": "src\\pages\\sales-dashboard\\index.jsx:459:18", "data-component-path": "src\\pages\\sales-dashboard\\index.jsx", "data-component-line": "459", "data-component-file": "index.jsx", "data-component-name": "RecentActivity", "data-component-content": "%7B%22elementName%22%3A%22RecentActivity%22%7D" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
              lineNumber: 459,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
            lineNumber: 451,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
          lineNumber: 399,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
        lineNumber: 343,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
      lineNumber: 271,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
      lineNumber: 270,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx",
    lineNumber: 268,
    columnNumber: 5
  }, this);
};
_s(SalesDashboard, "r30mfZZnAJvWeHatuKZOL32uJeo=", false, function() {
  return [useAuth];
});
_c = SalesDashboard;
export default SalesDashboard;
var _c;
$RefreshReg$(_c, "SalesDashboard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/sales-dashboard/index.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0tVLFNBZ0xFLFVBaExGOzJCQXRLVjtBQUFnQkEsTUFBVUMsY0FBUyxPQUFRLHNCQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ2xELFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxVQUFVQyxLQUFLQyxPQUFPQyxPQUFPQyxlQUFlQyxTQUFTQywyQkFBMkI7QUFDekYsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxnQkFBZ0I7QUFDdkIsT0FBT0MsVUFBVTtBQUNqQixTQUFTQyxlQUFlO0FBRXhCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0MsbUJBQW1CO0FBQzFCLE9BQU9DLG1CQUFtQjtBQUMxQixPQUFPQyx3QkFBd0I7QUFFL0IsT0FBT0Msa0JBQWtCO0FBSXpCLE1BQU1DLGlCQUFpQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzNCLFFBQU0sRUFBRUMsTUFBTUMsU0FBU0MsWUFBWSxJQUFJWCxRQUFRO0FBQy9DLFFBQU0sQ0FBQ1ksbUJBQW1CQyxvQkFBb0IsSUFBSTFCLFNBQVMsV0FBVztBQUN0RSxRQUFNLENBQUMyQixxQkFBcUJDLHNCQUFzQixJQUFJNUIsU0FBUyxLQUFLO0FBQ3BFLFFBQU0sQ0FBQzZCLG1CQUFtQkMsb0JBQW9CLElBQUk5QixTQUFTLEtBQUs7QUFDaEUsUUFBTSxDQUFDK0IsYUFBYUMsY0FBYyxJQUFJaEMsU0FBUyxvQkFBSWlDLEtBQUssQ0FBQztBQUN6RCxRQUFNLENBQUNDLGNBQWNDLGVBQWUsSUFBSW5DLFNBQVMsQ0FBQyxDQUFDO0FBQ25ELFFBQU0sQ0FBQ29DLGFBQWFDLGNBQWMsSUFBSXJDLFNBQVMsRUFBRTtBQUNqRCxRQUFNLENBQUNzQyxpQkFBaUJDLGtCQUFrQixJQUFJdkMsU0FBUyxDQUFDLENBQUM7QUFDekQsUUFBTSxDQUFDdUIsU0FBU2lCLFVBQVUsSUFBSXhDLFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUN5QyxPQUFPQyxRQUFRLElBQUkxQyxTQUFTLEVBQUU7QUFHckMsUUFBTTJDLG9CQUFvQixZQUFZO0FBQ3BDLFFBQUksQ0FBQ3JCO0FBQU07QUFFWCxRQUFJO0FBQ0ZrQixpQkFBVyxJQUFJO0FBQ2ZFLGVBQVMsRUFBRTtBQUdYLFlBQU07QUFBQSxRQUNKRTtBQUFBQSxRQUNBQztBQUFBQSxRQUNBQztBQUFBQSxNQUFnQixJQUNkLE1BQU1DLFFBQVFDO0FBQUFBLFFBQUk7QUFBQSxVQUNwQjdCLGNBQWM4QixpQkFBaUI7QUFBQSxVQUMvQjlCLGNBQWMrQixlQUFlO0FBQUEsVUFDN0IvQixjQUFjZ0Msc0JBQXNCO0FBQUEsUUFBQztBQUFBLE1BQ3RDO0FBRURoQixzQkFBZ0JTLGFBQWE7QUFDN0JQLHFCQUFlUSxZQUFZO0FBQzNCTix5QkFBbUJPLGdCQUFnQjtBQUNuQ2QscUJBQWUsb0JBQUlDLEtBQUssQ0FBQztBQUFBLElBRTNCLFNBQVNtQixLQUFLO0FBQ1pDLGNBQVFaLE1BQU0saUNBQWlDVyxHQUFHO0FBQ2xEVixlQUFTLGtEQUFrRDtBQUFBLElBQzdELFVBQUM7QUFDQ0YsaUJBQVcsS0FBSztBQUFBLElBQ2xCO0FBQUEsRUFDRjtBQUdBdkMsWUFBVSxNQUFNO0FBQ2QsUUFBSXFCLE1BQU07QUFDUnFCLHdCQUFrQjtBQUFBLElBQ3BCO0FBQUEsRUFDRixHQUFHLENBQUNyQixJQUFJLENBQUM7QUFFVHJCLFlBQVUsTUFBTTtBQUNkLFVBQU1xRCxXQUFXQyxZQUFZLE1BQU07QUFDakMsVUFBSWpDLE1BQU07QUFDUnFCLDBCQUFrQjtBQUFBLE1BQ3BCO0FBQUEsSUFDRixHQUFHLEdBQU07QUFFVCxXQUFPLE1BQU1hLGNBQWNGLFFBQVE7QUFBQSxFQUNyQyxHQUFHLENBQUNoQyxJQUFJLENBQUM7QUFHVCxRQUFNbUMsWUFBWSxPQUFPQyxXQUFXO0FBQ2xDLFVBQU0sRUFBRUMsYUFBYUMsUUFBUUMsWUFBWSxJQUFJSDtBQUU3QyxRQUFJLENBQUNDO0FBQWE7QUFDbEIsUUFBSUEsYUFBYUcsZ0JBQWdCRixRQUFRRSxlQUFlSCxhQUFhSSxVQUFVSCxRQUFRRyxPQUFPO0FBQzVGO0FBQUEsSUFDRjtBQUVBLFFBQUk7QUFFRixZQUFNNUMsY0FBYzZDLGdCQUFnQkgsYUFBYUYsYUFBYUcsV0FBVztBQUd6RSxZQUFNRyxjQUFjL0IsZUFBZTBCLFFBQVFFLFdBQVc7QUFDdEQsWUFBTUksWUFBWWhDLGVBQWV5QixhQUFhRyxXQUFXO0FBQ3pELFlBQU1LLGNBQWNGLGFBQWFHLE9BQU9DLEtBQUssQ0FBQUMsU0FBUUEsTUFBTUMsT0FBT1YsV0FBVztBQUU3RSxVQUFJTSxhQUFhO0FBQ2YsY0FBTUssYUFBYTtBQUFBLFVBQ2pCLFFBQVE7QUFBQSxVQUNSLGFBQWE7QUFBQSxVQUNiLFlBQVk7QUFBQSxVQUNaLGVBQWU7QUFBQSxVQUNmLGNBQWM7QUFBQSxVQUNkLGVBQWU7QUFBQSxRQUNqQjtBQUVBLGNBQU1DLGNBQWM7QUFBQSxVQUNsQixHQUFHTjtBQUFBQSxVQUNITyxhQUFhRixhQUFhYixhQUFhRyxXQUFXLEtBQUtLLGFBQWFPO0FBQUFBLFVBQ3BFQyxhQUFhO0FBQUEsUUFDZjtBQUdBLGNBQU1DLGlCQUFpQlgsYUFBYUcsT0FBT1MsT0FBTyxDQUFBUCxTQUFRQSxNQUFNQyxPQUFPVixXQUFXO0FBR2xGLGNBQU1pQixlQUFlLENBQUMsR0FBSVosV0FBV0UsU0FBUyxFQUFHO0FBQ2pEVSxzQkFBY0MsT0FBT3BCLGFBQWFJLE9BQU8sR0FBR1UsV0FBVztBQUV2RHRDLHdCQUFnQjtBQUFBLFVBQ2QsR0FBR0Q7QUFBQUEsVUFDSCxDQUFDMEIsUUFBUUUsV0FBVyxHQUFHO0FBQUEsWUFDckIsR0FBR0c7QUFBQUEsWUFDSEcsT0FBT1E7QUFBQUEsVUFDVDtBQUFBLFVBQ0EsQ0FBQ2pCLGFBQWFHLFdBQVcsR0FBRztBQUFBLFlBQzFCLEdBQUdJO0FBQUFBLFlBQ0hFLE9BQU9VO0FBQUFBLFVBQ1Q7QUFBQSxRQUNGLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRixTQUFTMUIsS0FBSztBQUNaQyxjQUFRWixNQUFNLDhCQUE4QlcsR0FBRztBQUMvQ1YsZUFBUyxnREFBZ0Q7QUFBQSxJQUMzRDtBQUFBLEVBQ0Y7QUFHQSxRQUFNc0Msc0JBQXNCQSxDQUFDQyxVQUFVO0FBQ3JDLFdBQU9BLE9BQU9iLE9BQU9jLE9BQU8sQ0FBQ0MsT0FBT2IsU0FBU2EsU0FBU2IsTUFBTWMsU0FBUyxJQUFJLENBQUMsS0FBSztBQUFBLEVBQ2pGO0FBRUEsUUFBTUMseUJBQXlCQSxDQUFDSixVQUFVO0FBQ3hDLFdBQU9BLE9BQU9iLE9BQU9jO0FBQUFBLE1BQU8sQ0FBQ0MsT0FBT2IsU0FDbENhLFNBQVViLE1BQU1jLFNBQVMsTUFBTWQsTUFBTUksZUFBZSxLQUFLO0FBQUEsTUFBTTtBQUFBLElBQ2pFLEtBQUs7QUFBQSxFQUNQO0FBRUEsUUFBTVkscUJBQXFCQyxPQUFPQyxPQUFPdEQsWUFBWSxHQUFHZ0Q7QUFBQUEsSUFBTyxDQUFDQyxPQUFPRixVQUNyRUUsUUFBUUgsb0JBQW9CQyxLQUFLO0FBQUEsSUFBRztBQUFBLEVBQ3RDO0FBRUEsUUFBTVEsd0JBQXdCRixPQUFPQyxPQUFPdEQsWUFBWSxHQUFHZ0Q7QUFBQUEsSUFBTyxDQUFDQyxPQUFPRixVQUN4RUUsUUFBUUUsdUJBQXVCSixLQUFLO0FBQUEsSUFBRztBQUFBLEVBQ3pDO0FBRUEsUUFBTVMsbUJBQW1CSCxPQUFPQyxPQUFPdEQsWUFBWSxHQUFHZ0Q7QUFBQUEsSUFBTyxDQUFDQyxPQUFPRixVQUNuRUUsU0FBU0YsT0FBT2IsT0FBT3VCLFVBQVU7QUFBQSxJQUFJO0FBQUEsRUFDdkM7QUFHQSxNQUFJbkUsYUFBYTtBQUNmLFdBQ0UsdUJBQUMsOFlBQUksV0FBVSwrREFDYixpQ0FBQywwV0FBSSxXQUFVLCtCQUNiO0FBQUEsNkJBQUMsaVpBQUksV0FBVSxpRUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZFO0FBQUEsTUFDN0UsdUJBQUMscVpBQUssV0FBVSx1QkFBc0Isb0NBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEQ7QUFBQSxTQUY1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxFQUVKO0FBRUEsTUFBSSxDQUFDRixNQUFNO0FBQ1QsV0FDRSx1QkFBQyx1V0FBSSxXQUFVLDhCQUNiO0FBQUEsNkJBQUMseVRBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFPO0FBQUEsTUFFUCx1QkFBQyxpV0FBSyxXQUFVLG1CQUNkLGlDQUFDLCtWQUFJLFdBQVUscUJBQ2I7QUFBQSwrQkFBQywyWUFBSSxXQUFVLHlEQUNiLGlDQUFDLDJXQUFJLFdBQVUsK0JBQ2I7QUFBQSxpQ0FBQyxvWEFBSyxNQUFLLFFBQU8sTUFBTSxJQUFJLFdBQVUsbUJBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFEO0FBQUEsVUFDckQsdUJBQUMsaVRBQ0M7QUFBQSxtQ0FBQyw0WUFBRSxXQUFVLDZCQUE0Qiw0QkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUQ7QUFBQSxZQUNyRCx1QkFBQyxtY0FBRSxXQUFVLHlCQUF3QjtBQUFBO0FBQUEsY0FDdUI7QUFBQSxjQUMxRCx1QkFBQyxxZEFBRSxNQUFLLFVBQVMsV0FBVSw2Q0FBNEMsMkNBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsZUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsYUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0EsS0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYUE7QUFBQSxRQUVBLHVCQUFDLHNWQUFJLFdBQVUsY0FDYjtBQUFBLGlDQUFDLHNhQUFHLFdBQVUsNkNBQTRDLCtCQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RTtBQUFBLFVBQ3pFLHVCQUFDLGljQUFFLFdBQVUsNEJBQTJCLHNFQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFHQSx1QkFBQyxtWkFBSSxXQUFVLDZEQUNiO0FBQUEsbUNBQUMsc1ZBQUksV0FBVSxZQUNiLGlDQUFDLGlYQUFJLFdBQVUscUNBQ2I7QUFBQSxxQ0FBQyxpVEFDQztBQUFBLHVDQUFDLGdaQUFFLFdBQVUsK0JBQThCLDhCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5RDtBQUFBLGdCQUN6RCx1QkFBQyxvWkFBRSxXQUFVLDBDQUF5QyxxQkFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkQ7QUFBQSxtQkFGN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsMlpBQUksV0FBVSx1RUFDYixpQ0FBQyx5WEFBSyxNQUFLLGNBQWEsTUFBTSxJQUFJLFdBQVUsa0JBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBELEtBRDVEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLFlBRUEsdUJBQUMsc1ZBQUksV0FBVSxZQUNiLGlDQUFDLGlYQUFJLFdBQVUscUNBQ2I7QUFBQSxxQ0FBQyxpVEFDQztBQUFBLHVDQUFDLG1aQUFFLFdBQVUsK0JBQThCLGlDQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE0RDtBQUFBLGdCQUM1RCx1QkFBQyxvWkFBRSxXQUFVLDBDQUF5QyxxQkFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkQ7QUFBQSxtQkFGN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsMlpBQUksV0FBVSx1RUFDYixpQ0FBQyxxWEFBSyxNQUFLLFVBQVMsTUFBTSxJQUFJLFdBQVUsa0JBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNELEtBRHhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLFlBRUEsdUJBQUMsc1ZBQUksV0FBVSxZQUNiLGlDQUFDLGlYQUFJLFdBQVUscUNBQ2I7QUFBQSxxQ0FBQyxpVEFDQztBQUFBLHVDQUFDLDhZQUFFLFdBQVUsK0JBQThCLDRCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1RDtBQUFBLGdCQUN2RCx1QkFBQywrWUFBRSxXQUFVLDBDQUF5QyxrQkFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0Q7QUFBQSxtQkFGMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsNlpBQUksV0FBVSx5RUFDYixpQ0FBQywwWEFBSyxNQUFLLGFBQVksTUFBTSxJQUFJLFdBQVUsb0JBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJELEtBRDdEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLFlBRUEsdUJBQUMsc1ZBQUksV0FBVSxZQUNiLGlDQUFDLGlYQUFJLFdBQVUscUNBQ2I7QUFBQSxxQ0FBQyxpVEFDQztBQUFBLHVDQUFDLG1aQUFFLFdBQVUsK0JBQThCLGlDQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE0RDtBQUFBLGdCQUM1RCx1QkFBQyxrWkFBRSxXQUFVLDBDQUF5QyxtQkFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUQ7QUFBQSxtQkFGM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsMFpBQUksV0FBVSxzRUFDYixpQ0FBQyxtWEFBSyxNQUFLLFNBQVEsTUFBTSxJQUFJLFdBQVUsaUJBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9ELEtBRHREO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLGVBL0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0RBO0FBQUEsVUFFQSx1QkFBQyxzVkFBSSxXQUFVLFlBQ2I7QUFBQSxtQ0FBQyx3YUFBRyxXQUFVLDhDQUE2QyxnQ0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkU7QUFBQSxZQUMzRSx1QkFBQywrVkFBSSxXQUFVLHFCQUNiO0FBQUEscUNBQUMsK1lBQUssTUFBSyxhQUFZLE1BQU0sSUFBSSxXQUFVLHFDQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0RTtBQUFBLGNBQzVFLHVCQUFDLG1iQUFFLFdBQVUsdUJBQXNCLCtEQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrRjtBQUFBLGlCQUZwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsZUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsYUEvREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdFQTtBQUFBLFdBaEZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpRkEsS0FsRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1GQTtBQUFBLFNBdEZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1RkE7QUFBQSxFQUVKO0FBRUEsU0FDRSx1QkFBQyx1V0FBSSxXQUFVLDhCQUNiO0FBQUEsMkJBQUMseVRBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFPO0FBQUEsSUFDUCx1QkFBQyxpV0FBSyxXQUFVLG1CQUNkLGlDQUFDLDhWQUFJLFdBQVUscUJBQ2I7QUFBQSw2QkFBQyxzVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVc7QUFBQSxNQUdYLHVCQUFDLDZaQUFJLFdBQVUscUVBQ2I7QUFBQSwrQkFBQyxpVEFDQztBQUFBLGlDQUFDLHNhQUFHLFdBQVUsNkNBQTRDLCtCQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RTtBQUFBLFVBQ3pFLHVCQUFDLHdiQUFFLFdBQVUsdUJBQXNCO0FBQUE7QUFBQSxZQUNsQlMsYUFBYTZELG1CQUFtQjtBQUFBLFlBQUU7QUFBQSxlQURuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUdBLHVCQUFDLHNZQUFJLFdBQVUsZ0RBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsT0FBT25FO0FBQUFBLGNBQ1AsVUFBVSxDQUFDb0UsTUFBTW5FLHFCQUFxQm1FLEdBQUdDLFFBQVFWLEtBQUs7QUFBQSxjQUN0RCxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLGlZQUFPLE9BQU0sWUFBVyx5QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0M7QUFBQSxnQkFDbEMsdUJBQUMsbVlBQU8sT0FBTSxhQUFZLDBCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvQztBQUFBLGdCQUNwQyx1QkFBQyx1WUFBTyxPQUFNLGVBQWMsNEJBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdDO0FBQUEsZ0JBQ3hDLHVCQUFDLGlZQUFPLE9BQU0sWUFBVyx5QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0M7QUFBQTtBQUFBO0FBQUEsWUFScEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBU0E7QUFBQSxVQUVBO0FBQUEsWUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FDQyxPQUFPekQ7QUFBQUEsY0FDUCxVQUFVLENBQUNrRSxNQUFNakUsdUJBQXVCaUUsR0FBR0MsUUFBUVYsS0FBSztBQUFBLGNBQ3hELFdBQVU7QUFBQSxjQUVWO0FBQUEsdUNBQUMsb1lBQU8sT0FBTSxPQUFNLGlDQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxQztBQUFBLGdCQUNyQyx1QkFBQyxtWUFBTyxPQUFNLFFBQU8sMkJBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1DO0FBQUEsZ0JBQ25DLHVCQUFDLHVZQUFPLE9BQU0sVUFBUywrQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0M7QUFBQSxnQkFDdEMsdUJBQUMsaVlBQU8sT0FBTSxPQUFNLDBCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpQztBQUFBO0FBQUE7QUFBQSxZQVJuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFTQTtBQUFBLFVBRUE7QUFBQSxZQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUNDLE9BQU92RDtBQUFBQSxjQUNQLFVBQVUsQ0FBQ2dFLE1BQU0vRCxxQkFBcUIrRCxHQUFHQyxRQUFRVixLQUFLO0FBQUEsY0FDdEQsV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxrWUFBTyxPQUFNLE9BQU0sK0JBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1DO0FBQUEsZ0JBQ25DLHVCQUFDLGtZQUFPLE9BQU0sU0FBUSw2QkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbUM7QUFBQSxnQkFDbkMsdUJBQUMsMFhBQU8sT0FBTSxVQUFTLHNCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2QjtBQUFBLGdCQUM3Qix1QkFBQyxnWUFBTyxPQUFNLFFBQU8sNEJBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlDO0FBQUE7QUFBQTtBQUFBLFlBUm5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVNBO0FBQUEsYUFoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlDQTtBQUFBLFdBMUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyQ0E7QUFBQSxNQUdDM0MsU0FDQyx1QkFBQyw0YkFBSSxXQUFVLGtHQUNiO0FBQUEsK0JBQUMsbVZBQUssTUFBSyxlQUFjLE1BQU0sTUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrQztBQUFBLFFBQ2xDLHVCQUFDLG9UQUFNQSxtQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWE7QUFBQSxRQUNiO0FBQUEsVUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU1DLFNBQVMsRUFBRTtBQUFBLFlBQzFCLFdBQVU7QUFBQSxZQUVWLGlDQUFDLHlVQUFLLE1BQUssS0FBSSxNQUFNLE1BQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdCO0FBQUE7QUFBQSxVQUoxQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLFdBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsTUFJRG5CLFVBQ0MsdUJBQUMsd1hBQUksV0FBVSwwQ0FDYixpQ0FBQywyV0FBSSxXQUFVLCtCQUNiO0FBQUEsK0JBQUMsaVpBQUksV0FBVSxpRUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZFO0FBQUEsUUFDN0UsdUJBQUMsNFpBQUssV0FBVSx1QkFBc0IseUNBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0Q7QUFBQSxXQUZqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0EsSUFFQSxtQ0FFRTtBQUFBLCtCQUFDLG1aQUFJLFdBQVUsNkRBQ2I7QUFBQSxpQ0FBQyxzVkFBSSxXQUFVLFlBQ2IsaUNBQUMsaVhBQUksV0FBVSxxQ0FDYjtBQUFBLG1DQUFDLGlUQUNDO0FBQUEscUNBQUMsOFpBQUUsV0FBVSwyQ0FBMEMsOEJBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFFO0FBQUEsY0FDckUsdUJBQUMsb1pBQUUsV0FBVSwwQ0FBeUM7QUFBQTtBQUFBLGlCQUNqRCtELHFCQUFxQixNQUFVUyxRQUFRLENBQUM7QUFBQSxnQkFBRTtBQUFBLG1CQUQvQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBQ0EsdUJBQUMsMlpBQUksV0FBVSx1RUFDYixpQ0FBQyx5WEFBSyxNQUFLLGNBQWEsTUFBTSxJQUFJLFdBQVUsa0JBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBELEtBRDVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUEsS0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVlBO0FBQUEsVUFFQSx1QkFBQyxzVkFBSSxXQUFVLFlBQ2IsaUNBQUMsaVhBQUksV0FBVSxxQ0FDYjtBQUFBLG1DQUFDLGlUQUNDO0FBQUEscUNBQUMsaWFBQUUsV0FBVSwyQ0FBMEMsaUNBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdFO0FBQUEsY0FDeEUsdUJBQUMsb1pBQUUsV0FBVSwwQ0FBeUM7QUFBQTtBQUFBLGlCQUNqRE4sd0JBQXdCLE1BQVVNLFFBQVEsQ0FBQztBQUFBLGdCQUFFO0FBQUEsbUJBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsWUFDQSx1QkFBQywyWkFBSSxXQUFVLHVFQUNiLGlDQUFDLHFYQUFLLE1BQUssVUFBUyxNQUFNLElBQUksV0FBVSxrQkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0QsS0FEeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQSxLQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxVQUVBLHVCQUFDLHNWQUFJLFdBQVUsWUFDYixpQ0FBQyxpWEFBSSxXQUFVLHFDQUNiO0FBQUEsbUNBQUMsaVRBQ0M7QUFBQSxxQ0FBQyw0WkFBRSxXQUFVLDJDQUEwQyw0QkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUU7QUFBQSxjQUNuRSx1QkFBQyxnWEFBRSxXQUFVLDBDQUEwQ0wsOEJBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdFO0FBQUEsaUJBRjFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLDZaQUFJLFdBQVUseUVBQ2IsaUNBQUMsMFhBQUssTUFBSyxhQUFZLE1BQU0sSUFBSSxXQUFVLG9CQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyRCxLQUQ3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBRUEsdUJBQUMsc1ZBQUksV0FBVSxZQUNiLGlDQUFDLGlYQUFJLFdBQVUscUNBQ2I7QUFBQSxtQ0FBQyxpVEFDQztBQUFBLHFDQUFDLGlhQUFFLFdBQVUsMkNBQTBDLGlDQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3RTtBQUFBLGNBQ3hFLHVCQUFDLGdaQUFFLFdBQVUsMENBQTBDcEQ7QUFBQUEsaUNBQWlCMEQsY0FBYztBQUFBLGdCQUFFO0FBQUEsbUJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlGO0FBQUEsaUJBRjNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLDBaQUFJLFdBQVUsc0VBQ2IsaUNBQUMsbVhBQUssTUFBSyxTQUFRLE1BQU0sSUFBSSxXQUFVLGlCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRCxLQUR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLGFBbkRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvREE7QUFBQSxRQUVBLHVCQUFDLHlYQUFJLFdBQVUseUNBRWI7QUFBQSxpQ0FBQyx1V0FBSSxXQUFVLDJCQUViO0FBQUEsbUNBQUMsc1ZBQUksV0FBVSxZQUNiO0FBQUEscUNBQUMsd1hBQUksV0FBVSwwQ0FDYjtBQUFBLHVDQUFDLCtaQUFHLFdBQVUseUNBQXdDLDhCQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvRTtBQUFBLGdCQUNwRSx1QkFBQywyWUFBSSxXQUFVLDJEQUNiO0FBQUEseUNBQUMsaVZBQUssTUFBSyxhQUFZLE1BQU0sTUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQSxrQkFDaEMsdUJBQUMsb1hBQUssMkNBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUM7QUFBQSxxQkFGbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLG1CQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTUE7QUFBQSxjQUVBLHVCQUFDLG1WQUFnQixXQUNmLGlDQUFDLDRZQUFJLFdBQVUsd0RBQ1pULGlCQUFPQyxPQUFPdEQsWUFBWSxHQUFHK0Q7QUFBQUEsZ0JBQUksQ0FBQ2hCLFVBQ2pDO0FBQUEsa0JBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUVDO0FBQUEsb0JBQ0EsWUFBWUQsb0JBQW9CQyxLQUFLO0FBQUEsb0JBQ3JDLGVBQWVJLHVCQUF1QkosS0FBSztBQUFBO0FBQUEsa0JBSHRDQSxPQUFPVjtBQUFBQSxrQkFEZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUkrQztBQUFBLGNBRWhELEtBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFTQSxLQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBV0E7QUFBQSxpQkFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFxQkE7QUFBQSxZQUdBLHVCQUFDLHNWQUFJLFdBQVUsWUFDYjtBQUFBLHFDQUFDLGtiQUFHLFdBQVUsOENBQTZDLHdDQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtRjtBQUFBLGNBQ25GLHVCQUFDLGdWQUFJLFdBQVUsUUFDYixpQ0FBQywrVkFBb0IsT0FBTSxRQUFPLFFBQU8sUUFDdkMsaUNBQUMsOFRBQVMsTUFBTW5DLGFBQ2Q7QUFBQSx1Q0FBQyw2VUFBYyxpQkFBZ0IsT0FBTSxRQUFPLGFBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFEO0FBQUEsZ0JBQ3JELHVCQUFDLHFUQUFNLFNBQVEsU0FBUSxRQUFPLGFBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVDO0FBQUEsZ0JBQ3ZDLHVCQUFDLHFUQUFNLFFBQU8sV0FBVSxlQUFlLENBQUNnRCxVQUFVLElBQUlBLFFBQVEsR0FBSSxPQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzRTtBQUFBLGdCQUN0RTtBQUFBLGtCQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFDQyxXQUFXLENBQUNBLFVBQVUsQ0FBQyxJQUFJQSxPQUFPYyxlQUFlLENBQUMsSUFBSSxFQUFFO0FBQUEsb0JBQ3hELFlBQVksRUFBRUMsT0FBTyxVQUFVO0FBQUE7QUFBQSxrQkFGakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUVtQztBQUFBLGdCQUVuQyx1QkFBQyw2VUFBSSxTQUFRLFlBQVcsTUFBSyx3QkFBdUIsTUFBSyxjQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtRTtBQUFBLGdCQUNuRSx1QkFBQywyVUFBSSxTQUFRLFVBQVMsTUFBSyx3QkFBdUIsTUFBSyxZQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUErRDtBQUFBLG1CQVRqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFZQSxLQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBY0E7QUFBQSxpQkFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQkE7QUFBQSxZQUdBLHVCQUFDLDRWQUFtQixNQUFNN0QsbUJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBDO0FBQUEsZUE5QzVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBK0NBO0FBQUEsVUFHQSx1QkFBQyxxVkFBSSxXQUFVLGFBRWI7QUFBQSxtQ0FBQyw0VUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFhO0FBQUEsWUFHYix1QkFBQywrVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFjO0FBQUEsWUFHZCx1QkFBQyxrVkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFlO0FBQUEsZUFSakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQTtBQUFBLGFBN0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE4REE7QUFBQSxXQXRIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdUhBO0FBQUEsU0EvTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlNQSxLQWxNRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbU1BO0FBQUEsT0FyTUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNNQTtBQUVKO0FBQUVqQixHQWpjSUQsZ0JBQWM7QUFBQSxVQUNxQlAsT0FBTztBQUFBO0FBQUF1RixLQUQxQ2hGO0FBbWNOLGVBQWVBO0FBQWUsSUFBQWdGO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsIkRyYWdEcm9wQ29udGV4dCIsIkJhckNoYXJ0IiwiQmFyIiwiWEF4aXMiLCJZQXhpcyIsIkNhcnRlc2lhbkdyaWQiLCJUb29sdGlwIiwiUmVzcG9uc2l2ZUNvbnRhaW5lciIsIkhlYWRlciIsIkJyZWFkY3J1bWIiLCJJY29uIiwidXNlQXV0aCIsIlJlY2VudEFjdGl2aXR5IiwiUXVpY2tBY3Rpb25zIiwiVXBjb21pbmdUYXNrcyIsIlBpcGVsaW5lU3RhZ2UiLCJQZXJmb3JtYW5jZU1ldHJpY3MiLCJkZWFsc1NlcnZpY2UiLCJTYWxlc0Rhc2hib2FyZCIsIl9zIiwidXNlciIsImxvYWRpbmciLCJhdXRoTG9hZGluZyIsInNlbGVjdGVkRGF0ZVJhbmdlIiwic2V0U2VsZWN0ZWREYXRlUmFuZ2UiLCJzZWxlY3RlZFByb2JhYmlsaXR5Iiwic2V0U2VsZWN0ZWRQcm9iYWJpbGl0eSIsInNlbGVjdGVkVGVycml0b3J5Iiwic2V0U2VsZWN0ZWRUZXJyaXRvcnkiLCJsYXN0VXBkYXRlZCIsInNldExhc3RVcGRhdGVkIiwiRGF0ZSIsInBpcGVsaW5lRGF0YSIsInNldFBpcGVsaW5lRGF0YSIsInJldmVudWVEYXRhIiwic2V0UmV2ZW51ZURhdGEiLCJwZXJmb3JtYW5jZURhdGEiLCJzZXRQZXJmb3JtYW5jZURhdGEiLCJzZXRMb2FkaW5nIiwiZXJyb3IiLCJzZXRFcnJvciIsImxvYWREYXNoYm9hcmREYXRhIiwicGlwZWxpbmVEZWFscyIsInJldmVudWVTdGF0cyIsInBlcmZvcm1hbmNlU3RhdHMiLCJQcm9taXNlIiwiYWxsIiwiZ2V0UGlwZWxpbmVEZWFscyIsImdldFJldmVudWVEYXRhIiwiZ2V0UGVyZm9ybWFuY2VNZXRyaWNzIiwiZXJyIiwiY29uc29sZSIsImludGVydmFsIiwic2V0SW50ZXJ2YWwiLCJjbGVhckludGVydmFsIiwib25EcmFnRW5kIiwicmVzdWx0IiwiZGVzdGluYXRpb24iLCJzb3VyY2UiLCJkcmFnZ2FibGVJZCIsImRyb3BwYWJsZUlkIiwiaW5kZXgiLCJ1cGRhdGVEZWFsU3RhZ2UiLCJzb3VyY2VTdGFnZSIsImRlc3RTdGFnZSIsImRyYWdnZWREZWFsIiwiZGVhbHMiLCJmaW5kIiwiZGVhbCIsImlkIiwic3RhZ2VQcm9icyIsInVwZGF0ZWREZWFsIiwicHJvYmFiaWxpdHkiLCJkYXlzSW5TdGFnZSIsIm5ld1NvdXJjZURlYWxzIiwiZmlsdGVyIiwibmV3RGVzdERlYWxzIiwic3BsaWNlIiwiY2FsY3VsYXRlU3RhZ2VUb3RhbCIsInN0YWdlIiwicmVkdWNlIiwidG90YWwiLCJ2YWx1ZSIsImNhbGN1bGF0ZVdlaWdodGVkVG90YWwiLCJ0b3RhbFBpcGVsaW5lVmFsdWUiLCJPYmplY3QiLCJ2YWx1ZXMiLCJ3ZWlnaHRlZFBpcGVsaW5lVmFsdWUiLCJ0b3RhbEFjdGl2ZURlYWxzIiwibGVuZ3RoIiwidG9Mb2NhbGVUaW1lU3RyaW5nIiwiZSIsInRhcmdldCIsInRvRml4ZWQiLCJwZXJjZW50YWdlIiwibWFwIiwidG9Mb2NhbGVTdHJpbmciLCJjb2xvciIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiaW5kZXguanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBEcmFnRHJvcENvbnRleHQgfSBmcm9tICdyZWFjdC1iZWF1dGlmdWwtZG5kJztcclxuaW1wb3J0IHsgQmFyQ2hhcnQsIEJhciwgWEF4aXMsIFlBeGlzLCBDYXJ0ZXNpYW5HcmlkLCBUb29sdGlwLCBSZXNwb25zaXZlQ29udGFpbmVyIH0gZnJvbSAncmVjaGFydHMnO1xyXG5pbXBvcnQgSGVhZGVyIGZyb20gJ2NvbXBvbmVudHMvdWkvSGVhZGVyJztcclxuaW1wb3J0IEJyZWFkY3J1bWIgZnJvbSAnY29tcG9uZW50cy91aS9CcmVhZGNydW1iJztcclxuaW1wb3J0IEljb24gZnJvbSAnY29tcG9uZW50cy9BcHBJY29uJztcclxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uLy4uL2NvbnRleHRzL0F1dGhDb250ZXh0JztcclxuXHJcbmltcG9ydCBSZWNlbnRBY3Rpdml0eSBmcm9tICcuL2NvbXBvbmVudHMvUmVjZW50QWN0aXZpdHknO1xyXG5pbXBvcnQgUXVpY2tBY3Rpb25zIGZyb20gJy4vY29tcG9uZW50cy9RdWlja0FjdGlvbnMnO1xyXG5pbXBvcnQgVXBjb21pbmdUYXNrcyBmcm9tICcuL2NvbXBvbmVudHMvVXBjb21pbmdUYXNrcyc7XHJcbmltcG9ydCBQaXBlbGluZVN0YWdlIGZyb20gJy4vY29tcG9uZW50cy9QaXBlbGluZVN0YWdlJztcclxuaW1wb3J0IFBlcmZvcm1hbmNlTWV0cmljcyBmcm9tICcuL2NvbXBvbmVudHMvUGVyZm9ybWFuY2VNZXRyaWNzJztcclxuXHJcbmltcG9ydCBkZWFsc1NlcnZpY2UgZnJvbSAnLi4vLi4vc2VydmljZXMvZGVhbHNTZXJ2aWNlJztcclxuXHJcblxyXG5cclxuY29uc3QgU2FsZXNEYXNoYm9hcmQgPSAoKSA9PiB7XHJcbiAgY29uc3QgeyB1c2VyLCBsb2FkaW5nOiBhdXRoTG9hZGluZyB9ID0gdXNlQXV0aCgpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZERhdGVSYW5nZSwgc2V0U2VsZWN0ZWREYXRlUmFuZ2VdID0gdXNlU3RhdGUoJ3RoaXNNb250aCcpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFByb2JhYmlsaXR5LCBzZXRTZWxlY3RlZFByb2JhYmlsaXR5XSA9IHVzZVN0YXRlKCdhbGwnKTtcclxuICBjb25zdCBbc2VsZWN0ZWRUZXJyaXRvcnksIHNldFNlbGVjdGVkVGVycml0b3J5XSA9IHVzZVN0YXRlKCdhbGwnKTtcclxuICBjb25zdCBbbGFzdFVwZGF0ZWQsIHNldExhc3RVcGRhdGVkXSA9IHVzZVN0YXRlKG5ldyBEYXRlKCkpO1xyXG4gIGNvbnN0IFtwaXBlbGluZURhdGEsIHNldFBpcGVsaW5lRGF0YV0gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW3JldmVudWVEYXRhLCBzZXRSZXZlbnVlRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3BlcmZvcm1hbmNlRGF0YSwgc2V0UGVyZm9ybWFuY2VEYXRhXSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKTtcclxuXHJcbiAgLy8gTG9hZCBkYXNoYm9hcmQgZGF0YVxyXG4gIGNvbnN0IGxvYWREYXNoYm9hcmREYXRhID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKCF1c2VyKSByZXR1cm47XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0TG9hZGluZyh0cnVlKTtcclxuICAgICAgc2V0RXJyb3IoJycpO1xyXG5cclxuICAgICAgLy8gTG9hZCBhbGwgZGFzaGJvYXJkIGRhdGEgaW4gcGFyYWxsZWxcclxuICAgICAgY29uc3QgW1xyXG4gICAgICAgIHBpcGVsaW5lRGVhbHMsXHJcbiAgICAgICAgcmV2ZW51ZVN0YXRzLFxyXG4gICAgICAgIHBlcmZvcm1hbmNlU3RhdHNcclxuICAgICAgXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcclxuICAgICAgICBkZWFsc1NlcnZpY2U/LmdldFBpcGVsaW5lRGVhbHMoKSxcclxuICAgICAgICBkZWFsc1NlcnZpY2U/LmdldFJldmVudWVEYXRhKCksXHJcbiAgICAgICAgZGVhbHNTZXJ2aWNlPy5nZXRQZXJmb3JtYW5jZU1ldHJpY3MoKVxyXG4gICAgICBdKTtcclxuXHJcbiAgICAgIHNldFBpcGVsaW5lRGF0YShwaXBlbGluZURlYWxzKTtcclxuICAgICAgc2V0UmV2ZW51ZURhdGEocmV2ZW51ZVN0YXRzKTtcclxuICAgICAgc2V0UGVyZm9ybWFuY2VEYXRhKHBlcmZvcm1hbmNlU3RhdHMpO1xyXG4gICAgICBzZXRMYXN0VXBkYXRlZChuZXcgRGF0ZSgpKTtcclxuXHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgbG9hZGluZyBkYXNoYm9hcmQgZGF0YTonLCBlcnIpO1xyXG4gICAgICBzZXRFcnJvcignRmFpbGVkIHRvIGxvYWQgZGFzaGJvYXJkIGRhdGEuIFBsZWFzZSB0cnkgYWdhaW4uJyk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyBBdXRvLXJlZnJlc2ggZnVuY3Rpb25hbGl0eVxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAodXNlcikge1xyXG4gICAgICBsb2FkRGFzaGJvYXJkRGF0YSgpO1xyXG4gICAgfVxyXG4gIH0sIFt1c2VyXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBpbnRlcnZhbCA9IHNldEludGVydmFsKCgpID0+IHtcclxuICAgICAgaWYgKHVzZXIpIHtcclxuICAgICAgICBsb2FkRGFzaGJvYXJkRGF0YSgpO1xyXG4gICAgICB9XHJcbiAgICB9LCAzMDAwMDApOyAvLyA1IG1pbnV0ZXNcclxuXHJcbiAgICByZXR1cm4gKCkgPT4gY2xlYXJJbnRlcnZhbChpbnRlcnZhbCk7XHJcbiAgfSwgW3VzZXJdKTtcclxuXHJcbiAgLy8gSGFuZGxlIGRyYWcgYW5kIGRyb3AgZm9yIHBpcGVsaW5lXHJcbiAgY29uc3Qgb25EcmFnRW5kID0gYXN5bmMgKHJlc3VsdCkgPT4ge1xyXG4gICAgY29uc3QgeyBkZXN0aW5hdGlvbiwgc291cmNlLCBkcmFnZ2FibGVJZCB9ID0gcmVzdWx0O1xyXG5cclxuICAgIGlmICghZGVzdGluYXRpb24pIHJldHVybjtcclxuICAgIGlmIChkZXN0aW5hdGlvbj8uZHJvcHBhYmxlSWQgPT09IHNvdXJjZT8uZHJvcHBhYmxlSWQgJiYgZGVzdGluYXRpb24/LmluZGV4ID09PSBzb3VyY2U/LmluZGV4KSB7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICB0cnkge1xyXG4gICAgICAvLyBVcGRhdGUgZGVhbCBzdGFnZSBpbiBkYXRhYmFzZVxyXG4gICAgICBhd2FpdCBkZWFsc1NlcnZpY2U/LnVwZGF0ZURlYWxTdGFnZShkcmFnZ2FibGVJZCwgZGVzdGluYXRpb24/LmRyb3BwYWJsZUlkKTtcclxuXHJcbiAgICAgIC8vIFVwZGF0ZSBsb2NhbCBzdGF0ZSBvcHRpbWlzdGljYWxseVxyXG4gICAgICBjb25zdCBzb3VyY2VTdGFnZSA9IHBpcGVsaW5lRGF0YT8uW3NvdXJjZT8uZHJvcHBhYmxlSWRdO1xyXG4gICAgICBjb25zdCBkZXN0U3RhZ2UgPSBwaXBlbGluZURhdGE/LltkZXN0aW5hdGlvbj8uZHJvcHBhYmxlSWRdO1xyXG4gICAgICBjb25zdCBkcmFnZ2VkRGVhbCA9IHNvdXJjZVN0YWdlPy5kZWFscz8uZmluZChkZWFsID0+IGRlYWw/LmlkID09PSBkcmFnZ2FibGVJZCk7XHJcblxyXG4gICAgICBpZiAoZHJhZ2dlZERlYWwpIHtcclxuICAgICAgICBjb25zdCBzdGFnZVByb2JzID0ge1xyXG4gICAgICAgICAgJ2xlYWQnOiAxMCxcclxuICAgICAgICAgICdxdWFsaWZpZWQnOiAyNSxcclxuICAgICAgICAgICdwcm9wb3NhbCc6IDUwLFxyXG4gICAgICAgICAgJ25lZ290aWF0aW9uJzogNzUsXHJcbiAgICAgICAgICAnY2xvc2VkX3dvbic6IDEwMCxcclxuICAgICAgICAgICdjbG9zZWRfbG9zdCc6IDBcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBjb25zdCB1cGRhdGVkRGVhbCA9IHtcclxuICAgICAgICAgIC4uLmRyYWdnZWREZWFsLFxyXG4gICAgICAgICAgcHJvYmFiaWxpdHk6IHN0YWdlUHJvYnM/LltkZXN0aW5hdGlvbj8uZHJvcHBhYmxlSWRdIHx8IGRyYWdnZWREZWFsPy5wcm9iYWJpbGl0eSxcclxuICAgICAgICAgIGRheXNJblN0YWdlOiAwXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgLy8gUmVtb3ZlIGZyb20gc291cmNlXHJcbiAgICAgICAgY29uc3QgbmV3U291cmNlRGVhbHMgPSBzb3VyY2VTdGFnZT8uZGVhbHM/LmZpbHRlcihkZWFsID0+IGRlYWw/LmlkICE9PSBkcmFnZ2FibGVJZCk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy8gQWRkIHRvIGRlc3RpbmF0aW9uXHJcbiAgICAgICAgY29uc3QgbmV3RGVzdERlYWxzID0gWy4uLihkZXN0U3RhZ2U/LmRlYWxzIHx8IFtdKV07XHJcbiAgICAgICAgbmV3RGVzdERlYWxzPy5zcGxpY2UoZGVzdGluYXRpb24/LmluZGV4LCAwLCB1cGRhdGVkRGVhbCk7XHJcblxyXG4gICAgICAgIHNldFBpcGVsaW5lRGF0YSh7XHJcbiAgICAgICAgICAuLi5waXBlbGluZURhdGEsXHJcbiAgICAgICAgICBbc291cmNlPy5kcm9wcGFibGVJZF06IHtcclxuICAgICAgICAgICAgLi4uc291cmNlU3RhZ2UsXHJcbiAgICAgICAgICAgIGRlYWxzOiBuZXdTb3VyY2VEZWFsc1xyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIFtkZXN0aW5hdGlvbj8uZHJvcHBhYmxlSWRdOiB7XHJcbiAgICAgICAgICAgIC4uLmRlc3RTdGFnZSxcclxuICAgICAgICAgICAgZGVhbHM6IG5ld0Rlc3REZWFsc1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgdXBkYXRpbmcgZGVhbCBzdGFnZTonLCBlcnIpO1xyXG4gICAgICBzZXRFcnJvcignRmFpbGVkIHRvIHVwZGF0ZSBkZWFsIHN0YWdlLiBQbGVhc2UgdHJ5IGFnYWluLicpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIENhbGN1bGF0ZSBwaXBlbGluZSB0b3RhbHNcclxuICBjb25zdCBjYWxjdWxhdGVTdGFnZVRvdGFsID0gKHN0YWdlKSA9PiB7XHJcbiAgICByZXR1cm4gc3RhZ2U/LmRlYWxzPy5yZWR1Y2UoKHRvdGFsLCBkZWFsKSA9PiB0b3RhbCArIChkZWFsPy52YWx1ZSB8fCAwKSwgMCkgfHwgMDtcclxuICB9O1xyXG5cclxuICBjb25zdCBjYWxjdWxhdGVXZWlnaHRlZFRvdGFsID0gKHN0YWdlKSA9PiB7XHJcbiAgICByZXR1cm4gc3RhZ2U/LmRlYWxzPy5yZWR1Y2UoKHRvdGFsLCBkZWFsKSA9PiBcclxuICAgICAgdG90YWwgKyAoKGRlYWw/LnZhbHVlIHx8IDApICogKGRlYWw/LnByb2JhYmlsaXR5IHx8IDApIC8gMTAwKSwgMFxyXG4gICAgKSB8fCAwO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHRvdGFsUGlwZWxpbmVWYWx1ZSA9IE9iamVjdC52YWx1ZXMocGlwZWxpbmVEYXRhKT8ucmVkdWNlKCh0b3RhbCwgc3RhZ2UpID0+IFxyXG4gICAgdG90YWwgKyBjYWxjdWxhdGVTdGFnZVRvdGFsKHN0YWdlKSwgMFxyXG4gICk7XHJcblxyXG4gIGNvbnN0IHdlaWdodGVkUGlwZWxpbmVWYWx1ZSA9IE9iamVjdC52YWx1ZXMocGlwZWxpbmVEYXRhKT8ucmVkdWNlKCh0b3RhbCwgc3RhZ2UpID0+IFxyXG4gICAgdG90YWwgKyBjYWxjdWxhdGVXZWlnaHRlZFRvdGFsKHN0YWdlKSwgMFxyXG4gICk7XHJcblxyXG4gIGNvbnN0IHRvdGFsQWN0aXZlRGVhbHMgPSBPYmplY3QudmFsdWVzKHBpcGVsaW5lRGF0YSk/LnJlZHVjZSgodG90YWwsIHN0YWdlKSA9PiBcclxuICAgIHRvdGFsICsgKHN0YWdlPy5kZWFscz8ubGVuZ3RoIHx8IDApLCAwXHJcbiAgKTtcclxuXHJcbiAgLy8gU2hvdyBwcmV2aWV3IG1vZGUgZm9yIG5vbi1hdXRoZW50aWNhdGVkIHVzZXJzXHJcbiAgaWYgKGF1dGhMb2FkaW5nKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy1iYWNrZ3JvdW5kIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTNcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluIHJvdW5kZWQtZnVsbCBoLTggdy04IGJvcmRlci1iLTIgYm9yZGVyLXByaW1hcnlcIj48L2Rpdj5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtdGV4dC1zZWNvbmRhcnlcIj5Mb2FkaW5nIGRhc2hib2FyZC4uLjwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgaWYgKCF1c2VyKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy1iYWNrZ3JvdW5kXCI+XHJcbiAgICAgICAgPEhlYWRlciAvPlxyXG4gICAgICAgIFxyXG4gICAgICAgIDxtYWluIGNsYXNzTmFtZT1cInB0LTIwIHB4LTYgcGItOFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy03eGwgbXgtYXV0b1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWJsdWUtNTAgYm9yZGVyIGJvcmRlci1ibHVlLTIwMCBwLTQgcm91bmRlZC1sZyBtYi02XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTJcIj5cclxuICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJJbmZvXCIgc2l6ZT17MjB9IGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTgwMCBmb250LW1lZGl1bVwiPlByZXZpZXcgTW9kZTwvcD5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTcwMCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgVGhpcyBpcyBob3cgdGhlIHNhbGVzIGRhc2hib2FyZCBsb29rcyB3aGVuIGF1dGhlbnRpY2F0ZWQueycgJ31cclxuICAgICAgICAgICAgICAgICAgICA8YSBocmVmPVwiL2xvZ2luXCIgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdW5kZXJsaW5lIGhvdmVyOnRleHQtYmx1ZS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIFNpZ24gaW4gdG8gYWNjZXNzIHJlYWwgZGF0YVxyXG4gICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvcGFjaXR5LTc1XCI+XHJcbiAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LXRleHQtcHJpbWFyeSBtYi0yXCI+U2FsZXMgRGFzaGJvYXJkPC9oMT5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5IG1iLThcIj5cclxuICAgICAgICAgICAgICAgIFByZXZpZXcgb2YgeW91ciBzYWxlcyBwaXBlbGluZSBhbmQgcGVyZm9ybWFuY2UgbWV0cmljc1xyXG4gICAgICAgICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgICAgICAgey8qIFByZXZpZXcgbWV0cmljcyAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLTYgbWItOFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIHAtNlwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5IHRleHQtc21cIj5Ub3RhbCBQaXBlbGluZTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtbm9ybWFsIHRleHQtdGV4dC1wcmltYXJ5XCI+JDIuMU08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgYmctcHJpbWFyeS01MCByb3VuZGVkLWxnIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiVHJlbmRpbmdVcFwiIHNpemU9ezI0fSBjbGFzc05hbWU9XCJ0ZXh0LXByaW1hcnlcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgcC02XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtdGV4dC1zZWNvbmRhcnkgdGV4dC1zbVwiPldlaWdodGVkIFBpcGVsaW5lPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ub3JtYWwgdGV4dC10ZXh0LXByaW1hcnlcIj4kMS4yTTwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTIgaC0xMiBiZy1zdWNjZXNzLTUwIHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJUYXJnZXRcIiBzaXplPXsyNH0gY2xhc3NOYW1lPVwidGV4dC1zdWNjZXNzXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIHAtNlwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5IHRleHQtc21cIj5BY3RpdmUgRGVhbHM8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LW5vcm1hbCB0ZXh0LXRleHQtcHJpbWFyeVwiPjI0PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMiBoLTEyIGJnLXNlY29uZGFyeS01MCByb3VuZGVkLWxnIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiQnJpZWZjYXNlXCIgc2l6ZT17MjR9IGNsYXNzTmFtZT1cInRleHQtc2Vjb25kYXJ5XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIHAtNlwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5IHRleHQtc21cIj5RdW90YSBBY2hpZXZlbWVudDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtbm9ybWFsIHRleHQtdGV4dC1wcmltYXJ5XCI+NzQlPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMiBoLTEyIGJnLWFjY2VudC01MCByb3VuZGVkLWxnIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiQXdhcmRcIiBzaXplPXsyNH0gY2xhc3NOYW1lPVwidGV4dC1hY2NlbnRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgcC02XCI+XHJcbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LW5vcm1hbCB0ZXh0LXRleHQtcHJpbWFyeSBtYi02XCI+UGlwZWxpbmUgUHJldmlldzwvaDI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LTEyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJCYXJDaGFydDNcIiBzaXplPXs0OH0gY2xhc3NOYW1lPVwidGV4dC10ZXh0LXRlcnRpYXJ5IG14LWF1dG8gbWItNFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtdGV4dC1zZWNvbmRhcnlcIj5TaWduIGluIHRvIHZpZXcgeW91ciBpbnRlcmFjdGl2ZSBzYWxlcyBwaXBlbGluZTwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvbWFpbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGJnLWJhY2tncm91bmRcIj5cclxuICAgICAgPEhlYWRlciAvPlxyXG4gICAgICA8bWFpbiBjbGFzc05hbWU9XCJwdC0yMCBweC02IHBiLThcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LTd4bCBteC1hdXRvXCI+XHJcbiAgICAgICAgICA8QnJlYWRjcnVtYiAvPlxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICB7LyogRGFzaGJvYXJkIEhlYWRlciAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBsZzpmbGV4LXJvdyBsZzppdGVtcy1jZW50ZXIgbGc6anVzdGlmeS1iZXR3ZWVuIG1iLThcIj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtdGV4dC1wcmltYXJ5IG1iLTJcIj5TYWxlcyBEYXNoYm9hcmQ8L2gxPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtdGV4dC1zZWNvbmRhcnlcIj5cclxuICAgICAgICAgICAgICAgIExhc3QgdXBkYXRlZDoge2xhc3RVcGRhdGVkPy50b0xvY2FsZVRpbWVTdHJpbmcoKX0g4oCiIEF1dG8tcmVmcmVzaCBldmVyeSA1IG1pbnV0ZXNcclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgey8qIEZpbHRlciBDb250cm9scyAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGdhcC00IG10LTQgbGc6bXQtMFwiPlxyXG4gICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZERhdGVSYW5nZX1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VsZWN0ZWREYXRlUmFuZ2UoZT8udGFyZ2V0Py52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbnB1dC1maWVsZCB0ZXh0LXNtXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwidGhpc1dlZWtcIj5UaGlzIFdlZWs8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJ0aGlzTW9udGhcIj5UaGlzIE1vbnRoPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwidGhpc1F1YXJ0ZXJcIj5UaGlzIFF1YXJ0ZXI8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJ0aGlzWWVhclwiPlRoaXMgWWVhcjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZFByb2JhYmlsaXR5fVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWxlY3RlZFByb2JhYmlsaXR5KGU/LnRhcmdldD8udmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5wdXQtZmllbGQgdGV4dC1zbVwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImFsbFwiPkFsbCBQcm9iYWJpbGl0aWVzPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiaGlnaFwiPkhpZ2ggKCZndDs3MCUpPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwibWVkaXVtXCI+TWVkaXVtICgzMC03MCUpPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwibG93XCI+TG93ICgmbHQ7MzAlKTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZFRlcnJpdG9yeX1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VsZWN0ZWRUZXJyaXRvcnkoZT8udGFyZ2V0Py52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbnB1dC1maWVsZCB0ZXh0LXNtXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYWxsXCI+QWxsIFRlcnJpdG9yaWVzPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwibm9ydGhcIj5Ob3J0aCBBbWVyaWNhPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiZXVyb3BlXCI+RXVyb3BlPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYXNpYVwiPkFzaWEgUGFjaWZpYzwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiBFcnJvciBNZXNzYWdlICovfVxyXG4gICAgICAgICAge2Vycm9yICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1lcnJvci01MCBib3JkZXIgYm9yZGVyLWVycm9yLTIwMCB0ZXh0LWVycm9yIHAtNCByb3VuZGVkLWxnIG1iLTYgZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCI+XHJcbiAgICAgICAgICAgICAgPEljb24gbmFtZT1cIkFsZXJ0Q2lyY2xlXCIgc2l6ZT17MjB9IC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4+e2Vycm9yfTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRFcnJvcignJyl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtbC1hdXRvIHRleHQtZXJyb3IgaG92ZXI6dGV4dC1lcnJvci02MDBcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJYXCIgc2l6ZT17MTZ9IC8+XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICB7LyogTG9hZGluZyBTdGF0ZSAqL31cclxuICAgICAgICAgIHtsb2FkaW5nID8gKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHB5LTEyXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTNcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluIHJvdW5kZWQtZnVsbCBoLTggdy04IGJvcmRlci1iLTIgYm9yZGVyLXByaW1hcnlcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtdGV4dC1zZWNvbmRhcnlcIj5Mb2FkaW5nIGRhc2hib2FyZCBkYXRhLi4uPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgey8qIEtleSBNZXRyaWNzICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtNiBtYi04XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgcC02XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtdGV4dC1zZWNvbmRhcnkgdGV4dC1zbSBmb250LW5vcm1hbFwiPlRvdGFsIFBpcGVsaW5lPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ub3JtYWwgdGV4dC10ZXh0LXByaW1hcnlcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgJHsodG90YWxQaXBlbGluZVZhbHVlIC8gMTAwMDAwMCk/LnRvRml4ZWQoMSl9TVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMiBoLTEyIGJnLXByaW1hcnktNTAgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIlRyZW5kaW5nVXBcIiBzaXplPXsyNH0gY2xhc3NOYW1lPVwidGV4dC1wcmltYXJ5XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIHAtNlwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5IHRleHQtc20gZm9udC1ub3JtYWxcIj5XZWlnaHRlZCBQaXBlbGluZTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtbm9ybWFsIHRleHQtdGV4dC1wcmltYXJ5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICR7KHdlaWdodGVkUGlwZWxpbmVWYWx1ZSAvIDEwMDAwMDApPy50b0ZpeGVkKDEpfU1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTIgaC0xMiBiZy1zdWNjZXNzLTUwIHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJUYXJnZXRcIiBzaXplPXsyNH0gY2xhc3NOYW1lPVwidGV4dC1zdWNjZXNzXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIHAtNlwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5IHRleHQtc20gZm9udC1ub3JtYWxcIj5BY3RpdmUgRGVhbHM8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LW5vcm1hbCB0ZXh0LXRleHQtcHJpbWFyeVwiPnt0b3RhbEFjdGl2ZURlYWxzfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTIgaC0xMiBiZy1zZWNvbmRhcnktNTAgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIkJyaWVmY2FzZVwiIHNpemU9ezI0fSBjbGFzc05hbWU9XCJ0ZXh0LXNlY29uZGFyeVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZCBwLTZcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC10ZXh0LXNlY29uZGFyeSB0ZXh0LXNtIGZvbnQtbm9ybWFsXCI+UXVvdGEgQWNoaWV2ZW1lbnQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LW5vcm1hbCB0ZXh0LXRleHQtcHJpbWFyeVwiPntwZXJmb3JtYW5jZURhdGE/LnBlcmNlbnRhZ2UgfHwgMH0lPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMiBoLTEyIGJnLWFjY2VudC01MCByb3VuZGVkLWxnIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiQXdhcmRcIiBzaXplPXsyNH0gY2xhc3NOYW1lPVwidGV4dC1hY2NlbnRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgeGw6Z3JpZC1jb2xzLTQgZ2FwLThcIj5cclxuICAgICAgICAgICAgICAgIHsvKiBNYWluIFBpcGVsaW5lIFNlY3Rpb24gKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInhsOmNvbC1zcGFuLTMgc3BhY2UteS04XCI+XHJcbiAgICAgICAgICAgICAgICAgIHsvKiBJbnRlcmFjdGl2ZSBQaXBlbGluZSAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIHAtNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtbm9ybWFsIHRleHQtdGV4dC1wcmltYXJ5XCI+U2FsZXMgUGlwZWxpbmU8L2gyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTIgdGV4dC1zbSB0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJSZWZyZXNoQ3dcIiBzaXplPXsxNn0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+RHJhZyBkZWFscyB0byB1cGRhdGUgc3RhZ2VzPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgPERyYWdEcm9wQ29udGV4dCBvbkRyYWdFbmQ9e29uRHJhZ0VuZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTUgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge09iamVjdC52YWx1ZXMocGlwZWxpbmVEYXRhKT8ubWFwKChzdGFnZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxQaXBlbGluZVN0YWdlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e3N0YWdlPy5pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0YWdlPXtzdGFnZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvdGFsVmFsdWU9e2NhbGN1bGF0ZVN0YWdlVG90YWwoc3RhZ2UpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgd2VpZ2h0ZWRWYWx1ZT17Y2FsY3VsYXRlV2VpZ2h0ZWRUb3RhbChzdGFnZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L0RyYWdEcm9wQ29udGV4dD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7LyogUmV2ZW51ZSBGb3JlY2FzdCBDaGFydCAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIHAtNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtbm9ybWFsIHRleHQtdGV4dC1wcmltYXJ5IG1iLTZcIj5Nb250aGx5IFJldmVudWUgRm9yZWNhc3Q8L2gyPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC04MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFJlc3BvbnNpdmVDb250YWluZXIgd2lkdGg9XCIxMDAlXCIgaGVpZ2h0PVwiMTAwJVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8QmFyQ2hhcnQgZGF0YT17cmV2ZW51ZURhdGF9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxDYXJ0ZXNpYW5HcmlkIHN0cm9rZURhc2hhcnJheT1cIjMgM1wiIHN0cm9rZT1cIiNFNUU3RUJcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxYQXhpcyBkYXRhS2V5PVwibW9udGhcIiBzdHJva2U9XCIjNkI3MjgwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8WUF4aXMgc3Ryb2tlPVwiIzZCNzI4MFwiIHRpY2tGb3JtYXR0ZXI9eyh2YWx1ZSkgPT4gYCQke3ZhbHVlIC8gMTAwMH1LYH0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8VG9vbHRpcCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1hdHRlcj17KHZhbHVlKSA9PiBbYCQke3ZhbHVlPy50b0xvY2FsZVN0cmluZygpfWAsICcnXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsU3R5bGU9e3sgY29sb3I6ICcjMUYyOTM3JyB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPEJhciBkYXRhS2V5PVwiZm9yZWNhc3RcIiBmaWxsPVwidmFyKC0tY29sb3ItcHJpbWFyeSlcIiBuYW1lPVwiRm9yZWNhc3RcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxCYXIgZGF0YUtleT1cImFjdHVhbFwiIGZpbGw9XCJ2YXIoLS1jb2xvci1zdWNjZXNzKVwiIG5hbWU9XCJBY3R1YWxcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0JhckNoYXJ0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9SZXNwb25zaXZlQ29udGFpbmVyPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBQZXJmb3JtYW5jZSBNZXRyaWNzICovfVxyXG4gICAgICAgICAgICAgICAgICA8UGVyZm9ybWFuY2VNZXRyaWNzIGRhdGE9e3BlcmZvcm1hbmNlRGF0YX0gLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBSaWdodCBTaWRlYmFyICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cclxuICAgICAgICAgICAgICAgICAgey8qIFF1aWNrIEFjdGlvbnMgKi99XHJcbiAgICAgICAgICAgICAgICAgIDxRdWlja0FjdGlvbnMgLz5cclxuICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBVcGNvbWluZyBUYXNrcyAqL31cclxuICAgICAgICAgICAgICAgICAgPFVwY29taW5nVGFza3MgLz5cclxuICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBSZWNlbnQgQWN0aXZpdHkgKi99XHJcbiAgICAgICAgICAgICAgICAgIDxSZWNlbnRBY3Rpdml0eSAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9tYWluPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFNhbGVzRGFzaGJvYXJkOyJdLCJmaWxlIjoiRDovY3VycmVudCBwcm9qZWN0cy9jbGF1ZGUtY29kZS9zcmMvcGFnZXMvc2FsZXMtZGFzaGJvYXJkL2luZGV4LmpzeCJ9