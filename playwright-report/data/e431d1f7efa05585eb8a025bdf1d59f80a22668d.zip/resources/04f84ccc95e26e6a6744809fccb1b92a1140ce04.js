import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/contact-management/components/ImportContactsModal.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import Icon from "/src/components/AppIcon.jsx";
const ImportContactsModal = ({ onImport, onClose }) => {
  _s();
  const [step, setStep] = useState(1);
  const [file, setFile] = useState(null);
  const [mappings, setMappings] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    company: "",
    position: ""
  });
  const [preview, setPreview] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const handleFileChange = (e) => {
    const selectedFile = e?.target?.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      setTimeout(() => {
        const mockPreview = [
          {
            firstName: "John",
            lastName: "Doe",
            email: "john.doe@example.com",
            phone: "+1 (555) 123-4567",
            company: "Example Corp",
            position: "Sales Manager"
          },
          {
            firstName: "Jane",
            lastName: "Smith",
            email: "jane.smith@example.com",
            phone: "+1 (555) 987-6543",
            company: "Sample Inc",
            position: "Marketing Director"
          },
          {
            firstName: "Robert",
            lastName: "Johnson",
            email: "robert.johnson@example.com",
            phone: "+1 (555) 456-7890",
            company: "Test LLC",
            position: "CEO"
          }
        ];
        setPreview(mockPreview);
        setMappings({
          firstName: "firstName",
          lastName: "lastName",
          email: "email",
          phone: "phone",
          company: "company",
          position: "position"
        });
        setStep(2);
      }, 500);
    }
  };
  const handleMappingChange = (field, value) => {
    setMappings({
      ...mappings,
      [field]: value
    });
  };
  const handleImport = () => {
    setIsLoading(true);
    setTimeout(() => {
      const importedContacts = preview?.map((item, index) => ({
        id: Date.now() + index,
        firstName: item?.[mappings?.firstName] || "",
        lastName: item?.[mappings?.lastName] || "",
        email: item?.[mappings?.email] || "",
        phone: item?.[mappings?.phone] || "",
        company: item?.[mappings?.company] || "",
        position: item?.[mappings?.position] || "",
        avatar: `https://randomuser.me/api/portraits/${index % 2 === 0 ? "men" : "women"}/${Math.floor(Math.random() * 100)}.jpg`,
        lastContactDate: (/* @__PURE__ */ new Date())?.toISOString(),
        status: "active",
        tags: [],
        deals: [],
        notes: "",
        socialProfiles: {},
        activities: [],
        customFields: {
          preferredContactMethod: "",
          decisionTimeframe: "",
          budgetRange: ""
        }
      }));
      onImport(importedContacts);
      setIsLoading(false);
    }, 1e3);
  };
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:112:4", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "112", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20z-1100%20overflow-y-auto%22%7D", className: "fixed inset-0 z-1100 overflow-y-auto", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:113:6", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "113", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-center%20min-h-screen%20px-4%20pt-4%20pb-20%20text-center%20sm%3Ablock%20sm%3Ap-0%22%7D", className: "flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0", children: [
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:114:8", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "114", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20transition-opacity%22%7D", className: "fixed inset-0 transition-opacity", "aria-hidden": "true", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:115:10", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "115", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22absolute%20inset-0%20bg-black%20bg-opacity-50%22%7D", className: "absolute inset-0 bg-black bg-opacity-50" }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
      lineNumber: 115,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
      lineNumber: 114,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:118:8", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "118", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22hidden%20sm%3Ainline-block%20sm%3Aalign-middle%20sm%3Ah-screen%22%2C%22textContent%22%3A%22%E2%80%8B%22%7D", className: "hidden sm:inline-block sm:align-middle sm:h-screen", "aria-hidden": "true", children: "​" }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
      lineNumber: 118,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:120:8", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "120", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22inline-block%20align-bottom%20bg-surface%20rounded-lg%20text-left%20overflow-hidden%20shadow-xl%20transform%20transition-all%20sm%3Amy-8%20sm%3Aalign-middle%20sm%3Amax-w-lg%20sm%3Aw-full%20md%3Amax-w-2xl%22%7D", className: "inline-block align-bottom bg-surface rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full md:max-w-2xl", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:121:10", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "121", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22px-6%20py-4%20border-b%20border-border%20flex%20justify-between%20items-center%22%7D", className: "px-6 py-4 border-b border-border flex justify-between items-center", children: [
        /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:122:12", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "122", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%2C%22textContent%22%3A%22Import%20Contacts%22%7D", className: "text-lg font-semibold text-text-primary", children: "Import Contacts" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
          lineNumber: 122,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:123:12",
            "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx",
            "data-component-line": "123",
            "data-component-file": "ImportContactsModal.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22text-text-secondary%20hover%3Atext-text-primary%22%7D",
            onClick: onClose,
            className: "text-text-secondary hover:text-text-primary",
            children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:127:14", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "127", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22X%22%7D", name: "X", size: 20 }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
              lineNumber: 127,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
            lineNumber: 123,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
        lineNumber: 121,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:131:10", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "131", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22px-6%20py-5%22%7D", className: "px-6 py-5", children: [
        step === 1 && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:134:12", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "134", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-center%22%7D", className: "text-center", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:135:16", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "135", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22mb-6%22%7D", className: "mb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:136:18", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "136", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-16%20h-16%20bg-primary-50%20rounded-full%20flex%20items-center%20justify-center%20mx-auto%20mb-4%22%7D", className: "w-16 h-16 bg-primary-50 rounded-full flex items-center justify-center mx-auto mb-4", children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:137:20", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "137", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Upload%22%2C%22className%22%3A%22text-primary%22%7D", name: "Upload", size: 24, className: "text-primary" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
              lineNumber: 137,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
              lineNumber: 136,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("h4", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:139:18", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "139", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "h4", "data-component-content": "%7B%22elementName%22%3A%22h4%22%2C%22className%22%3A%22text-lg%20font-medium%20text-text-primary%20mb-2%22%2C%22textContent%22%3A%22Upload%20Contact%20File%22%7D", className: "text-lg font-medium text-text-primary mb-2", children: "Upload Contact File" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
              lineNumber: 139,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:140:18", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "140", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20mb-4%22%2C%22textContent%22%3A%22Upload%20a%20CSV%20or%20Excel%20file%20with%20your%20contacts%20data.%22%7D", className: "text-text-secondary mb-4", children: "Upload a CSV or Excel file with your contacts data." }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
              lineNumber: 140,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
            lineNumber: 135,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:145:16", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "145", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22border-2%20border-dashed%20border-border%20rounded-lg%20p-8%20mb-6%22%7D", className: "border-2 border-dashed border-border rounded-lg p-8 mb-6", children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:146:18",
                "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx",
                "data-component-line": "146",
                "data-component-file": "ImportContactsModal.jsx",
                "data-component-name": "input",
                "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22file%22%2C%22id%22%3A%22contactFile%22%2C%22className%22%3A%22hidden%22%7D",
                type: "file",
                id: "contactFile",
                accept: ".csv,.xlsx,.xls",
                onChange: handleFileChange,
                className: "hidden"
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                lineNumber: 146,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:153:18",
                "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx",
                "data-component-line": "153",
                "data-component-file": "ImportContactsModal.jsx",
                "data-component-name": "label",
                "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22cursor-pointer%20flex%20flex-col%20items-center%20justify-center%22%7D",
                htmlFor: "contactFile",
                className: "cursor-pointer flex flex-col items-center justify-center",
                children: [
                  /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:157:20", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "157", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22FileText%22%2C%22className%22%3A%22text-text-tertiary%20mb-3%22%7D", name: "FileText", size: 36, className: "text-text-tertiary mb-3" }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                    lineNumber: 157,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:158:20", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "158", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-text-primary%20font-medium%20mb-1%22%2C%22textContent%22%3A%22Drag%20and%20drop%20your%20file%20here%20or%20click%20to%20browse%22%7D", className: "text-text-primary font-medium mb-1", children: "Drag and drop your file here or click to browse" }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                    lineNumber: 158,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:161:20", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "161", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-tertiary%22%2C%22textContent%22%3A%22Supports%20CSV%2C%20Excel%20(.xlsx%2C%20.xls)%22%7D", className: "text-sm text-text-tertiary", children: "Supports CSV, Excel (.xlsx, .xls)" }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                    lineNumber: 161,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                lineNumber: 153,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
            lineNumber: 145,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:167:16", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "167", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%7D", className: "text-sm text-text-secondary", children: [
            /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:168:18", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "168", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22mb-2%22%2C%22textContent%22%3A%22Your%20file%20should%20include%20the%20following%20columns%3A%22%7D", className: "mb-2", children: "Your file should include the following columns:" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
              lineNumber: 168,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("ul", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:169:18", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "169", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "ul", "data-component-content": "%7B%22elementName%22%3A%22ul%22%2C%22className%22%3A%22list-disc%20list-inside%20space-y-1%20text-left%22%7D", className: "list-disc list-inside space-y-1 text-left", children: [
              /* @__PURE__ */ jsxDEV("li", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:170:20", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "170", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "li", "data-component-content": "%7B%22elementName%22%3A%22li%22%2C%22textContent%22%3A%22First%20Name%22%7D", children: "First Name" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                lineNumber: 170,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("li", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:171:20", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "171", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "li", "data-component-content": "%7B%22elementName%22%3A%22li%22%2C%22textContent%22%3A%22Last%20Name%22%7D", children: "Last Name" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                lineNumber: 171,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("li", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:172:20", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "172", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "li", "data-component-content": "%7B%22elementName%22%3A%22li%22%2C%22textContent%22%3A%22Email%20Address%22%7D", children: "Email Address" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                lineNumber: 172,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("li", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:173:20", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "173", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "li", "data-component-content": "%7B%22elementName%22%3A%22li%22%2C%22textContent%22%3A%22Phone%20Number%20(optional)%22%7D", children: "Phone Number (optional)" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                lineNumber: 173,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("li", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:174:20", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "174", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "li", "data-component-content": "%7B%22elementName%22%3A%22li%22%2C%22textContent%22%3A%22Company%20Name%22%7D", children: "Company Name" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                lineNumber: 174,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("li", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:175:20", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "175", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "li", "data-component-content": "%7B%22elementName%22%3A%22li%22%2C%22textContent%22%3A%22Position%2FTitle%20(optional)%22%7D", children: "Position/Title (optional)" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                lineNumber: 175,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
              lineNumber: 169,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
            lineNumber: 167,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
          lineNumber: 134,
          columnNumber: 13
        }, this),
        step === 2 && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:183:12", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "183", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:184:16", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "184", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22mb-6%22%7D", className: "mb-6", children: [
            /* @__PURE__ */ jsxDEV("h4", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:185:18", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "185", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "h4", "data-component-content": "%7B%22elementName%22%3A%22h4%22%2C%22className%22%3A%22text-lg%20font-medium%20text-text-primary%20mb-2%22%2C%22textContent%22%3A%22Map%20Fields%22%7D", className: "text-lg font-medium text-text-primary mb-2", children: "Map Fields" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
              lineNumber: 185,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:186:18", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "186", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%22%2C%22textContent%22%3A%22Match%20your%20file%20columns%20to%20the%20appropriate%20contact%20fields.%22%7D", className: "text-text-secondary", children: "Match your file columns to the appropriate contact fields." }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
              lineNumber: 186,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
            lineNumber: 184,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:191:16", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "191", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-4%20mb-6%22%7D", className: "space-y-4 mb-6", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:192:18", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "192", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-2%20gap-4%22%7D", className: "grid grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:193:20", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "193", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:194:22", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "194", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-secondary%20mb-1%22%2C%22textContent%22%3A%22First%20Name*%22%7D", className: "block text-sm font-medium text-text-secondary mb-1", children: "First Name*" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                lineNumber: 194,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:197:22",
                  "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx",
                  "data-component-line": "197",
                  "data-component-file": "ImportContactsModal.jsx",
                  "data-component-name": "select",
                  "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22className%22%3A%22input-field%22%7D",
                  value: mappings?.firstName,
                  onChange: (e) => handleMappingChange("firstName", e?.target?.value),
                  className: "input-field",
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:202:24", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "202", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22%22%2C%22textContent%22%3A%22Select%20column%22%7D", value: "", children: "Select column" }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                      lineNumber: 202,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:203:24", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "203", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22firstName%22%2C%22textContent%22%3A%22firstName%22%7D", value: "firstName", children: "firstName" }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                      lineNumber: 203,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:204:24", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "204", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22first_name%22%2C%22textContent%22%3A%22first_name%22%7D", value: "first_name", children: "first_name" }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                      lineNumber: 204,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:205:24", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "205", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22FirstName%22%2C%22textContent%22%3A%22FirstName%22%7D", value: "FirstName", children: "FirstName" }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                      lineNumber: 205,
                      columnNumber: 25
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                  lineNumber: 197,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
              lineNumber: 193,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:209:20", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "209", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:210:22", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "210", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-secondary%20mb-1%22%2C%22textContent%22%3A%22Last%20Name*%22%7D", className: "block text-sm font-medium text-text-secondary mb-1", children: "Last Name*" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                lineNumber: 210,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:213:22",
                  "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx",
                  "data-component-line": "213",
                  "data-component-file": "ImportContactsModal.jsx",
                  "data-component-name": "select",
                  "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22className%22%3A%22input-field%22%7D",
                  value: mappings?.lastName,
                  onChange: (e) => handleMappingChange("lastName", e?.target?.value),
                  className: "input-field",
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:218:24", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "218", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22%22%2C%22textContent%22%3A%22Select%20column%22%7D", value: "", children: "Select column" }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                      lineNumber: 218,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:219:24", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "219", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22lastName%22%2C%22textContent%22%3A%22lastName%22%7D", value: "lastName", children: "lastName" }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                      lineNumber: 219,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:220:24", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "220", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22last_name%22%2C%22textContent%22%3A%22last_name%22%7D", value: "last_name", children: "last_name" }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                      lineNumber: 220,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:221:24", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "221", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22LastName%22%2C%22textContent%22%3A%22LastName%22%7D", value: "LastName", children: "LastName" }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                      lineNumber: 221,
                      columnNumber: 25
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                  lineNumber: 213,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
              lineNumber: 209,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:225:20", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "225", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:226:22", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "226", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-secondary%20mb-1%22%2C%22textContent%22%3A%22Email*%22%7D", className: "block text-sm font-medium text-text-secondary mb-1", children: "Email*" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                lineNumber: 226,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:229:22",
                  "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx",
                  "data-component-line": "229",
                  "data-component-file": "ImportContactsModal.jsx",
                  "data-component-name": "select",
                  "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22className%22%3A%22input-field%22%7D",
                  value: mappings?.email,
                  onChange: (e) => handleMappingChange("email", e?.target?.value),
                  className: "input-field",
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:234:24", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "234", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22%22%2C%22textContent%22%3A%22Select%20column%22%7D", value: "", children: "Select column" }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                      lineNumber: 234,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:235:24", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "235", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22email%22%2C%22textContent%22%3A%22email%22%7D", value: "email", children: "email" }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                      lineNumber: 235,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:236:24", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "236", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22email_address%22%2C%22textContent%22%3A%22email_address%22%7D", value: "email_address", children: "email_address" }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                      lineNumber: 236,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:237:24", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "237", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22Email%22%2C%22textContent%22%3A%22Email%22%7D", value: "Email", children: "Email" }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                      lineNumber: 237,
                      columnNumber: 25
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                  lineNumber: 229,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
              lineNumber: 225,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:241:20", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "241", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:242:22", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "242", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-secondary%20mb-1%22%2C%22textContent%22%3A%22Phone%22%7D", className: "block text-sm font-medium text-text-secondary mb-1", children: "Phone" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                lineNumber: 242,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:245:22",
                  "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx",
                  "data-component-line": "245",
                  "data-component-file": "ImportContactsModal.jsx",
                  "data-component-name": "select",
                  "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22className%22%3A%22input-field%22%7D",
                  value: mappings?.phone,
                  onChange: (e) => handleMappingChange("phone", e?.target?.value),
                  className: "input-field",
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:250:24", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "250", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22%22%2C%22textContent%22%3A%22Select%20column%22%7D", value: "", children: "Select column" }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                      lineNumber: 250,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:251:24", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "251", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22phone%22%2C%22textContent%22%3A%22phone%22%7D", value: "phone", children: "phone" }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                      lineNumber: 251,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:252:24", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "252", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22phone_number%22%2C%22textContent%22%3A%22phone_number%22%7D", value: "phone_number", children: "phone_number" }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                      lineNumber: 252,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:253:24", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "253", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22Phone%22%2C%22textContent%22%3A%22Phone%22%7D", value: "Phone", children: "Phone" }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                      lineNumber: 253,
                      columnNumber: 25
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                  lineNumber: 245,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
              lineNumber: 241,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:257:20", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "257", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:258:22", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "258", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-secondary%20mb-1%22%2C%22textContent%22%3A%22Company*%22%7D", className: "block text-sm font-medium text-text-secondary mb-1", children: "Company*" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                lineNumber: 258,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:261:22",
                  "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx",
                  "data-component-line": "261",
                  "data-component-file": "ImportContactsModal.jsx",
                  "data-component-name": "select",
                  "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22className%22%3A%22input-field%22%7D",
                  value: mappings?.company,
                  onChange: (e) => handleMappingChange("company", e?.target?.value),
                  className: "input-field",
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:266:24", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "266", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22%22%2C%22textContent%22%3A%22Select%20column%22%7D", value: "", children: "Select column" }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                      lineNumber: 266,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:267:24", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "267", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22company%22%2C%22textContent%22%3A%22company%22%7D", value: "company", children: "company" }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                      lineNumber: 267,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:268:24", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "268", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22company_name%22%2C%22textContent%22%3A%22company_name%22%7D", value: "company_name", children: "company_name" }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                      lineNumber: 268,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:269:24", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "269", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22Company%22%2C%22textContent%22%3A%22Company%22%7D", value: "Company", children: "Company" }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                      lineNumber: 269,
                      columnNumber: 25
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                  lineNumber: 261,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
              lineNumber: 257,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:273:20", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "273", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:274:22", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "274", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-secondary%20mb-1%22%2C%22textContent%22%3A%22Position%22%7D", className: "block text-sm font-medium text-text-secondary mb-1", children: "Position" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                lineNumber: 274,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:277:22",
                  "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx",
                  "data-component-line": "277",
                  "data-component-file": "ImportContactsModal.jsx",
                  "data-component-name": "select",
                  "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22className%22%3A%22input-field%22%7D",
                  value: mappings?.position,
                  onChange: (e) => handleMappingChange("position", e?.target?.value),
                  className: "input-field",
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:282:24", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "282", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22%22%2C%22textContent%22%3A%22Select%20column%22%7D", value: "", children: "Select column" }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                      lineNumber: 282,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:283:24", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "283", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22position%22%2C%22textContent%22%3A%22position%22%7D", value: "position", children: "position" }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                      lineNumber: 283,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:284:24", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "284", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22title%22%2C%22textContent%22%3A%22title%22%7D", value: "title", children: "title" }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                      lineNumber: 284,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:285:24", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "285", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22job_title%22%2C%22textContent%22%3A%22job_title%22%7D", value: "job_title", children: "job_title" }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                      lineNumber: 285,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:286:24", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "286", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22Position%22%2C%22textContent%22%3A%22Position%22%7D", value: "Position", children: "Position" }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                      lineNumber: 286,
                      columnNumber: 25
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                  lineNumber: 277,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
              lineNumber: 273,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
            lineNumber: 192,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
            lineNumber: 191,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:292:16", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "292", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22border%20border-border%20rounded-lg%20overflow-hidden%20mb-6%22%7D", className: "border border-border rounded-lg overflow-hidden mb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:293:18", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "293", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22px-4%20py-3%20bg-surface-hover%20text-sm%20font-medium%20text-text-primary%22%2C%22textContent%22%3A%22Preview%20(%20records)%22%7D", className: "px-4 py-3 bg-surface-hover text-sm font-medium text-text-primary", children: [
              "Preview (",
              preview?.length,
              " records)"
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
              lineNumber: 293,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:296:18", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "296", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22overflow-x-auto%22%7D", className: "overflow-x-auto", children: /* @__PURE__ */ jsxDEV("table", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:297:20", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "297", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "table", "data-component-content": "%7B%22elementName%22%3A%22table%22%2C%22className%22%3A%22min-w-full%20divide-y%20divide-border%22%7D", className: "min-w-full divide-y divide-border", children: [
              /* @__PURE__ */ jsxDEV("thead", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:298:22", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "298", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "thead", "data-component-content": "%7B%22elementName%22%3A%22thead%22%7D", children: /* @__PURE__ */ jsxDEV("tr", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:299:24", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "299", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "tr", "data-component-content": "%7B%22elementName%22%3A%22tr%22%7D", children: [
                /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:300:26", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "300", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22px-4%20py-3%20bg-surface-hover%20text-left%20text-xs%20font-medium%20text-text-secondary%20uppercase%20tracking-wider%22%2C%22textContent%22%3A%22First%20Name%22%7D", className: "px-4 py-3 bg-surface-hover text-left text-xs font-medium text-text-secondary uppercase tracking-wider", children: "First Name" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                  lineNumber: 300,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:303:26", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "303", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22px-4%20py-3%20bg-surface-hover%20text-left%20text-xs%20font-medium%20text-text-secondary%20uppercase%20tracking-wider%22%2C%22textContent%22%3A%22Last%20Name%22%7D", className: "px-4 py-3 bg-surface-hover text-left text-xs font-medium text-text-secondary uppercase tracking-wider", children: "Last Name" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                  lineNumber: 303,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:306:26", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "306", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22px-4%20py-3%20bg-surface-hover%20text-left%20text-xs%20font-medium%20text-text-secondary%20uppercase%20tracking-wider%22%2C%22textContent%22%3A%22Email%22%7D", className: "px-4 py-3 bg-surface-hover text-left text-xs font-medium text-text-secondary uppercase tracking-wider", children: "Email" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                  lineNumber: 306,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("th", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:309:26", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "309", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "th", "data-component-content": "%7B%22elementName%22%3A%22th%22%2C%22className%22%3A%22px-4%20py-3%20bg-surface-hover%20text-left%20text-xs%20font-medium%20text-text-secondary%20uppercase%20tracking-wider%22%2C%22textContent%22%3A%22Company%22%7D", className: "px-4 py-3 bg-surface-hover text-left text-xs font-medium text-text-secondary uppercase tracking-wider", children: "Company" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                  lineNumber: 309,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                lineNumber: 299,
                columnNumber: 25
              }, this) }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                lineNumber: 298,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("tbody", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:314:22", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "314", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "tbody", "data-component-content": "%7B%22elementName%22%3A%22tbody%22%2C%22className%22%3A%22bg-surface%20divide-y%20divide-border%22%7D", className: "bg-surface divide-y divide-border", children: preview?.slice(0, 3)?.map(
                (item, index) => /* @__PURE__ */ jsxDEV("tr", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:316:22", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "316", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "tr", "data-component-content": "%7B%22elementName%22%3A%22tr%22%7D", children: [
                  /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:317:28", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "317", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22px-4%20py-3%20whitespace-nowrap%20text-sm%20text-text-primary%22%7D", className: "px-4 py-3 whitespace-nowrap text-sm text-text-primary", children: item?.[mappings?.firstName] || "-" }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                    lineNumber: 317,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:320:28", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "320", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22px-4%20py-3%20whitespace-nowrap%20text-sm%20text-text-primary%22%7D", className: "px-4 py-3 whitespace-nowrap text-sm text-text-primary", children: item?.[mappings?.lastName] || "-" }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                    lineNumber: 320,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:323:28", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "323", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22px-4%20py-3%20whitespace-nowrap%20text-sm%20text-text-primary%22%7D", className: "px-4 py-3 whitespace-nowrap text-sm text-text-primary", children: item?.[mappings?.email] || "-" }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                    lineNumber: 323,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:326:28", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "326", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "td", "data-component-content": "%7B%22elementName%22%3A%22td%22%2C%22className%22%3A%22px-4%20py-3%20whitespace-nowrap%20text-sm%20text-text-primary%22%7D", className: "px-4 py-3 whitespace-nowrap text-sm text-text-primary", children: item?.[mappings?.company] || "-" }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                    lineNumber: 326,
                    columnNumber: 29
                  }, this)
                ] }, index, true, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                  lineNumber: 316,
                  columnNumber: 23
                }, this)
              ) }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                lineNumber: 314,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
              lineNumber: 297,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
              lineNumber: 296,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
            lineNumber: 292,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
          lineNumber: 183,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
        lineNumber: 131,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:339:10", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "339", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22px-6%20py-4%20border-t%20border-border%20flex%20justify-between%22%7D", className: "px-6 py-4 border-t border-border flex justify-between", children: [
        step === 1 ? /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:341:12",
            "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx",
            "data-component-line": "341",
            "data-component-file": "ImportContactsModal.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22px-4%20py-2%20border%20border-border%20rounded-lg%20text-text-secondary%20hover%3Atext-text-primary%20hover%3Abg-surface-hover%20transition-all%20duration-150%20ease-out%22%2C%22textContent%22%3A%22Cancel%22%7D",
            onClick: onClose,
            className: "px-4 py-2 border border-border rounded-lg text-text-secondary hover:text-text-primary hover:bg-surface-hover transition-all duration-150 ease-out",
            children: "Cancel"
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
            lineNumber: 341,
            columnNumber: 13
          },
          this
        ) : /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:348:12",
            "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx",
            "data-component-line": "348",
            "data-component-file": "ImportContactsModal.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22inline-flex%20items-center%20px-4%20py-2%20border%20border-border%20rounded-lg%20text-text-secondary%20hover%3Atext-text-primary%20hover%3Abg-surface-hover%20transition-all%20duration-150%20ease-out%22%2C%22textContent%22%3A%22Back%22%7D",
            onClick: () => setStep(1),
            className: "inline-flex items-center px-4 py-2 border border-border rounded-lg text-text-secondary hover:text-text-primary hover:bg-surface-hover transition-all duration-150 ease-out",
            children: [
              /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:352:16", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "352", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22ArrowLeft%22%2C%22className%22%3A%22mr-2%22%7D", name: "ArrowLeft", size: 16, className: "mr-2" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                lineNumber: 352,
                columnNumber: 17
              }, this),
              "Back"
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
            lineNumber: 348,
            columnNumber: 13
          },
          this
        ),
        step === 1 ? /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:358:12",
            "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx",
            "data-component-line": "358",
            "data-component-file": "ImportContactsModal.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22textContent%22%3A%22Next%22%7D",
            disabled: !file,
            className: `btn-primary ${!file ? "opacity-50 cursor-not-allowed" : ""}`,
            children: "Next"
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
            lineNumber: 358,
            columnNumber: 13
          },
          this
        ) : /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:365:12",
            "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx",
            "data-component-line": "365",
            "data-component-file": "ImportContactsModal.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%7D",
            onClick: handleImport,
            disabled: isLoading || !mappings?.firstName || !mappings?.lastName || !mappings?.email || !mappings?.company,
            className: `btn-primary inline-flex items-center ${isLoading || !mappings?.firstName || !mappings?.lastName || !mappings?.email || !mappings?.company ? "opacity-50 cursor-not-allowed" : ""}`,
            children: isLoading ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx:375:20", "data-component-path": "src\\pages\\contact-management\\components\\ImportContactsModal.jsx", "data-component-line": "375", "data-component-file": "ImportContactsModal.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Loader%22%2C%22className%22%3A%22animate-spin%20mr-2%22%7D", name: "Loader", size: 16, className: "animate-spin mr-2" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
                lineNumber: 375,
                columnNumber: 21
              }, this),
              "Importing..."
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
              lineNumber: 374,
              columnNumber: 15
            }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: "Import Contacts" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
              lineNumber: 379,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
            lineNumber: 365,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
        lineNumber: 339,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
      lineNumber: 120,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
    lineNumber: 113,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx",
    lineNumber: 112,
    columnNumber: 5
  }, this);
};
_s(ImportContactsModal, "iQ7coSInx1PZwDxhZmSwcDjE0nY=");
_c = ImportContactsModal;
export default ImportContactsModal;
var _c;
$RefreshReg$(_c, "ImportContactsModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/contact-management/components/ImportContactsModal.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0hVLFNBbVFRLFVBblFSOzJCQWxIVjtBQUFnQkEsTUFBUSxjQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3ZDLE9BQU9DLFVBQVU7QUFFakIsTUFBTUMsc0JBQXNCQSxDQUFDLEVBQUVDLFVBQVVDLFFBQVEsTUFBTTtBQUFBQyxLQUFBO0FBQ3JELFFBQU0sQ0FBQ0MsTUFBTUMsT0FBTyxJQUFJUCxTQUFTLENBQUM7QUFDbEMsUUFBTSxDQUFDUSxNQUFNQyxPQUFPLElBQUlULFNBQVMsSUFBSTtBQUNyQyxRQUFNLENBQUNVLFVBQVVDLFdBQVcsSUFBSVgsU0FBUztBQUFBLElBQ3ZDWSxXQUFXO0FBQUEsSUFDWEMsVUFBVTtBQUFBLElBQ1ZDLE9BQU87QUFBQSxJQUNQQyxPQUFPO0FBQUEsSUFDUEMsU0FBUztBQUFBLElBQ1RDLFVBQVU7QUFBQSxFQUNaLENBQUM7QUFDRCxRQUFNLENBQUNDLFNBQVNDLFVBQVUsSUFBSW5CLFNBQVMsRUFBRTtBQUN6QyxRQUFNLENBQUNvQixXQUFXQyxZQUFZLElBQUlyQixTQUFTLEtBQUs7QUFFaEQsUUFBTXNCLG1CQUFtQkEsQ0FBQ0MsTUFBTTtBQUM5QixVQUFNQyxlQUFlRCxHQUFHRSxRQUFRQyxRQUFRLENBQUM7QUFDekMsUUFBSUYsY0FBYztBQUNoQmYsY0FBUWUsWUFBWTtBQUdwQkcsaUJBQVcsTUFBTTtBQUVmLGNBQU1DLGNBQWM7QUFBQSxVQUNsQjtBQUFBLFlBQ0VoQixXQUFXO0FBQUEsWUFDWEMsVUFBVTtBQUFBLFlBQ1ZDLE9BQU87QUFBQSxZQUNQQyxPQUFPO0FBQUEsWUFDUEMsU0FBUztBQUFBLFlBQ1RDLFVBQVU7QUFBQSxVQUNaO0FBQUEsVUFDQTtBQUFBLFlBQ0VMLFdBQVc7QUFBQSxZQUNYQyxVQUFVO0FBQUEsWUFDVkMsT0FBTztBQUFBLFlBQ1BDLE9BQU87QUFBQSxZQUNQQyxTQUFTO0FBQUEsWUFDVEMsVUFBVTtBQUFBLFVBQ1o7QUFBQSxVQUNBO0FBQUEsWUFDRUwsV0FBVztBQUFBLFlBQ1hDLFVBQVU7QUFBQSxZQUNWQyxPQUFPO0FBQUEsWUFDUEMsT0FBTztBQUFBLFlBQ1BDLFNBQVM7QUFBQSxZQUNUQyxVQUFVO0FBQUEsVUFDWjtBQUFBLFFBQUM7QUFHSEUsbUJBQVdTLFdBQVc7QUFHdEJqQixvQkFBWTtBQUFBLFVBQ1ZDLFdBQVc7QUFBQSxVQUNYQyxVQUFVO0FBQUEsVUFDVkMsT0FBTztBQUFBLFVBQ1BDLE9BQU87QUFBQSxVQUNQQyxTQUFTO0FBQUEsVUFDVEMsVUFBVTtBQUFBLFFBQ1osQ0FBQztBQUVEVixnQkFBUSxDQUFDO0FBQUEsTUFDWCxHQUFHLEdBQUc7QUFBQSxJQUNSO0FBQUEsRUFDRjtBQUVBLFFBQU1zQixzQkFBc0JBLENBQUNDLE9BQU9DLFVBQVU7QUFDNUNwQixnQkFBWTtBQUFBLE1BQ1YsR0FBR0Q7QUFBQUEsTUFDSCxDQUFDb0IsS0FBSyxHQUFHQztBQUFBQSxJQUNYLENBQUM7QUFBQSxFQUNIO0FBRUEsUUFBTUMsZUFBZUEsTUFBTTtBQUN6QlgsaUJBQWEsSUFBSTtBQUdqQk0sZUFBVyxNQUFNO0FBRWYsWUFBTU0sbUJBQW1CZixTQUFTZ0IsSUFBSSxDQUFDQyxNQUFNQyxXQUFXO0FBQUEsUUFDdERDLElBQUlDLEtBQUtDLElBQUksSUFBSUg7QUFBQUEsUUFDakJ4QixXQUFXdUIsT0FBT3pCLFVBQVVFLFNBQVMsS0FBSztBQUFBLFFBQzFDQyxVQUFVc0IsT0FBT3pCLFVBQVVHLFFBQVEsS0FBSztBQUFBLFFBQ3hDQyxPQUFPcUIsT0FBT3pCLFVBQVVJLEtBQUssS0FBSztBQUFBLFFBQ2xDQyxPQUFPb0IsT0FBT3pCLFVBQVVLLEtBQUssS0FBSztBQUFBLFFBQ2xDQyxTQUFTbUIsT0FBT3pCLFVBQVVNLE9BQU8sS0FBSztBQUFBLFFBQ3RDQyxVQUFVa0IsT0FBT3pCLFVBQVVPLFFBQVEsS0FBSztBQUFBLFFBQ3hDdUIsUUFBUSx1Q0FBdUNKLFFBQVEsTUFBTSxJQUFJLFFBQVEsT0FBTyxJQUFJSyxLQUFLQyxNQUFNRCxLQUFLRSxPQUFPLElBQUksR0FBRyxDQUFDO0FBQUEsUUFDbkhDLGtCQUFpQixvQkFBSU4sS0FBSyxJQUFHTyxZQUFZO0FBQUEsUUFDekNDLFFBQVE7QUFBQSxRQUNSQyxNQUFNO0FBQUEsUUFDTkMsT0FBTztBQUFBLFFBQ1BDLE9BQU87QUFBQSxRQUNQQyxnQkFBZ0IsQ0FBQztBQUFBLFFBQ2pCQyxZQUFZO0FBQUEsUUFDWkMsY0FBYztBQUFBLFVBQ1pDLHdCQUF3QjtBQUFBLFVBQ3hCQyxtQkFBbUI7QUFBQSxVQUNuQkMsYUFBYTtBQUFBLFFBQ2Y7QUFBQSxNQUNGLEVBQUU7QUFFRnBELGVBQVM4QixnQkFBZ0I7QUFDekJaLG1CQUFhLEtBQUs7QUFBQSxJQUNwQixHQUFHLEdBQUk7QUFBQSxFQUNUO0FBRUEsU0FDRSx1QkFBQyw2YkFBSSxXQUFVLHdDQUNiLGlDQUFDLGtnQkFBSSxXQUFVLDZGQUNiO0FBQUEsMkJBQUMsdWJBQUksV0FBVSxvQ0FBbUMsZUFBWSxRQUM1RCxpQ0FBQyxpY0FBSSxXQUFVLDZDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUQsS0FEM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFFQSx1QkFBQywwZkFBSyxXQUFVLHNEQUFxRCxlQUFZLFFBQU8saUJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0Y7QUFBQSxJQUUvRix1QkFBQyw4bEJBQUksV0FBVSwyS0FDYjtBQUFBLDZCQUFDLGtlQUFJLFdBQVUsc0VBQ2I7QUFBQSwrQkFBQywwZUFBRyxXQUFVLDJDQUEwQywrQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RTtBQUFBLFFBQ3ZFO0FBQUEsVUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFDQyxTQUFTakI7QUFBQUEsWUFDVCxXQUFVO0FBQUEsWUFFVixpQ0FBQyxpWkFBSyxNQUFLLEtBQUksTUFBTSxNQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3QjtBQUFBO0FBQUEsVUFKMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxXQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BRUEsdUJBQUMsK1pBQUksV0FBVSxhQUVaRTtBQUFBQSxpQkFBUyxLQUNSLHVCQUFDLCtaQUFJLFdBQVUsZUFDYjtBQUFBLGlDQUFDLHdaQUFJLFdBQVUsUUFDYjtBQUFBLG1DQUFDLHNmQUFJLFdBQVUsc0ZBQ2IsaUNBQUMsNmJBQUssTUFBSyxVQUFTLE1BQU0sSUFBSSxXQUFVLGtCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRCxLQUR4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxxZkFBRyxXQUFVLDhDQUE2QyxtQ0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEU7QUFBQSxZQUM5RSx1QkFBQywwZ0JBQUUsV0FBVSw0QkFBMkIsbUVBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxVQUVBLHVCQUFDLHNkQUFJLFdBQVUsNERBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxJQUFHO0FBQUEsZ0JBQ0gsUUFBTztBQUFBLGdCQUNQLFVBQVVnQjtBQUFBQSxnQkFDVixXQUFVO0FBQUE7QUFBQSxjQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtvQjtBQUFBLFlBRXBCO0FBQUEsY0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ0MsU0FBUTtBQUFBLGdCQUNSLFdBQVU7QUFBQSxnQkFFVjtBQUFBLHlDQUFDLDRjQUFLLE1BQUssWUFBVyxNQUFNLElBQUksV0FBVSw2QkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBbUU7QUFBQSxrQkFDbkUsdUJBQUMsMmhCQUFLLFdBQVUsc0NBQXFDLCtEQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsNmZBQUssV0FBVSw4QkFBNkIsaURBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQTtBQUFBO0FBQUEsY0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFXQTtBQUFBLGVBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0JBO0FBQUEsVUFFQSx1QkFBQyxpYkFBSSxXQUFVLCtCQUNiO0FBQUEsbUNBQUMsNGVBQUUsV0FBVSxRQUFPLCtEQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRTtBQUFBLFlBQ25FLHVCQUFDLGdjQUFHLFdBQVUsNkNBQ1o7QUFBQSxxQ0FBQywrWkFBRywwQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFjO0FBQUEsY0FDZCx1QkFBQyw4WkFBRyx5QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFhO0FBQUEsY0FDYix1QkFBQyxrYUFBRyw2QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpQjtBQUFBLGNBQ2pCLHVCQUFDLDhhQUFHLHVDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJCO0FBQUEsY0FDM0IsdUJBQUMsaWFBQUcsNEJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0I7QUFBQSxjQUNoQix1QkFBQyxnYkFBRyx5Q0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2QjtBQUFBLGlCQU4vQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsZUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsYUEzQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTRDQTtBQUFBLFFBSURoQixTQUFTLEtBQ1IsdUJBQUMseVhBQ0M7QUFBQSxpQ0FBQyx3WkFBSSxXQUFVLFFBQ2I7QUFBQSxtQ0FBQywwZUFBRyxXQUFVLDhDQUE2QywwQkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUU7QUFBQSxZQUNyRSx1QkFBQyx3Z0JBQUUsV0FBVSx1QkFBc0IsMEVBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUVBLHVCQUFDLG9hQUFJLFdBQVUsa0JBQ2IsaUNBQUMsOGFBQUksV0FBVSwwQkFDYjtBQUFBLG1DQUFDLHlYQUNDO0FBQUEscUNBQUMsOGZBQU0sV0FBVSxzREFBcUQsMkJBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUNDLE9BQU9JLFVBQVVFO0FBQUFBLGtCQUNqQixVQUFVLENBQUNXLE1BQU1NLG9CQUFvQixhQUFhTixHQUFHRSxRQUFRTSxLQUFLO0FBQUEsa0JBQ2xFLFdBQVU7QUFBQSxrQkFFVjtBQUFBLDJDQUFDLHFjQUFPLE9BQU0sSUFBRyw2QkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBOEI7QUFBQSxvQkFDOUIsdUJBQUMsd2NBQU8sT0FBTSxhQUFZLHlCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFtQztBQUFBLG9CQUNuQyx1QkFBQywwY0FBTyxPQUFNLGNBQWEsMEJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXFDO0FBQUEsb0JBQ3JDLHVCQUFDLHdjQUFPLE9BQU0sYUFBWSx5QkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBbUM7QUFBQTtBQUFBO0FBQUEsZ0JBUnJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVNBO0FBQUEsaUJBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFjQTtBQUFBLFlBRUEsdUJBQUMseVhBQ0M7QUFBQSxxQ0FBQyw2ZkFBTSxXQUFVLHNEQUFxRCwwQkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBQ0MsT0FBT3JCLFVBQVVHO0FBQUFBLGtCQUNqQixVQUFVLENBQUNVLE1BQU1NLG9CQUFvQixZQUFZTixHQUFHRSxRQUFRTSxLQUFLO0FBQUEsa0JBQ2pFLFdBQVU7QUFBQSxrQkFFVjtBQUFBLDJDQUFDLHFjQUFPLE9BQU0sSUFBRyw2QkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBOEI7QUFBQSxvQkFDOUIsdUJBQUMsc2NBQU8sT0FBTSxZQUFXLHdCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpQztBQUFBLG9CQUNqQyx1QkFBQyx3Y0FBTyxPQUFNLGFBQVkseUJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW1DO0FBQUEsb0JBQ25DLHVCQUFDLHNjQUFPLE9BQU0sWUFBVyx3QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUM7QUFBQTtBQUFBO0FBQUEsZ0JBUm5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVNBO0FBQUEsaUJBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFjQTtBQUFBLFlBRUEsdUJBQUMseVhBQ0M7QUFBQSxxQ0FBQyx1ZkFBTSxXQUFVLHNEQUFxRCxzQkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBQ0MsT0FBT3JCLFVBQVVJO0FBQUFBLGtCQUNqQixVQUFVLENBQUNTLE1BQU1NLG9CQUFvQixTQUFTTixHQUFHRSxRQUFRTSxLQUFLO0FBQUEsa0JBQzlELFdBQVU7QUFBQSxrQkFFVjtBQUFBLDJDQUFDLHFjQUFPLE9BQU0sSUFBRyw2QkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBOEI7QUFBQSxvQkFDOUIsdUJBQUMsZ2NBQU8sT0FBTSxTQUFRLHFCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUEyQjtBQUFBLG9CQUMzQix1QkFBQyxnZEFBTyxPQUFNLGlCQUFnQiw2QkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBMkM7QUFBQSxvQkFDM0MsdUJBQUMsZ2NBQU8sT0FBTSxTQUFRLHFCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUEyQjtBQUFBO0FBQUE7QUFBQSxnQkFSN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBU0E7QUFBQSxpQkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWNBO0FBQUEsWUFFQSx1QkFBQyx5WEFDQztBQUFBLHFDQUFDLHNmQUFNLFdBQVUsc0RBQXFELHFCQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFDQyxPQUFPckIsVUFBVUs7QUFBQUEsa0JBQ2pCLFVBQVUsQ0FBQ1EsTUFBTU0sb0JBQW9CLFNBQVNOLEdBQUdFLFFBQVFNLEtBQUs7QUFBQSxrQkFDOUQsV0FBVTtBQUFBLGtCQUVWO0FBQUEsMkNBQUMscWNBQU8sT0FBTSxJQUFHLDZCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE4QjtBQUFBLG9CQUM5Qix1QkFBQyxnY0FBTyxPQUFNLFNBQVEscUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTJCO0FBQUEsb0JBQzNCLHVCQUFDLDhjQUFPLE9BQU0sZ0JBQWUsNEJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXlDO0FBQUEsb0JBQ3pDLHVCQUFDLGdjQUFPLE9BQU0sU0FBUSxxQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBMkI7QUFBQTtBQUFBO0FBQUEsZ0JBUjdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVNBO0FBQUEsaUJBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFjQTtBQUFBLFlBRUEsdUJBQUMseVhBQ0M7QUFBQSxxQ0FBQyx5ZkFBTSxXQUFVLHNEQUFxRCx3QkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBQ0MsT0FBT3JCLFVBQVVNO0FBQUFBLGtCQUNqQixVQUFVLENBQUNPLE1BQU1NLG9CQUFvQixXQUFXTixHQUFHRSxRQUFRTSxLQUFLO0FBQUEsa0JBQ2hFLFdBQVU7QUFBQSxrQkFFVjtBQUFBLDJDQUFDLHFjQUFPLE9BQU0sSUFBRyw2QkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBOEI7QUFBQSxvQkFDOUIsdUJBQUMsb2NBQU8sT0FBTSxXQUFVLHVCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUErQjtBQUFBLG9CQUMvQix1QkFBQyw4Y0FBTyxPQUFNLGdCQUFlLDRCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF5QztBQUFBLG9CQUN6Qyx1QkFBQyxvY0FBTyxPQUFNLFdBQVUsdUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQStCO0FBQUE7QUFBQTtBQUFBLGdCQVJqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FTQTtBQUFBLGlCQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBY0E7QUFBQSxZQUVBLHVCQUFDLHlYQUNDO0FBQUEscUNBQUMseWZBQU0sV0FBVSxzREFBcUQsd0JBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUNDLE9BQU9yQixVQUFVTztBQUFBQSxrQkFDakIsVUFBVSxDQUFDTSxNQUFNTSxvQkFBb0IsWUFBWU4sR0FBR0UsUUFBUU0sS0FBSztBQUFBLGtCQUNqRSxXQUFVO0FBQUEsa0JBRVY7QUFBQSwyQ0FBQyxxY0FBTyxPQUFNLElBQUcsNkJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQThCO0FBQUEsb0JBQzlCLHVCQUFDLHNjQUFPLE9BQU0sWUFBVyx3QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUM7QUFBQSxvQkFDakMsdUJBQUMsZ2NBQU8sT0FBTSxTQUFRLHFCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUEyQjtBQUFBLG9CQUMzQix1QkFBQyx3Y0FBTyxPQUFNLGFBQVkseUJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW1DO0FBQUEsb0JBQ25DLHVCQUFDLHNjQUFPLE9BQU0sWUFBVyx3QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUM7QUFBQTtBQUFBO0FBQUEsZ0JBVG5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVVBO0FBQUEsaUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFlQTtBQUFBLGVBaEdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUdBLEtBbEdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUdBO0FBQUEsVUFFQSx1QkFBQyxnZEFBSSxXQUFVLHdEQUNiO0FBQUEsbUNBQUMsaWhCQUFJLFdBQVUsb0VBQW1FO0FBQUE7QUFBQSxjQUN0RWIsU0FBU3NDO0FBQUFBLGNBQU87QUFBQSxpQkFENUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsbWFBQUksV0FBVSxtQkFDYixpQ0FBQywrYkFBTSxXQUFVLHFDQUNmO0FBQUEscUNBQUMsK1hBQ0MsaUNBQUMsc1hBQ0M7QUFBQSx1Q0FBQywraUJBQUcsV0FBVSx5R0FBd0csMEJBQXRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyw4aUJBQUcsV0FBVSx5R0FBd0cseUJBQXRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyx3aUJBQUcsV0FBVSx5R0FBd0cscUJBQXRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQywwaUJBQUcsV0FBVSx5R0FBd0csdUJBQXRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWFBLEtBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFlQTtBQUFBLGNBQ0EsdUJBQUMsK2JBQU0sV0FBVSxxQ0FDZHRDLG1CQUFTdUMsTUFBTSxHQUFHLENBQUMsR0FBR3ZCO0FBQUFBLGdCQUFJLENBQUNDLE1BQU1DLFVBQ2hDLHVCQUFDLHNYQUNDO0FBQUEseUNBQUMsOGNBQUcsV0FBVSx5REFDWEQsaUJBQU96QixVQUFVRSxTQUFTLEtBQUssT0FEbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLDhjQUFHLFdBQVUseURBQ1h1QixpQkFBT3pCLFVBQVVHLFFBQVEsS0FBSyxPQURqQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsOGNBQUcsV0FBVSx5REFDWHNCLGlCQUFPekIsVUFBVUksS0FBSyxLQUFLLE9BRDlCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyw4Y0FBRyxXQUFVLHlEQUNYcUIsaUJBQU96QixVQUFVTSxPQUFPLEtBQUssT0FEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQVpPb0IsT0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWFBO0FBQUEsY0FDRCxLQWhCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWlCQTtBQUFBLGlCQWxDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW1DQSxLQXBDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXFDQTtBQUFBLGVBekNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMENBO0FBQUEsYUF2SkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdKQTtBQUFBLFdBNU1KO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4TUE7QUFBQSxNQUVBLHVCQUFDLG1kQUFJLFdBQVUseURBQ1o5QjtBQUFBQSxpQkFBUyxJQUNSO0FBQUEsVUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFDQyxTQUFTRjtBQUFBQSxZQUNULFdBQVU7QUFBQSxZQUFtSjtBQUFBO0FBQUEsVUFGL0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0EsSUFFQTtBQUFBLFVBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNRyxRQUFRLENBQUM7QUFBQSxZQUN4QixXQUFVO0FBQUEsWUFFVjtBQUFBLHFDQUFDLHdiQUFLLE1BQUssYUFBWSxNQUFNLElBQUksV0FBVSxVQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpRDtBQUFBLGNBQUc7QUFBQTtBQUFBO0FBQUEsVUFKdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUE7QUFBQSxRQUdERCxTQUFTLElBQ1I7QUFBQSxVQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUNDLFVBQVUsQ0FBQ0U7QUFBQUEsWUFDWCxXQUFXLGVBQWUsQ0FBQ0EsT0FBTyxrQ0FBa0MsRUFBRTtBQUFBLFlBQUc7QUFBQTtBQUFBLFVBRjNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBLElBRUE7QUFBQSxVQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUNDLFNBQVN3QjtBQUFBQSxZQUNULFVBQVVaLGFBQWEsQ0FBQ1YsVUFBVUUsYUFBYSxDQUFDRixVQUFVRyxZQUFZLENBQUNILFVBQVVJLFNBQVMsQ0FBQ0osVUFBVU07QUFBQUEsWUFDckcsV0FBVyx3Q0FDVEksYUFBYSxDQUFDVixVQUFVRSxhQUFhLENBQUNGLFVBQVVHLFlBQVksQ0FBQ0gsVUFBVUksU0FBUyxDQUFDSixVQUFVTSxVQUN2RixrQ0FBaUMsRUFBRTtBQUFBLFlBR3hDSSxzQkFDQyxtQ0FDRTtBQUFBLHFDQUFDLG9jQUFLLE1BQUssVUFBUyxNQUFNLElBQUksV0FBVSx1QkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkQ7QUFBQSxjQUFHO0FBQUEsaUJBRGhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0EsSUFFQSxtQ0FBRSwrQkFBRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUE7QUFBQSxVQWhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFrQkE7QUFBQSxXQTVDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBOENBO0FBQUEsU0F6UUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBRQTtBQUFBLE9BalJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrUkEsS0FuUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW9SQTtBQUVKO0FBQUVmLEdBbFlJSCxxQkFBbUI7QUFBQXdELEtBQW5CeEQ7QUFvWU4sZUFBZUE7QUFBb0IsSUFBQXdEO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkljb24iLCJJbXBvcnRDb250YWN0c01vZGFsIiwib25JbXBvcnQiLCJvbkNsb3NlIiwiX3MiLCJzdGVwIiwic2V0U3RlcCIsImZpbGUiLCJzZXRGaWxlIiwibWFwcGluZ3MiLCJzZXRNYXBwaW5ncyIsImZpcnN0TmFtZSIsImxhc3ROYW1lIiwiZW1haWwiLCJwaG9uZSIsImNvbXBhbnkiLCJwb3NpdGlvbiIsInByZXZpZXciLCJzZXRQcmV2aWV3IiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwiaGFuZGxlRmlsZUNoYW5nZSIsImUiLCJzZWxlY3RlZEZpbGUiLCJ0YXJnZXQiLCJmaWxlcyIsInNldFRpbWVvdXQiLCJtb2NrUHJldmlldyIsImhhbmRsZU1hcHBpbmdDaGFuZ2UiLCJmaWVsZCIsInZhbHVlIiwiaGFuZGxlSW1wb3J0IiwiaW1wb3J0ZWRDb250YWN0cyIsIm1hcCIsIml0ZW0iLCJpbmRleCIsImlkIiwiRGF0ZSIsIm5vdyIsImF2YXRhciIsIk1hdGgiLCJmbG9vciIsInJhbmRvbSIsImxhc3RDb250YWN0RGF0ZSIsInRvSVNPU3RyaW5nIiwic3RhdHVzIiwidGFncyIsImRlYWxzIiwibm90ZXMiLCJzb2NpYWxQcm9maWxlcyIsImFjdGl2aXRpZXMiLCJjdXN0b21GaWVsZHMiLCJwcmVmZXJyZWRDb250YWN0TWV0aG9kIiwiZGVjaXNpb25UaW1lZnJhbWUiLCJidWRnZXRSYW5nZSIsImxlbmd0aCIsInNsaWNlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJJbXBvcnRDb250YWN0c01vZGFsLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCBJY29uIGZyb20gJ2NvbXBvbmVudHMvQXBwSWNvbic7XHJcblxyXG5jb25zdCBJbXBvcnRDb250YWN0c01vZGFsID0gKHsgb25JbXBvcnQsIG9uQ2xvc2UgfSkgPT4ge1xyXG4gIGNvbnN0IFtzdGVwLCBzZXRTdGVwXSA9IHVzZVN0YXRlKDEpO1xyXG4gIGNvbnN0IFtmaWxlLCBzZXRGaWxlXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFttYXBwaW5ncywgc2V0TWFwcGluZ3NdID0gdXNlU3RhdGUoe1xyXG4gICAgZmlyc3ROYW1lOiAnJyxcclxuICAgIGxhc3ROYW1lOiAnJyxcclxuICAgIGVtYWlsOiAnJyxcclxuICAgIHBob25lOiAnJyxcclxuICAgIGNvbXBhbnk6ICcnLFxyXG4gICAgcG9zaXRpb246ICcnXHJcbiAgfSk7XHJcbiAgY29uc3QgW3ByZXZpZXcsIHNldFByZXZpZXddID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZUZpbGVDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3Qgc2VsZWN0ZWRGaWxlID0gZT8udGFyZ2V0Py5maWxlcz8uWzBdO1xyXG4gICAgaWYgKHNlbGVjdGVkRmlsZSkge1xyXG4gICAgICBzZXRGaWxlKHNlbGVjdGVkRmlsZSk7XHJcbiAgICAgIFxyXG4gICAgICAvLyBNb2NrIENTViBwYXJzaW5nXHJcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgIC8vIFRoaXMgd291bGQgbm9ybWFsbHkgcGFyc2UgdGhlIENTViBmaWxlXHJcbiAgICAgICAgY29uc3QgbW9ja1ByZXZpZXcgPSBbXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGZpcnN0TmFtZTogJ0pvaG4nLFxyXG4gICAgICAgICAgICBsYXN0TmFtZTogJ0RvZScsXHJcbiAgICAgICAgICAgIGVtYWlsOiAnam9obi5kb2VAZXhhbXBsZS5jb20nLFxyXG4gICAgICAgICAgICBwaG9uZTogJysxICg1NTUpIDEyMy00NTY3JyxcclxuICAgICAgICAgICAgY29tcGFueTogJ0V4YW1wbGUgQ29ycCcsXHJcbiAgICAgICAgICAgIHBvc2l0aW9uOiAnU2FsZXMgTWFuYWdlcidcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGZpcnN0TmFtZTogJ0phbmUnLFxyXG4gICAgICAgICAgICBsYXN0TmFtZTogJ1NtaXRoJyxcclxuICAgICAgICAgICAgZW1haWw6ICdqYW5lLnNtaXRoQGV4YW1wbGUuY29tJyxcclxuICAgICAgICAgICAgcGhvbmU6ICcrMSAoNTU1KSA5ODctNjU0MycsXHJcbiAgICAgICAgICAgIGNvbXBhbnk6ICdTYW1wbGUgSW5jJyxcclxuICAgICAgICAgICAgcG9zaXRpb246ICdNYXJrZXRpbmcgRGlyZWN0b3InXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBmaXJzdE5hbWU6ICdSb2JlcnQnLFxyXG4gICAgICAgICAgICBsYXN0TmFtZTogJ0pvaG5zb24nLFxyXG4gICAgICAgICAgICBlbWFpbDogJ3JvYmVydC5qb2huc29uQGV4YW1wbGUuY29tJyxcclxuICAgICAgICAgICAgcGhvbmU6ICcrMSAoNTU1KSA0NTYtNzg5MCcsXHJcbiAgICAgICAgICAgIGNvbXBhbnk6ICdUZXN0IExMQycsXHJcbiAgICAgICAgICAgIHBvc2l0aW9uOiAnQ0VPJ1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIF07XHJcbiAgICAgICAgXHJcbiAgICAgICAgc2V0UHJldmlldyhtb2NrUHJldmlldyk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy8gQXV0by1tYXAgY29sdW1ucyBiYXNlZCBvbiBoZWFkZXJzXHJcbiAgICAgICAgc2V0TWFwcGluZ3Moe1xyXG4gICAgICAgICAgZmlyc3ROYW1lOiAnZmlyc3ROYW1lJyxcclxuICAgICAgICAgIGxhc3ROYW1lOiAnbGFzdE5hbWUnLFxyXG4gICAgICAgICAgZW1haWw6ICdlbWFpbCcsXHJcbiAgICAgICAgICBwaG9uZTogJ3Bob25lJyxcclxuICAgICAgICAgIGNvbXBhbnk6ICdjb21wYW55JyxcclxuICAgICAgICAgIHBvc2l0aW9uOiAncG9zaXRpb24nXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgc2V0U3RlcCgyKTtcclxuICAgICAgfSwgNTAwKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVNYXBwaW5nQ2hhbmdlID0gKGZpZWxkLCB2YWx1ZSkgPT4ge1xyXG4gICAgc2V0TWFwcGluZ3Moe1xyXG4gICAgICAuLi5tYXBwaW5ncyxcclxuICAgICAgW2ZpZWxkXTogdmFsdWVcclxuICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUltcG9ydCA9ICgpID0+IHtcclxuICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgIFxyXG4gICAgLy8gU2ltdWxhdGUgaW1wb3J0IHByb2Nlc3NcclxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAvLyBJbiBhIHJlYWwgYXBwLCB0aGlzIHdvdWxkIHByb2Nlc3MgdGhlIGZpbGUgd2l0aCB0aGUgbWFwcGluZ3NcclxuICAgICAgY29uc3QgaW1wb3J0ZWRDb250YWN0cyA9IHByZXZpZXc/Lm1hcCgoaXRlbSwgaW5kZXgpID0+ICh7XHJcbiAgICAgICAgaWQ6IERhdGUubm93KCkgKyBpbmRleCxcclxuICAgICAgICBmaXJzdE5hbWU6IGl0ZW0/LlttYXBwaW5ncz8uZmlyc3ROYW1lXSB8fCAnJyxcclxuICAgICAgICBsYXN0TmFtZTogaXRlbT8uW21hcHBpbmdzPy5sYXN0TmFtZV0gfHwgJycsXHJcbiAgICAgICAgZW1haWw6IGl0ZW0/LlttYXBwaW5ncz8uZW1haWxdIHx8ICcnLFxyXG4gICAgICAgIHBob25lOiBpdGVtPy5bbWFwcGluZ3M/LnBob25lXSB8fCAnJyxcclxuICAgICAgICBjb21wYW55OiBpdGVtPy5bbWFwcGluZ3M/LmNvbXBhbnldIHx8ICcnLFxyXG4gICAgICAgIHBvc2l0aW9uOiBpdGVtPy5bbWFwcGluZ3M/LnBvc2l0aW9uXSB8fCAnJyxcclxuICAgICAgICBhdmF0YXI6IGBodHRwczovL3JhbmRvbXVzZXIubWUvYXBpL3BvcnRyYWl0cy8ke2luZGV4ICUgMiA9PT0gMCA/ICdtZW4nIDogJ3dvbWVuJ30vJHtNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAxMDApfS5qcGdgLFxyXG4gICAgICAgIGxhc3RDb250YWN0RGF0ZTogbmV3IERhdGUoKT8udG9JU09TdHJpbmcoKSxcclxuICAgICAgICBzdGF0dXM6ICdhY3RpdmUnLFxyXG4gICAgICAgIHRhZ3M6IFtdLFxyXG4gICAgICAgIGRlYWxzOiBbXSxcclxuICAgICAgICBub3RlczogJycsXHJcbiAgICAgICAgc29jaWFsUHJvZmlsZXM6IHt9LFxyXG4gICAgICAgIGFjdGl2aXRpZXM6IFtdLFxyXG4gICAgICAgIGN1c3RvbUZpZWxkczoge1xyXG4gICAgICAgICAgcHJlZmVycmVkQ29udGFjdE1ldGhvZDogJycsXHJcbiAgICAgICAgICBkZWNpc2lvblRpbWVmcmFtZTogJycsXHJcbiAgICAgICAgICBidWRnZXRSYW5nZTogJydcclxuICAgICAgICB9XHJcbiAgICAgIH0pKTtcclxuICAgICAgXHJcbiAgICAgIG9uSW1wb3J0KGltcG9ydGVkQ29udGFjdHMpO1xyXG4gICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgfSwgMTAwMCk7XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTExMDAgb3ZlcmZsb3cteS1hdXRvXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbWluLWgtc2NyZWVuIHB4LTQgcHQtNCBwYi0yMCB0ZXh0LWNlbnRlciBzbTpibG9jayBzbTpwLTBcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgdHJhbnNpdGlvbi1vcGFjaXR5XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgYmctYmxhY2sgYmctb3BhY2l0eS01MFwiPjwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIFxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpZGRlbiBzbTppbmxpbmUtYmxvY2sgc206YWxpZ24tbWlkZGxlIHNtOmgtc2NyZWVuXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+JiM4MjAzOzwvc3Bhbj5cclxuICAgICAgICBcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlubGluZS1ibG9jayBhbGlnbi1ib3R0b20gYmctc3VyZmFjZSByb3VuZGVkLWxnIHRleHQtbGVmdCBvdmVyZmxvdy1oaWRkZW4gc2hhZG93LXhsIHRyYW5zZm9ybSB0cmFuc2l0aW9uLWFsbCBzbTpteS04IHNtOmFsaWduLW1pZGRsZSBzbTptYXgtdy1sZyBzbTp3LWZ1bGwgbWQ6bWF4LXctMnhsXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcHktNCBib3JkZXItYiBib3JkZXItYm9yZGVyIGZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtdGV4dC1wcmltYXJ5XCI+SW1wb3J0IENvbnRhY3RzPC9oMz5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC10ZXh0LXNlY29uZGFyeSBob3Zlcjp0ZXh0LXRleHQtcHJpbWFyeVwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiWFwiIHNpemU9ezIwfSAvPlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcHktNVwiPlxyXG4gICAgICAgICAgICB7LyogU3RlcCAxOiBGaWxlIFVwbG9hZCAqL31cclxuICAgICAgICAgICAge3N0ZXAgPT09IDEgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTYgaC0xNiBiZy1wcmltYXJ5LTUwIHJvdW5kZWQtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBteC1hdXRvIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiVXBsb2FkXCIgc2l6ZT17MjR9IGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSBtYi0yXCI+VXBsb2FkIENvbnRhY3QgRmlsZTwvaDQ+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtdGV4dC1zZWNvbmRhcnkgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFVwbG9hZCBhIENTViBvciBFeGNlbCBmaWxlIHdpdGggeW91ciBjb250YWN0cyBkYXRhLlxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItMiBib3JkZXItZGFzaGVkIGJvcmRlci1ib3JkZXIgcm91bmRlZC1sZyBwLTggbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJjb250YWN0RmlsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgYWNjZXB0PVwiLmNzdiwueGxzeCwueGxzXCJcclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlRmlsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoaWRkZW5cIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY29udGFjdEZpbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImN1cnNvci1wb2ludGVyIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJGaWxlVGV4dFwiIHNpemU9ezM2fSBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtdGVydGlhcnkgbWItM1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC10ZXh0LXByaW1hcnkgZm9udC1tZWRpdW0gbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgRHJhZyBhbmQgZHJvcCB5b3VyIGZpbGUgaGVyZSBvciBjbGljayB0byBicm93c2VcclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXRleHQtdGVydGlhcnlcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIFN1cHBvcnRzIENTViwgRXhjZWwgKC54bHN4LCAueGxzKVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC10ZXh0LXNlY29uZGFyeVwiPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtYi0yXCI+WW91ciBmaWxlIHNob3VsZCBpbmNsdWRlIHRoZSBmb2xsb3dpbmcgY29sdW1uczo8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJsaXN0LWRpc2MgbGlzdC1pbnNpZGUgc3BhY2UteS0xIHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsaT5GaXJzdCBOYW1lPC9saT5cclxuICAgICAgICAgICAgICAgICAgICA8bGk+TGFzdCBOYW1lPC9saT5cclxuICAgICAgICAgICAgICAgICAgICA8bGk+RW1haWwgQWRkcmVzczwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxpPlBob25lIE51bWJlciAob3B0aW9uYWwpPC9saT5cclxuICAgICAgICAgICAgICAgICAgICA8bGk+Q29tcGFueSBOYW1lPC9saT5cclxuICAgICAgICAgICAgICAgICAgICA8bGk+UG9zaXRpb24vVGl0bGUgKG9wdGlvbmFsKTwvbGk+XHJcbiAgICAgICAgICAgICAgICAgIDwvdWw+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIHsvKiBTdGVwIDI6IE1hcCBGaWVsZHMgKi99XHJcbiAgICAgICAgICAgIHtzdGVwID09PSAyICYmIChcclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IG1iLTJcIj5NYXAgRmllbGRzPC9oND5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC10ZXh0LXNlY29uZGFyeVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIE1hdGNoIHlvdXIgZmlsZSBjb2x1bW5zIHRvIHRoZSBhcHByb3ByaWF0ZSBjb250YWN0IGZpZWxkcy5cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1zZWNvbmRhcnkgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBGaXJzdCBOYW1lKlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e21hcHBpbmdzPy5maXJzdE5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlTWFwcGluZ0NoYW5nZSgnZmlyc3ROYW1lJywgZT8udGFyZ2V0Py52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlucHV0LWZpZWxkXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBjb2x1bW48L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImZpcnN0TmFtZVwiPmZpcnN0TmFtZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiZmlyc3RfbmFtZVwiPmZpcnN0X25hbWU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkZpcnN0TmFtZVwiPkZpcnN0TmFtZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1zZWNvbmRhcnkgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBMYXN0IE5hbWUqXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17bWFwcGluZ3M/Lmxhc3ROYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZU1hcHBpbmdDaGFuZ2UoJ2xhc3ROYW1lJywgZT8udGFyZ2V0Py52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlucHV0LWZpZWxkXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBjb2x1bW48L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImxhc3ROYW1lXCI+bGFzdE5hbWU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImxhc3RfbmFtZVwiPmxhc3RfbmFtZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiTGFzdE5hbWVcIj5MYXN0TmFtZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1zZWNvbmRhcnkgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBFbWFpbCpcclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXttYXBwaW5ncz8uZW1haWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlTWFwcGluZ0NoYW5nZSgnZW1haWwnLCBlPy50YXJnZXQ/LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5wdXQtZmllbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IGNvbHVtbjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiZW1haWxcIj5lbWFpbDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiZW1haWxfYWRkcmVzc1wiPmVtYWlsX2FkZHJlc3M8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkVtYWlsXCI+RW1haWw8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtc2Vjb25kYXJ5IG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgUGhvbmVcclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXttYXBwaW5ncz8ucGhvbmV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlTWFwcGluZ0NoYW5nZSgncGhvbmUnLCBlPy50YXJnZXQ/LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5wdXQtZmllbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IGNvbHVtbjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwicGhvbmVcIj5waG9uZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwicGhvbmVfbnVtYmVyXCI+cGhvbmVfbnVtYmVyPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJQaG9uZVwiPlBob25lPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXNlY29uZGFyeSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIENvbXBhbnkqXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17bWFwcGluZ3M/LmNvbXBhbnl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlTWFwcGluZ0NoYW5nZSgnY29tcGFueScsIGU/LnRhcmdldD8udmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbnB1dC1maWVsZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY3QgY29sdW1uPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJjb21wYW55XCI+Y29tcGFueTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiY29tcGFueV9uYW1lXCI+Y29tcGFueV9uYW1lPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJDb21wYW55XCI+Q29tcGFueTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1zZWNvbmRhcnkgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBQb3NpdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e21hcHBpbmdzPy5wb3NpdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVNYXBwaW5nQ2hhbmdlKCdwb3NpdGlvbicsIGU/LnRhcmdldD8udmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbnB1dC1maWVsZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY3QgY29sdW1uPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJwb3NpdGlvblwiPnBvc2l0aW9uPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJ0aXRsZVwiPnRpdGxlPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJqb2JfdGl0bGVcIj5qb2JfdGl0bGU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlBvc2l0aW9uXCI+UG9zaXRpb248L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbGcgb3ZlcmZsb3ctaGlkZGVuIG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC00IHB5LTMgYmctc3VyZmFjZS1ob3ZlciB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgUHJldmlldyAoe3ByZXZpZXc/Lmxlbmd0aH0gcmVjb3JkcylcclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWJvcmRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRoZWFkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTQgcHktMyBiZy1zdXJmYWNlLWhvdmVyIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1zZWNvbmRhcnkgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBGaXJzdCBOYW1lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0zIGJnLXN1cmZhY2UtaG92ZXIgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC10ZXh0LXNlY29uZGFyeSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIExhc3QgTmFtZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTQgcHktMyBiZy1zdXJmYWNlLWhvdmVyIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1zZWNvbmRhcnkgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBFbWFpbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTQgcHktMyBiZy1zdXJmYWNlLWhvdmVyIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1zZWNvbmRhcnkgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBDb21wYW55XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiYmctc3VyZmFjZSBkaXZpZGUteSBkaXZpZGUtYm9yZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtwcmV2aWV3Py5zbGljZSgwLCAzKT8ubWFwKChpdGVtLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2luZGV4fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTMgd2hpdGVzcGFjZS1ub3dyYXAgdGV4dC1zbSB0ZXh0LXRleHQtcHJpbWFyeVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbT8uW21hcHBpbmdzPy5maXJzdE5hbWVdIHx8ICctJ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0zIHdoaXRlc3BhY2Utbm93cmFwIHRleHQtc20gdGV4dC10ZXh0LXByaW1hcnlcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0/LlttYXBwaW5ncz8ubGFzdE5hbWVdIHx8ICctJ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0zIHdoaXRlc3BhY2Utbm93cmFwIHRleHQtc20gdGV4dC10ZXh0LXByaW1hcnlcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0/LlttYXBwaW5ncz8uZW1haWxdIHx8ICctJ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0zIHdoaXRlc3BhY2Utbm93cmFwIHRleHQtc20gdGV4dC10ZXh0LXByaW1hcnlcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0/LlttYXBwaW5ncz8uY29tcGFueV0gfHwgJy0nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcHktNCBib3JkZXItdCBib3JkZXItYm9yZGVyIGZsZXgganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgIHtzdGVwID09PSAxID8gKFxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYm9yZGVyIGJvcmRlci1ib3JkZXIgcm91bmRlZC1sZyB0ZXh0LXRleHQtc2Vjb25kYXJ5IGhvdmVyOnRleHQtdGV4dC1wcmltYXJ5IGhvdmVyOmJnLXN1cmZhY2UtaG92ZXIgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMTUwIGVhc2Utb3V0XCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBDYW5jZWxcclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTdGVwKDEpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLWxnIHRleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC10ZXh0LXByaW1hcnkgaG92ZXI6Ymctc3VyZmFjZS1ob3ZlciB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0xNTAgZWFzZS1vdXRcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJBcnJvd0xlZnRcIiBzaXplPXsxNn0gY2xhc3NOYW1lPVwibXItMlwiIC8+XHJcbiAgICAgICAgICAgICAgICBCYWNrXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB7c3RlcCA9PT0gMSA/IChcclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17IWZpbGV9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BidG4tcHJpbWFyeSAkeyFmaWxlID8gJ29wYWNpdHktNTAgY3Vyc29yLW5vdC1hbGxvd2VkJyA6ICcnfWB9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgTmV4dFxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUltcG9ydH1cclxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc0xvYWRpbmcgfHwgIW1hcHBpbmdzPy5maXJzdE5hbWUgfHwgIW1hcHBpbmdzPy5sYXN0TmFtZSB8fCAhbWFwcGluZ3M/LmVtYWlsIHx8ICFtYXBwaW5ncz8uY29tcGFueX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJ0bi1wcmltYXJ5IGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciAke1xyXG4gICAgICAgICAgICAgICAgICBpc0xvYWRpbmcgfHwgIW1hcHBpbmdzPy5maXJzdE5hbWUgfHwgIW1hcHBpbmdzPy5sYXN0TmFtZSB8fCAhbWFwcGluZ3M/LmVtYWlsIHx8ICFtYXBwaW5ncz8uY29tcGFueVxyXG4gICAgICAgICAgICAgICAgICAgID8gJ29wYWNpdHktNTAgY3Vyc29yLW5vdC1hbGxvd2VkJyA6JydcclxuICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtpc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIkxvYWRlclwiIHNpemU9ezE2fSBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW4gbXItMlwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgSW1wb3J0aW5nLi4uXHJcbiAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICBJbXBvcnQgQ29udGFjdHNcclxuICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEltcG9ydENvbnRhY3RzTW9kYWw7Il0sImZpbGUiOiJEOi9jdXJyZW50IHByb2plY3RzL2NsYXVkZS1jb2RlL3NyYy9wYWdlcy9jb250YWN0LW1hbmFnZW1lbnQvY29tcG9uZW50cy9JbXBvcnRDb250YWN0c01vZGFsLmpzeCJ9