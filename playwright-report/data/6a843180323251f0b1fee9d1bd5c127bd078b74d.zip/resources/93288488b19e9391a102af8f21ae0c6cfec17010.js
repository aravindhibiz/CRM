import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/settings-administration/components/Permissions.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import Icon from "/src/components/AppIcon.jsx";
const Permissions = () => {
  _s();
  const [selectedRole, setSelectedRole] = useState("Sales Manager");
  const roles = [
    { name: "Admin", userCount: 2 },
    { name: "Sales Manager", userCount: 5 },
    { name: "Sales Rep", userCount: 12 },
    { name: "Sales Operations", userCount: 3 }
  ];
  const permissions = [
    {
      category: "Dashboard & Analytics",
      items: [
        { name: "View Dashboard", key: "view_dashboard" },
        { name: "View Analytics", key: "view_analytics" },
        { name: "Export Reports", key: "export_reports" }
      ]
    },
    {
      category: "Contact Management",
      items: [
        { name: "View Contacts", key: "view_contacts" },
        { name: "Create Contacts", key: "create_contacts" },
        { name: "Edit Contacts", key: "edit_contacts" },
        { name: "Delete Contacts", key: "delete_contacts" },
        { name: "Import/Export Contacts", key: "import_export_contacts" }
      ]
    },
    {
      category: "Deal Management",
      items: [
        { name: "View Deals", key: "view_deals" },
        { name: "Create Deals", key: "create_deals" },
        { name: "Edit Deals", key: "edit_deals" },
        { name: "Delete Deals", key: "delete_deals" },
        { name: "Move Pipeline Stages", key: "move_pipeline_stages" }
      ]
    },
    {
      category: "User Management",
      items: [
        { name: "View Users", key: "view_users" },
        { name: "Invite Users", key: "invite_users" },
        { name: "Edit User Roles", key: "edit_user_roles" },
        { name: "Deactivate Users", key: "deactivate_users" }
      ]
    },
    {
      category: "System Configuration",
      items: [
        { name: "Manage Integrations", key: "manage_integrations" },
        { name: "Configure Custom Fields", key: "configure_custom_fields" },
        { name: "Manage Email Templates", key: "manage_email_templates" },
        { name: "Access System Settings", key: "access_system_settings" }
      ]
    }
  ];
  const [rolePermissions, setRolePermissions] = useState({
    "Admin": {
      view_dashboard: true,
      view_analytics: true,
      export_reports: true,
      view_contacts: true,
      create_contacts: true,
      edit_contacts: true,
      delete_contacts: true,
      import_export_contacts: true,
      view_deals: true,
      create_deals: true,
      edit_deals: true,
      delete_deals: true,
      move_pipeline_stages: true,
      view_users: true,
      invite_users: true,
      edit_user_roles: true,
      deactivate_users: true,
      manage_integrations: true,
      configure_custom_fields: true,
      manage_email_templates: true,
      access_system_settings: true
    },
    "Sales Manager": {
      view_dashboard: true,
      view_analytics: true,
      export_reports: true,
      view_contacts: true,
      create_contacts: true,
      edit_contacts: true,
      delete_contacts: false,
      import_export_contacts: true,
      view_deals: true,
      create_deals: true,
      edit_deals: true,
      delete_deals: false,
      move_pipeline_stages: true,
      view_users: true,
      invite_users: false,
      edit_user_roles: false,
      deactivate_users: false,
      manage_integrations: false,
      configure_custom_fields: false,
      manage_email_templates: true,
      access_system_settings: false
    },
    "Sales Rep": {
      view_dashboard: true,
      view_analytics: false,
      export_reports: false,
      view_contacts: true,
      create_contacts: true,
      edit_contacts: true,
      delete_contacts: false,
      import_export_contacts: false,
      view_deals: true,
      create_deals: true,
      edit_deals: true,
      delete_deals: false,
      move_pipeline_stages: true,
      view_users: false,
      invite_users: false,
      edit_user_roles: false,
      deactivate_users: false,
      manage_integrations: false,
      configure_custom_fields: false,
      manage_email_templates: false,
      access_system_settings: false
    },
    "Sales Operations": {
      view_dashboard: true,
      view_analytics: true,
      export_reports: true,
      view_contacts: true,
      create_contacts: true,
      edit_contacts: true,
      delete_contacts: true,
      import_export_contacts: true,
      view_deals: true,
      create_deals: false,
      edit_deals: false,
      delete_deals: false,
      move_pipeline_stages: false,
      view_users: true,
      invite_users: false,
      edit_user_roles: false,
      deactivate_users: false,
      manage_integrations: true,
      configure_custom_fields: true,
      manage_email_templates: true,
      access_system_settings: true
    }
  });
  const handlePermissionChange = (permissionKey) => {
    setRolePermissions((prev) => ({
      ...prev,
      [selectedRole]: {
        ...prev?.[selectedRole],
        [permissionKey]: !prev?.[selectedRole]?.[permissionKey]
      }
    }));
  };
  const handleSaveChanges = () => {
    console.log("Saving permission changes for:", selectedRole, rolePermissions?.[selectedRole]);
  };
  const getPermissionCount = (role) => {
    const permissions2 = rolePermissions?.[role] || {};
    return Object.values(permissions2)?.filter(Boolean)?.length;
  };
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:180:4", "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx", "data-component-line": "180", "data-component-file": "Permissions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-6%22%7D", className: "space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:182:6", "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx", "data-component-line": "182", "data-component-file": "Permissions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:183:8", "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx", "data-component-line": "183", "data-component-file": "Permissions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
        /* @__PURE__ */ jsxDEV("h2", { "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:184:10", "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx", "data-component-line": "184", "data-component-file": "Permissions.jsx", "data-component-name": "h2", "data-component-content": "%7B%22elementName%22%3A%22h2%22%2C%22className%22%3A%22text-2xl%20font-bold%20text-text-primary%22%2C%22textContent%22%3A%22Permissions%22%7D", className: "text-2xl font-bold text-text-primary", children: "Permissions" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
          lineNumber: 184,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:185:10", "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx", "data-component-line": "185", "data-component-file": "Permissions.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20mt-1%22%2C%22textContent%22%3A%22Configure%20role-based%20access%20control%22%7D", className: "text-text-secondary mt-1", children: "Configure role-based access control" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
          lineNumber: 185,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
        lineNumber: 183,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:187:8",
          "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx",
          "data-component-line": "187",
          "data-component-file": "Permissions.jsx",
          "data-component-name": "button",
          "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22bg-primary%20text-white%20px-4%20py-2%20rounded-lg%20hover%3Abg-primary-600%20transition-colors%20duration-150%20ease-smooth%20flex%20items-center%20space-x-2%22%7D",
          onClick: handleSaveChanges,
          className: "bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary-600 transition-colors duration-150 ease-smooth flex items-center space-x-2",
          children: [
            /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:191:10", "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx", "data-component-line": "191", "data-component-file": "Permissions.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Save%22%7D", name: "Save", size: 16 }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
              lineNumber: 191,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:192:10", "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx", "data-component-line": "192", "data-component-file": "Permissions.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Save%20Changes%22%7D", children: "Save Changes" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
              lineNumber: 192,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
          lineNumber: 187,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
      lineNumber: 182,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:195:6", "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx", "data-component-line": "195", "data-component-file": "Permissions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20lg%3Agrid-cols-12%20gap-6%22%7D", className: "grid grid-cols-1 lg:grid-cols-12 gap-6", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:197:8", "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx", "data-component-line": "197", "data-component-file": "Permissions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22lg%3Acol-span-4%22%7D", className: "lg:col-span-4", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:198:10", "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx", "data-component-line": "198", "data-component-file": "Permissions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20rounded-lg%20border%20border-border%20p-6%22%7D", className: "bg-surface rounded-lg border border-border p-6", children: [
        /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:199:12", "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx", "data-component-line": "199", "data-component-file": "Permissions.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%20mb-4%22%2C%22textContent%22%3A%22Roles%22%7D", className: "text-lg font-semibold text-text-primary mb-4", children: "Roles" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
          lineNumber: 199,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:200:12", "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx", "data-component-line": "200", "data-component-file": "Permissions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-2%22%7D", className: "space-y-2", children: roles?.map(
          (role) => /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:202:14",
              "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx",
              "data-component-line": "202",
              "data-component-file": "Permissions.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%7D",
              onClick: () => setSelectedRole(role?.name),
              className: `w-full text-left p-3 rounded-lg transition-all duration-150 ease-smooth ${selectedRole === role?.name ? "bg-primary-50 border border-primary-100 text-primary" : "text-text-secondary hover:text-text-primary hover:bg-surface-hover border border-transparent"}`,
              children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:210:18", "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx", "data-component-line": "210", "data-component-file": "Permissions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:211:20", "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx", "data-component-line": "211", "data-component-file": "Permissions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
                  /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:212:22", "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx", "data-component-line": "212", "data-component-file": "Permissions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", className: `font-medium text-sm ${selectedRole === role?.name ? "text-primary" : "text-text-primary"}`, children: role?.name }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
                    lineNumber: 212,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:217:22", "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx", "data-component-line": "217", "data-component-file": "Permissions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-xs%20text-text-tertiary%20mt-1%22%2C%22textContent%22%3A%22user%20%E2%80%A2%20permissions%22%7D", className: "text-xs text-text-tertiary mt-1", children: [
                    role?.userCount,
                    " user",
                    role?.userCount !== 1 ? "s" : "",
                    " • ",
                    getPermissionCount(role?.name),
                    " permissions"
                  ] }, void 0, true, {
                    fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
                    lineNumber: 217,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
                  lineNumber: 211,
                  columnNumber: 21
                }, this),
                selectedRole === role?.name && /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:222:18", "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx", "data-component-line": "222", "data-component-file": "Permissions.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Check%22%2C%22className%22%3A%22text-primary%22%7D", name: "Check", size: 16, className: "text-primary" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
                  lineNumber: 222,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
                lineNumber: 210,
                columnNumber: 19
              }, this)
            },
            role?.name,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
              lineNumber: 202,
              columnNumber: 15
            },
            this
          )
        ) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
          lineNumber: 200,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
        lineNumber: 198,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
        lineNumber: 197,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:232:8", "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx", "data-component-line": "232", "data-component-file": "Permissions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22lg%3Acol-span-8%22%7D", className: "lg:col-span-8", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:233:10", "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx", "data-component-line": "233", "data-component-file": "Permissions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20rounded-lg%20border%20border-border%22%7D", className: "bg-surface rounded-lg border border-border", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:234:12", "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx", "data-component-line": "234", "data-component-file": "Permissions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22p-6%20border-b%20border-border%22%7D", className: "p-6 border-b border-border", children: [
          /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:235:14", "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx", "data-component-line": "235", "data-component-file": "Permissions.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%2C%22textContent%22%3A%22Permissions%20for%22%7D", className: "text-lg font-semibold text-text-primary", children: [
            "Permissions for ",
            selectedRole
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
            lineNumber: 235,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:236:14", "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx", "data-component-line": "236", "data-component-file": "Permissions.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20text-sm%20mt-1%22%2C%22textContent%22%3A%22Configure%20what%20actions%20this%20role%20can%20perform%22%7D", className: "text-text-secondary text-sm mt-1", children: "Configure what actions this role can perform" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
            lineNumber: 236,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
          lineNumber: 234,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:241:12", "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx", "data-component-line": "241", "data-component-file": "Permissions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22p-6%20space-y-6%22%7D", className: "p-6 space-y-6", children: permissions?.map(
          (category) => /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:243:14", "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx", "data-component-line": "243", "data-component-file": "Permissions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
            /* @__PURE__ */ jsxDEV("h4", { "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:244:18", "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx", "data-component-line": "244", "data-component-file": "Permissions.jsx", "data-component-name": "h4", "data-component-content": "%7B%22elementName%22%3A%22h4%22%2C%22className%22%3A%22font-medium%20text-text-primary%20mb-3%20text-sm%20uppercase%20tracking-wide%22%7D", className: "font-medium text-text-primary mb-3 text-sm uppercase tracking-wide", children: category?.category }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
              lineNumber: 244,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:247:18", "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx", "data-component-line": "247", "data-component-file": "Permissions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-2%20ml-4%22%7D", className: "space-y-2 ml-4", children: category?.items?.map(
              (permission) => /* @__PURE__ */ jsxDEV(
                "label",
                {
                  "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:249:18",
                  "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx",
                  "data-component-line": "249",
                  "data-component-file": "Permissions.jsx",
                  "data-component-name": "label",
                  "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22flex%20items-center%20space-x-3%20p-2%20rounded%20hover%3Abg-surface-hover%20cursor-pointer%20group%22%7D",
                  className: "flex items-center space-x-3 p-2 rounded hover:bg-surface-hover cursor-pointer group",
                  children: [
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:253:24",
                        "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx",
                        "data-component-line": "253",
                        "data-component-file": "Permissions.jsx",
                        "data-component-name": "input",
                        "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22checkbox%22%2C%22className%22%3A%22rounded%20border-border%20text-primary%20focus%3Aring-primary%22%7D",
                        type: "checkbox",
                        checked: rolePermissions?.[selectedRole]?.[permission?.key] || false,
                        onChange: () => handlePermissionChange(permission?.key),
                        className: "rounded border-border text-primary focus:ring-primary"
                      },
                      void 0,
                      false,
                      {
                        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
                        lineNumber: 253,
                        columnNumber: 25
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:259:24", "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx", "data-component-line": "259", "data-component-file": "Permissions.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-secondary%20group-hover%3Atext-text-primary%20transition-colors%20duration-150%22%7D", className: "text-sm text-text-secondary group-hover:text-text-primary transition-colors duration-150", children: permission?.name }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
                      lineNumber: 259,
                      columnNumber: 25
                    }, this)
                  ]
                },
                permission?.key,
                true,
                {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
                  lineNumber: 249,
                  columnNumber: 19
                },
                this
              )
            ) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
              lineNumber: 247,
              columnNumber: 19
            }, this)
          ] }, category?.category, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
            lineNumber: 243,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
          lineNumber: 241,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
        lineNumber: 233,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
        lineNumber: 232,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
      lineNumber: 195,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:272:6", "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx", "data-component-line": "272", "data-component-file": "Permissions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-background%20border%20border-border%20rounded-lg%20p-4%22%7D", className: "bg-background border border-border rounded-lg p-4", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:273:8", "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx", "data-component-line": "273", "data-component-file": "Permissions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-start%20space-x-3%22%7D", className: "flex items-start space-x-3", children: [
      /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:274:10", "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx", "data-component-line": "274", "data-component-file": "Permissions.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Info%22%2C%22className%22%3A%22text-primary%20mt-0.5%22%7D", name: "Info", size: 16, className: "text-primary mt-0.5" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
        lineNumber: 274,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:275:10", "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx", "data-component-line": "275", "data-component-file": "Permissions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex-1%22%7D", className: "flex-1", children: [
        /* @__PURE__ */ jsxDEV("h4", { "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:276:12", "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx", "data-component-line": "276", "data-component-file": "Permissions.jsx", "data-component-name": "h4", "data-component-content": "%7B%22elementName%22%3A%22h4%22%2C%22className%22%3A%22font-medium%20text-text-primary%20text-sm%22%2C%22textContent%22%3A%22Permission%20Guidelines%22%7D", className: "font-medium text-text-primary text-sm", children: "Permission Guidelines" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
          lineNumber: 276,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\settings-administration\\components\\Permissions.jsx:277:12", "data-component-path": "src\\pages\\settings-administration\\components\\Permissions.jsx", "data-component-line": "277", "data-component-file": "Permissions.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20text-sm%20mt-1%22%2C%22textContent%22%3A%22Changes%20to%20permissions%20will%20take%20effect%20immediately%20for%20all%20users%20with%20the%20selected%20role.%20%5Cn%20%20%20%20%20%20%20%20%20%20%20%20%20%20Users%20may%20need%20to%20refresh%20their%20browser%20to%20see%20updated%20access.%22%7D", className: "text-text-secondary text-sm mt-1", children: "Changes to permissions will take effect immediately for all users with the selected role. Users may need to refresh their browser to see updated access." }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
          lineNumber: 277,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
        lineNumber: 275,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
      lineNumber: 273,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
      lineNumber: 272,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx",
    lineNumber: 180,
    columnNumber: 5
  }, this);
};
_s(Permissions, "1nKLbUsk6a2gdKBmiYtAEbR0sgs=");
_c = Permissions;
export default Permissions;
var _c;
$RefreshReg$(_c, "Permissions");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/settings-administration/components/Permissions.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUxVOzJCQXZMVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBLE9BQU9BLFNBQVNDLGdCQUFnQjtBQUNoQyxPQUFPQyxVQUFVO0FBRWpCLE1BQU1DLGNBQWNBLE1BQU07QUFBQUMsS0FBQTtBQUN4QixRQUFNLENBQUNDLGNBQWNDLGVBQWUsSUFBSUwsU0FBUyxlQUFlO0FBRWhFLFFBQU1NLFFBQVE7QUFBQSxJQUNaLEVBQUVDLE1BQU0sU0FBU0MsV0FBVyxFQUFFO0FBQUEsSUFDOUIsRUFBRUQsTUFBTSxpQkFBaUJDLFdBQVcsRUFBRTtBQUFBLElBQ3RDLEVBQUVELE1BQU0sYUFBYUMsV0FBVyxHQUFHO0FBQUEsSUFDbkMsRUFBRUQsTUFBTSxvQkFBb0JDLFdBQVcsRUFBRTtBQUFBLEVBQUM7QUFHNUMsUUFBTUMsY0FBYztBQUFBLElBQ2xCO0FBQUEsTUFDRUMsVUFBVTtBQUFBLE1BQ1ZDLE9BQU87QUFBQSxRQUNMLEVBQUVKLE1BQU0sa0JBQWtCSyxLQUFLLGlCQUFpQjtBQUFBLFFBQ2hELEVBQUVMLE1BQU0sa0JBQWtCSyxLQUFLLGlCQUFpQjtBQUFBLFFBQ2hELEVBQUVMLE1BQU0sa0JBQWtCSyxLQUFLLGlCQUFpQjtBQUFBLE1BQUM7QUFBQSxJQUVyRDtBQUFBLElBQ0E7QUFBQSxNQUNFRixVQUFVO0FBQUEsTUFDVkMsT0FBTztBQUFBLFFBQ0wsRUFBRUosTUFBTSxpQkFBaUJLLEtBQUssZ0JBQWdCO0FBQUEsUUFDOUMsRUFBRUwsTUFBTSxtQkFBbUJLLEtBQUssa0JBQWtCO0FBQUEsUUFDbEQsRUFBRUwsTUFBTSxpQkFBaUJLLEtBQUssZ0JBQWdCO0FBQUEsUUFDOUMsRUFBRUwsTUFBTSxtQkFBbUJLLEtBQUssa0JBQWtCO0FBQUEsUUFDbEQsRUFBRUwsTUFBTSwwQkFBMEJLLEtBQUsseUJBQXlCO0FBQUEsTUFBQztBQUFBLElBRXJFO0FBQUEsSUFDQTtBQUFBLE1BQ0VGLFVBQVU7QUFBQSxNQUNWQyxPQUFPO0FBQUEsUUFDTCxFQUFFSixNQUFNLGNBQWNLLEtBQUssYUFBYTtBQUFBLFFBQ3hDLEVBQUVMLE1BQU0sZ0JBQWdCSyxLQUFLLGVBQWU7QUFBQSxRQUM1QyxFQUFFTCxNQUFNLGNBQWNLLEtBQUssYUFBYTtBQUFBLFFBQ3hDLEVBQUVMLE1BQU0sZ0JBQWdCSyxLQUFLLGVBQWU7QUFBQSxRQUM1QyxFQUFFTCxNQUFNLHdCQUF3QkssS0FBSyx1QkFBdUI7QUFBQSxNQUFDO0FBQUEsSUFFakU7QUFBQSxJQUNBO0FBQUEsTUFDRUYsVUFBVTtBQUFBLE1BQ1ZDLE9BQU87QUFBQSxRQUNMLEVBQUVKLE1BQU0sY0FBY0ssS0FBSyxhQUFhO0FBQUEsUUFDeEMsRUFBRUwsTUFBTSxnQkFBZ0JLLEtBQUssZUFBZTtBQUFBLFFBQzVDLEVBQUVMLE1BQU0sbUJBQW1CSyxLQUFLLGtCQUFrQjtBQUFBLFFBQ2xELEVBQUVMLE1BQU0sb0JBQW9CSyxLQUFLLG1CQUFtQjtBQUFBLE1BQUM7QUFBQSxJQUV6RDtBQUFBLElBQ0E7QUFBQSxNQUNFRixVQUFVO0FBQUEsTUFDVkMsT0FBTztBQUFBLFFBQ0wsRUFBRUosTUFBTSx1QkFBdUJLLEtBQUssc0JBQXNCO0FBQUEsUUFDMUQsRUFBRUwsTUFBTSwyQkFBMkJLLEtBQUssMEJBQTBCO0FBQUEsUUFDbEUsRUFBRUwsTUFBTSwwQkFBMEJLLEtBQUsseUJBQXlCO0FBQUEsUUFDaEUsRUFBRUwsTUFBTSwwQkFBMEJLLEtBQUsseUJBQXlCO0FBQUEsTUFBQztBQUFBLElBRXJFO0FBQUEsRUFBQztBQUdILFFBQU0sQ0FBQ0MsaUJBQWlCQyxrQkFBa0IsSUFBSWQsU0FBUztBQUFBLElBQ3JELFNBQVM7QUFBQSxNQUNQZSxnQkFBZ0I7QUFBQSxNQUNoQkMsZ0JBQWdCO0FBQUEsTUFDaEJDLGdCQUFnQjtBQUFBLE1BQ2hCQyxlQUFlO0FBQUEsTUFDZkMsaUJBQWlCO0FBQUEsTUFDakJDLGVBQWU7QUFBQSxNQUNmQyxpQkFBaUI7QUFBQSxNQUNqQkMsd0JBQXdCO0FBQUEsTUFDeEJDLFlBQVk7QUFBQSxNQUNaQyxjQUFjO0FBQUEsTUFDZEMsWUFBWTtBQUFBLE1BQ1pDLGNBQWM7QUFBQSxNQUNkQyxzQkFBc0I7QUFBQSxNQUN0QkMsWUFBWTtBQUFBLE1BQ1pDLGNBQWM7QUFBQSxNQUNkQyxpQkFBaUI7QUFBQSxNQUNqQkMsa0JBQWtCO0FBQUEsTUFDbEJDLHFCQUFxQjtBQUFBLE1BQ3JCQyx5QkFBeUI7QUFBQSxNQUN6QkMsd0JBQXdCO0FBQUEsTUFDeEJDLHdCQUF3QjtBQUFBLElBQzFCO0FBQUEsSUFDQSxpQkFBaUI7QUFBQSxNQUNmcEIsZ0JBQWdCO0FBQUEsTUFDaEJDLGdCQUFnQjtBQUFBLE1BQ2hCQyxnQkFBZ0I7QUFBQSxNQUNoQkMsZUFBZTtBQUFBLE1BQ2ZDLGlCQUFpQjtBQUFBLE1BQ2pCQyxlQUFlO0FBQUEsTUFDZkMsaUJBQWlCO0FBQUEsTUFDakJDLHdCQUF3QjtBQUFBLE1BQ3hCQyxZQUFZO0FBQUEsTUFDWkMsY0FBYztBQUFBLE1BQ2RDLFlBQVk7QUFBQSxNQUNaQyxjQUFjO0FBQUEsTUFDZEMsc0JBQXNCO0FBQUEsTUFDdEJDLFlBQVk7QUFBQSxNQUNaQyxjQUFjO0FBQUEsTUFDZEMsaUJBQWlCO0FBQUEsTUFDakJDLGtCQUFrQjtBQUFBLE1BQ2xCQyxxQkFBcUI7QUFBQSxNQUNyQkMseUJBQXlCO0FBQUEsTUFDekJDLHdCQUF3QjtBQUFBLE1BQ3hCQyx3QkFBd0I7QUFBQSxJQUMxQjtBQUFBLElBQ0EsYUFBYTtBQUFBLE1BQ1hwQixnQkFBZ0I7QUFBQSxNQUNoQkMsZ0JBQWdCO0FBQUEsTUFDaEJDLGdCQUFnQjtBQUFBLE1BQ2hCQyxlQUFlO0FBQUEsTUFDZkMsaUJBQWlCO0FBQUEsTUFDakJDLGVBQWU7QUFBQSxNQUNmQyxpQkFBaUI7QUFBQSxNQUNqQkMsd0JBQXdCO0FBQUEsTUFDeEJDLFlBQVk7QUFBQSxNQUNaQyxjQUFjO0FBQUEsTUFDZEMsWUFBWTtBQUFBLE1BQ1pDLGNBQWM7QUFBQSxNQUNkQyxzQkFBc0I7QUFBQSxNQUN0QkMsWUFBWTtBQUFBLE1BQ1pDLGNBQWM7QUFBQSxNQUNkQyxpQkFBaUI7QUFBQSxNQUNqQkMsa0JBQWtCO0FBQUEsTUFDbEJDLHFCQUFxQjtBQUFBLE1BQ3JCQyx5QkFBeUI7QUFBQSxNQUN6QkMsd0JBQXdCO0FBQUEsTUFDeEJDLHdCQUF3QjtBQUFBLElBQzFCO0FBQUEsSUFDQSxvQkFBb0I7QUFBQSxNQUNsQnBCLGdCQUFnQjtBQUFBLE1BQ2hCQyxnQkFBZ0I7QUFBQSxNQUNoQkMsZ0JBQWdCO0FBQUEsTUFDaEJDLGVBQWU7QUFBQSxNQUNmQyxpQkFBaUI7QUFBQSxNQUNqQkMsZUFBZTtBQUFBLE1BQ2ZDLGlCQUFpQjtBQUFBLE1BQ2pCQyx3QkFBd0I7QUFBQSxNQUN4QkMsWUFBWTtBQUFBLE1BQ1pDLGNBQWM7QUFBQSxNQUNkQyxZQUFZO0FBQUEsTUFDWkMsY0FBYztBQUFBLE1BQ2RDLHNCQUFzQjtBQUFBLE1BQ3RCQyxZQUFZO0FBQUEsTUFDWkMsY0FBYztBQUFBLE1BQ2RDLGlCQUFpQjtBQUFBLE1BQ2pCQyxrQkFBa0I7QUFBQSxNQUNsQkMscUJBQXFCO0FBQUEsTUFDckJDLHlCQUF5QjtBQUFBLE1BQ3pCQyx3QkFBd0I7QUFBQSxNQUN4QkMsd0JBQXdCO0FBQUEsSUFDMUI7QUFBQSxFQUNGLENBQUM7QUFFRCxRQUFNQyx5QkFBeUJBLENBQUNDLGtCQUFrQjtBQUNoRHZCLHVCQUFtQixDQUFBd0IsVUFBUztBQUFBLE1BQzFCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ2xDLFlBQVksR0FBRztBQUFBLFFBQ2QsR0FBR2tDLE9BQU9sQyxZQUFZO0FBQUEsUUFDdEIsQ0FBQ2lDLGFBQWEsR0FBRyxDQUFDQyxPQUFPbEMsWUFBWSxJQUFJaUMsYUFBYTtBQUFBLE1BQ3hEO0FBQUEsSUFDRixFQUFFO0FBQUEsRUFDSjtBQUVBLFFBQU1FLG9CQUFvQkEsTUFBTTtBQUM5QkMsWUFBUUMsSUFBSSxrQ0FBa0NyQyxjQUFjUyxrQkFBa0JULFlBQVksQ0FBQztBQUFBLEVBRTdGO0FBRUEsUUFBTXNDLHFCQUFxQkEsQ0FBQ0MsU0FBUztBQUNuQyxVQUFNbEMsZUFBY0ksa0JBQWtCOEIsSUFBSSxLQUFLLENBQUM7QUFDaEQsV0FBT0MsT0FBT0MsT0FBT3BDLFlBQVcsR0FBR3FDLE9BQU9DLE9BQU8sR0FBR0M7QUFBQUEsRUFDdEQ7QUFFQSxTQUNFLHVCQUFDLDhZQUFJLFdBQVUsYUFFYjtBQUFBLDJCQUFDLDBhQUFJLFdBQVUscUNBQ2I7QUFBQSw2QkFBQywwV0FDQztBQUFBLCtCQUFDLG1kQUFHLFdBQVUsd0NBQXVDLDJCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdFO0FBQUEsUUFDaEUsdUJBQUMsZ2VBQUUsV0FBVSw0QkFBMkIsbURBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkU7QUFBQSxXQUY3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFDQyxTQUFTVDtBQUFBQSxVQUNULFdBQVU7QUFBQSxVQUVWO0FBQUEsbUNBQUMsc1lBQUssTUFBSyxRQUFPLE1BQU0sTUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkI7QUFBQSxZQUMzQix1QkFBQyx5WkFBSyw0QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrQjtBQUFBO0FBQUE7QUFBQSxRQUxwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNQTtBQUFBLFNBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVlBO0FBQUEsSUFDQSx1QkFBQyxtYkFBSSxXQUFVLDBDQUViO0FBQUEsNkJBQUMsb1pBQUksV0FBVSxpQkFDYixpQ0FBQyw0YkFBSSxXQUFVLGtEQUNiO0FBQUEsK0JBQUMsdWRBQUcsV0FBVSxnREFBK0MscUJBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0U7QUFBQSxRQUNsRSx1QkFBQywrWUFBSSxXQUFVLGFBQ1pqQyxpQkFBTzJDO0FBQUFBLFVBQUksQ0FBQ04sU0FDWDtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRUMsU0FBUyxNQUFNdEMsZ0JBQWdCc0MsTUFBTXBDLElBQUk7QUFBQSxjQUN6QyxXQUFXLDJFQUNUSCxpQkFBaUJ1QyxNQUFNcEMsT0FDbkIseURBQXdELDhGQUE4RjtBQUFBLGNBRzVKLGlDQUFDLDJhQUFJLFdBQVUscUNBQ2I7QUFBQSx1Q0FBQywyV0FDQztBQUFBLHlDQUFDLDJXQUFJLFdBQVcsdUJBQ2RILGlCQUFpQnVDLE1BQU1wQyxPQUFPLGlCQUFpQixtQkFBbUIsSUFFakVvQyxnQkFBTXBDLFFBSFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFJQTtBQUFBLGtCQUNBLHVCQUFDLG9lQUFJLFdBQVUsbUNBQ1pvQztBQUFBQSwwQkFBTW5DO0FBQUFBLG9CQUFVO0FBQUEsb0JBQU1tQyxNQUFNbkMsY0FBYyxJQUFJLE1BQU07QUFBQSxvQkFBRztBQUFBLG9CQUFJa0MsbUJBQW1CQyxNQUFNcEMsSUFBSTtBQUFBLG9CQUFFO0FBQUEsdUJBRDdGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVNBO0FBQUEsZ0JBQ0NILGlCQUFpQnVDLE1BQU1wQyxRQUN0Qix1QkFBQyw4YUFBSyxNQUFLLFNBQVEsTUFBTSxJQUFJLFdBQVUsa0JBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFEO0FBQUEsbUJBWnpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBY0E7QUFBQTtBQUFBLFlBckJLb0MsTUFBTXBDO0FBQUFBLFlBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQXVCQTtBQUFBLFFBQ0QsS0ExQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTJCQTtBQUFBLFdBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4QkEsS0EvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdDQTtBQUFBLE1BR0EsdUJBQUMsb1pBQUksV0FBVSxpQkFDYixpQ0FBQyxzYkFBSSxXQUFVLDhDQUNiO0FBQUEsK0JBQUMsb2FBQUksV0FBVSw4QkFDYjtBQUFBLGlDQUFDLDRkQUFHLFdBQVUsMkNBQTBDO0FBQUE7QUFBQSxZQUFpQkg7QUFBQUEsZUFBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0Y7QUFBQSxVQUN0Rix1QkFBQyx5ZkFBRSxXQUFVLG9DQUFtQyw0REFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFFQSx1QkFBQyxxWkFBSSxXQUFVLGlCQUNaSyx1QkFBYXdDO0FBQUFBLFVBQUksQ0FBQ3ZDLGFBQ2pCLHVCQUFDLDJXQUNDO0FBQUEsbUNBQUMsK2NBQUcsV0FBVSxzRUFDWEEsb0JBQVVBLFlBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsc1pBQUksV0FBVSxrQkFDWkEsb0JBQVVDLE9BQU9zQztBQUFBQSxjQUFJLENBQUNDLGVBQ3JCO0FBQUEsZ0JBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUVDLFdBQVU7QUFBQSxrQkFFVjtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxTQUFTckMsa0JBQWtCVCxZQUFZLElBQUk4QyxZQUFZdEMsR0FBRyxLQUFLO0FBQUEsd0JBQy9ELFVBQVUsTUFBTXdCLHVCQUF1QmMsWUFBWXRDLEdBQUc7QUFBQSx3QkFDdEQsV0FBVTtBQUFBO0FBQUEsc0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUltRTtBQUFBLG9CQUVuRSx1QkFBQywyZUFBSyxXQUFVLDRGQUNic0Msc0JBQVkzQyxRQURmO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQTtBQUFBO0FBQUEsZ0JBWEsyQyxZQUFZdEM7QUFBQUEsZ0JBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FhQTtBQUFBLFlBQ0QsS0FoQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQkE7QUFBQSxlQXJCUUYsVUFBVUEsVUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFzQkE7QUFBQSxRQUNELEtBekJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwQkE7QUFBQSxXQWxDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBbUNBLEtBcENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQ0E7QUFBQSxTQTFFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMkVBO0FBQUEsSUFFQSx1QkFBQyw4YkFBSSxXQUFVLHFEQUNiLGlDQUFDLG1hQUFJLFdBQVUsOEJBQ2I7QUFBQSw2QkFBQyxzYkFBSyxNQUFLLFFBQU8sTUFBTSxJQUFJLFdBQVUseUJBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkQ7QUFBQSxNQUMzRCx1QkFBQyw0WUFBSSxXQUFVLFVBQ2I7QUFBQSwrQkFBQyxnZUFBRyxXQUFVLHlDQUF3QyxxQ0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRTtBQUFBLFFBQzNFLHVCQUFDLHVyQkFBRSxXQUFVLG9DQUFtQyx3S0FBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUE7QUFBQSxTQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQSxLQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FXQTtBQUFBLE9BdkdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3R0E7QUFFSjtBQUFFUCxHQXpSSUQsYUFBVztBQUFBaUQsS0FBWGpEO0FBMlJOLGVBQWVBO0FBQVksSUFBQWlEO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZVN0YXRlIiwiSWNvbiIsIlBlcm1pc3Npb25zIiwiX3MiLCJzZWxlY3RlZFJvbGUiLCJzZXRTZWxlY3RlZFJvbGUiLCJyb2xlcyIsIm5hbWUiLCJ1c2VyQ291bnQiLCJwZXJtaXNzaW9ucyIsImNhdGVnb3J5IiwiaXRlbXMiLCJrZXkiLCJyb2xlUGVybWlzc2lvbnMiLCJzZXRSb2xlUGVybWlzc2lvbnMiLCJ2aWV3X2Rhc2hib2FyZCIsInZpZXdfYW5hbHl0aWNzIiwiZXhwb3J0X3JlcG9ydHMiLCJ2aWV3X2NvbnRhY3RzIiwiY3JlYXRlX2NvbnRhY3RzIiwiZWRpdF9jb250YWN0cyIsImRlbGV0ZV9jb250YWN0cyIsImltcG9ydF9leHBvcnRfY29udGFjdHMiLCJ2aWV3X2RlYWxzIiwiY3JlYXRlX2RlYWxzIiwiZWRpdF9kZWFscyIsImRlbGV0ZV9kZWFscyIsIm1vdmVfcGlwZWxpbmVfc3RhZ2VzIiwidmlld191c2VycyIsImludml0ZV91c2VycyIsImVkaXRfdXNlcl9yb2xlcyIsImRlYWN0aXZhdGVfdXNlcnMiLCJtYW5hZ2VfaW50ZWdyYXRpb25zIiwiY29uZmlndXJlX2N1c3RvbV9maWVsZHMiLCJtYW5hZ2VfZW1haWxfdGVtcGxhdGVzIiwiYWNjZXNzX3N5c3RlbV9zZXR0aW5ncyIsImhhbmRsZVBlcm1pc3Npb25DaGFuZ2UiLCJwZXJtaXNzaW9uS2V5IiwicHJldiIsImhhbmRsZVNhdmVDaGFuZ2VzIiwiY29uc29sZSIsImxvZyIsImdldFBlcm1pc3Npb25Db3VudCIsInJvbGUiLCJPYmplY3QiLCJ2YWx1ZXMiLCJmaWx0ZXIiLCJCb29sZWFuIiwibGVuZ3RoIiwibWFwIiwicGVybWlzc2lvbiIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUGVybWlzc2lvbnMuanN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIHNyYy9wYWdlcy9zZXR0aW5ncy1hZG1pbmlzdHJhdGlvbi9jb21wb25lbnRzL1Blcm1pc3Npb25zLmpzeFxyXG5pbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCBJY29uIGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvQXBwSWNvbic7XHJcblxyXG5jb25zdCBQZXJtaXNzaW9ucyA9ICgpID0+IHtcclxuICBjb25zdCBbc2VsZWN0ZWRSb2xlLCBzZXRTZWxlY3RlZFJvbGVdID0gdXNlU3RhdGUoJ1NhbGVzIE1hbmFnZXInKTtcclxuICBcclxuICBjb25zdCByb2xlcyA9IFtcclxuICAgIHsgbmFtZTogJ0FkbWluJywgdXNlckNvdW50OiAyIH0sXHJcbiAgICB7IG5hbWU6ICdTYWxlcyBNYW5hZ2VyJywgdXNlckNvdW50OiA1IH0sXHJcbiAgICB7IG5hbWU6ICdTYWxlcyBSZXAnLCB1c2VyQ291bnQ6IDEyIH0sXHJcbiAgICB7IG5hbWU6ICdTYWxlcyBPcGVyYXRpb25zJywgdXNlckNvdW50OiAzIH1cclxuICBdO1xyXG5cclxuICBjb25zdCBwZXJtaXNzaW9ucyA9IFtcclxuICAgIHtcclxuICAgICAgY2F0ZWdvcnk6ICdEYXNoYm9hcmQgJiBBbmFseXRpY3MnLFxyXG4gICAgICBpdGVtczogW1xyXG4gICAgICAgIHsgbmFtZTogJ1ZpZXcgRGFzaGJvYXJkJywga2V5OiAndmlld19kYXNoYm9hcmQnIH0sXHJcbiAgICAgICAgeyBuYW1lOiAnVmlldyBBbmFseXRpY3MnLCBrZXk6ICd2aWV3X2FuYWx5dGljcycgfSxcclxuICAgICAgICB7IG5hbWU6ICdFeHBvcnQgUmVwb3J0cycsIGtleTogJ2V4cG9ydF9yZXBvcnRzJyB9XHJcbiAgICAgIF1cclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGNhdGVnb3J5OiAnQ29udGFjdCBNYW5hZ2VtZW50JyxcclxuICAgICAgaXRlbXM6IFtcclxuICAgICAgICB7IG5hbWU6ICdWaWV3IENvbnRhY3RzJywga2V5OiAndmlld19jb250YWN0cycgfSxcclxuICAgICAgICB7IG5hbWU6ICdDcmVhdGUgQ29udGFjdHMnLCBrZXk6ICdjcmVhdGVfY29udGFjdHMnIH0sXHJcbiAgICAgICAgeyBuYW1lOiAnRWRpdCBDb250YWN0cycsIGtleTogJ2VkaXRfY29udGFjdHMnIH0sXHJcbiAgICAgICAgeyBuYW1lOiAnRGVsZXRlIENvbnRhY3RzJywga2V5OiAnZGVsZXRlX2NvbnRhY3RzJyB9LFxyXG4gICAgICAgIHsgbmFtZTogJ0ltcG9ydC9FeHBvcnQgQ29udGFjdHMnLCBrZXk6ICdpbXBvcnRfZXhwb3J0X2NvbnRhY3RzJyB9XHJcbiAgICAgIF1cclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGNhdGVnb3J5OiAnRGVhbCBNYW5hZ2VtZW50JyxcclxuICAgICAgaXRlbXM6IFtcclxuICAgICAgICB7IG5hbWU6ICdWaWV3IERlYWxzJywga2V5OiAndmlld19kZWFscycgfSxcclxuICAgICAgICB7IG5hbWU6ICdDcmVhdGUgRGVhbHMnLCBrZXk6ICdjcmVhdGVfZGVhbHMnIH0sXHJcbiAgICAgICAgeyBuYW1lOiAnRWRpdCBEZWFscycsIGtleTogJ2VkaXRfZGVhbHMnIH0sXHJcbiAgICAgICAgeyBuYW1lOiAnRGVsZXRlIERlYWxzJywga2V5OiAnZGVsZXRlX2RlYWxzJyB9LFxyXG4gICAgICAgIHsgbmFtZTogJ01vdmUgUGlwZWxpbmUgU3RhZ2VzJywga2V5OiAnbW92ZV9waXBlbGluZV9zdGFnZXMnIH1cclxuICAgICAgXVxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgY2F0ZWdvcnk6ICdVc2VyIE1hbmFnZW1lbnQnLFxyXG4gICAgICBpdGVtczogW1xyXG4gICAgICAgIHsgbmFtZTogJ1ZpZXcgVXNlcnMnLCBrZXk6ICd2aWV3X3VzZXJzJyB9LFxyXG4gICAgICAgIHsgbmFtZTogJ0ludml0ZSBVc2VycycsIGtleTogJ2ludml0ZV91c2VycycgfSxcclxuICAgICAgICB7IG5hbWU6ICdFZGl0IFVzZXIgUm9sZXMnLCBrZXk6ICdlZGl0X3VzZXJfcm9sZXMnIH0sXHJcbiAgICAgICAgeyBuYW1lOiAnRGVhY3RpdmF0ZSBVc2VycycsIGtleTogJ2RlYWN0aXZhdGVfdXNlcnMnIH1cclxuICAgICAgXVxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgY2F0ZWdvcnk6ICdTeXN0ZW0gQ29uZmlndXJhdGlvbicsXHJcbiAgICAgIGl0ZW1zOiBbXHJcbiAgICAgICAgeyBuYW1lOiAnTWFuYWdlIEludGVncmF0aW9ucycsIGtleTogJ21hbmFnZV9pbnRlZ3JhdGlvbnMnIH0sXHJcbiAgICAgICAgeyBuYW1lOiAnQ29uZmlndXJlIEN1c3RvbSBGaWVsZHMnLCBrZXk6ICdjb25maWd1cmVfY3VzdG9tX2ZpZWxkcycgfSxcclxuICAgICAgICB7IG5hbWU6ICdNYW5hZ2UgRW1haWwgVGVtcGxhdGVzJywga2V5OiAnbWFuYWdlX2VtYWlsX3RlbXBsYXRlcycgfSxcclxuICAgICAgICB7IG5hbWU6ICdBY2Nlc3MgU3lzdGVtIFNldHRpbmdzJywga2V5OiAnYWNjZXNzX3N5c3RlbV9zZXR0aW5ncycgfVxyXG4gICAgICBdXHJcbiAgICB9XHJcbiAgXTtcclxuXHJcbiAgY29uc3QgW3JvbGVQZXJtaXNzaW9ucywgc2V0Um9sZVBlcm1pc3Npb25zXSA9IHVzZVN0YXRlKHtcclxuICAgICdBZG1pbic6IHtcclxuICAgICAgdmlld19kYXNoYm9hcmQ6IHRydWUsXHJcbiAgICAgIHZpZXdfYW5hbHl0aWNzOiB0cnVlLFxyXG4gICAgICBleHBvcnRfcmVwb3J0czogdHJ1ZSxcclxuICAgICAgdmlld19jb250YWN0czogdHJ1ZSxcclxuICAgICAgY3JlYXRlX2NvbnRhY3RzOiB0cnVlLFxyXG4gICAgICBlZGl0X2NvbnRhY3RzOiB0cnVlLFxyXG4gICAgICBkZWxldGVfY29udGFjdHM6IHRydWUsXHJcbiAgICAgIGltcG9ydF9leHBvcnRfY29udGFjdHM6IHRydWUsXHJcbiAgICAgIHZpZXdfZGVhbHM6IHRydWUsXHJcbiAgICAgIGNyZWF0ZV9kZWFsczogdHJ1ZSxcclxuICAgICAgZWRpdF9kZWFsczogdHJ1ZSxcclxuICAgICAgZGVsZXRlX2RlYWxzOiB0cnVlLFxyXG4gICAgICBtb3ZlX3BpcGVsaW5lX3N0YWdlczogdHJ1ZSxcclxuICAgICAgdmlld191c2VyczogdHJ1ZSxcclxuICAgICAgaW52aXRlX3VzZXJzOiB0cnVlLFxyXG4gICAgICBlZGl0X3VzZXJfcm9sZXM6IHRydWUsXHJcbiAgICAgIGRlYWN0aXZhdGVfdXNlcnM6IHRydWUsXHJcbiAgICAgIG1hbmFnZV9pbnRlZ3JhdGlvbnM6IHRydWUsXHJcbiAgICAgIGNvbmZpZ3VyZV9jdXN0b21fZmllbGRzOiB0cnVlLFxyXG4gICAgICBtYW5hZ2VfZW1haWxfdGVtcGxhdGVzOiB0cnVlLFxyXG4gICAgICBhY2Nlc3Nfc3lzdGVtX3NldHRpbmdzOiB0cnVlXHJcbiAgICB9LFxyXG4gICAgJ1NhbGVzIE1hbmFnZXInOiB7XHJcbiAgICAgIHZpZXdfZGFzaGJvYXJkOiB0cnVlLFxyXG4gICAgICB2aWV3X2FuYWx5dGljczogdHJ1ZSxcclxuICAgICAgZXhwb3J0X3JlcG9ydHM6IHRydWUsXHJcbiAgICAgIHZpZXdfY29udGFjdHM6IHRydWUsXHJcbiAgICAgIGNyZWF0ZV9jb250YWN0czogdHJ1ZSxcclxuICAgICAgZWRpdF9jb250YWN0czogdHJ1ZSxcclxuICAgICAgZGVsZXRlX2NvbnRhY3RzOiBmYWxzZSxcclxuICAgICAgaW1wb3J0X2V4cG9ydF9jb250YWN0czogdHJ1ZSxcclxuICAgICAgdmlld19kZWFsczogdHJ1ZSxcclxuICAgICAgY3JlYXRlX2RlYWxzOiB0cnVlLFxyXG4gICAgICBlZGl0X2RlYWxzOiB0cnVlLFxyXG4gICAgICBkZWxldGVfZGVhbHM6IGZhbHNlLFxyXG4gICAgICBtb3ZlX3BpcGVsaW5lX3N0YWdlczogdHJ1ZSxcclxuICAgICAgdmlld191c2VyczogdHJ1ZSxcclxuICAgICAgaW52aXRlX3VzZXJzOiBmYWxzZSxcclxuICAgICAgZWRpdF91c2VyX3JvbGVzOiBmYWxzZSxcclxuICAgICAgZGVhY3RpdmF0ZV91c2VyczogZmFsc2UsXHJcbiAgICAgIG1hbmFnZV9pbnRlZ3JhdGlvbnM6IGZhbHNlLFxyXG4gICAgICBjb25maWd1cmVfY3VzdG9tX2ZpZWxkczogZmFsc2UsXHJcbiAgICAgIG1hbmFnZV9lbWFpbF90ZW1wbGF0ZXM6IHRydWUsXHJcbiAgICAgIGFjY2Vzc19zeXN0ZW1fc2V0dGluZ3M6IGZhbHNlXHJcbiAgICB9LFxyXG4gICAgJ1NhbGVzIFJlcCc6IHtcclxuICAgICAgdmlld19kYXNoYm9hcmQ6IHRydWUsXHJcbiAgICAgIHZpZXdfYW5hbHl0aWNzOiBmYWxzZSxcclxuICAgICAgZXhwb3J0X3JlcG9ydHM6IGZhbHNlLFxyXG4gICAgICB2aWV3X2NvbnRhY3RzOiB0cnVlLFxyXG4gICAgICBjcmVhdGVfY29udGFjdHM6IHRydWUsXHJcbiAgICAgIGVkaXRfY29udGFjdHM6IHRydWUsXHJcbiAgICAgIGRlbGV0ZV9jb250YWN0czogZmFsc2UsXHJcbiAgICAgIGltcG9ydF9leHBvcnRfY29udGFjdHM6IGZhbHNlLFxyXG4gICAgICB2aWV3X2RlYWxzOiB0cnVlLFxyXG4gICAgICBjcmVhdGVfZGVhbHM6IHRydWUsXHJcbiAgICAgIGVkaXRfZGVhbHM6IHRydWUsXHJcbiAgICAgIGRlbGV0ZV9kZWFsczogZmFsc2UsXHJcbiAgICAgIG1vdmVfcGlwZWxpbmVfc3RhZ2VzOiB0cnVlLFxyXG4gICAgICB2aWV3X3VzZXJzOiBmYWxzZSxcclxuICAgICAgaW52aXRlX3VzZXJzOiBmYWxzZSxcclxuICAgICAgZWRpdF91c2VyX3JvbGVzOiBmYWxzZSxcclxuICAgICAgZGVhY3RpdmF0ZV91c2VyczogZmFsc2UsXHJcbiAgICAgIG1hbmFnZV9pbnRlZ3JhdGlvbnM6IGZhbHNlLFxyXG4gICAgICBjb25maWd1cmVfY3VzdG9tX2ZpZWxkczogZmFsc2UsXHJcbiAgICAgIG1hbmFnZV9lbWFpbF90ZW1wbGF0ZXM6IGZhbHNlLFxyXG4gICAgICBhY2Nlc3Nfc3lzdGVtX3NldHRpbmdzOiBmYWxzZVxyXG4gICAgfSxcclxuICAgICdTYWxlcyBPcGVyYXRpb25zJzoge1xyXG4gICAgICB2aWV3X2Rhc2hib2FyZDogdHJ1ZSxcclxuICAgICAgdmlld19hbmFseXRpY3M6IHRydWUsXHJcbiAgICAgIGV4cG9ydF9yZXBvcnRzOiB0cnVlLFxyXG4gICAgICB2aWV3X2NvbnRhY3RzOiB0cnVlLFxyXG4gICAgICBjcmVhdGVfY29udGFjdHM6IHRydWUsXHJcbiAgICAgIGVkaXRfY29udGFjdHM6IHRydWUsXHJcbiAgICAgIGRlbGV0ZV9jb250YWN0czogdHJ1ZSxcclxuICAgICAgaW1wb3J0X2V4cG9ydF9jb250YWN0czogdHJ1ZSxcclxuICAgICAgdmlld19kZWFsczogdHJ1ZSxcclxuICAgICAgY3JlYXRlX2RlYWxzOiBmYWxzZSxcclxuICAgICAgZWRpdF9kZWFsczogZmFsc2UsXHJcbiAgICAgIGRlbGV0ZV9kZWFsczogZmFsc2UsXHJcbiAgICAgIG1vdmVfcGlwZWxpbmVfc3RhZ2VzOiBmYWxzZSxcclxuICAgICAgdmlld191c2VyczogdHJ1ZSxcclxuICAgICAgaW52aXRlX3VzZXJzOiBmYWxzZSxcclxuICAgICAgZWRpdF91c2VyX3JvbGVzOiBmYWxzZSxcclxuICAgICAgZGVhY3RpdmF0ZV91c2VyczogZmFsc2UsXHJcbiAgICAgIG1hbmFnZV9pbnRlZ3JhdGlvbnM6IHRydWUsXHJcbiAgICAgIGNvbmZpZ3VyZV9jdXN0b21fZmllbGRzOiB0cnVlLFxyXG4gICAgICBtYW5hZ2VfZW1haWxfdGVtcGxhdGVzOiB0cnVlLFxyXG4gICAgICBhY2Nlc3Nfc3lzdGVtX3NldHRpbmdzOiB0cnVlXHJcbiAgICB9XHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZVBlcm1pc3Npb25DaGFuZ2UgPSAocGVybWlzc2lvbktleSkgPT4ge1xyXG4gICAgc2V0Um9sZVBlcm1pc3Npb25zKHByZXYgPT4gKHtcclxuICAgICAgLi4ucHJldixcclxuICAgICAgW3NlbGVjdGVkUm9sZV06IHtcclxuICAgICAgICAuLi5wcmV2Py5bc2VsZWN0ZWRSb2xlXSxcclxuICAgICAgICBbcGVybWlzc2lvbktleV06ICFwcmV2Py5bc2VsZWN0ZWRSb2xlXT8uW3Blcm1pc3Npb25LZXldXHJcbiAgICAgIH1cclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTYXZlQ2hhbmdlcyA9ICgpID0+IHtcclxuICAgIGNvbnNvbGUubG9nKCdTYXZpbmcgcGVybWlzc2lvbiBjaGFuZ2VzIGZvcjonLCBzZWxlY3RlZFJvbGUsIHJvbGVQZXJtaXNzaW9ucz8uW3NlbGVjdGVkUm9sZV0pO1xyXG4gICAgLy8gSGVyZSB5b3Ugd291bGQgdHlwaWNhbGx5IG1ha2UgYW4gQVBJIGNhbGwgdG8gc2F2ZSB0aGUgY2hhbmdlc1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGdldFBlcm1pc3Npb25Db3VudCA9IChyb2xlKSA9PiB7XHJcbiAgICBjb25zdCBwZXJtaXNzaW9ucyA9IHJvbGVQZXJtaXNzaW9ucz8uW3JvbGVdIHx8IHt9O1xyXG4gICAgcmV0dXJuIE9iamVjdC52YWx1ZXMocGVybWlzc2lvbnMpPy5maWx0ZXIoQm9vbGVhbik/Lmxlbmd0aDtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cclxuICAgICAgey8qIEhlYWRlciAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXRleHQtcHJpbWFyeVwiPlBlcm1pc3Npb25zPC9oMj5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtdGV4dC1zZWNvbmRhcnkgbXQtMVwiPkNvbmZpZ3VyZSByb2xlLWJhc2VkIGFjY2VzcyBjb250cm9sPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVNhdmVDaGFuZ2VzfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiYmctcHJpbWFyeSB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkLWxnIGhvdmVyOmJnLXByaW1hcnktNjAwIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MCBlYXNlLXNtb290aCBmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTJcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxJY29uIG5hbWU9XCJTYXZlXCIgc2l6ZT17MTZ9IC8+XHJcbiAgICAgICAgICA8c3Bhbj5TYXZlIENoYW5nZXM8L3NwYW4+XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbGc6Z3JpZC1jb2xzLTEyIGdhcC02XCI+XHJcbiAgICAgICAgey8qIFJvbGUgU2VsZWN0aW9uICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6Y29sLXNwYW4tNFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zdXJmYWNlIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ib3JkZXIgcC02XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC10ZXh0LXByaW1hcnkgbWItNFwiPlJvbGVzPC9oMz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICB7cm9sZXM/Lm1hcCgocm9sZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBrZXk9e3JvbGU/Lm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkUm9sZShyb2xlPy5uYW1lKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIHRleHQtbGVmdCBwLTMgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0xNTAgZWFzZS1zbW9vdGggJHtcclxuICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZFJvbGUgPT09IHJvbGU/Lm5hbWVcclxuICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXByaW1hcnktNTAgYm9yZGVyIGJvcmRlci1wcmltYXJ5LTEwMCB0ZXh0LXByaW1hcnknIDondGV4dC10ZXh0LXNlY29uZGFyeSBob3Zlcjp0ZXh0LXRleHQtcHJpbWFyeSBob3ZlcjpiZy1zdXJmYWNlLWhvdmVyIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQnXHJcbiAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGZvbnQtbWVkaXVtIHRleHQtc20gJHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRSb2xlID09PSByb2xlPy5uYW1lID8gJ3RleHQtcHJpbWFyeScgOiAndGV4dC10ZXh0LXByaW1hcnknXHJcbiAgICAgICAgICAgICAgICAgICAgICB9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtyb2xlPy5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC10ZXh0LXRlcnRpYXJ5IG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3JvbGU/LnVzZXJDb3VudH0gdXNlcntyb2xlPy51c2VyQ291bnQgIT09IDEgPyAncycgOiAnJ30g4oCiIHtnZXRQZXJtaXNzaW9uQ291bnQocm9sZT8ubmFtZSl9IHBlcm1pc3Npb25zXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRSb2xlID09PSByb2xlPy5uYW1lICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJDaGVja1wiIHNpemU9ezE2fSBjbGFzc05hbWU9XCJ0ZXh0LXByaW1hcnlcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBQZXJtaXNzaW9uIE1hdHJpeCAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOmNvbC1zcGFuLThcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc3VyZmFjZSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItYm9yZGVyXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IGJvcmRlci1iIGJvcmRlci1ib3JkZXJcIj5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtdGV4dC1wcmltYXJ5XCI+UGVybWlzc2lvbnMgZm9yIHtzZWxlY3RlZFJvbGV9PC9oMz5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5IHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgQ29uZmlndXJlIHdoYXQgYWN0aW9ucyB0aGlzIHJvbGUgY2FuIHBlcmZvcm1cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgc3BhY2UteS02XCI+XHJcbiAgICAgICAgICAgICAge3Blcm1pc3Npb25zPy5tYXAoKGNhdGVnb3J5KSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17Y2F0ZWdvcnk/LmNhdGVnb3J5fT5cclxuICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IG1iLTMgdGV4dC1zbSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtjYXRlZ29yeT8uY2F0ZWdvcnl9XHJcbiAgICAgICAgICAgICAgICAgIDwvaDQ+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yIG1sLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Y2F0ZWdvcnk/Lml0ZW1zPy5tYXAoKHBlcm1pc3Npb24pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e3Blcm1pc3Npb24/LmtleX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0zIHAtMiByb3VuZGVkIGhvdmVyOmJnLXN1cmZhY2UtaG92ZXIgY3Vyc29yLXBvaW50ZXIgZ3JvdXBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3JvbGVQZXJtaXNzaW9ucz8uW3NlbGVjdGVkUm9sZV0/LltwZXJtaXNzaW9uPy5rZXldIHx8IGZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiBoYW5kbGVQZXJtaXNzaW9uQ2hhbmdlKHBlcm1pc3Npb24/LmtleSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZCBib3JkZXItYm9yZGVyIHRleHQtcHJpbWFyeSBmb2N1czpyaW5nLXByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtdGV4dC1zZWNvbmRhcnkgZ3JvdXAtaG92ZXI6dGV4dC10ZXh0LXByaW1hcnkgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge3Blcm1pc3Npb24/Lm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICB7LyogUGVybWlzc2lvbiBTdW1tYXJ5ICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWJhY2tncm91bmQgYm9yZGVyIGJvcmRlci1ib3JkZXIgcm91bmRlZC1sZyBwLTRcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgc3BhY2UteC0zXCI+XHJcbiAgICAgICAgICA8SWNvbiBuYW1lPVwiSW5mb1wiIHNpemU9ezE2fSBjbGFzc05hbWU9XCJ0ZXh0LXByaW1hcnkgbXQtMC41XCIgLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XHJcbiAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSB0ZXh0LXNtXCI+UGVybWlzc2lvbiBHdWlkZWxpbmVzPC9oND5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC10ZXh0LXNlY29uZGFyeSB0ZXh0LXNtIG10LTFcIj5cclxuICAgICAgICAgICAgICBDaGFuZ2VzIHRvIHBlcm1pc3Npb25zIHdpbGwgdGFrZSBlZmZlY3QgaW1tZWRpYXRlbHkgZm9yIGFsbCB1c2VycyB3aXRoIHRoZSBzZWxlY3RlZCByb2xlLiBcclxuICAgICAgICAgICAgICBVc2VycyBtYXkgbmVlZCB0byByZWZyZXNoIHRoZWlyIGJyb3dzZXIgdG8gc2VlIHVwZGF0ZWQgYWNjZXNzLlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgUGVybWlzc2lvbnM7Il0sImZpbGUiOiJEOi9jdXJyZW50IHByb2plY3RzL2NsYXVkZS1jb2RlL3NyYy9wYWdlcy9zZXR0aW5ncy1hZG1pbmlzdHJhdGlvbi9jb21wb25lbnRzL1Blcm1pc3Npb25zLmpzeCJ9