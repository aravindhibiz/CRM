import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/contact-management/components/ContactForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import Icon from "/src/components/AppIcon.jsx";
import { useAuth } from "/src/contexts/AuthContext.jsx";
import contactsService from "/src/services/contactsService.js";
import companiesService from "/src/services/companiesService.js";
const ContactForm = ({ contact = null, onSubmit, onCancel }) => {
  _s();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [companies, setCompanies] = useState([]);
  const [formData, setFormData] = useState({
    first_name: "",
    last_name: "",
    email: "",
    phone: "",
    mobile: "",
    position: "",
    department: "",
    company_id: "",
    companyName: "",
    // Keep for new company creation
    status: "prospect",
    lead_source: "website",
    notes: "",
    tags: [],
    linkedin_url: "",
    twitter_url: "",
    owner_id: user?.id || ""
  });
  const [errors, setErrors] = useState({});
  const [newTag, setNewTag] = useState("");
  useEffect(() => {
    loadCompanies();
    if (contact) {
      setFormData({
        first_name: contact?.first_name || "",
        last_name: contact?.last_name || "",
        email: contact?.email || "",
        phone: contact?.phone || "",
        mobile: contact?.mobile || "",
        position: contact?.position || "",
        department: contact?.department || "",
        company_id: contact?.company_id || "",
        companyName: "",
        status: contact?.status || "prospect",
        lead_source: contact?.lead_source || "website",
        notes: contact?.notes || "",
        tags: contact?.tags || [],
        linkedin_url: contact?.linkedin_url || "",
        twitter_url: contact?.twitter_url || "",
        owner_id: contact?.owner_id || user?.id || ""
      });
    }
  }, [contact, user]);
  const loadCompanies = async () => {
    try {
      const companiesData = await companiesService?.getAllCompanies();
      setCompanies(companiesData || []);
    } catch (err) {
      console.error("Error loading companies:", err);
      setErrors({
        submit: "Failed to load companies. Please try refreshing the page."
      });
    }
  };
  const handleSubmit = async (e) => {
    e?.preventDefault();
    setLoading(true);
    setErrors({});
    try {
      const requiredFields = ["first_name", "last_name", "email"];
      const validationErrors = {};
      requiredFields?.forEach((field) => {
        if (!formData?.[field]?.trim()) {
          validationErrors[field] = `${field?.replace("_", " ")} is required`;
        }
      });
      if (formData?.email && !/\S+@\S+\.\S+/?.test(formData?.email)) {
        validationErrors.email = "Please enter a valid email address";
      }
      if (Object.keys(validationErrors)?.length > 0) {
        setErrors(validationErrors);
        setLoading(false);
        return;
      }
      const { companyName, ...submitData } = formData;
      let result;
      if (contact) {
        result = await contactsService?.updateContact(contact?.id, submitData);
      } else {
        result = await contactsService?.createContact(formData);
      }
      onSubmit?.(result);
    } catch (err) {
      console.error("Error saving contact:", err);
      setErrors({
        submit: err?.message || "Failed to save contact. Please try again."
      });
    } finally {
      setLoading(false);
    }
  };
  const handleInputChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors?.[field]) {
      setErrors((prev) => {
        const newErrors = { ...prev };
        delete newErrors?.[field];
        return newErrors;
      });
    }
  };
  const addTag = () => {
    if (newTag?.trim() && !formData?.tags?.includes(newTag?.trim())) {
      setFormData((prev) => ({
        ...prev,
        tags: [...prev?.tags || [], newTag?.trim()]
      }));
      setNewTag("");
    }
  };
  const removeTag = (tagToRemove) => {
    setFormData((prev) => ({
      ...prev,
      tags: prev?.tags?.filter((tag) => tag !== tagToRemove) || []
    }));
  };
  const leadSources = [
    { value: "website", label: "Website" },
    { value: "referral", label: "Referral" },
    { value: "cold_call", label: "Cold Call" },
    { value: "email_campaign", label: "Email Campaign" },
    { value: "social_media", label: "Social Media" },
    { value: "event", label: "Event" },
    { value: "partner", label: "Partner" },
    { value: "other", label: "Other" }
  ];
  const contactStatuses = [
    { value: "prospect", label: "Prospect" },
    { value: "active", label: "Active" },
    { value: "customer", label: "Customer" },
    { value: "inactive", label: "Inactive" }
  ];
  return /* @__PURE__ */ jsxDEV("form", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:169:4", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "169", "data-component-file": "ContactForm.jsx", "data-component-name": "form", "data-component-content": "%7B%22elementName%22%3A%22form%22%2C%22className%22%3A%22space-y-6%22%7D", onSubmit: handleSubmit, className: "space-y-6", children: [
    errors?.submit && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:172:6", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "172", "data-component-file": "ContactForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-error-50%20border%20border-error-200%20text-error%20p-4%20rounded-lg%20flex%20items-center%20space-x-2%22%7D", className: "bg-error-50 border border-error-200 text-error p-4 rounded-lg flex items-center space-x-2", children: [
      /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:173:10", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "173", "data-component-file": "ContactForm.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22AlertCircle%22%7D", name: "AlertCircle", size: 20 }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
        lineNumber: 173,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:174:10", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "174", "data-component-file": "ContactForm.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: errors?.submit }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
        lineNumber: 174,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
      lineNumber: 172,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:179:6", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "179", "data-component-file": "ContactForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20md%3Agrid-cols-2%20gap-4%22%7D", className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:180:8", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "180", "data-component-file": "ContactForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
        /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:181:10", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "181", "data-component-file": "ContactForm.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22First%20Name%20*%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "First Name *" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
          lineNumber: 181,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:184:10",
            "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx",
            "data-component-line": "184",
            "data-component-file": "ContactForm.jsx",
            "data-component-name": "input",
            "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22text%22%7D",
            type: "text",
            value: formData?.first_name,
            onChange: (e) => handleInputChange("first_name", e?.target?.value),
            className: `w-full px-3 py-2 border rounded-lg focus:ring-primary focus:border-primary ${errors?.first_name ? "border-error" : "border-border"}`,
            placeholder: "John",
            required: true
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
            lineNumber: 184,
            columnNumber: 11
          },
          this
        ),
        errors?.first_name && /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:195:10", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "195", "data-component-file": "ContactForm.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%20text-error%20mt-1%22%7D", className: "text-sm text-error mt-1", children: errors?.first_name }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
          lineNumber: 195,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
        lineNumber: 180,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:199:8", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "199", "data-component-file": "ContactForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
        /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:200:10", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "200", "data-component-file": "ContactForm.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Last%20Name%20*%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Last Name *" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
          lineNumber: 200,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:203:10",
            "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx",
            "data-component-line": "203",
            "data-component-file": "ContactForm.jsx",
            "data-component-name": "input",
            "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22text%22%7D",
            type: "text",
            value: formData?.last_name,
            onChange: (e) => handleInputChange("last_name", e?.target?.value),
            className: `w-full px-3 py-2 border rounded-lg focus:ring-primary focus:border-primary ${errors?.last_name ? "border-error" : "border-border"}`,
            placeholder: "Doe",
            required: true
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
            lineNumber: 203,
            columnNumber: 11
          },
          this
        ),
        errors?.last_name && /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:214:10", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "214", "data-component-file": "ContactForm.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%20text-error%20mt-1%22%7D", className: "text-sm text-error mt-1", children: errors?.last_name }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
          lineNumber: 214,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
        lineNumber: 199,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
      lineNumber: 179,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:220:6", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "220", "data-component-file": "ContactForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20md%3Agrid-cols-2%20gap-4%22%7D", className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:221:8", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "221", "data-component-file": "ContactForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
        /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:222:10", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "222", "data-component-file": "ContactForm.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Email%20Address%20*%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Email Address *" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
          lineNumber: 222,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:225:10",
            "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx",
            "data-component-line": "225",
            "data-component-file": "ContactForm.jsx",
            "data-component-name": "input",
            "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22email%22%7D",
            type: "email",
            value: formData?.email,
            onChange: (e) => handleInputChange("email", e?.target?.value),
            className: `w-full px-3 py-2 border rounded-lg focus:ring-primary focus:border-primary ${errors?.email ? "border-error" : "border-border"}`,
            placeholder: "john.doe@company.com",
            required: true
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
            lineNumber: 225,
            columnNumber: 11
          },
          this
        ),
        errors?.email && /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:236:10", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "236", "data-component-file": "ContactForm.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%20text-error%20mt-1%22%7D", className: "text-sm text-error mt-1", children: errors?.email }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
          lineNumber: 236,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
        lineNumber: 221,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:240:8", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "240", "data-component-file": "ContactForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
        /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:241:10", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "241", "data-component-file": "ContactForm.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Phone%20Number%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Phone Number" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
          lineNumber: 241,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:244:10",
            "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx",
            "data-component-line": "244",
            "data-component-file": "ContactForm.jsx",
            "data-component-name": "input",
            "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22tel%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
            type: "tel",
            value: formData?.phone,
            onChange: (e) => handleInputChange("phone", e?.target?.value),
            className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
            placeholder: "+1 (555) 123-4567"
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
            lineNumber: 244,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
        lineNumber: 240,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
      lineNumber: 220,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:255:6", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "255", "data-component-file": "ContactForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20md%3Agrid-cols-2%20gap-4%22%7D", className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:256:8", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "256", "data-component-file": "ContactForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
        /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:257:10", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "257", "data-component-file": "ContactForm.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Position%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Position" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
          lineNumber: 257,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:260:10",
            "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx",
            "data-component-line": "260",
            "data-component-file": "ContactForm.jsx",
            "data-component-name": "input",
            "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22text%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
            type: "text",
            value: formData?.position,
            onChange: (e) => handleInputChange("position", e?.target?.value),
            className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
            placeholder: "Sales Manager"
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
            lineNumber: 260,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
        lineNumber: 256,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:269:8", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "269", "data-component-file": "ContactForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
        /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:270:10", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "270", "data-component-file": "ContactForm.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Department%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Department" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
          lineNumber: 270,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:273:10",
            "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx",
            "data-component-line": "273",
            "data-component-file": "ContactForm.jsx",
            "data-component-name": "input",
            "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22text%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
            type: "text",
            value: formData?.department,
            onChange: (e) => handleInputChange("department", e?.target?.value),
            className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
            placeholder: "Sales"
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
            lineNumber: 273,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
        lineNumber: 269,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
      lineNumber: 255,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:284:6", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "284", "data-component-file": "ContactForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
      /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:285:8", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "285", "data-component-file": "ContactForm.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Company%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Company" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
        lineNumber: 285,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:288:8", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "288", "data-component-file": "ContactForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20md%3Agrid-cols-2%20gap-4%22%7D", className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
        /* @__PURE__ */ jsxDEV(
          "select",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:289:10",
            "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx",
            "data-component-line": "289",
            "data-component-file": "ContactForm.jsx",
            "data-component-name": "select",
            "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
            value: formData?.company_id,
            onChange: (e) => handleInputChange("company_id", e?.target?.value),
            className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
            children: [
              /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:294:12", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "294", "data-component-file": "ContactForm.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22%22%2C%22textContent%22%3A%22Select%20Existing%20Company%22%7D", value: "", children: "Select Existing Company" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
                lineNumber: 294,
                columnNumber: 13
              }, this),
              companies?.map(
                (company) => /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:296:12", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "296", "data-component-file": "ContactForm.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%7D", value: company?.id, children: company?.name }, company?.id, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
                  lineNumber: 296,
                  columnNumber: 13
                }, this)
              )
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
            lineNumber: 289,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:302:10",
            "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx",
            "data-component-line": "302",
            "data-component-file": "ContactForm.jsx",
            "data-component-name": "input",
            "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22text%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
            type: "text",
            value: formData?.companyName,
            onChange: (e) => handleInputChange("companyName", e?.target?.value),
            className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
            placeholder: "Or enter new company name"
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
            lineNumber: 302,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
        lineNumber: 288,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
      lineNumber: 284,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:313:6", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "313", "data-component-file": "ContactForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20md%3Agrid-cols-2%20gap-4%22%7D", className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:314:8", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "314", "data-component-file": "ContactForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
        /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:315:10", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "315", "data-component-file": "ContactForm.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Status%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Status" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
          lineNumber: 315,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "select",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:318:10",
            "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx",
            "data-component-line": "318",
            "data-component-file": "ContactForm.jsx",
            "data-component-name": "select",
            "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
            value: formData?.status,
            onChange: (e) => handleInputChange("status", e?.target?.value),
            className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
            children: contactStatuses?.map(
              (status) => /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:324:12", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "324", "data-component-file": "ContactForm.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%7D", value: status?.value, children: status?.label }, status?.value, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
                lineNumber: 324,
                columnNumber: 13
              }, this)
            )
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
            lineNumber: 318,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
        lineNumber: 314,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:331:8", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "331", "data-component-file": "ContactForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
        /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:332:10", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "332", "data-component-file": "ContactForm.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Lead%20Source%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Lead Source" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
          lineNumber: 332,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "select",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:335:10",
            "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx",
            "data-component-line": "335",
            "data-component-file": "ContactForm.jsx",
            "data-component-name": "select",
            "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
            value: formData?.lead_source,
            onChange: (e) => handleInputChange("lead_source", e?.target?.value),
            className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
            children: leadSources?.map(
              (source) => /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:341:12", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "341", "data-component-file": "ContactForm.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%7D", value: source?.value, children: source?.label }, source?.value, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
                lineNumber: 341,
                columnNumber: 13
              }, this)
            )
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
            lineNumber: 335,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
        lineNumber: 331,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
      lineNumber: 313,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:350:6", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "350", "data-component-file": "ContactForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
      /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:351:8", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "351", "data-component-file": "ContactForm.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Tags%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Tags" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
        lineNumber: 351,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:354:8", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "354", "data-component-file": "ContactForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20flex-wrap%20gap-2%20mb-2%22%7D", className: "flex flex-wrap gap-2 mb-2", children: formData?.tags?.map(
        (tag, index) => /* @__PURE__ */ jsxDEV(
          "span",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:356:10",
            "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx",
            "data-component-line": "356",
            "data-component-file": "ContactForm.jsx",
            "data-component-name": "span",
            "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22inline-flex%20items-center%20px-2%20py-1%20rounded-full%20text-xs%20font-medium%20bg-primary-100%20text-primary-800%22%7D",
            className: "inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-primary-100 text-primary-800",
            children: [
              tag,
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:361:14",
                  "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx",
                  "data-component-line": "361",
                  "data-component-file": "ContactForm.jsx",
                  "data-component-name": "button",
                  "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22button%22%2C%22className%22%3A%22ml-1%20text-primary-600%20hover%3Atext-primary-800%22%7D",
                  type: "button",
                  onClick: () => removeTag(tag),
                  className: "ml-1 text-primary-600 hover:text-primary-800",
                  children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:366:16", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "366", "data-component-file": "ContactForm.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22X%22%7D", name: "X", size: 12 }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
                    lineNumber: 366,
                    columnNumber: 17
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
                  lineNumber: 361,
                  columnNumber: 15
                },
                this
              )
            ]
          },
          index,
          true,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
            lineNumber: 356,
            columnNumber: 11
          },
          this
        )
      ) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
        lineNumber: 354,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:371:8", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "371", "data-component-file": "ContactForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20space-x-2%22%7D", className: "flex space-x-2", children: [
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:372:10",
            "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx",
            "data-component-line": "372",
            "data-component-file": "ContactForm.jsx",
            "data-component-name": "input",
            "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22text%22%2C%22value%22%3A%22%5Bvar%3AnewTag%5D%22%2C%22className%22%3A%22flex-1%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
            type: "text",
            value: newTag,
            onChange: (e) => setNewTag(e?.target?.value),
            onKeyPress: (e) => e?.key === "Enter" && (e?.preventDefault(), addTag()),
            className: "flex-1 px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
            placeholder: "Add a tag and press Enter"
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
            lineNumber: 372,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:380:10",
            "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx",
            "data-component-line": "380",
            "data-component-file": "ContactForm.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22button%22%2C%22className%22%3A%22px-3%20py-2%20bg-text-secondary%20text-white%20rounded-lg%20hover%3Abg-text-primary%20transition-colors%20duration-150%22%2C%22textContent%22%3A%22Add%22%7D",
            type: "button",
            onClick: addTag,
            className: "px-3 py-2 bg-text-secondary text-white rounded-lg hover:bg-text-primary transition-colors duration-150",
            children: "Add"
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
            lineNumber: 380,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
        lineNumber: 371,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
      lineNumber: 350,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:391:6", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "391", "data-component-file": "ContactForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20md%3Agrid-cols-2%20gap-4%22%7D", className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:392:8", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "392", "data-component-file": "ContactForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
        /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:393:10", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "393", "data-component-file": "ContactForm.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22LinkedIn%20URL%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "LinkedIn URL" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
          lineNumber: 393,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:396:10",
            "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx",
            "data-component-line": "396",
            "data-component-file": "ContactForm.jsx",
            "data-component-name": "input",
            "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22url%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
            type: "url",
            value: formData?.linkedin_url,
            onChange: (e) => handleInputChange("linkedin_url", e?.target?.value),
            className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
            placeholder: "https://linkedin.com/in/johndoe"
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
            lineNumber: 396,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
        lineNumber: 392,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:405:8", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "405", "data-component-file": "ContactForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
        /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:406:10", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "406", "data-component-file": "ContactForm.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Twitter%20URL%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Twitter URL" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
          lineNumber: 406,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:409:10",
            "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx",
            "data-component-line": "409",
            "data-component-file": "ContactForm.jsx",
            "data-component-name": "input",
            "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22url%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
            type: "url",
            value: formData?.twitter_url,
            onChange: (e) => handleInputChange("twitter_url", e?.target?.value),
            className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
            placeholder: "https://twitter.com/johndoe"
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
            lineNumber: 409,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
        lineNumber: 405,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
      lineNumber: 391,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:420:6", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "420", "data-component-file": "ContactForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
      /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:421:8", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "421", "data-component-file": "ContactForm.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Notes%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Notes" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
        lineNumber: 421,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "textarea",
        {
          "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:424:8",
          "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx",
          "data-component-line": "424",
          "data-component-file": "ContactForm.jsx",
          "data-component-name": "textarea",
          "data-component-content": "%7B%22elementName%22%3A%22textarea%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
          value: formData?.notes,
          onChange: (e) => handleInputChange("notes", e?.target?.value),
          rows: 4,
          className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
          placeholder: "Additional notes about this contact..."
        },
        void 0,
        false,
        {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
          lineNumber: 424,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
      lineNumber: 420,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:434:6", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "434", "data-component-file": "ContactForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20justify-end%20space-x-3%20pt-4%20border-t%20border-border%22%7D", className: "flex justify-end space-x-3 pt-4 border-t border-border", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:435:8",
          "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx",
          "data-component-line": "435",
          "data-component-file": "ContactForm.jsx",
          "data-component-name": "button",
          "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22button%22%2C%22className%22%3A%22px-4%20py-2%20text-text-secondary%20hover%3Atext-text-primary%20transition-colors%20duration-150%22%2C%22textContent%22%3A%22Cancel%22%7D",
          type: "button",
          onClick: onCancel,
          className: "px-4 py-2 text-text-secondary hover:text-text-primary transition-colors duration-150",
          disabled: loading,
          children: "Cancel"
        },
        void 0,
        false,
        {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
          lineNumber: 435,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:443:8",
          "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx",
          "data-component-line": "443",
          "data-component-file": "ContactForm.jsx",
          "data-component-name": "button",
          "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22submit%22%2C%22className%22%3A%22bg-primary%20text-white%20px-4%20py-2%20rounded-lg%20hover%3Abg-primary-600%20transition-colors%20duration-150%20ease-smooth%20flex%20items-center%20space-x-2%22%7D",
          type: "submit",
          disabled: loading,
          className: "bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary-600 transition-colors duration-150 ease-smooth flex items-center space-x-2",
          children: [
            loading && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:448:22", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "448", "data-component-file": "ContactForm.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22animate-spin%20rounded-full%20h-4%20w-4%20border-b-2%20border-white%22%7D", className: "animate-spin rounded-full h-4 w-4 border-b-2 border-white" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
              lineNumber: 448,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\ContactForm.jsx:449:10", "data-component-path": "src\\pages\\contact-management\\components\\ContactForm.jsx", "data-component-line": "449", "data-component-file": "ContactForm.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: contact ? "Update Contact" : "Create Contact" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
              lineNumber: 449,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
          lineNumber: 443,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
      lineNumber: 434,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx",
    lineNumber: 169,
    columnNumber: 5
  }, this);
};
_s(ContactForm, "N/ZziV0v2IRalS7g7zUPW5y433Y=", false, function() {
  return [useAuth];
});
_c = ContactForm;
export default ContactForm;
var _c;
$RefreshReg$(_c, "ContactForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/contact-management/components/ContactForm.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEtVOzJCQTVLVjtBQUFnQkEsTUFBVUMsY0FBUyxPQUFRLHNCQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ2xELE9BQU9DLFVBQVU7QUFDakIsU0FBU0MsZUFBZTtBQUN4QixPQUFPQyxxQkFBcUI7QUFDNUIsT0FBT0Msc0JBQXNCO0FBRTdCLE1BQU1DLGNBQWNBLENBQUMsRUFBRUMsVUFBVSxNQUFNQyxVQUFVQyxTQUFTLE1BQU07QUFBQUMsS0FBQTtBQUM5RCxRQUFNLEVBQUVDLEtBQUssSUFBSVIsUUFBUTtBQUN6QixRQUFNLENBQUNTLFNBQVNDLFVBQVUsSUFBSWIsU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQ2MsV0FBV0MsWUFBWSxJQUFJZixTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDZ0IsVUFBVUMsV0FBVyxJQUFJakIsU0FBUztBQUFBLElBQ3ZDa0IsWUFBWTtBQUFBLElBQ1pDLFdBQVc7QUFBQSxJQUNYQyxPQUFPO0FBQUEsSUFDUEMsT0FBTztBQUFBLElBQ1BDLFFBQVE7QUFBQSxJQUNSQyxVQUFVO0FBQUEsSUFDVkMsWUFBWTtBQUFBLElBQ1pDLFlBQVk7QUFBQSxJQUNaQyxhQUFhO0FBQUE7QUFBQSxJQUNiQyxRQUFRO0FBQUEsSUFDUkMsYUFBYTtBQUFBLElBQ2JDLE9BQU87QUFBQSxJQUNQQyxNQUFNO0FBQUEsSUFDTkMsY0FBYztBQUFBLElBQ2RDLGFBQWE7QUFBQSxJQUNiQyxVQUFVdEIsTUFBTXVCLE1BQU07QUFBQSxFQUN4QixDQUFDO0FBQ0QsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUlwQyxTQUFTLENBQUMsQ0FBQztBQUN2QyxRQUFNLENBQUNxQyxRQUFRQyxTQUFTLElBQUl0QyxTQUFTLEVBQUU7QUFHdkNDLFlBQVUsTUFBTTtBQUNkc0Msa0JBQWM7QUFFZCxRQUFJaEMsU0FBUztBQUNYVSxrQkFBWTtBQUFBLFFBQ1ZDLFlBQVlYLFNBQVNXLGNBQWM7QUFBQSxRQUNuQ0MsV0FBV1osU0FBU1ksYUFBYTtBQUFBLFFBQ2pDQyxPQUFPYixTQUFTYSxTQUFTO0FBQUEsUUFDekJDLE9BQU9kLFNBQVNjLFNBQVM7QUFBQSxRQUN6QkMsUUFBUWYsU0FBU2UsVUFBVTtBQUFBLFFBQzNCQyxVQUFVaEIsU0FBU2dCLFlBQVk7QUFBQSxRQUMvQkMsWUFBWWpCLFNBQVNpQixjQUFjO0FBQUEsUUFDbkNDLFlBQVlsQixTQUFTa0IsY0FBYztBQUFBLFFBQ25DQyxhQUFhO0FBQUEsUUFDYkMsUUFBUXBCLFNBQVNvQixVQUFVO0FBQUEsUUFDM0JDLGFBQWFyQixTQUFTcUIsZUFBZTtBQUFBLFFBQ3JDQyxPQUFPdEIsU0FBU3NCLFNBQVM7QUFBQSxRQUN6QkMsTUFBTXZCLFNBQVN1QixRQUFRO0FBQUEsUUFDdkJDLGNBQWN4QixTQUFTd0IsZ0JBQWdCO0FBQUEsUUFDdkNDLGFBQWF6QixTQUFTeUIsZUFBZTtBQUFBLFFBQ3JDQyxVQUFVMUIsU0FBUzBCLFlBQVl0QixNQUFNdUIsTUFBTTtBQUFBLE1BQzdDLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRixHQUFHLENBQUMzQixTQUFTSSxJQUFJLENBQUM7QUFFbEIsUUFBTTRCLGdCQUFnQixZQUFZO0FBQ2hDLFFBQUk7QUFDRixZQUFNQyxnQkFBZ0IsTUFBTW5DLGtCQUFrQm9DLGdCQUFnQjtBQUM5RDFCLG1CQUFheUIsaUJBQWlCLEVBQUU7QUFBQSxJQUNsQyxTQUFTRSxLQUFLO0FBQ1pDLGNBQVFDLE1BQU0sNEJBQTRCRixHQUFHO0FBQzdDTixnQkFBVTtBQUFBLFFBQ1JTLFFBQVE7QUFBQSxNQUNWLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUVBLFFBQU1DLGVBQWUsT0FBT0MsTUFBTTtBQUNoQ0EsT0FBR0MsZUFBZTtBQUNsQm5DLGVBQVcsSUFBSTtBQUNmdUIsY0FBVSxDQUFDLENBQUM7QUFFWixRQUFJO0FBRUYsWUFBTWEsaUJBQWlCLENBQUMsY0FBYyxhQUFhLE9BQU87QUFDMUQsWUFBTUMsbUJBQW1CLENBQUM7QUFFMUJELHNCQUFnQkUsUUFBUSxDQUFBQyxVQUFTO0FBQy9CLFlBQUksQ0FBQ3BDLFdBQVdvQyxLQUFLLEdBQUdDLEtBQUssR0FBRztBQUM5QkgsMkJBQWlCRSxLQUFLLElBQUksR0FBR0EsT0FBT0UsUUFBUSxLQUFLLEdBQUcsQ0FBQztBQUFBLFFBQ3ZEO0FBQUEsTUFDRixDQUFDO0FBR0QsVUFBSXRDLFVBQVVJLFNBQVMsQ0FBQyxnQkFBZ0JtQyxLQUFLdkMsVUFBVUksS0FBSyxHQUFHO0FBQzdEOEIseUJBQWlCOUIsUUFBUTtBQUFBLE1BQzNCO0FBRUEsVUFBSW9DLE9BQU9DLEtBQUtQLGdCQUFnQixHQUFHUSxTQUFTLEdBQUc7QUFDN0N0QixrQkFBVWMsZ0JBQWdCO0FBQzFCckMsbUJBQVcsS0FBSztBQUNoQjtBQUFBLE1BQ0Y7QUFHQSxZQUFNLEVBQUVhLGFBQWEsR0FBR2lDLFdBQVcsSUFBSTNDO0FBRXZDLFVBQUk0QztBQUNKLFVBQUlyRCxTQUFTO0FBRVhxRCxpQkFBUyxNQUFNeEQsaUJBQWlCeUQsY0FBY3RELFNBQVMyQixJQUFJeUIsVUFBVTtBQUFBLE1BQ3ZFLE9BQU87QUFFTEMsaUJBQVMsTUFBTXhELGlCQUFpQjBELGNBQWM5QyxRQUFRO0FBQUEsTUFDeEQ7QUFFQVIsaUJBQVdvRCxNQUFNO0FBQUEsSUFDbkIsU0FBU2xCLEtBQUs7QUFDWkMsY0FBUUMsTUFBTSx5QkFBeUJGLEdBQUc7QUFDMUNOLGdCQUFVO0FBQUEsUUFDUlMsUUFBUUgsS0FBS3FCLFdBQVc7QUFBQSxNQUMxQixDQUFDO0FBQUEsSUFDSCxVQUFDO0FBQ0NsRCxpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBRUEsUUFBTW1ELG9CQUFvQkEsQ0FBQ1osT0FBT2EsVUFBVTtBQUMxQ2hELGdCQUFZLENBQUFpRCxVQUFTLEVBQUUsR0FBR0EsTUFBTSxDQUFDZCxLQUFLLEdBQUdhLE1BQU0sRUFBRTtBQUdqRCxRQUFJOUIsU0FBU2lCLEtBQUssR0FBRztBQUNuQmhCLGdCQUFVLENBQUE4QixTQUFRO0FBQ2hCLGNBQU1DLFlBQVksRUFBRSxHQUFHRCxLQUFLO0FBQzVCLGVBQU9DLFlBQVlmLEtBQUs7QUFDeEIsZUFBT2U7QUFBQUEsTUFDVCxDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFFQSxRQUFNQyxTQUFTQSxNQUFNO0FBQ25CLFFBQUkvQixRQUFRZ0IsS0FBSyxLQUFLLENBQUNyQyxVQUFVYyxNQUFNdUMsU0FBU2hDLFFBQVFnQixLQUFLLENBQUMsR0FBRztBQUMvRHBDLGtCQUFZLENBQUFpRCxVQUFTO0FBQUEsUUFDbkIsR0FBR0E7QUFBQUEsUUFDSHBDLE1BQU0sQ0FBQyxHQUFJb0MsTUFBTXBDLFFBQVEsSUFBS08sUUFBUWdCLEtBQUssQ0FBQztBQUFBLE1BQzlDLEVBQUU7QUFDRmYsZ0JBQVUsRUFBRTtBQUFBLElBQ2Q7QUFBQSxFQUNGO0FBRUEsUUFBTWdDLFlBQVlBLENBQUNDLGdCQUFnQjtBQUNqQ3RELGdCQUFZLENBQUFpRCxVQUFTO0FBQUEsTUFDbkIsR0FBR0E7QUFBQUEsTUFDSHBDLE1BQU1vQyxNQUFNcEMsTUFBTTBDLE9BQU8sQ0FBQUMsUUFBT0EsUUFBUUYsV0FBVyxLQUFLO0FBQUEsSUFDMUQsRUFBRTtBQUFBLEVBQ0o7QUFFQSxRQUFNRyxjQUFjO0FBQUEsSUFDbEIsRUFBRVQsT0FBTyxXQUFXVSxPQUFPLFVBQVU7QUFBQSxJQUNyQyxFQUFFVixPQUFPLFlBQVlVLE9BQU8sV0FBVztBQUFBLElBQ3ZDLEVBQUVWLE9BQU8sYUFBYVUsT0FBTyxZQUFZO0FBQUEsSUFDekMsRUFBRVYsT0FBTyxrQkFBa0JVLE9BQU8saUJBQWlCO0FBQUEsSUFDbkQsRUFBRVYsT0FBTyxnQkFBZ0JVLE9BQU8sZUFBZTtBQUFBLElBQy9DLEVBQUVWLE9BQU8sU0FBU1UsT0FBTyxRQUFRO0FBQUEsSUFDakMsRUFBRVYsT0FBTyxXQUFXVSxPQUFPLFVBQVU7QUFBQSxJQUNyQyxFQUFFVixPQUFPLFNBQVNVLE9BQU8sUUFBUTtBQUFBLEVBQUM7QUFHcEMsUUFBTUMsa0JBQWtCO0FBQUEsSUFDdEIsRUFBRVgsT0FBTyxZQUFZVSxPQUFPLFdBQVc7QUFBQSxJQUN2QyxFQUFFVixPQUFPLFVBQVVVLE9BQU8sU0FBUztBQUFBLElBQ25DLEVBQUVWLE9BQU8sWUFBWVUsT0FBTyxXQUFXO0FBQUEsSUFDdkMsRUFBRVYsT0FBTyxZQUFZVSxPQUFPLFdBQVc7QUFBQSxFQUFDO0FBRzFDLFNBQ0UsdUJBQUMsdVlBQUssVUFBVTdCLGNBQWMsV0FBVSxhQUVyQ1g7QUFBQUEsWUFBUVUsVUFDUCx1QkFBQyxvZUFBSSxXQUFVLDZGQUNiO0FBQUEsNkJBQUMsbVlBQUssTUFBSyxlQUFjLE1BQU0sTUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrQztBQUFBLE1BQ2xDLHVCQUFDLG9XQUFNVixrQkFBUVUsVUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNCO0FBQUEsU0FGeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFJRix1QkFBQyx3YUFBSSxXQUFVLHlDQUNiO0FBQUEsNkJBQUMsZ1dBQ0M7QUFBQSwrQkFBQyx1ZUFBTSxXQUFVLG9EQUFtRCw0QkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsT0FBTzdCLFVBQVVFO0FBQUFBLFlBQ2pCLFVBQVUsQ0FBQzZCLE1BQU1pQixrQkFBa0IsY0FBY2pCLEdBQUc4QixRQUFRWixLQUFLO0FBQUEsWUFDakUsV0FBVyw4RUFDVDlCLFFBQVFqQixhQUFhLGlCQUFpQixlQUFlO0FBQUEsWUFFdkQsYUFBWTtBQUFBLFlBQ1osVUFBUTtBQUFBO0FBQUEsVUFSVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFRVTtBQUFBLFFBRVRpQixRQUFRakIsY0FDUCx1QkFBQyxpWkFBRSxXQUFVLDJCQUEyQmlCLGtCQUFRakIsY0FBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRDtBQUFBLFdBZi9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpQkE7QUFBQSxNQUVBLHVCQUFDLGdXQUNDO0FBQUEsK0JBQUMsc2VBQU0sV0FBVSxvREFBbUQsMkJBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLE9BQU9GLFVBQVVHO0FBQUFBLFlBQ2pCLFVBQVUsQ0FBQzRCLE1BQU1pQixrQkFBa0IsYUFBYWpCLEdBQUc4QixRQUFRWixLQUFLO0FBQUEsWUFDaEUsV0FBVyw4RUFDVDlCLFFBQVFoQixZQUFZLGlCQUFpQixlQUFlO0FBQUEsWUFFdEQsYUFBWTtBQUFBLFlBQ1osVUFBUTtBQUFBO0FBQUEsVUFSVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFRVTtBQUFBLFFBRVRnQixRQUFRaEIsYUFDUCx1QkFBQyxpWkFBRSxXQUFVLDJCQUEyQmdCLGtCQUFRaEIsYUFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRDtBQUFBLFdBZjlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpQkE7QUFBQSxTQXJDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0NBO0FBQUEsSUFHQSx1QkFBQyx3YUFBSSxXQUFVLHlDQUNiO0FBQUEsNkJBQUMsZ1dBQ0M7QUFBQSwrQkFBQywwZUFBTSxXQUFVLG9EQUFtRCwrQkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsT0FBT0gsVUFBVUk7QUFBQUEsWUFDakIsVUFBVSxDQUFDMkIsTUFBTWlCLGtCQUFrQixTQUFTakIsR0FBRzhCLFFBQVFaLEtBQUs7QUFBQSxZQUM1RCxXQUFXLDhFQUNUOUIsUUFBUWYsUUFBUSxpQkFBaUIsZUFBZTtBQUFBLFlBRWxELGFBQVk7QUFBQSxZQUNaLFVBQVE7QUFBQTtBQUFBLFVBUlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBUVU7QUFBQSxRQUVUZSxRQUFRZixTQUNQLHVCQUFDLGlaQUFFLFdBQVUsMkJBQTJCZSxrQkFBUWYsU0FBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRDtBQUFBLFdBZjFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpQkE7QUFBQSxNQUVBLHVCQUFDLGdXQUNDO0FBQUEsK0JBQUMscWVBQU0sV0FBVSxvREFBbUQsNEJBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLE9BQU9KLFVBQVVLO0FBQUFBLFlBQ2pCLFVBQVUsQ0FBQzBCLE1BQU1pQixrQkFBa0IsU0FBU2pCLEdBQUc4QixRQUFRWixLQUFLO0FBQUEsWUFDNUQsV0FBVTtBQUFBLFlBQ1YsYUFBWTtBQUFBO0FBQUEsVUFMZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLaUM7QUFBQSxXQVRuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxTQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0NBO0FBQUEsSUFHQSx1QkFBQyx3YUFBSSxXQUFVLHlDQUNiO0FBQUEsNkJBQUMsZ1dBQ0M7QUFBQSwrQkFBQywrZEFBTSxXQUFVLG9EQUFtRCx3QkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsT0FBT2pELFVBQVVPO0FBQUFBLFlBQ2pCLFVBQVUsQ0FBQ3dCLE1BQU1pQixrQkFBa0IsWUFBWWpCLEdBQUc4QixRQUFRWixLQUFLO0FBQUEsWUFDL0QsV0FBVTtBQUFBLFlBQ1YsYUFBWTtBQUFBO0FBQUEsVUFMZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLNkI7QUFBQSxXQVQvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxNQUVBLHVCQUFDLGdXQUNDO0FBQUEsK0JBQUMsaWVBQU0sV0FBVSxvREFBbUQsMEJBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLE9BQU9qRCxVQUFVUTtBQUFBQSxZQUNqQixVQUFVLENBQUN1QixNQUFNaUIsa0JBQWtCLGNBQWNqQixHQUFHOEIsUUFBUVosS0FBSztBQUFBLFlBQ2pFLFdBQVU7QUFBQSxZQUNWLGFBQVk7QUFBQTtBQUFBLFVBTGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS3FCO0FBQUEsV0FUdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsU0F6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBCQTtBQUFBLElBR0EsdUJBQUMsZ1dBQ0M7QUFBQSw2QkFBQyw2ZEFBTSxXQUFVLG9EQUFtRCx1QkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyx3YUFBSSxXQUFVLHlDQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUNDLE9BQU9qRCxVQUFVUztBQUFBQSxZQUNqQixVQUFVLENBQUNzQixNQUFNaUIsa0JBQWtCLGNBQWNqQixHQUFHOEIsUUFBUVosS0FBSztBQUFBLFlBQ2pFLFdBQVU7QUFBQSxZQUVWO0FBQUEscUNBQUMseWJBQU8sT0FBTSxJQUFHLHVDQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3QztBQUFBLGNBQ3ZDbkQsV0FBV2dFO0FBQUFBLGdCQUFJLENBQUFDLFlBQ2QsdUJBQUMsMFdBQXlCLE9BQU9BLFNBQVM3QyxJQUN2QzZDLG1CQUFTQyxRQURDRCxTQUFTN0MsSUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGNBQ0Q7QUFBQTtBQUFBO0FBQUEsVUFWSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFXQTtBQUFBLFFBRUE7QUFBQSxVQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLE9BQU9sQixVQUFVVTtBQUFBQSxZQUNqQixVQUFVLENBQUNxQixNQUFNaUIsa0JBQWtCLGVBQWVqQixHQUFHOEIsUUFBUVosS0FBSztBQUFBLFlBQ2xFLFdBQVU7QUFBQSxZQUNWLGFBQVk7QUFBQTtBQUFBLFVBTGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS3lDO0FBQUEsV0FuQjNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQkE7QUFBQSxTQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMEJBO0FBQUEsSUFHQSx1QkFBQyx3YUFBSSxXQUFVLHlDQUNiO0FBQUEsNkJBQUMsZ1dBQ0M7QUFBQSwrQkFBQyw2ZEFBTSxXQUFVLG9EQUFtRCxzQkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBQ0MsT0FBT2pELFVBQVVXO0FBQUFBLFlBQ2pCLFVBQVUsQ0FBQ29CLE1BQU1pQixrQkFBa0IsVUFBVWpCLEdBQUc4QixRQUFRWixLQUFLO0FBQUEsWUFDN0QsV0FBVTtBQUFBLFlBRVRXLDJCQUFpQkU7QUFBQUEsY0FBSSxDQUFBbkQsV0FDcEIsdUJBQUMsMFdBQTJCLE9BQU9BLFFBQVFzQyxPQUN4Q3RDLGtCQUFRZ0QsU0FERWhELFFBQVFzQyxPQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsWUFDRDtBQUFBO0FBQUEsVUFUSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFVQTtBQUFBLFdBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWVBO0FBQUEsTUFFQSx1QkFBQyxnV0FDQztBQUFBLCtCQUFDLG9lQUFNLFdBQVUsb0RBQW1ELDJCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFDQyxPQUFPakQsVUFBVVk7QUFBQUEsWUFDakIsVUFBVSxDQUFDbUIsTUFBTWlCLGtCQUFrQixlQUFlakIsR0FBRzhCLFFBQVFaLEtBQUs7QUFBQSxZQUNsRSxXQUFVO0FBQUEsWUFFVFMsdUJBQWFJO0FBQUFBLGNBQUksQ0FBQUcsV0FDaEIsdUJBQUMsMFdBQTJCLE9BQU9BLFFBQVFoQixPQUN4Q2dCLGtCQUFRTixTQURFTSxRQUFRaEIsT0FBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLFlBQ0Q7QUFBQTtBQUFBLFVBVEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBVUE7QUFBQSxXQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFlQTtBQUFBLFNBakNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrQ0E7QUFBQSxJQUdBLHVCQUFDLGdXQUNDO0FBQUEsNkJBQUMsMGRBQU0sV0FBVSxvREFBbUQsb0JBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsMFpBQUksV0FBVSw2QkFDWmpELG9CQUFVYyxNQUFNZ0Q7QUFBQUEsUUFBSSxDQUFDTCxLQUFLUyxVQUN6QjtBQUFBLFVBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRUMsV0FBVTtBQUFBLFlBRVRUO0FBQUFBO0FBQUFBLGNBQ0Q7QUFBQSxnQkFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFNBQVMsTUFBTUgsVUFBVUcsR0FBRztBQUFBLGtCQUM1QixXQUFVO0FBQUEsa0JBRVYsaUNBQUMseVhBQUssTUFBSyxLQUFJLE1BQU0sTUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBd0I7QUFBQTtBQUFBLGdCQUwxQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNQTtBQUFBO0FBQUE7QUFBQSxVQVZLUztBQUFBQSxVQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFZQTtBQUFBLE1BQ0QsS0FmSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0JBO0FBQUEsTUFDQSx1QkFBQywyWUFBSSxXQUFVLGtCQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLE9BQU83QztBQUFBQSxZQUNQLFVBQVUsQ0FBQ1UsTUFBTVQsVUFBVVMsR0FBRzhCLFFBQVFaLEtBQUs7QUFBQSxZQUMzQyxZQUFZLENBQUNsQixNQUFNQSxHQUFHb0MsUUFBUSxZQUFZcEMsR0FBR0MsZUFBZSxHQUFHb0IsT0FBTztBQUFBLFlBQ3RFLFdBQVU7QUFBQSxZQUNWLGFBQVk7QUFBQTtBQUFBLFVBTmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTXlDO0FBQUEsUUFFekM7QUFBQSxVQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFNBQVNBO0FBQUFBLFlBQ1QsV0FBVTtBQUFBLFlBQXdHO0FBQUE7QUFBQSxVQUhwSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFdBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdCQTtBQUFBLFNBckNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzQ0E7QUFBQSxJQUdBLHVCQUFDLHdhQUFJLFdBQVUseUNBQ2I7QUFBQSw2QkFBQyxnV0FDQztBQUFBLCtCQUFDLHFlQUFNLFdBQVUsb0RBQW1ELDRCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxPQUFPcEQsVUFBVWU7QUFBQUEsWUFDakIsVUFBVSxDQUFDZ0IsTUFBTWlCLGtCQUFrQixnQkFBZ0JqQixHQUFHOEIsUUFBUVosS0FBSztBQUFBLFlBQ25FLFdBQVU7QUFBQSxZQUNWLGFBQVk7QUFBQTtBQUFBLFVBTGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSytDO0FBQUEsV0FUakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsTUFFQSx1QkFBQyxnV0FDQztBQUFBLCtCQUFDLG9lQUFNLFdBQVUsb0RBQW1ELDJCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxPQUFPakQsVUFBVWdCO0FBQUFBLFlBQ2pCLFVBQVUsQ0FBQ2UsTUFBTWlCLGtCQUFrQixlQUFlakIsR0FBRzhCLFFBQVFaLEtBQUs7QUFBQSxZQUNsRSxXQUFVO0FBQUEsWUFDVixhQUFZO0FBQUE7QUFBQSxVQUxkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUsyQztBQUFBLFdBVDdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFXQTtBQUFBLFNBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwQkE7QUFBQSxJQUdBLHVCQUFDLGdXQUNDO0FBQUEsNkJBQUMsMmRBQU0sV0FBVSxvREFBbUQscUJBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUNDLE9BQU9qRCxVQUFVYTtBQUFBQSxVQUNqQixVQUFVLENBQUNrQixNQUFNaUIsa0JBQWtCLFNBQVNqQixHQUFHOEIsUUFBUVosS0FBSztBQUFBLFVBQzVELE1BQU07QUFBQSxVQUNOLFdBQVU7QUFBQSxVQUNWLGFBQVk7QUFBQTtBQUFBLFFBTGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS3NEO0FBQUEsU0FUeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdBO0FBQUEsSUFHQSx1QkFBQywyYkFBSSxXQUFVLDBEQUNiO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFNBQVN4RDtBQUFBQSxVQUNULFdBQVU7QUFBQSxVQUNWLFVBQVVHO0FBQUFBLFVBQVE7QUFBQTtBQUFBLFFBSnBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9BO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsVUFBVUE7QUFBQUEsVUFDVixXQUFVO0FBQUEsVUFFVEE7QUFBQUEsdUJBQVcsdUJBQUMsK2JBQUksV0FBVSwrREFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyRTtBQUFBLFlBQ3ZGLHVCQUFDLG9XQUFNTCxvQkFBVSxtQkFBbUIsb0JBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFEO0FBQUE7QUFBQTtBQUFBLFFBTnZEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9BO0FBQUEsU0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCQTtBQUFBLE9BMVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EyUkE7QUFFSjtBQUFFRyxHQS9iSUosYUFBVztBQUFBLFVBQ0VILE9BQU87QUFBQTtBQUFBaUYsS0FEcEI5RTtBQWljTixlQUFlQTtBQUFZLElBQUE4RTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJJY29uIiwidXNlQXV0aCIsImNvbnRhY3RzU2VydmljZSIsImNvbXBhbmllc1NlcnZpY2UiLCJDb250YWN0Rm9ybSIsImNvbnRhY3QiLCJvblN1Ym1pdCIsIm9uQ2FuY2VsIiwiX3MiLCJ1c2VyIiwibG9hZGluZyIsInNldExvYWRpbmciLCJjb21wYW5pZXMiLCJzZXRDb21wYW5pZXMiLCJmb3JtRGF0YSIsInNldEZvcm1EYXRhIiwiZmlyc3RfbmFtZSIsImxhc3RfbmFtZSIsImVtYWlsIiwicGhvbmUiLCJtb2JpbGUiLCJwb3NpdGlvbiIsImRlcGFydG1lbnQiLCJjb21wYW55X2lkIiwiY29tcGFueU5hbWUiLCJzdGF0dXMiLCJsZWFkX3NvdXJjZSIsIm5vdGVzIiwidGFncyIsImxpbmtlZGluX3VybCIsInR3aXR0ZXJfdXJsIiwib3duZXJfaWQiLCJpZCIsImVycm9ycyIsInNldEVycm9ycyIsIm5ld1RhZyIsInNldE5ld1RhZyIsImxvYWRDb21wYW5pZXMiLCJjb21wYW5pZXNEYXRhIiwiZ2V0QWxsQ29tcGFuaWVzIiwiZXJyIiwiY29uc29sZSIsImVycm9yIiwic3VibWl0IiwiaGFuZGxlU3VibWl0IiwiZSIsInByZXZlbnREZWZhdWx0IiwicmVxdWlyZWRGaWVsZHMiLCJ2YWxpZGF0aW9uRXJyb3JzIiwiZm9yRWFjaCIsImZpZWxkIiwidHJpbSIsInJlcGxhY2UiLCJ0ZXN0IiwiT2JqZWN0Iiwia2V5cyIsImxlbmd0aCIsInN1Ym1pdERhdGEiLCJyZXN1bHQiLCJ1cGRhdGVDb250YWN0IiwiY3JlYXRlQ29udGFjdCIsIm1lc3NhZ2UiLCJoYW5kbGVJbnB1dENoYW5nZSIsInZhbHVlIiwicHJldiIsIm5ld0Vycm9ycyIsImFkZFRhZyIsImluY2x1ZGVzIiwicmVtb3ZlVGFnIiwidGFnVG9SZW1vdmUiLCJmaWx0ZXIiLCJ0YWciLCJsZWFkU291cmNlcyIsImxhYmVsIiwiY29udGFjdFN0YXR1c2VzIiwidGFyZ2V0IiwibWFwIiwiY29tcGFueSIsIm5hbWUiLCJzb3VyY2UiLCJpbmRleCIsImtleSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ29udGFjdEZvcm0uanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgSWNvbiBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL0FwcEljb24nO1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vLi4vLi4vY29udGV4dHMvQXV0aENvbnRleHQnO1xyXG5pbXBvcnQgY29udGFjdHNTZXJ2aWNlIGZyb20gJy4uLy4uLy4uL3NlcnZpY2VzL2NvbnRhY3RzU2VydmljZSc7XHJcbmltcG9ydCBjb21wYW5pZXNTZXJ2aWNlIGZyb20gJy4uLy4uLy4uL3NlcnZpY2VzL2NvbXBhbmllc1NlcnZpY2UnO1xyXG5cclxuY29uc3QgQ29udGFjdEZvcm0gPSAoeyBjb250YWN0ID0gbnVsbCwgb25TdWJtaXQsIG9uQ2FuY2VsIH0pID0+IHtcclxuICBjb25zdCB7IHVzZXIgfSA9IHVzZUF1dGgoKTtcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2NvbXBhbmllcywgc2V0Q29tcGFuaWVzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIGZpcnN0X25hbWU6ICcnLFxyXG4gICAgbGFzdF9uYW1lOiAnJyxcclxuICAgIGVtYWlsOiAnJyxcclxuICAgIHBob25lOiAnJyxcclxuICAgIG1vYmlsZTogJycsXHJcbiAgICBwb3NpdGlvbjogJycsXHJcbiAgICBkZXBhcnRtZW50OiAnJyxcclxuICAgIGNvbXBhbnlfaWQ6ICcnLFxyXG4gICAgY29tcGFueU5hbWU6ICcnLCAvLyBLZWVwIGZvciBuZXcgY29tcGFueSBjcmVhdGlvblxyXG4gICAgc3RhdHVzOiAncHJvc3BlY3QnLFxyXG4gICAgbGVhZF9zb3VyY2U6ICd3ZWJzaXRlJyxcclxuICAgIG5vdGVzOiAnJyxcclxuICAgIHRhZ3M6IFtdLFxyXG4gICAgbGlua2VkaW5fdXJsOiAnJyxcclxuICAgIHR3aXR0ZXJfdXJsOiAnJyxcclxuICAgIG93bmVyX2lkOiB1c2VyPy5pZCB8fCAnJ1xyXG4gIH0pO1xyXG4gIGNvbnN0IFtlcnJvcnMsIHNldEVycm9yc10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW25ld1RhZywgc2V0TmV3VGFnXSA9IHVzZVN0YXRlKCcnKTtcclxuXHJcbiAgLy8gTG9hZCBjb21wYW5pZXMgYW5kIHBvcHVsYXRlIGZvcm1cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgbG9hZENvbXBhbmllcygpO1xyXG4gICAgXHJcbiAgICBpZiAoY29udGFjdCkge1xyXG4gICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgZmlyc3RfbmFtZTogY29udGFjdD8uZmlyc3RfbmFtZSB8fCAnJyxcclxuICAgICAgICBsYXN0X25hbWU6IGNvbnRhY3Q/Lmxhc3RfbmFtZSB8fCAnJyxcclxuICAgICAgICBlbWFpbDogY29udGFjdD8uZW1haWwgfHwgJycsXHJcbiAgICAgICAgcGhvbmU6IGNvbnRhY3Q/LnBob25lIHx8ICcnLFxyXG4gICAgICAgIG1vYmlsZTogY29udGFjdD8ubW9iaWxlIHx8ICcnLFxyXG4gICAgICAgIHBvc2l0aW9uOiBjb250YWN0Py5wb3NpdGlvbiB8fCAnJyxcclxuICAgICAgICBkZXBhcnRtZW50OiBjb250YWN0Py5kZXBhcnRtZW50IHx8ICcnLFxyXG4gICAgICAgIGNvbXBhbnlfaWQ6IGNvbnRhY3Q/LmNvbXBhbnlfaWQgfHwgJycsXHJcbiAgICAgICAgY29tcGFueU5hbWU6ICcnLFxyXG4gICAgICAgIHN0YXR1czogY29udGFjdD8uc3RhdHVzIHx8ICdwcm9zcGVjdCcsXHJcbiAgICAgICAgbGVhZF9zb3VyY2U6IGNvbnRhY3Q/LmxlYWRfc291cmNlIHx8ICd3ZWJzaXRlJyxcclxuICAgICAgICBub3RlczogY29udGFjdD8ubm90ZXMgfHwgJycsXHJcbiAgICAgICAgdGFnczogY29udGFjdD8udGFncyB8fCBbXSxcclxuICAgICAgICBsaW5rZWRpbl91cmw6IGNvbnRhY3Q/LmxpbmtlZGluX3VybCB8fCAnJyxcclxuICAgICAgICB0d2l0dGVyX3VybDogY29udGFjdD8udHdpdHRlcl91cmwgfHwgJycsXHJcbiAgICAgICAgb3duZXJfaWQ6IGNvbnRhY3Q/Lm93bmVyX2lkIHx8IHVzZXI/LmlkIHx8ICcnXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH0sIFtjb250YWN0LCB1c2VyXSk7XHJcblxyXG4gIGNvbnN0IGxvYWRDb21wYW5pZXMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBjb21wYW5pZXNEYXRhID0gYXdhaXQgY29tcGFuaWVzU2VydmljZT8uZ2V0QWxsQ29tcGFuaWVzKCk7XHJcbiAgICAgIHNldENvbXBhbmllcyhjb21wYW5pZXNEYXRhIHx8IFtdKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBsb2FkaW5nIGNvbXBhbmllczonLCBlcnIpO1xyXG4gICAgICBzZXRFcnJvcnMoeyBcclxuICAgICAgICBzdWJtaXQ6ICdGYWlsZWQgdG8gbG9hZCBjb21wYW5pZXMuIFBsZWFzZSB0cnkgcmVmcmVzaGluZyB0aGUgcGFnZS4nIFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZT8ucHJldmVudERlZmF1bHQoKTtcclxuICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcbiAgICBzZXRFcnJvcnMoe30pO1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIC8vIFZhbGlkYXRlIHJlcXVpcmVkIGZpZWxkc1xyXG4gICAgICBjb25zdCByZXF1aXJlZEZpZWxkcyA9IFsnZmlyc3RfbmFtZScsICdsYXN0X25hbWUnLCAnZW1haWwnXTtcclxuICAgICAgY29uc3QgdmFsaWRhdGlvbkVycm9ycyA9IHt9O1xyXG4gICAgICBcclxuICAgICAgcmVxdWlyZWRGaWVsZHM/LmZvckVhY2goZmllbGQgPT4ge1xyXG4gICAgICAgIGlmICghZm9ybURhdGE/LltmaWVsZF0/LnRyaW0oKSkge1xyXG4gICAgICAgICAgdmFsaWRhdGlvbkVycm9yc1tmaWVsZF0gPSBgJHtmaWVsZD8ucmVwbGFjZSgnXycsICcgJyl9IGlzIHJlcXVpcmVkYDtcclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgLy8gRW1haWwgdmFsaWRhdGlvblxyXG4gICAgICBpZiAoZm9ybURhdGE/LmVtYWlsICYmICEvXFxTK0BcXFMrXFwuXFxTKy8/LnRlc3QoZm9ybURhdGE/LmVtYWlsKSkge1xyXG4gICAgICAgIHZhbGlkYXRpb25FcnJvcnMuZW1haWwgPSAnUGxlYXNlIGVudGVyIGEgdmFsaWQgZW1haWwgYWRkcmVzcyc7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmIChPYmplY3Qua2V5cyh2YWxpZGF0aW9uRXJyb3JzKT8ubGVuZ3RoID4gMCkge1xyXG4gICAgICAgIHNldEVycm9ycyh2YWxpZGF0aW9uRXJyb3JzKTtcclxuICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgICByZXR1cm47XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIFByZXBhcmUgZGF0YSBmb3Igc3VibWlzc2lvbiAtIHJlbW92ZSBjb21wYW55TmFtZSBmcm9tIHRoZSBwYXlsb2FkXHJcbiAgICAgIGNvbnN0IHsgY29tcGFueU5hbWUsIC4uLnN1Ym1pdERhdGEgfSA9IGZvcm1EYXRhO1xyXG5cclxuICAgICAgbGV0IHJlc3VsdDtcclxuICAgICAgaWYgKGNvbnRhY3QpIHtcclxuICAgICAgICAvLyBVcGRhdGUgZXhpc3RpbmcgY29udGFjdFxyXG4gICAgICAgIHJlc3VsdCA9IGF3YWl0IGNvbnRhY3RzU2VydmljZT8udXBkYXRlQ29udGFjdChjb250YWN0Py5pZCwgc3VibWl0RGF0YSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgLy8gQ3JlYXRlIG5ldyBjb250YWN0IC0gaW5jbHVkZSBjb21wYW55TmFtZSBmb3Igc2VydmljZSB0byBoYW5kbGVcclxuICAgICAgICByZXN1bHQgPSBhd2FpdCBjb250YWN0c1NlcnZpY2U/LmNyZWF0ZUNvbnRhY3QoZm9ybURhdGEpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBvblN1Ym1pdD8uKHJlc3VsdCk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignRXJyb3Igc2F2aW5nIGNvbnRhY3Q6JywgZXJyKTtcclxuICAgICAgc2V0RXJyb3JzKHsgXHJcbiAgICAgICAgc3VibWl0OiBlcnI/Lm1lc3NhZ2UgfHwgJ0ZhaWxlZCB0byBzYXZlIGNvbnRhY3QuIFBsZWFzZSB0cnkgYWdhaW4uJyBcclxuICAgICAgfSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVJbnB1dENoYW5nZSA9IChmaWVsZCwgdmFsdWUpID0+IHtcclxuICAgIHNldEZvcm1EYXRhKHByZXYgPT4gKHsgLi4ucHJldiwgW2ZpZWxkXTogdmFsdWUgfSkpO1xyXG4gICAgXHJcbiAgICAvLyBDbGVhciBmaWVsZCBlcnJvciB3aGVuIHVzZXIgc3RhcnRzIHR5cGluZ1xyXG4gICAgaWYgKGVycm9ycz8uW2ZpZWxkXSkge1xyXG4gICAgICBzZXRFcnJvcnMocHJldiA9PiB7XHJcbiAgICAgICAgY29uc3QgbmV3RXJyb3JzID0geyAuLi5wcmV2IH07XHJcbiAgICAgICAgZGVsZXRlIG5ld0Vycm9ycz8uW2ZpZWxkXTtcclxuICAgICAgICByZXR1cm4gbmV3RXJyb3JzO1xyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBhZGRUYWcgPSAoKSA9PiB7XHJcbiAgICBpZiAobmV3VGFnPy50cmltKCkgJiYgIWZvcm1EYXRhPy50YWdzPy5pbmNsdWRlcyhuZXdUYWc/LnRyaW0oKSkpIHtcclxuICAgICAgc2V0Rm9ybURhdGEocHJldiA9PiAoe1xyXG4gICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgdGFnczogWy4uLihwcmV2Py50YWdzIHx8IFtdKSwgbmV3VGFnPy50cmltKCldXHJcbiAgICAgIH0pKTtcclxuICAgICAgc2V0TmV3VGFnKCcnKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCByZW1vdmVUYWcgPSAodGFnVG9SZW1vdmUpID0+IHtcclxuICAgIHNldEZvcm1EYXRhKHByZXYgPT4gKHtcclxuICAgICAgLi4ucHJldixcclxuICAgICAgdGFnczogcHJldj8udGFncz8uZmlsdGVyKHRhZyA9PiB0YWcgIT09IHRhZ1RvUmVtb3ZlKSB8fCBbXVxyXG4gICAgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGxlYWRTb3VyY2VzID0gW1xyXG4gICAgeyB2YWx1ZTogJ3dlYnNpdGUnLCBsYWJlbDogJ1dlYnNpdGUnIH0sXHJcbiAgICB7IHZhbHVlOiAncmVmZXJyYWwnLCBsYWJlbDogJ1JlZmVycmFsJyB9LFxyXG4gICAgeyB2YWx1ZTogJ2NvbGRfY2FsbCcsIGxhYmVsOiAnQ29sZCBDYWxsJyB9LFxyXG4gICAgeyB2YWx1ZTogJ2VtYWlsX2NhbXBhaWduJywgbGFiZWw6ICdFbWFpbCBDYW1wYWlnbicgfSxcclxuICAgIHsgdmFsdWU6ICdzb2NpYWxfbWVkaWEnLCBsYWJlbDogJ1NvY2lhbCBNZWRpYScgfSxcclxuICAgIHsgdmFsdWU6ICdldmVudCcsIGxhYmVsOiAnRXZlbnQnIH0sXHJcbiAgICB7IHZhbHVlOiAncGFydG5lcicsIGxhYmVsOiAnUGFydG5lcicgfSxcclxuICAgIHsgdmFsdWU6ICdvdGhlcicsIGxhYmVsOiAnT3RoZXInIH1cclxuICBdO1xyXG5cclxuICBjb25zdCBjb250YWN0U3RhdHVzZXMgPSBbXHJcbiAgICB7IHZhbHVlOiAncHJvc3BlY3QnLCBsYWJlbDogJ1Byb3NwZWN0JyB9LFxyXG4gICAgeyB2YWx1ZTogJ2FjdGl2ZScsIGxhYmVsOiAnQWN0aXZlJyB9LFxyXG4gICAgeyB2YWx1ZTogJ2N1c3RvbWVyJywgbGFiZWw6ICdDdXN0b21lcicgfSxcclxuICAgIHsgdmFsdWU6ICdpbmFjdGl2ZScsIGxhYmVsOiAnSW5hY3RpdmUnIH1cclxuICBdO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XHJcbiAgICAgIHsvKiBFcnJvciBNZXNzYWdlcyAqL31cclxuICAgICAge2Vycm9ycz8uc3VibWl0ICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWVycm9yLTUwIGJvcmRlciBib3JkZXItZXJyb3ItMjAwIHRleHQtZXJyb3IgcC00IHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCI+XHJcbiAgICAgICAgICA8SWNvbiBuYW1lPVwiQWxlcnRDaXJjbGVcIiBzaXplPXsyMH0gLz5cclxuICAgICAgICAgIDxzcGFuPntlcnJvcnM/LnN1Ym1pdH08L3NwYW4+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7LyogQmFzaWMgSW5mb3JtYXRpb24gKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSBtYi0xXCI+XHJcbiAgICAgICAgICAgIEZpcnN0IE5hbWUgKlxyXG4gICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8uZmlyc3RfbmFtZX1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVJbnB1dENoYW5nZSgnZmlyc3RfbmFtZScsIGU/LnRhcmdldD8udmFsdWUpfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9e2B3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciByb3VuZGVkLWxnIGZvY3VzOnJpbmctcHJpbWFyeSBmb2N1czpib3JkZXItcHJpbWFyeSAke1xyXG4gICAgICAgICAgICAgIGVycm9ycz8uZmlyc3RfbmFtZSA/ICdib3JkZXItZXJyb3InIDogJ2JvcmRlci1ib3JkZXInXHJcbiAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkpvaG5cIlxyXG4gICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIHtlcnJvcnM/LmZpcnN0X25hbWUgJiYgKFxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZXJyb3IgbXQtMVwiPntlcnJvcnM/LmZpcnN0X25hbWV9PC9wPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IG1iLTFcIj5cclxuICAgICAgICAgICAgTGFzdCBOYW1lICpcclxuICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/Lmxhc3RfbmFtZX1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVJbnB1dENoYW5nZSgnbGFzdF9uYW1lJywgZT8udGFyZ2V0Py52YWx1ZSl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCBweC0zIHB5LTIgYm9yZGVyIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1wcmltYXJ5IGZvY3VzOmJvcmRlci1wcmltYXJ5ICR7XHJcbiAgICAgICAgICAgICAgZXJyb3JzPy5sYXN0X25hbWUgPyAnYm9yZGVyLWVycm9yJyA6ICdib3JkZXItYm9yZGVyJ1xyXG4gICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJEb2VcIlxyXG4gICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIHtlcnJvcnM/Lmxhc3RfbmFtZSAmJiAoXHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1lcnJvciBtdC0xXCI+e2Vycm9ycz8ubGFzdF9uYW1lfTwvcD5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIENvbnRhY3QgSW5mb3JtYXRpb24gKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSBtYi0xXCI+XHJcbiAgICAgICAgICAgIEVtYWlsIEFkZHJlc3MgKlxyXG4gICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxyXG4gICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LmVtYWlsfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUlucHV0Q2hhbmdlKCdlbWFpbCcsIGU/LnRhcmdldD8udmFsdWUpfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9e2B3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciByb3VuZGVkLWxnIGZvY3VzOnJpbmctcHJpbWFyeSBmb2N1czpib3JkZXItcHJpbWFyeSAke1xyXG4gICAgICAgICAgICAgIGVycm9ycz8uZW1haWwgPyAnYm9yZGVyLWVycm9yJyA6ICdib3JkZXItYm9yZGVyJ1xyXG4gICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJqb2huLmRvZUBjb21wYW55LmNvbVwiXHJcbiAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAge2Vycm9ycz8uZW1haWwgJiYgKFxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZXJyb3IgbXQtMVwiPntlcnJvcnM/LmVtYWlsfTwvcD5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSBtYi0xXCI+XHJcbiAgICAgICAgICAgIFBob25lIE51bWJlclxyXG4gICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICB0eXBlPVwidGVsXCJcclxuICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5waG9uZX1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVJbnB1dENoYW5nZSgncGhvbmUnLCBlPy50YXJnZXQ/LnZhbHVlKX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLWxnIGZvY3VzOnJpbmctcHJpbWFyeSBmb2N1czpib3JkZXItcHJpbWFyeVwiXHJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiKzEgKDU1NSkgMTIzLTQ1NjdcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogUHJvZmVzc2lvbmFsIEluZm9ybWF0aW9uICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItMVwiPlxyXG4gICAgICAgICAgICBQb3NpdGlvblxyXG4gICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8ucG9zaXRpb259XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlSW5wdXRDaGFuZ2UoJ3Bvc2l0aW9uJywgZT8udGFyZ2V0Py52YWx1ZSl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ib3JkZXIgcm91bmRlZC1sZyBmb2N1czpyaW5nLXByaW1hcnkgZm9jdXM6Ym9yZGVyLXByaW1hcnlcIlxyXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNhbGVzIE1hbmFnZXJcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IG1iLTFcIj5cclxuICAgICAgICAgICAgRGVwYXJ0bWVudFxyXG4gICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8uZGVwYXJ0bWVudH1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVJbnB1dENoYW5nZSgnZGVwYXJ0bWVudCcsIGU/LnRhcmdldD8udmFsdWUpfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1wcmltYXJ5IGZvY3VzOmJvcmRlci1wcmltYXJ5XCJcclxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTYWxlc1wiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBDb21wYW55ICovfVxyXG4gICAgICA8ZGl2PlxyXG4gICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IG1iLTFcIj5cclxuICAgICAgICAgIENvbXBhbnlcclxuICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LmNvbXBhbnlfaWR9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlSW5wdXRDaGFuZ2UoJ2NvbXBhbnlfaWQnLCBlPy50YXJnZXQ/LnZhbHVlKX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLWxnIGZvY3VzOnJpbmctcHJpbWFyeSBmb2N1czpib3JkZXItcHJpbWFyeVwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY3QgRXhpc3RpbmcgQ29tcGFueTwvb3B0aW9uPlxyXG4gICAgICAgICAgICB7Y29tcGFuaWVzPy5tYXAoY29tcGFueSA9PiAoXHJcbiAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2NvbXBhbnk/LmlkfSB2YWx1ZT17Y29tcGFueT8uaWR9PlxyXG4gICAgICAgICAgICAgICAge2NvbXBhbnk/Lm5hbWV9XHJcbiAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8uY29tcGFueU5hbWV9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlSW5wdXRDaGFuZ2UoJ2NvbXBhbnlOYW1lJywgZT8udGFyZ2V0Py52YWx1ZSl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ib3JkZXIgcm91bmRlZC1sZyBmb2N1czpyaW5nLXByaW1hcnkgZm9jdXM6Ym9yZGVyLXByaW1hcnlcIlxyXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk9yIGVudGVyIG5ldyBjb21wYW55IG5hbWVcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogU3RhdHVzIGFuZCBTb3VyY2UgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSBtYi0xXCI+XHJcbiAgICAgICAgICAgIFN0YXR1c1xyXG4gICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5zdGF0dXN9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlSW5wdXRDaGFuZ2UoJ3N0YXR1cycsIGU/LnRhcmdldD8udmFsdWUpfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1wcmltYXJ5IGZvY3VzOmJvcmRlci1wcmltYXJ5XCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge2NvbnRhY3RTdGF0dXNlcz8ubWFwKHN0YXR1cyA9PiAoXHJcbiAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3N0YXR1cz8udmFsdWV9IHZhbHVlPXtzdGF0dXM/LnZhbHVlfT5cclxuICAgICAgICAgICAgICAgIHtzdGF0dXM/LmxhYmVsfVxyXG4gICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItMVwiPlxyXG4gICAgICAgICAgICBMZWFkIFNvdXJjZVxyXG4gICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5sZWFkX3NvdXJjZX1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVJbnB1dENoYW5nZSgnbGVhZF9zb3VyY2UnLCBlPy50YXJnZXQ/LnZhbHVlKX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLWxnIGZvY3VzOnJpbmctcHJpbWFyeSBmb2N1czpib3JkZXItcHJpbWFyeVwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHtsZWFkU291cmNlcz8ubWFwKHNvdXJjZSA9PiAoXHJcbiAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3NvdXJjZT8udmFsdWV9IHZhbHVlPXtzb3VyY2U/LnZhbHVlfT5cclxuICAgICAgICAgICAgICAgIHtzb3VyY2U/LmxhYmVsfVxyXG4gICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBUYWdzICovfVxyXG4gICAgICA8ZGl2PlxyXG4gICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IG1iLTFcIj5cclxuICAgICAgICAgIFRhZ3NcclxuICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTIgbWItMlwiPlxyXG4gICAgICAgICAge2Zvcm1EYXRhPy50YWdzPy5tYXAoKHRhZywgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICBrZXk9e2luZGV4fVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0yIHB5LTEgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1tZWRpdW0gYmctcHJpbWFyeS0xMDAgdGV4dC1wcmltYXJ5LTgwMFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7dGFnfVxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcmVtb3ZlVGFnKHRhZyl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtbC0xIHRleHQtcHJpbWFyeS02MDAgaG92ZXI6dGV4dC1wcmltYXJ5LTgwMFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIlhcIiBzaXplPXsxMn0gLz5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHNwYWNlLXgtMlwiPlxyXG4gICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgdmFsdWU9e25ld1RhZ31cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROZXdUYWcoZT8udGFyZ2V0Py52YWx1ZSl9XHJcbiAgICAgICAgICAgIG9uS2V5UHJlc3M9eyhlKSA9PiBlPy5rZXkgPT09ICdFbnRlcicgJiYgKGU/LnByZXZlbnREZWZhdWx0KCksIGFkZFRhZygpKX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLWxnIGZvY3VzOnJpbmctcHJpbWFyeSBmb2N1czpib3JkZXItcHJpbWFyeVwiXHJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQWRkIGEgdGFnIGFuZCBwcmVzcyBFbnRlclwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgb25DbGljaz17YWRkVGFnfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTIgYmctdGV4dC1zZWNvbmRhcnkgdGV4dC13aGl0ZSByb3VuZGVkLWxnIGhvdmVyOmJnLXRleHQtcHJpbWFyeSB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTBcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBBZGRcclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBTb2NpYWwgTGlua3MgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSBtYi0xXCI+XHJcbiAgICAgICAgICAgIExpbmtlZEluIFVSTFxyXG4gICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICB0eXBlPVwidXJsXCJcclxuICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5saW5rZWRpbl91cmx9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlSW5wdXRDaGFuZ2UoJ2xpbmtlZGluX3VybCcsIGU/LnRhcmdldD8udmFsdWUpfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1wcmltYXJ5IGZvY3VzOmJvcmRlci1wcmltYXJ5XCJcclxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJodHRwczovL2xpbmtlZGluLmNvbS9pbi9qb2huZG9lXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSBtYi0xXCI+XHJcbiAgICAgICAgICAgIFR3aXR0ZXIgVVJMXHJcbiAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgIHR5cGU9XCJ1cmxcIlxyXG4gICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LnR3aXR0ZXJfdXJsfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUlucHV0Q2hhbmdlKCd0d2l0dGVyX3VybCcsIGU/LnRhcmdldD8udmFsdWUpfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1wcmltYXJ5IGZvY3VzOmJvcmRlci1wcmltYXJ5XCJcclxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJodHRwczovL3R3aXR0ZXIuY29tL2pvaG5kb2VcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogTm90ZXMgKi99XHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItMVwiPlxyXG4gICAgICAgICAgTm90ZXNcclxuICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgIDx0ZXh0YXJlYVxyXG4gICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5ub3Rlc31cclxuICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlSW5wdXRDaGFuZ2UoJ25vdGVzJywgZT8udGFyZ2V0Py52YWx1ZSl9XHJcbiAgICAgICAgICByb3dzPXs0fVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLWxnIGZvY3VzOnJpbmctcHJpbWFyeSBmb2N1czpib3JkZXItcHJpbWFyeVwiXHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFkZGl0aW9uYWwgbm90ZXMgYWJvdXQgdGhpcyBjb250YWN0Li4uXCJcclxuICAgICAgICAvPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBGb3JtIEFjdGlvbnMgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBzcGFjZS14LTMgcHQtNCBib3JkZXItdCBib3JkZXItYm9yZGVyXCI+XHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICBvbkNsaWNrPXtvbkNhbmNlbH1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LXRleHQtc2Vjb25kYXJ5IGhvdmVyOnRleHQtdGV4dC1wcmltYXJ5IHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MFwiXHJcbiAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZ31cclxuICAgICAgICA+XHJcbiAgICAgICAgICBDYW5jZWxcclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiYmctcHJpbWFyeSB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkLWxnIGhvdmVyOmJnLXByaW1hcnktNjAwIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MCBlYXNlLXNtb290aCBmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTJcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIHtsb2FkaW5nICYmIDxkaXYgY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluIHJvdW5kZWQtZnVsbCBoLTQgdy00IGJvcmRlci1iLTIgYm9yZGVyLXdoaXRlXCI+PC9kaXY+fVxyXG4gICAgICAgICAgPHNwYW4+e2NvbnRhY3QgPyAnVXBkYXRlIENvbnRhY3QnIDogJ0NyZWF0ZSBDb250YWN0J308L3NwYW4+XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9mb3JtPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDb250YWN0Rm9ybTsiXSwiZmlsZSI6IkQ6L2N1cnJlbnQgcHJvamVjdHMvY2xhdWRlLWNvZGUvc3JjL3BhZ2VzL2NvbnRhY3QtbWFuYWdlbWVudC9jb21wb25lbnRzL0NvbnRhY3RGb3JtLmpzeCJ9