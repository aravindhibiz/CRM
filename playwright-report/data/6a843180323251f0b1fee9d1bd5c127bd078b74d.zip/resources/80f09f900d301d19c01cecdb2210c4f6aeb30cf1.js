import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/contact-management/components/LogCallModal.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import Icon from "/src/components/AppIcon.jsx";
const LogCallModal = ({ contact, onClose, onLog }) => {
  _s();
  const [callData, setCallData] = useState({
    contactId: contact?.id,
    date: (/* @__PURE__ */ new Date())?.toISOString()?.slice(0, 16),
    // Format: YYYY-MM-DDThh:mm
    duration: 15,
    direction: "outbound",
    summary: "",
    outcome: "completed"
  });
  const [isLogging, setIsLogging] = useState(false);
  const handleChange = (e) => {
    const { name, value } = e?.target;
    setCallData({
      ...callData,
      [name]: value
    });
  };
  const handleSubmit = (e) => {
    e?.preventDefault();
    setIsLogging(true);
    setTimeout(() => {
      onLog({
        ...callData,
        id: Date.now(),
        type: "call"
      });
    }, 1e3);
  };
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:38:4", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "38", "data-component-file": "LogCallModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20z-1100%20overflow-y-auto%22%7D", className: "fixed inset-0 z-1100 overflow-y-auto", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:39:6", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "39", "data-component-file": "LogCallModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-center%20min-h-screen%20px-4%20pt-4%20pb-20%20text-center%20sm%3Ablock%20sm%3Ap-0%22%7D", className: "flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0", children: [
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:40:8", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "40", "data-component-file": "LogCallModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20transition-opacity%22%7D", className: "fixed inset-0 transition-opacity", "aria-hidden": "true", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:41:10", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "41", "data-component-file": "LogCallModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22absolute%20inset-0%20bg-black%20bg-opacity-50%22%7D", className: "absolute inset-0 bg-black bg-opacity-50" }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
      lineNumber: 41,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
      lineNumber: 40,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:44:8", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "44", "data-component-file": "LogCallModal.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22hidden%20sm%3Ainline-block%20sm%3Aalign-middle%20sm%3Ah-screen%22%2C%22textContent%22%3A%22%E2%80%8B%22%7D", className: "hidden sm:inline-block sm:align-middle sm:h-screen", "aria-hidden": "true", children: "​" }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
      lineNumber: 44,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:46:8", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "46", "data-component-file": "LogCallModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22inline-block%20align-bottom%20bg-surface%20rounded-lg%20text-left%20overflow-hidden%20shadow-xl%20transform%20transition-all%20sm%3Amy-8%20sm%3Aalign-middle%20sm%3Amax-w-lg%20sm%3Aw-full%22%7D", className: "inline-block align-bottom bg-surface rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full", children: /* @__PURE__ */ jsxDEV("form", { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:47:10", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "47", "data-component-file": "LogCallModal.jsx", "data-component-name": "form", "data-component-content": "%7B%22elementName%22%3A%22form%22%7D", onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:48:12", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "48", "data-component-file": "LogCallModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22px-6%20py-4%20border-b%20border-border%20flex%20justify-between%20items-center%22%7D", className: "px-6 py-4 border-b border-border flex justify-between items-center", children: [
        /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:49:14", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "49", "data-component-file": "LogCallModal.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%2C%22textContent%22%3A%22Log%20Call%22%7D", className: "text-lg font-semibold text-text-primary", children: "Log Call" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
          lineNumber: 49,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:50:14",
            "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx",
            "data-component-line": "50",
            "data-component-file": "LogCallModal.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22button%22%2C%22className%22%3A%22text-text-secondary%20hover%3Atext-text-primary%22%7D",
            type: "button",
            onClick: onClose,
            className: "text-text-secondary hover:text-text-primary",
            children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:55:16", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "55", "data-component-file": "LogCallModal.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22X%22%7D", name: "X", size: 20 }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
              lineNumber: 55,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
            lineNumber: 50,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
        lineNumber: 48,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:59:12", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "59", "data-component-file": "LogCallModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22px-6%20py-5%22%7D", className: "px-6 py-5", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:60:14", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "60", "data-component-file": "LogCallModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-4%22%7D", className: "space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:61:16", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "61", "data-component-file": "LogCallModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:62:18", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "62", "data-component-file": "LogCallModal.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-secondary%20mb-1%22%2C%22textContent%22%3A%22Contact%22%7D", className: "block text-sm font-medium text-text-secondary mb-1", children: "Contact" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
            lineNumber: 62,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:65:18",
              "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx",
              "data-component-line": "65",
              "data-component-file": "LogCallModal.jsx",
              "data-component-name": "input",
              "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22text%22%2C%22className%22%3A%22input-field%22%7D",
              type: "text",
              value: `${contact?.firstName} ${contact?.lastName}`,
              className: "input-field",
              readOnly: true
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
              lineNumber: 65,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
          lineNumber: 61,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:73:16", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "73", "data-component-file": "LogCallModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20md%3Agrid-cols-2%20gap-4%22%7D", className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:74:18", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "74", "data-component-file": "LogCallModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:75:20", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "75", "data-component-file": "LogCallModal.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-secondary%20mb-1%22%2C%22textContent%22%3A%22Date%20%26%20Time%22%7D", htmlFor: "date", className: "block text-sm font-medium text-text-secondary mb-1", children: "Date & Time" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
              lineNumber: 75,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:78:20",
                "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx",
                "data-component-line": "78",
                "data-component-file": "LogCallModal.jsx",
                "data-component-name": "input",
                "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22datetime-local%22%2C%22id%22%3A%22date%22%2C%22name%22%3A%22date%22%2C%22className%22%3A%22input-field%22%7D",
                type: "datetime-local",
                id: "date",
                name: "date",
                value: callData?.date,
                onChange: handleChange,
                className: "input-field",
                required: true
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
                lineNumber: 78,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
            lineNumber: 74,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:89:18", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "89", "data-component-file": "LogCallModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
            /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:90:20", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "90", "data-component-file": "LogCallModal.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-secondary%20mb-1%22%2C%22textContent%22%3A%22Duration%20(minutes)%22%7D", htmlFor: "duration", className: "block text-sm font-medium text-text-secondary mb-1", children: "Duration (minutes)" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
              lineNumber: 90,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:93:20",
                "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx",
                "data-component-line": "93",
                "data-component-file": "LogCallModal.jsx",
                "data-component-name": "input",
                "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22number%22%2C%22id%22%3A%22duration%22%2C%22name%22%3A%22duration%22%2C%22className%22%3A%22input-field%22%7D",
                type: "number",
                id: "duration",
                name: "duration",
                value: callData?.duration,
                onChange: handleChange,
                min: "1",
                max: "240",
                className: "input-field",
                required: true
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
                lineNumber: 93,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
            lineNumber: 89,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
          lineNumber: 73,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:107:16", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "107", "data-component-file": "LogCallModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:108:18", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "108", "data-component-file": "LogCallModal.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-secondary%20mb-1%22%2C%22textContent%22%3A%22Call%20Direction%22%7D", htmlFor: "direction", className: "block text-sm font-medium text-text-secondary mb-1", children: "Call Direction" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
            lineNumber: 108,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:111:18",
              "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx",
              "data-component-line": "111",
              "data-component-file": "LogCallModal.jsx",
              "data-component-name": "select",
              "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22id%22%3A%22direction%22%2C%22name%22%3A%22direction%22%2C%22className%22%3A%22input-field%22%7D",
              id: "direction",
              name: "direction",
              value: callData?.direction,
              onChange: handleChange,
              className: "input-field",
              required: true,
              children: [
                /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:119:20", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "119", "data-component-file": "LogCallModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22outbound%22%2C%22textContent%22%3A%22Outbound%22%7D", value: "outbound", children: "Outbound" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
                  lineNumber: 119,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:120:20", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "120", "data-component-file": "LogCallModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22inbound%22%2C%22textContent%22%3A%22Inbound%22%7D", value: "inbound", children: "Inbound" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
                  lineNumber: 120,
                  columnNumber: 21
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
              lineNumber: 111,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
          lineNumber: 107,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:124:16", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "124", "data-component-file": "LogCallModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:125:18", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "125", "data-component-file": "LogCallModal.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-secondary%20mb-1%22%2C%22textContent%22%3A%22Call%20Outcome%22%7D", htmlFor: "outcome", className: "block text-sm font-medium text-text-secondary mb-1", children: "Call Outcome" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
            lineNumber: 125,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:128:18",
              "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx",
              "data-component-line": "128",
              "data-component-file": "LogCallModal.jsx",
              "data-component-name": "select",
              "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22id%22%3A%22outcome%22%2C%22name%22%3A%22outcome%22%2C%22className%22%3A%22input-field%22%7D",
              id: "outcome",
              name: "outcome",
              value: callData?.outcome,
              onChange: handleChange,
              className: "input-field",
              required: true,
              children: [
                /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:136:20", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "136", "data-component-file": "LogCallModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22completed%22%2C%22textContent%22%3A%22Completed%22%7D", value: "completed", children: "Completed" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
                  lineNumber: 136,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:137:20", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "137", "data-component-file": "LogCallModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22left-voicemail%22%2C%22textContent%22%3A%22Left%20Voicemail%22%7D", value: "left-voicemail", children: "Left Voicemail" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
                  lineNumber: 137,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:138:20", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "138", "data-component-file": "LogCallModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22no-answer%22%2C%22textContent%22%3A%22No%20Answer%22%7D", value: "no-answer", children: "No Answer" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
                  lineNumber: 138,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:139:20", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "139", "data-component-file": "LogCallModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22busy%22%2C%22textContent%22%3A%22Busy%22%7D", value: "busy", children: "Busy" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
                  lineNumber: 139,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:140:20", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "140", "data-component-file": "LogCallModal.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%22wrong-number%22%2C%22textContent%22%3A%22Wrong%20Number%22%7D", value: "wrong-number", children: "Wrong Number" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
                  lineNumber: 140,
                  columnNumber: 21
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
              lineNumber: 128,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
          lineNumber: 124,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:144:16", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "144", "data-component-file": "LogCallModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:145:18", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "145", "data-component-file": "LogCallModal.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-secondary%20mb-1%22%2C%22textContent%22%3A%22Call%20Summary%22%7D", htmlFor: "summary", className: "block text-sm font-medium text-text-secondary mb-1", children: "Call Summary" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
            lineNumber: 145,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            "textarea",
            {
              "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:148:18",
              "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx",
              "data-component-line": "148",
              "data-component-file": "LogCallModal.jsx",
              "data-component-name": "textarea",
              "data-component-content": "%7B%22elementName%22%3A%22textarea%22%2C%22id%22%3A%22summary%22%2C%22name%22%3A%22summary%22%2C%22className%22%3A%22input-field%22%7D",
              id: "summary",
              name: "summary",
              value: callData?.summary,
              onChange: handleChange,
              rows: 4,
              placeholder: "Enter call notes and summary...",
              className: "input-field",
              required: true
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
              lineNumber: 148,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
          lineNumber: 144,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
        lineNumber: 60,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
        lineNumber: 59,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:162:12", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "162", "data-component-file": "LogCallModal.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22px-6%20py-4%20border-t%20border-border%20flex%20justify-end%20space-x-3%22%7D", className: "px-6 py-4 border-t border-border flex justify-end space-x-3", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:163:14",
            "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx",
            "data-component-line": "163",
            "data-component-file": "LogCallModal.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22button%22%2C%22className%22%3A%22px-4%20py-2%20border%20border-border%20rounded-lg%20text-text-secondary%20hover%3Atext-text-primary%20hover%3Abg-surface-hover%20transition-all%20duration-150%20ease-out%22%2C%22textContent%22%3A%22Cancel%22%7D",
            type: "button",
            onClick: onClose,
            className: "px-4 py-2 border border-border rounded-lg text-text-secondary hover:text-text-primary hover:bg-surface-hover transition-all duration-150 ease-out",
            children: "Cancel"
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
            lineNumber: 163,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:170:14",
            "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx",
            "data-component-line": "170",
            "data-component-file": "LogCallModal.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22submit%22%7D",
            type: "submit",
            disabled: isLogging,
            className: `btn-primary inline-flex items-center ${isLogging ? "opacity-50 cursor-not-allowed" : ""}`,
            children: isLogging ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:179:20", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "179", "data-component-file": "LogCallModal.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Loader%22%2C%22className%22%3A%22animate-spin%20mr-2%22%7D", name: "Loader", size: 16, className: "animate-spin mr-2" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
                lineNumber: 179,
                columnNumber: 21
              }, this),
              "Logging..."
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
              lineNumber: 178,
              columnNumber: 17
            }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\LogCallModal.jsx:184:20", "data-component-path": "src\\pages\\contact-management\\components\\LogCallModal.jsx", "data-component-line": "184", "data-component-file": "LogCallModal.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Save%22%2C%22className%22%3A%22mr-2%22%7D", name: "Save", size: 16, className: "mr-2" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
                lineNumber: 184,
                columnNumber: 21
              }, this),
              "Log Call"
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
              lineNumber: 183,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
            lineNumber: 170,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
        lineNumber: 162,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
      lineNumber: 47,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
      lineNumber: 46,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
    lineNumber: 39,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx",
    lineNumber: 38,
    columnNumber: 5
  }, this);
};
_s(LogCallModal, "SOxq4fAIKfMJOdJ005kJajejiD0=");
_c = LogCallModal;
export default LogCallModal;
var _c;
$RefreshReg$(_c, "LogCallModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/contact-management/components/LogCallModal.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0NVLFNBeUlRLFVBeklSOzJCQXhDVjtBQUFnQkEsTUFBUSxjQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3ZDLE9BQU9DLFVBQVU7QUFFakIsTUFBTUMsZUFBZUEsQ0FBQyxFQUFFQyxTQUFTQyxTQUFTQyxNQUFNLE1BQU07QUFBQUMsS0FBQTtBQUNwRCxRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSVIsU0FBUztBQUFBLElBQ3ZDUyxXQUFXTixTQUFTTztBQUFBQSxJQUNwQkMsT0FBTSxvQkFBSUMsS0FBSyxJQUFHQyxZQUFZLEdBQUdDLE1BQU0sR0FBRyxFQUFFO0FBQUE7QUFBQSxJQUM1Q0MsVUFBVTtBQUFBLElBQ1ZDLFdBQVc7QUFBQSxJQUNYQyxTQUFTO0FBQUEsSUFDVEMsU0FBUztBQUFBLEVBQ1gsQ0FBQztBQUNELFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJcEIsU0FBUyxLQUFLO0FBRWhELFFBQU1xQixlQUFlQSxDQUFDQyxNQUFNO0FBQzFCLFVBQU0sRUFBRUMsTUFBTUMsTUFBTSxJQUFJRixHQUFHRztBQUMzQmpCLGdCQUFZO0FBQUEsTUFDVixHQUFHRDtBQUFBQSxNQUNILENBQUNnQixJQUFJLEdBQUdDO0FBQUFBLElBQ1YsQ0FBQztBQUFBLEVBQ0g7QUFFQSxRQUFNRSxlQUFlQSxDQUFDSixNQUFNO0FBQzFCQSxPQUFHSyxlQUFlO0FBQ2xCUCxpQkFBYSxJQUFJO0FBR2pCUSxlQUFXLE1BQU07QUFDZnZCLFlBQU07QUFBQSxRQUNKLEdBQUdFO0FBQUFBLFFBQ0hHLElBQUlFLEtBQUtpQixJQUFJO0FBQUEsUUFDYkMsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUFBLElBQ0gsR0FBRyxHQUFJO0FBQUEsRUFDVDtBQUVBLFNBQ0UsdUJBQUMsc2FBQUksV0FBVSx3Q0FDYixpQ0FBQywyZUFBSSxXQUFVLDZGQUNiO0FBQUEsMkJBQUMsZ2FBQUksV0FBVSxvQ0FBbUMsZUFBWSxRQUM1RCxpQ0FBQywwYUFBSSxXQUFVLDZDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUQsS0FEM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFFQSx1QkFBQyxtZUFBSyxXQUFVLHNEQUFxRCxlQUFZLFFBQU8saUJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0Y7QUFBQSxJQUUvRix1QkFBQyxzakJBQUksV0FBVSw4SkFDYixpQ0FBQyxxV0FBSyxVQUFVSixjQUNkO0FBQUEsNkJBQUMsMmNBQUksV0FBVSxzRUFDYjtBQUFBLCtCQUFDLDRjQUFHLFdBQVUsMkNBQTBDLHdCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdFO0FBQUEsUUFDaEU7QUFBQSxVQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFNBQVN0QjtBQUFBQSxZQUNULFdBQVU7QUFBQSxZQUVWLGlDQUFDLDBYQUFLLE1BQUssS0FBSSxNQUFNLE1BQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdCO0FBQUE7QUFBQSxVQUwxQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFdBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsTUFFQSx1QkFBQyx3WUFBSSxXQUFVLGFBQ2IsaUNBQUMsc1lBQUksV0FBVSxhQUNiO0FBQUEsK0JBQUMsa1dBQ0M7QUFBQSxpQ0FBQyxpZUFBTSxXQUFVLHNEQUFxRCx1QkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE9BQU8sR0FBR0QsU0FBUzRCLFNBQVMsSUFBSTVCLFNBQVM2QixRQUFRO0FBQUEsY0FDakQsV0FBVTtBQUFBLGNBQ1YsVUFBUTtBQUFBO0FBQUEsWUFKVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJVTtBQUFBLGFBUlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsUUFFQSx1QkFBQywwYUFBSSxXQUFVLHlDQUNiO0FBQUEsaUNBQUMsa1dBQ0M7QUFBQSxtQ0FBQywyZUFBTSxTQUFRLFFBQU8sV0FBVSxzREFBcUQsMkJBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLElBQUc7QUFBQSxnQkFDSCxNQUFLO0FBQUEsZ0JBQ0wsT0FBT3pCLFVBQVVJO0FBQUFBLGdCQUNqQixVQUFVVTtBQUFBQSxnQkFDVixXQUFVO0FBQUEsZ0JBQ1YsVUFBUTtBQUFBO0FBQUEsY0FQVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPVTtBQUFBLGVBWFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFhQTtBQUFBLFVBRUEsdUJBQUMsa1dBQ0M7QUFBQSxtQ0FBQyw4ZUFBTSxTQUFRLFlBQVcsV0FBVSxzREFBcUQsa0NBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLElBQUc7QUFBQSxnQkFDSCxNQUFLO0FBQUEsZ0JBQ0wsT0FBT2QsVUFBVVE7QUFBQUEsZ0JBQ2pCLFVBQVVNO0FBQUFBLGdCQUNWLEtBQUk7QUFBQSxnQkFDSixLQUFJO0FBQUEsZ0JBQ0osV0FBVTtBQUFBLGdCQUNWLFVBQVE7QUFBQTtBQUFBLGNBVFY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBU1U7QUFBQSxlQWJaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZUE7QUFBQSxhQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0NBO0FBQUEsUUFFQSx1QkFBQyxvV0FDQztBQUFBLGlDQUFDLDRlQUFNLFNBQVEsYUFBWSxXQUFVLHNEQUFxRCw4QkFBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUNDLElBQUc7QUFBQSxjQUNILE1BQUs7QUFBQSxjQUNMLE9BQU9kLFVBQVVTO0FBQUFBLGNBQ2pCLFVBQVVLO0FBQUFBLGNBQ1YsV0FBVTtBQUFBLGNBQ1YsVUFBUTtBQUFBLGNBRVI7QUFBQSx1Q0FBQyxpYkFBTyxPQUFNLFlBQVcsd0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlDO0FBQUEsZ0JBQ2pDLHVCQUFDLCthQUFPLE9BQU0sV0FBVSx1QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0I7QUFBQTtBQUFBO0FBQUEsWUFUakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBVUE7QUFBQSxhQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQTtBQUFBLFFBRUEsdUJBQUMsb1dBQ0M7QUFBQSxpQ0FBQywwZUFBTSxTQUFRLFdBQVUsV0FBVSxzREFBcUQsNEJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FDQyxJQUFHO0FBQUEsY0FDSCxNQUFLO0FBQUEsY0FDTCxPQUFPZCxVQUFVVztBQUFBQSxjQUNqQixVQUFVRztBQUFBQSxjQUNWLFdBQVU7QUFBQSxjQUNWLFVBQVE7QUFBQSxjQUVSO0FBQUEsdUNBQUMsbWJBQU8sT0FBTSxhQUFZLHlCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtQztBQUFBLGdCQUNuQyx1QkFBQywrYkFBTyxPQUFNLGtCQUFpQiw4QkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkM7QUFBQSxnQkFDN0MsdUJBQUMscWJBQU8sT0FBTSxhQUFZLHlCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtQztBQUFBLGdCQUNuQyx1QkFBQyx5YUFBTyxPQUFNLFFBQU8sb0JBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlCO0FBQUEsZ0JBQ3pCLHVCQUFDLDJiQUFPLE9BQU0sZ0JBQWUsNEJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlDO0FBQUE7QUFBQTtBQUFBLFlBWjNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWFBO0FBQUEsYUFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWtCQTtBQUFBLFFBRUEsdUJBQUMsb1dBQ0M7QUFBQSxpQ0FBQywwZUFBTSxTQUFRLFdBQVUsV0FBVSxzREFBcUQsNEJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FDQyxJQUFHO0FBQUEsY0FDSCxNQUFLO0FBQUEsY0FDTCxPQUFPZCxVQUFVVTtBQUFBQSxjQUNqQixVQUFVSTtBQUFBQSxjQUNWLE1BQU07QUFBQSxjQUNOLGFBQVk7QUFBQSxjQUNaLFdBQVU7QUFBQSxjQUNWLFVBQVE7QUFBQTtBQUFBLFlBUlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBU0M7QUFBQSxhQWJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFjQTtBQUFBLFdBbEdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFtR0EsS0FwR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFHQTtBQUFBLE1BRUEsdUJBQUMsc2NBQUksV0FBVSwrREFDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTakI7QUFBQUEsWUFDVCxXQUFVO0FBQUEsWUFBbUo7QUFBQTtBQUFBLFVBSC9KO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsVUFBVWU7QUFBQUEsWUFDVixXQUFXLHdDQUNUQSxZQUFZLGtDQUFrQyxFQUFFO0FBQUEsWUFHakRBLHNCQUNDLG1DQUNFO0FBQUEscUNBQUMsK2FBQUssTUFBSyxVQUFTLE1BQU0sSUFBSSxXQUFVLHVCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyRDtBQUFBLGNBQUc7QUFBQSxpQkFEaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQSxJQUVBLG1DQUNFO0FBQUEscUNBQUMsOFpBQUssTUFBSyxRQUFPLE1BQU0sSUFBSSxXQUFVLFVBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRDO0FBQUEsY0FBRztBQUFBLGlCQURqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUE7QUFBQSxVQWhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFrQkE7QUFBQSxXQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMkJBO0FBQUEsU0E5SUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQStJQSxLQWhKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUpBO0FBQUEsT0F4SkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXlKQSxLQTFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMkpBO0FBRUo7QUFBRWIsR0EvTElKLGNBQVk7QUFBQStCLEtBQVovQjtBQWlNTixlQUFlQTtBQUFhLElBQUErQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJJY29uIiwiTG9nQ2FsbE1vZGFsIiwiY29udGFjdCIsIm9uQ2xvc2UiLCJvbkxvZyIsIl9zIiwiY2FsbERhdGEiLCJzZXRDYWxsRGF0YSIsImNvbnRhY3RJZCIsImlkIiwiZGF0ZSIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsInNsaWNlIiwiZHVyYXRpb24iLCJkaXJlY3Rpb24iLCJzdW1tYXJ5Iiwib3V0Y29tZSIsImlzTG9nZ2luZyIsInNldElzTG9nZ2luZyIsImhhbmRsZUNoYW5nZSIsImUiLCJuYW1lIiwidmFsdWUiLCJ0YXJnZXQiLCJoYW5kbGVTdWJtaXQiLCJwcmV2ZW50RGVmYXVsdCIsInNldFRpbWVvdXQiLCJub3ciLCJ0eXBlIiwiZmlyc3ROYW1lIiwibGFzdE5hbWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkxvZ0NhbGxNb2RhbC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgSWNvbiBmcm9tICdjb21wb25lbnRzL0FwcEljb24nO1xyXG5cclxuY29uc3QgTG9nQ2FsbE1vZGFsID0gKHsgY29udGFjdCwgb25DbG9zZSwgb25Mb2cgfSkgPT4ge1xyXG4gIGNvbnN0IFtjYWxsRGF0YSwgc2V0Q2FsbERhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgY29udGFjdElkOiBjb250YWN0Py5pZCxcclxuICAgIGRhdGU6IG5ldyBEYXRlKCk/LnRvSVNPU3RyaW5nKCk/LnNsaWNlKDAsIDE2KSwgLy8gRm9ybWF0OiBZWVlZLU1NLUREVGhoOm1tXHJcbiAgICBkdXJhdGlvbjogMTUsXHJcbiAgICBkaXJlY3Rpb246ICdvdXRib3VuZCcsXHJcbiAgICBzdW1tYXJ5OiAnJyxcclxuICAgIG91dGNvbWU6ICdjb21wbGV0ZWQnXHJcbiAgfSk7XHJcbiAgY29uc3QgW2lzTG9nZ2luZywgc2V0SXNMb2dnaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGU/LnRhcmdldDtcclxuICAgIHNldENhbGxEYXRhKHtcclxuICAgICAgLi4uY2FsbERhdGEsXHJcbiAgICAgIFtuYW1lXTogdmFsdWVcclxuICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IChlKSA9PiB7XHJcbiAgICBlPy5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgc2V0SXNMb2dnaW5nKHRydWUpO1xyXG4gICAgXHJcbiAgICAvLyBTaW11bGF0ZSBsb2dnaW5nIGNhbGxcclxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICBvbkxvZyh7XHJcbiAgICAgICAgLi4uY2FsbERhdGEsXHJcbiAgICAgICAgaWQ6IERhdGUubm93KCksXHJcbiAgICAgICAgdHlwZTogJ2NhbGwnXHJcbiAgICAgIH0pO1xyXG4gICAgfSwgMTAwMCk7XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTExMDAgb3ZlcmZsb3cteS1hdXRvXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbWluLWgtc2NyZWVuIHB4LTQgcHQtNCBwYi0yMCB0ZXh0LWNlbnRlciBzbTpibG9jayBzbTpwLTBcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgdHJhbnNpdGlvbi1vcGFjaXR5XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgYmctYmxhY2sgYmctb3BhY2l0eS01MFwiPjwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIFxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpZGRlbiBzbTppbmxpbmUtYmxvY2sgc206YWxpZ24tbWlkZGxlIHNtOmgtc2NyZWVuXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+JiM4MjAzOzwvc3Bhbj5cclxuICAgICAgICBcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlubGluZS1ibG9jayBhbGlnbi1ib3R0b20gYmctc3VyZmFjZSByb3VuZGVkLWxnIHRleHQtbGVmdCBvdmVyZmxvdy1oaWRkZW4gc2hhZG93LXhsIHRyYW5zZm9ybSB0cmFuc2l0aW9uLWFsbCBzbTpteS04IHNtOmFsaWduLW1pZGRsZSBzbTptYXgtdy1sZyBzbTp3LWZ1bGxcIj5cclxuICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcHktNCBib3JkZXItYiBib3JkZXItYm9yZGVyIGZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC10ZXh0LXByaW1hcnlcIj5Mb2cgQ2FsbDwvaDM+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC10ZXh0LXNlY29uZGFyeSBob3Zlcjp0ZXh0LXRleHQtcHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIlhcIiBzaXplPXsyMH0gLz5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcHktNVwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtc2Vjb25kYXJ5IG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICBDb250YWN0XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YCR7Y29udGFjdD8uZmlyc3ROYW1lfSAke2NvbnRhY3Q/Lmxhc3ROYW1lfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5wdXQtZmllbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJkYXRlXCIgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtc2Vjb25kYXJ5IG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIERhdGUgJiBUaW1lXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRldGltZS1sb2NhbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2NhbGxEYXRhPy5kYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlucHV0LWZpZWxkXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiZHVyYXRpb25cIiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1zZWNvbmRhcnkgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgRHVyYXRpb24gKG1pbnV0ZXMpXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJkdXJhdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZHVyYXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2NhbGxEYXRhPy5kdXJhdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBtaW49XCIxXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG1heD1cIjI0MFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbnB1dC1maWVsZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiZGlyZWN0aW9uXCIgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtc2Vjb25kYXJ5IG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICBDYWxsIERpcmVjdGlvblxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJkaXJlY3Rpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJkaXJlY3Rpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjYWxsRGF0YT8uZGlyZWN0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5wdXQtZmllbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwib3V0Ym91bmRcIj5PdXRib3VuZDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJpbmJvdW5kXCI+SW5ib3VuZDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cIm91dGNvbWVcIiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1zZWNvbmRhcnkgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIENhbGwgT3V0Y29tZVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJvdXRjb21lXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwib3V0Y29tZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2NhbGxEYXRhPy5vdXRjb21lfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5wdXQtZmllbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiY29tcGxldGVkXCI+Q29tcGxldGVkPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImxlZnQtdm9pY2VtYWlsXCI+TGVmdCBWb2ljZW1haWw8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwibm8tYW5zd2VyXCI+Tm8gQW5zd2VyPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImJ1c3lcIj5CdXN5PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIndyb25nLW51bWJlclwiPldyb25nIE51bWJlcjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInN1bW1hcnlcIiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1zZWNvbmRhcnkgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIENhbGwgU3VtbWFyeVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8dGV4dGFyZWFcclxuICAgICAgICAgICAgICAgICAgICBpZD1cInN1bW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJzdW1tYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y2FsbERhdGE/LnN1bW1hcnl9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICByb3dzPXs0fVxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgY2FsbCBub3RlcyBhbmQgc3VtbWFyeS4uLlwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5wdXQtZmllbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgID48L3RleHRhcmVhPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC02IHB5LTQgYm9yZGVyLXQgYm9yZGVyLWJvcmRlciBmbGV4IGp1c3RpZnktZW5kIHNwYWNlLXgtM1wiPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLWxnIHRleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC10ZXh0LXByaW1hcnkgaG92ZXI6Ymctc3VyZmFjZS1ob3ZlciB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0xNTAgZWFzZS1vdXRcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzTG9nZ2luZ31cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJ0bi1wcmltYXJ5IGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciAke1xyXG4gICAgICAgICAgICAgICAgICBpc0xvZ2dpbmcgPyAnb3BhY2l0eS01MCBjdXJzb3Itbm90LWFsbG93ZWQnIDogJydcclxuICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtpc0xvZ2dpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIkxvYWRlclwiIHNpemU9ezE2fSBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW4gbXItMlwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgTG9nZ2luZy4uLlxyXG4gICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIlNhdmVcIiBzaXplPXsxNn0gY2xhc3NOYW1lPVwibXItMlwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgTG9nIENhbGxcclxuICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgTG9nQ2FsbE1vZGFsOyJdLCJmaWxlIjoiRDovY3VycmVudCBwcm9qZWN0cy9jbGF1ZGUtY29kZS9zcmMvcGFnZXMvY29udGFjdC1tYW5hZ2VtZW50L2NvbXBvbmVudHMvTG9nQ2FsbE1vZGFsLmpzeCJ9