import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/settings-administration/components/Integrations.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import Icon from "/src/components/AppIcon.jsx";
const Integrations = () => {
  _s();
  const [integrations, setIntegrations] = useState(
    [
      {
        id: "gmail",
        name: "Gmail",
        description: "Sync emails and contacts with Gmail",
        status: "connected",
        lastSync: "2024-01-15 14:30",
        icon: "Mail",
        config: {
          syncFrequency: "15 minutes",
          autoSync: true,
          syncContacts: true,
          syncEmails: true
        }
      },
      {
        id: "google-calendar",
        name: "Google Calendar",
        description: "Schedule meetings and sync calendar events",
        status: "connected",
        lastSync: "2024-01-15 14:25",
        icon: "Calendar",
        config: {
          syncFrequency: "5 minutes",
          autoSync: true,
          createMeetings: true,
          syncEvents: true
        }
      },
      {
        id: "twilio",
        name: "Twilio",
        description: "Send SMS and make calls through Twilio",
        status: "disconnected",
        lastSync: null,
        icon: "Phone",
        config: {
          smsEnabled: false,
          callEnabled: false,
          webhookUrl: ""
        }
      },
      {
        id: "slack",
        name: "Slack",
        description: "Get notifications and updates in Slack",
        status: "error",
        lastSync: "2024-01-10 09:15",
        icon: "MessageSquare",
        config: {
          channel: "#sales",
          notifications: true,
          dealUpdates: true
        }
      }
    ]
  );
  const [selectedIntegration, setSelectedIntegration] = useState(null);
  const [showConfigModal, setShowConfigModal] = useState(false);
  const [testResults, setTestResults] = useState({});
  const getStatusBadge = (status) => {
    const statusStyles = {
      connected: { bg: "bg-success-50", text: "text-success-600", border: "border-success-100", label: "Connected" },
      disconnected: { bg: "bg-error-50", text: "text-error-600", border: "border-error-100", label: "Disconnected" },
      error: { bg: "bg-warning-50", text: "text-warning-600", border: "border-warning-100", label: "Error" }
    };
    const style = statusStyles?.[status] || statusStyles?.disconnected;
    return /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:77:6", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "77", "data-component-file": "Integrations.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", className: `px-2 py-1 text-xs font-medium rounded border ${style?.bg} ${style?.text} ${style?.border}`, children: style?.label }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
      lineNumber: 77,
      columnNumber: 7
    }, this);
  };
  const getStatusIcon = (status) => {
    const icons = {
      connected: { name: "CheckCircle", color: "text-success" },
      disconnected: { name: "XCircle", color: "text-error" },
      error: { name: "AlertCircle", color: "text-warning" }
    };
    const icon = icons?.[status] || icons?.disconnected;
    return /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:91:11", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "91", "data-component-file": "Integrations.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%7D", name: icon?.name, size: 20, className: icon?.color }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
      lineNumber: 91,
      columnNumber: 12
    }, this);
  };
  const handleConnect = (integrationId) => {
    console.log("Connecting to:", integrationId);
    setIntegrations(
      (prev) => prev?.map(
        (integration) => integration?.id === integrationId ? { ...integration, status: "connected", lastSync: (/* @__PURE__ */ new Date())?.toISOString()?.slice(0, 16)?.replace("T", " ") } : integration
      )
    );
  };
  const handleDisconnect = (integrationId) => {
    console.log("Disconnecting from:", integrationId);
    setIntegrations(
      (prev) => prev?.map(
        (integration) => integration?.id === integrationId ? { ...integration, status: "disconnected", lastSync: null } : integration
      )
    );
  };
  const handleTestConnection = async (integrationId) => {
    console.log("Testing connection for:", integrationId);
    setTestResults((prev) => ({ ...prev, [integrationId]: "testing" }));
    setTimeout(() => {
      const success = Math.random() > 0.3;
      setTestResults((prev) => ({
        ...prev,
        [integrationId]: success ? "success" : "error"
      }));
    }, 2e3);
  };
  const handleConfigure = (integration) => {
    setSelectedIntegration(integration);
    setShowConfigModal(true);
  };
  const handleSaveConfig = () => {
    console.log("Saving configuration for:", selectedIntegration?.name);
    setShowConfigModal(false);
    setSelectedIntegration(null);
  };
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:143:4", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "143", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-6%22%7D", className: "space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:145:6", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "145", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:146:8", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "146", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
        /* @__PURE__ */ jsxDEV("h2", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:147:10", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "147", "data-component-file": "Integrations.jsx", "data-component-name": "h2", "data-component-content": "%7B%22elementName%22%3A%22h2%22%2C%22className%22%3A%22text-2xl%20font-bold%20text-text-primary%22%2C%22textContent%22%3A%22Integrations%22%7D", className: "text-2xl font-bold text-text-primary", children: "Integrations" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
          lineNumber: 147,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:148:10", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "148", "data-component-file": "Integrations.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20mt-1%22%2C%22textContent%22%3A%22Manage%20API%20connections%20and%20third-party%20services%22%7D", className: "text-text-secondary mt-1", children: "Manage API connections and third-party services" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
          lineNumber: 148,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
        lineNumber: 146,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:150:8", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "150", "data-component-file": "Integrations.jsx", "data-component-name": "button", "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22bg-primary%20text-white%20px-4%20py-2%20rounded-lg%20hover%3Abg-primary-600%20transition-colors%20duration-150%20ease-smooth%20flex%20items-center%20space-x-2%22%7D", className: "bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary-600 transition-colors duration-150 ease-smooth flex items-center space-x-2", children: [
        /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:151:10", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "151", "data-component-file": "Integrations.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Plus%22%7D", name: "Plus", size: 16 }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
          lineNumber: 151,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:152:10", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "152", "data-component-file": "Integrations.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Add%20Integration%22%7D", children: "Add Integration" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
          lineNumber: 152,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
        lineNumber: 150,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
      lineNumber: 145,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:156:6", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "156", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20md%3Agrid-cols-2%20lg%3Agrid-cols-3%20gap-6%22%7D", className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6", children: integrations?.map(
      (integration) => /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:158:8", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "158", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20rounded-lg%20border%20border-border%20p-6%20hover%3Ashadow-md%20transition-shadow%20duration-150%22%7D", className: "bg-surface rounded-lg border border-border p-6 hover:shadow-md transition-shadow duration-150", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:159:12", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "159", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-start%20justify-between%20mb-4%22%7D", className: "flex items-start justify-between mb-4", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:160:14", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "160", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-3%22%7D", className: "flex items-center space-x-3", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:161:16", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "161", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-10%20h-10%20bg-primary-50%20rounded-lg%20flex%20items-center%20justify-center%22%7D", className: "w-10 h-10 bg-primary-50 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:162:18", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "162", "data-component-file": "Integrations.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22className%22%3A%22text-primary%22%7D", name: integration?.icon, size: 20, className: "text-primary" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
              lineNumber: 162,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
              lineNumber: 161,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:164:16", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "164", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:165:18", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "165", "data-component-file": "Integrations.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22font-semibold%20text-text-primary%22%7D", className: "font-semibold text-text-primary", children: integration?.name }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
                lineNumber: 165,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:166:18", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "166", "data-component-file": "Integrations.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%20text-text-secondary%20mt-1%22%7D", className: "text-sm text-text-secondary mt-1", children: integration?.description }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
                lineNumber: 166,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
              lineNumber: 164,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
            lineNumber: 160,
            columnNumber: 15
          }, this),
          getStatusIcon(integration?.status)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
          lineNumber: 159,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:172:12", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "172", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-3%20mb-4%22%7D", className: "space-y-3 mb-4", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:173:14", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "173", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:174:16", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "174", "data-component-file": "Integrations.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22Status%3A%22%7D", className: "text-sm text-text-secondary", children: "Status:" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
              lineNumber: 174,
              columnNumber: 17
            }, this),
            getStatusBadge(integration?.status)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
            lineNumber: 173,
            columnNumber: 15
          }, this),
          integration?.lastSync && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:179:12", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "179", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:180:18", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "180", "data-component-file": "Integrations.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22Last%20Sync%3A%22%7D", className: "text-sm text-text-secondary", children: "Last Sync:" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
              lineNumber: 180,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:181:18", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "181", "data-component-file": "Integrations.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-primary%22%7D", className: "text-sm text-text-primary", children: integration?.lastSync }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
              lineNumber: 181,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
            lineNumber: 179,
            columnNumber: 13
          }, this),
          testResults?.[integration?.id] && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:186:12", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "186", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:187:18", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "187", "data-component-file": "Integrations.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22Test%20Result%3A%22%7D", className: "text-sm text-text-secondary", children: "Test Result:" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
              lineNumber: 187,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:188:18", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "188", "data-component-file": "Integrations.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", className: `text-sm ${testResults?.[integration?.id] === "testing" ? "text-text-secondary" : testResults?.[integration?.id] === "success" ? "text-success" : "text-error"}`, children: testResults?.[integration?.id] === "testing" ? "Testing..." : testResults?.[integration?.id] === "success" ? "Success" : "Failed" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
              lineNumber: 188,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
            lineNumber: 186,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
          lineNumber: 172,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:199:12", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "199", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-2%22%7D", className: "space-y-2", children: [
          integration?.status === "connected" ? /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:201:12", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "201", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20space-x-2%22%7D", className: "flex space-x-2", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:202:18",
                "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx",
                "data-component-line": "202",
                "data-component-file": "Integrations.jsx",
                "data-component-name": "button",
                "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22flex-1%20px-3%20py-2%20text-sm%20bg-background%20text-text-primary%20rounded%20hover%3Abg-surface-hover%20transition-colors%20duration-150%20disabled%3Aopacity-50%20disabled%3Acursor-not-allowed%22%7D",
                onClick: () => handleTestConnection(integration?.id),
                disabled: testResults?.[integration?.id] === "testing",
                className: "flex-1 px-3 py-2 text-sm bg-background text-text-primary rounded hover:bg-surface-hover transition-colors duration-150 disabled:opacity-50 disabled:cursor-not-allowed",
                children: testResults?.[integration?.id] === "testing" ? /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:208:16", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "208", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-center%20space-x-2%22%7D", className: "flex items-center justify-center space-x-2", children: [
                  /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:209:24", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "209", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-4%20h-4%20border-2%20border-text-secondary%20border-t-transparent%20rounded-full%20animate-spin%22%7D", className: "w-4 h-4 border-2 border-text-secondary border-t-transparent rounded-full animate-spin" }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
                    lineNumber: 209,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:210:24", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "210", "data-component-file": "Integrations.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Testing%22%7D", children: "Testing" }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
                    lineNumber: 210,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
                  lineNumber: 208,
                  columnNumber: 17
                }, this) : "Test Connection"
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
                lineNumber: 202,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:216:18",
                "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx",
                "data-component-line": "216",
                "data-component-file": "Integrations.jsx",
                "data-component-name": "button",
                "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22flex-1%20px-3%20py-2%20text-sm%20bg-primary%20text-white%20rounded%20hover%3Abg-primary-600%20transition-colors%20duration-150%22%2C%22textContent%22%3A%22Configure%22%7D",
                onClick: () => handleConfigure(integration),
                className: "flex-1 px-3 py-2 text-sm bg-primary text-white rounded hover:bg-primary-600 transition-colors duration-150",
                children: "Configure"
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
                lineNumber: 216,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
            lineNumber: 201,
            columnNumber: 13
          }, this) : /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:224:12",
              "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx",
              "data-component-line": "224",
              "data-component-file": "Integrations.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20text-sm%20bg-primary%20text-white%20rounded%20hover%3Abg-primary-600%20transition-colors%20duration-150%22%2C%22textContent%22%3A%22Connect%22%7D",
              onClick: () => handleConnect(integration?.id),
              className: "w-full px-3 py-2 text-sm bg-primary text-white rounded hover:bg-primary-600 transition-colors duration-150",
              children: "Connect"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
              lineNumber: 224,
              columnNumber: 13
            },
            this
          ),
          integration?.status === "connected" && /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:233:12",
              "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx",
              "data-component-line": "233",
              "data-component-file": "Integrations.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20text-sm%20text-error%20hover%3Abg-error-50%20rounded%20transition-colors%20duration-150%22%2C%22textContent%22%3A%22Disconnect%22%7D",
              onClick: () => handleDisconnect(integration?.id),
              className: "w-full px-3 py-2 text-sm text-error hover:bg-error-50 rounded transition-colors duration-150",
              children: "Disconnect"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
              lineNumber: 233,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
          lineNumber: 199,
          columnNumber: 13
        }, this)
      ] }, integration?.id, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
        lineNumber: 158,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
      lineNumber: 156,
      columnNumber: 7
    }, this),
    showConfigModal && selectedIntegration && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:246:6", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "246", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20z-1200%20overflow-y-auto%22%7D", className: "fixed inset-0 z-1200 overflow-y-auto", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:247:10", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "247", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-center%20min-h-screen%20px-4%22%7D", className: "flex items-center justify-center min-h-screen px-4", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:248:12", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "248", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20bg-black%20bg-opacity-50%22%7D", className: "fixed inset-0 bg-black bg-opacity-50", onClick: () => setShowConfigModal(false) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
        lineNumber: 248,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:249:12", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "249", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20rounded-lg%20shadow-xl%20max-w-lg%20w-full%20relative%20z-1300%22%7D", className: "bg-surface rounded-lg shadow-xl max-w-lg w-full relative z-1300", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:250:14", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "250", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22p-6%22%7D", className: "p-6", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:251:16", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "251", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%20mb-4%22%7D", className: "flex items-center justify-between mb-4", children: [
          /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:252:18", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "252", "data-component-file": "Integrations.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%2C%22textContent%22%3A%22Configure%22%7D", className: "text-lg font-semibold text-text-primary", children: [
            "Configure ",
            selectedIntegration?.name
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
            lineNumber: 252,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:255:18",
              "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx",
              "data-component-line": "255",
              "data-component-file": "Integrations.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22text-text-secondary%20hover%3Atext-text-primary%20transition-colors%20duration-150%22%7D",
              onClick: () => setShowConfigModal(false),
              className: "text-text-secondary hover:text-text-primary transition-colors duration-150",
              children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:259:20", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "259", "data-component-file": "Integrations.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22X%22%7D", name: "X", size: 20 }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
                lineNumber: 259,
                columnNumber: 21
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
              lineNumber: 255,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
          lineNumber: 251,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:263:16", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "263", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-4%22%7D", className: "space-y-4", children: [
          selectedIntegration?.id === "gmail" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:266:22", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "266", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:267:24", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "267", "data-component-file": "Integrations.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22text-sm%20font-medium%20text-text-primary%22%2C%22textContent%22%3A%22Auto%20Sync%22%7D", className: "text-sm font-medium text-text-primary", children: "Auto Sync" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
                lineNumber: 267,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("input", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:268:24", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "268", "data-component-file": "Integrations.jsx", "data-component-name": "input", "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22checkbox%22%2C%22className%22%3A%22rounded%20border-border%20text-primary%20focus%3Aring-primary%22%7D", type: "checkbox", defaultChecked: true, className: "rounded border-border text-primary focus:ring-primary" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
                lineNumber: 268,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
              lineNumber: 266,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:270:22", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "270", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:271:24", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "271", "data-component-file": "Integrations.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22text-sm%20font-medium%20text-text-primary%22%2C%22textContent%22%3A%22Sync%20Contacts%22%7D", className: "text-sm font-medium text-text-primary", children: "Sync Contacts" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
                lineNumber: 271,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("input", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:272:24", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "272", "data-component-file": "Integrations.jsx", "data-component-name": "input", "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22checkbox%22%2C%22className%22%3A%22rounded%20border-border%20text-primary%20focus%3Aring-primary%22%7D", type: "checkbox", defaultChecked: true, className: "rounded border-border text-primary focus:ring-primary" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
                lineNumber: 272,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
              lineNumber: 270,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:274:22", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "274", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:275:24", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "275", "data-component-file": "Integrations.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22text-sm%20font-medium%20text-text-primary%22%2C%22textContent%22%3A%22Sync%20Emails%22%7D", className: "text-sm font-medium text-text-primary", children: "Sync Emails" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
                lineNumber: 275,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("input", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:276:24", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "276", "data-component-file": "Integrations.jsx", "data-component-name": "input", "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22checkbox%22%2C%22className%22%3A%22rounded%20border-border%20text-primary%20focus%3Aring-primary%22%7D", type: "checkbox", defaultChecked: true, className: "rounded border-border text-primary focus:ring-primary" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
                lineNumber: 276,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
              lineNumber: 274,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:278:22", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "278", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:279:24", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "279", "data-component-file": "Integrations.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Sync%20Frequency%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Sync Frequency" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
                lineNumber: 279,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("select", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:280:24", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "280", "data-component-file": "Integrations.jsx", "data-component-name": "select", "data-component-content": "%7B%22elementName%22%3A%22select%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D", className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary", children: [
                /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:281:26", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "281", "data-component-file": "Integrations.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%225%22%2C%22textContent%22%3A%22Every%205%20minutes%22%7D", value: "5", children: "Every 5 minutes" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
                  lineNumber: 281,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:282:26", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "282", "data-component-file": "Integrations.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%2215%22%2C%22textContent%22%3A%22Every%2015%20minutes%22%7D", value: "15", selected: true, children: "Every 15 minutes" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
                  lineNumber: 282,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:283:26", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "283", "data-component-file": "Integrations.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%2230%22%2C%22textContent%22%3A%22Every%2030%20minutes%22%7D", value: "30", children: "Every 30 minutes" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
                  lineNumber: 283,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("option", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:284:26", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "284", "data-component-file": "Integrations.jsx", "data-component-name": "option", "data-component-content": "%7B%22elementName%22%3A%22option%22%2C%22value%22%3A%2260%22%2C%22textContent%22%3A%22Every%20hour%22%7D", value: "60", children: "Every hour" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
                  lineNumber: 284,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
                lineNumber: 280,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
              lineNumber: 278,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
            lineNumber: 265,
            columnNumber: 17
          }, this),
          selectedIntegration?.id === "twilio" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:292:22", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "292", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:293:24", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "293", "data-component-file": "Integrations.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Account%20SID%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Account SID" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
                lineNumber: 293,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:294:24",
                  "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx",
                  "data-component-line": "294",
                  "data-component-file": "Integrations.jsx",
                  "data-component-name": "input",
                  "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22text%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
                  type: "text",
                  className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
                  placeholder: "ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                },
                void 0,
                false,
                {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
                  lineNumber: 294,
                  columnNumber: 25
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
              lineNumber: 292,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:300:22", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "300", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:301:24", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "301", "data-component-file": "Integrations.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-1%22%2C%22textContent%22%3A%22Auth%20Token%22%7D", className: "block text-sm font-medium text-text-primary mb-1", children: "Auth Token" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
                lineNumber: 301,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:302:24",
                  "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx",
                  "data-component-line": "302",
                  "data-component-file": "Integrations.jsx",
                  "data-component-name": "input",
                  "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22password%22%2C%22className%22%3A%22w-full%20px-3%20py-2%20border%20border-border%20rounded-lg%20focus%3Aring-primary%20focus%3Aborder-primary%22%7D",
                  type: "password",
                  className: "w-full px-3 py-2 border border-border rounded-lg focus:ring-primary focus:border-primary",
                  placeholder: "Enter auth token"
                },
                void 0,
                false,
                {
                  fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
                  lineNumber: 302,
                  columnNumber: 25
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
              lineNumber: 300,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:308:22", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "308", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:309:24", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "309", "data-component-file": "Integrations.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22text-sm%20font-medium%20text-text-primary%22%2C%22textContent%22%3A%22Enable%20SMS%22%7D", className: "text-sm font-medium text-text-primary", children: "Enable SMS" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
                lineNumber: 309,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("input", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:310:24", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "310", "data-component-file": "Integrations.jsx", "data-component-name": "input", "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22checkbox%22%2C%22className%22%3A%22rounded%20border-border%20text-primary%20focus%3Aring-primary%22%7D", type: "checkbox", className: "rounded border-border text-primary focus:ring-primary" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
                lineNumber: 310,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
              lineNumber: 308,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:312:22", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "312", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:313:24", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "313", "data-component-file": "Integrations.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22text-sm%20font-medium%20text-text-primary%22%2C%22textContent%22%3A%22Enable%20Calls%22%7D", className: "text-sm font-medium text-text-primary", children: "Enable Calls" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
                lineNumber: 313,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("input", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:314:24", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "314", "data-component-file": "Integrations.jsx", "data-component-name": "input", "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22checkbox%22%2C%22className%22%3A%22rounded%20border-border%20text-primary%20focus%3Aring-primary%22%7D", type: "checkbox", className: "rounded border-border text-primary focus:ring-primary" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
                lineNumber: 314,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
              lineNumber: 312,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
            lineNumber: 291,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
          lineNumber: 263,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:320:16", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "320", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20justify-end%20space-x-3%20mt-6%22%7D", className: "flex justify-end space-x-3 mt-6", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:321:18",
              "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx",
              "data-component-line": "321",
              "data-component-file": "Integrations.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22px-4%20py-2%20text-text-secondary%20hover%3Atext-text-primary%20transition-colors%20duration-150%22%2C%22textContent%22%3A%22Cancel%22%7D",
              onClick: () => setShowConfigModal(false),
              className: "px-4 py-2 text-text-secondary hover:text-text-primary transition-colors duration-150",
              children: "Cancel"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
              lineNumber: 321,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:327:18",
              "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx",
              "data-component-line": "327",
              "data-component-file": "Integrations.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22bg-primary%20text-white%20px-4%20py-2%20rounded-lg%20hover%3Abg-primary-600%20transition-colors%20duration-150%20ease-smooth%22%2C%22textContent%22%3A%22Save%20Configuration%22%7D",
              onClick: handleSaveConfig,
              className: "bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary-600 transition-colors duration-150 ease-smooth",
              children: "Save Configuration"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
              lineNumber: 327,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
          lineNumber: 320,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
        lineNumber: 250,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
        lineNumber: 249,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
      lineNumber: 247,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
      lineNumber: 246,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:340:6", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "340", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-background%20border%20border-border%20rounded-lg%20p-4%22%7D", className: "bg-background border border-border rounded-lg p-4", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:341:8", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "341", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-start%20space-x-3%22%7D", className: "flex items-start space-x-3", children: [
      /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:342:10", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "342", "data-component-file": "Integrations.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Zap%22%2C%22className%22%3A%22text-primary%20mt-0.5%22%7D", name: "Zap", size: 16, className: "text-primary mt-0.5" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
        lineNumber: 342,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:343:10", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "343", "data-component-file": "Integrations.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex-1%22%7D", className: "flex-1", children: [
        /* @__PURE__ */ jsxDEV("h4", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:344:12", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "344", "data-component-file": "Integrations.jsx", "data-component-name": "h4", "data-component-content": "%7B%22elementName%22%3A%22h4%22%2C%22className%22%3A%22font-medium%20text-text-primary%20text-sm%22%2C%22textContent%22%3A%22Integration%20Health%22%7D", className: "font-medium text-text-primary text-sm", children: "Integration Health" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
          lineNumber: 344,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\settings-administration\\components\\Integrations.jsx:345:12", "data-component-path": "src\\pages\\settings-administration\\components\\Integrations.jsx", "data-component-line": "345", "data-component-file": "Integrations.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20text-sm%20mt-1%22%2C%22textContent%22%3A%22of%20integrations%20are%20connected%20and%20working%20properly.%5Cn%20%20%20%20%20%20%20%20%20%20%20%20%20%20Regular%20testing%20ensures%20optimal%20performance.%22%7D", className: "text-text-secondary text-sm mt-1", children: [
          integrations?.filter((i) => i?.status === "connected")?.length,
          " of ",
          integrations?.length,
          " integrations are connected and working properly. Regular testing ensures optimal performance."
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
          lineNumber: 345,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
        lineNumber: 343,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
      lineNumber: 341,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
      lineNumber: 340,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx",
    lineNumber: 143,
    columnNumber: 5
  }, this);
};
_s(Integrations, "P7ZKWOXToHUI2u8pvRuSKiBhkoE=");
_c = Integrations;
export default Integrations;
var _c;
$RefreshReg$(_c, "Integrations");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/settings-administration/components/Integrations.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEVNLFNBNExjLFVBNUxkOzJCQTVFTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBLE9BQU9BLFNBQVNDLGdCQUFnQjtBQUNoQyxPQUFPQyxVQUFVO0FBRWpCLE1BQU1DLGVBQWVBLE1BQU07QUFBQUMsS0FBQTtBQUN6QixRQUFNLENBQUNDLGNBQWNDLGVBQWUsSUFBSUw7QUFBQUEsSUFBUztBQUFBLE1BQy9DO0FBQUEsUUFDRU0sSUFBSTtBQUFBLFFBQ0pDLE1BQU07QUFBQSxRQUNOQyxhQUFhO0FBQUEsUUFDYkMsUUFBUTtBQUFBLFFBQ1JDLFVBQVU7QUFBQSxRQUNWQyxNQUFNO0FBQUEsUUFDTkMsUUFBUTtBQUFBLFVBQ05DLGVBQWU7QUFBQSxVQUNmQyxVQUFVO0FBQUEsVUFDVkMsY0FBYztBQUFBLFVBQ2RDLFlBQVk7QUFBQSxRQUNkO0FBQUEsTUFDRjtBQUFBLE1BQ0E7QUFBQSxRQUNFVixJQUFJO0FBQUEsUUFDSkMsTUFBTTtBQUFBLFFBQ05DLGFBQWE7QUFBQSxRQUNiQyxRQUFRO0FBQUEsUUFDUkMsVUFBVTtBQUFBLFFBQ1ZDLE1BQU07QUFBQSxRQUNOQyxRQUFRO0FBQUEsVUFDTkMsZUFBZTtBQUFBLFVBQ2ZDLFVBQVU7QUFBQSxVQUNWRyxnQkFBZ0I7QUFBQSxVQUNoQkMsWUFBWTtBQUFBLFFBQ2Q7QUFBQSxNQUNGO0FBQUEsTUFDQTtBQUFBLFFBQ0VaLElBQUk7QUFBQSxRQUNKQyxNQUFNO0FBQUEsUUFDTkMsYUFBYTtBQUFBLFFBQ2JDLFFBQVE7QUFBQSxRQUNSQyxVQUFVO0FBQUEsUUFDVkMsTUFBTTtBQUFBLFFBQ05DLFFBQVE7QUFBQSxVQUNOTyxZQUFZO0FBQUEsVUFDWkMsYUFBYTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxRQUNkO0FBQUEsTUFDRjtBQUFBLE1BQ0E7QUFBQSxRQUNFZixJQUFJO0FBQUEsUUFDSkMsTUFBTTtBQUFBLFFBQ05DLGFBQWE7QUFBQSxRQUNiQyxRQUFRO0FBQUEsUUFDUkMsVUFBVTtBQUFBLFFBQ1ZDLE1BQU07QUFBQSxRQUNOQyxRQUFRO0FBQUEsVUFDTlUsU0FBUztBQUFBLFVBQ1RDLGVBQWU7QUFBQSxVQUNmQyxhQUFhO0FBQUEsUUFDZjtBQUFBLE1BQ0Y7QUFBQSxJQUFDO0FBQUEsRUFDRjtBQUVELFFBQU0sQ0FBQ0MscUJBQXFCQyxzQkFBc0IsSUFBSTFCLFNBQVMsSUFBSTtBQUNuRSxRQUFNLENBQUMyQixpQkFBaUJDLGtCQUFrQixJQUFJNUIsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQzZCLGFBQWFDLGNBQWMsSUFBSTlCLFNBQVMsQ0FBQyxDQUFDO0FBRWpELFFBQU0rQixpQkFBaUJBLENBQUN0QixXQUFXO0FBQ2pDLFVBQU11QixlQUFlO0FBQUEsTUFDbkJDLFdBQVcsRUFBRUMsSUFBSSxpQkFBaUJDLE1BQU0sb0JBQW9CQyxRQUFRLHNCQUFzQkMsT0FBTyxZQUFZO0FBQUEsTUFDN0dDLGNBQWMsRUFBRUosSUFBSSxlQUFlQyxNQUFNLGtCQUFrQkMsUUFBUSxvQkFBb0JDLE9BQU8sZUFBZTtBQUFBLE1BQzdHRSxPQUFPLEVBQUVMLElBQUksaUJBQWlCQyxNQUFNLG9CQUFvQkMsUUFBUSxzQkFBc0JDLE9BQU8sUUFBUTtBQUFBLElBQ3ZHO0FBRUEsVUFBTUcsUUFBUVIsZUFBZXZCLE1BQU0sS0FBS3VCLGNBQWNNO0FBRXRELFdBQ0UsdUJBQUMsOFdBQUssV0FBVyxnREFBZ0RFLE9BQU9OLEVBQUUsSUFBSU0sT0FBT0wsSUFBSSxJQUFJSyxPQUFPSixNQUFNLElBQ3ZHSSxpQkFBT0gsU0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBRUEsUUFBTUksZ0JBQWdCQSxDQUFDaEMsV0FBVztBQUNoQyxVQUFNaUMsUUFBUTtBQUFBLE1BQ1pULFdBQVcsRUFBRTFCLE1BQU0sZUFBZW9DLE9BQU8sZUFBZTtBQUFBLE1BQ3hETCxjQUFjLEVBQUUvQixNQUFNLFdBQVdvQyxPQUFPLGFBQWE7QUFBQSxNQUNyREosT0FBTyxFQUFFaEMsTUFBTSxlQUFlb0MsT0FBTyxlQUFlO0FBQUEsSUFDdEQ7QUFFQSxVQUFNaEMsT0FBTytCLFFBQVFqQyxNQUFNLEtBQUtpQyxPQUFPSjtBQUN2QyxXQUFPLHVCQUFDLDZXQUFLLE1BQU0zQixNQUFNSixNQUFNLE1BQU0sSUFBSSxXQUFXSSxNQUFNZ0MsU0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5RDtBQUFBLEVBQ2xFO0FBRUEsUUFBTUMsZ0JBQWdCQSxDQUFDQyxrQkFBa0I7QUFDdkNDLFlBQVFDLElBQUksa0JBQWtCRixhQUFhO0FBRTNDeEM7QUFBQUEsTUFBZ0IsQ0FBQTJDLFNBQ2RBLE1BQU1DO0FBQUFBLFFBQUksQ0FBQUMsZ0JBQ1JBLGFBQWE1QyxPQUFPdUMsZ0JBQ2hCLEVBQUUsR0FBR0ssYUFBYXpDLFFBQVEsYUFBYUMsV0FBVSxvQkFBSXlDLEtBQUssSUFBR0MsWUFBWSxHQUFHQyxNQUFNLEdBQUcsRUFBRSxHQUFHQyxRQUFRLEtBQUssR0FBRyxFQUFFLElBQzVHSjtBQUFBQSxNQUNOO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxRQUFNSyxtQkFBbUJBLENBQUNWLGtCQUFrQjtBQUMxQ0MsWUFBUUMsSUFBSSx1QkFBdUJGLGFBQWE7QUFDaER4QztBQUFBQSxNQUFnQixDQUFBMkMsU0FDZEEsTUFBTUM7QUFBQUEsUUFBSSxDQUFBQyxnQkFDUkEsYUFBYTVDLE9BQU91QyxnQkFDaEIsRUFBRSxHQUFHSyxhQUFhekMsUUFBUSxnQkFBZ0JDLFVBQVUsS0FBSyxJQUN6RHdDO0FBQUFBLE1BQ047QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLFFBQU1NLHVCQUF1QixPQUFPWCxrQkFBa0I7QUFDcERDLFlBQVFDLElBQUksMkJBQTJCRixhQUFhO0FBQ3BEZixtQkFBZSxDQUFBa0IsVUFBUyxFQUFFLEdBQUdBLE1BQU0sQ0FBQ0gsYUFBYSxHQUFHLFVBQVUsRUFBRTtBQUdoRVksZUFBVyxNQUFNO0FBQ2YsWUFBTUMsVUFBVUMsS0FBS0MsT0FBTyxJQUFJO0FBQ2hDOUIscUJBQWUsQ0FBQWtCLFVBQVM7QUFBQSxRQUN0QixHQUFHQTtBQUFBQSxRQUNILENBQUNILGFBQWEsR0FBR2EsVUFBVSxZQUFZO0FBQUEsTUFDekMsRUFBRTtBQUFBLElBQ0osR0FBRyxHQUFJO0FBQUEsRUFDVDtBQUVBLFFBQU1HLGtCQUFrQkEsQ0FBQ1gsZ0JBQWdCO0FBQ3ZDeEIsMkJBQXVCd0IsV0FBVztBQUNsQ3RCLHVCQUFtQixJQUFJO0FBQUEsRUFDekI7QUFFQSxRQUFNa0MsbUJBQW1CQSxNQUFNO0FBQzdCaEIsWUFBUUMsSUFBSSw2QkFBNkJ0QixxQkFBcUJsQixJQUFJO0FBQ2xFcUIsdUJBQW1CLEtBQUs7QUFDeEJGLDJCQUF1QixJQUFJO0FBQUEsRUFDN0I7QUFFQSxTQUNFLHVCQUFDLGlaQUFJLFdBQVUsYUFFYjtBQUFBLDJCQUFDLDZhQUFJLFdBQVUscUNBQ2I7QUFBQSw2QkFBQyw2V0FDQztBQUFBLCtCQUFDLHVkQUFHLFdBQVUsd0NBQXVDLDRCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlFO0FBQUEsUUFDakUsdUJBQUMsbWZBQUUsV0FBVSw0QkFBMkIsK0RBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUY7QUFBQSxXQUZ6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLCtpQkFBTyxXQUFVLDBJQUNoQjtBQUFBLCtCQUFDLHlZQUFLLE1BQUssUUFBTyxNQUFNLE1BQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkI7QUFBQSxRQUMzQix1QkFBQywrWkFBSywrQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFCO0FBQUEsV0FGdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxJQUVBLHVCQUFDLHdjQUFJLFdBQVUsd0RBQ1p0Qix3QkFBYzZDO0FBQUFBLE1BQUksQ0FBQ0MsZ0JBQ2xCLHVCQUFDLHFmQUEwQixXQUFVLGlHQUNuQztBQUFBLCtCQUFDLG9iQUFJLFdBQVUseUNBQ2I7QUFBQSxpQ0FBQyx3YUFBSSxXQUFVLCtCQUNiO0FBQUEsbUNBQUMsd2RBQUksV0FBVSx1RUFDYixpQ0FBQyxzWkFBSyxNQUFNQSxhQUFhdkMsTUFBTSxNQUFNLElBQUksV0FBVSxrQkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUUsS0FEbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsOFdBQ0M7QUFBQSxxQ0FBQyx1YUFBRyxXQUFVLG1DQUFtQ3VDLHVCQUFhM0MsUUFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUU7QUFBQSxjQUNuRSx1QkFBQyx1YUFBRSxXQUFVLG9DQUFvQzJDLHVCQUFhMUMsZUFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEU7QUFBQSxpQkFGNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLGVBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFVBQ0NpQyxjQUFjUyxhQUFhekMsTUFBTTtBQUFBLGFBVnBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFFBRUEsdUJBQUMseVpBQUksV0FBVSxrQkFDYjtBQUFBLGlDQUFDLDhhQUFJLFdBQVUscUNBQ2I7QUFBQSxtQ0FBQywrY0FBSyxXQUFVLCtCQUE4Qix1QkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUQ7QUFBQSxZQUNwRHNCLGVBQWVtQixhQUFhekMsTUFBTTtBQUFBLGVBRnJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUVDeUMsYUFBYXhDLFlBQ1osdUJBQUMsOGFBQUksV0FBVSxxQ0FDYjtBQUFBLG1DQUFDLG9kQUFLLFdBQVUsK0JBQThCLDBCQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RDtBQUFBLFlBQ3hELHVCQUFDLHVhQUFLLFdBQVUsNkJBQTZCd0MsdUJBQWF4QyxZQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRTtBQUFBLGVBRnJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUdEbUIsY0FBY3FCLGFBQWE1QyxFQUFFLEtBQzVCLHVCQUFDLDhhQUFJLFdBQVUscUNBQ2I7QUFBQSxtQ0FBQyxzZEFBSyxXQUFVLCtCQUE4Qiw0QkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEQ7QUFBQSxZQUMxRCx1QkFBQyxpWEFBSyxXQUFXLFdBQ2Z1QixjQUFjcUIsYUFBYTVDLEVBQUUsTUFBTSxZQUFZLHdCQUMvQ3VCLGNBQWNxQixhQUFhNUMsRUFBRSxNQUFNLFlBQVksaUJBQWlCLFlBQVksSUFFM0V1Qix3QkFBY3FCLGFBQWE1QyxFQUFFLE1BQU0sWUFBWSxlQUMvQ3VCLGNBQWNxQixhQUFhNUMsRUFBRSxNQUFNLFlBQVksWUFBWSxZQUw5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU1BO0FBQUEsZUFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVNBO0FBQUEsYUF2Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlCQTtBQUFBLFFBRUEsdUJBQUMsa1pBQUksV0FBVSxhQUNaNEM7QUFBQUEsdUJBQWF6QyxXQUFXLGNBQ3ZCLHVCQUFDLHlaQUFJLFdBQVUsa0JBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTStDLHFCQUFxQk4sYUFBYTVDLEVBQUU7QUFBQSxnQkFDbkQsVUFBVXVCLGNBQWNxQixhQUFhNUMsRUFBRSxNQUFNO0FBQUEsZ0JBQzdDLFdBQVU7QUFBQSxnQkFFVHVCLHdCQUFjcUIsYUFBYTVDLEVBQUUsTUFBTSxZQUNsQyx1QkFBQyx5YkFBSSxXQUFVLDhDQUNiO0FBQUEseUNBQUMsMGVBQUksV0FBVSwyRkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1RztBQUFBLGtCQUN2Ryx1QkFBQyxxWkFBSyx1QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFhO0FBQUEscUJBRmY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQSxJQUVBO0FBQUE7QUFBQSxjQVhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWFBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTXVELGdCQUFnQlgsV0FBVztBQUFBLGdCQUMxQyxXQUFVO0FBQUEsZ0JBQTRHO0FBQUE7QUFBQSxjQUZ4SDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLGVBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUJBLElBRUE7QUFBQSxZQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUNDLFNBQVMsTUFBTU4sY0FBY00sYUFBYTVDLEVBQUU7QUFBQSxjQUM1QyxXQUFVO0FBQUEsY0FBNEc7QUFBQTtBQUFBLFlBRnhIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsVUFHRDRDLGFBQWF6QyxXQUFXLGVBQ3ZCO0FBQUEsWUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FDQyxTQUFTLE1BQU04QyxpQkFBaUJMLGFBQWE1QyxFQUFFO0FBQUEsY0FDL0MsV0FBVTtBQUFBLGNBQThGO0FBQUE7QUFBQSxZQUYxRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLGFBdkNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5Q0E7QUFBQSxXQWxGUTRDLGFBQWE1QyxJQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBbUZBO0FBQUEsSUFDRCxLQXRGSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUZBO0FBQUEsSUFFQ3FCLG1CQUFtQkYsdUJBQ2xCLHVCQUFDLGtiQUFJLFdBQVUsd0NBQ2IsaUNBQUMsbWNBQUksV0FBVSxzREFDYjtBQUFBLDZCQUFDLG1iQUFJLFdBQVUsd0NBQXVDLFNBQVMsTUFBTUcsbUJBQW1CLEtBQUssS0FBN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnRztBQUFBLE1BQ2hHLHVCQUFDLG9kQUFJLFdBQVUsbUVBQ2IsaUNBQUMsNFlBQUksV0FBVSxPQUNiO0FBQUEsK0JBQUMscWJBQUksV0FBVSwwQ0FDYjtBQUFBLGlDQUFDLHVkQUFHLFdBQVUsMkNBQTBDO0FBQUE7QUFBQSxZQUMzQ0gscUJBQXFCbEI7QUFBQUEsZUFEbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUNDLFNBQVMsTUFBTXFCLG1CQUFtQixLQUFLO0FBQUEsY0FDdkMsV0FBVTtBQUFBLGNBRVYsaUNBQUMsc1lBQUssTUFBSyxLQUFJLE1BQU0sTUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0I7QUFBQTtBQUFBLFlBSjFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsYUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUVBLHVCQUFDLGtaQUFJLFdBQVUsYUFDWkg7QUFBQUEsK0JBQXFCbkIsT0FBTyxXQUMzQixtQ0FDRTtBQUFBLG1DQUFDLDhhQUFJLFdBQVUscUNBQ2I7QUFBQSxxQ0FBQyxnZUFBTSxXQUFVLHlDQUF3Qyx5QkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0U7QUFBQSxjQUNsRSx1QkFBQywwZUFBTSxNQUFLLFlBQVcsZ0JBQWMsTUFBQyxXQUFVLDJEQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1RztBQUFBLGlCQUZ6RztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyw4YUFBSSxXQUFVLHFDQUNiO0FBQUEscUNBQUMsb2VBQU0sV0FBVSx5Q0FBd0MsNkJBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNFO0FBQUEsY0FDdEUsdUJBQUMsMGVBQU0sTUFBSyxZQUFXLGdCQUFjLE1BQUMsV0FBVSwyREFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUc7QUFBQSxpQkFGekc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsOGFBQUksV0FBVSxxQ0FDYjtBQUFBLHFDQUFDLGtlQUFNLFdBQVUseUNBQXdDLDJCQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvRTtBQUFBLGNBQ3BFLHVCQUFDLDBlQUFNLE1BQUssWUFBVyxnQkFBYyxNQUFDLFdBQVUsMkRBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVHO0FBQUEsaUJBRnpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLDhXQUNDO0FBQUEscUNBQUMsb2ZBQU0sV0FBVSxvREFBbUQsOEJBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtGO0FBQUEsY0FDbEYsdUJBQUMsNGZBQU8sV0FBVSw0RkFDaEI7QUFBQSx1Q0FBQywrYkFBTyxPQUFNLEtBQUksK0JBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlDO0FBQUEsZ0JBQ2pDLHVCQUFDLGljQUFPLE9BQU0sTUFBSyxVQUFRLE1BQUMsZ0NBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTRDO0FBQUEsZ0JBQzVDLHVCQUFDLGljQUFPLE9BQU0sTUFBSyxnQ0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbUM7QUFBQSxnQkFDbkMsdUJBQUMseWJBQU8sT0FBTSxNQUFLLDBCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2QjtBQUFBLG1CQUovQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsaUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLGVBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBc0JBO0FBQUEsVUFHRG1CLHFCQUFxQm5CLE9BQU8sWUFDM0IsbUNBQ0U7QUFBQSxtQ0FBQyw4V0FDQztBQUFBLHFDQUFDLGlmQUFNLFdBQVUsb0RBQW1ELDJCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErRTtBQUFBLGNBQy9FO0FBQUEsZ0JBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsYUFBWTtBQUFBO0FBQUEsZ0JBSGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBR2tEO0FBQUEsaUJBTHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxZQUNBLHVCQUFDLDhXQUNDO0FBQUEscUNBQUMsZ2ZBQU0sV0FBVSxvREFBbUQsMEJBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQThFO0FBQUEsY0FDOUU7QUFBQSxnQkFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFDVixhQUFZO0FBQUE7QUFBQSxnQkFIZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FHZ0M7QUFBQSxpQkFMbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBQ0EsdUJBQUMsOGFBQUksV0FBVSxxQ0FDYjtBQUFBLHFDQUFDLGllQUFNLFdBQVUseUNBQXdDLDBCQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtRTtBQUFBLGNBQ25FLHVCQUFDLDBlQUFNLE1BQUssWUFBVyxXQUFVLDJEQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3RjtBQUFBLGlCQUYxRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyw4YUFBSSxXQUFVLHFDQUNiO0FBQUEscUNBQUMsbWVBQU0sV0FBVSx5Q0FBd0MsNEJBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFFO0FBQUEsY0FDckUsdUJBQUMsMGVBQU0sTUFBSyxZQUFXLFdBQVUsMkRBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdGO0FBQUEsaUJBRjFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxlQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXlCQTtBQUFBLGFBckRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF1REE7QUFBQSxRQUVBLHVCQUFDLDhhQUFJLFdBQVUsbUNBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNc0IsbUJBQW1CLEtBQUs7QUFBQSxjQUN2QyxXQUFVO0FBQUEsY0FBc0Y7QUFBQTtBQUFBLFlBRmxHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsU0FBU2tDO0FBQUFBLGNBQ1QsV0FBVTtBQUFBLGNBQTRHO0FBQUE7QUFBQSxZQUZ4SDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLGFBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWFBO0FBQUEsV0FuRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW9GQSxLQXJGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBc0ZBO0FBQUEsU0F4RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlGQSxLQTFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMkZBO0FBQUEsSUFHRix1QkFBQyxpY0FBSSxXQUFVLHFEQUNiLGlDQUFDLHNhQUFJLFdBQVUsOEJBQ2I7QUFBQSw2QkFBQyx3YkFBSyxNQUFLLE9BQU0sTUFBTSxJQUFJLFdBQVUseUJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEQ7QUFBQSxNQUMxRCx1QkFBQywrWUFBSSxXQUFVLFVBQ2I7QUFBQSwrQkFBQyxnZUFBRyxXQUFVLHlDQUF3QyxrQ0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RTtBQUFBLFFBQ3hFLHVCQUFDLHFtQkFBRSxXQUFVLG9DQUNWMUQ7QUFBQUEsd0JBQWMyRCxPQUFPLENBQUFDLE1BQUtBLEdBQUd2RCxXQUFXLFdBQVcsR0FBR3dEO0FBQUFBLFVBQU87QUFBQSxVQUFLN0QsY0FBYzZEO0FBQUFBLFVBQU87QUFBQSxhQUQxRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNQTtBQUFBLFNBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBLEtBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdBO0FBQUEsT0FoTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlOQTtBQUVKO0FBQUU5RCxHQTdWSUQsY0FBWTtBQUFBZ0UsS0FBWmhFO0FBK1ZOLGVBQWVBO0FBQWEsSUFBQWdFO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZVN0YXRlIiwiSWNvbiIsIkludGVncmF0aW9ucyIsIl9zIiwiaW50ZWdyYXRpb25zIiwic2V0SW50ZWdyYXRpb25zIiwiaWQiLCJuYW1lIiwiZGVzY3JpcHRpb24iLCJzdGF0dXMiLCJsYXN0U3luYyIsImljb24iLCJjb25maWciLCJzeW5jRnJlcXVlbmN5IiwiYXV0b1N5bmMiLCJzeW5jQ29udGFjdHMiLCJzeW5jRW1haWxzIiwiY3JlYXRlTWVldGluZ3MiLCJzeW5jRXZlbnRzIiwic21zRW5hYmxlZCIsImNhbGxFbmFibGVkIiwid2ViaG9va1VybCIsImNoYW5uZWwiLCJub3RpZmljYXRpb25zIiwiZGVhbFVwZGF0ZXMiLCJzZWxlY3RlZEludGVncmF0aW9uIiwic2V0U2VsZWN0ZWRJbnRlZ3JhdGlvbiIsInNob3dDb25maWdNb2RhbCIsInNldFNob3dDb25maWdNb2RhbCIsInRlc3RSZXN1bHRzIiwic2V0VGVzdFJlc3VsdHMiLCJnZXRTdGF0dXNCYWRnZSIsInN0YXR1c1N0eWxlcyIsImNvbm5lY3RlZCIsImJnIiwidGV4dCIsImJvcmRlciIsImxhYmVsIiwiZGlzY29ubmVjdGVkIiwiZXJyb3IiLCJzdHlsZSIsImdldFN0YXR1c0ljb24iLCJpY29ucyIsImNvbG9yIiwiaGFuZGxlQ29ubmVjdCIsImludGVncmF0aW9uSWQiLCJjb25zb2xlIiwibG9nIiwicHJldiIsIm1hcCIsImludGVncmF0aW9uIiwiRGF0ZSIsInRvSVNPU3RyaW5nIiwic2xpY2UiLCJyZXBsYWNlIiwiaGFuZGxlRGlzY29ubmVjdCIsImhhbmRsZVRlc3RDb25uZWN0aW9uIiwic2V0VGltZW91dCIsInN1Y2Nlc3MiLCJNYXRoIiwicmFuZG9tIiwiaGFuZGxlQ29uZmlndXJlIiwiaGFuZGxlU2F2ZUNvbmZpZyIsImZpbHRlciIsImkiLCJsZW5ndGgiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkludGVncmF0aW9ucy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gc3JjL3BhZ2VzL3NldHRpbmdzLWFkbWluaXN0cmF0aW9uL2NvbXBvbmVudHMvSW50ZWdyYXRpb25zLmpzeFxyXG5pbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCBJY29uIGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvQXBwSWNvbic7XHJcblxyXG5jb25zdCBJbnRlZ3JhdGlvbnMgPSAoKSA9PiB7XHJcbiAgY29uc3QgW2ludGVncmF0aW9ucywgc2V0SW50ZWdyYXRpb25zXSA9IHVzZVN0YXRlKFtcclxuICAgIHtcclxuICAgICAgaWQ6ICdnbWFpbCcsXHJcbiAgICAgIG5hbWU6ICdHbWFpbCcsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiAnU3luYyBlbWFpbHMgYW5kIGNvbnRhY3RzIHdpdGggR21haWwnLFxyXG4gICAgICBzdGF0dXM6ICdjb25uZWN0ZWQnLFxyXG4gICAgICBsYXN0U3luYzogJzIwMjQtMDEtMTUgMTQ6MzAnLFxyXG4gICAgICBpY29uOiAnTWFpbCcsXHJcbiAgICAgIGNvbmZpZzoge1xyXG4gICAgICAgIHN5bmNGcmVxdWVuY3k6ICcxNSBtaW51dGVzJyxcclxuICAgICAgICBhdXRvU3luYzogdHJ1ZSxcclxuICAgICAgICBzeW5jQ29udGFjdHM6IHRydWUsXHJcbiAgICAgICAgc3luY0VtYWlsczogdHJ1ZVxyXG4gICAgICB9XHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBpZDogJ2dvb2dsZS1jYWxlbmRhcicsXHJcbiAgICAgIG5hbWU6ICdHb29nbGUgQ2FsZW5kYXInLFxyXG4gICAgICBkZXNjcmlwdGlvbjogJ1NjaGVkdWxlIG1lZXRpbmdzIGFuZCBzeW5jIGNhbGVuZGFyIGV2ZW50cycsXHJcbiAgICAgIHN0YXR1czogJ2Nvbm5lY3RlZCcsXHJcbiAgICAgIGxhc3RTeW5jOiAnMjAyNC0wMS0xNSAxNDoyNScsXHJcbiAgICAgIGljb246ICdDYWxlbmRhcicsXHJcbiAgICAgIGNvbmZpZzoge1xyXG4gICAgICAgIHN5bmNGcmVxdWVuY3k6ICc1IG1pbnV0ZXMnLFxyXG4gICAgICAgIGF1dG9TeW5jOiB0cnVlLFxyXG4gICAgICAgIGNyZWF0ZU1lZXRpbmdzOiB0cnVlLFxyXG4gICAgICAgIHN5bmNFdmVudHM6IHRydWVcclxuICAgICAgfVxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgaWQ6ICd0d2lsaW8nLFxyXG4gICAgICBuYW1lOiAnVHdpbGlvJyxcclxuICAgICAgZGVzY3JpcHRpb246ICdTZW5kIFNNUyBhbmQgbWFrZSBjYWxscyB0aHJvdWdoIFR3aWxpbycsXHJcbiAgICAgIHN0YXR1czogJ2Rpc2Nvbm5lY3RlZCcsXHJcbiAgICAgIGxhc3RTeW5jOiBudWxsLFxyXG4gICAgICBpY29uOiAnUGhvbmUnLFxyXG4gICAgICBjb25maWc6IHtcclxuICAgICAgICBzbXNFbmFibGVkOiBmYWxzZSxcclxuICAgICAgICBjYWxsRW5hYmxlZDogZmFsc2UsXHJcbiAgICAgICAgd2ViaG9va1VybDogJydcclxuICAgICAgfVxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgaWQ6ICdzbGFjaycsXHJcbiAgICAgIG5hbWU6ICdTbGFjaycsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiAnR2V0IG5vdGlmaWNhdGlvbnMgYW5kIHVwZGF0ZXMgaW4gU2xhY2snLFxyXG4gICAgICBzdGF0dXM6ICdlcnJvcicsXHJcbiAgICAgIGxhc3RTeW5jOiAnMjAyNC0wMS0xMCAwOToxNScsXHJcbiAgICAgIGljb246ICdNZXNzYWdlU3F1YXJlJyxcclxuICAgICAgY29uZmlnOiB7XHJcbiAgICAgICAgY2hhbm5lbDogJyNzYWxlcycsXHJcbiAgICAgICAgbm90aWZpY2F0aW9uczogdHJ1ZSxcclxuICAgICAgICBkZWFsVXBkYXRlczogdHJ1ZVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgXSk7XHJcblxyXG4gIGNvbnN0IFtzZWxlY3RlZEludGVncmF0aW9uLCBzZXRTZWxlY3RlZEludGVncmF0aW9uXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtzaG93Q29uZmlnTW9kYWwsIHNldFNob3dDb25maWdNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Rlc3RSZXN1bHRzLCBzZXRUZXN0UmVzdWx0c10gPSB1c2VTdGF0ZSh7fSk7XHJcblxyXG4gIGNvbnN0IGdldFN0YXR1c0JhZGdlID0gKHN0YXR1cykgPT4ge1xyXG4gICAgY29uc3Qgc3RhdHVzU3R5bGVzID0ge1xyXG4gICAgICBjb25uZWN0ZWQ6IHsgYmc6ICdiZy1zdWNjZXNzLTUwJywgdGV4dDogJ3RleHQtc3VjY2Vzcy02MDAnLCBib3JkZXI6ICdib3JkZXItc3VjY2Vzcy0xMDAnLCBsYWJlbDogJ0Nvbm5lY3RlZCcgfSxcclxuICAgICAgZGlzY29ubmVjdGVkOiB7IGJnOiAnYmctZXJyb3ItNTAnLCB0ZXh0OiAndGV4dC1lcnJvci02MDAnLCBib3JkZXI6ICdib3JkZXItZXJyb3ItMTAwJywgbGFiZWw6ICdEaXNjb25uZWN0ZWQnIH0sXHJcbiAgICAgIGVycm9yOiB7IGJnOiAnYmctd2FybmluZy01MCcsIHRleHQ6ICd0ZXh0LXdhcm5pbmctNjAwJywgYm9yZGVyOiAnYm9yZGVyLXdhcm5pbmctMTAwJywgbGFiZWw6ICdFcnJvcicgfVxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBzdHlsZSA9IHN0YXR1c1N0eWxlcz8uW3N0YXR1c10gfHwgc3RhdHVzU3R5bGVzPy5kaXNjb25uZWN0ZWQ7XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgcHgtMiBweS0xIHRleHQteHMgZm9udC1tZWRpdW0gcm91bmRlZCBib3JkZXIgJHtzdHlsZT8uYmd9ICR7c3R5bGU/LnRleHR9ICR7c3R5bGU/LmJvcmRlcn1gfT5cclxuICAgICAgICB7c3R5bGU/LmxhYmVsfVxyXG4gICAgICA8L3NwYW4+XHJcbiAgICApO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGdldFN0YXR1c0ljb24gPSAoc3RhdHVzKSA9PiB7XHJcbiAgICBjb25zdCBpY29ucyA9IHtcclxuICAgICAgY29ubmVjdGVkOiB7IG5hbWU6ICdDaGVja0NpcmNsZScsIGNvbG9yOiAndGV4dC1zdWNjZXNzJyB9LFxyXG4gICAgICBkaXNjb25uZWN0ZWQ6IHsgbmFtZTogJ1hDaXJjbGUnLCBjb2xvcjogJ3RleHQtZXJyb3InIH0sXHJcbiAgICAgIGVycm9yOiB7IG5hbWU6ICdBbGVydENpcmNsZScsIGNvbG9yOiAndGV4dC13YXJuaW5nJyB9XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGljb24gPSBpY29ucz8uW3N0YXR1c10gfHwgaWNvbnM/LmRpc2Nvbm5lY3RlZDtcclxuICAgIHJldHVybiA8SWNvbiBuYW1lPXtpY29uPy5uYW1lfSBzaXplPXsyMH0gY2xhc3NOYW1lPXtpY29uPy5jb2xvcn0gLz47XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ29ubmVjdCA9IChpbnRlZ3JhdGlvbklkKSA9PiB7XHJcbiAgICBjb25zb2xlLmxvZygnQ29ubmVjdGluZyB0bzonLCBpbnRlZ3JhdGlvbklkKTtcclxuICAgIC8vIFNpbXVsYXRlIGNvbm5lY3Rpb24gcHJvY2Vzc1xyXG4gICAgc2V0SW50ZWdyYXRpb25zKHByZXYgPT5cclxuICAgICAgcHJldj8ubWFwKGludGVncmF0aW9uID0+XHJcbiAgICAgICAgaW50ZWdyYXRpb24/LmlkID09PSBpbnRlZ3JhdGlvbklkXHJcbiAgICAgICAgICA/IHsgLi4uaW50ZWdyYXRpb24sIHN0YXR1czogJ2Nvbm5lY3RlZCcsIGxhc3RTeW5jOiBuZXcgRGF0ZSgpPy50b0lTT1N0cmluZygpPy5zbGljZSgwLCAxNik/LnJlcGxhY2UoJ1QnLCAnICcpIH1cclxuICAgICAgICAgIDogaW50ZWdyYXRpb25cclxuICAgICAgKVxyXG4gICAgKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVEaXNjb25uZWN0ID0gKGludGVncmF0aW9uSWQpID0+IHtcclxuICAgIGNvbnNvbGUubG9nKCdEaXNjb25uZWN0aW5nIGZyb206JywgaW50ZWdyYXRpb25JZCk7XHJcbiAgICBzZXRJbnRlZ3JhdGlvbnMocHJldiA9PlxyXG4gICAgICBwcmV2Py5tYXAoaW50ZWdyYXRpb24gPT5cclxuICAgICAgICBpbnRlZ3JhdGlvbj8uaWQgPT09IGludGVncmF0aW9uSWRcclxuICAgICAgICAgID8geyAuLi5pbnRlZ3JhdGlvbiwgc3RhdHVzOiAnZGlzY29ubmVjdGVkJywgbGFzdFN5bmM6IG51bGwgfVxyXG4gICAgICAgICAgOiBpbnRlZ3JhdGlvblxyXG4gICAgICApXHJcbiAgICApO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVRlc3RDb25uZWN0aW9uID0gYXN5bmMgKGludGVncmF0aW9uSWQpID0+IHtcclxuICAgIGNvbnNvbGUubG9nKCdUZXN0aW5nIGNvbm5lY3Rpb24gZm9yOicsIGludGVncmF0aW9uSWQpO1xyXG4gICAgc2V0VGVzdFJlc3VsdHMocHJldiA9PiAoeyAuLi5wcmV2LCBbaW50ZWdyYXRpb25JZF06ICd0ZXN0aW5nJyB9KSk7XHJcbiAgICBcclxuICAgIC8vIFNpbXVsYXRlIHRlc3RcclxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICBjb25zdCBzdWNjZXNzID0gTWF0aC5yYW5kb20oKSA+IDAuMzsgLy8gNzAlIHN1Y2Nlc3MgcmF0ZVxyXG4gICAgICBzZXRUZXN0UmVzdWx0cyhwcmV2ID0+ICh7IFxyXG4gICAgICAgIC4uLnByZXYsIFxyXG4gICAgICAgIFtpbnRlZ3JhdGlvbklkXTogc3VjY2VzcyA/ICdzdWNjZXNzJyA6ICdlcnJvcicgXHJcbiAgICAgIH0pKTtcclxuICAgIH0sIDIwMDApO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNvbmZpZ3VyZSA9IChpbnRlZ3JhdGlvbikgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRJbnRlZ3JhdGlvbihpbnRlZ3JhdGlvbik7XHJcbiAgICBzZXRTaG93Q29uZmlnTW9kYWwodHJ1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU2F2ZUNvbmZpZyA9ICgpID0+IHtcclxuICAgIGNvbnNvbGUubG9nKCdTYXZpbmcgY29uZmlndXJhdGlvbiBmb3I6Jywgc2VsZWN0ZWRJbnRlZ3JhdGlvbj8ubmFtZSk7XHJcbiAgICBzZXRTaG93Q29uZmlnTW9kYWwoZmFsc2UpO1xyXG4gICAgc2V0U2VsZWN0ZWRJbnRlZ3JhdGlvbihudWxsKTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cclxuICAgICAgey8qIEhlYWRlciAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXRleHQtcHJpbWFyeVwiPkludGVncmF0aW9uczwvaDI+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5IG10LTFcIj5NYW5hZ2UgQVBJIGNvbm5lY3Rpb25zIGFuZCB0aGlyZC1wYXJ0eSBzZXJ2aWNlczwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJnLXByaW1hcnkgdGV4dC13aGl0ZSBweC00IHB5LTIgcm91bmRlZC1sZyBob3ZlcjpiZy1wcmltYXJ5LTYwMCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTAgZWFzZS1zbW9vdGggZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCI+XHJcbiAgICAgICAgICA8SWNvbiBuYW1lPVwiUGx1c1wiIHNpemU9ezE2fSAvPlxyXG4gICAgICAgICAgPHNwYW4+QWRkIEludGVncmF0aW9uPC9zcGFuPlxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgey8qIEludGVncmF0aW9ucyBHcmlkICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgZ2FwLTZcIj5cclxuICAgICAgICB7aW50ZWdyYXRpb25zPy5tYXAoKGludGVncmF0aW9uKSA9PiAoXHJcbiAgICAgICAgICA8ZGl2IGtleT17aW50ZWdyYXRpb24/LmlkfSBjbGFzc05hbWU9XCJiZy1zdXJmYWNlIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ib3JkZXIgcC02IGhvdmVyOnNoYWRvdy1tZCB0cmFuc2l0aW9uLXNoYWRvdyBkdXJhdGlvbi0xNTBcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBtYi00XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTNcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIGJnLXByaW1hcnktNTAgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPXtpbnRlZ3JhdGlvbj8uaWNvbn0gc2l6ZT17MjB9IGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeVwiIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtdGV4dC1wcmltYXJ5XCI+e2ludGVncmF0aW9uPy5uYW1lfTwvaDM+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC10ZXh0LXNlY29uZGFyeSBtdC0xXCI+e2ludGVncmF0aW9uPy5kZXNjcmlwdGlvbn08L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICB7Z2V0U3RhdHVzSWNvbihpbnRlZ3JhdGlvbj8uc3RhdHVzKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMyBtYi00XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC10ZXh0LXNlY29uZGFyeVwiPlN0YXR1czo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICB7Z2V0U3RhdHVzQmFkZ2UoaW50ZWdyYXRpb24/LnN0YXR1cyl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAge2ludGVncmF0aW9uPy5sYXN0U3luYyAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtdGV4dC1zZWNvbmRhcnlcIj5MYXN0IFN5bmM6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtdGV4dC1wcmltYXJ5XCI+e2ludGVncmF0aW9uPy5sYXN0U3luY308L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIHt0ZXN0UmVzdWx0cz8uW2ludGVncmF0aW9uPy5pZF0gJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+VGVzdCBSZXN1bHQ6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LXNtICR7XHJcbiAgICAgICAgICAgICAgICAgICAgdGVzdFJlc3VsdHM/LltpbnRlZ3JhdGlvbj8uaWRdID09PSAndGVzdGluZycgPyAndGV4dC10ZXh0LXNlY29uZGFyeScgOlxyXG4gICAgICAgICAgICAgICAgICAgIHRlc3RSZXN1bHRzPy5baW50ZWdyYXRpb24/LmlkXSA9PT0gJ3N1Y2Nlc3MnID8gJ3RleHQtc3VjY2VzcycgOiAndGV4dC1lcnJvcidcclxuICAgICAgICAgICAgICAgICAgfWB9PlxyXG4gICAgICAgICAgICAgICAgICAgIHt0ZXN0UmVzdWx0cz8uW2ludGVncmF0aW9uPy5pZF0gPT09ICd0ZXN0aW5nJyA/ICdUZXN0aW5nLi4uJyA6XHJcbiAgICAgICAgICAgICAgICAgICAgIHRlc3RSZXN1bHRzPy5baW50ZWdyYXRpb24/LmlkXSA9PT0gJ3N1Y2Nlc3MnID8gJ1N1Y2Nlc3MnIDogJ0ZhaWxlZCd9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICB7aW50ZWdyYXRpb24/LnN0YXR1cyA9PT0gJ2Nvbm5lY3RlZCcgPyAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggc3BhY2UteC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVUZXN0Q29ubmVjdGlvbihpbnRlZ3JhdGlvbj8uaWQpfVxyXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXt0ZXN0UmVzdWx0cz8uW2ludGVncmF0aW9uPy5pZF0gPT09ICd0ZXN0aW5nJ31cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgcHgtMyBweS0yIHRleHQtc20gYmctYmFja2dyb3VuZCB0ZXh0LXRleHQtcHJpbWFyeSByb3VuZGVkIGhvdmVyOmJnLXN1cmZhY2UtaG92ZXIgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwIGRpc2FibGVkOm9wYWNpdHktNTAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHt0ZXN0UmVzdWx0cz8uW2ludGVncmF0aW9uPy5pZF0gPT09ICd0ZXN0aW5nJyA/IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgc3BhY2UteC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy00IGgtNCBib3JkZXItMiBib3JkZXItdGV4dC1zZWNvbmRhcnkgYm9yZGVyLXQtdHJhbnNwYXJlbnQgcm91bmRlZC1mdWxsIGFuaW1hdGUtc3BpblwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5UZXN0aW5nPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICdUZXN0IENvbm5lY3Rpb24nXHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVDb25maWd1cmUoaW50ZWdyYXRpb24pfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBweC0zIHB5LTIgdGV4dC1zbSBiZy1wcmltYXJ5IHRleHQtd2hpdGUgcm91bmRlZCBob3ZlcjpiZy1wcmltYXJ5LTYwMCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTBcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgQ29uZmlndXJlXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQ29ubmVjdChpbnRlZ3JhdGlvbj8uaWQpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIHRleHQtc20gYmctcHJpbWFyeSB0ZXh0LXdoaXRlIHJvdW5kZWQgaG92ZXI6YmctcHJpbWFyeS02MDAgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQ29ubmVjdFxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICB7aW50ZWdyYXRpb24/LnN0YXR1cyA9PT0gJ2Nvbm5lY3RlZCcgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEaXNjb25uZWN0KGludGVncmF0aW9uPy5pZCl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgdGV4dC1zbSB0ZXh0LWVycm9yIGhvdmVyOmJnLWVycm9yLTUwIHJvdW5kZWQgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgRGlzY29ubmVjdFxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIHsvKiBDb25maWd1cmF0aW9uIE1vZGFsICovfVxyXG4gICAgICB7c2hvd0NvbmZpZ01vZGFsICYmIHNlbGVjdGVkSW50ZWdyYXRpb24gJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTEyMDAgb3ZlcmZsb3cteS1hdXRvXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG1pbi1oLXNjcmVlbiBweC00XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBiZy1ibGFjayBiZy1vcGFjaXR5LTUwXCIgb25DbGljaz17KCkgPT4gc2V0U2hvd0NvbmZpZ01vZGFsKGZhbHNlKX0+PC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc3VyZmFjZSByb3VuZGVkLWxnIHNoYWRvdy14bCBtYXgtdy1sZyB3LWZ1bGwgcmVsYXRpdmUgei0xMzAwXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTZcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXRleHQtcHJpbWFyeVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIENvbmZpZ3VyZSB7c2VsZWN0ZWRJbnRlZ3JhdGlvbj8ubmFtZX1cclxuICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dDb25maWdNb2RhbChmYWxzZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC10ZXh0LXNlY29uZGFyeSBob3Zlcjp0ZXh0LXRleHQtcHJpbWFyeSB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTBcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIlhcIiBzaXplPXsyMH0gLz5cclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgICAgICAge3NlbGVjdGVkSW50ZWdyYXRpb24/LmlkID09PSAnZ21haWwnICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnlcIj5BdXRvIFN5bmM8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgZGVmYXVsdENoZWNrZWQgY2xhc3NOYW1lPVwicm91bmRlZCBib3JkZXItYm9yZGVyIHRleHQtcHJpbWFyeSBmb2N1czpyaW5nLXByaW1hcnlcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeVwiPlN5bmMgQ29udGFjdHM8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgZGVmYXVsdENoZWNrZWQgY2xhc3NOYW1lPVwicm91bmRlZCBib3JkZXItYm9yZGVyIHRleHQtcHJpbWFyeSBmb2N1czpyaW5nLXByaW1hcnlcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeVwiPlN5bmMgRW1haWxzPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIGRlZmF1bHRDaGVja2VkIGNsYXNzTmFtZT1cInJvdW5kZWQgYm9yZGVyLWJvcmRlciB0ZXh0LXByaW1hcnkgZm9jdXM6cmluZy1wcmltYXJ5XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItMVwiPlN5bmMgRnJlcXVlbmN5PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdCBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1wcmltYXJ5IGZvY3VzOmJvcmRlci1wcmltYXJ5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIjVcIj5FdmVyeSA1IG1pbnV0ZXM8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiMTVcIiBzZWxlY3RlZD5FdmVyeSAxNSBtaW51dGVzPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIjMwXCI+RXZlcnkgMzAgbWludXRlczwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCI2MFwiPkV2ZXJ5IGhvdXI8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZEludGVncmF0aW9uPy5pZCA9PT0gJ3R3aWxpbycgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSBtYi0xXCI+QWNjb3VudCBTSUQ8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLWxnIGZvY3VzOnJpbmctcHJpbWFyeSBmb2N1czpib3JkZXItcHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJBQ3h4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItMVwiPkF1dGggVG9rZW48L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ib3JkZXIgcm91bmRlZC1sZyBmb2N1czpyaW5nLXByaW1hcnkgZm9jdXM6Ym9yZGVyLXByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgYXV0aCB0b2tlblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5XCI+RW5hYmxlIFNNUzwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIiBjbGFzc05hbWU9XCJyb3VuZGVkIGJvcmRlci1ib3JkZXIgdGV4dC1wcmltYXJ5IGZvY3VzOnJpbmctcHJpbWFyeVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5XCI+RW5hYmxlIENhbGxzPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIGNsYXNzTmFtZT1cInJvdW5kZWQgYm9yZGVyLWJvcmRlciB0ZXh0LXByaW1hcnkgZm9jdXM6cmluZy1wcmltYXJ5XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBzcGFjZS14LTMgbXQtNlwiPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0NvbmZpZ01vZGFsKGZhbHNlKX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC10ZXh0LXNlY29uZGFyeSBob3Zlcjp0ZXh0LXRleHQtcHJpbWFyeSB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTBcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU2F2ZUNvbmZpZ31cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1wcmltYXJ5IHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQtbGcgaG92ZXI6YmctcHJpbWFyeS02MDAgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwIGVhc2Utc21vb3RoXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFNhdmUgQ29uZmlndXJhdGlvblxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgICB7LyogSW50ZWdyYXRpb24gU3RhdHVzIFN1bW1hcnkgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYmFja2dyb3VuZCBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLWxnIHAtNFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBzcGFjZS14LTNcIj5cclxuICAgICAgICAgIDxJY29uIG5hbWU9XCJaYXBcIiBzaXplPXsxNn0gY2xhc3NOYW1lPVwidGV4dC1wcmltYXJ5IG10LTAuNVwiIC8+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgdGV4dC1zbVwiPkludGVncmF0aW9uIEhlYWx0aDwvaDQ+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtdGV4dC1zZWNvbmRhcnkgdGV4dC1zbSBtdC0xXCI+XHJcbiAgICAgICAgICAgICAge2ludGVncmF0aW9ucz8uZmlsdGVyKGkgPT4gaT8uc3RhdHVzID09PSAnY29ubmVjdGVkJyk/Lmxlbmd0aH0gb2Yge2ludGVncmF0aW9ucz8ubGVuZ3RofSBpbnRlZ3JhdGlvbnMgYXJlIGNvbm5lY3RlZCBhbmQgd29ya2luZyBwcm9wZXJseS5cclxuICAgICAgICAgICAgICBSZWd1bGFyIHRlc3RpbmcgZW5zdXJlcyBvcHRpbWFsIHBlcmZvcm1hbmNlLlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgSW50ZWdyYXRpb25zOyJdLCJmaWxlIjoiRDovY3VycmVudCBwcm9qZWN0cy9jbGF1ZGUtY29kZS9zcmMvcGFnZXMvc2V0dGluZ3MtYWRtaW5pc3RyYXRpb24vY29tcG9uZW50cy9JbnRlZ3JhdGlvbnMuanN4In0=