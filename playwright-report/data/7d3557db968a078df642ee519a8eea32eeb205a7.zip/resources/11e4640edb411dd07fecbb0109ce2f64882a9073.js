import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/sales-dashboard/components/QuickActions.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=44ab9529";
import Icon from "/src/components/AppIcon.jsx";
const QuickActions = () => {
  _s();
  const [showAddDealModal, setShowAddDealModal] = useState(false);
  const [showAddContactModal, setShowAddContactModal] = useState(false);
  const quickActions = [
    {
      id: "add-deal",
      title: "Add New Deal",
      description: "Create a new sales opportunity",
      icon: "Plus",
      color: "bg-primary text-white",
      hoverColor: "hover:bg-primary-700",
      action: () => setShowAddDealModal(true)
    },
    {
      id: "add-contact",
      title: "Add Contact",
      description: "Add a new customer contact",
      icon: "UserPlus",
      color: "bg-success text-white",
      hoverColor: "hover:bg-success-600",
      action: () => setShowAddContactModal(true)
    },
    {
      id: "schedule-meeting",
      title: "Schedule Meeting",
      description: "Book a call or demo",
      icon: "Calendar",
      color: "bg-accent text-white",
      hoverColor: "hover:bg-accent-600",
      action: () => window.open("https://calendar.google.com", "_blank")
    },
    {
      id: "send-email",
      title: "Send Email",
      description: "Compose and send email",
      icon: "Mail",
      color: "bg-secondary text-white",
      hoverColor: "hover:bg-secondary-600",
      action: () => window.open("mailto:", "_blank")
    }
  ];
  const shortcuts = [
    { title: "Deal Management", path: "/deal-management", icon: "Target" },
    { title: "Contact Management", path: "/contact-management", icon: "Users" },
    { title: "Pipeline Analytics", path: "/pipeline-analytics", icon: "TrendingUp" },
    { title: "Activity Timeline", path: "/activity-timeline", icon: "Clock" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:56:4", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "56", "data-component-file": "QuickActions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-6%22%7D", className: "card p-6", children: [
    /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:57:6", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "57", "data-component-file": "QuickActions.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%20mb-6%22%2C%22textContent%22%3A%22Quick%20Actions%22%7D", className: "text-lg font-semibold text-text-primary mb-6", children: "Quick Actions" }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
      lineNumber: 57,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:59:6", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "59", "data-component-file": "QuickActions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-2%20gap-3%20mb-6%22%7D", className: "grid grid-cols-2 gap-3 mb-6", children: quickActions?.map(
      (action) => /* @__PURE__ */ jsxDEV(
        "button",
        {
          "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:61:8",
          "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx",
          "data-component-line": "61",
          "data-component-file": "QuickActions.jsx",
          "data-component-name": "button",
          "data-component-content": "%7B%22elementName%22%3A%22button%22%7D",
          onClick: action?.action,
          className: `${action?.color} ${action?.hoverColor} p-4 rounded-lg transition-all duration-150 text-left group`,
          children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:66:12", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "66", "data-component-file": "QuickActions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-3%20mb-2%22%7D", className: "flex items-center space-x-3 mb-2", children: [
              /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:67:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "67", "data-component-file": "QuickActions.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%7D", name: action?.icon, size: 20 }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
                lineNumber: 67,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:68:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "68", "data-component-file": "QuickActions.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22font-medium%20text-sm%22%7D", className: "font-medium text-sm", children: action?.title }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
                lineNumber: 68,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
              lineNumber: 66,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:70:12", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "70", "data-component-file": "QuickActions.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-xs%20opacity-90%22%7D", className: "text-xs opacity-90", children: action?.description }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
              lineNumber: 70,
              columnNumber: 13
            }, this)
          ]
        },
        action?.id,
        true,
        {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
          lineNumber: 61,
          columnNumber: 9
        },
        this
      )
    ) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
      lineNumber: 59,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:75:6", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "75", "data-component-file": "QuickActions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22border-t%20border-border%20pt-6%22%7D", className: "border-t border-border pt-6", children: [
      /* @__PURE__ */ jsxDEV("h4", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:76:8", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "76", "data-component-file": "QuickActions.jsx", "data-component-name": "h4", "data-component-content": "%7B%22elementName%22%3A%22h4%22%2C%22className%22%3A%22text-sm%20font-medium%20text-text-primary%20mb-4%22%2C%22textContent%22%3A%22Quick%20Navigation%22%7D", className: "text-sm font-medium text-text-primary mb-4", children: "Quick Navigation" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
        lineNumber: 76,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:77:8", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "77", "data-component-file": "QuickActions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-2%22%7D", className: "space-y-2", children: shortcuts?.map(
        (shortcut) => /* @__PURE__ */ jsxDEV(
          Link,
          {
            "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:79:10",
            "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx",
            "data-component-line": "79",
            "data-component-file": "QuickActions.jsx",
            "data-component-name": "Link",
            "data-component-content": "%7B%22elementName%22%3A%22Link%22%2C%22className%22%3A%22flex%20items-center%20space-x-3%20p-2%20rounded-lg%20text-text-secondary%20hover%3Atext-text-primary%20hover%3Abg-surface-hover%20transition-all%20duration-150%22%7D",
            to: shortcut?.path,
            className: "flex items-center space-x-3 p-2 rounded-lg text-text-secondary hover:text-text-primary hover:bg-surface-hover transition-all duration-150",
            children: [
              /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:84:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "84", "data-component-file": "QuickActions.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%7D", name: shortcut?.icon, size: 16 }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
                lineNumber: 84,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:85:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "85", "data-component-file": "QuickActions.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%22%7D", className: "text-sm", children: shortcut?.title }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
                lineNumber: 85,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:86:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "86", "data-component-file": "QuickActions.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22ChevronRight%22%2C%22className%22%3A%22ml-auto%22%7D", name: "ChevronRight", size: 14, className: "ml-auto" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
                lineNumber: 86,
                columnNumber: 15
              }, this)
            ]
          },
          shortcut?.path,
          true,
          {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
            lineNumber: 79,
            columnNumber: 11
          },
          this
        )
      ) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
        lineNumber: 77,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
      lineNumber: 75,
      columnNumber: 7
    }, this),
    showAddDealModal && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:93:6", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "93", "data-component-file": "QuickActions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20bg-black%20bg-opacity-50%20flex%20items-center%20justify-center%20z-1300%22%7D", className: "fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-1300", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:94:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "94", "data-component-file": "QuickActions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20rounded-lg%20p-6%20w-full%20max-w-md%20mx-4%22%7D", className: "bg-surface rounded-lg p-6 w-full max-w-md mx-4", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:95:12", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "95", "data-component-file": "QuickActions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%20mb-4%22%7D", className: "flex items-center justify-between mb-4", children: [
        /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:96:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "96", "data-component-file": "QuickActions.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%2C%22textContent%22%3A%22Add%20New%20Deal%22%7D", className: "text-lg font-semibold text-text-primary", children: "Add New Deal" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
          lineNumber: 96,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:97:14",
            "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx",
            "data-component-line": "97",
            "data-component-file": "QuickActions.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22text-text-secondary%20hover%3Atext-text-primary%22%7D",
            onClick: () => setShowAddDealModal(false),
            className: "text-text-secondary hover:text-text-primary",
            children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:101:16", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "101", "data-component-file": "QuickActions.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22X%22%7D", name: "X", size: 20 }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
              lineNumber: 101,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
            lineNumber: 97,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
        lineNumber: 95,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:105:12", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "105", "data-component-file": "QuickActions.jsx", "data-component-name": "form", "data-component-content": "%7B%22elementName%22%3A%22form%22%2C%22className%22%3A%22space-y-4%22%7D", className: "space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:106:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "106", "data-component-file": "QuickActions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:107:16", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "107", "data-component-file": "QuickActions.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-2%22%2C%22textContent%22%3A%22Deal%20Title%22%7D", className: "block text-sm font-medium text-text-primary mb-2", children: "Deal Title" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
            lineNumber: 107,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:110:16",
              "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx",
              "data-component-line": "110",
              "data-component-file": "QuickActions.jsx",
              "data-component-name": "input",
              "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22text%22%2C%22className%22%3A%22input-field%22%7D",
              type: "text",
              className: "input-field",
              placeholder: "Enter deal title"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
              lineNumber: 110,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
          lineNumber: 106,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:117:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "117", "data-component-file": "QuickActions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:118:16", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "118", "data-component-file": "QuickActions.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-2%22%2C%22textContent%22%3A%22Company%22%7D", className: "block text-sm font-medium text-text-primary mb-2", children: "Company" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
            lineNumber: 118,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:121:16",
              "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx",
              "data-component-line": "121",
              "data-component-file": "QuickActions.jsx",
              "data-component-name": "input",
              "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22text%22%2C%22className%22%3A%22input-field%22%7D",
              type: "text",
              className: "input-field",
              placeholder: "Company name"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
              lineNumber: 121,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
          lineNumber: 117,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:128:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "128", "data-component-file": "QuickActions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:129:16", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "129", "data-component-file": "QuickActions.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-2%22%2C%22textContent%22%3A%22Deal%20Value%22%7D", className: "block text-sm font-medium text-text-primary mb-2", children: "Deal Value" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
            lineNumber: 129,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:132:16",
              "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx",
              "data-component-line": "132",
              "data-component-file": "QuickActions.jsx",
              "data-component-name": "input",
              "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22number%22%2C%22className%22%3A%22input-field%22%7D",
              type: "number",
              className: "input-field",
              placeholder: "0"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
              lineNumber: 132,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
          lineNumber: 128,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:139:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "139", "data-component-file": "QuickActions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20space-x-3%20pt-4%22%7D", className: "flex space-x-3 pt-4", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:140:16",
              "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx",
              "data-component-line": "140",
              "data-component-file": "QuickActions.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22button%22%2C%22className%22%3A%22flex-1%20px-4%20py-2%20border%20border-border%20rounded-lg%20text-text-secondary%20hover%3Atext-text-primary%20hover%3Abg-surface-hover%20transition-all%20duration-150%22%2C%22textContent%22%3A%22Cancel%22%7D",
              type: "button",
              onClick: () => setShowAddDealModal(false),
              className: "flex-1 px-4 py-2 border border-border rounded-lg text-text-secondary hover:text-text-primary hover:bg-surface-hover transition-all duration-150",
              children: "Cancel"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
              lineNumber: 140,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:147:16",
              "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx",
              "data-component-line": "147",
              "data-component-file": "QuickActions.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22submit%22%2C%22className%22%3A%22flex-1%20btn-primary%22%2C%22textContent%22%3A%22Create%20Deal%22%7D",
              type: "submit",
              className: "flex-1 btn-primary",
              onClick: () => setShowAddDealModal(false),
              children: "Create Deal"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
              lineNumber: 147,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
          lineNumber: 139,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
        lineNumber: 105,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
      lineNumber: 94,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
      lineNumber: 93,
      columnNumber: 7
    }, this),
    showAddContactModal && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:161:6", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "161", "data-component-file": "QuickActions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22fixed%20inset-0%20bg-black%20bg-opacity-50%20flex%20items-center%20justify-center%20z-1300%22%7D", className: "fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-1300", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:162:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "162", "data-component-file": "QuickActions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20rounded-lg%20p-6%20w-full%20max-w-md%20mx-4%22%7D", className: "bg-surface rounded-lg p-6 w-full max-w-md mx-4", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:163:12", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "163", "data-component-file": "QuickActions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%20mb-4%22%7D", className: "flex items-center justify-between mb-4", children: [
        /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:164:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "164", "data-component-file": "QuickActions.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%2C%22textContent%22%3A%22Add%20New%20Contact%22%7D", className: "text-lg font-semibold text-text-primary", children: "Add New Contact" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
          lineNumber: 164,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:165:14",
            "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx",
            "data-component-line": "165",
            "data-component-file": "QuickActions.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22text-text-secondary%20hover%3Atext-text-primary%22%7D",
            onClick: () => setShowAddContactModal(false),
            className: "text-text-secondary hover:text-text-primary",
            children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:169:16", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "169", "data-component-file": "QuickActions.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22X%22%7D", name: "X", size: 20 }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
              lineNumber: 169,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
            lineNumber: 165,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
        lineNumber: 163,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:173:12", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "173", "data-component-file": "QuickActions.jsx", "data-component-name": "form", "data-component-content": "%7B%22elementName%22%3A%22form%22%2C%22className%22%3A%22space-y-4%22%7D", className: "space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:174:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "174", "data-component-file": "QuickActions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:175:16", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "175", "data-component-file": "QuickActions.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-2%22%2C%22textContent%22%3A%22Full%20Name%22%7D", className: "block text-sm font-medium text-text-primary mb-2", children: "Full Name" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
            lineNumber: 175,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:178:16",
              "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx",
              "data-component-line": "178",
              "data-component-file": "QuickActions.jsx",
              "data-component-name": "input",
              "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22text%22%2C%22className%22%3A%22input-field%22%7D",
              type: "text",
              className: "input-field",
              placeholder: "Enter full name"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
              lineNumber: 178,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
          lineNumber: 174,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:185:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "185", "data-component-file": "QuickActions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:186:16", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "186", "data-component-file": "QuickActions.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-2%22%2C%22textContent%22%3A%22Email%22%7D", className: "block text-sm font-medium text-text-primary mb-2", children: "Email" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
            lineNumber: 186,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:189:16",
              "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx",
              "data-component-line": "189",
              "data-component-file": "QuickActions.jsx",
              "data-component-name": "input",
              "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22email%22%2C%22className%22%3A%22input-field%22%7D",
              type: "email",
              className: "input-field",
              placeholder: "email@company.com"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
              lineNumber: 189,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
          lineNumber: 185,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:196:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "196", "data-component-file": "QuickActions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:197:16", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "197", "data-component-file": "QuickActions.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22block%20text-sm%20font-medium%20text-text-primary%20mb-2%22%2C%22textContent%22%3A%22Company%22%7D", className: "block text-sm font-medium text-text-primary mb-2", children: "Company" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
            lineNumber: 197,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:200:16",
              "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx",
              "data-component-line": "200",
              "data-component-file": "QuickActions.jsx",
              "data-component-name": "input",
              "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22text%22%2C%22className%22%3A%22input-field%22%7D",
              type: "text",
              className: "input-field",
              placeholder: "Company name"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
              lineNumber: 200,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
          lineNumber: 196,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:207:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx", "data-component-line": "207", "data-component-file": "QuickActions.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20space-x-3%20pt-4%22%7D", className: "flex space-x-3 pt-4", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:208:16",
              "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx",
              "data-component-line": "208",
              "data-component-file": "QuickActions.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22button%22%2C%22className%22%3A%22flex-1%20px-4%20py-2%20border%20border-border%20rounded-lg%20text-text-secondary%20hover%3Atext-text-primary%20hover%3Abg-surface-hover%20transition-all%20duration-150%22%2C%22textContent%22%3A%22Cancel%22%7D",
              type: "button",
              onClick: () => setShowAddContactModal(false),
              className: "flex-1 px-4 py-2 border border-border rounded-lg text-text-secondary hover:text-text-primary hover:bg-surface-hover transition-all duration-150",
              children: "Cancel"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
              lineNumber: 208,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx:215:16",
              "data-component-path": "src\\pages\\sales-dashboard\\components\\QuickActions.jsx",
              "data-component-line": "215",
              "data-component-file": "QuickActions.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22type%22%3A%22submit%22%2C%22className%22%3A%22flex-1%20btn-primary%22%2C%22textContent%22%3A%22Add%20Contact%22%7D",
              type: "submit",
              className: "flex-1 btn-primary",
              onClick: () => setShowAddContactModal(false),
              children: "Add Contact"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
              lineNumber: 215,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
          lineNumber: 207,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
        lineNumber: 173,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
      lineNumber: 162,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
      lineNumber: 161,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx",
    lineNumber: 56,
    columnNumber: 5
  }, this);
};
_s(QuickActions, "jIGXXmSKwBQ28aiCeuAVN2orDNw=");
_c = QuickActions;
export default QuickActions;
var _c;
$RefreshReg$(_c, "QuickActions");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/sales-dashboard/components/QuickActions.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0RNOzJCQXhETjtBQUFnQkEsTUFBUSxjQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3ZDLFNBQVNDLFlBQVk7QUFDckIsT0FBT0MsVUFBVTtBQUVqQixNQUFNQyxlQUFlQSxNQUFNO0FBQUFDLEtBQUE7QUFDekIsUUFBTSxDQUFDQyxrQkFBa0JDLG1CQUFtQixJQUFJTixTQUFTLEtBQUs7QUFDOUQsUUFBTSxDQUFDTyxxQkFBcUJDLHNCQUFzQixJQUFJUixTQUFTLEtBQUs7QUFFcEUsUUFBTVMsZUFBZTtBQUFBLElBQ25CO0FBQUEsTUFDRUMsSUFBSTtBQUFBLE1BQ0pDLE9BQU87QUFBQSxNQUNQQyxhQUFhO0FBQUEsTUFDYkMsTUFBTTtBQUFBLE1BQ05DLE9BQU87QUFBQSxNQUNQQyxZQUFZO0FBQUEsTUFDWkMsUUFBUUEsTUFBTVYsb0JBQW9CLElBQUk7QUFBQSxJQUN4QztBQUFBLElBQ0E7QUFBQSxNQUNFSSxJQUFJO0FBQUEsTUFDSkMsT0FBTztBQUFBLE1BQ1BDLGFBQWE7QUFBQSxNQUNiQyxNQUFNO0FBQUEsTUFDTkMsT0FBTztBQUFBLE1BQ1BDLFlBQVk7QUFBQSxNQUNaQyxRQUFRQSxNQUFNUix1QkFBdUIsSUFBSTtBQUFBLElBQzNDO0FBQUEsSUFDQTtBQUFBLE1BQ0VFLElBQUk7QUFBQSxNQUNKQyxPQUFPO0FBQUEsTUFDUEMsYUFBYTtBQUFBLE1BQ2JDLE1BQU07QUFBQSxNQUNOQyxPQUFPO0FBQUEsTUFDUEMsWUFBWTtBQUFBLE1BQ1pDLFFBQVFBLE1BQU1DLE9BQU9DLEtBQUssK0JBQStCLFFBQVE7QUFBQSxJQUNuRTtBQUFBLElBQ0E7QUFBQSxNQUNFUixJQUFJO0FBQUEsTUFDSkMsT0FBTztBQUFBLE1BQ1BDLGFBQWE7QUFBQSxNQUNiQyxNQUFNO0FBQUEsTUFDTkMsT0FBTztBQUFBLE1BQ1BDLFlBQVk7QUFBQSxNQUNaQyxRQUFRQSxNQUFNQyxPQUFPQyxLQUFLLFdBQVcsUUFBUTtBQUFBLElBQy9DO0FBQUEsRUFBQztBQUdILFFBQU1DLFlBQVk7QUFBQSxJQUNoQixFQUFFUixPQUFPLG1CQUFtQlMsTUFBTSxvQkFBb0JQLE1BQU0sU0FBUztBQUFBLElBQ3JFLEVBQUVGLE9BQU8sc0JBQXNCUyxNQUFNLHVCQUF1QlAsTUFBTSxRQUFRO0FBQUEsSUFDMUUsRUFBRUYsT0FBTyxzQkFBc0JTLE1BQU0sdUJBQXVCUCxNQUFNLGFBQWE7QUFBQSxJQUMvRSxFQUFFRixPQUFPLHFCQUFxQlMsTUFBTSxzQkFBc0JQLE1BQU0sUUFBUTtBQUFBLEVBQUM7QUFHM0UsU0FDRSx1QkFBQyxnWUFBSSxXQUFVLFlBQ2I7QUFBQSwyQkFBQyxpZEFBRyxXQUFVLGdEQUErQyw2QkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwRTtBQUFBLElBRTFFLHVCQUFDLHVaQUFJLFdBQVUsK0JBQ1pKLHdCQUFjWTtBQUFBQSxNQUFJLENBQUNMLFdBQ2xCO0FBQUEsUUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFFQyxTQUFTQSxRQUFRQTtBQUFBQSxVQUNqQixXQUFXLEdBQUdBLFFBQVFGLEtBQUssSUFBSUUsUUFBUUQsVUFBVTtBQUFBLFVBRWpEO0FBQUEsbUNBQUMsNlpBQUksV0FBVSxvQ0FDYjtBQUFBLHFDQUFDLDZWQUFLLE1BQU1DLFFBQVFILE1BQU0sTUFBTSxNQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtQztBQUFBLGNBQ25DLHVCQUFDLCtZQUFLLFdBQVUsdUJBQXVCRyxrQkFBUUwsU0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUQ7QUFBQSxpQkFGdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMscVlBQUUsV0FBVSxzQkFBc0JLLGtCQUFRSixlQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RDtBQUFBO0FBQUE7QUFBQSxRQVJsREksUUFBUU47QUFBQUEsUUFEZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BVUE7QUFBQSxJQUNELEtBYkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWNBO0FBQUEsSUFFQSx1QkFBQyxxWkFBSSxXQUFVLCtCQUNiO0FBQUEsNkJBQUMsa2RBQUcsV0FBVSw4Q0FBNkMsZ0NBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkU7QUFBQSxNQUMzRSx1QkFBQywrWEFBSSxXQUFVLGFBQ1pTLHFCQUFXRTtBQUFBQSxRQUFJLENBQUNDLGFBQ2Y7QUFBQSxVQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUVDLElBQUlBLFVBQVVGO0FBQUFBLFlBQ2QsV0FBVTtBQUFBLFlBRVY7QUFBQSxxQ0FBQyw2VkFBSyxNQUFNRSxVQUFVVCxNQUFNLE1BQU0sTUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUM7QUFBQSxjQUNyQyx1QkFBQyxpWUFBSyxXQUFVLFdBQVdTLG9CQUFVWCxTQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyQztBQUFBLGNBQzNDLHVCQUFDLGlhQUFLLE1BQUssZ0JBQWUsTUFBTSxJQUFJLFdBQVUsYUFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUQ7QUFBQTtBQUFBO0FBQUEsVUFObERXLFVBQVVGO0FBQUFBLFVBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFRQTtBQUFBLE1BQ0QsS0FYSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBWUE7QUFBQSxTQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FlQTtBQUFBLElBRUNmLG9CQUNDLHVCQUFDLGdkQUFJLFdBQVUsZ0ZBQ2IsaUNBQUMsK2FBQUksV0FBVSxrREFDYjtBQUFBLDZCQUFDLG1hQUFJLFdBQVUsMENBQ2I7QUFBQSwrQkFBQyw0Y0FBRyxXQUFVLDJDQUEwQyw0QkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRTtBQUFBLFFBQ3BFO0FBQUEsVUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU1DLG9CQUFvQixLQUFLO0FBQUEsWUFDeEMsV0FBVTtBQUFBLFlBRVYsaUNBQUMsc1hBQUssTUFBSyxLQUFJLE1BQU0sTUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0I7QUFBQTtBQUFBLFVBSjFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsV0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxNQUVBLHVCQUFDLHFZQUFLLFdBQVUsYUFDZDtBQUFBLCtCQUFDLDhWQUNDO0FBQUEsaUNBQUMsZ2VBQU0sV0FBVSxvREFBbUQsMEJBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxXQUFVO0FBQUEsY0FDVixhQUFZO0FBQUE7QUFBQSxZQUhkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUdnQztBQUFBLGFBUGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFFBRUEsdUJBQUMsOFZBQ0M7QUFBQSxpQ0FBQywyZEFBTSxXQUFVLG9EQUFtRCx1QkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUNWLGFBQVk7QUFBQTtBQUFBLFlBSGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBRzRCO0FBQUEsYUFQOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFFQSx1QkFBQyw4VkFDQztBQUFBLGlDQUFDLGdlQUFNLFdBQVUsb0RBQW1ELDBCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQ1YsYUFBWTtBQUFBO0FBQUEsWUFIZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFHaUI7QUFBQSxhQVBuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxRQUVBLHVCQUFDLGdaQUFJLFdBQVUsdUJBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBUyxNQUFNQSxvQkFBb0IsS0FBSztBQUFBLGNBQ3hDLFdBQVU7QUFBQSxjQUFpSjtBQUFBO0FBQUEsWUFIN0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxXQUFVO0FBQUEsY0FDVixTQUFTLE1BQU1BLG9CQUFvQixLQUFLO0FBQUEsY0FBRTtBQUFBO0FBQUEsWUFINUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTUE7QUFBQSxhQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQTtBQUFBLFdBakRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrREE7QUFBQSxTQTdERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOERBLEtBL0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnRUE7QUFBQSxJQUdEQyx1QkFDQyx1QkFBQyxrZEFBSSxXQUFVLGdGQUNiLGlDQUFDLGliQUFJLFdBQVUsa0RBQ2I7QUFBQSw2QkFBQyxxYUFBSSxXQUFVLDBDQUNiO0FBQUEsK0JBQUMsaWRBQUcsV0FBVSwyQ0FBMEMsK0JBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUU7QUFBQSxRQUN2RTtBQUFBLFVBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNQyx1QkFBdUIsS0FBSztBQUFBLFlBQzNDLFdBQVU7QUFBQSxZQUVWLGlDQUFDLHNYQUFLLE1BQUssS0FBSSxNQUFNLE1BQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdCO0FBQUE7QUFBQSxVQUoxQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLFdBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFFQSx1QkFBQyxxWUFBSyxXQUFVLGFBQ2Q7QUFBQSwrQkFBQyw4VkFDQztBQUFBLGlDQUFDLCtkQUFNLFdBQVUsb0RBQW1ELHlCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQ1YsYUFBWTtBQUFBO0FBQUEsWUFIZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFHK0I7QUFBQSxhQVBqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxRQUVBLHVCQUFDLDhWQUNDO0FBQUEsaUNBQUMseWRBQU0sV0FBVSxvREFBbUQscUJBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxXQUFVO0FBQUEsY0FDVixhQUFZO0FBQUE7QUFBQSxZQUhkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUdpQztBQUFBLGFBUG5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFFBRUEsdUJBQUMsOFZBQ0M7QUFBQSxpQ0FBQywyZEFBTSxXQUFVLG9EQUFtRCx1QkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUNWLGFBQVk7QUFBQTtBQUFBLFlBSGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBRzRCO0FBQUEsYUFQOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFFQSx1QkFBQyxnWkFBSSxXQUFVLHVCQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTUEsdUJBQXVCLEtBQUs7QUFBQSxjQUMzQyxXQUFVO0FBQUEsY0FBaUo7QUFBQTtBQUFBLFlBSDdKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQ1YsU0FBUyxNQUFNQSx1QkFBdUIsS0FBSztBQUFBLGNBQUU7QUFBQTtBQUFBLFlBSC9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsYUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQSxXQWpERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0RBO0FBQUEsU0E3REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThEQSxLQS9ERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0VBO0FBQUEsT0F6S0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJLQTtBQUVKO0FBQUVKLEdBaE9JRCxjQUFZO0FBQUFvQixLQUFacEI7QUFrT04sZUFBZUE7QUFBYSxJQUFBb0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiTGluayIsIkljb24iLCJRdWlja0FjdGlvbnMiLCJfcyIsInNob3dBZGREZWFsTW9kYWwiLCJzZXRTaG93QWRkRGVhbE1vZGFsIiwic2hvd0FkZENvbnRhY3RNb2RhbCIsInNldFNob3dBZGRDb250YWN0TW9kYWwiLCJxdWlja0FjdGlvbnMiLCJpZCIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJpY29uIiwiY29sb3IiLCJob3ZlckNvbG9yIiwiYWN0aW9uIiwid2luZG93Iiwib3BlbiIsInNob3J0Y3V0cyIsInBhdGgiLCJtYXAiLCJzaG9ydGN1dCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUXVpY2tBY3Rpb25zLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0IEljb24gZnJvbSAnY29tcG9uZW50cy9BcHBJY29uJztcclxuXHJcbmNvbnN0IFF1aWNrQWN0aW9ucyA9ICgpID0+IHtcclxuICBjb25zdCBbc2hvd0FkZERlYWxNb2RhbCwgc2V0U2hvd0FkZERlYWxNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dBZGRDb250YWN0TW9kYWwsIHNldFNob3dBZGRDb250YWN0TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBxdWlja0FjdGlvbnMgPSBbXHJcbiAgICB7XHJcbiAgICAgIGlkOiAnYWRkLWRlYWwnLFxyXG4gICAgICB0aXRsZTogJ0FkZCBOZXcgRGVhbCcsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiAnQ3JlYXRlIGEgbmV3IHNhbGVzIG9wcG9ydHVuaXR5JyxcclxuICAgICAgaWNvbjogJ1BsdXMnLFxyXG4gICAgICBjb2xvcjogJ2JnLXByaW1hcnkgdGV4dC13aGl0ZScsXHJcbiAgICAgIGhvdmVyQ29sb3I6ICdob3ZlcjpiZy1wcmltYXJ5LTcwMCcsXHJcbiAgICAgIGFjdGlvbjogKCkgPT4gc2V0U2hvd0FkZERlYWxNb2RhbCh0cnVlKVxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgaWQ6ICdhZGQtY29udGFjdCcsXHJcbiAgICAgIHRpdGxlOiAnQWRkIENvbnRhY3QnLFxyXG4gICAgICBkZXNjcmlwdGlvbjogJ0FkZCBhIG5ldyBjdXN0b21lciBjb250YWN0JyxcclxuICAgICAgaWNvbjogJ1VzZXJQbHVzJyxcclxuICAgICAgY29sb3I6ICdiZy1zdWNjZXNzIHRleHQtd2hpdGUnLFxyXG4gICAgICBob3ZlckNvbG9yOiAnaG92ZXI6Ymctc3VjY2Vzcy02MDAnLFxyXG4gICAgICBhY3Rpb246ICgpID0+IHNldFNob3dBZGRDb250YWN0TW9kYWwodHJ1ZSlcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGlkOiAnc2NoZWR1bGUtbWVldGluZycsXHJcbiAgICAgIHRpdGxlOiAnU2NoZWR1bGUgTWVldGluZycsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiAnQm9vayBhIGNhbGwgb3IgZGVtbycsXHJcbiAgICAgIGljb246ICdDYWxlbmRhcicsXHJcbiAgICAgIGNvbG9yOiAnYmctYWNjZW50IHRleHQtd2hpdGUnLFxyXG4gICAgICBob3ZlckNvbG9yOiAnaG92ZXI6YmctYWNjZW50LTYwMCcsXHJcbiAgICAgIGFjdGlvbjogKCkgPT4gd2luZG93Lm9wZW4oJ2h0dHBzOi8vY2FsZW5kYXIuZ29vZ2xlLmNvbScsICdfYmxhbmsnKVxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgaWQ6ICdzZW5kLWVtYWlsJyxcclxuICAgICAgdGl0bGU6ICdTZW5kIEVtYWlsJyxcclxuICAgICAgZGVzY3JpcHRpb246ICdDb21wb3NlIGFuZCBzZW5kIGVtYWlsJyxcclxuICAgICAgaWNvbjogJ01haWwnLFxyXG4gICAgICBjb2xvcjogJ2JnLXNlY29uZGFyeSB0ZXh0LXdoaXRlJyxcclxuICAgICAgaG92ZXJDb2xvcjogJ2hvdmVyOmJnLXNlY29uZGFyeS02MDAnLFxyXG4gICAgICBhY3Rpb246ICgpID0+IHdpbmRvdy5vcGVuKCdtYWlsdG86JywgJ19ibGFuaycpXHJcbiAgICB9XHJcbiAgXTtcclxuXHJcbiAgY29uc3Qgc2hvcnRjdXRzID0gW1xyXG4gICAgeyB0aXRsZTogJ0RlYWwgTWFuYWdlbWVudCcsIHBhdGg6ICcvZGVhbC1tYW5hZ2VtZW50JywgaWNvbjogJ1RhcmdldCcgfSxcclxuICAgIHsgdGl0bGU6ICdDb250YWN0IE1hbmFnZW1lbnQnLCBwYXRoOiAnL2NvbnRhY3QtbWFuYWdlbWVudCcsIGljb246ICdVc2VycycgfSxcclxuICAgIHsgdGl0bGU6ICdQaXBlbGluZSBBbmFseXRpY3MnLCBwYXRoOiAnL3BpcGVsaW5lLWFuYWx5dGljcycsIGljb246ICdUcmVuZGluZ1VwJyB9LFxyXG4gICAgeyB0aXRsZTogJ0FjdGl2aXR5IFRpbWVsaW5lJywgcGF0aDogJy9hY3Rpdml0eS10aW1lbGluZScsIGljb246ICdDbG9jaycgfVxyXG4gIF07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgcC02XCI+XHJcbiAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC10ZXh0LXByaW1hcnkgbWItNlwiPlF1aWNrIEFjdGlvbnM8L2gzPlxyXG4gICAgICB7LyogQWN0aW9uIEJ1dHRvbnMgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMyBtYi02XCI+XHJcbiAgICAgICAge3F1aWNrQWN0aW9ucz8ubWFwKChhY3Rpb24pID0+IChcclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAga2V5PXthY3Rpb24/LmlkfVxyXG4gICAgICAgICAgICBvbkNsaWNrPXthY3Rpb24/LmFjdGlvbn1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgJHthY3Rpb24/LmNvbG9yfSAke2FjdGlvbj8uaG92ZXJDb2xvcn0gcC00IHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMTUwIHRleHQtbGVmdCBncm91cGB9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0zIG1iLTJcIj5cclxuICAgICAgICAgICAgICA8SWNvbiBuYW1lPXthY3Rpb24/Lmljb259IHNpemU9ezIwfSAvPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtc21cIj57YWN0aW9uPy50aXRsZX08L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIG9wYWNpdHktOTBcIj57YWN0aW9uPy5kZXNjcmlwdGlvbn08L3A+XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICApKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIHsvKiBRdWljayBOYXZpZ2F0aW9uICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci10IGJvcmRlci1ib3JkZXIgcHQtNlwiPlxyXG4gICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IG1iLTRcIj5RdWljayBOYXZpZ2F0aW9uPC9oND5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAge3Nob3J0Y3V0cz8ubWFwKChzaG9ydGN1dCkgPT4gKFxyXG4gICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgIGtleT17c2hvcnRjdXQ/LnBhdGh9XHJcbiAgICAgICAgICAgICAgdG89e3Nob3J0Y3V0Py5wYXRofVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMyBwLTIgcm91bmRlZC1sZyB0ZXh0LXRleHQtc2Vjb25kYXJ5IGhvdmVyOnRleHQtdGV4dC1wcmltYXJ5IGhvdmVyOmJnLXN1cmZhY2UtaG92ZXIgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMTUwXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxJY29uIG5hbWU9e3Nob3J0Y3V0Py5pY29ufSBzaXplPXsxNn0gLz5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtXCI+e3Nob3J0Y3V0Py50aXRsZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgPEljb24gbmFtZT1cIkNoZXZyb25SaWdodFwiIHNpemU9ezE0fSBjbGFzc05hbWU9XCJtbC1hdXRvXCIgLz5cclxuICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICB7LyogQWRkIERlYWwgTW9kYWwgKi99XHJcbiAgICAgIHtzaG93QWRkRGVhbE1vZGFsICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctYmxhY2sgYmctb3BhY2l0eS01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB6LTEzMDBcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc3VyZmFjZSByb3VuZGVkLWxnIHAtNiB3LWZ1bGwgbWF4LXctbWQgbXgtNFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi00XCI+XHJcbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXRleHQtcHJpbWFyeVwiPkFkZCBOZXcgRGVhbDwvaDM+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0FkZERlYWxNb2RhbChmYWxzZSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5IGhvdmVyOnRleHQtdGV4dC1wcmltYXJ5XCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiWFwiIHNpemU9ezIwfSAvPlxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIERlYWwgVGl0bGVcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbnB1dC1maWVsZFwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgZGVhbCB0aXRsZVwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIENvbXBhbnlcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbnB1dC1maWVsZFwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQ29tcGFueSBuYW1lXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgRGVhbCBWYWx1ZVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5wdXQtZmllbGRcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjBcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggc3BhY2UteC0zIHB0LTRcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dBZGREZWFsTW9kYWwoZmFsc2UpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgcHgtNCBweS0yIGJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbGcgdGV4dC10ZXh0LXNlY29uZGFyeSBob3Zlcjp0ZXh0LXRleHQtcHJpbWFyeSBob3ZlcjpiZy1zdXJmYWNlLWhvdmVyIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTE1MFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgYnRuLXByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93QWRkRGVhbE1vZGFsKGZhbHNlKX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQ3JlYXRlIERlYWxcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgICAgey8qIEFkZCBDb250YWN0IE1vZGFsICovfVxyXG4gICAgICB7c2hvd0FkZENvbnRhY3RNb2RhbCAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLWJsYWNrIGJnLW9wYWNpdHktNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgei0xMzAwXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXN1cmZhY2Ugcm91bmRlZC1sZyBwLTYgdy1mdWxsIG1heC13LW1kIG14LTRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItNFwiPlxyXG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC10ZXh0LXByaW1hcnlcIj5BZGQgTmV3IENvbnRhY3Q8L2gzPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dBZGRDb250YWN0TW9kYWwoZmFsc2UpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC10ZXh0LXNlY29uZGFyeSBob3Zlcjp0ZXh0LXRleHQtcHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIlhcIiBzaXplPXsyMH0gLz5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICBGdWxsIE5hbWVcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbnB1dC1maWVsZFwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgZnVsbCBuYW1lXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgRW1haWxcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5wdXQtZmllbGRcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImVtYWlsQGNvbXBhbnkuY29tXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgQ29tcGFueVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlucHV0LWZpZWxkXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJDb21wYW55IG5hbWVcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggc3BhY2UteC0zIHB0LTRcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dBZGRDb250YWN0TW9kYWwoZmFsc2UpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgcHgtNCBweS0yIGJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbGcgdGV4dC10ZXh0LXNlY29uZGFyeSBob3Zlcjp0ZXh0LXRleHQtcHJpbWFyeSBob3ZlcjpiZy1zdXJmYWNlLWhvdmVyIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTE1MFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgYnRuLXByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93QWRkQ29udGFjdE1vZGFsKGZhbHNlKX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQWRkIENvbnRhY3RcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBRdWlja0FjdGlvbnM7Il0sImZpbGUiOiJEOi9jdXJyZW50IHByb2plY3RzL2NsYXVkZS1jb2RlL3NyYy9wYWdlcy9zYWxlcy1kYXNoYm9hcmQvY29tcG9uZW50cy9RdWlja0FjdGlvbnMuanN4In0=