import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/contact-management/components/ContactDetail.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import { format } from "/node_modules/.vite/deps/date-fns.js?v=44ab9529";
import Icon from "/src/components/AppIcon.jsx";
import Image from "/src/components/AppImage.jsx";
import ActivityTimeline from "/src/pages/contact-management/components/ActivityTimeline.jsx";
import DealsList from "/src/pages/contact-management/components/DealsList.jsx";
import ComposeEmailModal from "/src/pages/contact-management/components/ComposeEmailModal.jsx";
import LogCallModal from "/src/pages/contact-management/components/LogCallModal.jsx";
const ContactDetail = ({ contact, onEdit, onDelete, onContactUpdate }) => {
  _s();
  const [activeTab, setActiveTab] = useState("overview");
  const [isEmailModalOpen, setIsEmailModalOpen] = useState(false);
  const [isCallModalOpen, setIsCallModalOpen] = useState(false);
  if (!contact)
    return null;
  const handleActivityAdded = (newActivity) => {
    if (onContactUpdate) {
      const updatedContact = {
        ...contact,
        activities: [newActivity, ...contact.activities || []]
      };
      onContactUpdate(updatedContact);
    }
  };
  const formatDate = (dateString) => {
    if (!dateString)
      return "Never contacted";
    try {
      return format(new Date(dateString), "MMM d, yyyy");
    } catch (error) {
      return "Invalid date";
    }
  };
  const renderSocialIcon = (platform) => {
    switch (platform) {
      case "linkedin":
        return "Linkedin";
      case "twitter":
        return "Twitter";
      case "facebook":
        return "Facebook";
      default:
        return "Link";
    }
  };
  const getSocialProfiles = () => {
    const profiles = {};
    if (contact?.linkedin_url) {
      profiles.linkedin = contact?.linkedin_url;
    }
    if (contact?.twitter_url) {
      profiles.twitter = contact?.twitter_url;
    }
    return profiles;
  };
  const socialProfiles = getSocialProfiles();
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:65:4", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "65", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20rounded-lg%20border%20border-border%20shadow-sm%22%7D", className: "bg-surface rounded-lg border border-border shadow-sm", children: [
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:67:6", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "67", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22p-6%20border-b%20border-border%22%7D", className: "p-6 border-b border-border", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:68:8", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "68", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20flex-col%20md%3Aflex-row%20md%3Aitems-center%20justify-between%20gap-4%22%7D", className: "flex flex-col md:flex-row md:items-center justify-between gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:69:10", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "69", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%22%7D", className: "flex items-center", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:70:12", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "70", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22relative%20mr-4%22%7D", className: "relative mr-4", children: [
          /* @__PURE__ */ jsxDEV(
            Image,
            {
              "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:71:14",
              "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx",
              "data-component-line": "71",
              "data-component-file": "ContactDetail.jsx",
              "data-component-name": "Image",
              "data-component-content": "%7B%22elementName%22%3A%22Image%22%2C%22className%22%3A%22w-16%20h-16%20rounded-full%20object-cover%22%7D",
              src: contact?.avatar_url || "/assets/images/no_image.png",
              alt: `${contact?.first_name || ""} ${contact?.last_name || ""}`,
              className: "w-16 h-16 rounded-full object-cover"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
              lineNumber: 71,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:76:14", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "76", "data-component-file": "ContactDetail.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", className: `absolute bottom-0 right-0 w-4 h-4 rounded-full border-2 border-surface ${contact?.status === "active" ? "bg-success" : "bg-text-tertiary"}` }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
            lineNumber: 76,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
          lineNumber: 70,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:81:12", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "81", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
          /* @__PURE__ */ jsxDEV("h2", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:82:14", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "82", "data-component-file": "ContactDetail.jsx", "data-component-name": "h2", "data-component-content": "%7B%22elementName%22%3A%22h2%22%2C%22className%22%3A%22text-xl%20font-bold%20text-text-primary%22%7D", className: "text-xl font-bold text-text-primary", children: contact?.full_name || `${contact?.first_name || ""} ${contact?.last_name || ""}`?.trim() || "Unnamed Contact" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
            lineNumber: 82,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:85:14", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "85", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20text-text-secondary%22%7D", className: "flex items-center text-text-secondary", children: [
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:86:16", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "86", "data-component-file": "ContactDetail.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: contact?.position || "No position" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
              lineNumber: 86,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:87:16", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "87", "data-component-file": "ContactDetail.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22mx-2%22%2C%22textContent%22%3A%22%E2%80%A2%22%7D", className: "mx-2", children: "•" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
              lineNumber: 87,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:88:16", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "88", "data-component-file": "ContactDetail.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: contact?.company?.name || "No Company" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
              lineNumber: 88,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
            lineNumber: 85,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:90:14", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "90", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20flex-wrap%20gap-2%20mt-2%22%7D", className: "flex flex-wrap gap-2 mt-2", children: contact?.tags?.map(
            (tag, index) => /* @__PURE__ */ jsxDEV(
              "span",
              {
                "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:92:16",
                "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx",
                "data-component-line": "92",
                "data-component-file": "ContactDetail.jsx",
                "data-component-name": "span",
                "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22inline-flex%20items-center%20px-2.5%20py-0.5%20rounded-full%20text-xs%20font-medium%20bg-primary-50%20text-primary%22%7D",
                className: "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-50 text-primary",
                children: tag
              },
              `${tag}-${index}`,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                lineNumber: 92,
                columnNumber: 17
              },
              this
            )
          ) || null }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
            lineNumber: 90,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
          lineNumber: 81,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
        lineNumber: 69,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:103:10", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "103", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20flex-wrap%20gap-2%22%7D", className: "flex flex-wrap gap-2", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:104:12",
            "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx",
            "data-component-line": "104",
            "data-component-file": "ContactDetail.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22inline-flex%20items-center%20space-x-2%20px-3%20py-2%20border%20border-border%20rounded-lg%20text-text-secondary%20hover%3Atext-primary%20hover%3Aborder-primary%20transition-all%20duration-150%20ease-out%22%7D",
            onClick: () => setIsEmailModalOpen(true),
            className: "inline-flex items-center space-x-2 px-3 py-2 border border-border rounded-lg text-text-secondary hover:text-primary hover:border-primary transition-all duration-150 ease-out",
            children: [
              /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:108:14", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "108", "data-component-file": "ContactDetail.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Mail%22%7D", name: "Mail", size: 16 }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                lineNumber: 108,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:109:14", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "109", "data-component-file": "ContactDetail.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Email%22%7D", children: "Email" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                lineNumber: 109,
                columnNumber: 15
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
            lineNumber: 104,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:112:12",
            "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx",
            "data-component-line": "112",
            "data-component-file": "ContactDetail.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22inline-flex%20items-center%20space-x-2%20px-3%20py-2%20border%20border-border%20rounded-lg%20text-text-secondary%20hover%3Atext-primary%20hover%3Aborder-primary%20transition-all%20duration-150%20ease-out%22%7D",
            onClick: () => setIsCallModalOpen(true),
            className: "inline-flex items-center space-x-2 px-3 py-2 border border-border rounded-lg text-text-secondary hover:text-primary hover:border-primary transition-all duration-150 ease-out",
            children: [
              /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:116:14", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "116", "data-component-file": "ContactDetail.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Phone%22%7D", name: "Phone", size: 16 }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                lineNumber: 116,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:117:14", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "117", "data-component-file": "ContactDetail.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Call%22%7D", children: "Call" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                lineNumber: 117,
                columnNumber: 15
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
            lineNumber: 112,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:120:12",
            "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx",
            "data-component-line": "120",
            "data-component-file": "ContactDetail.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22inline-flex%20items-center%20space-x-2%20px-3%20py-2%20border%20border-border%20rounded-lg%20text-text-secondary%20hover%3Atext-primary%20hover%3Aborder-primary%20transition-all%20duration-150%20ease-out%22%7D",
            onClick: onEdit,
            className: "inline-flex items-center space-x-2 px-3 py-2 border border-border rounded-lg text-text-secondary hover:text-primary hover:border-primary transition-all duration-150 ease-out",
            children: [
              /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:124:14", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "124", "data-component-file": "ContactDetail.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Edit%22%7D", name: "Edit", size: 16 }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                lineNumber: 124,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:125:14", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "125", "data-component-file": "ContactDetail.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Edit%22%7D", children: "Edit" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                lineNumber: 125,
                columnNumber: 15
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
            lineNumber: 120,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:128:12", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "128", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22relative%20group%22%7D", className: "relative group", children: [
          /* @__PURE__ */ jsxDEV("button", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:129:14", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "129", "data-component-file": "ContactDetail.jsx", "data-component-name": "button", "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22inline-flex%20items-center%20space-x-2%20px-3%20py-2%20border%20border-border%20rounded-lg%20text-text-secondary%20hover%3Atext-text-primary%20transition-all%20duration-150%20ease-out%22%7D", className: "inline-flex items-center space-x-2 px-3 py-2 border border-border rounded-lg text-text-secondary hover:text-text-primary transition-all duration-150 ease-out", children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:130:16", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "130", "data-component-file": "ContactDetail.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22MoreHorizontal%22%7D", name: "MoreHorizontal", size: 16 }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
            lineNumber: 130,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
            lineNumber: 129,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:133:14", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "133", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22absolute%20right-0%20mt-2%20w-48%20bg-surface%20rounded-lg%20shadow-lg%20border%20border-border%20z-10%20hidden%20group-hover%3Ablock%22%7D", className: "absolute right-0 mt-2 w-48 bg-surface rounded-lg shadow-lg border border-border z-10 hidden group-hover:block", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:134:16", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "134", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22py-1%22%7D", className: "py-1", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:135:18",
                "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx",
                "data-component-line": "135",
                "data-component-file": "ContactDetail.jsx",
                "data-component-name": "button",
                "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22flex%20w-full%20items-center%20px-4%20py-2%20text-sm%20text-error%20hover%3Abg-surface-hover%22%2C%22textContent%22%3A%22Delete%20Contact%22%7D",
                onClick: onDelete,
                className: "flex w-full items-center px-4 py-2 text-sm text-error hover:bg-surface-hover",
                children: [
                  /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:139:20", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "139", "data-component-file": "ContactDetail.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Trash2%22%2C%22className%22%3A%22mr-2%22%7D", name: "Trash2", size: 16, className: "mr-2" }, void 0, false, {
                    fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                    lineNumber: 139,
                    columnNumber: 21
                  }, this),
                  "Delete Contact"
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                lineNumber: 135,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("button", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:142:18", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "142", "data-component-file": "ContactDetail.jsx", "data-component-name": "button", "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22flex%20w-full%20items-center%20px-4%20py-2%20text-sm%20text-text-secondary%20hover%3Abg-surface-hover%22%2C%22textContent%22%3A%22Add%20to%20Campaign%22%7D", className: "flex w-full items-center px-4 py-2 text-sm text-text-secondary hover:bg-surface-hover", children: [
              /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:143:20", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "143", "data-component-file": "ContactDetail.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22UserPlus%22%2C%22className%22%3A%22mr-2%22%7D", name: "UserPlus", size: 16, className: "mr-2" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                lineNumber: 143,
                columnNumber: 21
              }, this),
              "Add to Campaign"
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
              lineNumber: 142,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("button", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:146:18", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "146", "data-component-file": "ContactDetail.jsx", "data-component-name": "button", "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22flex%20w-full%20items-center%20px-4%20py-2%20text-sm%20text-text-secondary%20hover%3Abg-surface-hover%22%2C%22textContent%22%3A%22Manage%20Tags%22%7D", className: "flex w-full items-center px-4 py-2 text-sm text-text-secondary hover:bg-surface-hover", children: [
              /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:147:20", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "147", "data-component-file": "ContactDetail.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Tag%22%2C%22className%22%3A%22mr-2%22%7D", name: "Tag", size: 16, className: "mr-2" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                lineNumber: 147,
                columnNumber: 21
              }, this),
              "Manage Tags"
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
              lineNumber: 146,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
            lineNumber: 134,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
            lineNumber: 133,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
          lineNumber: 128,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
        lineNumber: 103,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
      lineNumber: 68,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
      lineNumber: 67,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:157:6", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "157", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22border-b%20border-border%22%7D", className: "border-b border-border", children: /* @__PURE__ */ jsxDEV("nav", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:158:8", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "158", "data-component-file": "ContactDetail.jsx", "data-component-name": "nav", "data-component-content": "%7B%22elementName%22%3A%22nav%22%2C%22className%22%3A%22flex%20overflow-x-auto%22%7D", className: "flex overflow-x-auto", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:159:10",
          "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx",
          "data-component-line": "159",
          "data-component-file": "ContactDetail.jsx",
          "data-component-name": "button",
          "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22textContent%22%3A%22Overview%22%7D",
          onClick: () => setActiveTab("overview"),
          className: `px-4 py-3 text-sm font-medium whitespace-nowrap ${activeTab === "overview" ? "text-primary border-b-2 border-primary" : "text-text-secondary hover:text-text-primary"}`,
          children: "Overview"
        },
        void 0,
        false,
        {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
          lineNumber: 159,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:167:10",
          "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx",
          "data-component-line": "167",
          "data-component-file": "ContactDetail.jsx",
          "data-component-name": "button",
          "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22textContent%22%3A%22Activity%22%7D",
          onClick: () => setActiveTab("activity"),
          className: `px-4 py-3 text-sm font-medium whitespace-nowrap ${activeTab === "activity" ? "text-primary border-b-2 border-primary" : "text-text-secondary hover:text-text-primary"}`,
          children: "Activity"
        },
        void 0,
        false,
        {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
          lineNumber: 167,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:175:10",
          "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx",
          "data-component-line": "175",
          "data-component-file": "ContactDetail.jsx",
          "data-component-name": "button",
          "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22textContent%22%3A%22Deals%20(%20)%22%7D",
          onClick: () => setActiveTab("deals"),
          className: `px-4 py-3 text-sm font-medium whitespace-nowrap ${activeTab === "deals" ? "text-primary border-b-2 border-primary" : "text-text-secondary hover:text-text-primary"}`,
          children: [
            "Deals (",
            contact?.deals?.length || 0,
            ")"
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
          lineNumber: 175,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:183:10",
          "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx",
          "data-component-line": "183",
          "data-component-file": "ContactDetail.jsx",
          "data-component-name": "button",
          "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22textContent%22%3A%22Notes%22%7D",
          onClick: () => setActiveTab("notes"),
          className: `px-4 py-3 text-sm font-medium whitespace-nowrap ${activeTab === "notes" ? "text-primary border-b-2 border-primary" : "text-text-secondary hover:text-text-primary"}`,
          children: "Notes"
        },
        void 0,
        false,
        {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
          lineNumber: 183,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
      lineNumber: 158,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
      lineNumber: 157,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:194:6", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "194", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22p-6%22%7D", className: "p-6", children: [
      activeTab === "overview" && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:196:8", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "196", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20md%3Agrid-cols-2%20gap-6%22%7D", className: "grid grid-cols-1 md:grid-cols-2 gap-6", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:198:12", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "198", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-5%22%7D", className: "card p-5", children: [
          /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:199:14", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "199", "data-component-file": "ContactDetail.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%20mb-4%22%2C%22textContent%22%3A%22Contact%20Information%22%7D", className: "text-lg font-semibold text-text-primary mb-4", children: "Contact Information" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
            lineNumber: 199,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:201:14", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "201", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-4%22%7D", className: "space-y-4", children: [
            contact?.email && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:203:14", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "203", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:204:20", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "204", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20mb-1%22%7D", className: "flex items-center mb-1", children: [
                /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:205:22", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "205", "data-component-file": "ContactDetail.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Mail%22%2C%22className%22%3A%22text-text-tertiary%20mr-2%22%7D", name: "Mail", size: 16, className: "text-text-tertiary mr-2" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                  lineNumber: 205,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:206:22", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "206", "data-component-file": "ContactDetail.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22Email%22%7D", className: "text-sm text-text-secondary", children: "Email" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                  lineNumber: 206,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                lineNumber: 204,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("a", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:208:20", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "208", "data-component-file": "ContactDetail.jsx", "data-component-name": "a", "data-component-content": "%7B%22elementName%22%3A%22a%22%2C%22className%22%3A%22text-primary%20hover%3Aunderline%22%7D", href: `mailto:${contact?.email}`, className: "text-primary hover:underline", children: contact?.email }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                lineNumber: 208,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
              lineNumber: 203,
              columnNumber: 15
            }, this),
            contact?.phone && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:215:14", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "215", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:216:20", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "216", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20mb-1%22%7D", className: "flex items-center mb-1", children: [
                /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:217:22", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "217", "data-component-file": "ContactDetail.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Phone%22%2C%22className%22%3A%22text-text-tertiary%20mr-2%22%7D", name: "Phone", size: 16, className: "text-text-tertiary mr-2" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                  lineNumber: 217,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:218:22", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "218", "data-component-file": "ContactDetail.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22Phone%22%7D", className: "text-sm text-text-secondary", children: "Phone" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                  lineNumber: 218,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                lineNumber: 216,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("a", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:220:20", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "220", "data-component-file": "ContactDetail.jsx", "data-component-name": "a", "data-component-content": "%7B%22elementName%22%3A%22a%22%2C%22className%22%3A%22text-text-primary%22%7D", href: `tel:${contact?.phone}`, className: "text-text-primary", children: contact?.phone }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                lineNumber: 220,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
              lineNumber: 215,
              columnNumber: 15
            }, this),
            contact?.mobile && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:227:14", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "227", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:228:20", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "228", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20mb-1%22%7D", className: "flex items-center mb-1", children: [
                /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:229:22", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "229", "data-component-file": "ContactDetail.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Smartphone%22%2C%22className%22%3A%22text-text-tertiary%20mr-2%22%7D", name: "Smartphone", size: 16, className: "text-text-tertiary mr-2" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                  lineNumber: 229,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:230:22", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "230", "data-component-file": "ContactDetail.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22Mobile%22%7D", className: "text-sm text-text-secondary", children: "Mobile" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                  lineNumber: 230,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                lineNumber: 228,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("a", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:232:20", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "232", "data-component-file": "ContactDetail.jsx", "data-component-name": "a", "data-component-content": "%7B%22elementName%22%3A%22a%22%2C%22className%22%3A%22text-text-primary%22%7D", href: `tel:${contact?.mobile}`, className: "text-text-primary", children: contact?.mobile }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                lineNumber: 232,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
              lineNumber: 227,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:238:16", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "238", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:239:18", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "239", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20mb-1%22%7D", className: "flex items-center mb-1", children: [
                /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:240:20", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "240", "data-component-file": "ContactDetail.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Building%22%2C%22className%22%3A%22text-text-tertiary%20mr-2%22%7D", name: "Building", size: 16, className: "text-text-tertiary mr-2" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                  lineNumber: 240,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:241:20", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "241", "data-component-file": "ContactDetail.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22Company%22%7D", className: "text-sm text-text-secondary", children: "Company" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                  lineNumber: 241,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                lineNumber: 239,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:243:18", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "243", "data-component-file": "ContactDetail.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-text-primary%22%7D", className: "text-text-primary", children: contact?.company?.name || "No Company" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                lineNumber: 243,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
              lineNumber: 238,
              columnNumber: 17
            }, this),
            contact?.position && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:247:14", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "247", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:248:20", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "248", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20mb-1%22%7D", className: "flex items-center mb-1", children: [
                /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:249:22", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "249", "data-component-file": "ContactDetail.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Briefcase%22%2C%22className%22%3A%22text-text-tertiary%20mr-2%22%7D", name: "Briefcase", size: 16, className: "text-text-tertiary mr-2" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                  lineNumber: 249,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:250:22", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "250", "data-component-file": "ContactDetail.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22Position%22%7D", className: "text-sm text-text-secondary", children: "Position" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                  lineNumber: 250,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                lineNumber: 248,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:252:20", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "252", "data-component-file": "ContactDetail.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-text-primary%22%7D", className: "text-text-primary", children: contact?.position }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                lineNumber: 252,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
              lineNumber: 247,
              columnNumber: 15
            }, this),
            contact?.department && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:257:14", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "257", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:258:20", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "258", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20mb-1%22%7D", className: "flex items-center mb-1", children: [
                /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:259:22", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "259", "data-component-file": "ContactDetail.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Users%22%2C%22className%22%3A%22text-text-tertiary%20mr-2%22%7D", name: "Users", size: 16, className: "text-text-tertiary mr-2" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                  lineNumber: 259,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:260:22", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "260", "data-component-file": "ContactDetail.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22Department%22%7D", className: "text-sm text-text-secondary", children: "Department" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                  lineNumber: 260,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                lineNumber: 258,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:262:20", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "262", "data-component-file": "ContactDetail.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-text-primary%22%7D", className: "text-text-primary", children: contact?.department }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                lineNumber: 262,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
              lineNumber: 257,
              columnNumber: 15
            }, this),
            contact?.lead_source && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:267:14", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "267", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:268:20", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "268", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20mb-1%22%7D", className: "flex items-center mb-1", children: [
                /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:269:22", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "269", "data-component-file": "ContactDetail.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Target%22%2C%22className%22%3A%22text-text-tertiary%20mr-2%22%7D", name: "Target", size: 16, className: "text-text-tertiary mr-2" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                  lineNumber: 269,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:270:22", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "270", "data-component-file": "ContactDetail.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22Lead%20Source%22%7D", className: "text-sm text-text-secondary", children: "Lead Source" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                  lineNumber: 270,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                lineNumber: 268,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:272:20", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "272", "data-component-file": "ContactDetail.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-text-primary%20capitalize%22%7D", className: "text-text-primary capitalize", children: contact?.lead_source?.replace("_", " ") }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                lineNumber: 272,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
              lineNumber: 267,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:276:16", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "276", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:277:18", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "277", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20mb-1%22%7D", className: "flex items-center mb-1", children: [
                /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:278:20", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "278", "data-component-file": "ContactDetail.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Calendar%22%2C%22className%22%3A%22text-text-tertiary%20mr-2%22%7D", name: "Calendar", size: 16, className: "text-text-tertiary mr-2" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                  lineNumber: 278,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:279:20", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "279", "data-component-file": "ContactDetail.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22Last%20Contacted%22%7D", className: "text-sm text-text-secondary", children: "Last Contacted" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                  lineNumber: 279,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                lineNumber: 277,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:281:18", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "281", "data-component-file": "ContactDetail.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-text-primary%22%7D", className: "text-text-primary", children: formatDate(contact?.last_contact_date) }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                lineNumber: 281,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
              lineNumber: 276,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
            lineNumber: 201,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
          lineNumber: 198,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:287:12", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "287", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-6%22%7D", className: "space-y-6", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:289:14", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "289", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-5%22%7D", className: "card p-5", children: [
            /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:290:16", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "290", "data-component-file": "ContactDetail.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%20mb-4%22%2C%22textContent%22%3A%22Social%20Profiles%22%7D", className: "text-lg font-semibold text-text-primary mb-4", children: "Social Profiles" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
              lineNumber: 290,
              columnNumber: 17
            }, this),
            Object.keys(socialProfiles)?.length > 0 ? /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:293:14", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "293", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-3%22%7D", className: "space-y-3", children: Object.entries(socialProfiles)?.map(
              ([platform, url]) => /* @__PURE__ */ jsxDEV(
                "a",
                {
                  "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:295:16",
                  "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx",
                  "data-component-line": "295",
                  "data-component-file": "ContactDetail.jsx",
                  "data-component-name": "a",
                  "data-component-content": "%7B%22elementName%22%3A%22a%22%2C%22className%22%3A%22flex%20items-center%20text-text-primary%20hover%3Atext-primary%20transition-colors%20duration-150%20ease-out%22%7D",
                  href: url?.startsWith("http") ? url : `https://${url}`,
                  target: "_blank",
                  rel: "noopener noreferrer",
                  className: "flex items-center text-text-primary hover:text-primary transition-colors duration-150 ease-out",
                  children: [
                    /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:302:24", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "302", "data-component-file": "ContactDetail.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22className%22%3A%22mr-2%22%7D", name: renderSocialIcon(platform), size: 16, className: "mr-2" }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                      lineNumber: 302,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:303:24", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "303", "data-component-file": "ContactDetail.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: platform?.charAt(0)?.toUpperCase() + platform?.slice(1) }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                      lineNumber: 303,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:304:24", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "304", "data-component-file": "ContactDetail.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22ExternalLink%22%2C%22className%22%3A%22ml-2%22%7D", name: "ExternalLink", size: 14, className: "ml-2" }, void 0, false, {
                      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                      lineNumber: 304,
                      columnNumber: 25
                    }, this)
                  ]
                },
                platform,
                true,
                {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                  lineNumber: 295,
                  columnNumber: 17
                },
                this
              )
            ) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
              lineNumber: 293,
              columnNumber: 15
            }, this) : /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:309:14", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "309", "data-component-file": "ContactDetail.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20text-sm%22%2C%22textContent%22%3A%22No%20social%20profiles%20added%22%7D", className: "text-text-secondary text-sm", children: "No social profiles added" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
              lineNumber: 309,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
            lineNumber: 289,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:314:14", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "314", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-5%22%7D", className: "card p-5", children: [
            /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:315:16", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "315", "data-component-file": "ContactDetail.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%20mb-4%22%2C%22textContent%22%3A%22Additional%20Information%22%7D", className: "text-lg font-semibold text-text-primary mb-4", children: "Additional Information" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
              lineNumber: 315,
              columnNumber: 17
            }, this),
            contact?.custom_fields && Object.keys(contact?.custom_fields)?.length > 0 ? /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:318:14", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "318", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-3%22%7D", className: "space-y-3", children: Object.entries(contact?.custom_fields)?.map(
              ([key, value]) => /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:320:16", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "320", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
                /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:321:24", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "321", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-sm%20text-text-secondary%20mb-1%22%7D", className: "text-sm text-text-secondary mb-1", children: key?.replace(/([A-Z])/g, " $1")?.replace(/^./, (str) => str?.toUpperCase()) }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                  lineNumber: 321,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:324:24", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "324", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-text-primary%22%7D", className: "text-text-primary", children: String(value) }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                  lineNumber: 324,
                  columnNumber: 25
                }, this)
              ] }, key, true, {
                fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
                lineNumber: 320,
                columnNumber: 17
              }, this)
            ) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
              lineNumber: 318,
              columnNumber: 15
            }, this) : /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:329:14", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "329", "data-component-file": "ContactDetail.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20text-sm%22%2C%22textContent%22%3A%22No%20additional%20information%22%7D", className: "text-text-secondary text-sm", children: "No additional information" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
              lineNumber: 329,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
            lineNumber: 314,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
          lineNumber: 287,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
        lineNumber: 196,
        columnNumber: 9
      }, this),
      activeTab === "activity" && /* @__PURE__ */ jsxDEV(
        ActivityTimeline,
        {
          "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:337:8",
          "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx",
          "data-component-line": "337",
          "data-component-file": "ContactDetail.jsx",
          "data-component-name": "ActivityTimeline",
          "data-component-content": "%7B%22elementName%22%3A%22ActivityTimeline%22%7D",
          activities: contact?.activities || [],
          contact,
          onActivityAdded: handleActivityAdded
        },
        void 0,
        false,
        {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
          lineNumber: 337,
          columnNumber: 9
        },
        this
      ),
      activeTab === "deals" && /* @__PURE__ */ jsxDEV(
        DealsList,
        {
          "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:345:8",
          "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx",
          "data-component-line": "345",
          "data-component-file": "ContactDetail.jsx",
          "data-component-name": "DealsList",
          "data-component-content": "%7B%22elementName%22%3A%22DealsList%22%7D",
          deals: contact?.deals || [],
          contactName: contact?.full_name || `${contact?.first_name || ""} ${contact?.last_name || ""}`?.trim() || "Unnamed Contact"
        },
        void 0,
        false,
        {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
          lineNumber: 345,
          columnNumber: 9
        },
        this
      ),
      activeTab === "notes" && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:352:8", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "352", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-5%22%7D", className: "card p-5", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:353:12", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "353", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20justify-between%20items-center%20mb-4%22%7D", className: "flex justify-between items-center mb-4", children: [
          /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:354:14", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "354", "data-component-file": "ContactDetail.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%2C%22textContent%22%3A%22Notes%22%7D", className: "text-lg font-semibold text-text-primary", children: "Notes" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
            lineNumber: 354,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("button", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:355:14", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "355", "data-component-file": "ContactDetail.jsx", "data-component-name": "button", "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22text-primary%20hover%3Atext-primary-700%20transition-colors%20duration-150%20ease-out%22%7D", className: "text-primary hover:text-primary-700 transition-colors duration-150 ease-out", children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:356:16", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "356", "data-component-file": "ContactDetail.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Edit%22%7D", name: "Edit", size: 16 }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
            lineNumber: 356,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
            lineNumber: 355,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
          lineNumber: 353,
          columnNumber: 13
        }, this),
        contact?.notes ? /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:361:10", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "361", "data-component-file": "ContactDetail.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-primary%20whitespace-pre-line%22%7D", className: "text-text-primary whitespace-pre-line", children: contact?.notes }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
          lineNumber: 361,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:363:10", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "363", "data-component-file": "ContactDetail.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-center%20py-8%22%7D", className: "text-center py-8", children: [
          /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:364:16", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "364", "data-component-file": "ContactDetail.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22FileText%22%2C%22className%22%3A%22text-text-tertiary%20mx-auto%20mb-3%22%7D", name: "FileText", size: 32, className: "text-text-tertiary mx-auto mb-3" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
            lineNumber: 364,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:365:16", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "365", "data-component-file": "ContactDetail.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%22%2C%22textContent%22%3A%22No%20notes%20available%22%7D", className: "text-text-secondary", children: "No notes available" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
            lineNumber: 365,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("button", { "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:366:16", "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx", "data-component-line": "366", "data-component-file": "ContactDetail.jsx", "data-component-name": "button", "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22mt-3%20text-primary%20hover%3Aunderline%22%2C%22textContent%22%3A%22Add%20a%20note%22%7D", className: "mt-3 text-primary hover:underline", children: "Add a note" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
            lineNumber: 366,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
          lineNumber: 363,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
        lineNumber: 352,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
      lineNumber: 194,
      columnNumber: 7
    }, this),
    isEmailModalOpen && /* @__PURE__ */ jsxDEV(
      ComposeEmailModal,
      {
        "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:374:6",
        "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx",
        "data-component-line": "374",
        "data-component-file": "ContactDetail.jsx",
        "data-component-name": "ComposeEmailModal",
        "data-component-content": "%7B%22elementName%22%3A%22ComposeEmailModal%22%7D",
        contact,
        onClose: () => setIsEmailModalOpen(false),
        onSend: (emailData) => {
          console.log("Email sent:", emailData);
          setIsEmailModalOpen(false);
        }
      },
      void 0,
      false,
      {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
        lineNumber: 374,
        columnNumber: 7
      },
      this
    ),
    isCallModalOpen && /* @__PURE__ */ jsxDEV(
      LogCallModal,
      {
        "data-component-id": "src\\pages\\contact-management\\components\\ContactDetail.jsx:384:6",
        "data-component-path": "src\\pages\\contact-management\\components\\ContactDetail.jsx",
        "data-component-line": "384",
        "data-component-file": "ContactDetail.jsx",
        "data-component-name": "LogCallModal",
        "data-component-content": "%7B%22elementName%22%3A%22LogCallModal%22%7D",
        contact,
        onClose: () => setIsCallModalOpen(false),
        onLog: (callData) => {
          console.log("Call logged:", callData);
          setIsCallModalOpen(false);
        }
      },
      void 0,
      false,
      {
        fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
        lineNumber: 384,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx",
    lineNumber: 65,
    columnNumber: 5
  }, this);
};
_s(ContactDetail, "q35tW83jRtiu07uizZR55sXOPo0=");
_c = ContactDetail;
export default ContactDetail;
var _c;
$RefreshReg$(_c, "ContactDetail");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/contact-management/components/ContactDetail.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0VjOzJCQXRFZDtBQUFnQkEsTUFBUSxjQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3ZDLFNBQVNDLGNBQWM7QUFDdkIsT0FBT0MsVUFBVTtBQUNqQixPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLHNCQUFzQjtBQUM3QixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLHVCQUF1QjtBQUM5QixPQUFPQyxrQkFBa0I7QUFFekIsTUFBTUMsZ0JBQWdCQSxDQUFDLEVBQUVDLFNBQVNDLFFBQVFDLFVBQVVDLGdCQUFnQixNQUFNO0FBQUFDLEtBQUE7QUFDeEUsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUlmLFNBQVMsVUFBVTtBQUNyRCxRQUFNLENBQUNnQixrQkFBa0JDLG1CQUFtQixJQUFJakIsU0FBUyxLQUFLO0FBQzlELFFBQU0sQ0FBQ2tCLGlCQUFpQkMsa0JBQWtCLElBQUluQixTQUFTLEtBQUs7QUFFNUQsTUFBSSxDQUFDUztBQUFTLFdBQU87QUFFckIsUUFBTVcsc0JBQXNCQSxDQUFDQyxnQkFBZ0I7QUFDM0MsUUFBSVQsaUJBQWlCO0FBRW5CLFlBQU1VLGlCQUFpQjtBQUFBLFFBQ3JCLEdBQUdiO0FBQUFBLFFBQ0hjLFlBQVksQ0FBQ0YsYUFBYSxHQUFJWixRQUFRYyxjQUFjLEVBQUc7QUFBQSxNQUN6RDtBQUNBWCxzQkFBZ0JVLGNBQWM7QUFBQSxJQUNoQztBQUFBLEVBQ0Y7QUFFQSxRQUFNRSxhQUFhQSxDQUFDQyxlQUFlO0FBQ2pDLFFBQUksQ0FBQ0E7QUFBWSxhQUFPO0FBQ3hCLFFBQUk7QUFDRixhQUFPeEIsT0FBTyxJQUFJeUIsS0FBS0QsVUFBVSxHQUFHLGFBQWE7QUFBQSxJQUNuRCxTQUFTRSxPQUFPO0FBQ2QsYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBRUEsUUFBTUMsbUJBQW1CQSxDQUFDQyxhQUFhO0FBQ3JDLFlBQVFBLFVBQVE7QUFBQSxNQUNkLEtBQUs7QUFDSCxlQUFPO0FBQUEsTUFDVCxLQUFLO0FBQ0gsZUFBTztBQUFBLE1BQ1QsS0FBSztBQUNILGVBQU87QUFBQSxNQUNUO0FBQ0UsZUFBTztBQUFBLElBQ1g7QUFBQSxFQUNGO0FBR0EsUUFBTUMsb0JBQW9CQSxNQUFNO0FBQzlCLFVBQU1DLFdBQVcsQ0FBQztBQUNsQixRQUFJdEIsU0FBU3VCLGNBQWM7QUFDekJELGVBQVNFLFdBQVd4QixTQUFTdUI7QUFBQUEsSUFDL0I7QUFDQSxRQUFJdkIsU0FBU3lCLGFBQWE7QUFDeEJILGVBQVNJLFVBQVUxQixTQUFTeUI7QUFBQUEsSUFDOUI7QUFDQSxXQUFPSDtBQUFBQSxFQUNUO0FBRUEsUUFBTUssaUJBQWlCTixrQkFBa0I7QUFFekMsU0FDRSx1QkFBQywyYkFBSSxXQUFVLHdEQUViO0FBQUEsMkJBQUMsNlpBQUksV0FBVSw4QkFDYixpQ0FBQyw0Y0FBSSxXQUFVLG1FQUNiO0FBQUEsNkJBQUMsbVpBQUksV0FBVSxxQkFDYjtBQUFBLCtCQUFDLCtZQUFJLFdBQVUsaUJBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsS0FBS3JCLFNBQVM0QixjQUFjO0FBQUEsY0FDNUIsS0FBSyxHQUFHNUIsU0FBUzZCLGNBQWMsRUFBRSxJQUFJN0IsU0FBUzhCLGFBQWEsRUFBRTtBQUFBLGNBQzdELFdBQVU7QUFBQTtBQUFBLFlBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBR2lEO0FBQUEsVUFFakQsdUJBQUMsd1dBQUssV0FBVywwRUFDZjlCLFNBQVMrQixXQUFXLFdBQVcsZUFBZSxrQkFBa0IsTUFEbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFSTtBQUFBLGFBUk47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFFQSx1QkFBQyxxV0FDQztBQUFBLGlDQUFDLG9hQUFHLFdBQVUsdUNBQ1gvQixtQkFBU2dDLGFBQWEsR0FBR2hDLFNBQVM2QixjQUFjLEVBQUUsSUFBSTdCLFNBQVM4QixhQUFhLEVBQUUsSUFBSUcsS0FBSyxLQUFLLHFCQUQvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyx5YUFBSSxXQUFVLHlDQUNiO0FBQUEsbUNBQUMsd1dBQU1qQyxtQkFBU2tDLFlBQVksaUJBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBDO0FBQUEsWUFDMUMsdUJBQUMsNmFBQUssV0FBVSxRQUFPLGlCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3QjtBQUFBLFlBQ3hCLHVCQUFDLHdXQUFNbEMsbUJBQVNtQyxTQUFTQyxRQUFRLGdCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4QztBQUFBLGVBSGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxVQUNBLHVCQUFDLCtaQUFJLFdBQVUsNkJBQ1pwQyxtQkFBU3FDLE1BQU1DO0FBQUFBLFlBQUksQ0FBQ0MsS0FBS0MsVUFDeEI7QUFBQSxjQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFFQyxXQUFVO0FBQUEsZ0JBRVREO0FBQUFBO0FBQUFBLGNBSEksR0FBR0EsR0FBRyxJQUFJQyxLQUFLO0FBQUEsY0FEdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBO0FBQUEsVUFDRCxLQUFLLFFBUlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQTtBQUFBLGFBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtQkE7QUFBQSxXQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0NBO0FBQUEsTUFFQSx1QkFBQywwWkFBSSxXQUFVLHdCQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTWhDLG9CQUFvQixJQUFJO0FBQUEsWUFDdkMsV0FBVTtBQUFBLFlBRVY7QUFBQSxxQ0FBQyxrWUFBSyxNQUFLLFFBQU8sTUFBTSxNQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyQjtBQUFBLGNBQzNCLHVCQUFDLDRZQUFLLHFCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQVc7QUFBQTtBQUFBO0FBQUEsVUFMYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFFBRUE7QUFBQSxVQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTUUsbUJBQW1CLElBQUk7QUFBQSxZQUN0QyxXQUFVO0FBQUEsWUFFVjtBQUFBLHFDQUFDLG1ZQUFLLE1BQUssU0FBUSxNQUFNLE1BQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRCO0FBQUEsY0FDNUIsdUJBQUMsMllBQUssb0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBVTtBQUFBO0FBQUE7QUFBQSxVQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsUUFFQTtBQUFBLFVBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBQ0MsU0FBU1Q7QUFBQUEsWUFDVCxXQUFVO0FBQUEsWUFFVjtBQUFBLHFDQUFDLGtZQUFLLE1BQUssUUFBTyxNQUFNLE1BQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJCO0FBQUEsY0FDM0IsdUJBQUMsMllBQUssb0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBVTtBQUFBO0FBQUE7QUFBQSxVQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsUUFFQSx1QkFBQyxrWkFBSSxXQUFVLGtCQUNiO0FBQUEsaUNBQUMsa2tCQUFPLFdBQVUsaUtBQ2hCLGlDQUFDLDRZQUFLLE1BQUssa0JBQWlCLE1BQU0sTUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUMsS0FEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBRUEsdUJBQUMsdWdCQUFJLFdBQVUsaUhBQ2IsaUNBQUMsc1lBQUksV0FBVSxRQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFDQyxTQUFTQztBQUFBQSxnQkFDVCxXQUFVO0FBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxtYUFBSyxNQUFLLFVBQVMsTUFBTSxJQUFJLFdBQVUsVUFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBOEM7QUFBQSxrQkFBRztBQUFBO0FBQUE7QUFBQSxjQUpuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLFlBQ0EsdUJBQUMsZ2lCQUFPLFdBQVUseUZBQ2hCO0FBQUEscUNBQUMscWFBQUssTUFBSyxZQUFXLE1BQU0sSUFBSSxXQUFVLFVBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdEO0FBQUEsY0FBRztBQUFBLGlCQURyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQywwaEJBQU8sV0FBVSx5RkFDaEI7QUFBQSxxQ0FBQyxnYUFBSyxNQUFLLE9BQU0sTUFBTSxJQUFJLFdBQVUsVUFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkM7QUFBQSxjQUFHO0FBQUEsaUJBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxlQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0JBLEtBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0JBO0FBQUEsYUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdCQTtBQUFBLFdBakRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrREE7QUFBQSxTQXJGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0ZBLEtBdkZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3RkE7QUFBQSxJQUVBLHVCQUFDLHlaQUFJLFdBQVUsMEJBQ2IsaUNBQUMsdVpBQUksV0FBVSx3QkFDYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFDQyxTQUFTLE1BQU1JLGFBQWEsVUFBVTtBQUFBLFVBQ3RDLFdBQVcsbURBQ1RELGNBQWMsYUFBWSwyQ0FBMEMsNkNBQTZDO0FBQUEsVUFDaEg7QUFBQTtBQUFBLFFBSkw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0E7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFDQyxTQUFTLE1BQU1DLGFBQWEsVUFBVTtBQUFBLFVBQ3RDLFdBQVcsbURBQ1RELGNBQWMsYUFBWSwyQ0FBMEMsNkNBQTZDO0FBQUEsVUFDaEg7QUFBQTtBQUFBLFFBSkw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0E7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFDQyxTQUFTLE1BQU1DLGFBQWEsT0FBTztBQUFBLFVBQ25DLFdBQVcsbURBQ1RELGNBQWMsVUFBUywyQ0FBMEMsNkNBQTZDO0FBQUEsVUFDN0c7QUFBQTtBQUFBLFlBRUtMLFNBQVN5QyxPQUFPQyxVQUFVO0FBQUEsWUFBRTtBQUFBO0FBQUE7QUFBQSxRQU50QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFPQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUNDLFNBQVMsTUFBTXBDLGFBQWEsT0FBTztBQUFBLFVBQ25DLFdBQVcsbURBQ1RELGNBQWMsVUFBUywyQ0FBMEMsNkNBQTZDO0FBQUEsVUFDN0c7QUFBQTtBQUFBLFFBSkw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0E7QUFBQSxTQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUNBLEtBbENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtQ0E7QUFBQSxJQUVBLHVCQUFDLG9ZQUFJLFdBQVUsT0FDWkE7QUFBQUEsb0JBQWMsY0FDYix1QkFBQyw4YUFBSSxXQUFVLHlDQUViO0FBQUEsK0JBQUMsNFlBQUksV0FBVSxZQUNiO0FBQUEsaUNBQUMsbWVBQUcsV0FBVSxnREFBK0MsbUNBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdGO0FBQUEsVUFFaEYsdUJBQUMsMllBQUksV0FBVSxhQUNaTDtBQUFBQSxxQkFBUzJDLFNBQ1IsdUJBQUMsdVdBQ0M7QUFBQSxxQ0FBQyw0WkFBSSxXQUFVLDBCQUNiO0FBQUEsdUNBQUMsc2JBQUssTUFBSyxRQUFPLE1BQU0sSUFBSSxXQUFVLDZCQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUErRDtBQUFBLGdCQUMvRCx1QkFBQyxvY0FBSyxXQUFVLCtCQUE4QixxQkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbUQ7QUFBQSxtQkFGckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsNFpBQUUsTUFBTSxVQUFVM0MsU0FBUzJDLEtBQUssSUFBSSxXQUFVLGdDQUM1QzNDLG1CQUFTMkMsU0FEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLFlBR0QzQyxTQUFTNEMsU0FDUix1QkFBQyx1V0FDQztBQUFBLHFDQUFDLDRaQUFJLFdBQVUsMEJBQ2I7QUFBQSx1Q0FBQyx1YkFBSyxNQUFLLFNBQVEsTUFBTSxJQUFJLFdBQVUsNkJBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdFO0FBQUEsZ0JBQ2hFLHVCQUFDLG9jQUFLLFdBQVUsK0JBQThCLHFCQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtRDtBQUFBLG1CQUZyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyw2WUFBRSxNQUFNLE9BQU81QyxTQUFTNEMsS0FBSyxJQUFJLFdBQVUscUJBQ3pDNUMsbUJBQVM0QyxTQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsWUFHRDVDLFNBQVM2QyxVQUNSLHVCQUFDLHVXQUNDO0FBQUEscUNBQUMsNFpBQUksV0FBVSwwQkFDYjtBQUFBLHVDQUFDLDRiQUFLLE1BQUssY0FBYSxNQUFNLElBQUksV0FBVSw2QkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUU7QUFBQSxnQkFDckUsdUJBQUMscWNBQUssV0FBVSwrQkFBOEIsc0JBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW9EO0FBQUEsbUJBRnREO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLDZZQUFFLE1BQU0sT0FBTzdDLFNBQVM2QyxNQUFNLElBQUksV0FBVSxxQkFDMUM3QyxtQkFBUzZDLFVBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxZQUdGLHVCQUFDLHVXQUNDO0FBQUEscUNBQUMsNFpBQUksV0FBVSwwQkFDYjtBQUFBLHVDQUFDLDBiQUFLLE1BQUssWUFBVyxNQUFNLElBQUksV0FBVSw2QkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbUU7QUFBQSxnQkFDbkUsdUJBQUMsc2NBQUssV0FBVSwrQkFBOEIsdUJBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFEO0FBQUEsbUJBRnZEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLHNaQUFLLFdBQVUscUJBQXFCN0MsbUJBQVNtQyxTQUFTQyxRQUFRLGdCQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0RTtBQUFBLGlCQUw5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU1BO0FBQUEsWUFFQ3BDLFNBQVNrQyxZQUNSLHVCQUFDLHVXQUNDO0FBQUEscUNBQUMsNFpBQUksV0FBVSwwQkFDYjtBQUFBLHVDQUFDLDJiQUFLLE1BQUssYUFBWSxNQUFNLElBQUksV0FBVSw2QkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0U7QUFBQSxnQkFDcEUsdUJBQUMsdWNBQUssV0FBVSwrQkFBOEIsd0JBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXNEO0FBQUEsbUJBRnhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLHNaQUFLLFdBQVUscUJBQXFCbEMsbUJBQVNrQyxZQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1RDtBQUFBLGlCQUx6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU1BO0FBQUEsWUFHRGxDLFNBQVM4QyxjQUNSLHVCQUFDLHVXQUNDO0FBQUEscUNBQUMsNFpBQUksV0FBVSwwQkFDYjtBQUFBLHVDQUFDLHViQUFLLE1BQUssU0FBUSxNQUFNLElBQUksV0FBVSw2QkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0U7QUFBQSxnQkFDaEUsdUJBQUMseWNBQUssV0FBVSwrQkFBOEIsMEJBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdEO0FBQUEsbUJBRjFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLHNaQUFLLFdBQVUscUJBQXFCOUMsbUJBQVM4QyxjQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5RDtBQUFBLGlCQUwzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU1BO0FBQUEsWUFHRDlDLFNBQVMrQyxlQUNSLHVCQUFDLHVXQUNDO0FBQUEscUNBQUMsNFpBQUksV0FBVSwwQkFDYjtBQUFBLHVDQUFDLHdiQUFLLE1BQUssVUFBUyxNQUFNLElBQUksV0FBVSw2QkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUU7QUFBQSxnQkFDakUsdUJBQUMsNGNBQUssV0FBVSwrQkFBOEIsMkJBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlEO0FBQUEsbUJBRjNEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLG1hQUFLLFdBQVUsZ0NBQWdDL0MsbUJBQVMrQyxhQUFhQyxRQUFRLEtBQUssR0FBRyxLQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3RjtBQUFBLGlCQUwxRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU1BO0FBQUEsWUFHRix1QkFBQyx1V0FDQztBQUFBLHFDQUFDLDRaQUFJLFdBQVUsMEJBQ2I7QUFBQSx1Q0FBQywwYkFBSyxNQUFLLFlBQVcsTUFBTSxJQUFJLFdBQVUsNkJBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1FO0FBQUEsZ0JBQ25FLHVCQUFDLCtjQUFLLFdBQVUsK0JBQThCLDhCQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE0RDtBQUFBLG1CQUY5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxzWkFBSyxXQUFVLHFCQUFxQmpDLHFCQUFXZixTQUFTaUQsaUJBQWlCLEtBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRFO0FBQUEsaUJBTDlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTUE7QUFBQSxlQWpGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtGQTtBQUFBLGFBckZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzRkE7QUFBQSxRQUdBLHVCQUFDLDJZQUFJLFdBQVUsYUFFYjtBQUFBLGlDQUFDLDRZQUFJLFdBQVUsWUFDYjtBQUFBLG1DQUFDLCtkQUFHLFdBQVUsZ0RBQStDLCtCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0RTtBQUFBLFlBRTNFQyxPQUFPQyxLQUFLeEIsY0FBYyxHQUFHZSxTQUFTLElBQ3JDLHVCQUFDLDJZQUFJLFdBQVUsYUFDWlEsaUJBQU9FLFFBQVF6QixjQUFjLEdBQUdXO0FBQUFBLGNBQUksQ0FBQyxDQUFDbEIsVUFBVWlDLEdBQUcsTUFDbEQ7QUFBQSxnQkFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRUMsTUFBTUEsS0FBS0MsV0FBVyxNQUFNLElBQUlELE1BQU0sV0FBV0EsR0FBRztBQUFBLGtCQUNwRCxRQUFPO0FBQUEsa0JBQ1AsS0FBSTtBQUFBLGtCQUNKLFdBQVU7QUFBQSxrQkFFVjtBQUFBLDJDQUFDLHVZQUFLLE1BQU1sQyxpQkFBaUJDLFFBQVEsR0FBRyxNQUFNLElBQUksV0FBVSxVQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFrRTtBQUFBLG9CQUNsRSx1QkFBQywwV0FBTUEsb0JBQVVtQyxPQUFPLENBQUMsR0FBR0MsWUFBWSxJQUFJcEMsVUFBVXFDLE1BQU0sQ0FBQyxLQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUErRDtBQUFBLG9CQUMvRCx1QkFBQyx5YUFBSyxNQUFLLGdCQUFlLE1BQU0sSUFBSSxXQUFVLFVBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW9EO0FBQUE7QUFBQTtBQUFBLGdCQVIvQ3JDO0FBQUFBLGdCQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FVQTtBQUFBLFlBQ0QsS0FiSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWNBLElBRUEsdUJBQUMsb2RBQUUsV0FBVSwrQkFBOEIsd0NBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1FO0FBQUEsZUFwQnZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBc0JBO0FBQUEsVUFHQSx1QkFBQyw0WUFBSSxXQUFVLFlBQ2I7QUFBQSxtQ0FBQyxzZUFBRyxXQUFVLGdEQUErQyxzQ0FBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUY7QUFBQSxZQUVsRnBCLFNBQVMwRCxpQkFBaUJSLE9BQU9DLEtBQUtuRCxTQUFTMEQsYUFBYSxHQUFHaEIsU0FBUyxJQUN2RSx1QkFBQywyWUFBSSxXQUFVLGFBQ1pRLGlCQUFPRSxRQUFRcEQsU0FBUzBELGFBQWEsR0FBR3BCO0FBQUFBLGNBQUksQ0FBQyxDQUFDcUIsS0FBS0MsS0FBSyxNQUN2RCx1QkFBQyx1V0FDQztBQUFBLHVDQUFDLHNhQUFJLFdBQVUsb0NBQ1pELGVBQUtYLFFBQVEsWUFBWSxLQUFLLEdBQUdBLFFBQVEsTUFBTSxDQUFBYSxRQUFPQSxLQUFLTCxZQUFZLENBQUMsS0FEM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLG1aQUFJLFdBQVUscUJBQXFCTSxpQkFBT0YsS0FBSyxLQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrRDtBQUFBLG1CQUoxQ0QsS0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsWUFDRCxLQVJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBU0EsSUFFQSx1QkFBQyxtZEFBRSxXQUFVLCtCQUE4Qix5Q0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0U7QUFBQSxlQWZ4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWlCQTtBQUFBLGFBNUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE2Q0E7QUFBQSxXQXhJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeUlBO0FBQUEsTUFHRHRELGNBQWMsY0FDYjtBQUFBLFFBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBQ0MsWUFBWUwsU0FBU2MsY0FBYztBQUFBLFVBQ25DO0FBQUEsVUFDQSxpQkFBaUJIO0FBQUFBO0FBQUFBLFFBSG5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUd1QztBQUFBLE1BSXhDTixjQUFjLFdBQ2I7QUFBQSxRQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUNDLE9BQU9MLFNBQVN5QyxTQUFTO0FBQUEsVUFDekIsYUFBYXpDLFNBQVNnQyxhQUFhLEdBQUdoQyxTQUFTNkIsY0FBYyxFQUFFLElBQUk3QixTQUFTOEIsYUFBYSxFQUFFLElBQUlHLEtBQUssS0FBSztBQUFBO0FBQUEsUUFGM0c7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRTZIO0FBQUEsTUFJOUg1QixjQUFjLFdBQ2IsdUJBQUMsMllBQUksV0FBVSxZQUNiO0FBQUEsK0JBQUMsOGFBQUksV0FBVSwwQ0FDYjtBQUFBLGlDQUFDLDRjQUFHLFdBQVUsMkNBQTBDLHFCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RDtBQUFBLFVBQzdELHVCQUFDLGdlQUFPLFdBQVUsK0VBQ2hCLGlDQUFDLGtZQUFLLE1BQUssUUFBTyxNQUFNLE1BQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJCLEtBRDdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFFBRUNMLFNBQVMrRCxRQUNSLHVCQUFDLG1hQUFFLFdBQVUseUNBQXlDL0QsbUJBQVMrRCxTQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFFLElBRXJFLHVCQUFDLG9aQUFJLFdBQVUsb0JBQ2I7QUFBQSxpQ0FBQyxvY0FBSyxNQUFLLFlBQVcsTUFBTSxJQUFJLFdBQVUscUNBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJFO0FBQUEsVUFDM0UsdUJBQUMsa2NBQUUsV0FBVSx1QkFBc0Isa0NBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFEO0FBQUEsVUFDckQsdUJBQUMsNmRBQU8sV0FBVSxxQ0FBb0MsMEJBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdFO0FBQUEsYUFIbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsV0FmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUJBO0FBQUEsU0EvS0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlMQTtBQUFBLElBRUN4RCxvQkFDQztBQUFBLE1BQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBLFNBQVMsTUFBTUMsb0JBQW9CLEtBQUs7QUFBQSxRQUN4QyxRQUFRLENBQUN3RCxjQUFjO0FBQ3JCQyxrQkFBUUMsSUFBSSxlQUFlRixTQUFTO0FBQ3BDeEQsOEJBQW9CLEtBQUs7QUFBQSxRQUMzQjtBQUFBO0FBQUEsTUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFNSTtBQUFBLElBR0xDLG1CQUNDO0FBQUEsTUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFDQztBQUFBLFFBQ0EsU0FBUyxNQUFNQyxtQkFBbUIsS0FBSztBQUFBLFFBQ3ZDLE9BQU8sQ0FBQ3lELGFBQWE7QUFDbkJGLGtCQUFRQyxJQUFJLGdCQUFnQkMsUUFBUTtBQUNwQ3pELDZCQUFtQixLQUFLO0FBQUEsUUFDMUI7QUFBQTtBQUFBLE1BTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBTUk7QUFBQSxPQXJVUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBd1VBO0FBRUo7QUFBRU4sR0FqWUlMLGVBQWE7QUFBQXFFLEtBQWJyRTtBQW1ZTixlQUFlQTtBQUFjLElBQUFxRTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJmb3JtYXQiLCJJY29uIiwiSW1hZ2UiLCJBY3Rpdml0eVRpbWVsaW5lIiwiRGVhbHNMaXN0IiwiQ29tcG9zZUVtYWlsTW9kYWwiLCJMb2dDYWxsTW9kYWwiLCJDb250YWN0RGV0YWlsIiwiY29udGFjdCIsIm9uRWRpdCIsIm9uRGVsZXRlIiwib25Db250YWN0VXBkYXRlIiwiX3MiLCJhY3RpdmVUYWIiLCJzZXRBY3RpdmVUYWIiLCJpc0VtYWlsTW9kYWxPcGVuIiwic2V0SXNFbWFpbE1vZGFsT3BlbiIsImlzQ2FsbE1vZGFsT3BlbiIsInNldElzQ2FsbE1vZGFsT3BlbiIsImhhbmRsZUFjdGl2aXR5QWRkZWQiLCJuZXdBY3Rpdml0eSIsInVwZGF0ZWRDb250YWN0IiwiYWN0aXZpdGllcyIsImZvcm1hdERhdGUiLCJkYXRlU3RyaW5nIiwiRGF0ZSIsImVycm9yIiwicmVuZGVyU29jaWFsSWNvbiIsInBsYXRmb3JtIiwiZ2V0U29jaWFsUHJvZmlsZXMiLCJwcm9maWxlcyIsImxpbmtlZGluX3VybCIsImxpbmtlZGluIiwidHdpdHRlcl91cmwiLCJ0d2l0dGVyIiwic29jaWFsUHJvZmlsZXMiLCJhdmF0YXJfdXJsIiwiZmlyc3RfbmFtZSIsImxhc3RfbmFtZSIsInN0YXR1cyIsImZ1bGxfbmFtZSIsInRyaW0iLCJwb3NpdGlvbiIsImNvbXBhbnkiLCJuYW1lIiwidGFncyIsIm1hcCIsInRhZyIsImluZGV4IiwiZGVhbHMiLCJsZW5ndGgiLCJlbWFpbCIsInBob25lIiwibW9iaWxlIiwiZGVwYXJ0bWVudCIsImxlYWRfc291cmNlIiwicmVwbGFjZSIsImxhc3RfY29udGFjdF9kYXRlIiwiT2JqZWN0Iiwia2V5cyIsImVudHJpZXMiLCJ1cmwiLCJzdGFydHNXaXRoIiwiY2hhckF0IiwidG9VcHBlckNhc2UiLCJzbGljZSIsImN1c3RvbV9maWVsZHMiLCJrZXkiLCJ2YWx1ZSIsInN0ciIsIlN0cmluZyIsIm5vdGVzIiwiZW1haWxEYXRhIiwiY29uc29sZSIsImxvZyIsImNhbGxEYXRhIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDb250YWN0RGV0YWlsLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IGZvcm1hdCB9IGZyb20gJ2RhdGUtZm5zJztcclxuaW1wb3J0IEljb24gZnJvbSAnY29tcG9uZW50cy9BcHBJY29uJztcclxuaW1wb3J0IEltYWdlIGZyb20gJ2NvbXBvbmVudHMvQXBwSW1hZ2UnO1xyXG5pbXBvcnQgQWN0aXZpdHlUaW1lbGluZSBmcm9tICcuL0FjdGl2aXR5VGltZWxpbmUnO1xyXG5pbXBvcnQgRGVhbHNMaXN0IGZyb20gJy4vRGVhbHNMaXN0JztcclxuaW1wb3J0IENvbXBvc2VFbWFpbE1vZGFsIGZyb20gJy4vQ29tcG9zZUVtYWlsTW9kYWwnO1xyXG5pbXBvcnQgTG9nQ2FsbE1vZGFsIGZyb20gJy4vTG9nQ2FsbE1vZGFsJztcclxuXHJcbmNvbnN0IENvbnRhY3REZXRhaWwgPSAoeyBjb250YWN0LCBvbkVkaXQsIG9uRGVsZXRlLCBvbkNvbnRhY3RVcGRhdGUgfSkgPT4ge1xyXG4gIGNvbnN0IFthY3RpdmVUYWIsIHNldEFjdGl2ZVRhYl0gPSB1c2VTdGF0ZSgnb3ZlcnZpZXcnKTtcclxuICBjb25zdCBbaXNFbWFpbE1vZGFsT3Blbiwgc2V0SXNFbWFpbE1vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2lzQ2FsbE1vZGFsT3Blbiwgc2V0SXNDYWxsTW9kYWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBcclxuICBpZiAoIWNvbnRhY3QpIHJldHVybiBudWxsO1xyXG5cclxuICBjb25zdCBoYW5kbGVBY3Rpdml0eUFkZGVkID0gKG5ld0FjdGl2aXR5KSA9PiB7XHJcbiAgICBpZiAob25Db250YWN0VXBkYXRlKSB7XHJcbiAgICAgIC8vIFVwZGF0ZSB0aGUgY29udGFjdCB3aXRoIHRoZSBuZXcgYWN0aXZpdHlcclxuICAgICAgY29uc3QgdXBkYXRlZENvbnRhY3QgPSB7XHJcbiAgICAgICAgLi4uY29udGFjdCxcclxuICAgICAgICBhY3Rpdml0aWVzOiBbbmV3QWN0aXZpdHksIC4uLihjb250YWN0LmFjdGl2aXRpZXMgfHwgW10pXVxyXG4gICAgICB9O1xyXG4gICAgICBvbkNvbnRhY3RVcGRhdGUodXBkYXRlZENvbnRhY3QpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZvcm1hdERhdGUgPSAoZGF0ZVN0cmluZykgPT4ge1xyXG4gICAgaWYgKCFkYXRlU3RyaW5nKSByZXR1cm4gJ05ldmVyIGNvbnRhY3RlZCc7XHJcbiAgICB0cnkge1xyXG4gICAgICByZXR1cm4gZm9ybWF0KG5ldyBEYXRlKGRhdGVTdHJpbmcpLCAnTU1NIGQsIHl5eXknKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHJldHVybiAnSW52YWxpZCBkYXRlJztcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCByZW5kZXJTb2NpYWxJY29uID0gKHBsYXRmb3JtKSA9PiB7XHJcbiAgICBzd2l0Y2ggKHBsYXRmb3JtKSB7XHJcbiAgICAgIGNhc2UgJ2xpbmtlZGluJzpcclxuICAgICAgICByZXR1cm4gJ0xpbmtlZGluJztcclxuICAgICAgY2FzZSAndHdpdHRlcic6XHJcbiAgICAgICAgcmV0dXJuICdUd2l0dGVyJztcclxuICAgICAgY2FzZSAnZmFjZWJvb2snOlxyXG4gICAgICAgIHJldHVybiAnRmFjZWJvb2snO1xyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHJldHVybiAnTGluayc7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gRXh0cmFjdCBzb2NpYWwgcHJvZmlsZXMgZnJvbSBVUkxzXHJcbiAgY29uc3QgZ2V0U29jaWFsUHJvZmlsZXMgPSAoKSA9PiB7XHJcbiAgICBjb25zdCBwcm9maWxlcyA9IHt9O1xyXG4gICAgaWYgKGNvbnRhY3Q/LmxpbmtlZGluX3VybCkge1xyXG4gICAgICBwcm9maWxlcy5saW5rZWRpbiA9IGNvbnRhY3Q/LmxpbmtlZGluX3VybDtcclxuICAgIH1cclxuICAgIGlmIChjb250YWN0Py50d2l0dGVyX3VybCkge1xyXG4gICAgICBwcm9maWxlcy50d2l0dGVyID0gY29udGFjdD8udHdpdHRlcl91cmw7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gcHJvZmlsZXM7XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgc29jaWFsUHJvZmlsZXMgPSBnZXRTb2NpYWxQcm9maWxlcygpO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zdXJmYWNlIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ib3JkZXIgc2hhZG93LXNtXCI+XHJcbiAgICAgIHsvKiBDb250YWN0IEhlYWRlciAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgYm9yZGVyLWIgYm9yZGVyLWJvcmRlclwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBtZDpmbGV4LXJvdyBtZDppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgbXItNFwiPlxyXG4gICAgICAgICAgICAgIDxJbWFnZVxyXG4gICAgICAgICAgICAgICAgc3JjPXtjb250YWN0Py5hdmF0YXJfdXJsIHx8ICcvYXNzZXRzL2ltYWdlcy9ub19pbWFnZS5wbmcnfVxyXG4gICAgICAgICAgICAgICAgYWx0PXtgJHtjb250YWN0Py5maXJzdF9uYW1lIHx8ICcnfSAke2NvbnRhY3Q/Lmxhc3RfbmFtZSB8fCAnJ31gfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xNiBoLTE2IHJvdW5kZWQtZnVsbCBvYmplY3QtY292ZXJcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgYWJzb2x1dGUgYm90dG9tLTAgcmlnaHQtMCB3LTQgaC00IHJvdW5kZWQtZnVsbCBib3JkZXItMiBib3JkZXItc3VyZmFjZSAke1xyXG4gICAgICAgICAgICAgICAgY29udGFjdD8uc3RhdHVzID09PSAnYWN0aXZlJyA/ICdiZy1zdWNjZXNzJyA6ICdiZy10ZXh0LXRlcnRpYXJ5J1xyXG4gICAgICAgICAgICAgIH1gfT48L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC10ZXh0LXByaW1hcnlcIj5cclxuICAgICAgICAgICAgICAgIHtjb250YWN0Py5mdWxsX25hbWUgfHwgYCR7Y29udGFjdD8uZmlyc3RfbmFtZSB8fCAnJ30gJHtjb250YWN0Py5sYXN0X25hbWUgfHwgJyd9YD8udHJpbSgpIHx8ICdVbm5hbWVkIENvbnRhY3QnfVxyXG4gICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciB0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+XHJcbiAgICAgICAgICAgICAgICA8c3Bhbj57Y29udGFjdD8ucG9zaXRpb24gfHwgJ05vIHBvc2l0aW9uJ308L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJteC0yXCI+4oCiPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4+e2NvbnRhY3Q/LmNvbXBhbnk/Lm5hbWUgfHwgJ05vIENvbXBhbnknfTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0yIG10LTJcIj5cclxuICAgICAgICAgICAgICAgIHtjb250YWN0Py50YWdzPy5tYXAoKHRhZywgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgICAgPHNwYW4gXHJcbiAgICAgICAgICAgICAgICAgICAga2V5PXtgJHt0YWd9LSR7aW5kZXh9YH0gXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTIuNSBweS0wLjUgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1tZWRpdW0gYmctcHJpbWFyeS01MCB0ZXh0LXByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge3RhZ31cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgKSkgfHwgbnVsbH1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNFbWFpbE1vZGFsT3Blbih0cnVlKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLWxnIHRleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC1wcmltYXJ5IGhvdmVyOmJvcmRlci1wcmltYXJ5IHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTE1MCBlYXNlLW91dFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiTWFpbFwiIHNpemU9ezE2fSAvPlxyXG4gICAgICAgICAgICAgIDxzcGFuPkVtYWlsPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc0NhbGxNb2RhbE9wZW4odHJ1ZSl9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMiBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ib3JkZXIgcm91bmRlZC1sZyB0ZXh0LXRleHQtc2Vjb25kYXJ5IGhvdmVyOnRleHQtcHJpbWFyeSBob3Zlcjpib3JkZXItcHJpbWFyeSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0xNTAgZWFzZS1vdXRcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPEljb24gbmFtZT1cIlBob25lXCIgc2l6ZT17MTZ9IC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4+Q2FsbDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgb25DbGljaz17b25FZGl0fVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTIgcHgtMyBweS0yIGJvcmRlciBib3JkZXItYm9yZGVyIHJvdW5kZWQtbGcgdGV4dC10ZXh0LXNlY29uZGFyeSBob3Zlcjp0ZXh0LXByaW1hcnkgaG92ZXI6Ym9yZGVyLXByaW1hcnkgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMTUwIGVhc2Utb3V0XCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJFZGl0XCIgc2l6ZT17MTZ9IC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4+RWRpdDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkLWxnIHRleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC10ZXh0LXByaW1hcnkgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMTUwIGVhc2Utb3V0XCI+XHJcbiAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiTW9yZUhvcml6b250YWxcIiBzaXplPXsxNn0gLz5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHJpZ2h0LTAgbXQtMiB3LTQ4IGJnLXN1cmZhY2Ugcm91bmRlZC1sZyBzaGFkb3ctbGcgYm9yZGVyIGJvcmRlci1ib3JkZXIgei0xMCBoaWRkZW4gZ3JvdXAtaG92ZXI6YmxvY2tcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktMVwiPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17b25EZWxldGV9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCB3LWZ1bGwgaXRlbXMtY2VudGVyIHB4LTQgcHktMiB0ZXh0LXNtIHRleHQtZXJyb3IgaG92ZXI6Ymctc3VyZmFjZS1ob3ZlclwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiVHJhc2gyXCIgc2l6ZT17MTZ9IGNsYXNzTmFtZT1cIm1yLTJcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIERlbGV0ZSBDb250YWN0XHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImZsZXggdy1mdWxsIGl0ZW1zLWNlbnRlciBweC00IHB5LTIgdGV4dC1zbSB0ZXh0LXRleHQtc2Vjb25kYXJ5IGhvdmVyOmJnLXN1cmZhY2UtaG92ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiVXNlclBsdXNcIiBzaXplPXsxNn0gY2xhc3NOYW1lPVwibXItMlwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgQWRkIHRvIENhbXBhaWduXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImZsZXggdy1mdWxsIGl0ZW1zLWNlbnRlciBweC00IHB5LTIgdGV4dC1zbSB0ZXh0LXRleHQtc2Vjb25kYXJ5IGhvdmVyOmJnLXN1cmZhY2UtaG92ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiVGFnXCIgc2l6ZT17MTZ9IGNsYXNzTmFtZT1cIm1yLTJcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIE1hbmFnZSBUYWdzXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICB7LyogVGFicyAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItYm9yZGVyXCI+XHJcbiAgICAgICAgPG5hdiBjbGFzc05hbWU9XCJmbGV4IG92ZXJmbG93LXgtYXV0b1wiPlxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoJ292ZXJ2aWV3Jyl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTQgcHktMyB0ZXh0LXNtIGZvbnQtbWVkaXVtIHdoaXRlc3BhY2Utbm93cmFwICR7XHJcbiAgICAgICAgICAgICAgYWN0aXZlVGFiID09PSAnb3ZlcnZpZXcnID8ndGV4dC1wcmltYXJ5IGJvcmRlci1iLTIgYm9yZGVyLXByaW1hcnknIDondGV4dC10ZXh0LXNlY29uZGFyeSBob3Zlcjp0ZXh0LXRleHQtcHJpbWFyeSdcclxuICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIE92ZXJ2aWV3XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKCdhY3Rpdml0eScpfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9e2BweC00IHB5LTMgdGV4dC1zbSBmb250LW1lZGl1bSB3aGl0ZXNwYWNlLW5vd3JhcCAke1xyXG4gICAgICAgICAgICAgIGFjdGl2ZVRhYiA9PT0gJ2FjdGl2aXR5JyA/J3RleHQtcHJpbWFyeSBib3JkZXItYi0yIGJvcmRlci1wcmltYXJ5JyA6J3RleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC10ZXh0LXByaW1hcnknXHJcbiAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBBY3Rpdml0eVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYignZGVhbHMnKX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0zIHRleHQtc20gZm9udC1tZWRpdW0gd2hpdGVzcGFjZS1ub3dyYXAgJHtcclxuICAgICAgICAgICAgICBhY3RpdmVUYWIgPT09ICdkZWFscycgPyd0ZXh0LXByaW1hcnkgYm9yZGVyLWItMiBib3JkZXItcHJpbWFyeScgOid0ZXh0LXRleHQtc2Vjb25kYXJ5IGhvdmVyOnRleHQtdGV4dC1wcmltYXJ5J1xyXG4gICAgICAgICAgICB9YH1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgRGVhbHMgKHtjb250YWN0Py5kZWFscz8ubGVuZ3RoIHx8IDB9KVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYignbm90ZXMnKX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0zIHRleHQtc20gZm9udC1tZWRpdW0gd2hpdGVzcGFjZS1ub3dyYXAgJHtcclxuICAgICAgICAgICAgICBhY3RpdmVUYWIgPT09ICdub3RlcycgPyd0ZXh0LXByaW1hcnkgYm9yZGVyLWItMiBib3JkZXItcHJpbWFyeScgOid0ZXh0LXRleHQtc2Vjb25kYXJ5IGhvdmVyOnRleHQtdGV4dC1wcmltYXJ5J1xyXG4gICAgICAgICAgICB9YH1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgTm90ZXNcclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvbmF2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgey8qIFRhYiBDb250ZW50ICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNlwiPlxyXG4gICAgICAgIHthY3RpdmVUYWIgPT09ICdvdmVydmlldycgJiYgKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC02XCI+XHJcbiAgICAgICAgICAgIHsvKiBDb250YWN0IEluZm9ybWF0aW9uICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgcC01XCI+XHJcbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXRleHQtcHJpbWFyeSBtYi00XCI+Q29udGFjdCBJbmZvcm1hdGlvbjwvaDM+XHJcbiAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgICAgIHtjb250YWN0Py5lbWFpbCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiTWFpbFwiIHNpemU9ezE2fSBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtdGVydGlhcnkgbXItMlwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtdGV4dC1zZWNvbmRhcnlcIj5FbWFpbDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8YSBocmVmPXtgbWFpbHRvOiR7Y29udGFjdD8uZW1haWx9YH0gY2xhc3NOYW1lPVwidGV4dC1wcmltYXJ5IGhvdmVyOnVuZGVybGluZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2NvbnRhY3Q/LmVtYWlsfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICB7Y29udGFjdD8ucGhvbmUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIlBob25lXCIgc2l6ZT17MTZ9IGNsYXNzTmFtZT1cInRleHQtdGV4dC10ZXJ0aWFyeSBtci0yXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC10ZXh0LXNlY29uZGFyeVwiPlBob25lPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxhIGhyZWY9e2B0ZWw6JHtjb250YWN0Py5waG9uZX1gfSBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtcHJpbWFyeVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2NvbnRhY3Q/LnBob25lfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgIHtjb250YWN0Py5tb2JpbGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIlNtYXJ0cGhvbmVcIiBzaXplPXsxNn0gY2xhc3NOYW1lPVwidGV4dC10ZXh0LXRlcnRpYXJ5IG1yLTJcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+TW9iaWxlPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxhIGhyZWY9e2B0ZWw6JHtjb250YWN0Py5tb2JpbGV9YH0gY2xhc3NOYW1lPVwidGV4dC10ZXh0LXByaW1hcnlcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtjb250YWN0Py5tb2JpbGV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJCdWlsZGluZ1wiIHNpemU9ezE2fSBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtdGVydGlhcnkgbXItMlwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+Q29tcGFueTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtdGV4dC1wcmltYXJ5XCI+e2NvbnRhY3Q/LmNvbXBhbnk/Lm5hbWUgfHwgJ05vIENvbXBhbnknfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICB7Y29udGFjdD8ucG9zaXRpb24gJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIkJyaWVmY2FzZVwiIHNpemU9ezE2fSBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtdGVydGlhcnkgbXItMlwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtdGV4dC1zZWNvbmRhcnlcIj5Qb3NpdGlvbjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtcHJpbWFyeVwiPntjb250YWN0Py5wb3NpdGlvbn08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICB7Y29udGFjdD8uZGVwYXJ0bWVudCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiVXNlcnNcIiBzaXplPXsxNn0gY2xhc3NOYW1lPVwidGV4dC10ZXh0LXRlcnRpYXJ5IG1yLTJcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+RGVwYXJ0bWVudDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtcHJpbWFyeVwiPntjb250YWN0Py5kZXBhcnRtZW50fTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgIHtjb250YWN0Py5sZWFkX3NvdXJjZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiVGFyZ2V0XCIgc2l6ZT17MTZ9IGNsYXNzTmFtZT1cInRleHQtdGV4dC10ZXJ0aWFyeSBtci0yXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC10ZXh0LXNlY29uZGFyeVwiPkxlYWQgU291cmNlPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtdGV4dC1wcmltYXJ5IGNhcGl0YWxpemVcIj57Y29udGFjdD8ubGVhZF9zb3VyY2U/LnJlcGxhY2UoJ18nLCAnICcpfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiQ2FsZW5kYXJcIiBzaXplPXsxNn0gY2xhc3NOYW1lPVwidGV4dC10ZXh0LXRlcnRpYXJ5IG1yLTJcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC10ZXh0LXNlY29uZGFyeVwiPkxhc3QgQ29udGFjdGVkPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC10ZXh0LXByaW1hcnlcIj57Zm9ybWF0RGF0ZShjb250YWN0Py5sYXN0X2NvbnRhY3RfZGF0ZSl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgey8qIFNvY2lhbCBQcm9maWxlcyAmIEN1c3RvbSBGaWVsZHMgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XHJcbiAgICAgICAgICAgICAgey8qIFNvY2lhbCBQcm9maWxlcyAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgcC01XCI+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtdGV4dC1wcmltYXJ5IG1iLTRcIj5Tb2NpYWwgUHJvZmlsZXM8L2gzPlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICB7T2JqZWN0LmtleXMoc29jaWFsUHJvZmlsZXMpPy5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtPYmplY3QuZW50cmllcyhzb2NpYWxQcm9maWxlcyk/Lm1hcCgoW3BsYXRmb3JtLCB1cmxdKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8YSBcclxuICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtwbGF0Zm9ybX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgaHJlZj17dXJsPy5zdGFydHNXaXRoKCdodHRwJykgPyB1cmwgOiBgaHR0cHM6Ly8ke3VybH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZWw9XCJub29wZW5lciBub3JlZmVycmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgdGV4dC10ZXh0LXByaW1hcnkgaG92ZXI6dGV4dC1wcmltYXJ5IHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MCBlYXNlLW91dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9e3JlbmRlclNvY2lhbEljb24ocGxhdGZvcm0pfSBzaXplPXsxNn0gY2xhc3NOYW1lPVwibXItMlwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntwbGF0Zm9ybT8uY2hhckF0KDApPy50b1VwcGVyQ2FzZSgpICsgcGxhdGZvcm0/LnNsaWNlKDEpfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIkV4dGVybmFsTGlua1wiIHNpemU9ezE0fSBjbGFzc05hbWU9XCJtbC0yXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5IHRleHQtc21cIj5ObyBzb2NpYWwgcHJvZmlsZXMgYWRkZWQ8L3A+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIHsvKiBDdXN0b20gRmllbGRzICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZCBwLTVcIj5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC10ZXh0LXByaW1hcnkgbWItNFwiPkFkZGl0aW9uYWwgSW5mb3JtYXRpb248L2gzPlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICB7Y29udGFjdD8uY3VzdG9tX2ZpZWxkcyAmJiBPYmplY3Qua2V5cyhjb250YWN0Py5jdXN0b21fZmllbGRzKT8ubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cclxuICAgICAgICAgICAgICAgICAgICB7T2JqZWN0LmVudHJpZXMoY29udGFjdD8uY3VzdG9tX2ZpZWxkcyk/Lm1hcCgoW2tleSwgdmFsdWVdKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17a2V5fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtdGV4dC1zZWNvbmRhcnkgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtrZXk/LnJlcGxhY2UoLyhbQS1aXSkvZywgJyAkMScpPy5yZXBsYWNlKC9eLi8sIHN0ciA9PiBzdHI/LnRvVXBwZXJDYXNlKCkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtcHJpbWFyeVwiPntTdHJpbmcodmFsdWUpfTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC10ZXh0LXNlY29uZGFyeSB0ZXh0LXNtXCI+Tm8gYWRkaXRpb25hbCBpbmZvcm1hdGlvbjwvcD5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuICAgICAgICBcclxuICAgICAgICB7YWN0aXZlVGFiID09PSAnYWN0aXZpdHknICYmIChcclxuICAgICAgICAgIDxBY3Rpdml0eVRpbWVsaW5lIFxyXG4gICAgICAgICAgICBhY3Rpdml0aWVzPXtjb250YWN0Py5hY3Rpdml0aWVzIHx8IFtdfSBcclxuICAgICAgICAgICAgY29udGFjdD17Y29udGFjdH1cclxuICAgICAgICAgICAgb25BY3Rpdml0eUFkZGVkPXtoYW5kbGVBY3Rpdml0eUFkZGVkfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICApfVxyXG4gICAgICAgIFxyXG4gICAgICAgIHthY3RpdmVUYWIgPT09ICdkZWFscycgJiYgKFxyXG4gICAgICAgICAgPERlYWxzTGlzdCBcclxuICAgICAgICAgICAgZGVhbHM9e2NvbnRhY3Q/LmRlYWxzIHx8IFtdfSBcclxuICAgICAgICAgICAgY29udGFjdE5hbWU9e2NvbnRhY3Q/LmZ1bGxfbmFtZSB8fCBgJHtjb250YWN0Py5maXJzdF9uYW1lIHx8ICcnfSAke2NvbnRhY3Q/Lmxhc3RfbmFtZSB8fCAnJ31gPy50cmltKCkgfHwgJ1VubmFtZWQgQ29udGFjdCd9IFxyXG4gICAgICAgICAgLz5cclxuICAgICAgICApfVxyXG4gICAgICAgIFxyXG4gICAgICAgIHthY3RpdmVUYWIgPT09ICdub3RlcycgJiYgKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIHAtNVwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYi00XCI+XHJcbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXRleHQtcHJpbWFyeVwiPk5vdGVzPC9oMz5cclxuICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeSBob3Zlcjp0ZXh0LXByaW1hcnktNzAwIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MCBlYXNlLW91dFwiPlxyXG4gICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIkVkaXRcIiBzaXplPXsxNn0gLz5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB7Y29udGFjdD8ubm90ZXMgPyAoXHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC10ZXh0LXByaW1hcnkgd2hpdGVzcGFjZS1wcmUtbGluZVwiPntjb250YWN0Py5ub3Rlc308L3A+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS04XCI+XHJcbiAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiRmlsZVRleHRcIiBzaXplPXszMn0gY2xhc3NOYW1lPVwidGV4dC10ZXh0LXRlcnRpYXJ5IG14LWF1dG8gbWItM1wiIC8+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+Tm8gbm90ZXMgYXZhaWxhYmxlPC9wPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJtdC0zIHRleHQtcHJpbWFyeSBob3Zlcjp1bmRlcmxpbmVcIj5BZGQgYSBub3RlPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgey8qIE1vZGFscyAqL31cclxuICAgICAge2lzRW1haWxNb2RhbE9wZW4gJiYgKFxyXG4gICAgICAgIDxDb21wb3NlRW1haWxNb2RhbFxyXG4gICAgICAgICAgY29udGFjdD17Y29udGFjdH1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldElzRW1haWxNb2RhbE9wZW4oZmFsc2UpfVxyXG4gICAgICAgICAgb25TZW5kPXsoZW1haWxEYXRhKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdFbWFpbCBzZW50OicsIGVtYWlsRGF0YSk7XHJcbiAgICAgICAgICAgIHNldElzRW1haWxNb2RhbE9wZW4oZmFsc2UpO1xyXG4gICAgICAgICAgfX1cclxuICAgICAgICAvPlxyXG4gICAgICApfVxyXG4gICAgICB7aXNDYWxsTW9kYWxPcGVuICYmIChcclxuICAgICAgICA8TG9nQ2FsbE1vZGFsXHJcbiAgICAgICAgICBjb250YWN0PXtjb250YWN0fVxyXG4gICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0SXNDYWxsTW9kYWxPcGVuKGZhbHNlKX1cclxuICAgICAgICAgIG9uTG9nPXsoY2FsbERhdGEpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coJ0NhbGwgbG9nZ2VkOicsIGNhbGxEYXRhKTtcclxuICAgICAgICAgICAgc2V0SXNDYWxsTW9kYWxPcGVuKGZhbHNlKTtcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgLz5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDb250YWN0RGV0YWlsOyJdLCJmaWxlIjoiRDovY3VycmVudCBwcm9qZWN0cy9jbGF1ZGUtY29kZS9zcmMvcGFnZXMvY29udGFjdC1tYW5hZ2VtZW50L2NvbXBvbmVudHMvQ29udGFjdERldGFpbC5qc3gifQ==