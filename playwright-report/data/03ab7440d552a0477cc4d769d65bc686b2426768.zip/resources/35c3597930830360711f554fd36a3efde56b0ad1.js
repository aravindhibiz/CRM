import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ErrorBoundary.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport2_react.__esModule ? __vite__cjsImport2_react.default : __vite__cjsImport2_react;
import Icon from "/src/components/AppIcon.jsx";
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }
  static getDerivedStateFromError(error) {
    return { hasError: true };
  }
  componentDidCatch(error, errorInfo) {
    console.log("Error caught by ErrorBoundary:", error, errorInfo);
  }
  render() {
    if (this.state?.hasError) {
      return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\components\\ErrorBoundary.jsx:21:8", "data-component-path": "src\\components\\ErrorBoundary.jsx", "data-component-line": "21", "data-component-file": "ErrorBoundary.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22min-h-screen%20flex%20items-center%20justify-center%20bg-neutral-50%22%7D", className: "min-h-screen flex items-center justify-center bg-neutral-50", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\components\\ErrorBoundary.jsx:22:10", "data-component-path": "src\\components\\ErrorBoundary.jsx", "data-component-line": "22", "data-component-file": "ErrorBoundary.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-center%20p-8%20max-w-md%22%7D", className: "text-center p-8 max-w-md", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\components\\ErrorBoundary.jsx:23:12", "data-component-path": "src\\components\\ErrorBoundary.jsx", "data-component-line": "23", "data-component-file": "ErrorBoundary.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20justify-center%20items-center%20mb-2%22%7D", className: "flex justify-center items-center mb-2", children: /* @__PURE__ */ jsxDEV("svg", { "data-component-id": "src\\components\\ErrorBoundary.jsx:24:14", "data-component-path": "src\\components\\ErrorBoundary.jsx", "data-component-line": "24", "data-component-file": "ErrorBoundary.jsx", "data-component-name": "svg", "data-component-content": "%7B%22elementName%22%3A%22svg%22%7D", xmlns: "http://www.w3.org/2000/svg", width: "42px", height: "42px", viewBox: "0 0 32 33", fill: "none", children: [
          /* @__PURE__ */ jsxDEV("path", { "data-component-id": "src\\components\\ErrorBoundary.jsx:25:16", "data-component-path": "src\\components\\ErrorBoundary.jsx", "data-component-line": "25", "data-component-file": "ErrorBoundary.jsx", "data-component-name": "path", "data-component-content": "%7B%22elementName%22%3A%22path%22%7D", d: "M16 28.5C22.6274 28.5 28 23.1274 28 16.5C28 9.87258 22.6274 4.5 16 4.5C9.37258 4.5 4 9.87258 4 16.5C4 23.1274 9.37258 28.5 16 28.5Z", stroke: "#343330", "stroke-width": "2", "stroke-miterlimit": "10" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/components/ErrorBoundary.jsx",
            lineNumber: 25,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("path", { "data-component-id": "src\\components\\ErrorBoundary.jsx:26:16", "data-component-path": "src\\components\\ErrorBoundary.jsx", "data-component-line": "26", "data-component-file": "ErrorBoundary.jsx", "data-component-name": "path", "data-component-content": "%7B%22elementName%22%3A%22path%22%7D", d: "M11.5 15.5C12.3284 15.5 13 14.8284 13 14C13 13.1716 12.3284 12.5 11.5 12.5C10.6716 12.5 10 13.1716 10 14C10 14.8284 10.6716 15.5 11.5 15.5Z", fill: "#343330" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/components/ErrorBoundary.jsx",
            lineNumber: 26,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("path", { "data-component-id": "src\\components\\ErrorBoundary.jsx:27:16", "data-component-path": "src\\components\\ErrorBoundary.jsx", "data-component-line": "27", "data-component-file": "ErrorBoundary.jsx", "data-component-name": "path", "data-component-content": "%7B%22elementName%22%3A%22path%22%7D", d: "M20.5 15.5C21.3284 15.5 22 14.8284 22 14C22 13.1716 21.3284 12.5 20.5 12.5C19.6716 12.5 19 13.1716 19 14C19 14.8284 19.6716 15.5 20.5 15.5Z", fill: "#343330" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/components/ErrorBoundary.jsx",
            lineNumber: 27,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("path", { "data-component-id": "src\\components\\ErrorBoundary.jsx:28:16", "data-component-path": "src\\components\\ErrorBoundary.jsx", "data-component-line": "28", "data-component-file": "ErrorBoundary.jsx", "data-component-name": "path", "data-component-content": "%7B%22elementName%22%3A%22path%22%7D", d: "M21 22.5C19.9625 20.7062 18.2213 19.5 16 19.5C13.7787 19.5 12.0375 20.7062 11 22.5", stroke: "#343330", "stroke-width": "2", "stroke-linecap": "round", "stroke-linejoin": "round" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/components/ErrorBoundary.jsx",
            lineNumber: 28,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/components/ErrorBoundary.jsx",
          lineNumber: 24,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/components/ErrorBoundary.jsx",
          lineNumber: 23,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\components\\ErrorBoundary.jsx:31:12", "data-component-path": "src\\components\\ErrorBoundary.jsx", "data-component-line": "31", "data-component-file": "ErrorBoundary.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20flex-col%20gap-1%20text-center%22%7D", className: "flex flex-col gap-1 text-center", children: [
          /* @__PURE__ */ jsxDEV("h1", { "data-component-id": "src\\components\\ErrorBoundary.jsx:32:14", "data-component-path": "src\\components\\ErrorBoundary.jsx", "data-component-line": "32", "data-component-file": "ErrorBoundary.jsx", "data-component-name": "h1", "data-component-content": "%7B%22elementName%22%3A%22h1%22%2C%22className%22%3A%22text-2xl%20font-medium%20text-neutral-800%22%2C%22textContent%22%3A%22Something%20went%20wrong%22%7D", className: "text-2xl font-medium text-neutral-800", children: "Something went wrong" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/components/ErrorBoundary.jsx",
            lineNumber: 32,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\components\\ErrorBoundary.jsx:33:14", "data-component-path": "src\\components\\ErrorBoundary.jsx", "data-component-line": "33", "data-component-file": "ErrorBoundary.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-neutral-600%20text-base%20w-8%2F12%20mx-auto%22%2C%22textContent%22%3A%22We%20encountered%20an%20unexpected%20error%20while%20processing%20your%20request.%22%7D", className: "text-neutral-600 text-base w-8/12 mx-auto", children: "We encountered an unexpected error while processing your request." }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/components/ErrorBoundary.jsx",
            lineNumber: 33,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/components/ErrorBoundary.jsx",
          lineNumber: 31,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\components\\ErrorBoundary.jsx:35:12", "data-component-path": "src\\components\\ErrorBoundary.jsx", "data-component-line": "35", "data-component-file": "ErrorBoundary.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20justify-center%20items-center%20mt-6%22%7D", className: "flex justify-center items-center mt-6", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            "data-component-id": "src\\components\\ErrorBoundary.jsx:36:14",
            "data-component-path": "src\\components\\ErrorBoundary.jsx",
            "data-component-line": "36",
            "data-component-file": "ErrorBoundary.jsx",
            "data-component-name": "button",
            "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22bg-blue-500%20hover%3Abg-blue-600%20text-white%20font-medium%20py-2%20px-4%20rounded%20flex%20items-center%20gap-2%20transition-colors%20duration-200%20shadow-sm%22%2C%22textContent%22%3A%22Back%22%7D",
            onClick: () => {
              window.location.href = "/";
            },
            className: "bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded flex items-center gap-2 transition-colors duration-200 shadow-sm",
            children: [
              /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\components\\ErrorBoundary.jsx:42:16", "data-component-path": "src\\components\\ErrorBoundary.jsx", "data-component-line": "42", "data-component-file": "ErrorBoundary.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22ArrowLeft%22%7D", name: "ArrowLeft", size: 18, color: "#fff" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/components/ErrorBoundary.jsx",
                lineNumber: 42,
                columnNumber: 17
              }, this),
              "Back"
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/current projects/claude-code/src/components/ErrorBoundary.jsx",
            lineNumber: 36,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/components/ErrorBoundary.jsx",
          lineNumber: 35,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/components/ErrorBoundary.jsx",
        lineNumber: 22,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/components/ErrorBoundary.jsx",
        lineNumber: 21,
        columnNumber: 9
      }, this);
    }
    return this.props?.children;
  }
}
export default ErrorBoundary;
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/components/ErrorBoundary.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/components/ErrorBoundary.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0JnQjtBQXhCaEIsT0FBT0Esb0JBQWtCO0FBQUE7QUFBQTtBQUN6QixPQUFPQyxVQUFVO0FBRWpCLE1BQU1DLHNCQUFzQkYsTUFBTUcsVUFBVTtBQUFBLEVBQzFDQyxZQUFZQyxPQUFPO0FBQ2pCLFVBQU1BLEtBQUs7QUFDWCxTQUFLQyxRQUFRLEVBQUVDLFVBQVUsTUFBTTtBQUFBLEVBQ2pDO0FBQUEsRUFFQSxPQUFPQyx5QkFBeUJDLE9BQU87QUFDckMsV0FBTyxFQUFFRixVQUFVLEtBQUs7QUFBQSxFQUMxQjtBQUFBLEVBRUFHLGtCQUFrQkQsT0FBT0UsV0FBVztBQUNsQ0MsWUFBUUMsSUFBSSxrQ0FBa0NKLE9BQU9FLFNBQVM7QUFBQSxFQUNoRTtBQUFBLEVBRUFHLFNBQVM7QUFDUCxRQUFJLEtBQUtSLE9BQU9DLFVBQVU7QUFDeEIsYUFDRSx1QkFBQyw0WUFBSSxXQUFVLCtEQUNiLGlDQUFDLHNXQUFJLFdBQVUsNEJBQ2I7QUFBQSwrQkFBQyxxWEFBSSxXQUFVLHlDQUNiLGlDQUFDLCtTQUFJLE9BQU0sOEJBQTZCLE9BQU0sUUFBTyxRQUFPLFFBQU8sU0FBUSxhQUFZLE1BQUssUUFDMUY7QUFBQSxpQ0FBQyxrVEFBSyxHQUFFLHVJQUFzSSxRQUFPLFdBQVUsZ0JBQWEsS0FBSSxxQkFBa0IsUUFBbE07QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc007QUFBQSxVQUN0TSx1QkFBQyxrVEFBSyxHQUFFLCtJQUE4SSxNQUFLLGFBQTNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9LO0FBQUEsVUFDcEssdUJBQUMsa1RBQUssR0FBRSwrSUFBOEksTUFBSyxhQUEzSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvSztBQUFBLFVBQ3BLLHVCQUFDLGtUQUFLLEdBQUUsc0ZBQXFGLFFBQU8sV0FBVSxnQkFBYSxLQUFJLGtCQUFlLFNBQVEsbUJBQWdCLFdBQXRLO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZLO0FBQUEsYUFKL0s7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFDQSx1QkFBQywrV0FBSSxXQUFVLG1DQUNiO0FBQUEsaUNBQUMscWFBQUcsV0FBVSx5Q0FBd0Msb0NBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBFO0FBQUEsVUFDMUUsdUJBQUMsbWVBQUUsV0FBVSw2Q0FBNEMsaUZBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBIO0FBQUEsYUFGNUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxxWEFBSSxXQUFVLHlDQUNiO0FBQUEsVUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU07QUFDYlEscUJBQU9DLFNBQVNDLE9BQU87QUFBQSxZQUN6QjtBQUFBLFlBQ0EsV0FBVTtBQUFBLFlBRVY7QUFBQSxxQ0FBQywrVUFBSyxNQUFLLGFBQVksTUFBTSxJQUFJLE9BQU0sVUFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkM7QUFBQSxjQUFHO0FBQUE7QUFBQTtBQUFBLFVBTmxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsV0F2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXdCQSxLQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMEJBO0FBQUEsSUFFSjtBQUVBLFdBQU8sS0FBS1osT0FBT2E7QUFBQUEsRUFDckI7QUFDRjtBQUVBLGVBQWVoQiIsIm5hbWVzIjpbIlJlYWN0IiwiSWNvbiIsIkVycm9yQm91bmRhcnkiLCJDb21wb25lbnQiLCJjb25zdHJ1Y3RvciIsInByb3BzIiwic3RhdGUiLCJoYXNFcnJvciIsImdldERlcml2ZWRTdGF0ZUZyb21FcnJvciIsImVycm9yIiwiY29tcG9uZW50RGlkQ2F0Y2giLCJlcnJvckluZm8iLCJjb25zb2xlIiwibG9nIiwicmVuZGVyIiwid2luZG93IiwibG9jYXRpb24iLCJocmVmIiwiY2hpbGRyZW4iXSwic291cmNlcyI6WyJFcnJvckJvdW5kYXJ5LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBJY29uIGZyb20gXCIuL0FwcEljb25cIjtcclxuXHJcbmNsYXNzIEVycm9yQm91bmRhcnkgZXh0ZW5kcyBSZWFjdC5Db21wb25lbnQge1xyXG4gIGNvbnN0cnVjdG9yKHByb3BzKSB7XHJcbiAgICBzdXBlcihwcm9wcyk7XHJcbiAgICB0aGlzLnN0YXRlID0geyBoYXNFcnJvcjogZmFsc2UgfTtcclxuICB9XHJcblxyXG4gIHN0YXRpYyBnZXREZXJpdmVkU3RhdGVGcm9tRXJyb3IoZXJyb3IpIHtcclxuICAgIHJldHVybiB7IGhhc0Vycm9yOiB0cnVlIH07XHJcbiAgfVxyXG5cclxuICBjb21wb25lbnREaWRDYXRjaChlcnJvciwgZXJyb3JJbmZvKSB7XHJcbiAgICBjb25zb2xlLmxvZyhcIkVycm9yIGNhdWdodCBieSBFcnJvckJvdW5kYXJ5OlwiLCBlcnJvciwgZXJyb3JJbmZvKTtcclxuICB9XHJcblxyXG4gIHJlbmRlcigpIHtcclxuICAgIGlmICh0aGlzLnN0YXRlPy5oYXNFcnJvcikge1xyXG4gICAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLW5ldXRyYWwtNTBcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcC04IG1heC13LW1kXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgbWItMlwiPlxyXG4gICAgICAgICAgICAgIDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHdpZHRoPVwiNDJweFwiIGhlaWdodD1cIjQycHhcIiB2aWV3Qm94PVwiMCAwIDMyIDMzXCIgZmlsbD1cIm5vbmVcIj5cclxuICAgICAgICAgICAgICAgIDxwYXRoIGQ9XCJNMTYgMjguNUMyMi42Mjc0IDI4LjUgMjggMjMuMTI3NCAyOCAxNi41QzI4IDkuODcyNTggMjIuNjI3NCA0LjUgMTYgNC41QzkuMzcyNTggNC41IDQgOS44NzI1OCA0IDE2LjVDNCAyMy4xMjc0IDkuMzcyNTggMjguNSAxNiAyOC41WlwiIHN0cm9rZT1cIiMzNDMzMzBcIiBzdHJva2Utd2lkdGg9XCIyXCIgc3Ryb2tlLW1pdGVybGltaXQ9XCIxMFwiIC8+XHJcbiAgICAgICAgICAgICAgICA8cGF0aCBkPVwiTTExLjUgMTUuNUMxMi4zMjg0IDE1LjUgMTMgMTQuODI4NCAxMyAxNEMxMyAxMy4xNzE2IDEyLjMyODQgMTIuNSAxMS41IDEyLjVDMTAuNjcxNiAxMi41IDEwIDEzLjE3MTYgMTAgMTRDMTAgMTQuODI4NCAxMC42NzE2IDE1LjUgMTEuNSAxNS41WlwiIGZpbGw9XCIjMzQzMzMwXCIgLz5cclxuICAgICAgICAgICAgICAgIDxwYXRoIGQ9XCJNMjAuNSAxNS41QzIxLjMyODQgMTUuNSAyMiAxNC44Mjg0IDIyIDE0QzIyIDEzLjE3MTYgMjEuMzI4NCAxMi41IDIwLjUgMTIuNUMxOS42NzE2IDEyLjUgMTkgMTMuMTcxNiAxOSAxNEMxOSAxNC44Mjg0IDE5LjY3MTYgMTUuNSAyMC41IDE1LjVaXCIgZmlsbD1cIiMzNDMzMzBcIiAvPlxyXG4gICAgICAgICAgICAgICAgPHBhdGggZD1cIk0yMSAyMi41QzE5Ljk2MjUgMjAuNzA2MiAxOC4yMjEzIDE5LjUgMTYgMTkuNUMxMy43Nzg3IDE5LjUgMTIuMDM3NSAyMC43MDYyIDExIDIyLjVcIiBzdHJva2U9XCIjMzQzMzMwXCIgc3Ryb2tlLXdpZHRoPVwiMlwiIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIiBzdHJva2UtbGluZWpvaW49XCJyb3VuZFwiIC8+XHJcbiAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTEgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1tZWRpdW0gdGV4dC1uZXV0cmFsLTgwMFwiPlNvbWV0aGluZyB3ZW50IHdyb25nPC9oMT5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LW5ldXRyYWwtNjAwIHRleHQtYmFzZSB3LTgvMTIgbXgtYXV0b1wiPldlIGVuY291bnRlcmVkIGFuIHVuZXhwZWN0ZWQgZXJyb3Igd2hpbGUgcHJvY2Vzc2luZyB5b3VyIHJlcXVlc3QuPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBtdC02XCI+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICB3aW5kb3cubG9jYXRpb24uaHJlZiA9IFwiL1wiO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWJsdWUtNTAwIGhvdmVyOmJnLWJsdWUtNjAwIHRleHQtd2hpdGUgZm9udC1tZWRpdW0gcHktMiBweC00IHJvdW5kZWQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMjAwIHNoYWRvdy1zbVwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIkFycm93TGVmdFwiIHNpemU9ezE4fSBjb2xvcj1cIiNmZmZcIiAvPlxyXG4gICAgICAgICAgICAgICAgQmFja1xyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2ID5cclxuICAgICAgICA8L2RpdiA+XHJcbiAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHRoaXMucHJvcHM/LmNoaWxkcmVuO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgRXJyb3JCb3VuZGFyeTsiXSwiZmlsZSI6IkQ6L2N1cnJlbnQgcHJvamVjdHMvY2xhdWRlLWNvZGUvc3JjL2NvbXBvbmVudHMvRXJyb3JCb3VuZGFyeS5qc3gifQ==