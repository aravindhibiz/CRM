import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AppIcon.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/components/AppIcon.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import * as LucideIcons from "/node_modules/.vite/deps/lucide-react.js?v=44ab9529";
import { HelpCircle } from "/node_modules/.vite/deps/lucide-react.js?v=44ab9529";
function Icon({
  name,
  size = 24,
  color = "currentColor",
  className = "",
  strokeWidth = 2,
  ...props
}) {
  const IconComponent = LucideIcons?.[name];
  if (!IconComponent) {
    return /* @__PURE__ */ jsxDEV(HelpCircle, { "data-component-id": "src\\components\\AppIcon.jsx:16:11", "data-component-path": "src\\components\\AppIcon.jsx", "data-component-line": "16", "data-component-file": "AppIcon.jsx", "data-component-name": "HelpCircle", "data-component-content": "%7B%22elementName%22%3A%22HelpCircle%22%2C%22className%22%3A%22%5Bvar%3AclassName%5D%22%2C%22%5Bspread%5D%22%3A%22true%22%7D", size, color: "gray", strokeWidth, className, ...props }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/components/AppIcon.jsx",
      lineNumber: 16,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV(
    IconComponent,
    {
      "data-component-id": "src\\components\\AppIcon.jsx:19:9",
      "data-component-path": "src\\components\\AppIcon.jsx",
      "data-component-line": "19",
      "data-component-file": "AppIcon.jsx",
      "data-component-name": "IconComponent",
      "data-component-content": "%7B%22elementName%22%3A%22IconComponent%22%2C%22className%22%3A%22%5Bvar%3AclassName%5D%22%2C%22%5Bspread%5D%22%3A%22true%22%7D",
      size,
      color,
      strokeWidth,
      className,
      ...props
    },
    void 0,
    false,
    {
      fileName: "D:/current projects/claude-code/src/components/AppIcon.jsx",
      lineNumber: 19,
      columnNumber: 10
    },
    this
  );
}
_c = Icon;
export default Icon;
var _c;
$RefreshReg$(_c, "Icon");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/components/AppIcon.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/components/AppIcon.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZWU7QUFmZixPQUFPQSxvQkFBa0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDekIsWUFBWUMsaUJBQWlCO0FBQzdCLFNBQVNDLGtCQUFrQjtBQUUzQixTQUFTQyxLQUFLO0FBQUEsRUFDVkM7QUFBQUEsRUFDQUMsT0FBTztBQUFBLEVBQ1BDLFFBQVE7QUFBQSxFQUNSQyxZQUFZO0FBQUEsRUFDWkMsY0FBYztBQUFBLEVBQ2QsR0FBR0M7QUFDUCxHQUFHO0FBQ0MsUUFBTUMsZ0JBQWdCVCxjQUFjRyxJQUFJO0FBRXhDLE1BQUksQ0FBQ00sZUFBZTtBQUNoQixXQUFPLHVCQUFDLGtZQUFXLE1BQVksT0FBTSxRQUFPLGFBQTBCLFdBQXNCLEdBQUlELFNBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0Y7QUFBQSxFQUMxRztBQUVBLFNBQU87QUFBQSxJQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUNKO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQSxHQUFJQTtBQUFBQTtBQUFBQSxJQUxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUtPO0FBRWxCO0FBQUNFLEtBckJRUjtBQXNCVCxlQUFlQTtBQUFLLElBQUFRO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsIkx1Y2lkZUljb25zIiwiSGVscENpcmNsZSIsIkljb24iLCJuYW1lIiwic2l6ZSIsImNvbG9yIiwiY2xhc3NOYW1lIiwic3Ryb2tlV2lkdGgiLCJwcm9wcyIsIkljb25Db21wb25lbnQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFwcEljb24uanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCAqIGFzIEx1Y2lkZUljb25zIGZyb20gJ2x1Y2lkZS1yZWFjdCc7XHJcbmltcG9ydCB7IEhlbHBDaXJjbGUgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xyXG5cclxuZnVuY3Rpb24gSWNvbih7XHJcbiAgICBuYW1lLFxyXG4gICAgc2l6ZSA9IDI0LFxyXG4gICAgY29sb3IgPSBcImN1cnJlbnRDb2xvclwiLFxyXG4gICAgY2xhc3NOYW1lID0gXCJcIixcclxuICAgIHN0cm9rZVdpZHRoID0gMixcclxuICAgIC4uLnByb3BzXHJcbn0pIHtcclxuICAgIGNvbnN0IEljb25Db21wb25lbnQgPSBMdWNpZGVJY29ucz8uW25hbWVdO1xyXG5cclxuICAgIGlmICghSWNvbkNvbXBvbmVudCkge1xyXG4gICAgICAgIHJldHVybiA8SGVscENpcmNsZSBzaXplPXtzaXplfSBjb2xvcj1cImdyYXlcIiBzdHJva2VXaWR0aD17c3Ryb2tlV2lkdGh9IGNsYXNzTmFtZT17Y2xhc3NOYW1lfSB7Li4ucHJvcHN9IC8+O1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiA8SWNvbkNvbXBvbmVudFxyXG4gICAgICAgIHNpemU9e3NpemV9XHJcbiAgICAgICAgY29sb3I9e2NvbG9yfVxyXG4gICAgICAgIHN0cm9rZVdpZHRoPXtzdHJva2VXaWR0aH1cclxuICAgICAgICBjbGFzc05hbWU9e2NsYXNzTmFtZX1cclxuICAgICAgICB7Li4ucHJvcHN9XHJcbiAgICAvPjtcclxufVxyXG5leHBvcnQgZGVmYXVsdCBJY29uOyJdLCJmaWxlIjoiRDovY3VycmVudCBwcm9qZWN0cy9jbGF1ZGUtY29kZS9zcmMvY29tcG9uZW50cy9BcHBJY29uLmpzeCJ9