import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/settings-administration/components/SettingsNavigation.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/settings-administration/components/SettingsNavigation.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import Icon from "/src/components/AppIcon.jsx";
const SettingsNavigation = ({ activeSection, onSectionChange }) => {
  const navigationItems = [
    {
      id: "user-management",
      label: "User Management",
      icon: "Users",
      description: "Manage users, roles and status"
    },
    {
      id: "permissions",
      label: "Permissions",
      icon: "Shield",
      description: "Role-based access control"
    },
    {
      id: "integrations",
      label: "Integrations",
      icon: "Plug",
      description: "API connections and services"
    },
    {
      id: "custom-fields",
      label: "Custom Fields",
      icon: "ListPlus",
      description: "Field creation and configuration"
    },
    {
      id: "email-templates",
      label: "Email Templates",
      icon: "Mail",
      description: "Template editor and management"
    },
    {
      id: "system-config",
      label: "System Configuration",
      icon: "Settings",
      description: "General system settings"
    }
  ];
  return /* @__PURE__ */ jsxDEV("nav", { "data-component-id": "src\\pages\\settings-administration\\components\\SettingsNavigation.jsx:46:4", "data-component-path": "src\\pages\\settings-administration\\components\\SettingsNavigation.jsx", "data-component-line": "46", "data-component-file": "SettingsNavigation.jsx", "data-component-name": "nav", "data-component-content": "%7B%22elementName%22%3A%22nav%22%2C%22className%22%3A%22w-80%20bg-surface%20border-r%20border-border%20h-full%22%7D", className: "w-80 bg-surface border-r border-border h-full", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SettingsNavigation.jsx:47:6", "data-component-path": "src\\pages\\settings-administration\\components\\SettingsNavigation.jsx", "data-component-line": "47", "data-component-file": "SettingsNavigation.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22p-6%22%7D", className: "p-6", children: [
    /* @__PURE__ */ jsxDEV("h2", { "data-component-id": "src\\pages\\settings-administration\\components\\SettingsNavigation.jsx:48:8", "data-component-path": "src\\pages\\settings-administration\\components\\SettingsNavigation.jsx", "data-component-line": "48", "data-component-file": "SettingsNavigation.jsx", "data-component-name": "h2", "data-component-content": "%7B%22elementName%22%3A%22h2%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%20mb-6%22%2C%22textContent%22%3A%22Settings%20Categories%22%7D", className: "text-lg font-semibold text-text-primary mb-6", children: "Settings Categories" }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SettingsNavigation.jsx",
      lineNumber: 48,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("ul", { "data-component-id": "src\\pages\\settings-administration\\components\\SettingsNavigation.jsx:49:8", "data-component-path": "src\\pages\\settings-administration\\components\\SettingsNavigation.jsx", "data-component-line": "49", "data-component-file": "SettingsNavigation.jsx", "data-component-name": "ul", "data-component-content": "%7B%22elementName%22%3A%22ul%22%2C%22className%22%3A%22space-y-2%22%7D", className: "space-y-2", children: navigationItems?.map(
      (item) => /* @__PURE__ */ jsxDEV("li", { "data-component-id": "src\\pages\\settings-administration\\components\\SettingsNavigation.jsx:51:10", "data-component-path": "src\\pages\\settings-administration\\components\\SettingsNavigation.jsx", "data-component-line": "51", "data-component-file": "SettingsNavigation.jsx", "data-component-name": "li", "data-component-content": "%7B%22elementName%22%3A%22li%22%7D", children: /* @__PURE__ */ jsxDEV(
        "button",
        {
          "data-component-id": "src\\pages\\settings-administration\\components\\SettingsNavigation.jsx:52:14",
          "data-component-path": "src\\pages\\settings-administration\\components\\SettingsNavigation.jsx",
          "data-component-line": "52",
          "data-component-file": "SettingsNavigation.jsx",
          "data-component-name": "button",
          "data-component-content": "%7B%22elementName%22%3A%22button%22%7D",
          onClick: () => onSectionChange?.(item?.id),
          className: `w-full text-left p-4 rounded-lg transition-all duration-150 ease-smooth group ${activeSection === item?.id ? "bg-primary-50 border border-primary-100 text-primary" : "text-text-secondary hover:text-text-primary hover:bg-surface-hover"}`,
          children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SettingsNavigation.jsx:59:16", "data-component-path": "src\\pages\\settings-administration\\components\\SettingsNavigation.jsx", "data-component-line": "59", "data-component-file": "SettingsNavigation.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-start%20space-x-3%22%7D", className: "flex items-start space-x-3", children: [
            /* @__PURE__ */ jsxDEV(
              Icon,
              {
                "data-component-id": "src\\pages\\settings-administration\\components\\SettingsNavigation.jsx:60:18",
                "data-component-path": "src\\pages\\settings-administration\\components\\SettingsNavigation.jsx",
                "data-component-line": "60",
                "data-component-file": "SettingsNavigation.jsx",
                "data-component-name": "Icon",
                "data-component-content": "%7B%22elementName%22%3A%22Icon%22%7D",
                name: item?.icon,
                size: 20,
                className: `mt-0.5 ${activeSection === item?.id ? "text-primary" : "text-text-tertiary group-hover:text-text-secondary"}`
              },
              void 0,
              false,
              {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SettingsNavigation.jsx",
                lineNumber: 60,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SettingsNavigation.jsx:68:18", "data-component-path": "src\\pages\\settings-administration\\components\\SettingsNavigation.jsx", "data-component-line": "68", "data-component-file": "SettingsNavigation.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex-1%22%7D", className: "flex-1", children: [
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SettingsNavigation.jsx:69:20", "data-component-path": "src\\pages\\settings-administration\\components\\SettingsNavigation.jsx", "data-component-line": "69", "data-component-file": "SettingsNavigation.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", className: `font-medium text-sm ${activeSection === item?.id ? "text-primary" : ""}`, children: item?.label }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SettingsNavigation.jsx",
                lineNumber: 69,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\settings-administration\\components\\SettingsNavigation.jsx:74:20", "data-component-path": "src\\pages\\settings-administration\\components\\SettingsNavigation.jsx", "data-component-line": "74", "data-component-file": "SettingsNavigation.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-xs%20text-text-tertiary%20mt-1%20leading-tight%22%7D", className: "text-xs text-text-tertiary mt-1 leading-tight", children: item?.description }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SettingsNavigation.jsx",
                lineNumber: 74,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SettingsNavigation.jsx",
              lineNumber: 68,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SettingsNavigation.jsx",
            lineNumber: 59,
            columnNumber: 17
          }, this)
        },
        void 0,
        false,
        {
          fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SettingsNavigation.jsx",
          lineNumber: 52,
          columnNumber: 15
        },
        this
      ) }, item?.id, false, {
        fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SettingsNavigation.jsx",
        lineNumber: 51,
        columnNumber: 11
      }, this)
    ) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SettingsNavigation.jsx",
      lineNumber: 49,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SettingsNavigation.jsx",
    lineNumber: 47,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "D:/current projects/claude-code/src/pages/settings-administration/components/SettingsNavigation.jsx",
    lineNumber: 46,
    columnNumber: 5
  }, this);
};
_c = SettingsNavigation;
export default SettingsNavigation;
var _c;
$RefreshReg$(_c, "SettingsNavigation");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/settings-administration/components/SettingsNavigation.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/settings-administration/components/SettingsNavigation.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0NRO0FBL0NSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBLE9BQU9BLFdBQVc7QUFDbEIsT0FBT0MsVUFBVTtBQUVqQixNQUFNQyxxQkFBcUJBLENBQUMsRUFBRUMsZUFBZUMsZ0JBQWdCLE1BQU07QUFDakUsUUFBTUMsa0JBQWtCO0FBQUEsSUFDdEI7QUFBQSxNQUNFQyxJQUFJO0FBQUEsTUFDSkMsT0FBTztBQUFBLE1BQ1BDLE1BQU07QUFBQSxNQUNOQyxhQUFhO0FBQUEsSUFDZjtBQUFBLElBQ0E7QUFBQSxNQUNFSCxJQUFJO0FBQUEsTUFDSkMsT0FBTztBQUFBLE1BQ1BDLE1BQU07QUFBQSxNQUNOQyxhQUFhO0FBQUEsSUFDZjtBQUFBLElBQ0E7QUFBQSxNQUNFSCxJQUFJO0FBQUEsTUFDSkMsT0FBTztBQUFBLE1BQ1BDLE1BQU07QUFBQSxNQUNOQyxhQUFhO0FBQUEsSUFDZjtBQUFBLElBQ0E7QUFBQSxNQUNFSCxJQUFJO0FBQUEsTUFDSkMsT0FBTztBQUFBLE1BQ1BDLE1BQU07QUFBQSxNQUNOQyxhQUFhO0FBQUEsSUFDZjtBQUFBLElBQ0E7QUFBQSxNQUNFSCxJQUFJO0FBQUEsTUFDSkMsT0FBTztBQUFBLE1BQ1BDLE1BQU07QUFBQSxNQUNOQyxhQUFhO0FBQUEsSUFDZjtBQUFBLElBQ0E7QUFBQSxNQUNFSCxJQUFJO0FBQUEsTUFDSkMsT0FBTztBQUFBLE1BQ1BDLE1BQU07QUFBQSxNQUNOQyxhQUFhO0FBQUEsSUFDZjtBQUFBLEVBQUM7QUFHSCxTQUNFLHVCQUFDLDZjQUFJLFdBQVUsaURBQ2IsaUNBQUMsMlpBQUksV0FBVSxPQUNiO0FBQUEsMkJBQUMseWZBQUcsV0FBVSxnREFBK0MsbUNBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0Y7QUFBQSxJQUNoRix1QkFBQyw4WkFBRyxXQUFVLGFBQ1hKLDJCQUFpQks7QUFBQUEsTUFBSSxDQUFDQyxTQUNyQix1QkFBQywyWEFDQztBQUFBLFFBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBQ0MsU0FBUyxNQUFNUCxrQkFBa0JPLE1BQU1MLEVBQUU7QUFBQSxVQUN6QyxXQUFXLGlGQUNUSCxrQkFBa0JRLE1BQU1MLEtBQ3BCLHlEQUF3RCxvRUFBb0U7QUFBQSxVQUdsSSxpQ0FBQyx1YkFBSSxXQUFVLDhCQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFDQyxNQUFNSyxNQUFNSDtBQUFBQSxnQkFDWixNQUFNO0FBQUEsZ0JBQ04sV0FBVyxVQUNUTCxrQkFBa0JRLE1BQU1MLEtBQ3BCLGlCQUFnQixvREFBb0Q7QUFBQTtBQUFBLGNBTDVFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1LO0FBQUEsWUFFTCx1QkFBQywrWkFBSSxXQUFVLFVBQ2I7QUFBQSxxQ0FBQyw4WEFBSSxXQUFXLHVCQUNkSCxrQkFBa0JRLE1BQU1MLEtBQUssaUJBQWlCLEVBQUUsSUFFL0NLLGdCQUFNSixTQUhUO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSUE7QUFBQSxjQUNBLHVCQUFDLDRjQUFJLFdBQVUsaURBQ1pJLGdCQUFNRixlQURUO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUEsZUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQkE7QUFBQTtBQUFBLFFBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQTJCQSxLQTVCT0UsTUFBTUwsSUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNkJBO0FBQUEsSUFDRCxLQWhDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUNBO0FBQUEsT0FuQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW9DQSxLQXJDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBc0NBO0FBRUo7QUFBRU0sS0FqRklWO0FBbUZOLGVBQWVBO0FBQW1CLElBQUFVO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsIkljb24iLCJTZXR0aW5nc05hdmlnYXRpb24iLCJhY3RpdmVTZWN0aW9uIiwib25TZWN0aW9uQ2hhbmdlIiwibmF2aWdhdGlvbkl0ZW1zIiwiaWQiLCJsYWJlbCIsImljb24iLCJkZXNjcmlwdGlvbiIsIm1hcCIsIml0ZW0iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlNldHRpbmdzTmF2aWdhdGlvbi5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gc3JjL3BhZ2VzL3NldHRpbmdzLWFkbWluaXN0cmF0aW9uL2NvbXBvbmVudHMvU2V0dGluZ3NOYXZpZ2F0aW9uLmpzeFxyXG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgSWNvbiBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL0FwcEljb24nO1xyXG5cclxuY29uc3QgU2V0dGluZ3NOYXZpZ2F0aW9uID0gKHsgYWN0aXZlU2VjdGlvbiwgb25TZWN0aW9uQ2hhbmdlIH0pID0+IHtcclxuICBjb25zdCBuYXZpZ2F0aW9uSXRlbXMgPSBbXHJcbiAgICB7XHJcbiAgICAgIGlkOiAndXNlci1tYW5hZ2VtZW50JyxcclxuICAgICAgbGFiZWw6ICdVc2VyIE1hbmFnZW1lbnQnLFxyXG4gICAgICBpY29uOiAnVXNlcnMnLFxyXG4gICAgICBkZXNjcmlwdGlvbjogJ01hbmFnZSB1c2Vycywgcm9sZXMgYW5kIHN0YXR1cydcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGlkOiAncGVybWlzc2lvbnMnLFxyXG4gICAgICBsYWJlbDogJ1Blcm1pc3Npb25zJyxcclxuICAgICAgaWNvbjogJ1NoaWVsZCcsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiAnUm9sZS1iYXNlZCBhY2Nlc3MgY29udHJvbCdcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGlkOiAnaW50ZWdyYXRpb25zJyxcclxuICAgICAgbGFiZWw6ICdJbnRlZ3JhdGlvbnMnLFxyXG4gICAgICBpY29uOiAnUGx1ZycsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiAnQVBJIGNvbm5lY3Rpb25zIGFuZCBzZXJ2aWNlcydcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGlkOiAnY3VzdG9tLWZpZWxkcycsXHJcbiAgICAgIGxhYmVsOiAnQ3VzdG9tIEZpZWxkcycsXHJcbiAgICAgIGljb246ICdMaXN0UGx1cycsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiAnRmllbGQgY3JlYXRpb24gYW5kIGNvbmZpZ3VyYXRpb24nXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBpZDogJ2VtYWlsLXRlbXBsYXRlcycsXHJcbiAgICAgIGxhYmVsOiAnRW1haWwgVGVtcGxhdGVzJyxcclxuICAgICAgaWNvbjogJ01haWwnLFxyXG4gICAgICBkZXNjcmlwdGlvbjogJ1RlbXBsYXRlIGVkaXRvciBhbmQgbWFuYWdlbWVudCdcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGlkOiAnc3lzdGVtLWNvbmZpZycsXHJcbiAgICAgIGxhYmVsOiAnU3lzdGVtIENvbmZpZ3VyYXRpb24nLFxyXG4gICAgICBpY29uOiAnU2V0dGluZ3MnLFxyXG4gICAgICBkZXNjcmlwdGlvbjogJ0dlbmVyYWwgc3lzdGVtIHNldHRpbmdzJ1xyXG4gICAgfVxyXG4gIF07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8bmF2IGNsYXNzTmFtZT1cInctODAgYmctc3VyZmFjZSBib3JkZXItciBib3JkZXItYm9yZGVyIGgtZnVsbFwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNlwiPlxyXG4gICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC10ZXh0LXByaW1hcnkgbWItNlwiPlNldHRpbmdzIENhdGVnb3JpZXM8L2gyPlxyXG4gICAgICAgIDx1bCBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgIHtuYXZpZ2F0aW9uSXRlbXM/Lm1hcCgoaXRlbSkgPT4gKFxyXG4gICAgICAgICAgICA8bGkga2V5PXtpdGVtPy5pZH0+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25TZWN0aW9uQ2hhbmdlPy4oaXRlbT8uaWQpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIHRleHQtbGVmdCBwLTQgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0xNTAgZWFzZS1zbW9vdGggZ3JvdXAgJHtcclxuICAgICAgICAgICAgICAgICAgYWN0aXZlU2VjdGlvbiA9PT0gaXRlbT8uaWRcclxuICAgICAgICAgICAgICAgICAgICA/ICdiZy1wcmltYXJ5LTUwIGJvcmRlciBib3JkZXItcHJpbWFyeS0xMDAgdGV4dC1wcmltYXJ5JyA6J3RleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC10ZXh0LXByaW1hcnkgaG92ZXI6Ymctc3VyZmFjZS1ob3ZlcidcclxuICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBzcGFjZS14LTNcIj5cclxuICAgICAgICAgICAgICAgICAgPEljb25cclxuICAgICAgICAgICAgICAgICAgICBuYW1lPXtpdGVtPy5pY29ufVxyXG4gICAgICAgICAgICAgICAgICAgIHNpemU9ezIwfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YG10LTAuNSAke1xyXG4gICAgICAgICAgICAgICAgICAgICAgYWN0aXZlU2VjdGlvbiA9PT0gaXRlbT8uaWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyAndGV4dC1wcmltYXJ5JyA6J3RleHQtdGV4dC10ZXJ0aWFyeSBncm91cC1ob3Zlcjp0ZXh0LXRleHQtc2Vjb25kYXJ5J1xyXG4gICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgZm9udC1tZWRpdW0gdGV4dC1zbSAke1xyXG4gICAgICAgICAgICAgICAgICAgICAgYWN0aXZlU2VjdGlvbiA9PT0gaXRlbT8uaWQgPyAndGV4dC1wcmltYXJ5JyA6ICcnXHJcbiAgICAgICAgICAgICAgICAgICAgfWB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAge2l0ZW0/LmxhYmVsfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXRleHQtdGVydGlhcnkgbXQtMSBsZWFkaW5nLXRpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7aXRlbT8uZGVzY3JpcHRpb259XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICApKX1cclxuICAgICAgICA8L3VsPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvbmF2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBTZXR0aW5nc05hdmlnYXRpb247Il0sImZpbGUiOiJEOi9jdXJyZW50IHByb2plY3RzL2NsYXVkZS1jb2RlL3NyYy9wYWdlcy9zZXR0aW5ncy1hZG1pbmlzdHJhdGlvbi9jb21wb25lbnRzL1NldHRpbmdzTmF2aWdhdGlvbi5qc3gifQ==