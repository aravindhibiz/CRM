import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/deal-management/components/DealsGridView.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import Icon from "/src/components/AppIcon.jsx";
const DealsGridView = ({ deals, stages, onEditDeal }) => {
  if (deals.length === 0) {
    return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealsGridView.jsx:7:6", "data-component-path": "src\\pages\\deal-management\\components\\DealsGridView.jsx", "data-component-line": "7", "data-component-file": "DealsGridView.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-center%20py-12%22%7D", className: "text-center py-12", children: [
      /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\deal-management\\components\\DealsGridView.jsx:8:8", "data-component-path": "src\\pages\\deal-management\\components\\DealsGridView.jsx", "data-component-line": "8", "data-component-file": "DealsGridView.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Package%22%2C%22className%22%3A%22text-text-tertiary%20mx-auto%20mb-4%22%7D", name: "Package", size: 48, className: "text-text-tertiary mx-auto mb-4" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx",
        lineNumber: 8,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\deal-management\\components\\DealsGridView.jsx:9:8", "data-component-path": "src\\pages\\deal-management\\components\\DealsGridView.jsx", "data-component-line": "9", "data-component-file": "DealsGridView.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-medium%20text-text-primary%20mb-2%22%2C%22textContent%22%3A%22No%20deals%20found%22%7D", className: "text-lg font-medium text-text-primary mb-2", children: "No deals found" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx",
        lineNumber: 9,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\deal-management\\components\\DealsGridView.jsx:12:8", "data-component-path": "src\\pages\\deal-management\\components\\DealsGridView.jsx", "data-component-line": "12", "data-component-file": "DealsGridView.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%22%2C%22textContent%22%3A%22Try%20adjusting%20your%20filters%20or%20create%20a%20new%20deal%22%7D", className: "text-text-secondary", children: "Try adjusting your filters or create a new deal" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx",
        lineNumber: 12,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx",
      lineNumber: 7,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealsGridView.jsx:20:4", "data-component-path": "src\\pages\\deal-management\\components\\DealsGridView.jsx", "data-component-line": "20", "data-component-file": "DealsGridView.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22grid%20grid-cols-1%20md%3Agrid-cols-2%20lg%3Agrid-cols-3%20xl%3Agrid-cols-4%20gap-6%22%7D", className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6", children: deals.map((deal) => {
    const stage = stages.find((s) => s.value === deal.stage);
    return /* @__PURE__ */ jsxDEV(
      "div",
      {
        "data-component-id": "src\\pages\\deal-management\\components\\DealsGridView.jsx:25:10",
        "data-component-path": "src\\pages\\deal-management\\components\\DealsGridView.jsx",
        "data-component-line": "25",
        "data-component-file": "DealsGridView.jsx",
        "data-component-name": "div",
        "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-surface%20rounded-lg%20border%20border-border%20p-6%20hover%3Ashadow-md%20transition-shadow%20duration-200%20cursor-pointer%22%7D",
        className: "bg-surface rounded-lg border border-border p-6 hover:shadow-md transition-shadow duration-200 cursor-pointer",
        onClick: () => onEditDeal(deal),
        children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealsGridView.jsx:31:12", "data-component-path": "src\\pages\\deal-management\\components\\DealsGridView.jsx", "data-component-line": "31", "data-component-file": "DealsGridView.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22mb-4%22%7D", className: "mb-4", children: [
            /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\deal-management\\components\\DealsGridView.jsx:32:14", "data-component-path": "src\\pages\\deal-management\\components\\DealsGridView.jsx", "data-component-line": "32", "data-component-file": "DealsGridView.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%20mb-2%20line-clamp-2%22%7D", className: "text-lg font-semibold text-text-primary mb-2 line-clamp-2", children: deal.name || "Untitled Deal" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx",
              lineNumber: 32,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\deal-management\\components\\DealsGridView.jsx:35:14", "data-component-path": "src\\pages\\deal-management\\components\\DealsGridView.jsx", "data-component-line": "35", "data-component-file": "DealsGridView.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-sm%20text-text-secondary%20line-clamp-2%20min-h-%5B2.5rem%5D%22%7D", className: "text-sm text-text-secondary line-clamp-2 min-h-[2.5rem]", children: deal.description || "No description" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx",
              lineNumber: 35,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx",
            lineNumber: 31,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealsGridView.jsx:41:12", "data-component-path": "src\\pages\\deal-management\\components\\DealsGridView.jsx", "data-component-line": "41", "data-component-file": "DealsGridView.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22mb-4%22%7D", className: "mb-4", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealsGridView.jsx:42:14", "data-component-path": "src\\pages\\deal-management\\components\\DealsGridView.jsx", "data-component-line": "42", "data-component-file": "DealsGridView.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-2xl%20font-bold%20text-text-primary%22%2C%22textContent%22%3A%22%24%22%7D", className: "text-2xl font-bold text-text-primary", children: [
              "$",
              (deal.value || 0).toLocaleString()
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx",
              lineNumber: 42,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealsGridView.jsx:45:14", "data-component-path": "src\\pages\\deal-management\\components\\DealsGridView.jsx", "data-component-line": "45", "data-component-file": "DealsGridView.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%2C%22textContent%22%3A%22%25%20probability%22%7D", className: "text-sm text-text-secondary", children: [
              deal.probability || 0,
              "% probability"
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx",
              lineNumber: 45,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx",
            lineNumber: 41,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealsGridView.jsx:51:12", "data-component-path": "src\\pages\\deal-management\\components\\DealsGridView.jsx", "data-component-line": "51", "data-component-file": "DealsGridView.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22mb-4%22%7D", className: "mb-4", children: /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\DealsGridView.jsx:52:14", "data-component-path": "src\\pages\\deal-management\\components\\DealsGridView.jsx", "data-component-line": "52", "data-component-file": "DealsGridView.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", className: `px-3 py-1 text-xs font-medium rounded-full ${stage?.color || "bg-gray-100 text-gray-800"}`, children: stage?.label || deal.stage }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx",
            lineNumber: 52,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx",
            lineNumber: 51,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealsGridView.jsx:60:12", "data-component-path": "src\\pages\\deal-management\\components\\DealsGridView.jsx", "data-component-line": "60", "data-component-file": "DealsGridView.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-2%20text-xs%20text-text-secondary%22%7D", className: "space-y-2 text-xs text-text-secondary", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealsGridView.jsx:61:14", "data-component-path": "src\\pages\\deal-management\\components\\DealsGridView.jsx", "data-component-line": "61", "data-component-file": "DealsGridView.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\DealsGridView.jsx:62:16", "data-component-path": "src\\pages\\deal-management\\components\\DealsGridView.jsx", "data-component-line": "62", "data-component-file": "DealsGridView.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Created%3A%22%7D", children: "Created:" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx",
                lineNumber: 62,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\DealsGridView.jsx:63:16", "data-component-path": "src\\pages\\deal-management\\components\\DealsGridView.jsx", "data-component-line": "63", "data-component-file": "DealsGridView.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: new Date(deal.created_at).toLocaleDateString() }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx",
                lineNumber: 63,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx",
              lineNumber: 61,
              columnNumber: 15
            }, this),
            deal.updated_at && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealsGridView.jsx:67:14", "data-component-path": "src\\pages\\deal-management\\components\\DealsGridView.jsx", "data-component-line": "67", "data-component-file": "DealsGridView.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\DealsGridView.jsx:68:18", "data-component-path": "src\\pages\\deal-management\\components\\DealsGridView.jsx", "data-component-line": "68", "data-component-file": "DealsGridView.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Updated%3A%22%7D", children: "Updated:" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx",
                lineNumber: 68,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\DealsGridView.jsx:69:18", "data-component-path": "src\\pages\\deal-management\\components\\DealsGridView.jsx", "data-component-line": "69", "data-component-file": "DealsGridView.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: new Date(deal.updated_at).toLocaleDateString() }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx",
                lineNumber: 69,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx",
              lineNumber: 67,
              columnNumber: 15
            }, this),
            deal.contact_name && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealsGridView.jsx:74:14", "data-component-path": "src\\pages\\deal-management\\components\\DealsGridView.jsx", "data-component-line": "74", "data-component-file": "DealsGridView.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\DealsGridView.jsx:75:18", "data-component-path": "src\\pages\\deal-management\\components\\DealsGridView.jsx", "data-component-line": "75", "data-component-file": "DealsGridView.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Contact%3A%22%7D", children: "Contact:" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx",
                lineNumber: 75,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\DealsGridView.jsx:76:18", "data-component-path": "src\\pages\\deal-management\\components\\DealsGridView.jsx", "data-component-line": "76", "data-component-file": "DealsGridView.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22truncate%20ml-2%22%7D", className: "truncate ml-2", children: deal.contact_name }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx",
                lineNumber: 76,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx",
              lineNumber: 74,
              columnNumber: 15
            }, this),
            deal.company_name && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealsGridView.jsx:81:14", "data-component-path": "src\\pages\\deal-management\\components\\DealsGridView.jsx", "data-component-line": "81", "data-component-file": "DealsGridView.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%22%7D", className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\DealsGridView.jsx:82:18", "data-component-path": "src\\pages\\deal-management\\components\\DealsGridView.jsx", "data-component-line": "82", "data-component-file": "DealsGridView.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Company%3A%22%7D", children: "Company:" }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx",
                lineNumber: 82,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\DealsGridView.jsx:83:18", "data-component-path": "src\\pages\\deal-management\\components\\DealsGridView.jsx", "data-component-line": "83", "data-component-file": "DealsGridView.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22truncate%20ml-2%22%7D", className: "truncate ml-2", children: deal.company_name }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx",
                lineNumber: 83,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx",
              lineNumber: 81,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx",
            lineNumber: 60,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\deal-management\\components\\DealsGridView.jsx:89:12", "data-component-path": "src\\pages\\deal-management\\components\\DealsGridView.jsx", "data-component-line": "89", "data-component-file": "DealsGridView.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22mt-4%20pt-4%20border-t%20border-border%22%7D", className: "mt-4 pt-4 border-t border-border", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\deal-management\\components\\DealsGridView.jsx:90:14",
              "data-component-path": "src\\pages\\deal-management\\components\\DealsGridView.jsx",
              "data-component-line": "90",
              "data-component-file": "DealsGridView.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22w-full%20text-sm%20text-primary%20hover%3Atext-primary-600%20font-medium%20flex%20items-center%20justify-center%20space-x-1%22%7D",
              onClick: (e) => {
                e.stopPropagation();
                onEditDeal(deal);
              },
              className: "w-full text-sm text-primary hover:text-primary-600 font-medium flex items-center justify-center space-x-1",
              children: [
                /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\deal-management\\components\\DealsGridView.jsx:97:16", "data-component-path": "src\\pages\\deal-management\\components\\DealsGridView.jsx", "data-component-line": "97", "data-component-file": "DealsGridView.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Edit%22%7D", name: "Edit", size: 14 }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx",
                  lineNumber: 97,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\deal-management\\components\\DealsGridView.jsx:98:16", "data-component-path": "src\\pages\\deal-management\\components\\DealsGridView.jsx", "data-component-line": "98", "data-component-file": "DealsGridView.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Edit%20Deal%22%7D", children: "Edit Deal" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx",
                  lineNumber: 98,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx",
              lineNumber: 90,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx",
            lineNumber: 89,
            columnNumber: 13
          }, this)
        ]
      },
      deal.id,
      true,
      {
        fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx",
        lineNumber: 25,
        columnNumber: 11
      },
      this
    );
  }) }, void 0, false, {
    fileName: "D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx",
    lineNumber: 20,
    columnNumber: 5
  }, this);
};
_c = DealsGridView;
export default DealsGridView;
var _c;
$RefreshReg$(_c, "DealsGridView");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/deal-management/components/DealsGridView.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT1E7QUFQUixPQUFPQSxvQkFBa0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDekIsT0FBT0MsVUFBVTtBQUVqQixNQUFNQyxnQkFBZ0JBLENBQUMsRUFBRUMsT0FBT0MsUUFBUUMsV0FBVyxNQUFNO0FBQ3ZELE1BQUlGLE1BQU1HLFdBQVcsR0FBRztBQUN0QixXQUNFLHVCQUFDLDBZQUFJLFdBQVUscUJBQ2I7QUFBQSw2QkFBQyx3YkFBSyxNQUFLLFdBQVUsTUFBTSxJQUFJLFdBQVUscUNBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEU7QUFBQSxNQUMxRSx1QkFBQyxtZEFBRyxXQUFVLDhDQUE2Qyw4QkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxrZUFBRSxXQUFVLHVCQUFzQiwrREFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxFQUVKO0FBRUEsU0FDRSx1QkFBQyw0Y0FBSSxXQUFVLHVFQUNaSCxnQkFBTUksSUFBSSxDQUFDQyxTQUFTO0FBQ25CLFVBQU1DLFFBQVFMLE9BQU9NLEtBQUssQ0FBQUMsTUFBS0EsRUFBRUMsVUFBVUosS0FBS0MsS0FBSztBQUVyRCxXQUNFO0FBQUEsTUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFQyxXQUFVO0FBQUEsUUFDVixTQUFTLE1BQU1KLFdBQVdHLElBQUk7QUFBQSxRQUc5QjtBQUFBLGlDQUFDLDhYQUFJLFdBQVUsUUFDYjtBQUFBLG1DQUFDLHdiQUFHLFdBQVUsNkRBQ1hBLGVBQUtLLFFBQVEsbUJBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLHFiQUFFLFdBQVUsMkRBQ1ZMLGVBQUtNLGVBQWUsb0JBRHZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUdBLHVCQUFDLDhYQUFJLFdBQVUsUUFDYjtBQUFBLG1DQUFDLGtjQUFJLFdBQVUsd0NBQXVDO0FBQUE7QUFBQSxlQUNqRE4sS0FBS0ksU0FBUyxHQUFHRyxlQUFlO0FBQUEsaUJBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLHFjQUFJLFdBQVUsK0JBQ1pQO0FBQUFBLG1CQUFLUSxlQUFlO0FBQUEsY0FBRTtBQUFBLGlCQUR6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFHQSx1QkFBQyw4WEFBSSxXQUFVLFFBQ2IsaUNBQUMsa1dBQUssV0FBVyw4Q0FDZlAsT0FBT1EsU0FBUywyQkFBMkIsSUFFMUNSLGlCQUFPUyxTQUFTVixLQUFLQyxTQUh4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBLEtBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLFVBR0EsdUJBQUMsbWFBQUksV0FBVSx5Q0FDYjtBQUFBLG1DQUFDLCtaQUFJLFdBQVUscUNBQ2I7QUFBQSxxQ0FBQyx5WUFBSyx3QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFjO0FBQUEsY0FDZCx1QkFBQyxrV0FBTSxjQUFJVSxLQUFLWCxLQUFLWSxVQUFVLEVBQUVDLG1CQUFtQixLQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzRDtBQUFBLGlCQUZ4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFFQ2IsS0FBS2MsY0FDSix1QkFBQywrWkFBSSxXQUFVLHFDQUNiO0FBQUEscUNBQUMseVlBQUssd0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBYztBQUFBLGNBQ2QsdUJBQUMsa1dBQU0sY0FBSUgsS0FBS1gsS0FBS2MsVUFBVSxFQUFFRCxtQkFBbUIsS0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0Q7QUFBQSxpQkFGeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBR0RiLEtBQUtlLGdCQUNKLHVCQUFDLCtaQUFJLFdBQVUscUNBQ2I7QUFBQSxxQ0FBQyx5WUFBSyx3QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFjO0FBQUEsY0FDZCx1QkFBQyw0WUFBSyxXQUFVLGlCQUFpQmYsZUFBS2UsZ0JBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1EO0FBQUEsaUJBRnJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUdEZixLQUFLZ0IsZ0JBQ0osdUJBQUMsK1pBQUksV0FBVSxxQ0FDYjtBQUFBLHFDQUFDLHlZQUFLLHdCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWM7QUFBQSxjQUNkLHVCQUFDLDRZQUFLLFdBQVUsaUJBQWlCaEIsZUFBS2dCLGdCQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtRDtBQUFBLGlCQUZyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsZUF4Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEwQkE7QUFBQSxVQUdBLHVCQUFDLGdhQUFJLFdBQVUsb0NBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUNDLFNBQVMsQ0FBQ0MsTUFBTTtBQUNkQSxrQkFBRUMsZ0JBQWdCO0FBQ2xCckIsMkJBQVdHLElBQUk7QUFBQSxjQUNqQjtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQywwWEFBSyxNQUFLLFFBQU8sTUFBTSxNQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyQjtBQUFBLGdCQUMzQix1QkFBQywwWUFBSyx5QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFlO0FBQUE7QUFBQTtBQUFBLFlBUmpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVNBLEtBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBO0FBQUE7QUFBQSxNQTFFS0EsS0FBS21CO0FBQUFBLE1BRFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQTRFQTtBQUFBLEVBRUosQ0FBQyxLQW5GSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBb0ZBO0FBRUo7QUFBRUMsS0F0R0kxQjtBQXdHTixlQUFlQTtBQUFjLElBQUEwQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJJY29uIiwiRGVhbHNHcmlkVmlldyIsImRlYWxzIiwic3RhZ2VzIiwib25FZGl0RGVhbCIsImxlbmd0aCIsIm1hcCIsImRlYWwiLCJzdGFnZSIsImZpbmQiLCJzIiwidmFsdWUiLCJuYW1lIiwiZGVzY3JpcHRpb24iLCJ0b0xvY2FsZVN0cmluZyIsInByb2JhYmlsaXR5IiwiY29sb3IiLCJsYWJlbCIsIkRhdGUiLCJjcmVhdGVkX2F0IiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwidXBkYXRlZF9hdCIsImNvbnRhY3RfbmFtZSIsImNvbXBhbnlfbmFtZSIsImUiLCJzdG9wUHJvcGFnYXRpb24iLCJpZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiRGVhbHNHcmlkVmlldy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IEljb24gZnJvbSAnY29tcG9uZW50cy9BcHBJY29uJztcclxuXHJcbmNvbnN0IERlYWxzR3JpZFZpZXcgPSAoeyBkZWFscywgc3RhZ2VzLCBvbkVkaXREZWFsIH0pID0+IHtcclxuICBpZiAoZGVhbHMubGVuZ3RoID09PSAwKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LTEyXCI+XHJcbiAgICAgICAgPEljb24gbmFtZT1cIlBhY2thZ2VcIiBzaXplPXs0OH0gY2xhc3NOYW1lPVwidGV4dC10ZXh0LXRlcnRpYXJ5IG14LWF1dG8gbWItNFwiIC8+XHJcbiAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItMlwiPlxyXG4gICAgICAgICAgTm8gZGVhbHMgZm91bmRcclxuICAgICAgICA8L2gzPlxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtdGV4dC1zZWNvbmRhcnlcIj5cclxuICAgICAgICAgIFRyeSBhZGp1c3RpbmcgeW91ciBmaWx0ZXJzIG9yIGNyZWF0ZSBhIG5ldyBkZWFsXHJcbiAgICAgICAgPC9wPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy0zIHhsOmdyaWQtY29scy00IGdhcC02XCI+XHJcbiAgICAgIHtkZWFscy5tYXAoKGRlYWwpID0+IHtcclxuICAgICAgICBjb25zdCBzdGFnZSA9IHN0YWdlcy5maW5kKHMgPT4gcy52YWx1ZSA9PT0gZGVhbC5zdGFnZSk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAga2V5PXtkZWFsLmlkfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zdXJmYWNlIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ib3JkZXIgcC02IGhvdmVyOnNoYWRvdy1tZCB0cmFuc2l0aW9uLXNoYWRvdyBkdXJhdGlvbi0yMDAgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbkVkaXREZWFsKGRlYWwpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7LyogRGVhbCBIZWFkZXIgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNFwiPlxyXG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC10ZXh0LXByaW1hcnkgbWItMiBsaW5lLWNsYW1wLTJcIj5cclxuICAgICAgICAgICAgICAgIHtkZWFsLm5hbWUgfHwgJ1VudGl0bGVkIERlYWwnfVxyXG4gICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXRleHQtc2Vjb25kYXJ5IGxpbmUtY2xhbXAtMiBtaW4taC1bMi41cmVtXVwiPlxyXG4gICAgICAgICAgICAgICAge2RlYWwuZGVzY3JpcHRpb24gfHwgJ05vIGRlc2NyaXB0aW9uJ31cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIERlYWwgVmFsdWUgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtdGV4dC1wcmltYXJ5XCI+XHJcbiAgICAgICAgICAgICAgICAkeyhkZWFsLnZhbHVlIHx8IDApLnRvTG9jYWxlU3RyaW5nKCl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtdGV4dC1zZWNvbmRhcnlcIj5cclxuICAgICAgICAgICAgICAgIHtkZWFsLnByb2JhYmlsaXR5IHx8IDB9JSBwcm9iYWJpbGl0eVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBTdGFnZSBCYWRnZSAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00XCI+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgcHgtMyBweS0xIHRleHQteHMgZm9udC1tZWRpdW0gcm91bmRlZC1mdWxsICR7XHJcbiAgICAgICAgICAgICAgICBzdGFnZT8uY29sb3IgfHwgJ2JnLWdyYXktMTAwIHRleHQtZ3JheS04MDAnXHJcbiAgICAgICAgICAgICAgfWB9PlxyXG4gICAgICAgICAgICAgICAge3N0YWdlPy5sYWJlbCB8fCBkZWFsLnN0YWdlfVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogRGVhbCBNZXRhZGF0YSAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTIgdGV4dC14cyB0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuPkNyZWF0ZWQ6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4+e25ldyBEYXRlKGRlYWwuY3JlYXRlZF9hdCkudG9Mb2NhbGVEYXRlU3RyaW5nKCl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIHtkZWFsLnVwZGF0ZWRfYXQgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4+VXBkYXRlZDo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuPntuZXcgRGF0ZShkZWFsLnVwZGF0ZWRfYXQpLnRvTG9jYWxlRGF0ZVN0cmluZygpfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAge2RlYWwuY29udGFjdF9uYW1lICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuPkNvbnRhY3Q6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0cnVuY2F0ZSBtbC0yXCI+e2RlYWwuY29udGFjdF9uYW1lfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAge2RlYWwuY29tcGFueV9uYW1lICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuPkNvbXBhbnk6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0cnVuY2F0ZSBtbC0yXCI+e2RlYWwuY29tcGFueV9uYW1lfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIEFjdGlvbiBCdXR0b24gKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBwdC00IGJvcmRlci10IGJvcmRlci1ib3JkZXJcIj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xyXG4gICAgICAgICAgICAgICAgICBvbkVkaXREZWFsKGRlYWwpO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LXNtIHRleHQtcHJpbWFyeSBob3Zlcjp0ZXh0LXByaW1hcnktNjAwIGZvbnQtbWVkaXVtIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHNwYWNlLXgtMVwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIkVkaXRcIiBzaXplPXsxNH0gLz5cclxuICAgICAgICAgICAgICAgIDxzcGFuPkVkaXQgRGVhbDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApO1xyXG4gICAgICB9KX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBEZWFsc0dyaWRWaWV3OyJdLCJmaWxlIjoiRDovY3VycmVudCBwcm9qZWN0cy9jbGF1ZGUtY29kZS9zcmMvcGFnZXMvZGVhbC1tYW5hZ2VtZW50L2NvbXBvbmVudHMvRGVhbHNHcmlkVmlldy5qc3gifQ==