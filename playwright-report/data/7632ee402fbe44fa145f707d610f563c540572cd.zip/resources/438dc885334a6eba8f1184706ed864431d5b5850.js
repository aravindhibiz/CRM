import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/sales-dashboard/components/UpcomingTasks.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import Icon from "/src/components/AppIcon.jsx";
import { useAuth } from "/src/contexts/AuthContext.jsx";
import tasksService from "/src/services/tasksService.js";
const UpcomingTasks = () => {
  _s();
  const { user } = useAuth();
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  useEffect(() => {
    if (user) {
      loadUpcomingTasks();
    }
  }, [user]);
  const loadUpcomingTasks = async () => {
    try {
      setLoading(true);
      setError("");
      const data = await tasksService?.getUpcomingTasks(7);
      setTasks(data || []);
    } catch (err) {
      console.error("Error loading upcoming tasks:", err);
      setError("Failed to load tasks");
    } finally {
      setLoading(false);
    }
  };
  const handleCompleteTask = async (taskId) => {
    try {
      await tasksService?.completeTask(taskId);
      loadUpcomingTasks();
    } catch (err) {
      console.error("Error completing task:", err);
      setError("Failed to complete task");
    }
  };
  const getPriorityColor = (priority) => {
    const colors = {
      urgent: "text-red-600 bg-red-100",
      high: "text-orange-600 bg-orange-100",
      medium: "text-yellow-600 bg-yellow-100",
      low: "text-green-600 bg-green-100"
    };
    return colors?.[priority] || "text-gray-600 bg-gray-100";
  };
  const formatDueDate = (dueDate, daysUntilDue) => {
    if (!dueDate)
      return null;
    if (daysUntilDue < 0) {
      return `Overdue by ${Math.abs(daysUntilDue)} day${Math.abs(daysUntilDue) !== 1 ? "s" : ""}`;
    } else if (daysUntilDue === 0) {
      return "Due today";
    } else if (daysUntilDue === 1) {
      return "Due tomorrow";
    } else {
      return `Due in ${daysUntilDue} days`;
    }
  };
  if (!user) {
    return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:69:6", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "69", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-6%22%7D", className: "card p-6", children: [
      /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:70:8", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "70", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%20mb-4%22%2C%22textContent%22%3A%22Upcoming%20Tasks%22%7D", className: "text-lg font-semibold text-text-primary mb-4", children: "Upcoming Tasks" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
        lineNumber: 70,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:71:8", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "71", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-center%20py-8%22%7D", className: "text-center py-8", children: [
        /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:72:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "72", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22CheckSquare%22%2C%22className%22%3A%22text-text-tertiary%20mx-auto%20mb-3%22%7D", name: "CheckSquare", size: 32, className: "text-text-tertiary mx-auto mb-3" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
          lineNumber: 72,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:73:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "73", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20text-sm%22%2C%22textContent%22%3A%22Sign%20in%20to%20view%20your%20tasks%22%7D", className: "text-text-secondary text-sm", children: "Sign in to view your tasks" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
          lineNumber: 73,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
        lineNumber: 71,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
      lineNumber: 69,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:80:4", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "80", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22card%20p-6%22%7D", className: "card p-6", children: [
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:81:6", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "81", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20justify-between%20mb-4%22%7D", className: "flex items-center justify-between mb-4", children: [
      /* @__PURE__ */ jsxDEV("h3", { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:82:8", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "82", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "h3", "data-component-content": "%7B%22elementName%22%3A%22h3%22%2C%22className%22%3A%22text-lg%20font-semibold%20text-text-primary%22%2C%22textContent%22%3A%22Upcoming%20Tasks%22%7D", className: "text-lg font-semibold text-text-primary", children: "Upcoming Tasks" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
        lineNumber: 82,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:83:8",
          "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx",
          "data-component-line": "83",
          "data-component-file": "UpcomingTasks.jsx",
          "data-component-name": "button",
          "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22text-text-tertiary%20hover%3Atext-text-secondary%22%7D",
          onClick: loadUpcomingTasks,
          className: "text-text-tertiary hover:text-text-secondary",
          disabled: loading,
          children: /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:88:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "88", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22RefreshCw%22%7D", name: "RefreshCw", size: 16, className: loading ? "animate-spin" : "" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
            lineNumber: 88,
            columnNumber: 11
          }, this)
        },
        void 0,
        false,
        {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
          lineNumber: 83,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
      lineNumber: 81,
      columnNumber: 7
    }, this),
    error && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:92:6", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "92", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22bg-error-50%20text-error%20text-sm%20p-3%20rounded-lg%20mb-4%22%7D", className: "bg-error-50 text-error text-sm p-3 rounded-lg mb-4", children: error }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
      lineNumber: 92,
      columnNumber: 7
    }, this),
    loading ? /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:97:6", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "97", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-3%22%7D", className: "space-y-3", children: [...Array(4)]?.map(
      (_, index) => /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:99:8", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "99", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22animate-pulse%22%7D", className: "animate-pulse", children: /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:100:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "100", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-3%22%7D", className: "flex items-center space-x-3", children: [
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:101:16", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "101", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22w-4%20h-4%20bg-gray-200%20rounded%22%7D", className: "w-4 h-4 bg-gray-200 rounded" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
          lineNumber: 101,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:102:16", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "102", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex-1%22%7D", className: "flex-1", children: [
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:103:18", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "103", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22h-3%20bg-gray-200%20rounded%20w-3%2F4%20mb-1%22%7D", className: "h-3 bg-gray-200 rounded w-3/4 mb-1" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
            lineNumber: 103,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:104:18", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "104", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22h-2%20bg-gray-200%20rounded%20w-1%2F2%22%7D", className: "h-2 bg-gray-200 rounded w-1/2" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
            lineNumber: 104,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
          lineNumber: 102,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
        lineNumber: 100,
        columnNumber: 15
      }, this) }, index, false, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
        lineNumber: 99,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
      lineNumber: 97,
      columnNumber: 7
    }, this) : tasks?.length === 0 ? /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:111:6", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "111", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22text-center%20py-8%22%7D", className: "text-center py-8", children: [
      /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:112:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "112", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22CheckSquare%22%2C%22className%22%3A%22text-text-tertiary%20mx-auto%20mb-3%22%7D", name: "CheckSquare", size: 32, className: "text-text-tertiary mx-auto mb-3" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
        lineNumber: 112,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:113:10", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "113", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-text-secondary%20text-sm%22%2C%22textContent%22%3A%22No%20upcoming%20tasks%22%7D", className: "text-text-secondary text-sm", children: "No upcoming tasks" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
        lineNumber: 113,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
      lineNumber: 111,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:116:6", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "116", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-4%22%7D", className: "space-y-4", children: [
      tasks?.slice(0, 6)?.map(
        (task) => /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:118:8", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "118", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-start%20space-x-3%20group%22%7D", className: "flex items-start space-x-3 group", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:119:14",
              "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx",
              "data-component-line": "119",
              "data-component-file": "UpcomingTasks.jsx",
              "data-component-name": "button",
              "data-component-content": "%7B%22elementName%22%3A%22button%22%7D",
              onClick: () => handleCompleteTask(task?.id),
              className: `w-4 h-4 rounded border-2 flex-shrink-0 mt-0.5 flex items-center justify-center transition-colors ${task?.status === "completed" ? "bg-success border-success text-white" : "border-border hover:border-primary hover:bg-primary-50"}`,
              children: task?.status === "completed" && /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:127:12", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "127", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Check%22%7D", name: "Check", size: 12 }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
                lineNumber: 127,
                columnNumber: 13
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
              lineNumber: 119,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:131:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "131", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex-1%20min-w-0%22%7D", className: "flex-1 min-w-0", children: [
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:132:16", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "132", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-start%20justify-between%22%7D", className: "flex items-start justify-between", children: [
              /* @__PURE__ */ jsxDEV("h4", { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:133:18", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "133", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "h4", "data-component-content": "%7B%22elementName%22%3A%22h4%22%7D", className: `text-sm font-medium ${task?.status === "completed" ? "text-text-secondary line-through" : "text-text-primary"}`, children: task?.title }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
                lineNumber: 133,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:140:18", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "140", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", className: `px-2 py-1 text-xs rounded-full ${getPriorityColor(task?.priority)} ml-2 flex-shrink-0`, children: task?.priority }, void 0, false, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
                lineNumber: 140,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
              lineNumber: 132,
              columnNumber: 17
            }, this),
            task?.description && /* @__PURE__ */ jsxDEV("p", { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:146:12", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "146", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "p", "data-component-content": "%7B%22elementName%22%3A%22p%22%2C%22className%22%3A%22text-xs%20text-text-secondary%20mt-1%20line-clamp-2%22%7D", className: "text-xs text-text-secondary mt-1 line-clamp-2", children: task?.description }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
              lineNumber: 146,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:151:16", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "151", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%20text-xs%20text-text-tertiary%20mt-2%22%7D", className: "flex items-center space-x-2 text-xs text-text-tertiary mt-2", children: [
              task?.deal && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:154:22", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "154", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Briefcase%22%7D", name: "Briefcase", size: 12 }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
                  lineNumber: 154,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:155:22", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "155", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: task?.deal }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
                  lineNumber: 155,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
                lineNumber: 153,
                columnNumber: 15
              }, this),
              task?.contact && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:161:22", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "161", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22%E2%80%A2%22%7D", children: "•" }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
                  lineNumber: 161,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:162:22", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "162", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22User%22%7D", name: "User", size: 12 }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
                  lineNumber: 162,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:163:22", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "163", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%7D", children: task?.contact }, void 0, false, {
                  fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
                  lineNumber: 163,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
                lineNumber: 160,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
              lineNumber: 151,
              columnNumber: 17
            }, this),
            task?.dueDate && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:169:12", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "169", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", className: `text-xs mt-2 ${task?.isOverdue ? "text-error font-medium" : task?.daysUntilDue === 0 ? "text-warning font-medium" : "text-text-tertiary"}`, children: formatDueDate(task?.dueDate, task?.daysUntilDue) }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
              lineNumber: 169,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
            lineNumber: 131,
            columnNumber: 15
          }, this)
        ] }, task?.id, true, {
          fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
          lineNumber: 118,
          columnNumber: 9
        }, this)
      ),
      tasks?.length > 6 && /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:183:8", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "183", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22pt-3%20border-t%20border-border%22%7D", className: "pt-3 border-t border-border", children: /* @__PURE__ */ jsxDEV("button", { "data-component-id": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx:184:14", "data-component-path": "src\\pages\\sales-dashboard\\components\\UpcomingTasks.jsx", "data-component-line": "184", "data-component-file": "UpcomingTasks.jsx", "data-component-name": "button", "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22text-sm%20text-primary%20hover%3Atext-primary-600%20font-medium%22%2C%22textContent%22%3A%22View%20all%20tasks%20(%20)%20%E2%86%92%22%7D", className: "text-sm text-primary hover:text-primary-600 font-medium", children: [
        "View all tasks (",
        tasks?.length,
        ") →"
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
        lineNumber: 184,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
        lineNumber: 183,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
      lineNumber: 116,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx",
    lineNumber: 80,
    columnNumber: 5
  }, this);
};
_s(UpcomingTasks, "ijwULzul31xSfkvio5tCasl6+Rc=", false, function() {
  return [useAuth];
});
_c = UpcomingTasks;
export default UpcomingTasks;
var _c;
$RefreshReg$(_c, "UpcomingTasks");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/sales-dashboard/components/UpcomingTasks.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUVRLFNBbUZZLFVBbkZaOzJCQXJFUjtBQUFnQkEsTUFBVUMsY0FBUyxPQUFRLHNCQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ2xELE9BQU9DLFVBQVU7QUFDakIsU0FBU0MsZUFBZTtBQUN4QixPQUFPQyxrQkFBa0I7QUFFekIsTUFBTUMsZ0JBQWdCQSxNQUFNO0FBQUFDLEtBQUE7QUFDMUIsUUFBTSxFQUFFQyxLQUFLLElBQUlKLFFBQVE7QUFDekIsUUFBTSxDQUFDSyxPQUFPQyxRQUFRLElBQUlULFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNVLFNBQVNDLFVBQVUsSUFBSVgsU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQ1ksT0FBT0MsUUFBUSxJQUFJYixTQUFTLEVBQUU7QUFFckNDLFlBQVUsTUFBTTtBQUNkLFFBQUlNLE1BQU07QUFDUk8sd0JBQWtCO0FBQUEsSUFDcEI7QUFBQSxFQUNGLEdBQUcsQ0FBQ1AsSUFBSSxDQUFDO0FBRVQsUUFBTU8sb0JBQW9CLFlBQVk7QUFDcEMsUUFBSTtBQUNGSCxpQkFBVyxJQUFJO0FBQ2ZFLGVBQVMsRUFBRTtBQUNYLFlBQU1FLE9BQU8sTUFBTVgsY0FBY1ksaUJBQWlCLENBQUM7QUFDbkRQLGVBQVNNLFFBQVEsRUFBRTtBQUFBLElBQ3JCLFNBQVNFLEtBQUs7QUFDWkMsY0FBUU4sTUFBTSxpQ0FBaUNLLEdBQUc7QUFDbERKLGVBQVMsc0JBQXNCO0FBQUEsSUFDakMsVUFBQztBQUNDRixpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBRUEsUUFBTVEscUJBQXFCLE9BQU9DLFdBQVc7QUFDM0MsUUFBSTtBQUNGLFlBQU1oQixjQUFjaUIsYUFBYUQsTUFBTTtBQUV2Q04sd0JBQWtCO0FBQUEsSUFDcEIsU0FBU0csS0FBSztBQUNaQyxjQUFRTixNQUFNLDBCQUEwQkssR0FBRztBQUMzQ0osZUFBUyx5QkFBeUI7QUFBQSxJQUNwQztBQUFBLEVBQ0Y7QUFFQSxRQUFNUyxtQkFBbUJBLENBQUNDLGFBQWE7QUFDckMsVUFBTUMsU0FBUztBQUFBLE1BQ2JDLFFBQVE7QUFBQSxNQUNSQyxNQUFNO0FBQUEsTUFDTkMsUUFBUTtBQUFBLE1BQ1JDLEtBQUs7QUFBQSxJQUNQO0FBQ0EsV0FBT0osU0FBU0QsUUFBUSxLQUFLO0FBQUEsRUFDL0I7QUFFQSxRQUFNTSxnQkFBZ0JBLENBQUNDLFNBQVNDLGlCQUFpQjtBQUMvQyxRQUFJLENBQUNEO0FBQVMsYUFBTztBQUVyQixRQUFJQyxlQUFlLEdBQUc7QUFDcEIsYUFBTyxjQUFjQyxLQUFLQyxJQUFJRixZQUFZLENBQUMsT0FBT0MsS0FBS0MsSUFBSUYsWUFBWSxNQUFNLElBQUksTUFBTSxFQUFFO0FBQUEsSUFDM0YsV0FBV0EsaUJBQWlCLEdBQUc7QUFDN0IsYUFBTztBQUFBLElBQ1QsV0FBV0EsaUJBQWlCLEdBQUc7QUFDN0IsYUFBTztBQUFBLElBQ1QsT0FBTztBQUNMLGFBQU8sVUFBVUEsWUFBWTtBQUFBLElBQy9CO0FBQUEsRUFDRjtBQUVBLE1BQUksQ0FBQ3hCLE1BQU07QUFDVCxXQUNFLHVCQUFDLG1ZQUFJLFdBQVUsWUFDYjtBQUFBLDZCQUFDLHFkQUFHLFdBQVUsZ0RBQStDLDhCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJFO0FBQUEsTUFDM0UsdUJBQUMsMllBQUksV0FBVSxvQkFDYjtBQUFBLCtCQUFDLCtiQUFLLE1BQUssZUFBYyxNQUFNLElBQUksV0FBVSxxQ0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4RTtBQUFBLFFBQzlFLHVCQUFDLGtkQUFFLFdBQVUsK0JBQThCLDBDQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFFO0FBQUEsV0FGdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxFQUVKO0FBRUEsU0FDRSx1QkFBQyxtWUFBSSxXQUFVLFlBQ2I7QUFBQSwyQkFBQyxxYUFBSSxXQUFVLDBDQUNiO0FBQUEsNkJBQUMsOGNBQUcsV0FBVSwyQ0FBMEMsOEJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0U7QUFBQSxNQUN0RTtBQUFBLFFBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBQ0MsU0FBU087QUFBQUEsVUFDVCxXQUFVO0FBQUEsVUFDVixVQUFVSjtBQUFBQSxVQUVWLGlDQUFDLCtYQUFLLE1BQUssYUFBWSxNQUFNLElBQUksV0FBV0EsVUFBVSxpQkFBaUIsTUFBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEU7QUFBQTtBQUFBLFFBTDVFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1BO0FBQUEsU0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxJQUNDRSxTQUNDLHVCQUFDLHFiQUFJLFdBQVUsc0RBQ1pBLG1CQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBRURGLFVBQ0MsdUJBQUMsa1lBQUksV0FBVSxhQUNaLFdBQUMsR0FBR3dCLE1BQU0sQ0FBQyxDQUFDLEdBQUdDO0FBQUFBLE1BQUksQ0FBQ0MsR0FBR0MsVUFDdEIsdUJBQUMsc1lBQWdCLFdBQVUsaUJBQ3pCLGlDQUFDLDJaQUFJLFdBQVUsK0JBQ2I7QUFBQSwrQkFBQyw2WkFBSSxXQUFVLGlDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkM7QUFBQSxRQUM3Qyx1QkFBQyxrWUFBSSxXQUFVLFVBQ2I7QUFBQSxpQ0FBQyx3YUFBSSxXQUFVLHdDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9EO0FBQUEsVUFDcEQsdUJBQUMsaWFBQUksV0FBVSxtQ0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErQztBQUFBLGFBRmpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BLEtBUFFBLE9BQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsSUFDRCxLQVhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQSxJQUNFN0IsT0FBTzhCLFdBQVcsSUFDcEIsdUJBQUMsNllBQUksV0FBVSxvQkFDYjtBQUFBLDZCQUFDLGljQUFLLE1BQUssZUFBYyxNQUFNLElBQUksV0FBVSxxQ0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4RTtBQUFBLE1BQzlFLHVCQUFDLHFjQUFFLFdBQVUsK0JBQThCLGlDQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTREO0FBQUEsU0FGOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBLElBRUEsdUJBQUMsb1lBQUksV0FBVSxhQUNaOUI7QUFBQUEsYUFBTytCLE1BQU0sR0FBRyxDQUFDLEdBQUdKO0FBQUFBLFFBQUksQ0FBQ0ssU0FDeEIsdUJBQUMsaWFBQW1CLFdBQVUsb0NBQzVCO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUNDLFNBQVMsTUFBTXJCLG1CQUFtQnFCLE1BQU1DLEVBQUU7QUFBQSxjQUMxQyxXQUFXLG9HQUNURCxNQUFNRSxXQUFXLGNBQ2IseUNBQXdDLHdEQUF3RDtBQUFBLGNBR3JHRixnQkFBTUUsV0FBVyxlQUNoQix1QkFBQyw2WEFBSyxNQUFLLFNBQVEsTUFBTSxNQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0QjtBQUFBO0FBQUEsWUFSaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBVUE7QUFBQSxVQUVBLHVCQUFDLDRZQUFJLFdBQVUsa0JBQ2I7QUFBQSxtQ0FBQyxnYUFBSSxXQUFVLG9DQUNiO0FBQUEscUNBQUMsOFZBQUcsV0FBVyx1QkFDYkYsTUFBTUUsV0FBVyxjQUNiLHFDQUFvQyxtQkFBbUIsSUFFMURGLGdCQUFNRyxTQUpUO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxjQUVBLHVCQUFDLG9XQUFLLFdBQVcsa0NBQWtDckIsaUJBQWlCa0IsTUFBTWpCLFFBQVEsQ0FBQyx1QkFDaEZpQixnQkFBTWpCLFlBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBV0E7QUFBQSxZQUVDaUIsTUFBTUksZUFDTCx1QkFBQyx5YUFBRSxXQUFVLGlEQUNWSixnQkFBTUksZUFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFHRix1QkFBQyxpY0FBSSxXQUFVLCtEQUNaSjtBQUFBQSxvQkFBTUssUUFDTCxtQ0FDRTtBQUFBLHVDQUFDLGlZQUFLLE1BQUssYUFBWSxNQUFNLE1BQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdDO0FBQUEsZ0JBQ2hDLHVCQUFDLG9XQUFNTCxnQkFBTUssUUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrQjtBQUFBLG1CQUZwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FHREwsTUFBTU0sV0FDTCxtQ0FDRTtBQUFBLHVDQUFDLDBZQUFLLGlCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQU87QUFBQSxnQkFDUCx1QkFBQyw0WEFBSyxNQUFLLFFBQU8sTUFBTSxNQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyQjtBQUFBLGdCQUMzQix1QkFBQyxvV0FBTU4sZ0JBQU1NLFdBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUI7QUFBQSxtQkFIdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFJQTtBQUFBLGlCQWJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZUE7QUFBQSxZQUVDTixNQUFNVixXQUNMLHVCQUFDLGlXQUFJLFdBQVcsZ0JBQ2RVLE1BQU1PLFlBQ0YsMkJBQ0FQLE1BQU1ULGlCQUFpQixJQUN2Qiw2QkFBNEIsb0JBQW9CLElBRW5ERix3QkFBY1csTUFBTVYsU0FBU1UsTUFBTVQsWUFBWSxLQU5sRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsZUE3Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkErQ0E7QUFBQSxhQTVEUVMsTUFBTUMsSUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTZEQTtBQUFBLE1BQ0Q7QUFBQSxNQUVBakMsT0FBTzhCLFNBQVMsS0FDZix1QkFBQywwWkFBSSxXQUFVLCtCQUNiLGlDQUFDLHVnQkFBTyxXQUFVLDJEQUEwRDtBQUFBO0FBQUEsUUFDekQ5QixPQUFPOEI7QUFBQUEsUUFBTztBQUFBLFdBRGpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJQTtBQUFBLFNBdkVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5RUE7QUFBQSxPQTdHSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBK0dBO0FBRUo7QUFBRWhDLEdBM0xJRCxlQUFhO0FBQUEsVUFDQUYsT0FBTztBQUFBO0FBQUE2QyxLQURwQjNDO0FBNkxOLGVBQWVBO0FBQWMsSUFBQTJDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsIkljb24iLCJ1c2VBdXRoIiwidGFza3NTZXJ2aWNlIiwiVXBjb21pbmdUYXNrcyIsIl9zIiwidXNlciIsInRhc2tzIiwic2V0VGFza3MiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImVycm9yIiwic2V0RXJyb3IiLCJsb2FkVXBjb21pbmdUYXNrcyIsImRhdGEiLCJnZXRVcGNvbWluZ1Rhc2tzIiwiZXJyIiwiY29uc29sZSIsImhhbmRsZUNvbXBsZXRlVGFzayIsInRhc2tJZCIsImNvbXBsZXRlVGFzayIsImdldFByaW9yaXR5Q29sb3IiLCJwcmlvcml0eSIsImNvbG9ycyIsInVyZ2VudCIsImhpZ2giLCJtZWRpdW0iLCJsb3ciLCJmb3JtYXREdWVEYXRlIiwiZHVlRGF0ZSIsImRheXNVbnRpbER1ZSIsIk1hdGgiLCJhYnMiLCJBcnJheSIsIm1hcCIsIl8iLCJpbmRleCIsImxlbmd0aCIsInNsaWNlIiwidGFzayIsImlkIiwic3RhdHVzIiwidGl0bGUiLCJkZXNjcmlwdGlvbiIsImRlYWwiLCJjb250YWN0IiwiaXNPdmVyZHVlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJVcGNvbWluZ1Rhc2tzLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IEljb24gZnJvbSAnY29tcG9uZW50cy9BcHBJY29uJztcclxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uLy4uLy4uL2NvbnRleHRzL0F1dGhDb250ZXh0JztcclxuaW1wb3J0IHRhc2tzU2VydmljZSBmcm9tICcuLi8uLi8uLi9zZXJ2aWNlcy90YXNrc1NlcnZpY2UnO1xyXG5cclxuY29uc3QgVXBjb21pbmdUYXNrcyA9ICgpID0+IHtcclxuICBjb25zdCB7IHVzZXIgfSA9IHVzZUF1dGgoKTtcclxuICBjb25zdCBbdGFza3MsIHNldFRhc2tzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZSgnJyk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAodXNlcikge1xyXG4gICAgICBsb2FkVXBjb21pbmdUYXNrcygpO1xyXG4gICAgfVxyXG4gIH0sIFt1c2VyXSk7XHJcblxyXG4gIGNvbnN0IGxvYWRVcGNvbWluZ1Rhc2tzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0TG9hZGluZyh0cnVlKTtcclxuICAgICAgc2V0RXJyb3IoJycpO1xyXG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgdGFza3NTZXJ2aWNlPy5nZXRVcGNvbWluZ1Rhc2tzKDcpOyAvLyBOZXh0IDcgZGF5c1xyXG4gICAgICBzZXRUYXNrcyhkYXRhIHx8IFtdKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBsb2FkaW5nIHVwY29taW5nIHRhc2tzOicsIGVycik7XHJcbiAgICAgIHNldEVycm9yKCdGYWlsZWQgdG8gbG9hZCB0YXNrcycpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ29tcGxldGVUYXNrID0gYXN5bmMgKHRhc2tJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgdGFza3NTZXJ2aWNlPy5jb21wbGV0ZVRhc2sodGFza0lkKTtcclxuICAgICAgLy8gUmVmcmVzaCB0YXNrcyBhZnRlciBjb21wbGV0aW9uXHJcbiAgICAgIGxvYWRVcGNvbWluZ1Rhc2tzKCk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgY29tcGxldGluZyB0YXNrOicsIGVycik7XHJcbiAgICAgIHNldEVycm9yKCdGYWlsZWQgdG8gY29tcGxldGUgdGFzaycpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGdldFByaW9yaXR5Q29sb3IgPSAocHJpb3JpdHkpID0+IHtcclxuICAgIGNvbnN0IGNvbG9ycyA9IHtcclxuICAgICAgdXJnZW50OiAndGV4dC1yZWQtNjAwIGJnLXJlZC0xMDAnLFxyXG4gICAgICBoaWdoOiAndGV4dC1vcmFuZ2UtNjAwIGJnLW9yYW5nZS0xMDAnLCBcclxuICAgICAgbWVkaXVtOiAndGV4dC15ZWxsb3ctNjAwIGJnLXllbGxvdy0xMDAnLFxyXG4gICAgICBsb3c6ICd0ZXh0LWdyZWVuLTYwMCBiZy1ncmVlbi0xMDAnXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIGNvbG9ycz8uW3ByaW9yaXR5XSB8fCAndGV4dC1ncmF5LTYwMCBiZy1ncmF5LTEwMCc7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZm9ybWF0RHVlRGF0ZSA9IChkdWVEYXRlLCBkYXlzVW50aWxEdWUpID0+IHtcclxuICAgIGlmICghZHVlRGF0ZSkgcmV0dXJuIG51bGw7XHJcbiAgICBcclxuICAgIGlmIChkYXlzVW50aWxEdWUgPCAwKSB7XHJcbiAgICAgIHJldHVybiBgT3ZlcmR1ZSBieSAke01hdGguYWJzKGRheXNVbnRpbER1ZSl9IGRheSR7TWF0aC5hYnMoZGF5c1VudGlsRHVlKSAhPT0gMSA/ICdzJyA6ICcnfWA7XHJcbiAgICB9IGVsc2UgaWYgKGRheXNVbnRpbER1ZSA9PT0gMCkge1xyXG4gICAgICByZXR1cm4gJ0R1ZSB0b2RheSc7XHJcbiAgICB9IGVsc2UgaWYgKGRheXNVbnRpbER1ZSA9PT0gMSkge1xyXG4gICAgICByZXR1cm4gJ0R1ZSB0b21vcnJvdyc7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4gYER1ZSBpbiAke2RheXNVbnRpbER1ZX0gZGF5c2A7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgaWYgKCF1c2VyKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgcC02XCI+XHJcbiAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXRleHQtcHJpbWFyeSBtYi00XCI+VXBjb21pbmcgVGFza3M8L2gzPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktOFwiPlxyXG4gICAgICAgICAgPEljb24gbmFtZT1cIkNoZWNrU3F1YXJlXCIgc2l6ZT17MzJ9IGNsYXNzTmFtZT1cInRleHQtdGV4dC10ZXJ0aWFyeSBteC1hdXRvIG1iLTNcIiAvPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC10ZXh0LXNlY29uZGFyeSB0ZXh0LXNtXCI+U2lnbiBpbiB0byB2aWV3IHlvdXIgdGFza3M8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgcC02XCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTRcIj5cclxuICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtdGV4dC1wcmltYXJ5XCI+VXBjb21pbmcgVGFza3M8L2gzPlxyXG4gICAgICAgIDxidXR0b24gXHJcbiAgICAgICAgICBvbkNsaWNrPXtsb2FkVXBjb21pbmdUYXNrc31cclxuICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtdGV4dC10ZXJ0aWFyeSBob3Zlcjp0ZXh0LXRleHQtc2Vjb25kYXJ5XCJcclxuICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxJY29uIG5hbWU9XCJSZWZyZXNoQ3dcIiBzaXplPXsxNn0gY2xhc3NOYW1lPXtsb2FkaW5nID8gJ2FuaW1hdGUtc3BpbicgOiAnJ30gLz5cclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIHtlcnJvciAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1lcnJvci01MCB0ZXh0LWVycm9yIHRleHQtc20gcC0zIHJvdW5kZWQtbGcgbWItNFwiPlxyXG4gICAgICAgICAge2Vycm9yfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgICB7bG9hZGluZyA/IChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxyXG4gICAgICAgICAge1suLi5BcnJheSg0KV0/Lm1hcCgoXywgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgPGRpdiBrZXk9e2luZGV4fSBjbGFzc05hbWU9XCJhbmltYXRlLXB1bHNlXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTNcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy00IGgtNCBiZy1ncmF5LTIwMCByb3VuZGVkXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMyBiZy1ncmF5LTIwMCByb3VuZGVkIHctMy80IG1iLTFcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTIgYmctZ3JheS0yMDAgcm91bmRlZCB3LTEvMlwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICkgOiB0YXNrcz8ubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktOFwiPlxyXG4gICAgICAgICAgPEljb24gbmFtZT1cIkNoZWNrU3F1YXJlXCIgc2l6ZT17MzJ9IGNsYXNzTmFtZT1cInRleHQtdGV4dC10ZXJ0aWFyeSBteC1hdXRvIG1iLTNcIiAvPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC10ZXh0LXNlY29uZGFyeSB0ZXh0LXNtXCI+Tm8gdXBjb21pbmcgdGFza3M8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICkgOiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cclxuICAgICAgICAgIHt0YXNrcz8uc2xpY2UoMCwgNik/Lm1hcCgodGFzaykgPT4gKFxyXG4gICAgICAgICAgICA8ZGl2IGtleT17dGFzaz8uaWR9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgc3BhY2UteC0zIGdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQ29tcGxldGVUYXNrKHRhc2s/LmlkKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctNCBoLTQgcm91bmRlZCBib3JkZXItMiBmbGV4LXNocmluay0wIG10LTAuNSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0cmFuc2l0aW9uLWNvbG9ycyAke1xyXG4gICAgICAgICAgICAgICAgICB0YXNrPy5zdGF0dXMgPT09ICdjb21wbGV0ZWQnXHJcbiAgICAgICAgICAgICAgICAgICAgPyAnYmctc3VjY2VzcyBib3JkZXItc3VjY2VzcyB0ZXh0LXdoaXRlJyA6J2JvcmRlci1ib3JkZXIgaG92ZXI6Ym9yZGVyLXByaW1hcnkgaG92ZXI6YmctcHJpbWFyeS01MCdcclxuICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHt0YXNrPy5zdGF0dXMgPT09ICdjb21wbGV0ZWQnICYmIChcclxuICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIkNoZWNrXCIgc2l6ZT17MTJ9IC8+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LTBcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT17YHRleHQtc20gZm9udC1tZWRpdW0gJHtcclxuICAgICAgICAgICAgICAgICAgICB0YXNrPy5zdGF0dXMgPT09ICdjb21wbGV0ZWQnIFxyXG4gICAgICAgICAgICAgICAgICAgICAgPyAndGV4dC10ZXh0LXNlY29uZGFyeSBsaW5lLXRocm91Z2gnIDondGV4dC10ZXh0LXByaW1hcnknXHJcbiAgICAgICAgICAgICAgICAgIH1gfT5cclxuICAgICAgICAgICAgICAgICAgICB7dGFzaz8udGl0bGV9XHJcbiAgICAgICAgICAgICAgICAgIDwvaDQ+XHJcbiAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0yIHB5LTEgdGV4dC14cyByb3VuZGVkLWZ1bGwgJHtnZXRQcmlvcml0eUNvbG9yKHRhc2s/LnByaW9yaXR5KX0gbWwtMiBmbGV4LXNocmluay0wYH0+XHJcbiAgICAgICAgICAgICAgICAgICAge3Rhc2s/LnByaW9yaXR5fVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAge3Rhc2s/LmRlc2NyaXB0aW9uICYmIChcclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXRleHQtc2Vjb25kYXJ5IG10LTEgbGluZS1jbGFtcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3Rhc2s/LmRlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMiB0ZXh0LXhzIHRleHQtdGV4dC10ZXJ0aWFyeSBtdC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIHt0YXNrPy5kZWFsICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIkJyaWVmY2FzZVwiIHNpemU9ezEyfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3Rhc2s/LmRlYWx9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAge3Rhc2s/LmNvbnRhY3QgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj7igKI8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiVXNlclwiIHNpemU9ezEyfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3Rhc2s/LmNvbnRhY3R9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIHt0YXNrPy5kdWVEYXRlICYmIChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2B0ZXh0LXhzIG10LTIgJHtcclxuICAgICAgICAgICAgICAgICAgICB0YXNrPy5pc092ZXJkdWUgXHJcbiAgICAgICAgICAgICAgICAgICAgICA/ICd0ZXh0LWVycm9yIGZvbnQtbWVkaXVtJyBcclxuICAgICAgICAgICAgICAgICAgICAgIDogdGFzaz8uZGF5c1VudGlsRHVlID09PSAwXHJcbiAgICAgICAgICAgICAgICAgICAgICA/ICd0ZXh0LXdhcm5pbmcgZm9udC1tZWRpdW0nIDondGV4dC10ZXh0LXRlcnRpYXJ5J1xyXG4gICAgICAgICAgICAgICAgICB9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1hdER1ZURhdGUodGFzaz8uZHVlRGF0ZSwgdGFzaz8uZGF5c1VudGlsRHVlKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICkpfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICB7dGFza3M/Lmxlbmd0aCA+IDYgJiYgKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTMgYm9yZGVyLXQgYm9yZGVyLWJvcmRlclwiPlxyXG4gICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXByaW1hcnkgaG92ZXI6dGV4dC1wcmltYXJ5LTYwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgVmlldyBhbGwgdGFza3MgKHt0YXNrcz8ubGVuZ3RofSkg4oaSXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBVcGNvbWluZ1Rhc2tzOyJdLCJmaWxlIjoiRDovY3VycmVudCBwcm9qZWN0cy9jbGF1ZGUtY29kZS9zcmMvcGFnZXMvc2FsZXMtZGFzaGJvYXJkL2NvbXBvbmVudHMvVXBjb21pbmdUYXNrcy5qc3gifQ==