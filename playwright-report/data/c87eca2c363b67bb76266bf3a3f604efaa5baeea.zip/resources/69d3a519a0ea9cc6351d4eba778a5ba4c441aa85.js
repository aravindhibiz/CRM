import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/activity-timeline/components/ActivityFilters.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import Icon from "/src/components/AppIcon.jsx";
const ActivityFilters = ({ selectedFilters, onFiltersChange }) => {
  const activityTypes = [
    { value: "all", label: "All Activities", icon: "Activity" },
    { value: "email", label: "Emails", icon: "Mail" },
    { value: "call", label: "Calls", icon: "Phone" },
    { value: "meeting", label: "Meetings", icon: "Calendar" },
    { value: "deal_update", label: "Deal Updates", icon: "TrendingUp" },
    { value: "task", label: "Tasks", icon: "CheckSquare" }
  ];
  const dateRanges = [
    { value: "all", label: "All Time" },
    { value: "today", label: "Today" },
    { value: "week", label: "This Week" },
    { value: "month", label: "This Month" }
  ];
  const channels = [
    { value: "all", label: "All Channels", icon: "Globe" },
    { value: "gmail", label: "Gmail", icon: "Mail" },
    { value: "twilio", label: "Phone", icon: "Phone" },
    { value: "calendar", label: "Calendar", icon: "Calendar" },
    { value: "system", label: "System", icon: "Settings" }
  ];
  const teamMembers = [
    { value: "all", label: "All Team Members" },
    { value: "michael", label: "Michael Rodriguez" },
    { value: "jennifer", label: "Jennifer Walsh" },
    { value: "alex", label: "Alex Thompson" },
    { value: "sarah", label: "Sarah Chen" }
  ];
  const handleFilterChange = (filterType, value) => {
    onFiltersChange({
      ...selectedFilters,
      [filterType]: value
    });
  };
  return /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:45:4", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "45", "data-component-file": "ActivityFilters.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-6%22%7D", className: "space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:47:6", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "47", "data-component-file": "ActivityFilters.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
      /* @__PURE__ */ jsxDEV("h4", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:48:8", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "48", "data-component-file": "ActivityFilters.jsx", "data-component-name": "h4", "data-component-content": "%7B%22elementName%22%3A%22h4%22%2C%22className%22%3A%22text-sm%20font-medium%20text-text-primary%20mb-3%22%2C%22textContent%22%3A%22Activity%20Type%22%7D", className: "text-sm font-medium text-text-primary mb-3", children: "Activity Type" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
        lineNumber: 48,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:49:8", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "49", "data-component-file": "ActivityFilters.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-2%22%7D", className: "space-y-2", children: activityTypes?.map(
        (type) => /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:51:10", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "51", "data-component-file": "ActivityFilters.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22flex%20items-center%20space-x-3%20cursor-pointer%22%7D", className: "flex items-center space-x-3 cursor-pointer", children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:52:14",
              "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx",
              "data-component-line": "52",
              "data-component-file": "ActivityFilters.jsx",
              "data-component-name": "input",
              "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22radio%22%2C%22name%22%3A%22activityType%22%2C%22className%22%3A%22w-4%20h-4%20text-primary%20border-border%20focus%3Aring-primary-500%22%7D",
              type: "radio",
              name: "activityType",
              value: type?.value,
              checked: selectedFilters?.activityType === type?.value,
              onChange: (e) => handleFilterChange("activityType", e?.target?.value),
              className: "w-4 h-4 text-primary border-border focus:ring-primary-500"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
              lineNumber: 52,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:60:14", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "60", "data-component-file": "ActivityFilters.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%22%7D", className: "flex items-center space-x-2", children: [
            /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:61:16", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "61", "data-component-file": "ActivityFilters.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22className%22%3A%22text-text-secondary%22%7D", name: type?.icon, size: 16, className: "text-text-secondary" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
              lineNumber: 61,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:62:16", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "62", "data-component-file": "ActivityFilters.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%7D", className: "text-sm text-text-secondary", children: type?.label }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
              lineNumber: 62,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
            lineNumber: 60,
            columnNumber: 15
          }, this)
        ] }, type?.value, true, {
          fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
          lineNumber: 51,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
        lineNumber: 49,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
      lineNumber: 47,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:69:6", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "69", "data-component-file": "ActivityFilters.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
      /* @__PURE__ */ jsxDEV("h4", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:70:8", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "70", "data-component-file": "ActivityFilters.jsx", "data-component-name": "h4", "data-component-content": "%7B%22elementName%22%3A%22h4%22%2C%22className%22%3A%22text-sm%20font-medium%20text-text-primary%20mb-3%22%2C%22textContent%22%3A%22Date%20Range%22%7D", className: "text-sm font-medium text-text-primary mb-3", children: "Date Range" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
        lineNumber: 70,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:71:8", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "71", "data-component-file": "ActivityFilters.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-2%22%7D", className: "space-y-2", children: dateRanges?.map(
        (range) => /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:73:10", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "73", "data-component-file": "ActivityFilters.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22flex%20items-center%20space-x-3%20cursor-pointer%22%7D", className: "flex items-center space-x-3 cursor-pointer", children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:74:14",
              "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx",
              "data-component-line": "74",
              "data-component-file": "ActivityFilters.jsx",
              "data-component-name": "input",
              "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22radio%22%2C%22name%22%3A%22dateRange%22%2C%22className%22%3A%22w-4%20h-4%20text-primary%20border-border%20focus%3Aring-primary-500%22%7D",
              type: "radio",
              name: "dateRange",
              value: range?.value,
              checked: selectedFilters?.dateRange === range?.value,
              onChange: (e) => handleFilterChange("dateRange", e?.target?.value),
              className: "w-4 h-4 text-primary border-border focus:ring-primary-500"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
              lineNumber: 74,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:82:14", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "82", "data-component-file": "ActivityFilters.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%7D", className: "text-sm text-text-secondary", children: range?.label }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
            lineNumber: 82,
            columnNumber: 15
          }, this)
        ] }, range?.value, true, {
          fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
          lineNumber: 73,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
        lineNumber: 71,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
      lineNumber: 69,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:88:6", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "88", "data-component-file": "ActivityFilters.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
      /* @__PURE__ */ jsxDEV("h4", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:89:8", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "89", "data-component-file": "ActivityFilters.jsx", "data-component-name": "h4", "data-component-content": "%7B%22elementName%22%3A%22h4%22%2C%22className%22%3A%22text-sm%20font-medium%20text-text-primary%20mb-3%22%2C%22textContent%22%3A%22Communication%20Channel%22%7D", className: "text-sm font-medium text-text-primary mb-3", children: "Communication Channel" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
        lineNumber: 89,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:90:8", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "90", "data-component-file": "ActivityFilters.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-2%22%7D", className: "space-y-2", children: channels?.map(
        (channel) => /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:92:10", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "92", "data-component-file": "ActivityFilters.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22flex%20items-center%20space-x-3%20cursor-pointer%22%7D", className: "flex items-center space-x-3 cursor-pointer", children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:93:14",
              "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx",
              "data-component-line": "93",
              "data-component-file": "ActivityFilters.jsx",
              "data-component-name": "input",
              "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22radio%22%2C%22name%22%3A%22channel%22%2C%22className%22%3A%22w-4%20h-4%20text-primary%20border-border%20focus%3Aring-primary-500%22%7D",
              type: "radio",
              name: "channel",
              value: channel?.value,
              checked: selectedFilters?.channel === channel?.value,
              onChange: (e) => handleFilterChange("channel", e?.target?.value),
              className: "w-4 h-4 text-primary border-border focus:ring-primary-500"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
              lineNumber: 93,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:101:14", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "101", "data-component-file": "ActivityFilters.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%22%7D", className: "flex items-center space-x-2", children: [
            /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:102:16", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "102", "data-component-file": "ActivityFilters.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22className%22%3A%22text-text-secondary%22%7D", name: channel?.icon, size: 16, className: "text-text-secondary" }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
              lineNumber: 102,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:103:16", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "103", "data-component-file": "ActivityFilters.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%7D", className: "text-sm text-text-secondary", children: channel?.label }, void 0, false, {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
              lineNumber: 103,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
            lineNumber: 101,
            columnNumber: 15
          }, this)
        ] }, channel?.value, true, {
          fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
          lineNumber: 92,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
        lineNumber: 90,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
      lineNumber: 88,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:110:6", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "110", "data-component-file": "ActivityFilters.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%7D", children: [
      /* @__PURE__ */ jsxDEV("h4", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:111:8", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "111", "data-component-file": "ActivityFilters.jsx", "data-component-name": "h4", "data-component-content": "%7B%22elementName%22%3A%22h4%22%2C%22className%22%3A%22text-sm%20font-medium%20text-text-primary%20mb-3%22%2C%22textContent%22%3A%22Team%20Member%22%7D", className: "text-sm font-medium text-text-primary mb-3", children: "Team Member" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
        lineNumber: 111,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:112:8", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "112", "data-component-file": "ActivityFilters.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-2%22%7D", className: "space-y-2", children: teamMembers?.map(
        (member) => /* @__PURE__ */ jsxDEV("label", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:114:10", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "114", "data-component-file": "ActivityFilters.jsx", "data-component-name": "label", "data-component-content": "%7B%22elementName%22%3A%22label%22%2C%22className%22%3A%22flex%20items-center%20space-x-3%20cursor-pointer%22%7D", className: "flex items-center space-x-3 cursor-pointer", children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:115:14",
              "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx",
              "data-component-line": "115",
              "data-component-file": "ActivityFilters.jsx",
              "data-component-name": "input",
              "data-component-content": "%7B%22elementName%22%3A%22input%22%2C%22type%22%3A%22radio%22%2C%22name%22%3A%22teamMember%22%2C%22className%22%3A%22w-4%20h-4%20text-primary%20border-border%20focus%3Aring-primary-500%22%7D",
              type: "radio",
              name: "teamMember",
              value: member?.value,
              checked: selectedFilters?.teamMember === member?.value,
              onChange: (e) => handleFilterChange("teamMember", e?.target?.value),
              className: "w-4 h-4 text-primary border-border focus:ring-primary-500"
            },
            void 0,
            false,
            {
              fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
              lineNumber: 115,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:123:14", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "123", "data-component-file": "ActivityFilters.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-sm%20text-text-secondary%22%7D", className: "text-sm text-text-secondary", children: member?.label }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
            lineNumber: 123,
            columnNumber: 15
          }, this)
        ] }, member?.value, true, {
          fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
          lineNumber: 114,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
        lineNumber: 112,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
      lineNumber: 110,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:129:6", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "129", "data-component-file": "ActivityFilters.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22pt-4%20border-t%20border-border%22%7D", className: "pt-4 border-t border-border", children: [
      /* @__PURE__ */ jsxDEV("h4", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:130:8", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "130", "data-component-file": "ActivityFilters.jsx", "data-component-name": "h4", "data-component-content": "%7B%22elementName%22%3A%22h4%22%2C%22className%22%3A%22text-sm%20font-medium%20text-text-primary%20mb-3%22%2C%22textContent%22%3A%22Quick%20Actions%22%7D", className: "text-sm font-medium text-text-primary mb-3", children: "Quick Actions" }, void 0, false, {
        fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
        lineNumber: 130,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:131:8", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "131", "data-component-file": "ActivityFilters.jsx", "data-component-name": "div", "data-component-content": "%7B%22elementName%22%3A%22div%22%2C%22className%22%3A%22space-y-2%22%7D", className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV("button", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:132:10", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "132", "data-component-file": "ActivityFilters.jsx", "data-component-name": "button", "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22w-full%20flex%20items-center%20space-x-2%20px-3%20py-2%20text-sm%20text-text-secondary%20hover%3Atext-primary%20hover%3Abg-primary-50%20rounded-lg%20transition-all%20duration-150%20ease-out%22%7D", className: "w-full flex items-center space-x-2 px-3 py-2 text-sm text-text-secondary hover:text-primary hover:bg-primary-50 rounded-lg transition-all duration-150 ease-out", children: [
          /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:133:12", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "133", "data-component-file": "ActivityFilters.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Filter%22%7D", name: "Filter", size: 16 }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
            lineNumber: 133,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:134:12", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "134", "data-component-file": "ActivityFilters.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Save%20Current%20Filter%22%7D", children: "Save Current Filter" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
            lineNumber: 134,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
          lineNumber: 132,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:137:10", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "137", "data-component-file": "ActivityFilters.jsx", "data-component-name": "button", "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22w-full%20flex%20items-center%20space-x-2%20px-3%20py-2%20text-sm%20text-text-secondary%20hover%3Atext-primary%20hover%3Abg-primary-50%20rounded-lg%20transition-all%20duration-150%20ease-out%22%7D", className: "w-full flex items-center space-x-2 px-3 py-2 text-sm text-text-secondary hover:text-primary hover:bg-primary-50 rounded-lg transition-all duration-150 ease-out", children: [
          /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:138:12", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "138", "data-component-file": "ActivityFilters.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22RefreshCw%22%7D", name: "RefreshCw", size: 16 }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
            lineNumber: 138,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:139:12", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "139", "data-component-file": "ActivityFilters.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Refresh%20Timeline%22%7D", children: "Refresh Timeline" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
            lineNumber: 139,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
          lineNumber: 137,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:142:10", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "142", "data-component-file": "ActivityFilters.jsx", "data-component-name": "button", "data-component-content": "%7B%22elementName%22%3A%22button%22%2C%22className%22%3A%22w-full%20flex%20items-center%20space-x-2%20px-3%20py-2%20text-sm%20text-text-secondary%20hover%3Atext-primary%20hover%3Abg-primary-50%20rounded-lg%20transition-all%20duration-150%20ease-out%22%7D", className: "w-full flex items-center space-x-2 px-3 py-2 text-sm text-text-secondary hover:text-primary hover:bg-primary-50 rounded-lg transition-all duration-150 ease-out", children: [
          /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:143:12", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "143", "data-component-file": "ActivityFilters.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Settings%22%7D", name: "Settings", size: 16 }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
            lineNumber: 143,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx:144:12", "data-component-path": "src\\pages\\activity-timeline\\components\\ActivityFilters.jsx", "data-component-line": "144", "data-component-file": "ActivityFilters.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22textContent%22%3A%22Timeline%20Settings%22%7D", children: "Timeline Settings" }, void 0, false, {
            fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
            lineNumber: 144,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
          lineNumber: 142,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
        lineNumber: 131,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
      lineNumber: 129,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx",
    lineNumber: 45,
    columnNumber: 5
  }, this);
};
_c = ActivityFilters;
export default ActivityFilters;
var _c;
$RefreshReg$(_c, "ActivityFilters");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/pages/activity-timeline/components/ActivityFilters.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0NRO0FBL0NSLE9BQU9BLG9CQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN6QixPQUFPQyxVQUFVO0FBRWpCLE1BQU1DLGtCQUFrQkEsQ0FBQyxFQUFFQyxpQkFBaUJDLGdCQUFnQixNQUFNO0FBQ2hFLFFBQU1DLGdCQUFnQjtBQUFBLElBQ3BCLEVBQUVDLE9BQU8sT0FBT0MsT0FBTyxrQkFBa0JDLE1BQU0sV0FBVztBQUFBLElBQzFELEVBQUVGLE9BQU8sU0FBU0MsT0FBTyxVQUFVQyxNQUFNLE9BQU87QUFBQSxJQUNoRCxFQUFFRixPQUFPLFFBQVFDLE9BQU8sU0FBU0MsTUFBTSxRQUFRO0FBQUEsSUFDL0MsRUFBRUYsT0FBTyxXQUFXQyxPQUFPLFlBQVlDLE1BQU0sV0FBVztBQUFBLElBQ3hELEVBQUVGLE9BQU8sZUFBZUMsT0FBTyxnQkFBZ0JDLE1BQU0sYUFBYTtBQUFBLElBQ2xFLEVBQUVGLE9BQU8sUUFBUUMsT0FBTyxTQUFTQyxNQUFNLGNBQWM7QUFBQSxFQUFDO0FBR3hELFFBQU1DLGFBQWE7QUFBQSxJQUNqQixFQUFFSCxPQUFPLE9BQU9DLE9BQU8sV0FBVztBQUFBLElBQ2xDLEVBQUVELE9BQU8sU0FBU0MsT0FBTyxRQUFRO0FBQUEsSUFDakMsRUFBRUQsT0FBTyxRQUFRQyxPQUFPLFlBQVk7QUFBQSxJQUNwQyxFQUFFRCxPQUFPLFNBQVNDLE9BQU8sYUFBYTtBQUFBLEVBQUM7QUFHekMsUUFBTUcsV0FBVztBQUFBLElBQ2YsRUFBRUosT0FBTyxPQUFPQyxPQUFPLGdCQUFnQkMsTUFBTSxRQUFRO0FBQUEsSUFDckQsRUFBRUYsT0FBTyxTQUFTQyxPQUFPLFNBQVNDLE1BQU0sT0FBTztBQUFBLElBQy9DLEVBQUVGLE9BQU8sVUFBVUMsT0FBTyxTQUFTQyxNQUFNLFFBQVE7QUFBQSxJQUNqRCxFQUFFRixPQUFPLFlBQVlDLE9BQU8sWUFBWUMsTUFBTSxXQUFXO0FBQUEsSUFDekQsRUFBRUYsT0FBTyxVQUFVQyxPQUFPLFVBQVVDLE1BQU0sV0FBVztBQUFBLEVBQUM7QUFHeEQsUUFBTUcsY0FBYztBQUFBLElBQ2xCLEVBQUVMLE9BQU8sT0FBT0MsT0FBTyxtQkFBbUI7QUFBQSxJQUMxQyxFQUFFRCxPQUFPLFdBQVdDLE9BQU8sb0JBQW9CO0FBQUEsSUFDL0MsRUFBRUQsT0FBTyxZQUFZQyxPQUFPLGlCQUFpQjtBQUFBLElBQzdDLEVBQUVELE9BQU8sUUFBUUMsT0FBTyxnQkFBZ0I7QUFBQSxJQUN4QyxFQUFFRCxPQUFPLFNBQVNDLE9BQU8sYUFBYTtBQUFBLEVBQUM7QUFHekMsUUFBTUsscUJBQXFCQSxDQUFDQyxZQUFZUCxVQUFVO0FBQ2hERixvQkFBZ0I7QUFBQSxNQUNkLEdBQUdEO0FBQUFBLE1BQ0gsQ0FBQ1UsVUFBVSxHQUFHUDtBQUFBQSxJQUNoQixDQUFDO0FBQUEsRUFDSDtBQUVBLFNBQ0UsdUJBQUMsNFlBQUksV0FBVSxhQUViO0FBQUEsMkJBQUMsd1dBQ0M7QUFBQSw2QkFBQyw0ZEFBRyxXQUFVLDhDQUE2Qyw2QkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3RTtBQUFBLE1BQ3hFLHVCQUFDLDRZQUFJLFdBQVUsYUFDWkQseUJBQWVTO0FBQUFBLFFBQUksQ0FBQ0MsU0FDbkIsdUJBQUMsMGJBQXdCLFdBQVUsOENBQ2pDO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE1BQUs7QUFBQSxjQUNMLE9BQU9BLE1BQU1UO0FBQUFBLGNBQ2IsU0FBU0gsaUJBQWlCYSxpQkFBaUJELE1BQU1UO0FBQUFBLGNBQ2pELFVBQVUsQ0FBQ1csTUFBTUwsbUJBQW1CLGdCQUFnQkssR0FBR0MsUUFBUVosS0FBSztBQUFBLGNBQ3BFLFdBQVU7QUFBQTtBQUFBLFlBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTXVFO0FBQUEsVUFFdkUsdUJBQUMsbWFBQUksV0FBVSwrQkFDYjtBQUFBLG1DQUFDLHdaQUFLLE1BQU1TLE1BQU1QLE1BQU0sTUFBTSxJQUFJLFdBQVUseUJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlFO0FBQUEsWUFDakUsdUJBQUMsb2FBQUssV0FBVSwrQkFBK0JPLGdCQUFNUixTQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyRDtBQUFBLGVBRjdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQVpVUSxNQUFNVCxPQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYUE7QUFBQSxNQUNELEtBaEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpQkE7QUFBQSxTQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb0JBO0FBQUEsSUFFQSx1QkFBQyx3V0FDQztBQUFBLDZCQUFDLHlkQUFHLFdBQVUsOENBQTZDLDBCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFFO0FBQUEsTUFDckUsdUJBQUMsNFlBQUksV0FBVSxhQUNaRyxzQkFBWUs7QUFBQUEsUUFBSSxDQUFDSyxVQUNoQix1QkFBQywwYkFBeUIsV0FBVSw4Q0FDbEM7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsTUFBSztBQUFBLGNBQ0wsT0FBT0EsT0FBT2I7QUFBQUEsY0FDZCxTQUFTSCxpQkFBaUJpQixjQUFjRCxPQUFPYjtBQUFBQSxjQUMvQyxVQUFVLENBQUNXLE1BQU1MLG1CQUFtQixhQUFhSyxHQUFHQyxRQUFRWixLQUFLO0FBQUEsY0FDakUsV0FBVTtBQUFBO0FBQUEsWUFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNdUU7QUFBQSxVQUV2RSx1QkFBQyxvYUFBSyxXQUFVLCtCQUErQmEsaUJBQU9aLFNBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTREO0FBQUEsYUFUbERZLE9BQU9iLE9BQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLE1BQ0QsS0FiSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBY0E7QUFBQSxTQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUJBO0FBQUEsSUFFQSx1QkFBQyx3V0FDQztBQUFBLDZCQUFDLG9lQUFHLFdBQVUsOENBQTZDLHFDQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdGO0FBQUEsTUFDaEYsdUJBQUMsNFlBQUksV0FBVSxhQUNaSSxvQkFBVUk7QUFBQUEsUUFBSSxDQUFDTyxZQUNkLHVCQUFDLDBiQUEyQixXQUFVLDhDQUNwQztBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxNQUFLO0FBQUEsY0FDTCxPQUFPQSxTQUFTZjtBQUFBQSxjQUNoQixTQUFTSCxpQkFBaUJrQixZQUFZQSxTQUFTZjtBQUFBQSxjQUMvQyxVQUFVLENBQUNXLE1BQU1MLG1CQUFtQixXQUFXSyxHQUFHQyxRQUFRWixLQUFLO0FBQUEsY0FDL0QsV0FBVTtBQUFBO0FBQUEsWUFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNdUU7QUFBQSxVQUV2RSx1QkFBQyxxYUFBSSxXQUFVLCtCQUNiO0FBQUEsbUNBQUMsMFpBQUssTUFBTWUsU0FBU2IsTUFBTSxNQUFNLElBQUksV0FBVSx5QkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0U7QUFBQSxZQUNwRSx1QkFBQyxzYUFBSyxXQUFVLCtCQUErQmEsbUJBQVNkLFNBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThEO0FBQUEsZUFGaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBWlVjLFNBQVNmLE9BQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLE1BQ0QsS0FoQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWlCQTtBQUFBLFNBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQkE7QUFBQSxJQUVBLHVCQUFDLDBXQUNDO0FBQUEsNkJBQUMsNGRBQUcsV0FBVSw4Q0FBNkMsMkJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0U7QUFBQSxNQUN0RSx1QkFBQyw4WUFBSSxXQUFVLGFBQ1pLLHVCQUFhRztBQUFBQSxRQUFJLENBQUNRLFdBQ2pCLHVCQUFDLDRiQUEwQixXQUFVLDhDQUNuQztBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxNQUFLO0FBQUEsY0FDTCxPQUFPQSxRQUFRaEI7QUFBQUEsY0FDZixTQUFTSCxpQkFBaUJvQixlQUFlRCxRQUFRaEI7QUFBQUEsY0FDakQsVUFBVSxDQUFDVyxNQUFNTCxtQkFBbUIsY0FBY0ssR0FBR0MsUUFBUVosS0FBSztBQUFBLGNBQ2xFLFdBQVU7QUFBQTtBQUFBLFlBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTXVFO0FBQUEsVUFFdkUsdUJBQUMsc2FBQUssV0FBVSwrQkFBK0JnQixrQkFBUWYsU0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkQ7QUFBQSxhQVRuRGUsUUFBUWhCLE9BQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLE1BQ0QsS0FiSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBY0E7QUFBQSxTQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUJBO0FBQUEsSUFFQSx1QkFBQyxvYUFBSSxXQUFVLCtCQUNiO0FBQUEsNkJBQUMsOGRBQUcsV0FBVSw4Q0FBNkMsNkJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0U7QUFBQSxNQUN4RSx1QkFBQyw4WUFBSSxXQUFVLGFBQ2I7QUFBQSwrQkFBQyw0a0JBQU8sV0FBVSxtS0FDaEI7QUFBQSxpQ0FBQyx3WUFBSyxNQUFLLFVBQVMsTUFBTSxNQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2QjtBQUFBLFVBQzdCLHVCQUFDLGthQUFLLG1DQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlCO0FBQUEsYUFGM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFFQSx1QkFBQyw0a0JBQU8sV0FBVSxtS0FDaEI7QUFBQSxpQ0FBQywyWUFBSyxNQUFLLGFBQVksTUFBTSxNQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnQztBQUFBLFVBQ2hDLHVCQUFDLDZaQUFLLGdDQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNCO0FBQUEsYUFGeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFFQSx1QkFBQyw0a0JBQU8sV0FBVSxtS0FDaEI7QUFBQSxpQ0FBQywwWUFBSyxNQUFLLFlBQVcsTUFBTSxNQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErQjtBQUFBLFVBQy9CLHVCQUFDLDhaQUFLLGlDQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVCO0FBQUEsYUFGekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZUE7QUFBQSxTQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0JBO0FBQUEsT0F0R0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVHQTtBQUVKO0FBQUVrQixLQWxKSXRCO0FBb0pOLGVBQWVBO0FBQWdCLElBQUFzQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJJY29uIiwiQWN0aXZpdHlGaWx0ZXJzIiwic2VsZWN0ZWRGaWx0ZXJzIiwib25GaWx0ZXJzQ2hhbmdlIiwiYWN0aXZpdHlUeXBlcyIsInZhbHVlIiwibGFiZWwiLCJpY29uIiwiZGF0ZVJhbmdlcyIsImNoYW5uZWxzIiwidGVhbU1lbWJlcnMiLCJoYW5kbGVGaWx0ZXJDaGFuZ2UiLCJmaWx0ZXJUeXBlIiwibWFwIiwidHlwZSIsImFjdGl2aXR5VHlwZSIsImUiLCJ0YXJnZXQiLCJyYW5nZSIsImRhdGVSYW5nZSIsImNoYW5uZWwiLCJtZW1iZXIiLCJ0ZWFtTWVtYmVyIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBY3Rpdml0eUZpbHRlcnMuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCBJY29uIGZyb20gJ2NvbXBvbmVudHMvQXBwSWNvbic7XHJcblxyXG5jb25zdCBBY3Rpdml0eUZpbHRlcnMgPSAoeyBzZWxlY3RlZEZpbHRlcnMsIG9uRmlsdGVyc0NoYW5nZSB9KSA9PiB7XHJcbiAgY29uc3QgYWN0aXZpdHlUeXBlcyA9IFtcclxuICAgIHsgdmFsdWU6ICdhbGwnLCBsYWJlbDogJ0FsbCBBY3Rpdml0aWVzJywgaWNvbjogJ0FjdGl2aXR5JyB9LFxyXG4gICAgeyB2YWx1ZTogJ2VtYWlsJywgbGFiZWw6ICdFbWFpbHMnLCBpY29uOiAnTWFpbCcgfSxcclxuICAgIHsgdmFsdWU6ICdjYWxsJywgbGFiZWw6ICdDYWxscycsIGljb246ICdQaG9uZScgfSxcclxuICAgIHsgdmFsdWU6ICdtZWV0aW5nJywgbGFiZWw6ICdNZWV0aW5ncycsIGljb246ICdDYWxlbmRhcicgfSxcclxuICAgIHsgdmFsdWU6ICdkZWFsX3VwZGF0ZScsIGxhYmVsOiAnRGVhbCBVcGRhdGVzJywgaWNvbjogJ1RyZW5kaW5nVXAnIH0sXHJcbiAgICB7IHZhbHVlOiAndGFzaycsIGxhYmVsOiAnVGFza3MnLCBpY29uOiAnQ2hlY2tTcXVhcmUnIH1cclxuICBdO1xyXG5cclxuICBjb25zdCBkYXRlUmFuZ2VzID0gW1xyXG4gICAgeyB2YWx1ZTogJ2FsbCcsIGxhYmVsOiAnQWxsIFRpbWUnIH0sXHJcbiAgICB7IHZhbHVlOiAndG9kYXknLCBsYWJlbDogJ1RvZGF5JyB9LFxyXG4gICAgeyB2YWx1ZTogJ3dlZWsnLCBsYWJlbDogJ1RoaXMgV2VlaycgfSxcclxuICAgIHsgdmFsdWU6ICdtb250aCcsIGxhYmVsOiAnVGhpcyBNb250aCcgfVxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGNoYW5uZWxzID0gW1xyXG4gICAgeyB2YWx1ZTogJ2FsbCcsIGxhYmVsOiAnQWxsIENoYW5uZWxzJywgaWNvbjogJ0dsb2JlJyB9LFxyXG4gICAgeyB2YWx1ZTogJ2dtYWlsJywgbGFiZWw6ICdHbWFpbCcsIGljb246ICdNYWlsJyB9LFxyXG4gICAgeyB2YWx1ZTogJ3R3aWxpbycsIGxhYmVsOiAnUGhvbmUnLCBpY29uOiAnUGhvbmUnIH0sXHJcbiAgICB7IHZhbHVlOiAnY2FsZW5kYXInLCBsYWJlbDogJ0NhbGVuZGFyJywgaWNvbjogJ0NhbGVuZGFyJyB9LFxyXG4gICAgeyB2YWx1ZTogJ3N5c3RlbScsIGxhYmVsOiAnU3lzdGVtJywgaWNvbjogJ1NldHRpbmdzJyB9XHJcbiAgXTtcclxuXHJcbiAgY29uc3QgdGVhbU1lbWJlcnMgPSBbXHJcbiAgICB7IHZhbHVlOiAnYWxsJywgbGFiZWw6ICdBbGwgVGVhbSBNZW1iZXJzJyB9LFxyXG4gICAgeyB2YWx1ZTogJ21pY2hhZWwnLCBsYWJlbDogJ01pY2hhZWwgUm9kcmlndWV6JyB9LFxyXG4gICAgeyB2YWx1ZTogJ2plbm5pZmVyJywgbGFiZWw6ICdKZW5uaWZlciBXYWxzaCcgfSxcclxuICAgIHsgdmFsdWU6ICdhbGV4JywgbGFiZWw6ICdBbGV4IFRob21wc29uJyB9LFxyXG4gICAgeyB2YWx1ZTogJ3NhcmFoJywgbGFiZWw6ICdTYXJhaCBDaGVuJyB9XHJcbiAgXTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRmlsdGVyQ2hhbmdlID0gKGZpbHRlclR5cGUsIHZhbHVlKSA9PiB7XHJcbiAgICBvbkZpbHRlcnNDaGFuZ2Uoe1xyXG4gICAgICAuLi5zZWxlY3RlZEZpbHRlcnMsXHJcbiAgICAgIFtmaWx0ZXJUeXBlXTogdmFsdWVcclxuICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxyXG4gICAgICB7LyogQWN0aXZpdHkgVHlwZSBGaWx0ZXIgKi99XHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItM1wiPkFjdGl2aXR5IFR5cGU8L2g0PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICB7YWN0aXZpdHlUeXBlcz8ubWFwKCh0eXBlKSA9PiAoXHJcbiAgICAgICAgICAgIDxsYWJlbCBrZXk9e3R5cGU/LnZhbHVlfSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTMgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJyYWRpb1wiXHJcbiAgICAgICAgICAgICAgICBuYW1lPVwiYWN0aXZpdHlUeXBlXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXt0eXBlPy52YWx1ZX1cclxuICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3NlbGVjdGVkRmlsdGVycz8uYWN0aXZpdHlUeXBlID09PSB0eXBlPy52YWx1ZX1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRmlsdGVyQ2hhbmdlKCdhY3Rpdml0eVR5cGUnLCBlPy50YXJnZXQ/LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1wcmltYXJ5IGJvcmRlci1ib3JkZXIgZm9jdXM6cmluZy1wcmltYXJ5LTUwMFwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMlwiPlxyXG4gICAgICAgICAgICAgICAgPEljb24gbmFtZT17dHlwZT8uaWNvbn0gc2l6ZT17MTZ9IGNsYXNzTmFtZT1cInRleHQtdGV4dC1zZWNvbmRhcnlcIiAvPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+e3R5cGU/LmxhYmVsfTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICkpfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgey8qIERhdGUgUmFuZ2UgRmlsdGVyICovfVxyXG4gICAgICA8ZGl2PlxyXG4gICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IG1iLTNcIj5EYXRlIFJhbmdlPC9oND5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAge2RhdGVSYW5nZXM/Lm1hcCgocmFuZ2UpID0+IChcclxuICAgICAgICAgICAgPGxhYmVsIGtleT17cmFuZ2U/LnZhbHVlfSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTMgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJyYWRpb1wiXHJcbiAgICAgICAgICAgICAgICBuYW1lPVwiZGF0ZVJhbmdlXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtyYW5nZT8udmFsdWV9XHJcbiAgICAgICAgICAgICAgICBjaGVja2VkPXtzZWxlY3RlZEZpbHRlcnM/LmRhdGVSYW5nZSA9PT0gcmFuZ2U/LnZhbHVlfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVGaWx0ZXJDaGFuZ2UoJ2RhdGVSYW5nZScsIGU/LnRhcmdldD8udmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXByaW1hcnkgYm9yZGVyLWJvcmRlciBmb2N1czpyaW5nLXByaW1hcnktNTAwXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC10ZXh0LXNlY29uZGFyeVwiPntyYW5nZT8ubGFiZWx9PC9zcGFuPlxyXG4gICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICB7LyogQ2hhbm5lbCBGaWx0ZXIgKi99XHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC10ZXh0LXByaW1hcnkgbWItM1wiPkNvbW11bmljYXRpb24gQ2hhbm5lbDwvaDQ+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgIHtjaGFubmVscz8ubWFwKChjaGFubmVsKSA9PiAoXHJcbiAgICAgICAgICAgIDxsYWJlbCBrZXk9e2NoYW5uZWw/LnZhbHVlfSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTMgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJyYWRpb1wiXHJcbiAgICAgICAgICAgICAgICBuYW1lPVwiY2hhbm5lbFwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Y2hhbm5lbD8udmFsdWV9XHJcbiAgICAgICAgICAgICAgICBjaGVja2VkPXtzZWxlY3RlZEZpbHRlcnM/LmNoYW5uZWwgPT09IGNoYW5uZWw/LnZhbHVlfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVGaWx0ZXJDaGFuZ2UoJ2NoYW5uZWwnLCBlPy50YXJnZXQ/LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1wcmltYXJ5IGJvcmRlci1ib3JkZXIgZm9jdXM6cmluZy1wcmltYXJ5LTUwMFwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMlwiPlxyXG4gICAgICAgICAgICAgICAgPEljb24gbmFtZT17Y2hhbm5lbD8uaWNvbn0gc2l6ZT17MTZ9IGNsYXNzTmFtZT1cInRleHQtdGV4dC1zZWNvbmRhcnlcIiAvPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+e2NoYW5uZWw/LmxhYmVsfTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICkpfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgey8qIFRlYW0gTWVtYmVyIEZpbHRlciAqL31cclxuICAgICAgPGRpdj5cclxuICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXRleHQtcHJpbWFyeSBtYi0zXCI+VGVhbSBNZW1iZXI8L2g0PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICB7dGVhbU1lbWJlcnM/Lm1hcCgobWVtYmVyKSA9PiAoXHJcbiAgICAgICAgICAgIDxsYWJlbCBrZXk9e21lbWJlcj8udmFsdWV9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMyBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInJhZGlvXCJcclxuICAgICAgICAgICAgICAgIG5hbWU9XCJ0ZWFtTWVtYmVyXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXttZW1iZXI/LnZhbHVlfVxyXG4gICAgICAgICAgICAgICAgY2hlY2tlZD17c2VsZWN0ZWRGaWx0ZXJzPy50ZWFtTWVtYmVyID09PSBtZW1iZXI/LnZhbHVlfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVGaWx0ZXJDaGFuZ2UoJ3RlYW1NZW1iZXInLCBlPy50YXJnZXQ/LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1wcmltYXJ5IGJvcmRlci1ib3JkZXIgZm9jdXM6cmluZy1wcmltYXJ5LTUwMFwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtdGV4dC1zZWNvbmRhcnlcIj57bWVtYmVyPy5sYWJlbH08L3NwYW4+XHJcbiAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICApKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIHsvKiBRdWljayBBY3Rpb25zICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTQgYm9yZGVyLXQgYm9yZGVyLWJvcmRlclwiPlxyXG4gICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtdGV4dC1wcmltYXJ5IG1iLTNcIj5RdWljayBBY3Rpb25zPC9oND5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yIHB4LTMgcHktMiB0ZXh0LXNtIHRleHQtdGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC1wcmltYXJ5IGhvdmVyOmJnLXByaW1hcnktNTAgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0xNTAgZWFzZS1vdXRcIj5cclxuICAgICAgICAgICAgPEljb24gbmFtZT1cIkZpbHRlclwiIHNpemU9ezE2fSAvPlxyXG4gICAgICAgICAgICA8c3Bhbj5TYXZlIEN1cnJlbnQgRmlsdGVyPC9zcGFuPlxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwidy1mdWxsIGZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMiBweC0zIHB5LTIgdGV4dC1zbSB0ZXh0LXRleHQtc2Vjb25kYXJ5IGhvdmVyOnRleHQtcHJpbWFyeSBob3ZlcjpiZy1wcmltYXJ5LTUwIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMTUwIGVhc2Utb3V0XCI+XHJcbiAgICAgICAgICAgIDxJY29uIG5hbWU9XCJSZWZyZXNoQ3dcIiBzaXplPXsxNn0gLz5cclxuICAgICAgICAgICAgPHNwYW4+UmVmcmVzaCBUaW1lbGluZTwvc3Bhbj5cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTIgcHgtMyBweS0yIHRleHQtc20gdGV4dC10ZXh0LXNlY29uZGFyeSBob3Zlcjp0ZXh0LXByaW1hcnkgaG92ZXI6YmctcHJpbWFyeS01MCByb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTE1MCBlYXNlLW91dFwiPlxyXG4gICAgICAgICAgICA8SWNvbiBuYW1lPVwiU2V0dGluZ3NcIiBzaXplPXsxNn0gLz5cclxuICAgICAgICAgICAgPHNwYW4+VGltZWxpbmUgU2V0dGluZ3M8L3NwYW4+XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQWN0aXZpdHlGaWx0ZXJzOyJdLCJmaWxlIjoiRDovY3VycmVudCBwcm9qZWN0cy9jbGF1ZGUtY29kZS9zcmMvcGFnZXMvYWN0aXZpdHktdGltZWxpbmUvY29tcG9uZW50cy9BY3Rpdml0eUZpbHRlcnMuanN4In0=