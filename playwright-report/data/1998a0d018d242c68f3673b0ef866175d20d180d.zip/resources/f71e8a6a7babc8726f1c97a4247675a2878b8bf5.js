import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/Breadcrumb.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=44ab9529"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/current projects/claude-code/src/components/ui/Breadcrumb.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=44ab9529"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { Link, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=44ab9529";
import Icon from "/src/components/AppIcon.jsx";
const Breadcrumb = () => {
  _s();
  const location = useLocation();
  const routeMap = {
    "/sales-dashboard": { label: "Dashboard", parent: null },
    "/deal-management": { label: "Deal Management", parent: "/sales-dashboard" },
    "/contact-management": { label: "Contact Management", parent: "/sales-dashboard" },
    "/pipeline-analytics": { label: "Pipeline Analytics", parent: "/sales-dashboard" },
    "/activity-timeline": { label: "Activity Timeline", parent: "/sales-dashboard" },
    "/settings-administration": { label: "Settings & Administration", parent: "/sales-dashboard" },
    "/login": { label: "Login", parent: null }
  };
  const generateBreadcrumbs = () => {
    const currentPath = location.pathname;
    const breadcrumbs2 = [];
    if (!routeMap?.[currentPath]) {
      return breadcrumbs2;
    }
    let path = currentPath;
    while (path && routeMap?.[path]) {
      breadcrumbs2?.unshift({
        label: routeMap?.[path]?.label,
        path,
        isActive: path === currentPath
      });
      path = routeMap?.[path]?.parent;
    }
    if (breadcrumbs2?.length > 0 && breadcrumbs2?.[0]?.path !== "/sales-dashboard" && currentPath !== "/sales-dashboard") {
      breadcrumbs2?.unshift({
        label: "Dashboard",
        path: "/sales-dashboard",
        isActive: false
      });
    }
    return breadcrumbs2;
  };
  const breadcrumbs = generateBreadcrumbs();
  if (location.pathname === "/login" || breadcrumbs?.length <= 1) {
    return null;
  }
  return /* @__PURE__ */ jsxDEV("nav", { "data-component-id": "src\\components\\ui\\Breadcrumb.jsx:56:4", "data-component-path": "src\\components\\ui\\Breadcrumb.jsx", "data-component-line": "56", "data-component-file": "Breadcrumb.jsx", "data-component-name": "nav", "data-component-content": "%7B%22elementName%22%3A%22nav%22%2C%22className%22%3A%22flex%20items-center%20space-x-2%20text-sm%20mb-6%22%7D", className: "flex items-center space-x-2 text-sm mb-6", "aria-label": "Breadcrumb", children: [
    /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\components\\ui\\Breadcrumb.jsx:57:6", "data-component-path": "src\\components\\ui\\Breadcrumb.jsx", "data-component-line": "57", "data-component-file": "Breadcrumb.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22Home%22%2C%22className%22%3A%22text-text-tertiary%22%7D", name: "Home", size: 16, className: "text-text-tertiary" }, void 0, false, {
      fileName: "D:/current projects/claude-code/src/components/ui/Breadcrumb.jsx",
      lineNumber: 57,
      columnNumber: 7
    }, this),
    breadcrumbs?.map(
      (crumb, index) => /* @__PURE__ */ jsxDEV(React.Fragment, { children: [
        index > 0 && /* @__PURE__ */ jsxDEV(Icon, { "data-component-id": "src\\components\\ui\\Breadcrumb.jsx:61:8", "data-component-path": "src\\components\\ui\\Breadcrumb.jsx", "data-component-line": "61", "data-component-file": "Breadcrumb.jsx", "data-component-name": "Icon", "data-component-content": "%7B%22elementName%22%3A%22Icon%22%2C%22name%22%3A%22ChevronRight%22%2C%22className%22%3A%22text-text-tertiary%22%7D", name: "ChevronRight", size: 14, className: "text-text-tertiary" }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/components/ui/Breadcrumb.jsx",
          lineNumber: 61,
          columnNumber: 9
        }, this),
        crumb?.isActive ? /* @__PURE__ */ jsxDEV("span", { "data-component-id": "src\\components\\ui\\Breadcrumb.jsx:65:8", "data-component-path": "src\\components\\ui\\Breadcrumb.jsx", "data-component-line": "65", "data-component-file": "Breadcrumb.jsx", "data-component-name": "span", "data-component-content": "%7B%22elementName%22%3A%22span%22%2C%22className%22%3A%22text-text-primary%20font-medium%22%7D", className: "text-text-primary font-medium", "aria-current": "page", children: crumb?.label }, void 0, false, {
          fileName: "D:/current projects/claude-code/src/components/ui/Breadcrumb.jsx",
          lineNumber: 65,
          columnNumber: 9
        }, this) : /* @__PURE__ */ jsxDEV(
          Link,
          {
            "data-component-id": "src\\components\\ui\\Breadcrumb.jsx:69:8",
            "data-component-path": "src\\components\\ui\\Breadcrumb.jsx",
            "data-component-line": "69",
            "data-component-file": "Breadcrumb.jsx",
            "data-component-name": "Link",
            "data-component-content": "%7B%22elementName%22%3A%22Link%22%2C%22className%22%3A%22text-text-secondary%20hover%3Atext-primary%20transition-colors%20duration-150%20ease-smooth%22%7D",
            to: crumb?.path,
            className: "text-text-secondary hover:text-primary transition-colors duration-150 ease-smooth",
            children: crumb?.label
          },
          void 0,
          false,
          {
            fileName: "D:/current projects/claude-code/src/components/ui/Breadcrumb.jsx",
            lineNumber: 69,
            columnNumber: 9
          },
          this
        )
      ] }, crumb?.path, true, {
        fileName: "D:/current projects/claude-code/src/components/ui/Breadcrumb.jsx",
        lineNumber: 59,
        columnNumber: 7
      }, this)
    )
  ] }, void 0, true, {
    fileName: "D:/current projects/claude-code/src/components/ui/Breadcrumb.jsx",
    lineNumber: 56,
    columnNumber: 5
  }, this);
};
_s(Breadcrumb, "pkHmaVRPskBaU4tMJuJJpV42k1I=", false, function() {
  return [useLocation];
});
_c = Breadcrumb;
export default Breadcrumb;
var _c;
$RefreshReg$(_c, "Breadcrumb");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/current projects/claude-code/src/components/ui/Breadcrumb.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/current projects/claude-code/src/components/ui/Breadcrumb.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0RNOzJCQXhETjtBQUFrQixNQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3pCLFNBQVNBLE1BQU1DLG1CQUFtQjtBQUNsQyxPQUFPQyxVQUFVO0FBRWpCLE1BQU1DLGFBQWFBLE1BQU07QUFBQUMsS0FBQTtBQUN2QixRQUFNQyxXQUFXSixZQUFZO0FBRTdCLFFBQU1LLFdBQVc7QUFBQSxJQUNmLG9CQUFvQixFQUFFQyxPQUFPLGFBQWFDLFFBQVEsS0FBSztBQUFBLElBQ3ZELG9CQUFvQixFQUFFRCxPQUFPLG1CQUFtQkMsUUFBUSxtQkFBbUI7QUFBQSxJQUMzRSx1QkFBdUIsRUFBRUQsT0FBTyxzQkFBc0JDLFFBQVEsbUJBQW1CO0FBQUEsSUFDakYsdUJBQXVCLEVBQUVELE9BQU8sc0JBQXNCQyxRQUFRLG1CQUFtQjtBQUFBLElBQ2pGLHNCQUFzQixFQUFFRCxPQUFPLHFCQUFxQkMsUUFBUSxtQkFBbUI7QUFBQSxJQUMvRSw0QkFBNEIsRUFBRUQsT0FBTyw2QkFBNkJDLFFBQVEsbUJBQW1CO0FBQUEsSUFDN0YsVUFBVSxFQUFFRCxPQUFPLFNBQVNDLFFBQVEsS0FBSztBQUFBLEVBQzNDO0FBRUEsUUFBTUMsc0JBQXNCQSxNQUFNO0FBQ2hDLFVBQU1DLGNBQWNMLFNBQVNNO0FBQzdCLFVBQU1DLGVBQWM7QUFFcEIsUUFBSSxDQUFDTixXQUFXSSxXQUFXLEdBQUc7QUFDNUIsYUFBT0U7QUFBQUEsSUFDVDtBQUVBLFFBQUlDLE9BQU9IO0FBQ1gsV0FBT0csUUFBUVAsV0FBV08sSUFBSSxHQUFHO0FBQy9CRCxvQkFBYUUsUUFBUTtBQUFBLFFBQ25CUCxPQUFPRCxXQUFXTyxJQUFJLEdBQUdOO0FBQUFBLFFBQ3pCTTtBQUFBQSxRQUNBRSxVQUFVRixTQUFTSDtBQUFBQSxNQUNyQixDQUFDO0FBQ0RHLGFBQU9QLFdBQVdPLElBQUksR0FBR0w7QUFBQUEsSUFDM0I7QUFHQSxRQUFJSSxjQUFhSSxTQUFTLEtBQUtKLGVBQWMsQ0FBQyxHQUFHQyxTQUFTLHNCQUFzQkgsZ0JBQWdCLG9CQUFvQjtBQUNsSEUsb0JBQWFFLFFBQVE7QUFBQSxRQUNuQlAsT0FBTztBQUFBLFFBQ1BNLE1BQU07QUFBQSxRQUNORSxVQUFVO0FBQUEsTUFDWixDQUFDO0FBQUEsSUFDSDtBQUVBLFdBQU9IO0FBQUFBLEVBQ1Q7QUFFQSxRQUFNQSxjQUFjSCxvQkFBb0I7QUFHeEMsTUFBSUosU0FBU00sYUFBYSxZQUFZQyxhQUFhSSxVQUFVLEdBQUc7QUFDOUQsV0FBTztBQUFBLEVBQ1Q7QUFFQSxTQUNFLHVCQUFDLHdYQUFJLFdBQVUsNENBQTJDLGNBQVcsY0FDbkU7QUFBQSwyQkFBQyxxWEFBSyxNQUFLLFFBQU8sTUFBTSxJQUFJLFdBQVUsd0JBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEQ7QUFBQSxJQUN6REosYUFBYUs7QUFBQUEsTUFBSSxDQUFDQyxPQUFPQyxVQUN4Qix1QkFBQyxNQUFNLFVBQU4sRUFDRUE7QUFBQUEsZ0JBQVEsS0FDUCx1QkFBQyw2WEFBSyxNQUFLLGdCQUFlLE1BQU0sSUFBSSxXQUFVLHdCQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtFO0FBQUEsUUFHbkVELE9BQU9ILFdBQ04sdUJBQUMsMFdBQUssV0FBVSxpQ0FBZ0MsZ0JBQWEsUUFDMURHLGlCQUFPWCxTQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxJQUVBO0FBQUEsVUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFDQyxJQUFJVyxPQUFPTDtBQUFBQSxZQUNYLFdBQVU7QUFBQSxZQUVUSyxpQkFBT1g7QUFBQUE7QUFBQUEsVUFKVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLFdBZmlCVyxPQUFPTCxNQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUJBO0FBQUEsSUFDRDtBQUFBLE9BckJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzQkE7QUFFSjtBQUFFVCxHQTNFSUQsWUFBVTtBQUFBLFVBQ0dGLFdBQVc7QUFBQTtBQUFBbUIsS0FEeEJqQjtBQTZFTixlQUFlQTtBQUFXLElBQUFpQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiTGluayIsInVzZUxvY2F0aW9uIiwiSWNvbiIsIkJyZWFkY3J1bWIiLCJfcyIsImxvY2F0aW9uIiwicm91dGVNYXAiLCJsYWJlbCIsInBhcmVudCIsImdlbmVyYXRlQnJlYWRjcnVtYnMiLCJjdXJyZW50UGF0aCIsInBhdGhuYW1lIiwiYnJlYWRjcnVtYnMiLCJwYXRoIiwidW5zaGlmdCIsImlzQWN0aXZlIiwibGVuZ3RoIiwibWFwIiwiY3J1bWIiLCJpbmRleCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQnJlYWRjcnVtYi5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgTGluaywgdXNlTG9jYXRpb24gfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0IEljb24gZnJvbSAnLi4vQXBwSWNvbic7XHJcblxyXG5jb25zdCBCcmVhZGNydW1iID0gKCkgPT4ge1xyXG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcclxuICBcclxuICBjb25zdCByb3V0ZU1hcCA9IHtcclxuICAgICcvc2FsZXMtZGFzaGJvYXJkJzogeyBsYWJlbDogJ0Rhc2hib2FyZCcsIHBhcmVudDogbnVsbCB9LFxyXG4gICAgJy9kZWFsLW1hbmFnZW1lbnQnOiB7IGxhYmVsOiAnRGVhbCBNYW5hZ2VtZW50JywgcGFyZW50OiAnL3NhbGVzLWRhc2hib2FyZCcgfSxcclxuICAgICcvY29udGFjdC1tYW5hZ2VtZW50JzogeyBsYWJlbDogJ0NvbnRhY3QgTWFuYWdlbWVudCcsIHBhcmVudDogJy9zYWxlcy1kYXNoYm9hcmQnIH0sXHJcbiAgICAnL3BpcGVsaW5lLWFuYWx5dGljcyc6IHsgbGFiZWw6ICdQaXBlbGluZSBBbmFseXRpY3MnLCBwYXJlbnQ6ICcvc2FsZXMtZGFzaGJvYXJkJyB9LFxyXG4gICAgJy9hY3Rpdml0eS10aW1lbGluZSc6IHsgbGFiZWw6ICdBY3Rpdml0eSBUaW1lbGluZScsIHBhcmVudDogJy9zYWxlcy1kYXNoYm9hcmQnIH0sXHJcbiAgICAnL3NldHRpbmdzLWFkbWluaXN0cmF0aW9uJzogeyBsYWJlbDogJ1NldHRpbmdzICYgQWRtaW5pc3RyYXRpb24nLCBwYXJlbnQ6ICcvc2FsZXMtZGFzaGJvYXJkJyB9LFxyXG4gICAgJy9sb2dpbic6IHsgbGFiZWw6ICdMb2dpbicsIHBhcmVudDogbnVsbCB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZ2VuZXJhdGVCcmVhZGNydW1icyA9ICgpID0+IHtcclxuICAgIGNvbnN0IGN1cnJlbnRQYXRoID0gbG9jYXRpb24ucGF0aG5hbWU7XHJcbiAgICBjb25zdCBicmVhZGNydW1icyA9IFtdO1xyXG4gICAgXHJcbiAgICBpZiAoIXJvdXRlTWFwPy5bY3VycmVudFBhdGhdKSB7XHJcbiAgICAgIHJldHVybiBicmVhZGNydW1icztcclxuICAgIH1cclxuXHJcbiAgICBsZXQgcGF0aCA9IGN1cnJlbnRQYXRoO1xyXG4gICAgd2hpbGUgKHBhdGggJiYgcm91dGVNYXA/LltwYXRoXSkge1xyXG4gICAgICBicmVhZGNydW1icz8udW5zaGlmdCh7XHJcbiAgICAgICAgbGFiZWw6IHJvdXRlTWFwPy5bcGF0aF0/LmxhYmVsLFxyXG4gICAgICAgIHBhdGg6IHBhdGgsXHJcbiAgICAgICAgaXNBY3RpdmU6IHBhdGggPT09IGN1cnJlbnRQYXRoXHJcbiAgICAgIH0pO1xyXG4gICAgICBwYXRoID0gcm91dGVNYXA/LltwYXRoXT8ucGFyZW50O1xyXG4gICAgfVxyXG5cclxuICAgIC8vIEFsd2F5cyBpbmNsdWRlIEhvbWUvRGFzaGJvYXJkIGFzIHJvb3QgaWYgbm90IGFscmVhZHkgcHJlc2VudFxyXG4gICAgaWYgKGJyZWFkY3J1bWJzPy5sZW5ndGggPiAwICYmIGJyZWFkY3J1bWJzPy5bMF0/LnBhdGggIT09ICcvc2FsZXMtZGFzaGJvYXJkJyAmJiBjdXJyZW50UGF0aCAhPT0gJy9zYWxlcy1kYXNoYm9hcmQnKSB7XHJcbiAgICAgIGJyZWFkY3J1bWJzPy51bnNoaWZ0KHtcclxuICAgICAgICBsYWJlbDogJ0Rhc2hib2FyZCcsXHJcbiAgICAgICAgcGF0aDogJy9zYWxlcy1kYXNoYm9hcmQnLFxyXG4gICAgICAgIGlzQWN0aXZlOiBmYWxzZVxyXG4gICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gYnJlYWRjcnVtYnM7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgYnJlYWRjcnVtYnMgPSBnZW5lcmF0ZUJyZWFkY3J1bWJzKCk7XHJcblxyXG4gIC8vIERvbid0IHNob3cgYnJlYWRjcnVtYnMgb24gbG9naW4gcGFnZSBvciBpZiBvbmx5IG9uZSBpdGVtXHJcbiAgaWYgKGxvY2F0aW9uLnBhdGhuYW1lID09PSAnL2xvZ2luJyB8fCBicmVhZGNydW1icz8ubGVuZ3RoIDw9IDEpIHtcclxuICAgIHJldHVybiBudWxsO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxuYXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yIHRleHQtc20gbWItNlwiIGFyaWEtbGFiZWw9XCJCcmVhZGNydW1iXCI+XHJcbiAgICAgIDxJY29uIG5hbWU9XCJIb21lXCIgc2l6ZT17MTZ9IGNsYXNzTmFtZT1cInRleHQtdGV4dC10ZXJ0aWFyeVwiIC8+XHJcbiAgICAgIHticmVhZGNydW1icz8ubWFwKChjcnVtYiwgaW5kZXgpID0+IChcclxuICAgICAgICA8UmVhY3QuRnJhZ21lbnQga2V5PXtjcnVtYj8ucGF0aH0+XHJcbiAgICAgICAgICB7aW5kZXggPiAwICYmIChcclxuICAgICAgICAgICAgPEljb24gbmFtZT1cIkNoZXZyb25SaWdodFwiIHNpemU9ezE0fSBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtdGVydGlhcnlcIiAvPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAge2NydW1iPy5pc0FjdGl2ZSA/IChcclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC10ZXh0LXByaW1hcnkgZm9udC1tZWRpdW1cIiBhcmlhLWN1cnJlbnQ9XCJwYWdlXCI+XHJcbiAgICAgICAgICAgICAge2NydW1iPy5sYWJlbH1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICB0bz17Y3J1bWI/LnBhdGh9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC10ZXh0LXNlY29uZGFyeSBob3Zlcjp0ZXh0LXByaW1hcnkgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwIGVhc2Utc21vb3RoXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIHtjcnVtYj8ubGFiZWx9XHJcbiAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9SZWFjdC5GcmFnbWVudD5cclxuICAgICAgKSl9XHJcbiAgICA8L25hdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQnJlYWRjcnVtYjsiXSwiZmlsZSI6IkQ6L2N1cnJlbnQgcHJvamVjdHMvY2xhdWRlLWNvZGUvc3JjL2NvbXBvbmVudHMvdWkvQnJlYWRjcnVtYi5qc3gifQ==